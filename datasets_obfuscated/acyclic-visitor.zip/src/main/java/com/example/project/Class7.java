/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

/**
 * The Acyclic Visitor pattern allows new functions to be added to existing class hierarchies
 * without affecting those hierarchies, and without creating the dependency cycles that are inherent
 * to the GoF Visitor pattern, by making the Visitor base class degenerate
 *
 * <p>In this example the visitor base class is {@link Class4}. The base class of the visited
 * hierarchy is {@link Class8} and has two children {@link Class1} and {@link Class2} each one having
 * its own visitor interface {@link Class6} and {@link Class10} respectively. {@link
 * Class9} and {@link Class5} implement each derivative's visit
 * method only if it is required
 */
public class Class7 {

  /** Program's entry point. */
  public static void main(String[] args) {
    var conUnix = new Class9();
    var conDos = new Class5();

    var zoom = new Class2();
    var hayes = new Class1();

    hayes.accept(conDos); // Class1 modem with Dos configurator
    zoom.accept(conDos); // Class2 modem with Dos configurator
    hayes.accept(conUnix); // Class1 modem with Unix configurator
    zoom.accept(conUnix); // Class2 modem with Unix configurator
  }
}
