/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import com.example.project.pattern.Class4;
import com.example.project.pattern.propertiesversion.Class5;
import com.example.project.pattern.tieredversion.Class6;
import com.example.project.user.Class2;
import com.example.project.user.Class3;
import java.util.Properties;
import lombok.extern.slf4j.Slf4j;

/**
 * The Feature Toggle pattern allows for complete code executions to be turned on or off with ease.
 * This allows features to be controlled by either dynamic methods just as {@link Class2} information
 * or by {@link Properties}. In the Class1 below there are two examples. Firstly the {@link Properties}
 * version of the feature toggle, where the enhanced version of the welcome message which is
 * personalised is turned either on or off at instance creation. This method is not as dynamic as
 * the {@link Class2} driven version where the feature of the personalised welcome message is
 * dependent on the {@link Class3} the {@link Class2} is in. So if the user is a member of the
 * {@link Class3#isPaid(Class2)} then they get an enhanced version of the welcome message.
 *
 * <p>Note that this pattern can easily introduce code complexity, and if not kept in check can
 * result in redundant unmaintained code within the codebase.
 */
@Slf4j
public class Class1 {

  /**
   * Block 1 shows the {@link Class5} being run with {@link Properties}
   * setting the feature toggle to enabled.
   *
   * <p>Block 2 shows the {@link Class5} being run with {@link Properties}
   * setting the feature toggle to disabled. Notice the difference with the printed welcome message
   * the username is not included.
   *
   * <p>Block 3 shows the {@link
   * com.iluwatar.featuretoggle.pattern.tieredversion.Class6} being set up with
   * two users on who is on the free level, while the other is on the paid level. When the {@link
   * Class4#getWelcomeMessage(Class2)} is called with the paid {@link Class2} note that the welcome
   * message contains their username, while the same service call with the free tier user is more
   * generic. No username is printed.
   *
   * @see Class2
   * @see Class3
   * @see Class4
   * @see Class5
   * @see com.iluwatar.featuretoggle.pattern.tieredversion.Class6
   */
  public static void main(String[] args) {

    // Demonstrates the Class5 running with properties
    // that set the feature toggle to enabled.

    final var properties = new Properties();
    properties.put("enhancedWelcome", true);
    var service = new Class5(properties);
    final var welcomeMessage = service.getWelcomeMessage(new Class2("Jamie No Code"));
    LOGGER.info(welcomeMessage);

    // Demonstrates the Class5 running with properties
    // that set the feature toggle to disabled. Note the difference in the printed welcome message
    // where the username is not included.

    final var turnedOff = new Properties();
    turnedOff.put("enhancedWelcome", false);
    var turnedOffService = new Class5(turnedOff);
    final var welcomeMessageturnedOff =
        turnedOffService.getWelcomeMessage(new Class2("Jamie No Code"));
    LOGGER.info(welcomeMessageturnedOff);

    // Demonstrates the Class6 setup with
    // two users: one on the free tier and the other on the paid tier. When the
    // Class4#getWelcomeMessage(Class2) method is called with the paid user, the welcome
    // message includes their username. In contrast, calling the same service with the free tier
    // user results
    // in a more generic welcome message without the username.

    var service2 = new Class6();

    final var paidUser = new Class2("Jamie Coder");
    final var freeUser = new Class2("Alan Defect");

    Class3.addUserToPaidGroup(paidUser);
    Class3.addUserToFreeGroup(freeUser);

    final var welcomeMessagePaidUser = service2.getWelcomeMessage(paidUser);
    final var welcomeMessageFreeUser = service2.getWelcomeMessage(freeUser);
    LOGGER.info(welcomeMessageFreeUser);
    LOGGER.info(welcomeMessagePaidUser);
  }
}
