/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.featuretoggle.pattern;

import com.example.project.user.Class2;

/**
 * Simple interfaces to allow the calling of the method to generate the welcome message for a given
 * user. While there is a helper method to gather the status of the feature toggle. In some cases
 * there is no need for the {@link Class4#isEnhanced()} in {@link
 * com.iluwatar.featuretoggle.pattern.tieredversion.Class6} where the toggle is
 * determined by the actual {@link Class2}.
 *
 * @see com.iluwatar.featuretoggle.pattern.propertiesversion.Class5
 * @see com.iluwatar.featuretoggle.pattern.tieredversion.Class6
 * @see Class2
 */
public interface Class4 {

  /**
   * Generates a welcome message for the passed user.
   *
   * @param user the {@link Class2} to be used if the message is to be personalised.
   * @return Generated {@link String} welcome message
   */
  String getWelcomeMessage(Class2 user);

  /**
   * Returns if the welcome message to be displayed will be the enhanced version.
   *
   * @return Boolean {@code true} if enhanced.
   */
  boolean isEnhanced();
}
