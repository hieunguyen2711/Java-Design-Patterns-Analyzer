/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.featuretoggle.user;

import java.util.ArrayList;
import java.util.List;

/**
 * Contains the lists of users of different groups paid and free. Used to demonstrate the tiered
 * example of feature toggle. Allowing certain features to be available to only certain groups of
 * users.
 *
 * @see Class2
 */
public class Class3 {

  private static final List<Class2> freeGroup = new ArrayList<>();
  private static final List<Class2> paidGroup = new ArrayList<>();

  /**
   * Add the passed {@link Class2} to the free user group list.
   *
   * @param user {@link Class2} to be added to the free group
   * @throws IllegalArgumentException when user is already added to the paid group
   * @see Class2
   */
  public static void addUserToFreeGroup(final Class2 user) throws IllegalArgumentException {
    if (paidGroup.contains(user)) {
      throw new IllegalArgumentException("Class2 already member of paid group.");
    } else {
      if (!freeGroup.contains(user)) {
        freeGroup.add(user);
      }
    }
  }

  /**
   * Add the passed {@link Class2} to the paid user group list.
   *
   * @param user {@link Class2} to be added to the paid group
   * @throws IllegalArgumentException when the user is already added to the free group
   * @see Class2
   */
  public static void addUserToPaidGroup(final Class2 user) throws IllegalArgumentException {
    if (freeGroup.contains(user)) {
      throw new IllegalArgumentException("Class2 already member of free group.");
    } else {
      if (!paidGroup.contains(user)) {
        paidGroup.add(user);
      }
    }
  }

  /**
   * Method to take a {@link Class2} to determine if the user is in the {@link Class3#paidGroup}.
   *
   * @param user {@link Class2} to check if they are in the {@link Class3#paidGroup}
   * @return true if the {@link Class2} is in {@link Class3#paidGroup}
   */
  public static boolean isPaid(Class2 user) {
    return paidGroup.contains(user);
  }
}
