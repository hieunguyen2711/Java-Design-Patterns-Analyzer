/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import static org.junit.jupiter.api.Assertions.*;

import java.util.concurrent.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class Class8 {

  private Class3 gatewayFactory;
  private ExecutorService executorService;

  @BeforeEach
  void setUp() {
    gatewayFactory = new Class3();
    executorService = Executors.newFixedThreadPool(2);
    gatewayFactory.registerGateway("ServiceA", new Class1());
    gatewayFactory.registerGateway("ServiceB", new Class5());
    gatewayFactory.registerGateway("ServiceC", new Class6());
  }

  @Test
  void testServiceAExecution() throws InterruptedException, ExecutionException {
    // Test Service A execution
    Future<?> serviceAFuture =
        executorService.submit(
            () -> {
              try {
                Class2 serviceA = gatewayFactory.getGateway("ServiceA");
                serviceA.execute();
              } catch (Exception e) {
                fail("Service A should not throw an exception.");
              }
            });

    // Wait for Service A to complete
    serviceAFuture.get();
  }

  @Test
  void testServiceCExecutionWithException() throws InterruptedException, ExecutionException {
    // Test Service B execution with an exception
    Future<?> serviceBFuture =
        executorService.submit(
            () -> {
              try {
                Class2 serviceB = gatewayFactory.getGateway("ServiceB");
                serviceB.execute();
              } catch (Exception e) {
                fail("Service B should not throw an exception.");
              }
            });

    // Wait for Service B to complete
    serviceBFuture.get();
  }

  @Test
  void testServiceCExecution() throws InterruptedException, ExecutionException {
    // Test Service C execution
    Future<?> serviceCFuture =
        executorService.submit(
            () -> {
              try {
                Class2 serviceC = gatewayFactory.getGateway("ServiceC");
                serviceC.execute();
              } catch (Exception e) {
                fail("Service C should not throw an exception.");
              }
            });

    // Wait for Service C to complete
    serviceCFuture.get();
  }

  @Test
  void testServiceCError() {
    try {
      Class6 serviceC = (Class6) gatewayFactory.getGateway("ServiceC");
      serviceC.error();
      fail("Service C should throw an exception.");
    } catch (Exception e) {
      assertEquals("Service C encountered an error", e.getMessage());
    }
  }
}
