/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import static org.junit.jupiter.api.Assertions.*;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class Class7 {

  private Class3 gatewayFactory;
  private ExecutorService executorService;

  @BeforeEach
  void setUp() {
    gatewayFactory = new Class3();
    executorService = Executors.newFixedThreadPool(2);
    gatewayFactory.registerGateway("ServiceA", new Class1());
    gatewayFactory.registerGateway("ServiceB", new Class5());
    gatewayFactory.registerGateway("ServiceC", new Class6());
  }

  @Test
  void testGatewayFactoryRegistrationAndRetrieval() {
    Class2 serviceA = gatewayFactory.getGateway("ServiceA");
    Class2 serviceB = gatewayFactory.getGateway("ServiceB");
    Class2 serviceC = gatewayFactory.getGateway("ServiceC");

    // Check if the retrieved instances match their expected types
    assertTrue(
        serviceA instanceof Class1, "ServiceA should be an instance of Class1");
    assertTrue(
        serviceB instanceof Class5, "ServiceB should be an instance of Class5");
    assertTrue(
        serviceC instanceof Class6, "ServiceC should be an instance of Class6");
  }

  @Test
  void testGatewayFactoryRegistrationWithNonExistingKey() {
    Class2 nonExistingService = gatewayFactory.getGateway("NonExistingService");
    assertNull(nonExistingService);
  }

  @Test
  void testGatewayFactoryConcurrency() throws InterruptedException {
    int numThreads = 10;
    CountDownLatch latch = new CountDownLatch(numThreads);
    AtomicBoolean failed = new AtomicBoolean(false);

    for (int i = 0; i < numThreads; i++) {
      executorService.submit(
          () -> {
            try {
              Class2 serviceA = gatewayFactory.getGateway("ServiceA");
              serviceA.execute();
            } catch (Exception e) {
              failed.set(true);
            } finally {
              latch.countDown();
            }
          });
    }

    latch.await();
    assertFalse(failed.get(), "This should not fail");
  }
}
