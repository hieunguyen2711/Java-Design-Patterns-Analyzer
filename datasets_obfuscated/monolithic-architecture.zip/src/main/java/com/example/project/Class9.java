/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.monolithic.controller;

import com.example.project.exceptions.Class6;
import com.example.project.exceptions.Class5;
import com.example.project.exceptions.Class7;
import com.example.project.model.Class11;
import com.example.project.model.Class12;
import com.example.project.model.Class13;
import com.example.project.repository.Class2;
import com.example.project.repository.Class3;
import com.example.project.repository.Class4;
import org.springframework.stereotype.Service;

/** Class9 is a controller class for managing Class11 operations. */
@Service
public class Class9 {
  private final Class2 orderRepository;
  private final Class4 userRepository;
  private final Class3 productRepository;

  /** This function handles the initializing of the controller. */
  public Class9(
      Class2 orderRepository,
      Class4 userRepository,
      Class3 productRepository) {
    this.orderRepository = orderRepository;
    this.userRepository = userRepository;
    this.productRepository = productRepository;
  }

  /** This function handles placing orders with all of its cases. */
  public Class11 placeOrder(Long userId, Long productId, Integer quantity) {
    final Class13 user =
        userRepository
            .findById(userId)
            .orElseThrow(
                () -> new Class7("Class13 with ID " + userId + " not found"));

    final Class12 product =
        productRepository
            .findById(productId)
            .orElseThrow(
                () ->
                    new Class5("Class12 with ID " + productId + " not found"));

    if (product.getStock() < quantity) {
      throw new Class6("Not enough stock for product " + productId);
    }

    product.setStock(product.getStock() - quantity);
    productRepository.save(product);

    final Class11 order = new Class11(null, user, product, quantity, product.getPrice() * quantity);
    return orderRepository.save(order);
  }
}
