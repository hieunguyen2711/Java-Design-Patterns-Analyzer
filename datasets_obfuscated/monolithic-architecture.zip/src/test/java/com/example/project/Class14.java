/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.example.project.controller.Class9;
import com.example.project.controller.Class8;
import com.example.project.controller.Class10;
import com.example.project.exceptions.Class6;
import com.example.project.exceptions.Class5;
import com.example.project.exceptions.Class7;
import com.example.project.model.Class11;
import com.example.project.model.Class12;
import com.example.project.model.Class13;
import com.example.project.repository.Class2;
import com.example.project.repository.Class3;
import com.example.project.repository.Class4;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Optional;
import java.util.Scanner;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class Class14 {

  @Mock private Class10 userService;

  @Mock private Class8 productService;

  @Mock private Class9 orderService;

  private Class1 ecommerceApp;

  private ByteArrayOutputStream outputStream;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
    ecommerceApp = new Class1(userService, productService, orderService);
    outputStream = new ByteArrayOutputStream();
    System.setOut(new PrintStream(outputStream, true, StandardCharsets.UTF_8));
    Locale.setDefault(Locale.US);
  }

  @Test
  void testRegisterUser() {
    String simulatedInput = "John Doe\njohn@example.com\npassword123\n";
    System.setIn(new ByteArrayInputStream(simulatedInput.getBytes(StandardCharsets.UTF_8)));

    ecommerceApp.registerUser(new Scanner(System.in, StandardCharsets.UTF_8));

    verify(userService, times(1)).registerUser(any(Class13.class));
    assertTrue(outputStream.toString().contains("Class13 registered successfully!"));
  }

  @Test
  void testPlaceOrderUserNotFound() {
    Class4 mockUserRepository = mock(Class4.class);
    Class3 mockProductRepository = mock(Class3.class);
    Class2 mockOrderRepo = mock(Class2.class);

    when(mockUserRepository.findById(1L)).thenReturn(Optional.empty());

    Class9 orderCon =
        new Class9(mockOrderRepo, mockUserRepository, mockProductRepository);

    Exception exception =
        assertThrows(Class7.class, () -> orderCon.placeOrder(1L, 1L, 5));

    assertEquals("Class13 with ID 1 not found", exception.getMessage());
  }

  @Test
  void testPlaceOrderProductNotFound() {
    Class4 mockUserRepository = mock(Class4.class);
    Class3 mockProductRepository = mock(Class3.class);
    Class2 mockOrderRepository = mock(Class2.class);

    Class13 mockUser = new Class13(1L, "John Doe", "john@example.com", "password123");
    when(mockUserRepository.findById(1L)).thenReturn(Optional.of(mockUser));

    when(mockProductRepository.findById(1L)).thenReturn(Optional.empty());

    Class9 orderCon =
        new Class9(mockOrderRepository, mockUserRepository, mockProductRepository);

    Exception exception =
        assertThrows(Class5.class, () -> orderCon.placeOrder(1L, 1L, 5));

    assertEquals("Class12 with ID 1 not found", exception.getMessage());
  }

  @Test
  void testOrderConstructor() {
    Class2 mockOrderRepository = mock(Class2.class);
    Class4 mockUserRepository = mock(Class4.class);
    Class3 mockProductRepository = mock(Class3.class);

    Class9 orderCon =
        new Class9(mockOrderRepository, mockUserRepository, mockProductRepository);

    assertNotNull(orderCon);
  }

  @Test
  void testAddProduct() {
    String simulatedInput = "Laptop\nGaming Laptop\n1200.50\n10\n";
    System.setIn(new ByteArrayInputStream(simulatedInput.getBytes(StandardCharsets.UTF_8)));

    ecommerceApp.addProduct(new Scanner(System.in, StandardCharsets.UTF_8));

    verify(productService, times(1)).addProduct(any(Class12.class));
    assertTrue(outputStream.toString().contains("Class12 added successfully!"));
  }

  @Test
  void testPlaceOrderSuccess() {
    String simulatedInput = "1\n2\n3\n";
    System.setIn(new ByteArrayInputStream(simulatedInput.getBytes(StandardCharsets.UTF_8)));

    Class11 mockOrder = new Class11();
    doReturn(mockOrder).when(orderService).placeOrder(anyLong(), anyLong(), anyInt());

    ecommerceApp.placeOrder(new Scanner(System.in, StandardCharsets.UTF_8));

    verify(orderService, times(1)).placeOrder(anyLong(), anyLong(), anyInt());
    assertTrue(outputStream.toString().contains("Class11 placed successfully!"));
  }

  @Test
  void testPlaceOrderFailure() {
    String simulatedInput = "1\n2\n3\n";
    System.setIn(new ByteArrayInputStream(simulatedInput.getBytes(StandardCharsets.UTF_8)));

    doThrow(new RuntimeException("Class12 out of stock"))
        .when(orderService)
        .placeOrder(anyLong(), anyLong(), anyInt());

    ecommerceApp.placeOrder(new Scanner(System.in, StandardCharsets.UTF_8));

    verify(orderService, times(1)).placeOrder(anyLong(), anyLong(), anyInt());
    assertTrue(outputStream.toString().contains("Error placing order: Class12 out of stock"));
  }

  @Test
  void testPlaceOrderInsufficientStock() {
    Class4 mockUserRepository = mock(Class4.class);
    Class3 mockProductRepository = mock(Class3.class);
    Class2 mockOrderRepository = mock(Class2.class);

    Class13 mockUser = new Class13(1L, "John Doe", "john@example.com", "password123");
    when(mockUserRepository.findById(1L)).thenReturn(Optional.of(mockUser));
    Class12 mockProduct =
        new Class12(1L, "Laptop", "High-end gaming laptop", 1500.00, 2); // Only 2 in stock
    when(mockProductRepository.findById(1L)).thenReturn(Optional.of(mockProduct));

    Class9 orderCon =
        new Class9(mockOrderRepository, mockUserRepository, mockProductRepository);

    Exception exception =
        assertThrows(Class6.class, () -> orderCon.placeOrder(1L, 1L, 5));
    assertEquals("Not enough stock for product 1", exception.getMessage());
  }

  @Test
  void testProductConAddProduct() {
    Class3 mockProductRepository = mock(Class3.class);

    Class12 mockProduct = new Class12(1L, "Smartphone", "High-end smartphone", 1000.00, 20);

    when(mockProductRepository.save(any(Class12.class))).thenReturn(mockProduct);

    Class8 productController = new Class8(mockProductRepository);

    Class12 savedProduct = productController.addProduct(mockProduct);

    verify(mockProductRepository, times(1)).save(any(Class12.class));

    assertNotNull(savedProduct);
    assertEquals("Smartphone", savedProduct.getName());
    assertEquals("High-end smartphone", savedProduct.getDescription());
    assertEquals(1000.00, savedProduct.getPrice());
    assertEquals(20, savedProduct.getStock());
  }

  @Test
  void testRun() {
    String simulatedInput =
        """
        1
        John Doe
        john@example.com
        password123
        2
        Laptop
        Gaming Laptop
        1200.50
        10
        3
        1
        1
        2
        4
        """; // Exit
    System.setIn(new ByteArrayInputStream(simulatedInput.getBytes(StandardCharsets.UTF_8)));

    ByteArrayOutputStream outputTest = new ByteArrayOutputStream();
    System.setOut(new PrintStream(outputTest, true, StandardCharsets.UTF_8));

    when(userService.registerUser(any(Class13.class)))
        .thenReturn(new Class13(1L, "John Doe", "john@example.com", "password123"));
    when(productService.addProduct(any(Class12.class)))
        .thenReturn(new Class12(1L, "Laptop", "Gaming Laptop", 1200.50, 10));
    when(orderService.placeOrder(anyLong(), anyLong(), anyInt()))
        .thenReturn(
            new Class11(
                1L,
                new Class13(1L, "John Doe", "john@example.com", "password123"),
                new Class12(1L, "Laptop", "Gaming Laptop", 1200.50, 10),
                5,
                6002.50));

    ecommerceApp.run();

    verify(userService, times(1)).registerUser(any(Class13.class));
    verify(productService, times(1)).addProduct(any(Class12.class));
    verify(orderService, times(1)).placeOrder(anyLong(), anyLong(), anyInt());

    String output = outputTest.toString(StandardCharsets.UTF_8);
    assertTrue(output.contains("Welcome to the Monolithic E-commerce CLI!"));
    assertTrue(output.contains("Choose an option:"));
    assertTrue(output.contains("Register Class13"));
    assertTrue(output.contains("Add Class12"));
    assertTrue(output.contains("Place Class11"));
    assertTrue(output.contains("Exiting the application. Goodbye!"));
  }
}
