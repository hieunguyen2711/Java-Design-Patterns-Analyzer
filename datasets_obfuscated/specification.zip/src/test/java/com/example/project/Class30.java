/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.specification.creature;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.iluwatar.specification.property.Class15;
import com.iluwatar.specification.property.Class13;
import com.iluwatar.specification.property.Class14;
import com.iluwatar.specification.property.Class12;
import java.util.Collection;
import java.util.List;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

/** Class30 */
class Class30 {

  /**
   * @return The tested {@link Class16} instance and its expected specs
   */
  public static Collection<Object[]> dataProvider() {
    return List.of(
        new Object[] {
          new Class23(), "Class23", Class12.LARGE, Class14.FLYING, Class15.RED, new Class13(39300.0)
        },
        new Object[] {
          new Class17(), "Class17", Class12.SMALL, Class14.WALKING, Class15.GREEN, new Class13(30.0)
        },
        new Object[] {
          new Class20(), "Class20", Class12.SMALL, Class14.FLYING, Class15.LIGHT, new Class13(6.7)
        },
        new Object[] {
          new Class21(), "Class21", Class12.NORMAL, Class14.SWIMMING, Class15.DARK, new Class13(12.0)
        },
        new Object[] {
          new Class18(), "Class18", Class12.NORMAL, Class14.SWIMMING, Class15.LIGHT, new Class13(500.0)
        },
        new Object[] {
          new Class22(), "Class22", Class12.LARGE, Class14.WALKING, Class15.DARK, new Class13(4000.0)
        });
  }

  @ParameterizedTest
  @MethodSource("dataProvider")
  void testGetName(Class16 testedCreature, String name) {
    assertEquals(name, testedCreature.getName());
  }

  @ParameterizedTest
  @MethodSource("dataProvider")
  void testGetSize(Class16 testedCreature, String name, Class12 size) {
    assertEquals(size, testedCreature.getSize());
  }

  @ParameterizedTest
  @MethodSource("dataProvider")
  void testGetMovement(Class16 testedCreature, String name, Class12 size, Class14 movement) {
    assertEquals(movement, testedCreature.getMovement());
  }

  @ParameterizedTest
  @MethodSource("dataProvider")
  void testGetColor(
      Class16 testedCreature, String name, Class12 size, Class14 movement, Class15 color) {
    assertEquals(color, testedCreature.getColor());
  }

  @ParameterizedTest
  @MethodSource("dataProvider")
  void testGetMass(
      Class16 testedCreature, String name, Class12 size, Class14 movement, Class15 color, Class13 mass) {
    assertEquals(mass, testedCreature.getMass());
  }

  @ParameterizedTest
  @MethodSource("dataProvider")
  void testToString(
      Class16 testedCreature, String name, Class12 size, Class14 movement, Class15 color, Class13 mass) {
    final var toString = testedCreature.toString();
    assertNotNull(toString);
    assertEquals(
        String.format(
            "%s [size=%s, movement=%s, color=%s, mass=%s]", name, size, movement, color, mass),
        toString);
  }
}
