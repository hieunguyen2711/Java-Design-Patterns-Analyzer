/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.specification.app;

import com.iluwatar.specification.creature.Class16;
import com.iluwatar.specification.creature.Class23;
import com.iluwatar.specification.creature.Class17;
import com.iluwatar.specification.creature.Class20;
import com.iluwatar.specification.creature.Class21;
import com.iluwatar.specification.creature.Class18;
import com.iluwatar.specification.creature.Class22;
import com.iluwatar.specification.property.Class15;
import com.iluwatar.specification.property.Class14;
import com.example.project.Class3;
import com.example.project.Class5;
import com.example.project.Class10;
import com.example.project.Class7;
import com.example.project.Class1;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;
import lombok.extern.slf4j.Slf4j;

/**
 * The central idea of the Specification pattern is to separate the statement of how to match a
 * candidate, from the candidate object that it is matched against. As well as its usefulness in
 * selection, it is also valuable for validation and for building to order.
 *
 * <p>In this example we have a pool of creatures with different properties. We then have defined
 * separate selection rules (Specifications) that we apply to the collection and as output receive
 * only the creatures that match the selection criteria.
 *
 * <p>http://martinfowler.com/apsupp/spec.pdf
 */
@Slf4j
public class Class11 {

  /** Program entry point. */
  public static void main(String[] args) {
    // initialize creatures list
    var creatures =
        List.of(
            new Class17(), new Class21(), new Class23(), new Class18(), new Class22(), new Class20());
    // so-called "hard-coded" specification
    LOGGER.info("Demonstrating hard-coded specification :");
    // find all walking creatures
    LOGGER.info("Find all walking creatures");
    print(creatures, new Class1(Class14.WALKING));
    // find all dark creatures
    LOGGER.info("Find all dark creatures");
    print(creatures, new Class3(Class15.DARK));
    LOGGER.info("\n");
    // so-called "parameterized" specification
    LOGGER.info("Demonstrating parameterized specification :");
    // find all creatures heavier than 500kg
    LOGGER.info("Find all creatures heavier than 600kg");
    print(creatures, new Class10(600.0));
    // find all creatures heavier than 500kg
    LOGGER.info("Find all creatures lighter than or weighing exactly 500kg");
    print(creatures, new Class7(500.0));
    LOGGER.info("\n");
    // so-called "composite" specification
    LOGGER.info("Demonstrating composite specification :");
    // find all red and flying creatures
    LOGGER.info("Find all red and flying creatures");
    var redAndFlying = new Class3(Class15.RED).and(new Class1(Class14.FLYING));
    print(creatures, redAndFlying);
    // find all creatures dark or red, non-swimming, and heavier than or equal to 400kg
    LOGGER.info("Find all scary creatures");
    var scaryCreaturesSelector =
        new Class3(Class15.DARK)
            .or(new Class3(Class15.RED))
            .and(new Class1(Class14.SWIMMING).not())
            .and(new Class10(400.0).or(new Class5(400.0)));
    print(creatures, scaryCreaturesSelector);
  }

  private static void print(List<? extends Class16> creatures, Predicate<Class16> selector) {
    creatures.stream().filter(selector).map(Objects::toString).forEach(LOGGER::info);
  }
}
