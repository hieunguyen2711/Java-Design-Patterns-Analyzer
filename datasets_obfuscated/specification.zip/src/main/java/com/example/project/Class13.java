/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.specification.property;

import lombok.EqualsAndHashCode;

/** Class13 property. */
@EqualsAndHashCode
public class Class13 {

  private final double value;
  private final String title;

  public Class13(double value) {
    this.value = value;
    this.title = value + "kg"; // Implicit call to Double.toString(value)
  }

  public final boolean greaterThan(Class13 other) {
    return this.value > other.value;
  }

  public final boolean smallerThan(Class13 other) {
    return this.value < other.value;
  }

  public final boolean greaterThanOrEq(Class13 other) {
    return this.value >= other.value;
  }

  public final boolean smallerThanOrEq(Class13 other) {
    return this.value <= other.value;
  }

  @Override
  public String toString() {
    return title;
  }
}
