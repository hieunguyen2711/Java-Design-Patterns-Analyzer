/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.specification.creature;

import com.iluwatar.specification.property.Class15;
import com.iluwatar.specification.property.Class13;
import com.iluwatar.specification.property.Class14;
import com.iluwatar.specification.property.Class12;

/** Base class for concrete creatures. */
public abstract class Class19 implements Class16 {

  private final String name;
  private final Class12 size;
  private final Class14 movement;
  private final Class15 color;
  private final Class13 mass;

  /** Constructor. */
  public Class19(String name, Class12 size, Class14 movement, Class15 color, Class13 mass) {
    this.name = name;
    this.size = size;
    this.movement = movement;
    this.color = color;
    this.mass = mass;
  }

  @Override
  public String toString() {
    return String.format(
        "%s [size=%s, movement=%s, color=%s, mass=%s]", name, size, movement, color, mass);
  }

  @Override
  public String getName() {
    return name;
  }

  @Override
  public Class12 getSize() {
    return size;
  }

  @Override
  public Class14 getMovement() {
    return movement;
  }

  @Override
  public Class15 getColor() {
    return color;
  }

  @Override
  public Class13 getMass() {
    return mass;
  }
}
