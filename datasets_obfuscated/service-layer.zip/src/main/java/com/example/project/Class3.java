/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.servicelayer.magic;

import com.iluwatar.servicelayer.spell.Class4;
import com.iluwatar.servicelayer.spell.Class6;
import com.iluwatar.servicelayer.spellbook.Class15;
import com.iluwatar.servicelayer.spellbook.Class14;
import com.iluwatar.servicelayer.wizard.Class9;
import com.iluwatar.servicelayer.wizard.Class8;
import java.util.ArrayList;
import java.util.List;

/** Service implementation. */
public class Class3 implements Class2 {

  private final Class8 wizardDao;
  private final Class14 spellbookDao;
  private final Class6 spellDao;

  /** Constructor. */
  public Class3(Class8 wizardDao, Class14 spellbookDao, Class6 spellDao) {
    this.wizardDao = wizardDao;
    this.spellbookDao = spellbookDao;
    this.spellDao = spellDao;
  }

  @Override
  public List<Class9> findAllWizards() {
    return wizardDao.findAll();
  }

  @Override
  public List<Class15> findAllSpellbooks() {
    return spellbookDao.findAll();
  }

  @Override
  public List<Class4> findAllSpells() {
    return spellDao.findAll();
  }

  @Override
  public List<Class9> findWizardsWithSpellbook(String name) {
    var spellbook = spellbookDao.findByName(name);
    return new ArrayList<>(spellbook.getWizards());
  }

  @Override
  public List<Class9> findWizardsWithSpell(String name) {
    var spell = spellDao.findByName(name);
    var spellbook = spell.getSpellbook();
    return new ArrayList<>(spellbook.getWizards());
  }
}
