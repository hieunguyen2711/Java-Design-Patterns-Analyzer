/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.servicelayer.magic;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import com.iluwatar.servicelayer.spell.Class4;
import com.iluwatar.servicelayer.spell.Class6;
import com.iluwatar.servicelayer.spellbook.Class15;
import com.iluwatar.servicelayer.spellbook.Class14;
import com.iluwatar.servicelayer.wizard.Class9;
import com.iluwatar.servicelayer.wizard.Class8;
import java.util.Set;
import org.junit.jupiter.api.Test;

/** Class18 */
class Class18 {

  @Test
  void testFindAllWizards() {
    final var wizardDao = mock(Class8.class);
    final var spellbookDao = mock(Class14.class);
    final var spellDao = mock(Class6.class);

    final var service = new Class3(wizardDao, spellbookDao, spellDao);
    verifyNoInteractions(wizardDao, spellbookDao, spellDao);

    service.findAllWizards();
    verify(wizardDao).findAll();
    verifyNoMoreInteractions(wizardDao, spellbookDao, spellDao);
  }

  @Test
  void testFindAllSpellbooks() {
    final var wizardDao = mock(Class8.class);
    final var spellbookDao = mock(Class14.class);
    final var spellDao = mock(Class6.class);

    final var service = new Class3(wizardDao, spellbookDao, spellDao);
    verifyNoInteractions(wizardDao, spellbookDao, spellDao);

    service.findAllSpellbooks();
    verify(spellbookDao).findAll();
    verifyNoMoreInteractions(wizardDao, spellbookDao, spellDao);
  }

  @Test
  void testFindAllSpells() {
    final var wizardDao = mock(Class8.class);
    final var spellbookDao = mock(Class14.class);
    final var spellDao = mock(Class6.class);

    final var service = new Class3(wizardDao, spellbookDao, spellDao);
    verifyNoInteractions(wizardDao, spellbookDao, spellDao);

    service.findAllSpells();
    verify(spellDao).findAll();
    verifyNoMoreInteractions(wizardDao, spellbookDao, spellDao);
  }

  @Test
  void testFindWizardsWithSpellbook() {
    final var bookname = "bookname";
    final var spellbook = mock(Class15.class);
    final var wizards = Set.of(mock(Class9.class), mock(Class9.class), mock(Class9.class));
    when(spellbook.getWizards()).thenReturn(wizards);

    final var spellbookDao = mock(Class14.class);
    when(spellbookDao.findByName(bookname)).thenReturn(spellbook);

    final var wizardDao = mock(Class8.class);
    final var spellDao = mock(Class6.class);

    final var service = new Class3(wizardDao, spellbookDao, spellDao);
    verifyNoInteractions(wizardDao, spellbookDao, spellDao, spellbook);

    final var result = service.findWizardsWithSpellbook(bookname);
    verify(spellbookDao).findByName(bookname);
    verify(spellbook).getWizards();

    assertNotNull(result);
    assertEquals(3, result.size());

    verifyNoMoreInteractions(wizardDao, spellbookDao, spellDao);
  }

  @Test
  void testFindWizardsWithSpell() {
    final var wizards = Set.of(mock(Class9.class), mock(Class9.class), mock(Class9.class));
    final var spellbook = mock(Class15.class);
    when(spellbook.getWizards()).thenReturn(wizards);

    final var spellbookDao = mock(Class14.class);
    final var wizardDao = mock(Class8.class);

    final var spell = mock(Class4.class);
    when(spell.getSpellbook()).thenReturn(spellbook);

    final var spellName = "spellname";
    final var spellDao = mock(Class6.class);
    when(spellDao.findByName(spellName)).thenReturn(spell);

    final var service = new Class3(wizardDao, spellbookDao, spellDao);
    verifyNoInteractions(wizardDao, spellbookDao, spellDao, spellbook);

    final var result = service.findWizardsWithSpell(spellName);
    verify(spellDao).findByName(spellName);
    verify(spellbook).getWizards();

    assertNotNull(result);
    assertEquals(3, result.size());

    verifyNoMoreInteractions(wizardDao, spellbookDao, spellDao);
  }
}
