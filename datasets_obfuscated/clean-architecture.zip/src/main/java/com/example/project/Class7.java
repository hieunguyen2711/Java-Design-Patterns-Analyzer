/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import java.util.List;

/**
 * Service class for managing shopping cart operations.
 *
 * <p>This class provides functionalities to add and remove items from the cart, calculate the total
 * price, and handle checkout operations.
 */
public class Class7 {
  /** Repository for managing product data. */
  private final Class6 productRepository;

  /** Repository for managing cart data. */
  private final Class8 cartRepository;

  /** Repository for managing order data. */
  private final Class2 orderRepository;

  /**
   * Constructs a Class7 with the required repositories.
   *
   * @param pdtRepository The repository to fetch product details.
   * @param repository The repository to manage cart operations.
   * @param ordRepository The repository to handle order persistence.
   */
  public Class7(
      final Class6 pdtRepository,
      final Class8 repository,
      final Class2 ordRepository) {
    this.productRepository = pdtRepository;
    this.cartRepository = repository;
    this.orderRepository = ordRepository;
  }

  /**
   * Adds an item to the user's shopping cart.
   *
   * @param userId The ID of the user.
   * @param productId The ID of the product to be added.
   * @param quantity The quantity of the product.
   */
  public void addItemToCart(final String userId, final String productId, final int quantity) {
    Class5 product = productRepository.getProductById(productId);
    if (product != null) {
      cartRepository.addItemToCart(userId, product, quantity);
    }
  }

  /**
   * Removes an item from the user's shopping cart.
   *
   * @param userId The ID of the user.
   * @param productId The ID of the product to be removed.
   */
  public void removeItemFromCart(final String userId, final String productId) {
    cartRepository.removeItemFromCart(userId, productId);
  }

  /**
   * Calculates the total cost of items in the user's shopping cart.
   *
   * @param userId The ID of the user.
   * @return The total price of all items in the cart.
   */
  public double calculateTotal(final String userId) {
    return cartRepository.calculateTotal(userId);
  }

  /**
   * Checks out the user's cart and creates an order.
   *
   * <p>This method retrieves the cart items, generates an order ID, creates a new order, saves it,
   * and clears the cart.
   *
   * @param userId The ID of the user.
   * @return The created order containing purchased items.
   */
  public Class1 checkout(final String userId) {
    List<Class12> items = cartRepository.getItemsInCart(userId);
    String orderId = "ORDER-" + System.currentTimeMillis();
    Class1 order = new Class1(orderId, items);
    orderRepository.saveOrder(order);
    cartRepository.clearCart(userId);
    return order;
  }
}
