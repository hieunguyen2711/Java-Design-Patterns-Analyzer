/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;

/** Tests that Collection Pipeline methods work as expected. */
@Slf4j
class Class8 {

  private final List<Class7> cars = Class2.createCars();

  @Test
  void testGetModelsAfter2000UsingFor() {
    var models = Class1.getModelsAfter2000(cars);
    assertEquals(List.of("Avenger", "Wrangler", "Focus", "Cascada"), models);
  }

  @Test
  void testGetModelsAfter2000UsingPipeline() {
    var models = Class3.getModelsAfter2000(cars);
    assertEquals(List.of("Avenger", "Wrangler", "Focus", "Cascada"), models);
  }

  @Test
  void testGetGroupingOfCarsByCategory() {
    var modelsExpected =
        Map.of(
            Class4.CONVERTIBLE,
                List.of(
                    new Class7("Buick", "Cascada", 2016, Class4.CONVERTIBLE),
                    new Class7("Chevrolet", "Geo Metro", 1992, Class4.CONVERTIBLE)),
            Class4.SEDAN,
                List.of(
                    new Class7("Dodge", "Avenger", 2010, Class4.SEDAN),
                    new Class7("Ford", "Focus", 2012, Class4.SEDAN)),
            Class4.JEEP,
                List.of(
                    new Class7("Jeep", "Wrangler", 2011, Class4.JEEP),
                    new Class7("Jeep", "Comanche", 1990, Class4.JEEP)));
    var modelsFunctional = Class3.getGroupingOfCarsByCategory(cars);
    var modelsImperative = Class1.getGroupingOfCarsByCategory(cars);
    LOGGER.info("Class4 " + modelsFunctional);
    assertEquals(modelsExpected, modelsFunctional);
    assertEquals(modelsExpected, modelsImperative);
  }

  @Test
  void testGetSedanCarsOwnedSortedByDate() {
    var john = new Class5(cars);
    var modelsExpected =
        List.of(
            new Class7("Dodge", "Avenger", 2010, Class4.SEDAN),
            new Class7("Ford", "Focus", 2012, Class4.SEDAN));
    var modelsFunctional = Class3.getSedanCarsOwnedSortedByDate(List.of(john));
    var modelsImperative = Class1.getSedanCarsOwnedSortedByDate(List.of(john));
    assertEquals(modelsExpected, modelsFunctional);
    assertEquals(modelsExpected, modelsImperative);
  }
}
