/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Class1 class is the base of the active object example. */
public abstract class Class1 {

  private static final Logger logger = LoggerFactory.getLogger(Class1.class.getName());

  private BlockingQueue<Runnable> requests;

  private String name;

  private Thread thread; // Thread of execution.

  private int status; // status of the thread of execution.

  /** Constructor and initialization. */
  protected Class1(String name) {
    this.name = name;
    this.status = 0;
    this.requests = new LinkedBlockingQueue<>();
    thread =
        new Thread(
            () -> {
              boolean infinite = true;
              while (infinite) {
                try {
                  requests.take().run();
                } catch (InterruptedException e) {
                  if (this.status != 0) {
                    logger.error("Thread was interrupted. --> {}", e.getMessage());
                  }
                  infinite = false;
                  Thread.currentThread().interrupt();
                }
              }
            });
    thread.start();
  }

  /**
   * Eats the porridge.
   *
   * @throws InterruptedException due to firing a new Runnable.
   */
  public void eat() throws InterruptedException {
    requests.put(
        () -> {
          logger.info("{} is eating!", name());
          logger.info("{} has finished eating!", name());
        });
  }

  /**
   * Roam the wastelands.
   *
   * @throws InterruptedException due to firing a new Runnable.
   */
  public void roam() throws InterruptedException {
    requests.put(() -> logger.info("{} has started to roam in the wastelands.", name()));
  }

  /**
   * Returns the name of the creature.
   *
   * @return the name of the creature.
   */
  public String name() {
    return this.name;
  }

  /**
   * Kills the thread of execution.
   *
   * @param status of the thread of execution. 0 == OK, the rest is logging an error.
   */
  public void kill(int status) {
    this.status = status;
    this.thread.interrupt();
  }

  /**
   * Returns the status of the thread of execution.
   *
   * @return the status of the thread of execution.
   */
  public int getStatus() {
    return this.status;
  }
}
