/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import com.example.project.actions.Class7;
import com.example.project.actions.Class6;
import com.example.project.actions.Class11;
import com.example.project.actions.Class10;
import com.example.project.actions.Class9;
import com.example.project.actions.Class8;

/**
 * Handle transformations to {@link Class1} based on intercepted {@link Class6}.
 */
public final class Class3 {

  /** Current calculator model (can be changed). */
  private Class1 model = new Class1(0.0, 0.0);

  /**
   * Handle calculator action.
   *
   * @param action -> transforms calculator model.
   */
  void handleAction(final Class6 action) {
    switch (action.tag()) {
      case Class7.ADDITION -> add();
      case Class8.SUBTRACTION -> subtract();
      case Class10.MULTIPLICATION -> multiply();
      case Class11.DIVISION -> divide();
      case Class9.SET_VARIABLE -> {
        Class9 setVariableAction = (Class9) action;
        setVariable(setVariableAction.getVariable());
      }
      default -> throw new IllegalArgumentException("Unknown tag");
    }
  }

  /**
   * Getter.
   *
   * @return current calculator model.
   */
  public Class1 getCalculatorModel() {
    return model;
  }

  /**
   * Set new calculator model variable.
   *
   * @param variable -> value of new calculator model variable.
   */
  private void setVariable(final Double variable) {
    model = new Class1(variable, model.getOutput());
  }

  /** Add variable to model output. */
  private void add() {
    model = new Class1(model.getVariable(), model.getOutput() + model.getVariable());
  }

  /** Subtract variable from model output. */
  private void subtract() {
    model = new Class1(model.getVariable(), model.getOutput() - model.getVariable());
  }

  /** Multiply model output by variable. */
  private void multiply() {
    model = new Class1(model.getVariable(), model.getOutput() * model.getVariable());
  }

  /** Divide model output by variable. */
  private void divide() {
    model = new Class1(model.getVariable(), model.getOutput() / model.getVariable());
  }
}
