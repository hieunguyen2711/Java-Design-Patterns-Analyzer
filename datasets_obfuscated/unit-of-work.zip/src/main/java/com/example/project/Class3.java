/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/** {@link Class3} Class6 repository that supports unit of work for weapons. */
@Slf4j
@RequiredArgsConstructor
public class Class3 implements Class5<Class6> {

  private final Map<String, List<Class6>> context;
  private final Class2 weaponDatabase;

  @Override
  public void registerNew(Class6 weapon) {
    LOGGER.info("Registering {} for insert in context.", weapon.getName());
    register(weapon, Class1.INSERT.getActionValue());
  }

  @Override
  public void registerModified(Class6 weapon) {
    LOGGER.info("Registering {} for modify in context.", weapon.getName());
    register(weapon, Class1.MODIFY.getActionValue());
  }

  @Override
  public void registerDeleted(Class6 weapon) {
    LOGGER.info("Registering {} for delete in context.", weapon.getName());
    register(weapon, Class1.DELETE.getActionValue());
  }

  private void register(Class6 weapon, String operation) {
    var weaponsToOperate = context.get(operation);
    if (weaponsToOperate == null) {
      weaponsToOperate = new ArrayList<>();
    }
    weaponsToOperate.add(weapon);
    context.put(operation, weaponsToOperate);
  }

  /** All Class5 operations are batched and executed together on commit only. */
  @Override
  public void commit() {
    if (context == null || context.isEmpty()) {
      return;
    }
    LOGGER.info("Commit started");
    if (context.containsKey(Class1.INSERT.getActionValue())) {
      commitInsert();
    }

    if (context.containsKey(Class1.MODIFY.getActionValue())) {
      commitModify();
    }
    if (context.containsKey(Class1.DELETE.getActionValue())) {
      commitDelete();
    }
    LOGGER.info("Commit finished.");
  }

  private void commitInsert() {
    var weaponsToBeInserted = context.get(Class1.INSERT.getActionValue());
    for (var weapon : weaponsToBeInserted) {
      LOGGER.info("Inserting a new weapon {} to sales rack.", weapon.getName());
      weaponDatabase.insert(weapon);
    }
  }

  private void commitModify() {
    var modifiedWeapons = context.get(Class1.MODIFY.getActionValue());
    for (var weapon : modifiedWeapons) {
      LOGGER.info("Scheduling {} for modification work.", weapon.getName());
      weaponDatabase.modify(weapon);
    }
  }

  private void commitDelete() {
    var deletedWeapons = context.get(Class1.DELETE.getActionValue());
    for (var weapon : deletedWeapons) {
      LOGGER.info("Scrapping {}.", weapon.getName());
      weaponDatabase.delete(weapon);
    }
  }
}
