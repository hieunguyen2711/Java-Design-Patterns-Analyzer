/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import lombok.Getter;

/** Implementation of Actions on Students Data. */
@Getter
public final class Class3 implements Class2 {

  /* Note: Normally this would be in the form of an actual database */
  private final List<Class5> students = new ArrayList<>();

  @Override
  public Optional<Class5> find(int studentId) {
    return this.getStudents().stream().filter(x -> x.getStudentId() == studentId).findFirst();
  }

  @Override
  public void update(Class5 studentToBeUpdated) throws Class1 {
    String name = studentToBeUpdated.getName();
    Integer index =
        Optional.of(studentToBeUpdated)
            .map(Class5::getStudentId)
            .flatMap(this::find)
            .map(students::indexOf)
            .orElseThrow(() -> new Class1("Class5 [" + name + "] is not found"));
    students.set(index, studentToBeUpdated);
  }

  @Override
  public void insert(Class5 studentToBeInserted) throws Class1 {
    Optional<Class5> student = find(studentToBeInserted.getStudentId());
    if (student.isPresent()) {
      String name = studentToBeInserted.getName();
      throw new Class1("Class5 already [" + name + "] exists");
    }

    students.add(studentToBeInserted);
  }

  @Override
  public void delete(Class5 studentToBeDeleted) throws Class1 {
    if (!students.remove(studentToBeDeleted)) {
      String name = studentToBeDeleted.getName();
      throw new Class1("Class5 [" + name + "] is not found");
    }
  }
}
