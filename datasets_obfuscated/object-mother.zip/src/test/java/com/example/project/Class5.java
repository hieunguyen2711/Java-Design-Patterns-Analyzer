/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.objectmother.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.example.project.Class3;
import com.example.project.Class2;
import com.example.project.Class1;
import org.junit.jupiter.api.Test;

/** Test Generation of Class4 Types using the object-mother */
class Class5 {

  @Test
  void unsuccessfulKingFlirt() {
    var soberUnhappyKing = Class1.createSoberUnhappyKing();
    var flirtyQueen = Class1.createFlirtyQueen();
    soberUnhappyKing.flirt(flirtyQueen);
    assertFalse(soberUnhappyKing.isHappy());
  }

  @Test
  void queenIsBlockingFlirtCauseDrunkKing() {
    var drunkUnhappyKing = Class1.createDrunkKing();
    var notFlirtyQueen = Class1.createNotFlirtyQueen();
    drunkUnhappyKing.flirt(notFlirtyQueen);
    assertFalse(drunkUnhappyKing.isHappy());
  }

  @Test
  void queenIsBlockingFlirt() {
    var soberHappyKing = Class1.createHappyKing();
    var notFlirtyQueen = Class1.createNotFlirtyQueen();
    soberHappyKing.flirt(notFlirtyQueen);
    assertFalse(soberHappyKing.isHappy());
  }

  @Test
  void successfullKingFlirt() {
    var soberHappyKing = Class1.createHappyKing();
    var flirtyQueen = Class1.createFlirtyQueen();
    soberHappyKing.flirt(flirtyQueen);
    assertTrue(soberHappyKing.isHappy());
  }

  @Test
  void testQueenType() {
    var flirtyQueen = Class1.createFlirtyQueen();
    var notFlirtyQueen = Class1.createNotFlirtyQueen();
    assertEquals(flirtyQueen.getClass(), Class2.class);
    assertEquals(notFlirtyQueen.getClass(), Class2.class);
  }

  @Test
  void testKingType() {
    var drunkKing = Class1.createDrunkKing();
    var happyDrunkKing = Class1.createHappyDrunkKing();
    var happyKing = Class1.createHappyKing();
    var soberUnhappyKing = Class1.createSoberUnhappyKing();
    assertEquals(drunkKing.getClass(), Class3.class);
    assertEquals(happyDrunkKing.getClass(), Class3.class);
    assertEquals(happyKing.getClass(), Class3.class);
    assertEquals(soberUnhappyKing.getClass(), Class3.class);
  }
}
