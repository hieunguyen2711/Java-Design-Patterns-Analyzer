/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/** Unit tests for Class6 class. */
class Class12 {

  private Class4 data;

  private Class6 shard;

  @BeforeEach
  void setup() {
    data = new Class4(1, "test", Class4.DataType.TYPE_1);
    shard = new Class6(1);
  }

  @Test
  void testStoreData() {
    try {
      shard.storeData(data);
      var field = Class6.class.getDeclaredField("dataStore");
      field.setAccessible(true);
      var dataMap = (Map<Integer, Class4>) field.get(shard);
      assertEquals(1, dataMap.size());
      assertEquals(data, dataMap.get(1));
    } catch (NoSuchFieldException | IllegalAccessException e) {
      fail("Fail to modify field access.");
    }
  }

  @Test
  void testClearData() {
    try {
      var dataMap = new HashMap<Integer, Class4>();
      dataMap.put(1, data);
      var field = Class6.class.getDeclaredField("dataStore");
      field.setAccessible(true);
      field.set(shard, dataMap);
      shard.clearData();
      dataMap = (HashMap<Integer, Class4>) field.get(shard);
      assertEquals(0, dataMap.size());
    } catch (NoSuchFieldException | IllegalAccessException e) {
      fail("Fail to modify field access.");
    }
  }
}
