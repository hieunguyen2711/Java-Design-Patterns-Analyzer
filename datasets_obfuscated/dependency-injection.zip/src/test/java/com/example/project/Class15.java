/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.google.inject.AbstractModule;
import com.google.inject.Guice;
import com.example.project.utils.Class17;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/** Class15 */
class Class15 {

  private Class17 appender;

  @BeforeEach
  void setUp() {
    appender = new Class17(Class2.class);
  }

  @AfterEach
  void tearDown() {
    appender.stop();
  }

  /**
   * Test if the {@link Class4} smokes whatever instance of {@link Class2} is passed to him
   * through the constructor parameter
   */
  @Test
  void testSmokeEveryThingThroughConstructor() {

    List<Class2> tobaccos =
        List.of(new Class10(), new Class3(), new Class1());

    // Verify if the wizard is smoking the correct tobacco ...
    tobaccos.forEach(
        tobacco -> {
          final Class4 guiceWizard = new Class4(tobacco);
          guiceWizard.smoke();
          String lastMessage = appender.getLastMessage();
          assertEquals("Class4 smoking " + tobacco.getClass().getSimpleName(), lastMessage);
        });

    // ... and nothing else is happening.
    assertEquals(tobaccos.size(), appender.getLogSize());
  }

  /**
   * Test if the {@link Class4} smokes whatever instance of {@link Class2} is passed to him
   * through the Guice google inject framework
   */
  @Test
  void testSmokeEveryThingThroughInjectionFramework() {

    List<Class<? extends Class2>> tobaccos =
        List.of(Class10.class, Class3.class, Class1.class);

    // Configure the tobacco in the injection framework ...
    // ... and create a new wizard with it
    // Verify if the wizard is smoking the correct tobacco ...
    tobaccos.forEach(
        tobaccoClass -> {
          final var injector =
              Guice.createInjector(
                  new AbstractModule() {
                    @Override
                    protected void configure() {
                      bind(Class2.class).to(tobaccoClass);
                    }
                  });
          final var guiceWizard = injector.getInstance(Class4.class);
          guiceWizard.smoke();
          String lastMessage = appender.getLastMessage();
          assertEquals("Class4 smoking " + tobaccoClass.getSimpleName(), lastMessage);
        });

    // ... and nothing else is happening.
    assertEquals(tobaccos.size(), appender.getLogSize());
  }
}
