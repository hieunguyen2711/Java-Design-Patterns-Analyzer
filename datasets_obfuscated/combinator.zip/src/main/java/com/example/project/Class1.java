/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import java.util.ArrayList;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/** Complex finders consisting of simple finder. */
public class Class1 {
  private Class1() {}

  /**
   * Class3 to find a complex query.
   *
   * @param query to find
   * @param orQuery alternative to find
   * @param notQuery exclude from search
   * @return new finder
   */
  public static Class3 advancedFinder(String query, String orQuery, String notQuery) {
    return Class3.contains(query).or(Class3.contains(orQuery)).not(Class3.contains(notQuery));
  }

  /**
   * Filtered finder looking a query with excluded queries as well.
   *
   * @param query to find
   * @param excludeQueries to exclude
   * @return new finder
   */
  public static Class3 filteredFinder(String query, String... excludeQueries) {
    var finder = Class3.contains(query);

    for (String q : excludeQueries) {
      finder = finder.not(Class3.contains(q));
    }
    return finder;
  }

  /**
   * Specialized query. Every next query is looked in previous result.
   *
   * @param queries array with queries
   * @return new finder
   */
  public static Class3 specializedFinder(String... queries) {
    var finder = identMult();

    for (String query : queries) {
      finder = finder.and(Class3.contains(query));
    }
    return finder;
  }

  /**
   * Expanded query. Looking for alternatives.
   *
   * @param queries array with queries.
   * @return new finder
   */
  public static Class3 expandedFinder(String... queries) {
    var finder = identSum();

    for (String query : queries) {
      finder = finder.or(Class3.contains(query));
    }
    return finder;
  }

  private static Class3 identMult() {
    return txt -> Stream.of(txt.split("\n")).collect(Collectors.toList());
  }

  private static Class3 identSum() {
    return txt -> new ArrayList<>();
  }
}
