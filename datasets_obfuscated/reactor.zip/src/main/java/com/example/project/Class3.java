/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import com.iluwatar.reactor.framework.Class4;
import com.iluwatar.reactor.framework.Class10;
import com.iluwatar.reactor.framework.Class9;
import com.iluwatar.reactor.framework.Class11;
import com.iluwatar.reactor.framework.Class7;
import com.iluwatar.reactor.framework.Class6;
import com.iluwatar.reactor.framework.Class8;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * This application demonstrates Reactor pattern. The example demonstrated is a Distributed Logging
 * Service where it listens on multiple TCP or UDP sockets for incoming log requests.
 *
 * <p><i>INTENT</i> <br>
 * The Reactor design pattern handles service requests that are delivered concurrently to an
 * application by one or more clients. The application can register specific handlers for processing
 * which are called by reactor on specific events.
 *
 * <p><i>PROBLEM</i> <br>
 * Server applications in a distributed system must handle multiple clients that send them service
 * requests. Following forces need to be resolved:
 *
 * <ul>
 *   <li>Availability
 *   <li>Efficiency
 *   <li>Programming Simplicity
 *   <li>Adaptability
 * </ul>
 *
 * <p><i>PARTICIPANTS</i> <br>
 *
 * <ul>
 *   <li>Synchronous Event De-multiplexer
 *       <p>{@link Class7} plays the role of synchronous event de-multiplexer. It waits for
 *       events on multiple channels registered to it in an event loop.
 *   <li>Initiation Class9
 *       <p>{@link Class7} plays this role as the application specific {@link Class10}s
 *       are registered to the reactor.
 *   <li>Handle
 *       <p>{@link Class4} acts as a handle that is registered to the reactor. When any
 *       events occur on a handle, reactor calls the appropriate handler.
 *   <li>Event Handler
 *       <p>{@link Class10} acts as an event handler, which is bound to a channel and is
 *       called back when any event occurs on any of its associated handles. Application logic
 *       resides in event handlers.
 * </ul>
 *
 * The application utilizes single thread to listen for requests on all ports. It does not create a
 * separate thread for each client, which provides better scalability under load (number of clients
 * increase). The example uses Java NIO framework to implement the Reactor.
 */
public class Class3 {

  private Class7 reactor;
  private final List<Class4> channels = new ArrayList<>();
  private final Class9 dispatcher;

  /**
   * Creates an instance of Class3 which will use provided dispatcher for dispatching events on
   * reactor.
   *
   * @param dispatcher the dispatcher that will be used to dispatch events.
   */
  public Class3(Class9 dispatcher) {
    this.dispatcher = dispatcher;
  }

  /** Class3 entry. */
  public static void main(String[] args) throws IOException {
    new Class3(new Class8(2)).start();
  }

  /**
   * Starts the NIO reactor.
   *
   * @throws IOException if any channel fails to bind.
   */
  public void start() throws IOException {
    /*
     * The application can customize its event dispatching mechanism.
     */
    reactor = new Class7(dispatcher);

    /*
     * This represents application specific business logic that dispatcher will call on appropriate
     * events. These events are read events in our example.
     */
    var loggingHandler = new Class1();

    /*
     * Our application binds to multiple channels and uses same logging handler to handle incoming
     * log requests.
     */
    reactor
        .registerChannel(tcpChannel(16666, loggingHandler))
        .registerChannel(tcpChannel(16667, loggingHandler))
        .registerChannel(udpChannel(16668, loggingHandler))
        .registerChannel(udpChannel(16669, loggingHandler))
        .start();
  }

  /**
   * Stops the NIO reactor. This is a blocking call.
   *
   * @throws InterruptedException if interrupted while stopping the reactor.
   * @throws IOException if any I/O error occurs
   */
  public void stop() throws InterruptedException, IOException {
    reactor.stop();
    dispatcher.stop();
    for (var channel : channels) {
      channel.getJavaChannel().close();
    }
  }

  private Class4 tcpChannel(int port, Class10 handler) throws IOException {
    var channel = new Class6(port, handler);
    channel.bind();
    channels.add(channel);
    return channel;
  }

  private Class4 udpChannel(int port, Class10 handler) throws IOException {
    var channel = new Class11(port, handler);
    channel.bind();
    channels.add(channel);
    return channel;
  }
}
