/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;

import java.util.Arrays;
import org.junit.jupiter.api.Test;

/** Class13 */
class Class13 extends Class19<Class2> {

  /** Create a new test instance, using the correct object factory */
  public Class13() {
    super(null, null, Class2::new, Class2::new);
  }

  /**
   * The {@link Class2} is both an {@link Class5} as an {@link Class9} so verify if
   * every event received is passed up to its superior, in most cases {@link Class10} but now
   * just a mocked observer.
   */
  @Test
  void testPassThrough() {
    final var observer = mock(Class9.class);
    final var kingsHand = new Class2();
    kingsHand.registerObserver(observer, Class4.STARK_SIGHTED);
    kingsHand.registerObserver(observer, Class4.WARSHIPS_APPROACHING);
    kingsHand.registerObserver(observer, Class4.TRAITOR_DETECTED);
    kingsHand.registerObserver(observer, Class4.WHITE_WALKERS_SIGHTED);

    // The kings hand should not pass any events before he received one
    verifyNoMoreInteractions(observer);

    // Verify if each event is passed on to the observer, nothing less, nothing more.
    Arrays.stream(Class4.values())
        .forEach(
            event -> {
              kingsHand.onEvent(event);
              verify(observer, times(1)).onEvent(eq(event));
              verifyNoMoreInteractions(observer);
            });
  }
}
