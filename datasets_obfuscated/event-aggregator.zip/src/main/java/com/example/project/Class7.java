/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

/**
 * A system with lots of objects can lead to complexities when a client wants to subscribe to
 * events. The client has to find and register for each object individually, if each object has
 * multiple events then each event requires a separate subscription.
 *
 * <p>An Class4 Aggregator acts as a single source of events for many objects. It registers for all
 * the events of the many objects allowing clients to register with just the aggregator.
 *
 * <p>In the example {@link Class1}, {@link Class8} and {@link Class3} deliver events to
 * {@link Class2}. {@link Class2}, the event aggregator, then delivers the events to {@link
 * Class10}.
 */
public class Class7 {

  /**
   * Program entry point.
   *
   * @param args command line args
   */
  public static void main(String[] args) {

    var kingJoffrey = new Class10();

    var kingsHand = new Class2();
    kingsHand.registerObserver(kingJoffrey, Class4.TRAITOR_DETECTED);
    kingsHand.registerObserver(kingJoffrey, Class4.STARK_SIGHTED);
    kingsHand.registerObserver(kingJoffrey, Class4.WARSHIPS_APPROACHING);
    kingsHand.registerObserver(kingJoffrey, Class4.WHITE_WALKERS_SIGHTED);

    var varys = new Class8();
    varys.registerObserver(kingsHand, Class4.TRAITOR_DETECTED);
    varys.registerObserver(kingsHand, Class4.WHITE_WALKERS_SIGHTED);

    var scout = new Class3();
    scout.registerObserver(kingsHand, Class4.WARSHIPS_APPROACHING);
    scout.registerObserver(varys, Class4.WHITE_WALKERS_SIGHTED);

    var baelish = new Class1(kingsHand, Class4.STARK_SIGHTED);

    var emitters = List.of(kingsHand, baelish, varys, scout);

    Arrays.stream(Class6.values())
        .<Consumer<? super Class5>>map(day -> emitter -> emitter.timePasses(day))
        .forEachOrdered(emitters::forEach);
  }
}
