/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import java.util.HashMap;
import java.util.Map;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/** DB class for seeding user info. */
public class Class11 {

  private static Class11 instance;
  private Map<String, User> userName2User;
  private Map<User, Account> user2Account;
  private Map<String, Product> itemName2Product;

  /**
   * Get the instance of Class11.
   *
   * @return singleton instance of Class11 class
   */
  public static synchronized Class11 getInstance() {
    if (instance == null) {
      Class11 newInstance = new Class11();
      newInstance.userName2User = new HashMap<>();
      newInstance.user2Account = new HashMap<>();
      newInstance.itemName2Product = new HashMap<>();
      instance = newInstance;
    }
    return instance;
  }

  /**
   * Seed a user into Class11.
   *
   * @param userName of the user
   * @param amount of the user's account
   */
  public void seedUser(String userName, Double amount) {
    User user = new User(userName);
    instance.userName2User.put(userName, user);
    Account account = new Account(amount);
    instance.user2Account.put(user, account);
  }

  /**
   * Seed an item into Class11.
   *
   * @param itemName of the item
   * @param price of the item
   */
  public void seedItem(String itemName, Double price) {
    Product item = new Product(price);
    itemName2Product.put(itemName, item);
  }

  /**
   * Find a user with the userName.
   *
   * @param userName of the user
   * @return instance of User
   */
  public User findUserByUserName(String userName) {
    if (!userName2User.containsKey(userName)) {
      return null;
    }
    return userName2User.get(userName);
  }

  /**
   * Find an account of the user.
   *
   * @param user in Class11
   * @return instance of Account of the user
   */
  public Account findAccountByUser(User user) {
    if (!user2Account.containsKey(user)) {
      return null;
    }
    return user2Account.get(user);
  }

  /**
   * Find a product with the itemName.
   *
   * @param itemName of the item
   * @return instance of Product
   */
  public Product findProductByItemName(String itemName) {
    if (!itemName2Product.containsKey(itemName)) {
      return null;
    }
    return itemName2Product.get(itemName);
  }

  /** User class to store user info. */
  @RequiredArgsConstructor
  @Getter
  public class User {

    private final String userName;

    public Class4 purchase(Product item) {
      return new Class4(item.getPrice());
    }
  }

  /** Account info. */
  @RequiredArgsConstructor
  @Getter
  public static class Account {

    private final Double amount;

    /**
     * Withdraw the price of the item from the account.
     *
     * @param price of the item
     * @return instance of Class1
     */
    public Class1 withdraw(Double price) {
      if (price > amount) {
        return null;
      }
      return new Class1(amount, price);
    }
  }

  /** Product info. */
  @RequiredArgsConstructor
  @Getter
  public static class Product {

    private final Double price;
  }
}
