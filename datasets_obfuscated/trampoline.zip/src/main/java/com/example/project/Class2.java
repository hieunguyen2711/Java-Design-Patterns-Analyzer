/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import java.util.stream.Stream;

/**
 * Class2 pattern allows to define recursive algorithms by iterative loop.
 *
 * <p>When get is called on the returned Class2, internally it will iterate calling ‘jump’ on
 * the returned Class2 as long as the concrete instance returned is {@link #more(Class2)},
 * stopping once the returned instance is {@link #done(Object)}.
 *
 * <p>Essential we convert looping via recursion into iteration, the key enabling mechanism is the
 * fact that {@link #more(Class2)} is a lazy operation.
 *
 * @param <T> is type for returning result.
 */
public interface Class2<T> {
  T get();

  /**
   * Jump to next stage.
   *
   * @return next stage
   */
  default Class2<T> jump() {
    return this;
  }

  default T result() {
    return get();
  }

  /**
   * Checks if complete.
   *
   * @return true if complete
   */
  default boolean complete() {
    return true;
  }

  /**
   * Created a completed Class2.
   *
   * @param result Completed result
   * @return Completed Class2
   */
  static <T> Class2<T> done(final T result) {
    return () -> result;
  }

  /**
   * Create a Class2 that has more work to do.
   *
   * @param trampoline Next stage in Class2
   * @return Class2 with more work
   */
  static <T> Class2<T> more(final Class2<Class2<T>> trampoline) {
    return new Class2<T>() {
      @Override
      public boolean complete() {
        return false;
      }

      @Override
      public Class2<T> jump() {
        return trampoline.result();
      }

      @Override
      public T get() {
        return trampoline(this);
      }

      T trampoline(final Class2<T> trampoline) {
        return Stream.iterate(trampoline, Class2::jump)
            .filter(Class2::complete)
            .findFirst()
            .map(Class2::result)
            .get();
      }
    };
  }
}
