/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class Class11 {

  @Test
  void addRole() {
    var core = new Class1();
    assertTrue(core.addRole(Class7.BORROWER));
  }

  @Test
  void hasRole() {
    var core = new Class1();
    core.addRole(Class7.BORROWER);
    assertTrue(core.hasRole(Class7.BORROWER));
    assertFalse(core.hasRole(Class7.INVESTOR));
  }

  @Test
  void remRole() {
    var core = new Class1();
    core.addRole(Class7.BORROWER);

    var bRole = core.getRole(Class7.BORROWER, Class3.class);
    assertTrue(bRole.isPresent());

    assertTrue(core.remRole(Class7.BORROWER));

    var empt = core.getRole(Class7.BORROWER, Class3.class);
    assertFalse(empt.isPresent());
  }

  @Test
  void getRole() {
    var core = new Class1();
    core.addRole(Class7.BORROWER);

    var bRole = core.getRole(Class7.BORROWER, Class3.class);
    assertTrue(bRole.isPresent());

    var nonRole = core.getRole(Class7.BORROWER, Class5.class);
    assertFalse(nonRole.isPresent());

    var invRole = core.getRole(Class7.INVESTOR, Class5.class);
    assertFalse(invRole.isPresent());
  }

  @Test
  void toStringTest() {
    var core = new Class1();
    core.addRole(Class7.BORROWER);
    assertEquals("Class2{roles=[BORROWER]}", core.toString());

    core = new Class1();
    core.addRole(Class7.INVESTOR);
    assertEquals("Class2{roles=[INVESTOR]}", core.toString());

    core = new Class1();
    assertEquals("Class2{roles=[]}", core.toString());
  }
}
