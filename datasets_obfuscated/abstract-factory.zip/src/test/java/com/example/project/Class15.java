/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/** Tests for abstract factory. */
class Class15 {

  private final Class13 app = new Class13();

  @Test
  void verifyKingCreation() {
    app.createKingdom(Class6.FactoryMaker.KingdomType.ELF);
    final var kingdom = app.getKingdom();

    final var elfKing = kingdom.getKing();
    assertTrue(elfKing instanceof Class2);
    assertEquals(Class2.DESCRIPTION, elfKing.getDescription());

    app.createKingdom(Class6.FactoryMaker.KingdomType.ORC);
    final var orcKing = kingdom.getKing();
    assertTrue(orcKing instanceof Class14);
    assertEquals(Class14.DESCRIPTION, orcKing.getDescription());
  }

  @Test
  void verifyCastleCreation() {
    app.createKingdom(Class6.FactoryMaker.KingdomType.ELF);
    final var kingdom = app.getKingdom();

    final var elfCastle = kingdom.getCastle();
    assertTrue(elfCastle instanceof Class3);
    assertEquals(Class3.DESCRIPTION, elfCastle.getDescription());

    app.createKingdom(Class6.FactoryMaker.KingdomType.ORC);
    final var orcCastle = kingdom.getCastle();
    assertTrue(orcCastle instanceof Class9);
    assertEquals(Class9.DESCRIPTION, orcCastle.getDescription());
  }

  @Test
  void verifyArmyCreation() {
    app.createKingdom(Class6.FactoryMaker.KingdomType.ELF);
    final var kingdom = app.getKingdom();

    final var elfArmy = kingdom.getArmy();
    assertTrue(elfArmy instanceof Class7);
    assertEquals(Class7.DESCRIPTION, elfArmy.getDescription());

    app.createKingdom(Class6.FactoryMaker.KingdomType.ORC);
    final var orcArmy = kingdom.getArmy();
    assertTrue(orcArmy instanceof Class1);
    assertEquals(Class1.DESCRIPTION, orcArmy.getDescription());
  }

  @Test
  void verifyElfKingdomCreation() {
    app.createKingdom(Class6.FactoryMaker.KingdomType.ELF);
    final var kingdom = app.getKingdom();

    final var king = kingdom.getKing();
    final var castle = kingdom.getCastle();
    final var army = kingdom.getArmy();
    assertTrue(king instanceof Class2);
    assertEquals(Class2.DESCRIPTION, king.getDescription());
    assertTrue(castle instanceof Class3);
    assertEquals(Class3.DESCRIPTION, castle.getDescription());
    assertTrue(army instanceof Class7);
    assertEquals(Class7.DESCRIPTION, army.getDescription());
  }

  @Test
  void verifyOrcKingdomCreation() {
    app.createKingdom(Class6.FactoryMaker.KingdomType.ORC);
    final var kingdom = app.getKingdom();

    final var king = kingdom.getKing();
    final var castle = kingdom.getCastle();
    final var army = kingdom.getArmy();
    assertTrue(king instanceof Class14);
    assertEquals(Class14.DESCRIPTION, king.getDescription());
    assertTrue(castle instanceof Class9);
    assertEquals(Class9.DESCRIPTION, castle.getDescription());
    assertTrue(army instanceof Class1);
    assertEquals(Class1.DESCRIPTION, army.getDescription());
  }
}
