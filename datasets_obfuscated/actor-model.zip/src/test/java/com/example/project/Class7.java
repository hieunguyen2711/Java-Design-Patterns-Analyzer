/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.actor;

import static org.junit.jupiter.api.Assertions.*;

import com.example.project.Class4;
import com.example.project.Class6;
import com.example.project.Class3;
import com.example.project.Class2;
import com.example.project.Class1;
import org.junit.jupiter.api.Test;

public class Class7 {
  @Test
  void testMainMethod() throws InterruptedException {
    Class6.main(new String[] {});
  }

  @Test
  public void testMessagePassing() throws InterruptedException {
    Class4 system = new Class4();

    Class3 srijan = new Class3(system);
    Class2 ansh = new Class2(system);

    system.startActor(srijan);
    system.startActor(ansh);

    // Ansh recieves a message from Srijan
    ansh.send(new Class1("Hello ansh", srijan.getActorId()));

    // Wait briefly to allow async processing
    Thread.sleep(200);

    // Check that Srijan received the message
    assertTrue(
        ansh.getReceivedMessages().contains("Hello ansh"),
        "ansh should receive the message from Srijan");
  }
}
