/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.example.project.domain.Class6;
import com.example.project.domain.Class5;
import com.example.project.domain.enums.Class10;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;

/** Test for Class5 and Class6 */
class Class11 {

  private static final String TEST_PART_TYPE = "test-part-type";
  private static final String TEST_PART_MODEL = "test-part-model";
  private static final long TEST_PART_PRICE = 0L;

  private static final String TEST_CAR_MODEL = "test-car-model";
  private static final long TEST_CAR_PRICE = 1L;

  @Test
  void shouldConstructPart() {
    var partProperties =
        Map.of(
            Class10.TYPE.toString(), TEST_PART_TYPE,
            Class10.MODEL.toString(), TEST_PART_MODEL,
            Class10.PRICE.toString(), (Object) TEST_PART_PRICE);
    var part = new Class5(partProperties);
    assertEquals(TEST_PART_TYPE, part.getType().orElseThrow());
    assertEquals(TEST_PART_MODEL, part.getModel().orElseThrow());
    assertEquals(TEST_PART_PRICE, part.getPrice().orElseThrow());
  }

  @Test
  void shouldConstructCar() {
    var carProperties =
        Map.of(
            Class10.MODEL.toString(), TEST_CAR_MODEL,
            Class10.PRICE.toString(), TEST_CAR_PRICE,
            Class10.PARTS.toString(), List.of(Map.of(), Map.of()));
    var car = new Class6(carProperties);
    assertEquals(TEST_CAR_MODEL, car.getModel().orElseThrow());
    assertEquals(TEST_CAR_PRICE, car.getPrice().orElseThrow());
    assertEquals(2, car.getParts().count());
  }
}
