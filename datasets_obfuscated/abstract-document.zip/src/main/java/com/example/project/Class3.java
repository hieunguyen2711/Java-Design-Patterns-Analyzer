/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import com.example.project.domain.Class6;
import com.example.project.domain.enums.Class10;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;

/**
 * The Abstract Class2 pattern enables handling additional, non-static properties. This pattern
 * uses concept of traits to enable type safety and separate properties of different classes into
 * set of interfaces.
 *
 * <p>In Abstract Class2 pattern,({@link Class1}) fully implements {@link Class2})
 * interface. Traits are then defined to enable access to properties in usual, static way.
 */
@Slf4j
public class Class3 {

  /**
   * Program entry point.
   *
   * @param args command line args
   */
  public static void main(String[] args) {
    LOGGER.info("Constructing parts and car");

    var wheelProperties =
        Map.of(
            Class10.TYPE.toString(), "wheel",
            Class10.MODEL.toString(), "15C",
            Class10.PRICE.toString(), 100L);

    var doorProperties =
        Map.of(
            Class10.TYPE.toString(), "door",
            Class10.MODEL.toString(), "Lambo",
            Class10.PRICE.toString(), 300L);

    var carProperties =
        Map.of(
            Class10.MODEL.toString(),
            "300SL",
            Class10.PRICE.toString(),
            10000L,
            Class10.PARTS.toString(),
            List.of(wheelProperties, doorProperties));

    var car = new Class6(carProperties);

    LOGGER.info("Here is our car:");
    LOGGER.info("-> model: {}", car.getModel().orElseThrow());
    LOGGER.info("-> price: {}", car.getPrice().orElseThrow());
    LOGGER.info("-> parts: ");
    car.getParts()
        .forEach(
            p ->
                LOGGER.info(
                    "\t{}/{}/{}",
                    p.getType().orElse(null),
                    p.getModel().orElse(null),
                    p.getPrice().orElse(null)));
  }
}
