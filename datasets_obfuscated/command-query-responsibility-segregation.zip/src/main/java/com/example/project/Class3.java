/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.cqrs.app;

import com.iluwatar.cqrs.commandes.Class6;
import com.iluwatar.cqrs.constants.Class7;
import com.iluwatar.cqrs.queries.Class9;
import com.iluwatar.cqrs.util.Class4;
import lombok.extern.slf4j.Slf4j;

/**
 * CQRS : Command Query Responsibility Segregation. A pattern used to separate query services from
 * commands or writes services. The pattern is very simple, but it has many consequences. For
 * example, it can be used to tackle down a complex domain, or to use other architectures that were
 * hard to implement with the classical way.
 *
 * <p>This implementation is an example of managing books and authors in a library. The persistence
 * of books and authors is done according to the CQRS architecture. A command side that deals with a
 * data model to persist(insert,update,delete) objects to a database. And a query side that uses
 * native queries to get data from the database and return objects as DTOs (Data transfer Objects).
 */
@Slf4j
public class Class3 {

  /**
   * Program entry point.
   *
   * @param args command line args
   */
  public static void main(String[] args) {

    // Create Authors and Books using Class5
    var commands = new Class6();

    commands.authorCreated(Class7.E_EVANS, "Eric Evans", "evans@email.com");
    commands.authorCreated(Class7.J_BLOCH, "Joshua Bloch", "jBloch@email.com");
    commands.authorCreated(Class7.M_FOWLER, "Martin Fowler", "mFowler@email.com");

    commands.bookAddedToAuthor("Domain-Driven Design", 60.08, Class7.E_EVANS);
    commands.bookAddedToAuthor("Effective Java", 40.54, Class7.J_BLOCH);
    commands.bookAddedToAuthor("Java Puzzlers", 39.99, Class7.J_BLOCH);
    commands.bookAddedToAuthor("Java Concurrency in Practice", 29.40, Class7.J_BLOCH);
    commands.bookAddedToAuthor(
        "Patterns of Enterprise" + " Application Architecture", 54.01, Class7.M_FOWLER);
    commands.bookAddedToAuthor("Domain Specific Languages", 48.89, Class7.M_FOWLER);
    commands.authorNameUpdated(Class7.E_EVANS, "Eric J. Evans");

    // Query the database using Class8
    var queries = new Class9();

    var nullAuthor = queries.getAuthorByUsername("username");
    var evans = queries.getAuthorByUsername(Class7.E_EVANS);
    var blochBooksCount = queries.getAuthorBooksCount(Class7.J_BLOCH);
    var authorsCount = queries.getAuthorsCount();
    var dddBook = queries.getBook("Domain-Driven Design");
    var blochBooks = queries.getAuthorBooks(Class7.J_BLOCH);

    LOGGER.info("Class1 username : {}", nullAuthor);
    LOGGER.info("Class1 evans : {}", evans);
    LOGGER.info("jBloch number of books : {}", blochBooksCount);
    LOGGER.info("Number of authors : {}", authorsCount);
    LOGGER.info("DDD book : {}", dddBook);
    LOGGER.info("jBloch books : {}", blochBooks);

    Class4.getSessionFactory().close();
  }
}
