/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import lombok.Getter;

/**
 * Class3 is a Multiton class. Class3 instances can be queried using {@link #getInstance} method.
 */
public final class Class3 {

  private static final Map<Class1, Class3> nazguls;

  @Getter private final Class1 name;

  static {
    nazguls = new ConcurrentHashMap<>();
    nazguls.put(Class1.KHAMUL, new Class3(Class1.KHAMUL));
    nazguls.put(Class1.MURAZOR, new Class3(Class1.MURAZOR));
    nazguls.put(Class1.DWAR, new Class3(Class1.DWAR));
    nazguls.put(Class1.JI_INDUR, new Class3(Class1.JI_INDUR));
    nazguls.put(Class1.AKHORAHIL, new Class3(Class1.AKHORAHIL));
    nazguls.put(Class1.HOARMURATH, new Class3(Class1.HOARMURATH));
    nazguls.put(Class1.ADUNAPHEL, new Class3(Class1.ADUNAPHEL));
    nazguls.put(Class1.REN, new Class3(Class1.REN));
    nazguls.put(Class1.UVATHA, new Class3(Class1.UVATHA));
  }

  private Class3(Class1 name) {
    this.name = name;
  }

  public static Class3 getInstance(Class1 name) {
    return nazguls.get(name);
  }
}
