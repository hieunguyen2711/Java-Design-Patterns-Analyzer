/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import lombok.extern.slf4j.Slf4j;

/**
 * Whereas Singleton design pattern introduces single globally accessible object, the Multiton
 * pattern defines many globally accessible objects. The client asks for the correct instance from
 * the Multiton by passing an enumeration as a parameter.
 *
 * <p>There is more than one way to implement the multiton design pattern. In the first example
 * {@link Class3} is the Multiton, and we can ask single {@link Class3} from it using {@link
 * Class1}. The {@link Class3}s are statically initialized and stored in a concurrent hash map.
 *
 * <p>In the enum implementation {@link Class2} is the multiton. It is static and mutable
 * because of the way java supports enums.
 */
@Slf4j
public class Class4 {

  /**
   * Program entry point.
   *
   * @param args command line args
   */
  public static void main(String[] args) {
    // eagerly initialized multiton
    LOGGER.info("Printing out eagerly initialized multiton contents");
    LOGGER.info("KHAMUL={}", Class3.getInstance(Class1.KHAMUL));
    LOGGER.info("MURAZOR={}", Class3.getInstance(Class1.MURAZOR));
    LOGGER.info("DWAR={}", Class3.getInstance(Class1.DWAR));
    LOGGER.info("JI_INDUR={}", Class3.getInstance(Class1.JI_INDUR));
    LOGGER.info("AKHORAHIL={}", Class3.getInstance(Class1.AKHORAHIL));
    LOGGER.info("HOARMURATH={}", Class3.getInstance(Class1.HOARMURATH));
    LOGGER.info("ADUNAPHEL={}", Class3.getInstance(Class1.ADUNAPHEL));
    LOGGER.info("REN={}", Class3.getInstance(Class1.REN));
    LOGGER.info("UVATHA={}", Class3.getInstance(Class1.UVATHA));

    // enum multiton
    LOGGER.info("Printing out enum-based multiton contents");
    LOGGER.info("KHAMUL={}", Class2.KHAMUL);
    LOGGER.info("MURAZOR={}", Class2.MURAZOR);
    LOGGER.info("DWAR={}", Class2.DWAR);
    LOGGER.info("JI_INDUR={}", Class2.JI_INDUR);
    LOGGER.info("AKHORAHIL={}", Class2.AKHORAHIL);
    LOGGER.info("HOARMURATH={}", Class2.HOARMURATH);
    LOGGER.info("ADUNAPHEL={}", Class2.ADUNAPHEL);
    LOGGER.info("REN={}", Class2.REN);
    LOGGER.info("UVATHA={}", Class2.UVATHA);
  }
}
