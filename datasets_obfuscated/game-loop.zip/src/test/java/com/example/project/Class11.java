/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import static org.junit.jupiter.api.Assertions.assertFalse;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/** Class2 unit test class. */
class Class11 {

  private Class2 gameLoop;

  /** Create mock implementation of Class2. */
  @BeforeEach
  void setup() {
    gameLoop =
        new Class2() {
          @Override
          protected void processGameLoop() {
            throw new UnsupportedOperationException("Not supported yet.");
          }
        };
  }

  @AfterEach
  void tearDown() {
    gameLoop = null;
  }

  @Test
  void testRun() {
    gameLoop.run();
    Assertions.assertEquals(Class6.RUNNING, gameLoop.status);
  }

  @Test
  void testStop() {
    gameLoop.stop();
    Assertions.assertEquals(Class6.STOPPED, gameLoop.status);
  }

  @Test
  void testIsGameRunning() {
    assertFalse(gameLoop.isGameRunning());
  }
}
