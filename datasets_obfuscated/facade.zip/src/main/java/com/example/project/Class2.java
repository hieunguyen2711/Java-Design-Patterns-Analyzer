/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import java.util.Collection;
import java.util.List;

/**
 * Class2 provides a single interface through which users can operate the subsystems.
 *
 * <p>This makes the goldmine easier to operate and cuts the dependencies from the goldmine user to
 * the subsystems.
 */
public class Class2 {

  private final List<Class6> workers;

  /** Constructor. */
  public Class2() {
    workers =
        List.of(new Class3(), new Class4(), new Class1());
  }

  public void startNewDay() {
    makeActions(workers, Class6.Action.WAKE_UP, Class6.Action.GO_TO_MINE);
  }

  public void digOutGold() {
    makeActions(workers, Class6.Action.WORK);
  }

  public void endDay() {
    makeActions(workers, Class6.Action.GO_HOME, Class6.Action.GO_TO_SLEEP);
  }

  private static void makeActions(
      Collection<Class6> workers, Class6.Action... actions) {
    workers.forEach(worker -> worker.action(actions));
  }
}
