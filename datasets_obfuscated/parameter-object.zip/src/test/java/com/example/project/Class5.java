/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class Class5 {

  private static final Logger LOGGER = LoggerFactory.getLogger(Class5.class);

  @Test
  void testForDefaultSortBy() {
    // Creating parameter object with default value for SortBy set
    Class3 params =
        Class3.newBuilder().withType("sneakers").sortOrder(Class1.DESC).build();

    assertEquals(Class3.DEFAULT_SORT_BY, params.getSortBy(), "Default SortBy is not set.");
    LOGGER.info(
        "{} Default parameter value is set during object creation as no value is passed.",
        "SortBy");
  }

  @Test
  void testForDefaultSortOrder() {
    // Creating parameter object with default value for Class1 set
    Class3 params =
        Class3.newBuilder().withType("sneakers").sortBy("brand").build();

    assertEquals(
        Class3.DEFAULT_SORT_ORDER, params.getSortOrder(), "Default Class1 is not set.");
    LOGGER.info(
        "{} Default parameter value is set during object creation as no value is passed.",
        "Class1");
  }
}
