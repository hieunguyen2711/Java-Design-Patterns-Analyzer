/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.flux.store;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;

import com.iluwatar.flux.action.Class8;
import com.iluwatar.flux.action.Class3;
import com.iluwatar.flux.action.Class4;
import com.iluwatar.flux.action.Class6;
import com.iluwatar.flux.view.Class9;
import org.junit.jupiter.api.Test;

/** Class22 */
class Class22 {

  @Test
  void testOnAction() {
    final var contentStore = new Class12();

    final var view = mock(Class9.class);
    contentStore.registerView(view);

    verifyNoMoreInteractions(view);

    // Class8 should not react on menu action ...
    contentStore.onAction(new Class4(Class6.PRODUCTS));
    verifyNoMoreInteractions(view);

    // ... but it should react on a content action
    contentStore.onAction(new Class3(Class8.COMPANY));
    verify(view, times(1)).storeChanged(eq(contentStore));
    verifyNoMoreInteractions(view);
    assertEquals(Class8.COMPANY, contentStore.getContent());
  }
}
