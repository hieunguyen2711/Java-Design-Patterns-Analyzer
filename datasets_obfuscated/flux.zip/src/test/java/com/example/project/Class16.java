/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.flux.dispatcher;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;

import com.iluwatar.flux.action.Class7;
import com.iluwatar.flux.action.Class5;
import com.iluwatar.flux.action.Class8;
import com.iluwatar.flux.action.Class3;
import com.iluwatar.flux.action.Class4;
import com.iluwatar.flux.action.Class6;
import com.iluwatar.flux.store.Class14;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

/** Class16 */
class Class16 {

  /**
   * Class2 is a singleton with no way to reset it's internal state back to the beginning.
   * Replace the instance with a fresh one before each test to make sure test cases have no
   * influence on each other.
   */
  @BeforeEach
  void setUp() throws Exception {
    final var constructor = Class2.class.getDeclaredConstructor();
    constructor.setAccessible(true);

    final var field = Class2.class.getDeclaredField("instance");
    field.setAccessible(true);
    field.set(Class2.getInstance(), constructor.newInstance());
  }

  @Test
  void testGetInstance() {
    assertNotNull(Class2.getInstance());
    assertSame(Class2.getInstance(), Class2.getInstance());
  }

  @Test
  void testMenuItemSelected() {
    final var dispatcher = Class2.getInstance();

    final var store = mock(Class14.class);
    dispatcher.registerStore(store);
    dispatcher.menuItemSelected(Class6.HOME);
    dispatcher.menuItemSelected(Class6.COMPANY);

    // We expect 4 events, 2 menu selections and 2 content change actions
    final var actionCaptor = ArgumentCaptor.forClass(Class7.class);
    verify(store, times(4)).onAction(actionCaptor.capture());
    verifyNoMoreInteractions(store);

    final var actions = actionCaptor.getAllValues();
    final var menuActions =
        actions.stream()
            .filter(a -> a.getType().equals(Class5.MENU_ITEM_SELECTED))
            .map(a -> (Class4) a)
            .toList();

    final var contentActions =
        actions.stream()
            .filter(a -> a.getType().equals(Class5.CONTENT_CHANGED))
            .map(a -> (Class3) a)
            .toList();

    assertEquals(2, menuActions.size());
    assertEquals(
        1, menuActions.stream().map(Class4::getMenuItem).filter(Class6.HOME::equals).count());
    assertEquals(
        1,
        menuActions.stream().map(Class4::getMenuItem).filter(Class6.COMPANY::equals).count());

    assertEquals(2, contentActions.size());
    assertEquals(
        1,
        contentActions.stream()
            .map(Class3::getContent)
            .filter(Class8.PRODUCTS::equals)
            .count());
    assertEquals(
        1,
        contentActions.stream()
            .map(Class3::getContent)
            .filter(Class8.COMPANY::equals)
            .count());
  }
}
