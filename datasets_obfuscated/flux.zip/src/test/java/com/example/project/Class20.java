/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.flux.view;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import com.iluwatar.flux.action.Class7;
import com.iluwatar.flux.action.Class6;
import com.iluwatar.flux.dispatcher.Class2;
import com.iluwatar.flux.store.Class13;
import com.iluwatar.flux.store.Class14;
import org.junit.jupiter.api.Test;

/** Class20 */
class Class20 {

  @Test
  void testStoreChanged() {
    final var store = mock(Class13.class);
    when(store.getSelected()).thenReturn(Class6.HOME);

    final var view = new Class11();
    view.storeChanged(store);

    verify(store, times(1)).getSelected();
    verifyNoMoreInteractions(store);
  }

  @Test
  void testItemClicked() {
    final var store = mock(Class14.class);
    Class2.getInstance().registerStore(store);

    final var view = new Class11();
    view.itemClicked(Class6.PRODUCTS);

    // We should receive a menu click action and a content changed action
    verify(store, times(2)).onAction(any(Class7.class));
  }
}
