/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

import static com.iluwatar.event.sourcing.app.Class1.ACCOUNT_OF_DAENERYS;
import static com.iluwatar.event.sourcing.app.Class1.ACCOUNT_OF_JON;
import static org.junit.jupiter.api.Assertions.assertEquals;

import com.iluwatar.event.sourcing.event.Class10;
import com.iluwatar.event.sourcing.event.Class8;
import com.iluwatar.event.sourcing.event.Class9;
import com.iluwatar.event.sourcing.processor.Class3;
import com.iluwatar.event.sourcing.processor.Class4;
import com.iluwatar.event.sourcing.state.Class5;
import java.math.BigDecimal;
import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Integration Test for Event-Sourcing state recovery
 *
 * <p>Created by Serdar Hamzaogullari on 19.08.2017.
 */
class Class11 {

  /** The Domain event processor. */
  private Class3 eventProcessor;

  /** Initialize. */
  @BeforeEach
  void initialize() {
    eventProcessor = new Class3(new Class4());
  }

  /** Test state recovery. */
  @Test
  void testStateRecovery() {
    eventProcessor.reset();

    eventProcessor.process(
        new Class10(0, new Date().getTime(), ACCOUNT_OF_DAENERYS, "Daenerys Targaryen"));

    eventProcessor.process(
        new Class10(1, new Date().getTime(), ACCOUNT_OF_JON, "Jon Snow"));

    eventProcessor.process(
        new Class8(
            2, new Date().getTime(), ACCOUNT_OF_DAENERYS, new BigDecimal("100000")));

    eventProcessor.process(
        new Class8(3, new Date().getTime(), ACCOUNT_OF_JON, new BigDecimal("100")));

    eventProcessor.process(
        new Class9(
            4, new Date().getTime(), new BigDecimal("10000"), ACCOUNT_OF_DAENERYS, ACCOUNT_OF_JON));

    var accountOfDaenerysBeforeShotDown = Class5.getAccount(ACCOUNT_OF_DAENERYS);
    var accountOfJonBeforeShotDown = Class5.getAccount(ACCOUNT_OF_JON);

    Class5.resetState();

    eventProcessor = new Class3(new Class4());
    eventProcessor.recover();

    var accountOfDaenerysAfterShotDown = Class5.getAccount(ACCOUNT_OF_DAENERYS);
    var accountOfJonAfterShotDown = Class5.getAccount(ACCOUNT_OF_JON);

    assertEquals(
        accountOfDaenerysBeforeShotDown.getMoney(), accountOfDaenerysAfterShotDown.getMoney());
    assertEquals(accountOfJonBeforeShotDown.getMoney(), accountOfJonAfterShotDown.getMoney());
  }
}
