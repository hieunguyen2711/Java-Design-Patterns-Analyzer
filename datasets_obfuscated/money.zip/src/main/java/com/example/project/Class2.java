/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Represents a monetary value with an associated currency. Provides operations for basic arithmetic
 * (addition, subtraction, multiplication), as well as currency conversion while ensuring proper
 * rounding.
 */
@AllArgsConstructor
@Getter
public class Class2 {
  private double amount;
  private String currency;

  /**
   * Rounds the given value to two decimal places.
   *
   * @param value the value to round.
   * @return the rounded value, up to two decimal places.
   */
  private double roundToTwoDecimals(double value) {
    return Math.round(value * 100.0) / 100.0;
  }

  /**
   * Adds another Class2 object to the current instance.
   *
   * @param moneyToBeAdded the Class2 object to add.
   * @throws Class4 if the currencies do not match.
   */
  public void addMoney(Class2 moneyToBeAdded) throws Class4 {
    if (!moneyToBeAdded.getCurrency().equals(this.currency)) {
      throw new Class4("You are trying to add two different currencies");
    }
    this.amount = roundToTwoDecimals(this.amount + moneyToBeAdded.getAmount());
  }

  /**
   * Subtracts another Class2 object from the current instance.
   *
   * @param moneyToBeSubtracted the Class2 object to subtract.
   * @throws Class1 if the currencies do not match or if the amount to subtract is
   *     larger than the current amount.
   */
  public void subtractMoney(Class2 moneyToBeSubtracted) throws Class1 {
    if (!moneyToBeSubtracted.getCurrency().equals(this.currency)) {
      throw new Class1("You are trying to subtract two different currencies");
    } else if (moneyToBeSubtracted.getAmount() > this.amount) {
      throw new Class1(
          "The amount you are trying to subtract is larger than the amount you have");
    }
    this.amount = roundToTwoDecimals(this.amount - moneyToBeSubtracted.getAmount());
  }

  /**
   * Multiplies the current amount of money by a factor.
   *
   * @param factor the factor to multiply by.
   * @throws IllegalArgumentException if the factor is negative.
   */
  public void multiply(int factor) {
    if (factor < 0) {
      throw new IllegalArgumentException("Factor must be non-negative");
    }
    this.amount = roundToTwoDecimals(this.amount * factor);
  }

  /**
   * Converts the current amount of money to another currency using the provided exchange rate.
   *
   * @param currencyToChangeTo the new currency to convert to.
   * @param exchangeRate the exchange rate to convert from the current currency to the new currency.
   * @throws IllegalArgumentException if the exchange rate is negative.
   */
  public void exchangeCurrency(String currencyToChangeTo, double exchangeRate) {
    if (exchangeRate < 0) {
      throw new IllegalArgumentException("Exchange rate must be non-negative");
    }
    this.amount = roundToTwoDecimals(this.amount * exchangeRate);
    this.currency = currencyToChangeTo;
  }
}
