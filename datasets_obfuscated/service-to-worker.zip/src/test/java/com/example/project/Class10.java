/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;

import com.iluwatar.model.view.controller.Fatigue;
import com.iluwatar.model.view.controller.Health;
import com.iluwatar.model.view.controller.Nourishment;
import org.junit.jupiter.api.Test;

/** The type Class5 test. */
class Class10 {

  /** Test perform action. */
  @Test
  void testPerformAction() {
    final var model =
        new Class3("giant1", Health.HEALTHY, Fatigue.ALERT, Nourishment.SATURATED);
    Class7 action = new Class7(model);
    Class1 giantView = new Class1();
    Class5 dispatcher = new Class5(giantView);
    assertEquals(Nourishment.SATURATED, model.getNourishment());
    dispatcher.addAction(action);
    for (final var nourishment : Nourishment.values()) {
      for (final var fatigue : Fatigue.values()) {
        for (final var health : Health.values()) {
          Class2 cmd = new Class2(fatigue, health, nourishment);
          dispatcher.performAction(cmd, 0);
          assertEquals(nourishment, model.getNourishment());
          assertEquals(fatigue, model.getFatigue());
          assertEquals(health, model.getHealth());
        }
      }
    }
  }

  @Test
  void testUpdateView() {
    final var model =
        new Class3("giant1", Health.HEALTHY, Fatigue.ALERT, Nourishment.SATURATED);
    Class1 giantView = new Class1();
    Class5 dispatcher = new Class5(giantView);
    assertDoesNotThrow(() -> dispatcher.updateView(model));
  }
}
