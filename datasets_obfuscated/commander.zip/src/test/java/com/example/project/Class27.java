/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import static org.junit.jupiter.api.Assertions.assertTrue;

import com.example.project.exceptions.Class13;
import com.example.project.exceptions.Class14;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class Class27 {

  private static final Logger LOG = LoggerFactory.getLogger(Class27.class);

  @Test
  void performTest() {
    Class3.Operation op =
        (l) -> {
          if (!l.isEmpty()) {
            throw l.remove(0);
          }
        };
    Class3.HandleErrorIssue<Class2> handleError = (o, e) -> {};
    var r1 =
        new Class3<>(
            op,
            handleError,
            3,
            30000,
            e -> Class13.class.isAssignableFrom(e.getClass()));
    var r2 =
        new Class3<>(
            op,
            handleError,
            3,
            30000,
            e -> Class13.class.isAssignableFrom(e.getClass()));
    var user = new Class7("Jim", "ABCD");
    var order = new Class2(user, "book", 10f);
    var arr1 =
        new ArrayList<>(
            List.of(new Class14(), new Class13()));
    try {
      r1.perform(arr1, order);
    } catch (Exception e1) {
      LOG.error("An exception occurred", e1);
    }
    var arr2 =
        new ArrayList<>(
            List.of(new Class13(), new Class14()));
    try {
      r2.perform(arr2, order);
    } catch (Exception e1) {
      LOG.error("An exception occurred", e1);
    }
    // r1 stops at Class14, r2 retries because it encounters
    // Class13
    assertTrue(arr1.size() == 1 && arr2.isEmpty());
  }
}
