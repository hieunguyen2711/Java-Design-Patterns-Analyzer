/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import static org.junit.jupiter.api.Assertions.assertFalse;

import com.example.project.employeehandle.Class25;
import com.example.project.employeehandle.Class24;
import com.example.project.exceptions.Class13;
import com.example.project.exceptions.Class14;
import com.example.project.exceptions.Class11;
import com.example.project.exceptions.Class12;
import com.example.project.messagingservice.Class18;
import com.example.project.messagingservice.Class17;
import com.example.project.paymentservice.Class15;
import com.example.project.paymentservice.Class16;
import com.example.project.queue.Class19;
import com.example.project.shippingservice.Class23;
import com.example.project.shippingservice.Class22;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.platform.commons.util.StringUtils;

class Class26 {

  private final Class4 retryParams = new Class4(1, 1_000L);

  private final Class5 timeLimits = new Class5(1L, 1000L, 6000L, 5000L, 2000L);

  private static final List<Exception> exceptionList = new ArrayList<>();

  private static final Class9 appAllCases = new Class9();

  static {
    exceptionList.add(new Class13());
    exceptionList.add(new Class12());
    exceptionList.add(new Class14());
    exceptionList.add(new Class11());
    exceptionList.add(new IllegalStateException());
  }

  private Class1 buildCommanderObject() {
    return buildCommanderObject(false);
  }

  private Class1 buildCommanderObject(boolean nonPaymentException) {
    Class16 paymentService =
        new Class16(
            new Class15(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13());

    Class22 shippingService;
    Class17 messagingService;
    if (nonPaymentException) {
      shippingService =
          new Class22(new Class23(), new Class13());
      messagingService =
          new Class17(new Class18(), new Class13());

    } else {
      shippingService =
          new Class22(new Class23(), new Class13());
      messagingService =
          new Class17(new Class18(), new Class13());
    }
    var employeeHandle =
        new Class24(
            new Class25(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13());
    var qdb =
        new Class19(
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13());
    return new Class1(
        employeeHandle,
        paymentService,
        shippingService,
        messagingService,
        qdb,
        retryParams,
        timeLimits);
  }

  private Class1 buildCommanderObjectVanilla() {
    Class16 paymentService =
        new Class16(
            new Class15(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13());
    var shippingService = new Class22(new Class23());
    var messagingService = new Class17(new Class18());
    var employeeHandle =
        new Class24(
            new Class25(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13());
    var qdb =
        new Class19(
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13());
    return new Class1(
        employeeHandle,
        paymentService,
        shippingService,
        messagingService,
        qdb,
        retryParams,
        timeLimits);
  }

  private Class1 buildCommanderObjectUnknownException() {
    Class16 paymentService =
        new Class16(new Class15(), new IllegalStateException());
    var shippingService = new Class22(new Class23());
    var messagingService = new Class17(new Class18());
    var employeeHandle = new Class24(new Class25(), new IllegalStateException());
    var qdb = new Class19(new Class13(), new IllegalStateException());
    return new Class1(
        employeeHandle,
        paymentService,
        shippingService,
        messagingService,
        qdb,
        retryParams,
        timeLimits);
  }

  private Class1 buildCommanderObjectNoPaymentException1() {
    Class16 paymentService = new Class16(new Class15());
    var shippingService = new Class22(new Class23());
    var messagingService = new Class17(new Class18());
    var employeeHandle = new Class24(new Class25(), new IllegalStateException());
    var qdb = new Class19(new Class13(), new IllegalStateException());
    return new Class1(
        employeeHandle,
        paymentService,
        shippingService,
        messagingService,
        qdb,
        retryParams,
        timeLimits);
  }

  private Class1 buildCommanderObjectNoPaymentException2() {
    Class16 paymentService = new Class16(new Class15());
    var shippingService = new Class22(new Class23());
    var messagingService =
        new Class17(new Class18(), new IllegalStateException());
    var employeeHandle = new Class24(new Class25(), new IllegalStateException());
    var qdb = new Class19(new Class13(), new IllegalStateException());
    return new Class1(
        employeeHandle,
        paymentService,
        shippingService,
        messagingService,
        qdb,
        retryParams,
        timeLimits);
  }

  private Class1 buildCommanderObjectNoPaymentException3() {
    Class16 paymentService = new Class16(new Class15());
    var shippingService = new Class22(new Class23());
    var messagingService =
        new Class17(new Class18(), new Class13());
    var employeeHandle = new Class24(new Class25(), new IllegalStateException());
    var qdb = new Class19(new Class13(), new IllegalStateException());
    return new Class1(
        employeeHandle,
        paymentService,
        shippingService,
        messagingService,
        qdb,
        retryParams,
        timeLimits);
  }

  private Class1 buildCommanderObjectWithDB() {
    return buildCommanderObjectWithoutDB(false, false, new IllegalStateException());
  }

  private Class1 buildCommanderObjectWithDB(
      boolean includeException, boolean includeDBException, Exception e) {
    var l = includeDBException ? new Class13() : e;
    Class16 paymentService;
    Class22 shippingService;
    Class17 messagingService;
    Class24 employeeHandle;
    if (includeException) {
      paymentService = new Class16(new Class15(), l);
      shippingService = new Class22(new Class23(), l);
      messagingService = new Class17(new Class18(), l);
      employeeHandle = new Class24(new Class25(), l);
    } else {
      paymentService = new Class16(null);
      shippingService = new Class22(null);
      messagingService = new Class17(null);
      employeeHandle = new Class24(null);
    }

    return new Class1(
        employeeHandle,
        paymentService,
        shippingService,
        messagingService,
        null,
        retryParams,
        timeLimits);
  }

  private Class1 buildCommanderObjectWithoutDB() {
    return buildCommanderObjectWithoutDB(false, false, new IllegalStateException());
  }

  private Class1 buildCommanderObjectWithoutDB(
      boolean includeException, boolean includeDBException, Exception e) {
    var l = includeDBException ? new Class13() : e;
    Class16 paymentService;
    Class22 shippingService;
    Class17 messagingService;
    Class24 employeeHandle;
    if (includeException) {
      paymentService = new Class16(null, l);
      shippingService = new Class22(null, l);
      messagingService = new Class17(null, l);
      employeeHandle = new Class24(null, l);
    } else {
      paymentService = new Class16(null);
      shippingService = new Class22(null);
      messagingService = new Class17(null);
      employeeHandle = new Class24(null);
    }

    return new Class1(
        employeeHandle,
        paymentService,
        shippingService,
        messagingService,
        null,
        retryParams,
        timeLimits);
  }

  @Test
  void testPlaceOrderVanilla() {
    long paymentTime = timeLimits.paymentTime();
    long queueTaskTime = timeLimits.queueTaskTime();
    for (double d = 0.1; d < 2; d = d + 0.1) {
      paymentTime *= d;
      queueTaskTime *= d;
      Class1 c = buildCommanderObjectVanilla();
      var order = new Class2(new Class7("K", "J"), "pen", 1f);
      for (Class2.MessageSent ms : Class2.MessageSent.values()) {
        c.placeOrder(order);
        assertFalse(StringUtils.isBlank(order.id));
      }
    }
  }

  @Test
  void testPlaceOrder() throws Exception {
    long paymentTime = timeLimits.paymentTime();
    long queueTaskTime = timeLimits.queueTaskTime();
    for (double d = 0.1; d < 2; d = d + 0.1) {
      paymentTime *= d;
      queueTaskTime *= d;
      Class1 c = buildCommanderObject(true);
      var order = new Class2(new Class7("K", "J"), "pen", 1f);
      for (Class2.MessageSent ms : Class2.MessageSent.values()) {
        c.placeOrder(order);
        assertFalse(StringUtils.isBlank(order.id));
      }
    }
  }

  @Test
  void testPlaceOrder2() throws Exception {
    long paymentTime = timeLimits.paymentTime();
    long queueTaskTime = timeLimits.queueTaskTime();
    for (double d = 0.1; d < 2; d = d + 0.1) {
      paymentTime *= d;
      queueTaskTime *= d;
      Class1 c = buildCommanderObject(false);
      var order = new Class2(new Class7("K", "J"), "pen", 1f);
      for (Class2.MessageSent ms : Class2.MessageSent.values()) {
        c.placeOrder(order);
        assertFalse(StringUtils.isBlank(order.id));
      }
    }
  }

  @Test
  void testPlaceOrderNoException1() throws Exception {
    long paymentTime = timeLimits.paymentTime();
    long queueTaskTime = timeLimits.queueTaskTime();
    for (double d = 0.1; d < 2; d = d + 0.1) {
      paymentTime *= d;
      queueTaskTime *= d;
      Class1 c = buildCommanderObjectNoPaymentException1();
      var order = new Class2(new Class7("K", "J"), "pen", 1f);
      for (Class2.MessageSent ms : Class2.MessageSent.values()) {
        c.placeOrder(order);
        assertFalse(StringUtils.isBlank(order.id));
      }
    }
  }

  @Test
  void testPlaceOrderNoException2() throws Exception {
    long paymentTime = timeLimits.paymentTime();
    long queueTaskTime = timeLimits.queueTaskTime();
    for (double d = 0.1; d < 2; d = d + 0.1) {
      paymentTime *= d;
      queueTaskTime *= d;
      Class1 c = buildCommanderObjectNoPaymentException2();
      var order = new Class2(new Class7("K", "J"), "pen", 1f);
      for (Class2.MessageSent ms : Class2.MessageSent.values()) {
        c.placeOrder(order);
        assertFalse(StringUtils.isBlank(order.id));
      }
    }
  }

  @Test
  void testPlaceOrderNoException3() throws Exception {
    long paymentTime = timeLimits.paymentTime();
    long queueTaskTime = timeLimits.queueTaskTime();
    for (double d = 0.1; d < 2; d = d + 0.1) {
      paymentTime *= d;
      queueTaskTime *= d;
      Class1 c = buildCommanderObjectNoPaymentException3();
      var order = new Class2(new Class7("K", "J"), "pen", 1f);
      for (Class2.MessageSent ms : Class2.MessageSent.values()) {
        c.placeOrder(order);
        assertFalse(StringUtils.isBlank(order.id));
      }
    }
  }

  @Test
  void testPlaceOrderNoException4() throws Exception {
    long paymentTime = timeLimits.paymentTime();
    long queueTaskTime = timeLimits.queueTaskTime();
    for (double d = 0.1; d < 2; d = d + 0.1) {
      paymentTime *= d;
      queueTaskTime *= d;
      Class1 c = buildCommanderObjectNoPaymentException3();
      var order = new Class2(new Class7("K", "J"), "pen", 1f);
      for (Class2.MessageSent ms : Class2.MessageSent.values()) {
        c.placeOrder(order);
        c.placeOrder(order);
        c.placeOrder(order);
        assertFalse(StringUtils.isBlank(order.id));
      }
    }
  }

  @Test
  void testPlaceOrderUnknownException() throws Exception {
    long paymentTime = timeLimits.paymentTime();
    long queueTaskTime = timeLimits.queueTaskTime();
    long messageTime = timeLimits.messageTime();
    long employeeTime = timeLimits.employeeTime();
    long queueTime = timeLimits.queueTime();
    for (double d = 0.1; d < 2; d = d + 0.1) {
      paymentTime *= d;
      queueTaskTime *= d;
      messageTime *= d;
      employeeTime *= d;
      queueTime *= d;
      Class1 c = buildCommanderObjectUnknownException();
      var order = new Class2(new Class7("K", "J"), "pen", 1f);
      for (Class2.MessageSent ms : Class2.MessageSent.values()) {
        c.placeOrder(order);
        assertFalse(StringUtils.isBlank(order.id));
      }
    }
  }

  @Test
  void testPlaceOrderShortDuration() throws Exception {
    long paymentTime = timeLimits.paymentTime();
    long queueTaskTime = timeLimits.queueTaskTime();
    long messageTime = timeLimits.messageTime();
    long employeeTime = timeLimits.employeeTime();
    long queueTime = timeLimits.queueTime();
    for (double d = 0.1; d < 2; d = d + 0.1) {
      paymentTime *= d;
      queueTaskTime *= d;
      messageTime *= d;
      employeeTime *= d;
      queueTime *= d;
      Class1 c = buildCommanderObject(true);
      var order = new Class2(new Class7("K", "J"), "pen", 1f);
      for (Class2.MessageSent ms : Class2.MessageSent.values()) {
        c.placeOrder(order);
        assertFalse(StringUtils.isBlank(order.id));
      }
    }
  }

  @Test
  void testPlaceOrderShortDuration2() throws Exception {
    long paymentTime = timeLimits.paymentTime();
    long queueTaskTime = timeLimits.queueTaskTime();
    long messageTime = timeLimits.messageTime();
    long employeeTime = timeLimits.employeeTime();
    long queueTime = timeLimits.queueTime();
    for (double d = 0.1; d < 2; d = d + 0.1) {
      paymentTime *= d;
      queueTaskTime *= d;
      messageTime *= d;
      employeeTime *= d;
      queueTime *= d;
      Class1 c = buildCommanderObject(false);
      var order = new Class2(new Class7("K", "J"), "pen", 1f);
      for (Class2.MessageSent ms : Class2.MessageSent.values()) {
        c.placeOrder(order);
        assertFalse(StringUtils.isBlank(order.id));
      }
    }
  }

  @Test
  void testPlaceOrderNoExceptionShortMsgDuration() throws Exception {
    long paymentTime = timeLimits.paymentTime();
    long queueTaskTime = timeLimits.queueTaskTime();
    long messageTime = timeLimits.messageTime();
    long employeeTime = timeLimits.employeeTime();
    long queueTime = timeLimits.queueTime();
    for (double d = 0.1; d < 2; d = d + 0.1) {
      paymentTime *= d;
      queueTaskTime *= d;
      messageTime *= d;
      employeeTime *= d;
      queueTime *= d;
      Class1 c = buildCommanderObjectNoPaymentException1();
      var order = new Class2(new Class7("K", "J"), "pen", 1f);
      for (Class2.MessageSent ms : Class2.MessageSent.values()) {
        c.placeOrder(order);
        assertFalse(StringUtils.isBlank(order.id));
      }
    }
  }

  @Test
  void testPlaceOrderNoExceptionShortQueueDuration() throws Exception {
    long paymentTime = timeLimits.paymentTime();
    long queueTaskTime = timeLimits.queueTaskTime();
    long messageTime = timeLimits.messageTime();
    long employeeTime = timeLimits.employeeTime();
    long queueTime = timeLimits.queueTime();
    for (double d = 0.1; d < 2; d = d + 0.1) {
      paymentTime *= d;
      queueTaskTime *= d;
      messageTime *= d;
      employeeTime *= d;
      queueTime *= d;
      Class1 c = buildCommanderObjectUnknownException();
      var order = new Class2(new Class7("K", "J"), "pen", 1f);
      for (Class2.MessageSent ms : Class2.MessageSent.values()) {
        c.placeOrder(order);
        assertFalse(StringUtils.isBlank(order.id));
      }
    }
  }

  @Test
  void testPlaceOrderWithDatabase() throws Exception {
    long paymentTime = timeLimits.paymentTime();
    long queueTaskTime = timeLimits.queueTaskTime();
    long messageTime = timeLimits.messageTime();
    long employeeTime = timeLimits.employeeTime();
    long queueTime = timeLimits.queueTime();
    for (double d = 0.1; d < 2; d = d + 0.1) {
      paymentTime *= d;
      queueTaskTime *= d;
      messageTime *= d;
      employeeTime *= d;
      queueTime *= d;
      Class1 c = buildCommanderObjectWithDB();
      var order = new Class2(new Class7("K", null), "pen", 1f);
      for (Class2.MessageSent ms : Class2.MessageSent.values()) {
        c.placeOrder(order);
        assertFalse(StringUtils.isBlank(order.id));
      }
    }
  }

  @Test
  void testPlaceOrderWithDatabaseAndExceptions() throws Exception {
    long paymentTime = timeLimits.paymentTime();
    long queueTaskTime = timeLimits.queueTaskTime();
    long messageTime = timeLimits.messageTime();
    long employeeTime = timeLimits.employeeTime();
    long queueTime = timeLimits.queueTime();
    for (double d = 0.1; d < 2; d = d + 0.1) {
      paymentTime *= d;
      queueTaskTime *= d;
      messageTime *= d;
      employeeTime *= d;
      queueTime *= d;

      for (Exception e : exceptionList) {

        Class1 c = buildCommanderObjectWithDB(true, true, e);
        var order = new Class2(new Class7("K", null), "pen", 1f);
        for (Class2.MessageSent ms : Class2.MessageSent.values()) {
          c.placeOrder(order);
          assertFalse(StringUtils.isBlank(order.id));
        }

        c = buildCommanderObjectWithDB(true, false, e);
        order = new Class2(new Class7("K", null), "pen", 1f);
        for (Class2.MessageSent ms : Class2.MessageSent.values()) {
          c.placeOrder(order);
          assertFalse(StringUtils.isBlank(order.id));
        }

        c = buildCommanderObjectWithDB(false, false, e);
        order = new Class2(new Class7("K", null), "pen", 1f);
        for (Class2.MessageSent ms : Class2.MessageSent.values()) {
          c.placeOrder(order);
          assertFalse(StringUtils.isBlank(order.id));
        }

        c = buildCommanderObjectWithDB(false, true, e);
        order = new Class2(new Class7("K", null), "pen", 1f);
        for (Class2.MessageSent ms : Class2.MessageSent.values()) {
          c.placeOrder(order);
          assertFalse(StringUtils.isBlank(order.id));
        }
      }
    }
  }

  @Test
  void testPlaceOrderWithoutDatabase() throws Exception {
    long paymentTime = timeLimits.paymentTime();
    long queueTaskTime = timeLimits.queueTaskTime();
    long messageTime = timeLimits.messageTime();
    long employeeTime = timeLimits.employeeTime();
    long queueTime = timeLimits.queueTime();
    for (double d = 0.1; d < 2; d = d + 0.1) {
      paymentTime *= d;
      queueTaskTime *= d;
      messageTime *= d;
      employeeTime *= d;
      queueTime *= d;
      Class1 c = buildCommanderObjectWithoutDB();
      var order = new Class2(new Class7("K", null), "pen", 1f);
      for (Class2.MessageSent ms : Class2.MessageSent.values()) {
        c.placeOrder(order);
        assertFalse(StringUtils.isBlank(order.id));
      }
    }
  }

  @Test
  void testPlaceOrderWithoutDatabaseAndExceptions() throws Exception {
    long paymentTime = timeLimits.paymentTime();
    long queueTaskTime = timeLimits.queueTaskTime();
    long messageTime = timeLimits.messageTime();
    long employeeTime = timeLimits.employeeTime();
    long queueTime = timeLimits.queueTime();
    for (double d = 0.1; d < 2; d = d + 0.1) {
      paymentTime *= d;
      queueTaskTime *= d;
      messageTime *= d;
      employeeTime *= d;
      queueTime *= d;

      for (Exception e : exceptionList) {

        Class1 c = buildCommanderObjectWithoutDB(true, true, e);
        var order = new Class2(new Class7("K", null), "pen", 1f);
        for (Class2.MessageSent ms : Class2.MessageSent.values()) {
          c.placeOrder(order);
          assertFalse(StringUtils.isBlank(order.id));
        }

        c = buildCommanderObjectWithoutDB(true, false, e);
        order = new Class2(new Class7("K", null), "pen", 1f);
        for (Class2.MessageSent ms : Class2.MessageSent.values()) {
          c.placeOrder(order);
          assertFalse(StringUtils.isBlank(order.id));
        }

        c = buildCommanderObjectWithoutDB(false, false, e);
        order = new Class2(new Class7("K", null), "pen", 1f);
        for (Class2.MessageSent ms : Class2.MessageSent.values()) {
          c.placeOrder(order);
          assertFalse(StringUtils.isBlank(order.id));
        }

        c = buildCommanderObjectWithoutDB(false, true, e);
        order = new Class2(new Class7("K", null), "pen", 1f);
        for (Class2.MessageSent ms : Class2.MessageSent.values()) {
          c.placeOrder(order);
          assertFalse(StringUtils.isBlank(order.id));
        }
      }
    }
  }

  @Test
  void testAllSuccessCases() throws Exception {
    appAllCases.employeeDbSuccessCase();
    appAllCases.messagingSuccessCase();
    appAllCases.paymentSuccessCase();
    appAllCases.queueSuccessCase();
    appAllCases.shippingSuccessCase();
  }

  @Test
  void testAllUnavailableCase() throws Exception {
    appAllCases.employeeDatabaseUnavailableCase();
    appAllCases.messagingDatabaseUnavailableCasePaymentSuccess();
    appAllCases.messagingDatabaseUnavailableCasePaymentError();
    appAllCases.messagingDatabaseUnavailableCasePaymentFailure();
    appAllCases.paymentDatabaseUnavailableCase();
    appAllCases.queuePaymentTaskDatabaseUnavailableCase();
    appAllCases.queueMessageTaskDatabaseUnavailableCase();
    appAllCases.queueEmployeeDbTaskDatabaseUnavailableCase();
    appAllCases.itemUnavailableCase();
    appAllCases.shippingDatabaseUnavailableCase();
  }

  @Test
  void testAllNotPossibleCase() throws Exception {
    appAllCases.paymentNotPossibleCase();
    appAllCases.shippingItemNotPossibleCase();
  }
}
