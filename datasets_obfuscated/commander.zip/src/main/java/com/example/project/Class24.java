/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.commander.employeehandle;

import com.example.project.Class2;
import com.example.project.Class8;
import com.example.project.exceptions.Class13;

/**
 * The Class24 class is the middle-man between {@link com.iluwatar.commander.Class1} and
 * {@link Class25}.
 */
public class Class24 extends Class8 {

  public Class24(Class25 db, Exception... exc) {
    super(db, exc);
  }

  public String receiveRequest(Object... parameters) throws Class13 {
    return updateDb(parameters[0]);
  }

  protected String updateDb(Object... parameters) throws Class13 {
    var o = (Class2) parameters[0];
    if (database.get(o.id) == null) {
      database.add(o);
      return o.id; // true rcvd - change addedToEmployeeHandle to true else don't do anything
    }
    return null;
  }
}
