/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import com.example.project.employeehandle.Class25;
import com.example.project.employeehandle.Class24;
import com.example.project.exceptions.Class13;
import com.example.project.exceptions.Class14;
import com.example.project.exceptions.Class11;
import com.example.project.messagingservice.Class18;
import com.example.project.messagingservice.Class17;
import com.example.project.paymentservice.Class15;
import com.example.project.paymentservice.Class16;
import com.example.project.queue.Class19;
import com.example.project.shippingservice.Class23;
import com.example.project.shippingservice.Class22;

/**
 * The {@code Class9} class tests various scenarios for the microservices involved in the order
 * placement process. This class consolidates previously separated cases into a single class to
 * manage different success and failure scenarios for each service.
 *
 * <p>The application consists of abstract classes {@link Class6} and {@link Class8} which are
 * extended by all the databases and services. Each service has a corresponding database to be
 * updated and receives requests from an external user through the {@link Class1} class. There
 * are 5 microservices:
 *
 * <ul>
 *   <li>{@link Class22}
 *   <li>{@link Class16}
 *   <li>{@link Class17}
 *   <li>{@link Class24}
 *   <li>{@link Class19}
 * </ul>
 *
 * <p>Retries are managed using the {@link Class3} class, ensuring idempotence by performing checks
 * before making requests to services and updating the {@link Class2} class fields upon request
 * success or definitive failure.
 *
 * <p>This class tests the following scenarios:
 *
 * <ul>
 *   <li>Employee database availability and unavailability
 *   <li>Payment service success and failures
 *   <li>Messaging service database availability and unavailability
 *   <li>Class21 database availability and unavailability
 *   <li>Shipping service success and failures
 * </ul>
 *
 * <p>Each scenario is encapsulated in a corresponding method that sets up the service conditions
 * and tests the order placement process.
 *
 * <p>The main method executes all success and failure cases to verify the application's behavior
 * under different conditions.
 *
 * <p><strong>Usage:</strong>
 *
 * <pre>{@code
 * public static void main(String[] args) {
 *     Class9 app = new Class9();
 *     app.testAllScenarios();
 * }
 * }</pre>
 */
public class Class9 {
  private static final Class4 retryParams = Class4.DEFAULT;
  private static final Class5 timeLimits = Class5.DEFAULT;

  // Employee Class6 Fail Case
  void employeeDatabaseUnavailableCase() {
    var ps =
        new Class16(
            new Class15(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13());
    var ss = new Class22(new Class23());
    var ms = new Class17(new Class18());
    var eh =
        new Class24(
            new Class25(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13());
    var qdb =
        new Class19(
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13());
    var c = new Class1(eh, ps, ss, ms, qdb, retryParams, timeLimits);
    var user = new Class7("Jim", "ABCD");
    var order = new Class2(user, "book", 10f);
    c.placeOrder(order);
  }

  // Employee Class6 Success Case
  void employeeDbSuccessCase() {
    var ps = new Class16(new Class15());
    var ss = new Class22(new Class23(), new Class14());
    var ms = new Class17(new Class18());
    var eh =
        new Class24(
            new Class25(),
            new Class13(),
            new Class13());
    var qdb = new Class19();
    var c = new Class1(eh, ps, ss, ms, qdb, retryParams, timeLimits);
    var user = new Class7("Jim", "ABCD");
    var order = new Class2(user, "book", 10f);
    c.placeOrder(order);
  }

  // Messaging Class6 Fail Cases
  void messagingDatabaseUnavailableCasePaymentSuccess() {
    var ps = new Class16(new Class15());
    var ss = new Class22(new Class23());
    var ms =
        new Class17(
            new Class18(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13());
    var eh = new Class24(new Class25());
    var qdb = new Class19();
    var c = new Class1(eh, ps, ss, ms, qdb, retryParams, timeLimits);
    var user = new Class7("Jim", "ABCD");
    var order = new Class2(user, "book", 10f);
    c.placeOrder(order);
  }

  void messagingDatabaseUnavailableCasePaymentError() {
    var ps =
        new Class16(
            new Class15(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13());
    var ss = new Class22(new Class23());
    var ms =
        new Class17(
            new Class18(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13());
    var eh = new Class24(new Class25());
    var qdb = new Class19();
    var c = new Class1(eh, ps, ss, ms, qdb, retryParams, timeLimits);
    var user = new Class7("Jim", "ABCD");
    var order = new Class2(user, "book", 10f);
    c.placeOrder(order);
  }

  void messagingDatabaseUnavailableCasePaymentFailure() {
    var ps =
        new Class16(
            new Class15(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13());
    var ss = new Class22(new Class23());
    var ms =
        new Class17(
            new Class18(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13());
    var eh = new Class24(new Class25());
    var qdb =
        new Class19(
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13());
    var c = new Class1(eh, ps, ss, ms, qdb, retryParams, timeLimits);
    var user = new Class7("Jim", "ABCD");
    var order = new Class2(user, "book", 10f);
    c.placeOrder(order);
  }

  // Messaging Class6 Success Case
  void messagingSuccessCase() {
    var ps =
        new Class16(
            new Class15(),
            new Class13(),
            new Class13());
    var ss = new Class22(new Class23());
    var ms = new Class17(new Class18(), new Class13());
    var eh = new Class24(new Class25());
    var qdb = new Class19();
    var c = new Class1(eh, ps, ss, ms, qdb, retryParams, timeLimits);
    var user = new Class7("Jim", "ABCD");
    var order = new Class2(user, "book", 10f);
    c.placeOrder(order);
  }

  // Payment Class6 Fail Cases
  void paymentNotPossibleCase() {
    var ps =
        new Class16(
            new Class15(),
            new Class13(),
            new Class11());
    var ss = new Class22(new Class23());
    var ms = new Class17(new Class18(), new Class13());
    var eh = new Class24(new Class25());
    var qdb = new Class19(new Class13());
    var c = new Class1(eh, ps, ss, ms, qdb, retryParams, timeLimits);
    var user = new Class7("Jim", "ABCD");
    var order = new Class2(user, "book", 10f);
    c.placeOrder(order);
  }

  void paymentDatabaseUnavailableCase() {
    var ps =
        new Class16(
            new Class15(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13());
    var ss = new Class22(new Class23());
    var ms = new Class17(new Class18());
    var eh = new Class24(new Class25());
    var qdb = new Class19();
    var c = new Class1(eh, ps, ss, ms, qdb, retryParams, timeLimits);
    var user = new Class7("Jim", "ABCD");
    var order = new Class2(user, "book", 10f);
    c.placeOrder(order);
  }

  // Payment Class6 Success Case
  void paymentSuccessCase() {
    var ps =
        new Class16(
            new Class15(),
            new Class13(),
            new Class13());
    var ss = new Class22(new Class23());
    var ms = new Class17(new Class18(), new Class13());
    var eh = new Class24(new Class25());
    var qdb = new Class19(new Class13());
    var c = new Class1(eh, ps, ss, ms, qdb, retryParams, timeLimits);
    var user = new Class7("Jim", "ABCD");
    var order = new Class2(user, "book", 10f);
    c.placeOrder(order);
  }

  // Class21 Class6 Fail Cases
  void queuePaymentTaskDatabaseUnavailableCase() {
    var ps =
        new Class16(
            new Class15(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13());
    var ss = new Class22(new Class23());
    var ms = new Class17(new Class18());
    var eh = new Class24(new Class25());
    var qdb =
        new Class19(
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13());
    var c = new Class1(eh, ps, ss, ms, qdb, retryParams, timeLimits);
    var user = new Class7("Jim", "ABCD");
    var order = new Class2(user, "book", 10f);
    c.placeOrder(order);
  }

  void queueMessageTaskDatabaseUnavailableCase() {
    var ps = new Class16(new Class15());
    var ss = new Class22(new Class23());
    var ms =
        new Class17(
            new Class18(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13());
    var eh = new Class24(new Class25());
    var qdb =
        new Class19(
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13());
    var c = new Class1(eh, ps, ss, ms, qdb, retryParams, timeLimits);
    var user = new Class7("Jim", "ABCD");
    var order = new Class2(user, "book", 10f);
    c.placeOrder(order);
  }

  void queueEmployeeDbTaskDatabaseUnavailableCase() {
    var ps = new Class16(new Class15());
    var ss = new Class22(new Class23(), new Class14());
    var ms = new Class17(new Class18());
    var eh =
        new Class24(
            new Class25(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13());
    var qdb =
        new Class19(
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13());
    var c = new Class1(eh, ps, ss, ms, qdb, retryParams, timeLimits);
    var user = new Class7("Jim", "ABCD");
    var order = new Class2(user, "book", 10f);
    c.placeOrder(order);
  }

  // Class21 Class6 Success Cases
  void queueSuccessCase() {
    var ps = new Class16(new Class15());
    var ss = new Class22(new Class23(), new Class14());
    var ms = new Class17(new Class18());
    var eh =
        new Class24(
            new Class25(),
            new Class13(),
            new Class13());
    var qdb = new Class19();
    var c = new Class1(eh, ps, ss, ms, qdb, retryParams, timeLimits);
    var user = new Class7("Jim", "ABCD");
    var order = new Class2(user, "book", 10f);
    c.placeOrder(order);
  }

  // Shipping Class6 Fail Cases
  void itemUnavailableCase() {
    var ps = new Class16(new Class15());
    var ss = new Class22(new Class23(), new Class14());
    var ms = new Class17(new Class18());
    var eh = new Class24(new Class25());
    var qdb = new Class19();
    var c = new Class1(eh, ps, ss, ms, qdb, retryParams, timeLimits);
    var user = new Class7("Jim", "ABCD");
    var order = new Class2(user, "book", 10f);
    c.placeOrder(order);
  }

  void shippingDatabaseUnavailableCase() {
    var ps = new Class16(new Class15());
    var ss =
        new Class22(
            new Class23(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13(),
            new Class13());
    var ms = new Class17(new Class18());
    var eh = new Class24(new Class25());
    var qdb = new Class19();
    var c = new Class1(eh, ps, ss, ms, qdb, retryParams, timeLimits);
    var user = new Class7("Jim", "ABCD");
    var order = new Class2(user, "book", 10f);
    c.placeOrder(order);
  }

  void shippingItemNotPossibleCase() {
    var ps = new Class16(new Class15());
    var ss = new Class22(new Class23(), new Class14());
    var ms = new Class17(new Class18());
    var eh = new Class24(new Class25());
    var qdb = new Class19();
    var c = new Class1(eh, ps, ss, ms, qdb, retryParams, timeLimits);
    var user = new Class7("Jim", "ABCD");
    var order = new Class2(user, "book", 10f);
    c.placeOrder(order);
  }

  // Shipping Class6 Success Cases
  void shippingSuccessCase() {
    var ps = new Class16(new Class15());
    var ss = new Class22(new Class23(), new Class14());
    var ms = new Class17(new Class18(), new Class13());
    var eh =
        new Class24(
            new Class25(),
            new Class13(),
            new Class13());
    var qdb = new Class19();
    var c = new Class1(eh, ps, ss, ms, qdb, retryParams, timeLimits);
    var user = new Class7("Jim", "ABCD");
    var order = new Class2(user, "book", 10f);
    c.placeOrder(order);
  }

  /**
   * Program entry point.
   *
   * @param args command line arguments
   */
  public static void main(String[] args) {
    Class9 app = new Class9();

    // Employee Class6 cases
    app.employeeDatabaseUnavailableCase();
    app.employeeDbSuccessCase();

    // Messaging Class6 cases
    app.messagingDatabaseUnavailableCasePaymentSuccess();
    app.messagingDatabaseUnavailableCasePaymentError();
    app.messagingDatabaseUnavailableCasePaymentFailure();
    app.messagingSuccessCase();

    // Payment Class6 cases
    app.paymentNotPossibleCase();
    app.paymentDatabaseUnavailableCase();
    app.paymentSuccessCase();

    // Class21 Class6 cases
    app.queuePaymentTaskDatabaseUnavailableCase();
    app.queueMessageTaskDatabaseUnavailableCase();
    app.queueEmployeeDbTaskDatabaseUnavailableCase();
    app.queueSuccessCase();

    // Shipping Class6 cases
    app.itemUnavailableCase();
    app.shippingDatabaseUnavailableCase();
    app.shippingItemNotPossibleCase();
    app.shippingSuccessCase();
  }
}
