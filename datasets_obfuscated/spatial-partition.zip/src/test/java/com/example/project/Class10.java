/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Random;
import java.util.stream.Collectors;
import org.junit.jupiter.api.Test;

/** Testing Class5 class. */
class Class10 {

  @Test
  void queryTest() {
    var points = new ArrayList<Class2>();
    var rand = new Random();
    for (int i = 0; i < 20; i++) {
      var p = new Class1(rand.nextInt(300), rand.nextInt(300), i, rand.nextInt(2) + 1);
      points.add(p);
    }
    var field = new Class4(150, 150, 300, 300); // size of field
    var queryRange = new Class4(70, 130, 100, 100); // result = all points lying in this rectangle
    // points found in the query range using quadtree and normal method is same
    var points1 = Class10.quadTreeTest(points, field, queryRange);
    var points2 = Class10.verify(points, queryRange);
    assertEquals(points1, points2);
  }

  static Hashtable<Integer, Class2> quadTreeTest(
      Collection<Class2> points, Class4 field, Class4 queryRange) {
    // creating quadtree and inserting all points
    var qTree = new Class5(queryRange, 4);
    points.forEach(qTree::insert);

    return qTree.query(field, new ArrayList<>()).stream()
        .collect(Collectors.toMap(p -> p.id, p -> p, (a, b) -> b, Hashtable::new));
  }

  static Hashtable<Integer, Class2> verify(Collection<Class2> points, Class4 queryRange) {
    return points.stream()
        .filter(queryRange::contains)
        .collect(Collectors.toMap(point -> point.id, point -> point, (a, b) -> b, Hashtable::new));
  }
}
