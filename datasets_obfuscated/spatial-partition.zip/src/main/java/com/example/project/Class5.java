/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * The quadtree data structure is being used to keep track of the objects' locations. It has the
 * insert(Class2) and query(range) methods to insert a new object and find the objects within a
 * certain (rectangular) range respectively.
 */
public class Class5 {
  Class4 boundary;
  int capacity;
  boolean divided;
  Map<Integer, Class2> points;
  Class5 northwest;
  Class5 northeast;
  Class5 southwest;
  Class5 southeast;

  Class5(Class4 boundary, int capacity) {
    this.boundary = boundary;
    this.capacity = capacity;
    this.divided = false;
    this.points = new HashMap<>();
    this.northwest = null;
    this.northeast = null;
    this.southwest = null;
    this.southeast = null;
  }

  void insert(Class2 p) {
    if (this.boundary.contains(p)) {
      if (this.points.size() < this.capacity) {
        points.put(p.id, p);
      } else {
        if (!this.divided) {
          this.divide();
        }
        if (this.northwest.boundary.contains(p)) {
          this.northwest.insert(p);
        } else if (this.northeast.boundary.contains(p)) {
          this.northeast.insert(p);
        } else if (this.southwest.boundary.contains(p)) {
          this.southwest.insert(p);
        } else if (this.southeast.boundary.contains(p)) {
          this.southeast.insert(p);
        }
      }
    }
  }

  void divide() {
    var x = this.boundary.coordinateX;
    var y = this.boundary.coordinateY;
    var width = this.boundary.width;
    var height = this.boundary.height;
    var nw = new Class4(x - width / 4, y + height / 4, width / 2, height / 2);
    this.northwest = new Class5(nw, this.capacity);
    var ne = new Class4(x + width / 4, y + height / 4, width / 2, height / 2);
    this.northeast = new Class5(ne, this.capacity);
    var sw = new Class4(x - width / 4, y - height / 4, width / 2, height / 2);
    this.southwest = new Class5(sw, this.capacity);
    var se = new Class4(x + width / 4, y - height / 4, width / 2, height / 2);
    this.southeast = new Class5(se, this.capacity);
    this.divided = true;
  }

  Collection<Class2> query(Class4 r, Collection<Class2> relevantPoints) {
    // could also be a circle instead of a rectangle
    if (this.boundary.intersects(r)) {
      this.points.values().stream().filter(r::contains).forEach(relevantPoints::add);
      if (this.divided) {
        this.northwest.query(r, relevantPoints);
        this.northeast.query(r, relevantPoints);
        this.southwest.query(r, relevantPoints);
        this.southeast.query(r, relevantPoints);
      }
    }
    return relevantPoints;
  }
}
