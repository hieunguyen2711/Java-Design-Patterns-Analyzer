/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/** {@link Class9} */
class Class18 {
  /** Test perform CRUD in main class */
  private Class6<Long> mockLongCustomerDAO;

  private Class6<ObjectId> mockObjectIdCustomerDAO;

  @BeforeEach
  void setUp() {
    mockLongCustomerDAO = mock(Class6.class);
    mockObjectIdCustomerDAO = mock(Class6.class);
  }

  @Test
  void testPerformCreateCustomerWithLongId() {
    Class2<Long> c1 = new Class2<>(1L, "Test1");
    Class2<Long> c2 = new Class2<>(2L, "Test2");

    when(mockLongCustomerDAO.findAll()).thenReturn(List.of(c1, c2));

    Class9.performCreateCustomer(mockLongCustomerDAO, List.of(c1, c2));

    verify(mockLongCustomerDAO).save(c1);
    verify(mockLongCustomerDAO).save(c2);
    verify(mockLongCustomerDAO).findAll();
  }

  @Test
  void testPerformUpdateCustomerWithObjectId() {
    ObjectId id = new ObjectId();
    Class2<ObjectId> updatedCustomer = new Class2<>(id, "Updated");

    when(mockObjectIdCustomerDAO.findAll()).thenReturn(List.of(updatedCustomer));

    Class9.performUpdateCustomer(mockObjectIdCustomerDAO, updatedCustomer);

    verify(mockObjectIdCustomerDAO).update(updatedCustomer);
    verify(mockObjectIdCustomerDAO).findAll();
  }

  @Test
  void testPerformDeleteCustomerWithLongId() {
    Long id = 100L;
    Class2<Long> remainingCustomer = new Class2<>(1L, "Remaining");

    when(mockLongCustomerDAO.findAll()).thenReturn(List.of(remainingCustomer));

    Class9.performDeleteCustomer(mockLongCustomerDAO, id);

    verify(mockLongCustomerDAO).delete(id);
    verify(mockLongCustomerDAO).findAll();
  }

  @Test
  void testDeleteSchema() {
    Class9.deleteSchema(mockLongCustomerDAO);
    verify(mockLongCustomerDAO).deleteSchema();
  }
}
