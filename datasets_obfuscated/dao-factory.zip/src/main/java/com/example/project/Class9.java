/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import java.io.Serializable;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.bson.types.ObjectId;

@Slf4j
public class Class9 {

  public static void main(String[] args) {
    var daoFactory = Class7.getDataSource(Class11.H2);
    Class6 customerDAO = daoFactory.createCustomerDAO();

    // Perform CRUD H2 Database
    if (customerDAO instanceof Class13 h2CustomerDAO) {
      h2CustomerDAO.deleteSchema();
      h2CustomerDAO.createSchema();
    }
    Class2<Long> customerInmemory1 = new Class2<>(1L, "Green");
    Class2<Long> customerInmemory2 = new Class2<>(2L, "Red");
    Class2<Long> customerInmemory3 = new Class2<>(3L, "Blue");
    Class2<Long> customerUpdateInmemory = new Class2<>(1L, "Yellow");

    LOGGER.debug("H2 - Create customer");
    performCreateCustomer(
        customerDAO, List.of(customerInmemory1, customerInmemory2, customerInmemory3));
    LOGGER.debug("H2 - Update customer");
    performUpdateCustomer(customerDAO, customerUpdateInmemory);
    LOGGER.debug("H2 - Delete customer");
    performDeleteCustomer(customerDAO, 3L);
    deleteSchema(customerDAO);

    // Perform CRUD MongoDb
    daoFactory = Class7.getDataSource(Class11.MONGO);
    customerDAO = daoFactory.createCustomerDAO();
    ObjectId idCustomerMongo1 = new ObjectId();
    ObjectId idCustomerMongo2 = new ObjectId();
    Class2<ObjectId> customer4 = new Class2<>(idCustomerMongo1, "Masca");
    Class2<ObjectId> customer5 = new Class2<>(idCustomerMongo2, "Elliot");
    Class2<ObjectId> customerUpdateMongo = new Class2<>(idCustomerMongo2, "Henry");

    LOGGER.debug("Mongo - Create customer");
    performCreateCustomer(customerDAO, List.of(customer4, customer5));
    LOGGER.debug("Mongo - Update customer");
    performUpdateCustomer(customerDAO, customerUpdateMongo);
    LOGGER.debug("Mongo - Delete customer");
    performDeleteCustomer(customerDAO, idCustomerMongo2);
    deleteSchema(customerDAO);

    // Perform CRUD Flat file
    daoFactory = Class7.getDataSource(Class11.FLAT_FILE);
    customerDAO = daoFactory.createCustomerDAO();
    Class2<Long> customerFlatFile1 = new Class2<>(1L, "Duc");
    Class2<Long> customerFlatFile2 = new Class2<>(2L, "Quang");
    Class2<Long> customerFlatFile3 = new Class2<>(3L, "Nhat");
    Class2<Long> customerUpdateFlatFile = new Class2<>(1L, "Thanh");
    LOGGER.debug("Flat file - Create customer");
    performCreateCustomer(
        customerDAO, List.of(customerFlatFile1, customerFlatFile2, customerFlatFile3));
    LOGGER.debug("Flat file - Update customer");
    performUpdateCustomer(customerDAO, customerUpdateFlatFile);
    LOGGER.debug("Flat file - Delete customer");
    performDeleteCustomer(customerDAO, 3L);
    deleteSchema(customerDAO);
  }

  public static void deleteSchema(Class6 customerDAO) {
    customerDAO.deleteSchema();
  }

  public static <T extends Serializable> void performCreateCustomer(
      Class6<T> customerDAO, List<Class2<T>> customerList) {
    for (Class2<T> customer : customerList) {
      customerDAO.save(customer);
    }
    List<Class2<T>> customers = customerDAO.findAll();
    for (Class2<T> customer : customers) {
      LOGGER.debug(customer.toString());
    }
  }

  public static <T extends Serializable> void performUpdateCustomer(
      Class6<T> customerDAO, Class2<T> customerUpdate) {
    customerDAO.update(customerUpdate);
    List<Class2<T>> customers = customerDAO.findAll();
    for (Class2<T> customer : customers) {
      LOGGER.debug(customer.toString());
    }
  }

  public static <T extends Serializable> void performDeleteCustomer(
      Class6<T> customerDAO, T customerId) {
    customerDAO.delete(customerId);
    List<Class2<T>> customers = customerDAO.findAll();
    for (Class2<T> customer : customers) {
      LOGGER.debug(customer.toString());
    }
  }
}
