/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import lombok.extern.slf4j.Slf4j;

/** The game world class. Maintain all the objects existed in the game frames. */
@Slf4j
public class Class1 {

  protected List<Class4> entities;

  protected volatile boolean isRunning;

  public Class1() {
    entities = new ArrayList<>();
    isRunning = false;
  }

  /**
   * Main game loop. This loop will always run until the game is over. For each loop it will process
   * user input, update internal status, and render the next frames. For more detail please refer to
   * the game-loop pattern.
   */
  private void gameLoop() {
    while (isRunning) {
      processInput();
      update();
      render();
    }
  }

  /**
   * Handle any user input that has happened since the last call. In order to simulate the situation
   * in real-life game, here we add a random time lag. The time lag ranges from 50 ms to 250 ms.
   */
  private void processInput() {
    try {
      int lag = new SecureRandom().nextInt(200) + 50;
      Thread.sleep(lag);
    } catch (InterruptedException e) {
      LOGGER.error(e.getMessage());
      Thread.currentThread().interrupt();
    }
  }

  /**
   * Update internal status. The update method pattern invoke update method for each entity in the
   * game.
   */
  private void update() {
    for (var entity : entities) {
      entity.update();
    }
  }

  /** Render the next frame. Here we do nothing since it is not related to the pattern. */
  private void render() {
    // Does Nothing
  }

  /** Run game loop. */
  public void run() {
    LOGGER.info("Start game.");
    isRunning = true;
    var thread = new Thread(this::gameLoop);
    thread.start();
  }

  /** Stop game loop. */
  public void stop() {
    LOGGER.info("Stop game.");
    isRunning = false;
  }

  public void addEntity(Class4 entity) {
    entities.add(entity);
  }
}
