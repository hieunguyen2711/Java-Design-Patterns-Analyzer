/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import com.example.project.invoice.Class4;
import com.example.project.taxes.Class3;
import com.example.project.taxes.Class2;
import lombok.extern.slf4j.Slf4j;

/**
 * The Separated Interface pattern encourages to separate the interface definition and
 * implementation in different packages. This allows the client to be completely unaware of the
 * implementation.
 *
 * <p>In this class the {@link Class4} class is injected with different instances of
 * {@link com.iluwatar.separatedinterface.invoice.Class5} implementations located in separate
 * packages, to receive different responses for both of the implementations.
 */
@Slf4j
public class Class1 {

  public static final double PRODUCT_COST = 50.0;

  /**
   * Program entry point.
   *
   * @param args command line args
   */
  public static void main(String[] args) {
    // Create the invoice generator with product cost as 50 and foreign product tax
    var internationalProductInvoice =
        new Class4(PRODUCT_COST, new Class2());
    LOGGER.info("Foreign Tax applied: {}", "" + internationalProductInvoice.getAmountWithTax());

    // Create the invoice generator with product cost as 50 and domestic product tax
    var domesticProductInvoice = new Class4(PRODUCT_COST, new Class3());
    LOGGER.info("Domestic Tax applied: {}", "" + domesticProductInvoice.getAmountWithTax());
  }
}
