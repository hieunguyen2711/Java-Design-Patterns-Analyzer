/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

/** Class8 */
class Class8 {

  /** Test if we get the expected exception when trying to create a hero without a profession */
  @Test
  void testMissingProfession() {
    assertThrows(IllegalArgumentException.class, () -> new Class1.Builder(null, "Sir without a job"));
  }

  /** Test if we get the expected exception when trying to create a hero without a name */
  @Test
  void testMissingName() {
    assertThrows(IllegalArgumentException.class, () -> new Class1.Builder(Class3.THIEF, null));
  }

  /** Test if the hero build by the builder has the correct attributes, as requested */
  @Test
  void testBuildHero() {
    final String heroName = "Sir Lancelot";

    final var hero =
        new Class1.Builder(Class3.WARRIOR, heroName)
            .withArmor(Class6.CHAIN_MAIL)
            .withWeapon(Class7.SWORD)
            .withHairType(Class5.LONG_CURLY)
            .withHairColor(Class2.BLOND)
            .build();

    assertNotNull(hero);
    assertNotNull(hero.toString());
    assertEquals(Class3.WARRIOR, hero.profession());
    assertEquals(heroName, hero.name());
    assertEquals(Class6.CHAIN_MAIL, hero.armor());
    assertEquals(Class7.SWORD, hero.weapon());
    assertEquals(Class5.LONG_CURLY, hero.hairType());
    assertEquals(Class2.BLOND, hero.hairColor());
  }
}
