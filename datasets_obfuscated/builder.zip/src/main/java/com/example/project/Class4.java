/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import com.example.project.Class1.Builder;
import lombok.extern.slf4j.Slf4j;

/**
 * The intention of the Builder pattern is to find a solution to the telescoping constructor
 * antipattern. The telescoping constructor antipattern occurs when the increase of object
 * constructor parameter combination leads to an exponential list of constructors. Instead of using
 * numerous constructors, the builder pattern uses another object, a builder, that receives each
 * initialization parameter step by step and then returns the resulting constructed object at once.
 *
 * <p>The Builder pattern has another benefit. It can be used for objects that contain flat data
 * (html code, SQL query, X.509 certificate...), that is to say, data that can't be easily edited.
 * This type of data cannot be edited step by step and must be edited at once. The best way to
 * construct such an object is to use a builder class.
 *
 * <p>In this example we have the Builder pattern variation as described by Joshua Bloch in
 * Effective Java 2nd Edition.
 *
 * <p>We want to build {@link Class1} objects, but its construction is complex because of the many
 * parameters needed. To aid the user we introduce {@link Builder} class. {@link Class1.Builder} takes
 * the minimum parameters to build {@link Class1} object in its constructor. After that additional
 * configuration for the {@link Class1} object can be done using the fluent {@link Builder} interface.
 * When configuration is ready the build method is called to receive the final {@link Class1} object.
 */
@Slf4j
public class Class4 {

  /**
   * Program entry point.
   *
   * @param args command line args
   */
  public static void main(String[] args) {

    var mage =
        new Class1.Builder(Class3.MAGE, "Riobard")
            .withHairColor(Class2.BLACK)
            .withWeapon(Class7.DAGGER)
            .build();
    LOGGER.info(mage.toString());

    var warrior =
        new Class1.Builder(Class3.WARRIOR, "Amberjill")
            .withHairColor(Class2.BLOND)
            .withHairType(Class5.LONG_CURLY)
            .withArmor(Class6.CHAIN_MAIL)
            .withWeapon(Class7.SWORD)
            .build();
    LOGGER.info(warrior.toString());

    var thief =
        new Class1.Builder(Class3.THIEF, "Desmond")
            .withHairType(Class5.BALD)
            .withWeapon(Class7.BOW)
            .build();
    LOGGER.info(thief.toString());
  }
}
