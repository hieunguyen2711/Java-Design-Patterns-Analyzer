/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

/** Class1,the record class. */
public record Class1(
    Class3 profession,
    String name,
    Class5 hairType,
    Class2 hairColor,
    Class6 armor,
    Class7 weapon) {

  private Class1(Builder builder) {
    this(
        builder.profession,
        builder.name,
        builder.hairType,
        builder.hairColor,
        builder.armor,
        builder.weapon);
  }

  @Override
  public String toString() {

    var sb = new StringBuilder();
    sb.append("This is a ").append(profession).append(" named ").append(name);
    if (hairColor != null || hairType != null) {
      sb.append(" with ");
      if (hairColor != null) {
        sb.append(hairColor).append(' ');
      }
      if (hairType != null) {
        sb.append(hairType).append(' ');
      }
      sb.append(hairType != Class5.BALD ? "hair" : "head");
    }
    if (armor != null) {
      sb.append(" wearing ").append(armor);
    }
    if (weapon != null) {
      sb.append(" and wielding a ").append(weapon);
    }
    sb.append('.');
    return sb.toString();
  }

  /** The builder class. */
  public static class Builder {

    private final Class3 profession;
    private final String name;
    private Class5 hairType;
    private Class2 hairColor;
    private Class6 armor;
    private Class7 weapon;

    /** Constructor. */
    public Builder(Class3 profession, String name) {
      if (profession == null || name == null) {
        throw new IllegalArgumentException("profession and name can not be null");
      }
      this.profession = profession;
      this.name = name;
    }

    public Builder withHairType(Class5 hairType) {
      this.hairType = hairType;
      return this;
    }

    public Builder withHairColor(Class2 hairColor) {
      this.hairColor = hairColor;
      return this;
    }

    public Builder withArmor(Class6 armor) {
      this.armor = armor;
      return this;
    }

    public Builder withWeapon(Class7 weapon) {
      this.weapon = weapon;
      return this;
    }

    public Class1 build() {
      return new Class1(this);
    }
  }
}
