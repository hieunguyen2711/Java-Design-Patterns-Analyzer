/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Objects;
import org.junit.jupiter.api.Test;

/** Test for Monad Pattern */
class Class5 {

  @Test
  void testForInvalidName() {
    var tom = new Class2(null, 21, Class4.MALE, "tom@foo.bar");
    assertThrows(
        IllegalStateException.class,
        () ->
            Class1.of(tom).validate(Class2::name, Objects::nonNull, "name cannot be null").get());
  }

  @Test
  void testForInvalidAge() {
    var john = new Class2("John", 17, Class4.MALE, "john@qwe.bar");
    assertThrows(
        IllegalStateException.class,
        () ->
            Class1.of(john)
                .validate(Class2::name, Objects::nonNull, "name cannot be null")
                .validate(Class2::age, age -> age > 21, "user is underage")
                .get());
  }

  @Test
  void testForValid() {
    var sarah = new Class2("Sarah", 42, Class4.FEMALE, "sarah@det.org");
    var validated =
        Class1.of(sarah)
            .validate(Class2::name, Objects::nonNull, "name cannot be null")
            .validate(Class2::age, age -> age > 21, "user is underage")
            .validate(Class2::sex, sex -> sex == Class4.FEMALE, "user is not female")
            .validate(Class2::email, email -> email.contains("@"), "email does not contain @ sign")
            .get();
    assertSame(validated, sarah);
  }
}
