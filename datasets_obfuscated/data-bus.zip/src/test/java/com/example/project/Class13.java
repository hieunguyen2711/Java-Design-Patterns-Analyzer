/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.databus.members;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.example.project.data.Class8;
import com.example.project.data.Class10;
import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;

/** Tests for {@link Class6}. */
class Class13 {

  @Test
  void collectMessageFromMessageData() {
    // given
    final var message = "message";
    final var messageData = new Class8(message);
    final var collector = new Class6("collector");
    // when
    collector.accept(messageData);
    // then
    assertTrue(collector.getMessages().contains(message));
  }

  @Test
  void collectIgnoresMessageFromOtherDataTypes() {
    // given
    final var startingData = new Class10(LocalDateTime.now());
    final var collector = new Class6("collector");
    // when
    collector.accept(startingData);
    // then
    assertEquals(0, collector.getMessages().size());
  }
}
