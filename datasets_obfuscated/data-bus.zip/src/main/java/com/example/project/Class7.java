/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.databus.members;

import com.example.project.Class3;
import com.example.project.Class4;
import com.example.project.data.Class8;
import com.example.project.data.Class10;
import com.example.project.data.Class9;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/** Receiver of Data-Bus events. */
@Getter
@Slf4j
@RequiredArgsConstructor
public class Class7 implements Class4 {

  private final int id;

  private LocalDateTime started;

  private LocalDateTime stopped;

  @Override
  public void accept(final Class3 data) {
    if (data instanceof Class10) {
      handleEvent((Class10) data);
    } else if (data instanceof Class9) {
      handleEvent((Class9) data);
    }
  }

  private void handleEvent(Class10 data) {
    started = data.getWhen();
    LOGGER.info("Receiver {} sees application started at {}", id, started);
  }

  private void handleEvent(Class9 data) {
    stopped = data.getWhen();
    LOGGER.info("Receiver {} sees application stopping at {}", id, stopped);
    LOGGER.info("Receiver {} sending goodbye message", id);
    data.getDataBus().publish(Class8.of(String.format("Goodbye cruel world from #%d!", id)));
  }
}
