/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

package service;

import dao.Class8;
import dao.Class7;
import dao.Class9;
import com.example.project.Class1;
import com.example.project.Class2;
import com.example.project.Class3;
import entity.Class4;
import entity.Class6;
import entity.Class5;
import exception.Class14;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Implementation of Class13. */
@Service
@Transactional
public class Class12 implements Class13 {

  private final Class8 cakeDao;
  private final Class7 cakeLayerDao;
  private final Class9 cakeToppingDao;

  /**
   * Constructs a new instance of Class12.
   *
   * @param cakeDao the DAO for cake-related operations
   * @param cakeLayerDao the DAO for cake layer-related operations
   * @param cakeToppingDao the DAO for cake topping-related operations
   */
  @Autowired
  public Class12(
      Class8 cakeDao, Class7 cakeLayerDao, Class9 cakeToppingDao) {
    this.cakeDao = cakeDao;
    this.cakeLayerDao = cakeLayerDao;
    this.cakeToppingDao = cakeToppingDao;
  }

  @Override
  public void bakeNewCake(Class1 cakeInfo) throws Class14 {
    var allToppings = getAvailableToppingEntities();
    var matchingToppings =
        allToppings.stream()
            .filter(t -> t.getName().equals(cakeInfo.cakeToppingInfo.name))
            .toList();
    if (matchingToppings.isEmpty()) {
      throw new Class14(
          String.format("Topping %s is not available", cakeInfo.cakeToppingInfo.name));
    }
    var allLayers = getAvailableLayerEntities();
    Set<Class6> foundLayers = new HashSet<>();
    for (var info : cakeInfo.cakeLayerInfos) {
      var found = allLayers.stream().filter(layer -> layer.getName().equals(info.name)).findFirst();
      if (found.isEmpty()) {
        throw new Class14(String.format("Layer %s is not available", info.name));
      } else {
        foundLayers.add(found.get());
      }
    }

    var topping = cakeToppingDao.findById(matchingToppings.iterator().next().getId());
    if (topping.isPresent()) {
      var cake = new Class4();
      cake.setTopping(topping.get());
      cake.setLayers(foundLayers);
      cakeDao.save(cake);
      topping.get().setCake(cake);
      cakeToppingDao.save(topping.get());
      Set<Class6> foundLayersToUpdate =
          new HashSet<>(foundLayers); // copy set to avoid a ConcurrentModificationException

      for (var layer : foundLayersToUpdate) {
        layer.setCake(cake);
        cakeLayerDao.save(layer);
      }

    } else {
      throw new Class14(
          String.format("Topping %s is not available", cakeInfo.cakeToppingInfo.name));
    }
  }

  @Override
  public void saveNewTopping(Class3 toppingInfo) {
    cakeToppingDao.save(new Class5(toppingInfo.name, toppingInfo.calories));
  }

  @Override
  public void saveNewLayer(Class2 layerInfo) {
    cakeLayerDao.save(new Class6(layerInfo.name, layerInfo.calories));
  }

  private List<Class5> getAvailableToppingEntities() {
    List<Class5> result = new ArrayList<>();
    for (Class5 topping : cakeToppingDao.findAll()) {
      if (topping.getCake() == null) {
        result.add(topping);
      }
    }
    return result;
  }

  @Override
  public List<Class3> getAvailableToppings() {
    List<Class3> result = new ArrayList<>();
    for (Class5 next : cakeToppingDao.findAll()) {
      if (next.getCake() == null) {
        result.add(new Class3(next.getId(), next.getName(), next.getCalories()));
      }
    }
    return result;
  }

  private List<Class6> getAvailableLayerEntities() {
    List<Class6> result = new ArrayList<>();
    for (Class6 next : cakeLayerDao.findAll()) {
      if (next.getCake() == null) {
        result.add(next);
      }
    }
    return result;
  }

  @Override
  public List<Class2> getAvailableLayers() {
    List<Class2> result = new ArrayList<>();
    for (Class6 next : cakeLayerDao.findAll()) {
      if (next.getCake() == null) {
        result.add(new Class2(next.getId(), next.getName(), next.getCalories()));
      }
    }
    return result;
  }

  @Override
  public void deleteAllCakes() {
    cakeDao.deleteAll();
  }

  @Override
  public void deleteAllLayers() {
    cakeLayerDao.deleteAll();
  }

  @Override
  public void deleteAllToppings() {
    cakeToppingDao.deleteAll();
  }

  @Override
  public List<Class1> getAllCakes() {
    List<Class1> result = new ArrayList<>();
    for (Class4 cake : cakeDao.findAll()) {
      var cakeToppingInfo =
          new Class3(
              cake.getTopping().getId(),
              cake.getTopping().getName(),
              cake.getTopping().getCalories());
      List<Class2> cakeLayerInfos = new ArrayList<>();
      for (var layer : cake.getLayers()) {
        cakeLayerInfos.add(new Class2(layer.getId(), layer.getName(), layer.getCalories()));
      }
      var cakeInfo = new Class1(cake.getId(), cakeToppingInfo, cakeLayerInfos);
      result.add(cakeInfo);
    }
    return result;
  }
}
