/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

package service;

import com.example.project.Class1;
import com.example.project.Class2;
import com.example.project.Class3;
import exception.Class14;
import java.util.List;
import org.springframework.stereotype.Service;

/** Service for cake baking operations. */
@Service
public interface Class13 {

  /** Bakes new cake according to parameters. */
  void bakeNewCake(Class1 cakeInfo) throws Class14;

  /** Get all cakes. */
  List<Class1> getAllCakes();

  /** Store new cake topping. */
  void saveNewTopping(Class3 toppingInfo);

  /** Get available cake toppings. */
  List<Class3> getAvailableToppings();

  /** Add new cake layer. */
  void saveNewLayer(Class2 layerInfo);

  /** Get available cake layers. */
  List<Class2> getAvailableLayers();

  void deleteAllCakes();

  void deleteAllLayers();

  void deleteAllToppings();
}
