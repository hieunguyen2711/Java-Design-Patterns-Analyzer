/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.layers;

import com.example.project.Class1;
import com.example.project.Class2;
import com.example.project.Class3;
import exception.Class14;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;
import service.Class13;
import view.Class11;

/**
 * The Class15 class is the entry point of the application. It implements CommandLineRunner, which
 * means it will execute the run method after the application context is loaded.
 *
 * <p>The Class15 class is responsible for initializing the cake baking service with sample data and
 * creating a view to render the cakes. It uses the Class13 to save new layers and
 * toppings and to bake new cakes. It also handles exceptions that might occur during the cake
 * baking process.
 */
@EntityScan(basePackages = "entity")
@ComponentScan(basePackages = {"com.iluwatar.layers", "service", "dto", "exception", "view", "dao"})
@Component
@Slf4j
public class Class15 implements CommandLineRunner {
  private final Class13 cakeBakingService;
  public static final String STRAWBERRY = "strawberry";

  @Autowired
  public Class15(Class13 cakeBakingService) {
    this.cakeBakingService = cakeBakingService;
  }

  @Override
  public void run(String... args) {
    // initialize sample data
    initializeData();
    // create view and render it
    var cakeView = new Class11(cakeBakingService);
    cakeView.render();
  }

  public static void main(String[] args) {
    SpringApplication.run(Class15.class, args);
  }

  /** Initializes the example data. */
  private void initializeData() {
    cakeBakingService.saveNewLayer(new Class2("chocolate", 1200));
    cakeBakingService.saveNewLayer(new Class2("banana", 900));
    cakeBakingService.saveNewLayer(new Class2(STRAWBERRY, 950));
    cakeBakingService.saveNewLayer(new Class2("lemon", 950));
    cakeBakingService.saveNewLayer(new Class2("vanilla", 950));
    cakeBakingService.saveNewLayer(new Class2(STRAWBERRY, 950));

    cakeBakingService.saveNewTopping(new Class3("candies", 350));
    cakeBakingService.saveNewTopping(new Class3("cherry", 350));

    var cake1 =
        new Class1(
            new Class3("candies", 0),
            List.of(
                new Class2("chocolate", 0),
                new Class2("banana", 0),
                new Class2(STRAWBERRY, 0)));
    try {
      cakeBakingService.bakeNewCake(cake1);
    } catch (Class14 e) {
      LOGGER.error("Class4 baking exception", e);
    }
    var cake2 =
        new Class1(
            new Class3("cherry", 0),
            List.of(
                new Class2("vanilla", 0),
                new Class2("lemon", 0),
                new Class2(STRAWBERRY, 0)));
    try {
      cakeBakingService.bakeNewCake(cake2);
    } catch (Class14 e) {
      LOGGER.error("Class4 baking exception", e);
    }
  }
}
