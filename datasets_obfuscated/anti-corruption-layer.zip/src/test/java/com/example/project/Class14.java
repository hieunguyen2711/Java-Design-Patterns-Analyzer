/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.corruption.system;

import static org.junit.jupiter.api.Assertions.*;

import com.example.project.system.legacy.Class6;
import com.example.project.system.legacy.Class7;
import com.example.project.system.modern.Class11;
import com.example.project.system.modern.Class13;
import com.example.project.system.modern.Class12;
import com.example.project.system.modern.Class9;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@SpringBootTest
public class Class14 {

  @Autowired private Class7 legacyShop;

  @Autowired private Class12 modernShop;

  /**
   * Test the anti-corruption layer. Main intention is to demonstrate how the anti-corruption layer
   * works. The 2 shops (modern and legacy) should operate independently and in the same time
   * synchronize the data.
   */
  @Test
  public void antiCorruptionLayerTest() throws Class4 {
    // a new order comes to the legacy shop.
    Class6 legacyOrder = new Class6("1", "addr1", "item1", 1, 1);
    // place the order in the legacy shop.
    legacyShop.placeOrder(legacyOrder);
    // the order is placed as usual since there is no other orders with the id in the both systems.
    Optional<Class6> legacyOrderWithIdOne = legacyShop.findOrder("1");
    assertEquals(Optional.of(legacyOrder), legacyOrderWithIdOne);

    // a new order (or maybe just the same order) appears in the modern shop
    Class13 modernOrder =
        new Class13("1", new Class11("addr1"), new Class9("item1", 1, 1), "");
    // the system places it, but it checks if there is an order with the same id in the legacy shop.
    modernShop.placeOrder(modernOrder);

    Optional<Class13> modernOrderWithIdOne = modernShop.findOrder("1");
    // there is no new order placed since there is already an order with the same id in the legacy
    // shop.
    assertTrue(modernOrderWithIdOne.isEmpty());
  }

  /**
   * Test the anti-corruption layer when a conflict occurs between systems. This test ensures that
   * an exception is thrown when conflicting orders are placed.
   */
  @Test
  public void antiCorruptionLayerWithExTest() throws Class4 {
    // a new order comes to the legacy shop.
    Class6 legacyOrder = new Class6("1", "addr1", "item1", 1, 1);
    // place the order in the legacy shop.
    legacyShop.placeOrder(legacyOrder);
    // the order is placed as usual since there is no other orders with the id in the both systems.
    Optional<Class6> legacyOrderWithIdOne = legacyShop.findOrder("1");
    assertEquals(Optional.of(legacyOrder), legacyOrderWithIdOne);
    // a new order but with the same id and different data appears in the modern shop
    Class13 modernOrder =
        new Class13("1", new Class11("addr1"), new Class9("item1", 10, 1), "");
    // the system rejects the order since there are 2 orders with contradiction there.
    assertThrows(Class4.class, () -> modernShop.placeOrder(modernOrder));
  }
}
