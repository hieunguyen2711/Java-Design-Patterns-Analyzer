/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;

import java.util.List;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

/** Class16 */
class Class16 {

  private static final Class1 PERFECT_ORDER =
      new Class1("name", "12345678901", "addr", "dep", "order");
  private static final Class1 WRONG_ORDER = new Class1("name", "12345678901", "addr", "dep", "");
  private static final Class1 WRONG_DEPOSIT = new Class1("name", "12345678901", "addr", "", "order");
  private static final Class1 WRONG_ADDRESS = new Class1("name", "12345678901", "", "dep", "order");
  private static final Class1 WRONG_CONTACT = new Class1("name", "", "addr", "dep", "order");
  private static final Class1 WRONG_NAME = new Class1("", "12345678901", "addr", "dep", "order");

  static List<Object[]> getTestData() {
    return List.of(
        new Object[] {new Class6(), PERFECT_ORDER, ""},
        new Object[] {new Class6(), WRONG_NAME, "Invalid name!"},
        new Object[] {new Class6(), WRONG_CONTACT, ""},
        new Object[] {new Class6(), WRONG_ADDRESS, ""},
        new Object[] {new Class6(), WRONG_DEPOSIT, ""},
        new Object[] {new Class6(), WRONG_ORDER, ""},
        new Object[] {new Class5(), PERFECT_ORDER, ""},
        new Object[] {new Class5(), WRONG_NAME, ""},
        new Object[] {new Class5(), WRONG_CONTACT, "Invalid contact number!"},
        new Object[] {new Class5(), WRONG_ADDRESS, ""},
        new Object[] {new Class5(), WRONG_DEPOSIT, ""},
        new Object[] {new Class5(), WRONG_ORDER, ""},
        new Object[] {new Class3(), PERFECT_ORDER, ""},
        new Object[] {new Class3(), WRONG_NAME, ""},
        new Object[] {new Class3(), WRONG_CONTACT, ""},
        new Object[] {new Class3(), WRONG_ADDRESS, "Invalid address!"},
        new Object[] {new Class3(), WRONG_DEPOSIT, ""},
        new Object[] {new Class3(), WRONG_ORDER, ""},
        new Object[] {new Class8(), PERFECT_ORDER, ""},
        new Object[] {new Class8(), WRONG_NAME, ""},
        new Object[] {new Class8(), WRONG_CONTACT, ""},
        new Object[] {new Class8(), WRONG_ADDRESS, ""},
        new Object[] {new Class8(), WRONG_DEPOSIT, "Invalid deposit number!"},
        new Object[] {new Class8(), WRONG_ORDER, ""},
        new Object[] {new Class10(), PERFECT_ORDER, ""},
        new Object[] {new Class10(), WRONG_NAME, ""},
        new Object[] {new Class10(), WRONG_CONTACT, ""},
        new Object[] {new Class10(), WRONG_ADDRESS, ""},
        new Object[] {new Class10(), WRONG_DEPOSIT, ""},
        new Object[] {new Class10(), WRONG_ORDER, "Invalid order!"});
  }

  @ParameterizedTest
  @MethodSource("getTestData")
  void testExecute(Class13 filter, Class1 order, String expectedResult) {
    final var result = filter.execute(order);
    assertNotNull(result);
    assertEquals(expectedResult, result.trim());
  }

  @ParameterizedTest
  @MethodSource("getTestData")
  void testNext(Class13 filter) {
    assertNull(filter.getNext());
    assertSame(filter, filter.getLast());
  }
}
