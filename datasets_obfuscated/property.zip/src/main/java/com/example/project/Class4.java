/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import com.example.project.Class3.Type;
import lombok.extern.slf4j.Slf4j;

/**
 * The Property pattern is also known as Class2 inheritance.
 *
 * <p>In prototype inheritance instead of classes, as opposite to Java class inheritance, objects
 * are used to create another objects and object hierarchies. Hierarchies are created using
 * prototype chain through delegation: every object has link to parent object. Any base (parent)
 * object can be amended at runtime (by adding or removal of some property), and all child objects
 * will be affected as result.
 *
 * <p>In this example we demonstrate {@link Class3} instantiation using the Property pattern.
 */
@Slf4j
public class Class4 {

  /**
   * Program entry point.
   *
   * @param args command line args
   */
  public static void main(String[] args) {
    /* set up */
    var charProto = new Class3();
    charProto.set(Class1.STRENGTH, 10);
    charProto.set(Class1.AGILITY, 10);
    charProto.set(Class1.ARMOR, 10);
    charProto.set(Class1.ATTACK_POWER, 10);

    var mageProto = new Class3(Type.MAGE, charProto);
    mageProto.set(Class1.INTELLECT, 15);
    mageProto.set(Class1.SPIRIT, 10);

    var warProto = new Class3(Type.WARRIOR, charProto);
    warProto.set(Class1.RAGE, 15);
    warProto.set(Class1.ARMOR, 15); // boost default armor for warrior

    var rogueProto = new Class3(Type.ROGUE, charProto);
    rogueProto.set(Class1.ENERGY, 15);
    rogueProto.set(Class1.AGILITY, 15); // boost default agility for rogue

    /* usage */
    var mag = new Class3("Player_1", mageProto);
    mag.set(Class1.ARMOR, 8);
    LOGGER.info(mag.toString());

    var warrior = new Class3("Player_2", warProto);
    LOGGER.info(warrior.toString());

    var rogue = new Class3("Player_3", rogueProto);
    LOGGER.info(rogue.toString());

    var rogueDouble = new Class3("Player_4", rogue);
    rogueDouble.set(Class1.ATTACK_POWER, 12);
    LOGGER.info(rogueDouble.toString());
  }
}
