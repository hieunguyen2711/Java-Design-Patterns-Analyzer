/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import java.util.HashMap;
import java.util.Map;

/** Represents Class3 in game and his abilities (base stats). */
public class Class3 implements Class2 {

  /** Enumeration of Class3 types. */
  public enum Type {
    WARRIOR,
    MAGE,
    ROGUE
  }

  private final Class2 prototype;
  private final Map<Class1, Integer> properties = new HashMap<>();

  private String name;
  private Type type;

  /** Constructor. */
  public Class3() {
    this.prototype =
        new Class2() { // Null-value object
          @Override
          public Integer get(Class1 stat) {
            return null;
          }

          @Override
          public boolean has(Class1 stat) {
            return false;
          }

          @Override
          public void set(Class1 stat, Integer val) {
            // Does Nothing
          }

          @Override
          public void remove(Class1 stat) {
            // Does Nothing.
          }
        };
  }

  public Class3(Type type, Class2 prototype) {
    this.type = type;
    this.prototype = prototype;
  }

  /** Constructor. */
  public Class3(String name, Class3 prototype) {
    this.name = name;
    this.type = prototype.type;
    this.prototype = prototype;
  }

  public String name() {
    return name;
  }

  public Type type() {
    return type;
  }

  @Override
  public Integer get(Class1 stat) {
    var containsValue = properties.containsKey(stat);
    if (containsValue) {
      return properties.get(stat);
    } else {
      return prototype.get(stat);
    }
  }

  @Override
  public boolean has(Class1 stat) {
    return get(stat) != null;
  }

  @Override
  public void set(Class1 stat, Integer val) {
    properties.put(stat, val);
  }

  @Override
  public void remove(Class1 stat) {
    properties.put(stat, null);
  }

  @Override
  public String toString() {
    var builder = new StringBuilder();
    if (name != null) {
      builder.append("Player: ").append(name).append('\n');
    }

    if (type != null) {
      builder.append("Class3 type: ").append(type.name()).append('\n');
    }

    builder.append("Class1:\n");
    for (var stat : Class1.values()) {
      var value = this.get(stat);
      if (value == null) {
        continue;
      }
      builder.append(" - ").append(stat.name()).append(':').append(value).append('\n');
    }
    return builder.toString();
  }
}
