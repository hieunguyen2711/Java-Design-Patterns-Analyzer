/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import static com.iluwatar.property.Class3.Type;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import org.junit.jupiter.api.Test;

/** Class5 */
class Class5 {

  @Test
  void testPrototypeStats() {
    final var prototype = new Class3();

    for (final var stat : Class1.values()) {
      assertFalse(prototype.has(stat));
      assertNull(prototype.get(stat));

      final var expectedValue = stat.ordinal();
      prototype.set(stat, expectedValue);
      assertTrue(prototype.has(stat));
      assertEquals(expectedValue, prototype.get(stat));

      prototype.remove(stat);
      assertFalse(prototype.has(stat));
      assertNull(prototype.get(stat));
    }
  }

  @Test
  void testCharacterStats() {
    final var prototype = new Class3();
    Arrays.stream(Class1.values()).forEach(stat -> prototype.set(stat, stat.ordinal()));

    final var mage = new Class3(Type.MAGE, prototype);
    for (final var stat : Class1.values()) {
      final var expectedValue = stat.ordinal();
      assertTrue(mage.has(stat));
      assertEquals(expectedValue, mage.get(stat));
    }
  }

  @Test
  void testToString() {
    final var prototype = new Class3();
    prototype.set(Class1.ARMOR, 1);
    prototype.set(Class1.AGILITY, 2);
    prototype.set(Class1.INTELLECT, 3);
    var message =
        """
            Class1:
             - AGILITY:2
             - ARMOR:1
             - INTELLECT:3
            """;
    assertEquals(message, prototype.toString());

    final var stupid = new Class3(Type.ROGUE, prototype);
    stupid.remove(Class1.INTELLECT);
    String expectedStupidString =
        """
            Class3 type: ROGUE
            Class1:
             - AGILITY:2
             - ARMOR:1
            """;
    assertEquals(expectedStupidString, stupid.toString());

    final var weak = new Class3("weak", prototype);
    weak.remove(Class1.ARMOR);
    String expectedWeakString =
        """
            Player: weak
            Class1:
             - AGILITY:2
             - INTELLECT:3
            """;
    assertEquals(expectedWeakString, weak.toString());
  }

  @Test
  void testName() {
    final var prototype = new Class3();
    prototype.set(Class1.ARMOR, 1);
    prototype.set(Class1.INTELLECT, 2);
    assertNull(prototype.name());

    final var stupid = new Class3(Type.ROGUE, prototype);
    stupid.remove(Class1.INTELLECT);
    assertNull(stupid.name());

    final var weak = new Class3("weak", prototype);
    weak.remove(Class1.ARMOR);
    assertEquals("weak", weak.name());
  }

  @Test
  void testType() {
    final var prototype = new Class3();
    prototype.set(Class1.ARMOR, 1);
    prototype.set(Class1.INTELLECT, 2);
    assertNull(prototype.type());

    final var stupid = new Class3(Type.ROGUE, prototype);
    stupid.remove(Class1.INTELLECT);
    assertEquals(Type.ROGUE, stupid.type());

    final var weak = new Class3("weak", prototype);
    weak.remove(Class1.ARMOR);
    assertNull(weak.type());
  }
}
