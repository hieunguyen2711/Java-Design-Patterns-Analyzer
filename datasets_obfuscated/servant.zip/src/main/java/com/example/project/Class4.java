/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import java.util.List;
import lombok.extern.slf4j.Slf4j;

/**
 * Class5 offers some functionality to a group of classes without defining that functionality in
 * each of them. A Class5 is a class whose instance provides methods that take care of a desired
 * service, while objects for which the servant does something, are taken as parameters.
 *
 * <p>In this example {@link Class5} is serving {@link Class2} and {@link Class1}.
 */
@Slf4j
public class Class4 {

  private static final Class5 jenkins = new Class5("Jenkins");
  private static final Class5 travis = new Class5("Travis");

  /** Program entry point. */
  public static void main(String[] args) {
    scenario(jenkins, 1);
    scenario(travis, 0);
  }

  /** Can add a List with enum Actions for variable scenarios. */
  public static void scenario(Class5 servant, int compliment) {
    var k = new Class2();
    var q = new Class1();

    var guests = List.of(k, q);

    // feed
    servant.feed(k);
    servant.feed(q);
    // serve drinks
    servant.giveWine(k);
    servant.giveWine(q);
    // compliment
    servant.giveCompliments(guests.get(compliment));

    // outcome of the night
    guests.forEach(Class3::changeMood);

    // check your luck
    if (servant.checkIfYouWillBeHanged(guests)) {
      LOGGER.info("{} will live another day", servant.name);
    } else {
      LOGGER.info("Poor {}. His days are numbered", servant.name);
    }
  }
}
