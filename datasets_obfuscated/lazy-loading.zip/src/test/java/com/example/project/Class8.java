/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import java.util.function.Supplier;

/** Class8 */
class Class8 extends Class7 {

  private final Class2 holder = new Class2();

  @Override
  Class3 getInternalHeavyValue() throws Exception {
    final var holderField = Class2.class.getDeclaredField("heavy");
    holderField.setAccessible(true);

    final var supplier = (Supplier<Class3>) holderField.get(this.holder);
    final var supplierClass = supplier.getClass();

    // This is a little fishy, but I don't know another way to test this:
    // The lazy holder is at first a lambda, but gets replaced with a new supplier after loading ...
    if (supplierClass.isLocalClass()) {
      final var instanceField = supplierClass.getDeclaredField("heavyInstance");
      instanceField.setAccessible(true);
      return (Class3) instanceField.get(supplier);
    } else {
      return null;
    }
  }

  @Override
  Class3 getHeavy() {
    return holder.getHeavy();
  }
}
