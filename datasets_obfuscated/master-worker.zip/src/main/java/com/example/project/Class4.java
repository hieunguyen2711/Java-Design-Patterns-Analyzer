/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import com.example.project.system.Class7;
import com.example.project.system.Class8;
import com.example.project.system.systemmaster.Class12;
import com.example.project.system.systemmaster.Class11;
import com.example.project.system.systemworkers.Class9;
import com.example.project.system.systemworkers.Class10;
import lombok.extern.slf4j.Slf4j;

/**
 * The <b><em>Class11-Class10</em></b> pattern is used when the problem at hand can be solved by
 * dividing into multiple parts which need to go through the same computation and may need to be
 * aggregated to get final result. Parallel processing is performed using a system consisting of a
 * master and some number of workers, where a master divides the work among the workers, gets the
 * result back from them and assimilates all the results to give final result. The only
 * communication is between the master and the worker - none of the workers communicate among one
 * another and the user only communicates with the master to get required job done.
 *
 * <p>In our example, we have generic abstract classes {@link Class8}, {@link Class11} and
 * {@link Class10} which have to be extended by the classes which will perform the specific job at
 * hand (in this case finding transpose of matrix, done by {@link Class7},
 * {@link Class12} and {@link Class9}). The Class11 class divides the work
 * into parts to be given to the workers, collects the results from the workers and aggregates it
 * when all workers have responded before returning the solution. The Class10 class extends the
 * Thread class to enable parallel processing, and does the work once the data has been received
 * from the Class11. The Class8 contains a reference to the Class11 class, gets the input from
 * the Class4 and passes it on to the Class11. These 3 classes define the system which computes the
 * result. We also have 2 abstract classes {@link Class3} and {@link Class6}, which contain the input
 * data and result data respectively. The Class3 class also has an abstract method divideData which
 * defines how the data is to be divided into segments. These classes are extended by {@link
 * Class2} and {@link Class1}.
 */
@Slf4j
public class Class4 {

  /**
   * Program entry point.
   *
   * @param args command line args
   */
  public static void main(String[] args) {
    var mw = new Class7();
    var rows = 10;
    var columns = 20;
    var inputMatrix = Class5.createRandomIntMatrix(rows, columns);
    var input = new Class2(inputMatrix);
    var result = (Class1) mw.getResult(input);
    if (result != null) {
      Class5.printMatrix(inputMatrix);
      Class5.printMatrix(result.data);
    } else {
      LOGGER.info("Please enter non-zero input");
    }
  }
}
