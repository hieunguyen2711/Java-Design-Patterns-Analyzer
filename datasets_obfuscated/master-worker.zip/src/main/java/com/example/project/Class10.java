/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.masterworker.system.systemworkers;

import com.example.project.Class3;
import com.example.project.Class6;
import com.example.project.system.systemmaster.Class11;
import lombok.Getter;

/**
 * The abstract Class10 class which extends Thread class to enable parallel processing. Contains
 * fields master(holding reference to master), workerId (unique id) and receivedData(from master).
 */
public abstract class Class10 extends Thread {
  private final Class11 master;
  @Getter private final int workerId;
  private Class3<?> receivedData;

  Class10(Class11 master, int id) {
    this.master = master;
    this.workerId = id;
    this.receivedData = null;
  }

  Class3<?> getReceivedData() {
    return this.receivedData;
  }

  public void setReceivedData(Class11 m, Class3<?> i) {
    // check if we are ready to receive... if yes:
    this.receivedData = i;
  }

  abstract Class6<?> executeOperation();

  private void sendToMaster(Class6<?> data) {
    this.master.receiveData(data, this);
  }

  public void run() { // from Thread class
    var work = executeOperation();
    sendToMaster(work);
  }
}
