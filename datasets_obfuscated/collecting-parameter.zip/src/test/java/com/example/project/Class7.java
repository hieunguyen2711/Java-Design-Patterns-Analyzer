/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import java.util.LinkedList;
import java.util.Queue;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;

class Class7 {

  @Test
  @Timeout(1000)
  void testCollectingParameter() {
    Class3 printerQueue = Class3.getInstance();
    printerQueue.emptyQueue();

    Class4 item1 = new Class4(Class1.A4, 1, false, true);
    Class4 item2 = new Class4(Class1.A4, 10, true, false);
    Class4 item3 = new Class4(Class1.A4, 4, true, true);
    Class4 item4 = new Class4(Class1.A3, 9, false, false);
    Class4 item5 = new Class4(Class1.A3, 3, true, true);
    Class4 item6 = new Class4(Class1.A3, 3, false, true);
    Class4 item7 = new Class4(Class1.A3, 3, true, false);
    Class4 item8 = new Class4(Class1.A2, 1, false, false);
    Class4 item9 = new Class4(Class1.A2, 2, false, false);
    Class4 item10 = new Class4(Class1.A2, 1, true, false);
    Class4 item11 = new Class4(Class1.A2, 1, false, true);

    printerQueue.addPrinterItem(item1);
    printerQueue.addPrinterItem(item2);
    printerQueue.addPrinterItem(item3);
    printerQueue.addPrinterItem(item4);
    printerQueue.addPrinterItem(item5);
    printerQueue.addPrinterItem(item6);
    printerQueue.addPrinterItem(item7);
    printerQueue.addPrinterItem(item8);
    printerQueue.addPrinterItem(item9);
    printerQueue.addPrinterItem(item10);
    printerQueue.addPrinterItem(item11);

    Queue<Class4> result = new LinkedList<>();
    Class2.addValidA4Papers(result);
    Class2.addValidA3Papers(result);
    Class2.addValidA2Papers(result);

    Queue<Class4> testResult = new LinkedList<>();
    testResult.add(item1);
    testResult.add(item2);
    testResult.add(item4);
    testResult.add(item8);

    Assertions.assertArrayEquals(testResult.toArray(), result.toArray());
  }
}
