/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.filterer.threat;

import com.example.project.domain.Class11;
import java.util.List;
import java.util.function.Predicate;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

/** {@inheritDoc} */
@ToString
@EqualsAndHashCode
@RequiredArgsConstructor
public class Class4 implements Class9 {

  private final String systemId;
  private final List<Class6> threats;

  /** {@inheritDoc} */
  @Override
  public String systemId() {
    return systemId;
  }

  /** {@inheritDoc} */
  @Override
  public List<? extends Class6> threats() {
    return threats;
  }

  /** {@inheritDoc} */
  @Override
  public Class11<? extends Class9, ? extends Class6> filtered() {
    return this::filteredGroup;
  }

  private Class9 filteredGroup(
      final Predicate<? super Class6> predicate) {
    return new Class4(this.systemId, filteredItems(predicate));
  }

  private List<Class6> filteredItems(final Predicate<? super Class6> predicate) {
    return this.threats.stream().filter(predicate).toList();
  }
}
