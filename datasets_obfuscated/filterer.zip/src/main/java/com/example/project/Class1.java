/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import com.example.project.threat.Class6;
import com.example.project.threat.Class4;
import com.example.project.threat.Class2;
import com.example.project.threat.Class7;
import com.example.project.threat.Class8;
import com.example.project.threat.Class5;
import com.example.project.threat.Class3;
import com.example.project.threat.Class10;
import java.util.List;
import java.util.function.Predicate;
import lombok.extern.slf4j.Slf4j;

/**
 * This demo class represent how {@link com.iluwatar.filterer.domain.Class11} pattern is used to
 * filter container-like objects to return filtered versions of themselves. The container like
 * objects are systems that are aware of threats that they can be vulnerable to. We would like to
 * have a way to create copy of different system objects but with filtered threats. The thing is to
 * keep it simple if we add new subtype of {@link Class5} (for example {@link Class6}) - we
 * still need to be able to filter by its properties.
 */
@Slf4j
public class Class1 {

  public static void main(String[] args) {
    filteringSimpleThreats();
    filteringSimpleProbableThreats();
  }

  /**
   * Demonstrates how to filter {@link com.iluwatar.filterer.threat.Class9}
   * based on probability property. The @{@link com.iluwatar.filterer.domain.Class11#by(Predicate)}
   * method is able to use {@link com.iluwatar.filterer.threat.Class6} as predicate
   * argument.
   */
  private static void filteringSimpleProbableThreats() {
    LOGGER.info("### Filtering Class9 by probability ###");

    var trojanArcBomb = new Class2("Trojan-ArcBomb", 1, Class10.TROJAN, 0.99);
    var rootkit = new Class2("Rootkit-Kernel", 2, Class10.ROOTKIT, 0.8);

    List<Class6> probableThreats = List.of(trojanArcBomb, rootkit);

    var probabilisticThreatAwareSystem =
        new Class4("Sys-1", probableThreats);

    LOGGER.info(
        "Filtering Class9. Initial : " + probabilisticThreatAwareSystem);

    // Filtering using filterer
    var filteredThreatAwareSystem =
        probabilisticThreatAwareSystem
            .filtered()
            .by(probableThreat -> Double.compare(probableThreat.probability(), 0.99) == 0);

    LOGGER.info("Filtered by probability = 0.99 : " + filteredThreatAwareSystem);
  }

  /**
   * Demonstrates how to filter {@link Class3} based on startingOffset property of {@link
   * Class7}. The @{@link com.iluwatar.filterer.domain.Class11#by(Predicate)} method is able
   * to use {@link Class5} as predicate argument.
   */
  private static void filteringSimpleThreats() {
    LOGGER.info("### Filtering Class3 by Class10 ###");

    var rootkit = new Class7(Class10.ROOTKIT, 1, "Simple-Rootkit");
    var trojan = new Class7(Class10.TROJAN, 2, "Simple-Trojan");
    List<Class5> threats = List.of(rootkit, trojan);

    var threatAwareSystem = new Class8("Sys-1", threats);

    LOGGER.info("Filtering Class3. Initial : " + threatAwareSystem);

    // Filtering using Class11
    var rootkitThreatAwareSystem =
        threatAwareSystem.filtered().by(threat -> threat.type() == Class10.ROOTKIT);

    LOGGER.info("Filtered by threatType = ROOTKIT : " + rootkitThreatAwareSystem);
  }
}
