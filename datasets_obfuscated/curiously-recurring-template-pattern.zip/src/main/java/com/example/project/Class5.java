/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import lombok.extern.slf4j.Slf4j;

/**
 * Shows the {@link Class3} fight method call on some implementations of {@link Class2}. Note
 * that fighters can only fight against opponents of their same weight class.
 */
@Slf4j
public class Class5 {

  /**
   * Program entry point.
   *
   * @param args command line args
   */
  public static void main(String[] args) {

    Class4 fighter1 =
        new Class4("Joe", "Johnson", "The Geek", "Muay Thai");
    Class4 fighter2 =
        new Class4("Ed", "Edwards", "The Problem Solver", "Judo");
    fighter1.fight(fighter2);

    Class1 fighter3 =
        new Class1("Dave", "Davidson", "The Bug Smasher", "Kickboxing");
    Class1 fighter4 =
        new Class1("Jack", "Jackson", "The Pragmatic", "Brazilian Jiu-Jitsu");
    fighter3.fight(fighter4);
  }
}
