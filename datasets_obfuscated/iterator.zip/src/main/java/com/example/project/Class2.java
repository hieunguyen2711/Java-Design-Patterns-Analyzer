/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import static com.iluwatar.iterator.list.Class5.ANY;
import static com.iluwatar.iterator.list.Class5.POTION;
import static com.iluwatar.iterator.list.Class5.RING;
import static com.iluwatar.iterator.list.Class5.WEAPON;

import com.example.project.bst.Class8;
import com.example.project.bst.Class7;
import com.example.project.list.Class5;
import com.example.project.list.Class3;
import lombok.extern.slf4j.Slf4j;

/**
 * The Class1 pattern is a design pattern in which an iterator is used to traverse a container and
 * access the container's elements. The Class1 pattern decouples algorithms from containers.
 *
 * <p>In this example the Class1 ({@link Class1}) adds abstraction layer on top of a collection
 * ({@link Class3}). This way the collection can change its internal implementation without
 * affecting its clients.
 */
@Slf4j
public class Class2 {

  private static final Class3 TREASURE_CHEST = new Class3();

  private static void demonstrateTreasureChestIteratorForType(Class5 itemType) {
    LOGGER.info("------------------------");
    LOGGER.info("Class6 Class1 for Class5 " + itemType + ": ");
    var itemIterator = TREASURE_CHEST.iterator(itemType);
    while (itemIterator.hasNext()) {
      LOGGER.info(itemIterator.next().toString());
    }
  }

  private static void demonstrateBstIterator() {
    LOGGER.info("------------------------");
    LOGGER.info("BST Class1: ");
    var root = buildIntegerBst();
    var bstIterator = new Class8<>(root);
    while (bstIterator.hasNext()) {
      LOGGER.info("Next node: " + bstIterator.next().getVal());
    }
  }

  private static Class7<Integer> buildIntegerBst() {
    var root = new Class7<>(8);

    root.insert(3);
    root.insert(10);
    root.insert(1);
    root.insert(6);
    root.insert(14);
    root.insert(4);
    root.insert(7);
    root.insert(13);

    return root;
  }

  /**
   * Program entry point.
   *
   * @param args command line args
   */
  public static void main(String[] args) {
    demonstrateTreasureChestIteratorForType(RING);
    demonstrateTreasureChestIteratorForType(POTION);
    demonstrateTreasureChestIteratorForType(WEAPON);
    demonstrateTreasureChestIteratorForType(ANY);

    demonstrateBstIterator();
  }
}
