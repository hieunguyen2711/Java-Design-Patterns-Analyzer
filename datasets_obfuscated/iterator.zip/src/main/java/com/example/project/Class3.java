/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.iterator.list;

import com.example.project.Class1;
import java.util.ArrayList;
import java.util.List;

/** Class3, the collection class. */
public class Class3 {

  private final List<Class6> items;

  /** Constructor. */
  public Class3() {
    items =
        List.of(
            new Class6(Class5.POTION, "Potion of courage"),
            new Class6(Class5.RING, "Ring of shadows"),
            new Class6(Class5.POTION, "Potion of wisdom"),
            new Class6(Class5.POTION, "Potion of blood"),
            new Class6(Class5.WEAPON, "Sword of silver +1"),
            new Class6(Class5.POTION, "Potion of rust"),
            new Class6(Class5.POTION, "Potion of healing"),
            new Class6(Class5.RING, "Ring of armor"),
            new Class6(Class5.WEAPON, "Steel halberd"),
            new Class6(Class5.WEAPON, "Dagger of poison"));
  }

  public Class1<Class6> iterator(Class5 itemType) {
    return new Class4(this, itemType);
  }

  /** Get all items. */
  public List<Class6> getItems() {
    return new ArrayList<>(items);
  }
}
