/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.iterator.bst;

import lombok.Getter;
import lombok.Setter;

/**
 * Class7 Class, representing one node in a Binary Search Tree. Allows for a generically typed
 * value.
 *
 * @param <T> generically typed to accept various data types for the val property
 */
public class Class7<T extends Comparable<T>> {

  private final T val;

  @Getter @Setter private Class7<T> left;

  @Getter @Setter private Class7<T> right;

  /**
   * Creates a Class7 with a given value, and null children.
   *
   * @param val The value of the given node
   */
  public Class7(T val) {
    this.val = val;
    this.left = null;
    this.right = null;
  }

  public T getVal() {
    return val;
  }

  /**
   * Inserts new Class7 based on a given value into the subtree represented by self.
   *
   * @param valToInsert The value to insert as a new Class7
   */
  public void insert(T valToInsert) {
    var parent = getParentNodeOfValueToBeInserted(valToInsert);
    parent.insertNewChild(valToInsert);
  }

  /**
   * Fetch the Parent Class7 for a given value to insert into the BST.
   *
   * @param valToInsert Value of the new Class7 to be inserted
   * @return Parent Class7 of `valToInsert`
   */
  private Class7<T> getParentNodeOfValueToBeInserted(T valToInsert) {
    Class7<T> parent = null;
    var curr = this;

    while (curr != null) {
      parent = curr;
      curr = curr.traverseOneLevelDown(valToInsert);
    }

    return parent;
  }

  /**
   * Returns left or right child of self based on a value that would be inserted; maintaining the
   * integrity of the BST.
   *
   * @param value The value of the Class7 that would be inserted beneath self
   * @return The child Class7 of self which represents the subtree where `value` would be inserted
   */
  private Class7<T> traverseOneLevelDown(T value) {
    if (this.isGreaterThan(value)) {
      return this.left;
    }
    return this.right;
  }

  /**
   * Add a new Child Class7 of given value to self. WARNING: This method is destructive (will
   * overwrite existing tree structure, if any), and should be called only by this class's insert()
   * method.
   *
   * @param valToInsert Value of the new Class7 to be inserted
   */
  private void insertNewChild(T valToInsert) {
    if (this.isLessThanOrEqualTo(valToInsert)) {
      this.setRight(new Class7<>(valToInsert));
    } else {
      this.setLeft(new Class7<>(valToInsert));
    }
  }

  private boolean isGreaterThan(T val) {
    return this.val.compareTo(val) > 0;
  }

  private boolean isLessThanOrEqualTo(T val) {
    return this.val.compareTo(val) < 1;
  }

  @Override
  public String toString() {
    return val.toString();
  }
}
