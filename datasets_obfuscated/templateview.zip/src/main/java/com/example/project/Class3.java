/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import lombok.extern.slf4j.Slf4j;

/**
 * Template View defines a consistent layout for rendering views, delegating dynamic content
 * rendering to subclasses.
 *
 * <p>In this example, the {@link Class1} class provides the skeleton for rendering views with
 * a header, dynamic content, and a footer. Subclasses {@link Class2} and {@link
 * Class4} define the specific dynamic content for their respective views.
 *
 * <p>The {@link Class3} class demonstrates the usage of the Template View Pattern by rendering
 * instances of {@link Class2} and {@link Class4}.
 */
@Slf4j
public class Class3 {

  /**
   * Program entry point.
   *
   * @param args command line args
   */
  public static void main(String[] args) {
    // Create and render the Class2
    Class1 homePage = new Class2();
    LOGGER.info("Rendering HomePage:");
    homePage.render();

    // Create and render the Class4
    Class1 contactPage = new Class4();
    LOGGER.info("\nRendering ContactPage:");
    contactPage.render();
  }
}
