/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.CommandLineRunner;

/** Application test */
class Class9 {

  @Test
  void testMain() {
    assertDoesNotThrow(() -> Class5.main(new String[] {}));
  }

  @Test
  void testRun() throws Exception {
    Class3 requestService = Mockito.mock(Class3.class);
    Class2 requestRepository = Mockito.mock(Class2.class);
    UUID uuid = UUID.randomUUID();
    Class7 requestPending = new Class7(uuid);
    Class7 requestStarted = new Class7(uuid, Class7.Status.STARTED);
    Class7 requestCompleted = new Class7(uuid, Class7.Status.COMPLETED);
    when(requestService.create(any())).thenReturn(requestPending);
    when(requestService.start(any())).thenReturn(requestStarted);
    when(requestService.complete(any())).thenReturn(requestCompleted);

    CommandLineRunner runner = new Class5().run(requestService, requestRepository);

    runner.run();

    verify(requestService, times(3)).create(any());
    verify(requestService, times(2)).start(any());
    verify(requestService, times(1)).complete(any());
    verify(requestRepository, times(1)).count();
  }
}
