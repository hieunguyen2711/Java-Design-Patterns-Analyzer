/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class Class8 {
  private Class6 requestStateMachine;

  @BeforeEach
  void setUp() {
    requestStateMachine = new Class6();
  }

  @Test
  void transitionPendingToStarted() {
    Class7 startedRequest =
        requestStateMachine.next(
            new Class7(UUID.randomUUID(), Class7.Status.PENDING), Class7.Status.STARTED);
    assertEquals(Class7.Status.STARTED, startedRequest.getStatus());
  }

  @Test
  void transitionAnyToPending_shouldThrowError() {
    assertThrows(
        Class1.class,
        () ->
            requestStateMachine.next(
                new Class7(UUID.randomUUID(), Class7.Status.PENDING), Class7.Status.PENDING));
    assertThrows(
        Class1.class,
        () ->
            requestStateMachine.next(
                new Class7(UUID.randomUUID(), Class7.Status.STARTED), Class7.Status.PENDING));
    assertThrows(
        Class1.class,
        () ->
            requestStateMachine.next(
                new Class7(UUID.randomUUID(), Class7.Status.COMPLETED), Class7.Status.PENDING));
  }

  @Test
  void transitionCompletedToAny_shouldThrowError() {
    assertThrows(
        Class1.class,
        () ->
            requestStateMachine.next(
                new Class7(UUID.randomUUID(), Class7.Status.COMPLETED), Class7.Status.PENDING));
    assertThrows(
        Class1.class,
        () ->
            requestStateMachine.next(
                new Class7(UUID.randomUUID(), Class7.Status.COMPLETED), Class7.Status.STARTED));
    assertThrows(
        Class1.class,
        () ->
            requestStateMachine.next(
                new Class7(UUID.randomUUID(), Class7.Status.COMPLETED),
                Class7.Status.COMPLETED));
  }

  @Test
  void transitionStartedToCompleted() {
    Class7 completedRequest =
        requestStateMachine.next(
            new Class7(UUID.randomUUID(), Class7.Status.STARTED), Class7.Status.COMPLETED);
    assertEquals(Class7.Status.COMPLETED, completedRequest.getStatus());
  }
}
