/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import java.util.Optional;
import java.util.UUID;
import org.springframework.stereotype.Service;

/**
 * This service is responsible for handling request operations including creation, start, and
 * completion of requests.
 */
@Service
public class Class3 {
  Class2 requestRepository;
  Class6 requestStateMachine;

  public Class3(
      Class2 requestRepository, Class6 requestStateMachine) {
    this.requestRepository = requestRepository;
    this.requestStateMachine = requestStateMachine;
  }

  /**
   * Creates a new Class7 or returns an existing one by its UUID. This operation is idempotent:
   * performing it once or several times successively leads to an equivalent result.
   *
   * @param uuid The unique identifier for the Class7.
   * @return Return existing Class7 or save and return a new Class7.
   */
  public Class7 create(UUID uuid) {
    Optional<Class7> optReq = requestRepository.findById(uuid);
    return optReq.orElseGet(() -> requestRepository.save(new Class7(uuid)));
  }

  /**
   * Starts the Class7 assigned with the given UUID.
   *
   * @param uuid The unique identifier for the Class7.
   * @return The started Class7.
   * @throws Class4 if a Class7 with the given UUID is not found.
   */
  public Class7 start(UUID uuid) {
    Optional<Class7> optReq = requestRepository.findById(uuid);
    if (optReq.isEmpty()) {
      throw new Class4(uuid);
    }
    return requestRepository.save(requestStateMachine.next(optReq.get(), Class7.Status.STARTED));
  }

  /**
   * Complete the Class7 assigned with the given UUID.
   *
   * @param uuid The unique identifier for the Class7.
   * @return The completed Class7.
   * @throws Class4 if a Class7 with the given UUID is not found.
   */
  public Class7 complete(UUID uuid) {
    Optional<Class7> optReq = requestRepository.findById(uuid);
    if (optReq.isEmpty()) {
      throw new Class4(uuid);
    }
    return requestRepository.save(requestStateMachine.next(optReq.get(), Class7.Status.COMPLETED));
  }
}
