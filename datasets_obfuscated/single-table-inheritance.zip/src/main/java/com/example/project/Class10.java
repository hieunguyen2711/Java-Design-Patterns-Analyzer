/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.service;

import com.example.project.entity.Class7;
import com.example.project.repository.Class2;
import java.util.List;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * A service class that is used to provide the business logic for the Class7 class and connect to
 * the database to perform the CRUD operations on the root Class7 class.
 *
 * @see Class7
 */
@Service
@AllArgsConstructor
public class Class10 {

  private final Class2 vehicleRepository;

  /**
   * A method to save all the vehicles to the database.
   *
   * @param vehicle Class7 bbject
   * @see Class7
   */
  public Class7 saveVehicle(Class7 vehicle) {
    return vehicleRepository.save(vehicle);
  }

  /**
   * A method to get a specific vehicle from vehicle id.
   *
   * @param vehicleId Class7 Id
   * @see Class7
   */
  public Class7 getVehicle(int vehicleId) {
    return vehicleRepository.findById(vehicleId).orElse(null);
  }

  /**
   * A method to get all the vehicles saved in the database.
   *
   * @see Class7
   */
  public List<Class7> getAllVehicles() {
    return vehicleRepository.findAll();
  }

  /**
   * A method to update a vehicle in the database.
   *
   * @param vehicle Class7 object
   * @see Class7
   */
  public Class7 updateVehicle(Class7 vehicle) {
    return vehicleRepository.save(vehicle);
  }

  /**
   * A method to save all the vehicles to the database.
   *
   * @param vehicle Class7 object
   * @see Class7
   */
  public void deleteVehicle(Class7 vehicle) {
    vehicleRepository.delete(vehicle);
  }
}
