/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import com.example.project.lob.Class3;
import com.example.project.lob.Class4;
import com.example.project.lob.Class2;
import com.example.project.serializers.Class5;
import com.example.project.serializers.Class6;
import com.example.project.serializers.Class7;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Collections;
import java.util.Objects;
import java.util.Set;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXException;

/** SLOB Application using {@link Class7} and H2 DB. */
public class Class1 {

  public static final String CLOB = "CLOB";
  private static final Logger LOGGER = LoggerFactory.getLogger(Class1.class);

  /**
   * Main entry point to program.
   *
   * <p>In the SLOB pattern, the object graph is serialized into a single large object (a BLOB or
   * CLOB, for Binary Large Object or Character Large Object, respectively) and stored in the
   * database. When the object graph needs to be retrieved, it is read from the database and
   * deserialized back into the original object graph.
   *
   * <p>A Class4 is created using {@link #createForest()} with Animals and Plants along with their
   * respective relationships.
   *
   * <p>Creates a {@link Class7} using the method {@link #createLobSerializer(String[])}.
   *
   * <p>Once created the serializer is passed to the {@link #executeSerializer(Class4,
   * Class7)} which handles the serialization, deserialization and persisting and loading
   * from DB.
   *
   * @param args if first arg is CLOB then Class6 is used else Class5 is used.
   */
  public static void main(String[] args) throws SQLException {
    Class4 forest = createForest();
    Class7 serializer = createLobSerializer(args);
    executeSerializer(forest, serializer);
  }

  /**
   * Creates a {@link Class7} on the basis of input args.
   *
   * <p>If input args are not empty and the value equals {@link Class1#CLOB} then a {@link
   * Class6} is created else a {@link Class5} is created.
   *
   * @param args if first arg is {@link Class1#CLOB} then Class6 is instantiated else
   *     Class5 is instantiated.
   */
  private static Class7 createLobSerializer(String[] args) throws SQLException {
    Class7 serializer;
    if (args.length > 0 && Objects.equals(args[0], CLOB)) {
      serializer = new Class6();
    } else {
      serializer = new Class5();
    }
    return serializer;
  }

  /**
   * Creates a Class4 with {@link Class3} and {@link Class2} along with their respective
   * relationships.
   *
   * <p>The method creates a {@link Class4} with 2 Plants Grass and Oak of type Herb and tree
   * respectively.
   *
   * <p>It also creates 3 animals Zebra and Buffalo which eat the plant grass. Lion consumes the
   * Zebra and the Buffalo.
   *
   * <p>With the above animals and plants and their relationships a forest object is created which
   * represents the Object Graph.
   *
   * @return Class4 Object
   */
  private static Class4 createForest() {
    Class2 grass = new Class2("Grass", "Herb");
    Class2 oak = new Class2("Oak", "Tree");

    Class3 zebra = new Class3("Zebra", Set.of(grass), Collections.emptySet());
    Class3 buffalo = new Class3("Buffalo", Set.of(grass), Collections.emptySet());
    Class3 lion = new Class3("Lion", Collections.emptySet(), Set.of(zebra, buffalo));

    return new Class4("Amazon", Set.of(lion, buffalo, zebra), Set.of(grass, oak));
  }

  /**
   * Serialize the input object using the input serializer and persist to DB. After this it loads
   * the same object back from DB and deserializes using the same serializer.
   *
   * @param forest Object to Serialize and Persist
   * @param lobSerializer Serializer to Serialize and Deserialize Object
   */
  private static void executeSerializer(Class4 forest, Class7 lobSerializer) {
    try (Class7 serializer = lobSerializer) {

      Object serialized = serializer.serialize(forest);
      int id = serializer.persistToDb(1, forest.getName(), serialized);

      Object fromDb = serializer.loadFromDb(id, Class4.class.getSimpleName());
      Class4 forestFromDb = serializer.deSerialize(fromDb);

      LOGGER.info(forestFromDb.toString());
    } catch (SQLException
        | IOException
        | TransformerException
        | ParserConfigurationException
        | SAXException
        | ClassNotFoundException e) {
      throw new RuntimeException(e);
    }
  }
}
