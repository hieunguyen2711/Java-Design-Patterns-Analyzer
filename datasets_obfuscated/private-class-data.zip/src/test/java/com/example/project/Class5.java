/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.example.project.utils.Class8;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/** Class5 */
class Class5 {

  private Class8 appender;

  @BeforeEach
  void setUp() {
    appender = new Class8();
  }

  @AfterEach
  void tearDown() {
    appender.stop();
  }

  /** Verify if mixing the stew doesn't change the internal state */
  @Test
  void testMix() {
    var stew = new Class3(1, 2, 3, 4);
    var expectedMessage = "Mixing the stew we find: 1 potatoes, 2 carrots, 3 meat and 4 peppers";

    for (var i = 0; i < 20; i++) {
      stew.mix();
      assertEquals(expectedMessage, appender.getLastMessage());
    }

    assertEquals(20, appender.getLogSize());
  }

  /** Verify if tasting the stew actually removes one of each ingredient */
  @Test
  void testDrink() {
    final var stew = new Class3(1, 2, 3, 4);
    stew.mix();

    assertEquals(
        "Mixing the stew we find: 1 potatoes, 2 carrots, 3 meat and 4 peppers",
        appender.getLastMessage());

    stew.taste();
    assertEquals("Tasting the stew", appender.getLastMessage());

    stew.mix();
    assertEquals(
        "Mixing the stew we find: 0 potatoes, 1 carrots, 2 meat and 3 peppers",
        appender.getLastMessage());
  }
}
