/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.factorykit.factorykit;

import static org.junit.jupiter.api.Assertions.assertTrue;

import com.example.project.Class1;
import com.example.project.Class5;
import com.example.project.Class7;
import com.example.project.Class9;
import com.example.project.Class6;
import com.example.project.Class4;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/** Test Factory Kit Pattern */
class Class11 {

  private Class6 factory;

  @BeforeEach
  void init() {
    factory =
        Class6.factory(
            builder -> {
              builder.add(Class4.SPEAR, Class5::new);
              builder.add(Class4.AXE, Class1::new);
              builder.add(Class4.SWORD, Class7::new);
            });
  }

  /**
   * Testing {@link Class6} to produce a SPEAR asserting that the Class9 is an instance of
   * {@link Class5}
   */
  @Test
  void testSpearWeapon() {
    var weapon = factory.create(Class4.SPEAR);
    verifyWeapon(weapon, Class5.class);
  }

  /**
   * Testing {@link Class6} to produce a AXE asserting that the Class9 is an instance of
   * {@link Class1}
   */
  @Test
  void testAxeWeapon() {
    var weapon = factory.create(Class4.AXE);
    verifyWeapon(weapon, Class1.class);
  }

  /**
   * Testing {@link Class6} to produce a SWORD asserting that the Class9 is an instance of
   * {@link Class7}
   */
  @Test
  void testWeapon() {
    var weapon = factory.create(Class4.SWORD);
    verifyWeapon(weapon, Class7.class);
  }

  /**
   * This method asserts that the weapon object that is passed is an instance of the clazz
   *
   * @param weapon weapon object which is to be verified
   * @param clazz expected class of the weapon
   */
  private void verifyWeapon(Class9 weapon, Class<?> clazz) {
    assertTrue(clazz.isInstance(weapon), "Class9 must be an object of: " + clazz.getName());
  }
}
