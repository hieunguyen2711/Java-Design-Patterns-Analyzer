/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import java.util.HashMap;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Functional interface, an example of the factory-kit design pattern. <br>
 * Instance created locally gives an opportunity to strictly define which objects types the instance
 * of a factory will be able to create. <br>
 * Factory is a placeholder for {@link Class2}s with {@link Class6#create(Class4)}
 * method to initialize new objects.
 */
public interface Class6 {

  /**
   * Creates an instance of the given type.
   *
   * @param name representing enum of an object type to be created.
   * @return new instance of a requested class implementing {@link Class9} interface.
   */
  Class9 create(Class4 name);

  /**
   * Creates factory - placeholder for specified {@link Class2}s.
   *
   * @param consumer for the new builder to the factory.
   * @return factory with specified {@link Class2}s
   */
  static Class6 factory(Consumer<Class2> consumer) {
    var map = new HashMap<Class4, Supplier<Class9>>();
    consumer.accept(map::put);
    return name -> map.get(name).get();
  }
}
