/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import java.util.List;

/** Class5. */
public class Class5 {

  Class2 messageFromOrcs() {

    var words =
        List.of(
            new Class3('W', 'h', 'e', 'r', 'e'),
            new Class3('t', 'h', 'e', 'r', 'e'),
            new Class3('i', 's'),
            new Class3('a'),
            new Class3('w', 'h', 'i', 'p'),
            new Class3('t', 'h', 'e', 'r', 'e'),
            new Class3('i', 's'),
            new Class3('a'),
            new Class3('w', 'a', 'y'));

    return new Class4(words);
  }

  Class2 messageFromElves() {

    var words =
        List.of(
            new Class3('M', 'u', 'c', 'h'),
            new Class3('w', 'i', 'n', 'd'),
            new Class3('p', 'o', 'u', 'r', 's'),
            new Class3('f', 'r', 'o', 'm'),
            new Class3('y', 'o', 'u', 'r'),
            new Class3('m', 'o', 'u', 't', 'h'));

    return new Class4(words);
  }
}
