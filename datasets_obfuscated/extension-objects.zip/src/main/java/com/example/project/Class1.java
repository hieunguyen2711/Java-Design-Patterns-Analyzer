/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
import com.example.project.Class2;
import com.example.project.Class4;
import com.example.project.Class5;
import java.util.Optional;
import java.util.function.Function;
import org.slf4j.LoggerFactory;
import units.Class11;
import units.Class9;
import units.Class12;
import units.Class10;

/**
 * Anticipate that an object’s interface needs to be extended in the future. Additional interfaces
 * are defined by extension objects.
 */
public class Class1 {

  /**
   * Program entry point.
   *
   * @param args command line args
   */
  public static void main(String[] args) {

    // Create 3 different units
    var soldierUnit = new Class12("SoldierUnit1");
    var sergeantUnit = new Class9("SergeantUnit1");
    var commanderUnit = new Class11("CommanderUnit1");

    // check for each unit to have an extension
    checkExtensionsForUnit(soldierUnit);
    checkExtensionsForUnit(sergeantUnit);
    checkExtensionsForUnit(commanderUnit);
  }

  private static void checkExtensionsForUnit(Class10 unit) {
    final var logger = LoggerFactory.getLogger(Class1.class);

    var name = unit.getName();
    Function<String, Runnable> func = e -> () -> logger.info("{} without {}", name, e);

    var extension = "Class5";
    Optional.ofNullable(unit.getUnitExtension(extension))
        .map(e -> (Class5) e)
        .ifPresentOrElse(Class5::soldierReady, func.apply(extension));

    extension = "Class4";
    Optional.ofNullable(unit.getUnitExtension(extension))
        .map(e -> (Class4) e)
        .ifPresentOrElse(Class4::sergeantReady, func.apply(extension));

    extension = "Class2";
    Optional.ofNullable(unit.getUnitExtension(extension))
        .map(e -> (Class2) e)
        .ifPresentOrElse(Class2::commanderReady, func.apply(extension));
  }
}
