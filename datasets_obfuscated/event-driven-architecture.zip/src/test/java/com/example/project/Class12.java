/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.eda.framework;

import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;

import com.example.project.event.Class10;
import com.example.project.event.Class9;
import com.example.project.handler.Class3;
import com.example.project.handler.Class2;
import com.example.project.model.Class7;
import org.junit.jupiter.api.Test;

/** Class6 Dispatcher unit tests to assert and verify correct event dispatcher behaviour */
class Class12 {

  /**
   * This unit test should register events and event handlers correctly with the event dispatcher
   * and events should be dispatched accordingly.
   */
  @Test
  void testEventDriverPattern() {

    var dispatcher = spy(new Class4());
    var userCreatedEventHandler = spy(new Class3());
    var userUpdatedEventHandler = spy(new Class2());
    dispatcher.registerHandler(Class10.class, userCreatedEventHandler);
    dispatcher.registerHandler(Class9.class, userUpdatedEventHandler);

    var user = new Class7("iluwatar");

    var userCreatedEvent = new Class10(user);
    var userUpdatedEvent = new Class9(user);

    // fire a userCreatedEvent and verify that userCreatedEventHandler has been invoked.
    dispatcher.dispatch(userCreatedEvent);
    verify(userCreatedEventHandler).onEvent(userCreatedEvent);
    verify(dispatcher).dispatch(userCreatedEvent);

    // fire a userCreatedEvent and verify that userUpdatedEventHandler has been invoked.
    dispatcher.dispatch(userUpdatedEvent);
    verify(userUpdatedEventHandler).onEvent(userUpdatedEvent);
    verify(dispatcher).dispatch(userUpdatedEvent);
  }
}
