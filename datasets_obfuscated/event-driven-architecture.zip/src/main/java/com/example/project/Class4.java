/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.eda.framework;

import java.util.HashMap;
import java.util.Map;

/**
 * Handles the routing of {@link Class6} messages to associated handlers. A {@link HashMap} is used
 * to store the association between events and their respective handlers.
 */
public class Class4 {

  private final Map<Class<? extends Class6>, Class5<? extends Class6>> handlers;

  public Class4() {
    handlers = new HashMap<>();
  }

  /**
   * Links an {@link Class6} to a specific {@link Class5}.
   *
   * @param eventType The {@link Class6} to be registered
   * @param handler The {@link Class5} that will be handling the {@link Class6}
   */
  public <E extends Class6> void registerHandler(Class<E> eventType, Class5<E> handler) {
    handlers.put(eventType, handler);
  }

  /**
   * Dispatches an {@link Class6} depending on its type.
   *
   * @param event The {@link Class6} to be dispatched
   */
  @SuppressWarnings("unchecked")
  public <E extends Class6> void dispatch(E event) {
    var handler = (Class5<E>) handlers.get(event.getClass());
    if (handler != null) {
      handler.onEvent(event);
    }
  }
}
