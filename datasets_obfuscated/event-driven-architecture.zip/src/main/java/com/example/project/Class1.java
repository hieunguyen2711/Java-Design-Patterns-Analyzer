/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import com.example.project.event.Class10;
import com.example.project.event.Class9;
import com.example.project.framework.Class6;
import com.example.project.framework.Class4;
import com.example.project.handler.Class3;
import com.example.project.handler.Class2;
import com.example.project.model.Class7;

/**
 * An event-driven architecture (EDA) is a framework that orchestrates behavior around the
 * production, detection and consumption of events as well as the responses they evoke. An event is
 * any identifiable occurrence that has significance for system hardware or software.
 *
 * <p>The example below uses an {@link Class4} to link/register {@link Class6} objects to
 * their respective handlers once an {@link Class6} is dispatched, it's respective handler is invoked
 * and the {@link Class6} is handled accordingly.
 */
public class Class1 {

  /**
   * Once the {@link Class4} is initialised, handlers related to specific events have to be
   * made known to the dispatcher by registering them. In this case the {@link Class10} is
   * bound to the Class3, whilst the {@link Class9} is bound to the
   * {@link Class2}. The dispatcher can now be called to dispatch specific events.
   * When a user is saved, the {@link Class10} can be dispatched. On the other hand, when a
   * user is updated, {@link Class9} can be dispatched.
   */
  public static void main(String[] args) {

    var dispatcher = new Class4();
    dispatcher.registerHandler(Class10.class, new Class3());
    dispatcher.registerHandler(Class9.class, new Class2());

    var user = new Class7("iluwatar");
    dispatcher.dispatch(new Class10(user));
    dispatcher.dispatch(new Class9(user));
  }
}
