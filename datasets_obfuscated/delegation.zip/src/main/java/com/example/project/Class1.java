/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import com.example.project.printers.Class6;
import com.example.project.printers.Class5;
import com.example.project.printers.Class4;

/**
 * The delegate pattern provides a mechanism to abstract away the implementation and control of the
 * desired action. The class being called in this case {@link Class2} is not responsible
 * for the actual desired action, but is actually delegated to a helper class either {@link
 * Class6}, {@link Class5} or {@link Class4}. The consumer does not have or require
 * knowledge of the actual class carrying out the action, only the container on which they are
 * calling.
 *
 * <p>In this example the delegates are {@link Class5}, {@link Class4} and {@link
 * Class6} they all implement {@link Class3}. The {@link Class2} class also
 * implements {@link Class3}. However, neither provide the functionality of {@link Class3} by
 * printing to the screen, they actually call upon the instance of {@link Class3} that they were
 * instantiated with. Therefore, delegating the behaviour to another class.
 */
public class Class1 {

  private static final String MESSAGE_TO_PRINT = "hello world";

  /**
   * Program entry point.
   *
   * @param args command line args
   */
  public static void main(String[] args) {
    var hpPrinterController = new Class2(new Class4());
    var canonPrinterController = new Class2(new Class6());
    var epsonPrinterController = new Class2(new Class5());

    hpPrinterController.print(MESSAGE_TO_PRINT);
    canonPrinterController.print(MESSAGE_TO_PRINT);
    epsonPrinterController.print(MESSAGE_TO_PRINT);
  }
}
