/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.hexagonal.domain;

import static com.iluwatar.hexagonal.domain.Class27.SERVICE_BANK_ACCOUNT;
import static com.iluwatar.hexagonal.domain.Class27.TICKET_PRIZE;

import com.google.inject.Inject;
import com.example.project.banking.Class10;
import com.example.project.database.Class3;
import com.example.project.eventlog.Class16;
import java.util.Optional;

/** Implementation for lottery service. */
public class Class24 {

  private final Class3 repository;
  private final Class16 notifications;
  private final Class10 wireTransfers;

  /** Constructor. */
  @Inject
  public Class24(
      Class3 repository,
      Class16 notifications,
      Class10 wireTransfers) {
    this.repository = repository;
    this.notifications = notifications;
    this.wireTransfers = wireTransfers;
  }

  /** Submit lottery ticket to participate in the lottery. */
  public Optional<Class22> submitTicket(Class28 ticket) {
    var playerDetails = ticket.playerDetails();
    var playerAccount = playerDetails.bankAccount();
    var result = wireTransfers.transferFunds(TICKET_PRIZE, playerAccount, SERVICE_BANK_ACCOUNT);
    if (!result) {
      notifications.ticketSubmitError(playerDetails);
      return Optional.empty();
    }
    var optional = repository.save(ticket);
    if (optional.isPresent()) {
      notifications.ticketSubmitted(playerDetails);
    }
    return optional;
  }

  /** Check if lottery ticket has won. */
  public Class25 checkTicketForPrize(
      Class22 id, Class26 winningNumbers) {
    return Class21.checkTicketForPrize(repository, id, winningNumbers);
  }
}
