/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.hexagonal.database;

import com.example.project.domain.Class28;
import com.example.project.domain.Class22;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/** Mock database for lottery tickets. */
public class Class4 implements Class3 {

  private static final Map<Class22, Class28> tickets = new HashMap<>();

  @Override
  public Optional<Class28> findById(Class22 id) {
    return Optional.ofNullable(tickets.get(id));
  }

  @Override
  public Optional<Class22> save(Class28 ticket) {
    var id = new Class22();
    tickets.put(id, ticket);
    return Optional.of(id);
  }

  @Override
  public Map<Class22, Class28> findAll() {
    return tickets;
  }

  @Override
  public void deleteAll() {
    tickets.clear();
  }
}
