/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.hexagonal.sampledata;

import com.example.project.banking.Class9;
import com.example.project.domain.Class27;
import com.example.project.domain.Class26;
import com.example.project.domain.Class24;
import com.example.project.domain.Class28;
import com.example.project.domain.Class22;
import com.example.project.domain.Class23;
import java.security.SecureRandom;
import java.util.AbstractMap.SimpleEntry;
import java.util.List;
import java.util.stream.Collectors;

/** Utilities for creating sample lottery tickets. */
public class Class5 {

  private static final List<Class23> PLAYERS;
  private static final SecureRandom RANDOM = new SecureRandom();

  static {
    PLAYERS =
        List.of(
            new Class23("john@google.com", "312-342", "+3242434242"),
            new Class23("mary@google.com", "234-987", "+23452346"),
            new Class23("steve@google.com", "833-836", "+63457543"),
            new Class23("wayne@google.com", "319-826", "+24626"),
            new Class23("johnie@google.com", "983-322", "+3635635"),
            new Class23("andy@google.com", "934-734", "+0898245"),
            new Class23("richard@google.com", "536-738", "+09845325"),
            new Class23("kevin@google.com", "453-936", "+2423532"),
            new Class23("arnold@google.com", "114-988", "+5646346524"),
            new Class23("ian@google.com", "663-765", "+928394235"),
            new Class23("robin@google.com", "334-763", "+35448"),
            new Class23("ted@google.com", "735-964", "+98752345"),
            new Class23("larry@google.com", "734-853", "+043842423"),
            new Class23("calvin@google.com", "334-746", "+73294135"),
            new Class23("jacob@google.com", "444-766", "+358042354"),
            new Class23("edwin@google.com", "895-345", "+9752435"),
            new Class23("mary@google.com", "760-009", "+34203542"),
            new Class23("lolita@google.com", "425-907", "+9872342"),
            new Class23("bruno@google.com", "023-638", "+673824122"),
            new Class23("peter@google.com", "335-886", "+5432503945"),
            new Class23("warren@google.com", "225-946", "+9872341324"),
            new Class23("monica@google.com", "265-748", "+134124"),
            new Class23("ollie@google.com", "190-045", "+34453452"),
            new Class23("yngwie@google.com", "241-465", "+9897641231"),
            new Class23("lars@google.com", "746-936", "+42345298345"),
            new Class23("bobbie@google.com", "946-384", "+79831742"),
            new Class23("tyron@google.com", "310-992", "+0498837412"),
            new Class23("tyrell@google.com", "032-045", "+67834134"),
            new Class23("nadja@google.com", "000-346", "+498723"),
            new Class23("wendy@google.com", "994-989", "+987324454"),
            new Class23("luke@google.com", "546-634", "+987642435"),
            new Class23("bjorn@google.com", "342-874", "+7834325"),
            new Class23("lisa@google.com", "024-653", "+980742154"),
            new Class23("anton@google.com", "834-935", "+876423145"),
            new Class23("bruce@google.com", "284-936", "+09843212345"),
            new Class23("ray@google.com", "843-073", "+678324123"),
            new Class23("ron@google.com", "637-738", "+09842354"),
            new Class23("xavier@google.com", "143-947", "+375245"),
            new Class23("harriet@google.com", "842-404", "+131243252"));
    var wireTransfers = new Class9();
    PLAYERS.stream()
        .map(Class23::bankAccount)
        .map(e -> new SimpleEntry<>(e, RANDOM.nextInt(Class27.PLAYER_MAX_BALANCE)))
        .collect(Collectors.toMap(SimpleEntry::getKey, SimpleEntry::getValue))
        .forEach(wireTransfers::setFunds);
  }

  /** Inserts lottery tickets into the database based on the sample data. */
  public static void submitTickets(Class24 lotteryService, int numTickets) {
    for (var i = 0; i < numTickets; i++) {
      var randomPlayerDetails = getRandomPlayerDetails();
      var lotteryNumbers = Class26.createRandom();
      var lotteryTicketId = new Class22();
      var ticket = new Class28(lotteryTicketId, randomPlayerDetails, lotteryNumbers);
      lotteryService.submitTicket(ticket);
    }
  }

  private static Class23 getRandomPlayerDetails() {
    return PLAYERS.get(RANDOM.nextInt(PLAYERS.size()));
  }
}
