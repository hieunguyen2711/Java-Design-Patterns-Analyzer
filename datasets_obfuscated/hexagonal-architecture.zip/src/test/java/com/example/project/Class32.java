/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.hexagonal.database;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.example.project.domain.Class26;
import com.example.project.domain.Class28;
import com.example.project.domain.Class22;
import com.example.project.domain.Class23;
import com.example.project.mongo.Class11;
import com.mongodb.MongoClient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

/** Tests for Mongo based ticket repository */
@Disabled
class Class32 {

  private static final String TEST_DB = "lotteryTestDB";
  private static final String TEST_TICKETS_COLLECTION = "lotteryTestTickets";
  private static final String TEST_COUNTERS_COLLECTION = "testCounters";

  private Class2 repository;

  @BeforeEach
  void init() {
    Class11.load();
    var mongoClient =
        new MongoClient(
            System.getProperty("mongo-host"), Integer.parseInt(System.getProperty("mongo-port")));
    mongoClient.dropDatabase(TEST_DB);
    mongoClient.close();
    repository =
        new Class2(TEST_DB, TEST_TICKETS_COLLECTION, TEST_COUNTERS_COLLECTION);
  }

  @Test
  void testSetup() {
    assertEquals(1, repository.getCountersCollection().countDocuments());
    assertEquals(0, repository.getTicketsCollection().countDocuments());
  }

  @Test
  void testNextId() {
    assertEquals(1, repository.getNextId());
    assertEquals(2, repository.getNextId());
    assertEquals(3, repository.getNextId());
  }

  @Test
  void testCrudOperations() {
    // create new lottery ticket and save it
    var details = new Class23("foo@bar.com", "123-123", "07001234");
    var random = Class26.createRandom();
    var original = new Class28(new Class22(), details, random);
    var saved = repository.save(original);
    assertEquals(1, repository.getTicketsCollection().countDocuments());
    assertTrue(saved.isPresent());
    // fetch the saved lottery ticket from database and check its contents
    var found = repository.findById(saved.get());
    assertTrue(found.isPresent());
    var ticket = found.get();
    assertEquals("foo@bar.com", ticket.playerDetails().email());
    assertEquals("123-123", ticket.playerDetails().bankAccount());
    assertEquals("07001234", ticket.playerDetails().phoneNumber());
    assertEquals(original.lotteryNumbers(), ticket.lotteryNumbers());
    // clear the collection
    repository.deleteAll();
    assertEquals(0, repository.getTicketsCollection().countDocuments());
  }
}
