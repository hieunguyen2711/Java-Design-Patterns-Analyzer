/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.publish.subscribe.publisher;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;

import com.example.project.Class11;
import com.example.project.model.Class4;
import com.example.project.model.Class5;
import java.lang.reflect.Field;
import java.util.Set;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.RegisterExtension;

class Class12 {

  @RegisterExtension public Class11 loggerExtension = new Class11();

  private static final String TOPIC_WEATHER = "WEATHER";
  private static final String TOPIC_CUSTOMER_SUPPORT = "CUSTOMER_SUPPORT";

  @Test
  void testRegisterTopic() throws NoSuchFieldException, IllegalAccessException {
    Class5 topic = new Class5(TOPIC_CUSTOMER_SUPPORT);
    Class3 publisher = new Class2();
    publisher.registerTopic(topic);

    Field field = publisher.getClass().getDeclaredField("topics");
    field.setAccessible(true);
    Object value = field.get(publisher);
    assertInstanceOf(Set.class, value);

    Set<?> topics = (Set<?>) field.get(publisher);
    assertEquals(1, topics.size());
  }

  @Test
  void testPublish() {
    Class5 topic = new Class5(TOPIC_WEATHER);
    Class3 publisher = new Class2();
    publisher.registerTopic(topic);

    Class4 message = new Class4("weather");
    assertDoesNotThrow(() -> publisher.publish(topic, message));
  }

  @Test
  void testPublishUnregisteredTopic() {
    Class5 topic = new Class5(TOPIC_WEATHER);
    Class3 publisher = new Class2();
    publisher.registerTopic(topic);

    Class5 topicUnregistered = new Class5(TOPIC_CUSTOMER_SUPPORT);
    Class4 message = new Class4("support");
    publisher.publish(topicUnregistered, message);
    assertEquals(
        "This topic is not registered: CUSTOMER_SUPPORT",
        loggerExtension.getFormattedMessages().getFirst());
  }
}
