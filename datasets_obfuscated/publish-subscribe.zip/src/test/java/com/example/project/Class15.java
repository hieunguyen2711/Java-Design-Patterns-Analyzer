/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.iluwatar.publish.subscribe.subscriber;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.example.project.Class11;
import com.example.project.model.Class4;
import com.example.project.model.Class5;
import com.example.project.publisher.Class3;
import com.example.project.publisher.Class2;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.RegisterExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Class15 {

  private static final Logger logger = LoggerFactory.getLogger(Class15.class);
  @RegisterExtension public Class11 loggerExtension = new Class11();

  private static final String TOPIC_WEATHER = "WEATHER";
  private static final String TOPIC_TEMPERATURE = "TEMPERATURE";
  private static final String TOPIC_CUSTOMER_SUPPORT = "CUSTOMER_SUPPORT";

  @Test
  void testSubscribeToMultipleTopics() {

    Class5 topicWeather = new Class5(TOPIC_WEATHER);
    Class5 topicTemperature = new Class5(TOPIC_TEMPERATURE);
    Class7 weatherSubscriber = new Class8();

    topicWeather.addSubscriber(weatherSubscriber);
    topicTemperature.addSubscriber(weatherSubscriber);

    Class3 publisher = new Class2();
    publisher.registerTopic(topicWeather);
    publisher.registerTopic(topicTemperature);

    publisher.publish(topicWeather, new Class4("earthquake"));
    publisher.publish(topicTemperature, new Class4("-2C"));

    waitForOutput();
    assertEquals(2, loggerExtension.getFormattedMessages().size());
  }

  @Test
  void testOnlyReceiveSubscribedTopic() {

    Class5 weatherTopic = new Class5(TOPIC_WEATHER);
    Class7 weatherSubscriber = new Class8();
    weatherTopic.addSubscriber(weatherSubscriber);

    Class5 customerSupportTopic = new Class5(TOPIC_CUSTOMER_SUPPORT);
    Class3 publisher = new Class2();
    publisher.registerTopic(weatherTopic);
    publisher.registerTopic(customerSupportTopic);

    publisher.publish(customerSupportTopic, new Class4("support@test.de"));

    waitForOutput();
    assertEquals(0, loggerExtension.getFormattedMessages().size());
  }

  @Test
  void testMultipleSubscribersOnSameTopic() {

    Class5 weatherTopic = new Class5(TOPIC_WEATHER);
    Class7 weatherSubscriber1 = new Class8();
    weatherTopic.addSubscriber(weatherSubscriber1);

    Class7 weatherSubscriber2 = new Class8();
    weatherTopic.addSubscriber(weatherSubscriber2);

    Class3 publisher = new Class2();
    publisher.registerTopic(weatherTopic);

    publisher.publish(weatherTopic, new Class4("tornado"));

    waitForOutput();
    assertEquals(2, loggerExtension.getFormattedMessages().size());
    assertEquals(
        "Weather Class7: " + weatherSubscriber1.hashCode() + " issued message: tornado",
        getMessage(weatherSubscriber1.hashCode()));
    assertEquals(
        "Weather Class7: " + weatherSubscriber2.hashCode() + " issued message: tornado",
        getMessage(weatherSubscriber2.hashCode()));
  }

  @Test
  void testMultipleSubscribersOnDifferentTopics() {

    Class5 weatherTopic = new Class5(TOPIC_WEATHER);
    Class7 weatherSubscriber = new Class8();
    weatherTopic.addSubscriber(weatherSubscriber);

    Class5 customerSupportTopic = new Class5(TOPIC_CUSTOMER_SUPPORT);
    Class7 customerSupportSubscriber = new Class9();
    customerSupportTopic.addSubscriber(customerSupportSubscriber);

    Class3 publisher = new Class2();
    publisher.registerTopic(weatherTopic);
    publisher.registerTopic(customerSupportTopic);

    publisher.publish(weatherTopic, new Class4("flood"));
    publisher.publish(customerSupportTopic, new Class4("support@test.at"));

    waitForOutput();
    assertEquals(2, loggerExtension.getFormattedMessages().size());
    assertEquals(
        "Weather Class7: " + weatherSubscriber.hashCode() + " issued message: flood",
        getMessage(weatherSubscriber.hashCode()));
    assertEquals(
        "Customer Support Class7: "
            + customerSupportSubscriber.hashCode()
            + " sent the email to: support@test.at",
        getMessage(customerSupportSubscriber.hashCode()));
  }

  @Test
  void testInvalidContentOnTopics() {

    Class5 weatherTopic = new Class5(TOPIC_WEATHER);
    Class7 weatherSubscriber = new Class8();
    weatherTopic.addSubscriber(weatherSubscriber);

    Class5 customerSupportTopic = new Class5(TOPIC_CUSTOMER_SUPPORT);
    Class7 customerSupportSubscriber = new Class9();
    customerSupportTopic.addSubscriber(customerSupportSubscriber);

    Class3 publisher = new Class2();
    publisher.registerTopic(weatherTopic);
    publisher.registerTopic(customerSupportTopic);

    publisher.publish(weatherTopic, new Class4(123));
    publisher.publish(customerSupportTopic, new Class4(34.56));

    waitForOutput();
    assertTrue(loggerExtension.getFormattedMessages().getFirst().contains("Unknown content type"));
    assertTrue(loggerExtension.getFormattedMessages().get(1).contains("Unknown content type"));
  }

  @Test
  void testUnsubscribe() {

    Class5 weatherTopic = new Class5(TOPIC_WEATHER);
    Class7 weatherSubscriber = new Class8();
    weatherTopic.addSubscriber(weatherSubscriber);

    Class3 publisher = new Class2();
    publisher.registerTopic(weatherTopic);

    publisher.publish(weatherTopic, new Class4("earthquake"));

    weatherTopic.removeSubscriber(weatherSubscriber);
    publisher.publish(weatherTopic, new Class4("tornado"));

    waitForOutput();
    assertEquals(1, loggerExtension.getFormattedMessages().size());
    assertTrue(loggerExtension.getFormattedMessages().getFirst().contains("earthquake"));
    assertFalse(loggerExtension.getFormattedMessages().getFirst().contains("tornado"));
  }

  private String getMessage(int subscriberHash) {
    Optional<String> message =
        loggerExtension.getFormattedMessages().stream()
            .filter(str -> str.contains(String.valueOf(subscriberHash)))
            .findFirst();
    assertTrue(message.isPresent());
    return message.get();
  }

  private void waitForOutput() {
    try {
      TimeUnit.SECONDS.sleep(1);
    } catch (InterruptedException e) {
      logger.error("Interrupted!", e);
      Thread.currentThread().interrupt();
    }
  }
}
