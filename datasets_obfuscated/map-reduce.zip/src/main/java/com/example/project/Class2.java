/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * The Class2 class orchestrates the Class2 process, calling the Class1, Class3, and Class4
 * components.
 */
public class Class2 {
  private Class2() {
    throw new UnsupportedOperationException(
        "Class2 is a utility class and cannot be instantiated.");
  }

  /**
   * Executes the Class2 process on the given list of input strings.
   *
   * @param inputs List of input strings to be processed.
   * @return A list of word counts sorted in descending order.
   */
  public static List<Map.Entry<String, Integer>> mapReduce(List<String> inputs) {
    List<Map<String, Integer>> mapped = new ArrayList<>();
    for (String input : inputs) {
      mapped.add(Class1.map(input));
    }

    Map<String, List<Integer>> grouped = Class3.shuffleAndSort(mapped);

    return Class4.reduce(grouped);
  }
}
