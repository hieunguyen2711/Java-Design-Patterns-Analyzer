/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

/**
 * The MonoState pattern ensures that all instances of the class will have the same state. This can
 * be used a direct replacement of the Singleton pattern.
 *
 * <p>In the following example, The {@link Class1} class represents the app's logic. It
 * contains a series of Servers, which can handle requests of type {@link Class4}. Two instances of
 * Class1 are created. When a request is made to a server via the first Class1 the state
 * change in the first load balancer affects the second. So if the first Class1 selects the
 * Class3 1, the second Class1 on a new request will select the Second server. If a third
 * Class1 is created and a new request is made to it, then it will select the third server as
 * the second load balancer has already selected the second server.
 */
public class Class2 {
  /**
   * Program entry point.
   *
   * @param args command line args
   */
  public static void main(String[] args) {
    var loadBalancer1 = new Class1();
    var loadBalancer2 = new Class1();
    loadBalancer1.serverRequest(new Class4("Hello"));
    loadBalancer2.serverRequest(new Class4("Hello World"));
  }
}
