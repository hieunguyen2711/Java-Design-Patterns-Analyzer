/*
 * This project is licensed under the MIT license. Module model-view-viewmodel is using ZK framework licensed under LGPL (see lgpl-3.0.txt).
 *
 * The MIT License
 * Copyright © 2014-2022 Ilkka Seppälä
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.example.project;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/** Tests for the {@link Class4} */
class Class8 {

  private Class2 netflixService;

  private Class1 youTubeService;

  private Class4 businessDelegate;

  /**
   * This method sets up the instance variables of this test class. It is executed before the
   * execution of every test.
   */
  @BeforeEach
  void setup() {
    netflixService = spy(new Class2());
    youTubeService = spy(new Class1());

    Class3 businessLookup = spy(new Class3());
    businessLookup.setNetflixService(netflixService);
    businessLookup.setYouTubeService(youTubeService);

    businessDelegate = spy(new Class4());
    businessDelegate.setLookupService(businessLookup);
  }

  /**
   * In this example the client ({@link Class7}) utilizes a business delegate ( {@link
   * Class4}) to execute a task. The Business Delegate then selects the appropriate
   * service and makes the service call.
   */
  @Test
  void testBusinessDelegate() {

    // setup a client object
    var client = new Class7(businessDelegate);

    // action
    client.playbackMovie("Die hard");

    // verifying that the businessDelegate was used by client during playbackMovie() method.
    verify(businessDelegate).playbackMovie(anyString());
    verify(netflixService).doProcessing();

    // action
    client.playbackMovie("Maradona");

    // verifying that the businessDelegate was used by client during doTask() method.
    verify(businessDelegate, times(2)).playbackMovie(anyString());
    verify(youTubeService).doProcessing();
  }
}
