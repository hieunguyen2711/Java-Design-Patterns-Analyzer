package restaurant.service;

import restaurant.order.Order;
import restaurant.order.OrderBuilder;

public class RestaurantService {
    
    public Order createOrder(String customerId) {
        return new OrderBuilder(customerId)
                .withMenu("MENU001")
                .withQuantity(2)
                .atAddress("123 Main St")
                .build();
    }
    
    public Order processDelivery(Order order) {
        return order
                .setMenuId("MENU001")
                .setQuantity(2)
                .setDeliveryAddress("456 Oak Ave")
                .markAsDelivered();
    }
}