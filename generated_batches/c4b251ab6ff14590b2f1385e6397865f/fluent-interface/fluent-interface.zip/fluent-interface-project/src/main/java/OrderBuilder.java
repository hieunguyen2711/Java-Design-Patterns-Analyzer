package restaurant.order;

public class OrderBuilder {
    private Order order;
    
    public OrderBuilder(String customerId) {
        this.order = new Order(customerId);
    }
    
    public OrderBuilder withMenu(String menuId) {
        order.setMenuId(menuId);
        return this;
    }
    
    public OrderBuilder withQuantity(int quantity) {
        order.setQuantity(quantity);
        return this;
    }
    
    public OrderBuilder atAddress(String address) {
        order.setDeliveryAddress(address);
        return this;
    }
    
    public Order build() {
        return order;
    }
}