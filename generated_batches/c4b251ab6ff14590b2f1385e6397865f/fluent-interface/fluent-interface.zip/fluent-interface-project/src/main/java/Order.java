package restaurant.order;

public class Order {
    private String customerId;
    private String menuId;
    private int quantity;
    private boolean isDelivered;
    private String deliveryAddress;
    
    public Order(String customerId) {
        this.customerId = customerId;
    }
    
    public Order setMenuId(String menuId) {
        this.menuId = menuId;
        return this;
    }
    
    public Order setQuantity(int quantity) {
        this.quantity = quantity;
        return this;
    }
    
    public Order setDeliveryAddress(String deliveryAddress) {
        this.deliveryAddress = deliveryAddress;
        return this;
    }
    
    public Order markAsDelivered() {
        this.isDelivered = true;
        return this;
    }
    
    // Getters
    public String getCustomerId() { return customerId; }
    public String getMenuId() { return menuId; }
    public int getQuantity() { return quantity; }
    public boolean isDelivered() { return isDelivered; }
    public String getDeliveryAddress() { return deliveryAddress; }
}