package restaurant.order;

public class PickupOrder extends OrderProcessingTemplate {

    @Override
    protected void validateOrder() {
        System.out.println("Validating pickup order - checking order time and availability");
    }

    @Override
    protected void calculateTotal() {
        System.out.println("Calculating total with tax only for pickup");
    }

    @Override
    protected void applyDiscounts() {
        System.out.println("Applying pickup discounts and loyalty points");
    }

    @Override
    protected void updateInventory() {
        System.out.println("Updating inventory for pickup order items");
    }

    @Override
    protected void notifyCustomer() {
        System.out.println("Sending pickup confirmation to customer via email");
    }
}