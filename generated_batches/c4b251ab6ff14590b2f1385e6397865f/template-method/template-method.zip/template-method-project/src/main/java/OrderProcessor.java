package restaurant.order;

public class OrderProcessor {
    
    public static void main(String[] args) {
        // Process delivery order
        System.out.println("=== Processing Delivery Order ===");
        OrderProcessingTemplate deliveryOrder = new DeliveryOrder();
        deliveryOrder.processOrder();
        
        System.out.println("\n=== Processing Pickup Order ===");
        OrderProcessingTemplate pickupOrder = new PickupOrder