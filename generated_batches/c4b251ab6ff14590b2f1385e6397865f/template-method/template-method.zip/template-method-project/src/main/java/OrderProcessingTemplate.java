package restaurant.order;

public abstract class OrderProcessingTemplate {
    
    // Template method - final to prevent overriding
    public final void processOrder() {
        validateOrder();
        calculateTotal();
        applyDiscounts();
        updateInventory();
        notifyCustomer();
    }
    
    protected abstract void validateOrder();
    protected abstract void calculateTotal();
    protected abstract void applyDiscounts();
    protected abstract void updateInventory();
    protected abstract void notifyCustomer();
}