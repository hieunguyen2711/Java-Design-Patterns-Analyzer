package restaurant.order;

public class DeliveryOrder extends OrderProcessingTemplate {

    @Override
    protected void validateOrder() {
        System.out.println("Validating delivery order - checking address and time window");
    }

    @Override
    protected void calculateTotal() {
        System.out.println("Calculating total with delivery fee and tax");
    }

    @Override
    protected void applyDiscounts() {
        System.out.println("Applying delivery discounts and promo codes");
    }

    @Override
    protected void updateInventory() {
        System.out.println("Updating inventory for delivery order items");
    }

    @Override
    protected void notifyCustomer() {
        System.out.println("Sending delivery confirmation to customer via SMS");
    }
}