package restaurant.repository;

import restaurant.model.Order;
import java.util.HashMap;
import java.util.Map;

public class OrderRepository {
    private Map<Integer, Order> orders = new HashMap<>();
    
    public void save(Order order) {
        orders.put(order.getId(), order);
    }
    
    public Order findById(int id) {
        return orders.get(id);
    }
}