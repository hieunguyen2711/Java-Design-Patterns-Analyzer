package restaurant.service;

import restaurant.model.Order;
import restaurant.repository.OrderRepository;

public class OrderService {
    private OrderRepository orderRepository;
    private UnitOfWork unitOfWork;
    
    public OrderService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
        this.unitOfWork = new UnitOfWork(orderRepository);
    }
    
    public void processOrder(int orderId, String status) {
        Order order = orderRepository.findById(orderId);
        if (order != null) {
            order.setStatus(status);
            unitOfWork.registerOrder(order);
        }
    }
    
    public void completeTransaction() {
        unitOfWork.commit();
    }
}