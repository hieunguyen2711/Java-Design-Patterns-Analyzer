package restaurant.model;

public class Order {
    private int id;
    private String customerId;
    private String status;
    
    public Order(int id, String customerId) {
        this.id = id;
        this.customerId = customerId;
        this.status = "PENDING";
    }
    
    public int getId() {
        return id;
    }
    
    public String getCustomerId() {
        return customerId;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
}