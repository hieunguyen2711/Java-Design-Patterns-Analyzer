package restaurant.service;

import restaurant.model.Order;
import restaurant.repository.OrderRepository;
import java.util.ArrayList;
import java.util.List;

public class UnitOfWork {
    private OrderRepository orderRepository;
    private List<Order> changedOrders = new ArrayList<>();
    
    public UnitOfWork(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }
    
    public void registerOrder(Order order) {
        changedOrders.add(order);
    }
    
    public void commit() {
        for (Order order : changedOrders) {
            orderRepository.save(order);
        }
        changedOrders.clear();
    }
}