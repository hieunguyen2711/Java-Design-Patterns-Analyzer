package restaurant.actor;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class OrderActor implements Actor<OrderMessage> {
    private final BlockingQueue<OrderMessage> mailbox = new LinkedBlockingQueue<>();
    private volatile boolean running = true;
    
    public void start() {
        Thread actorThread = new Thread(() -> {
            while (running) {
                try {
                    OrderMessage message = mailbox.take();
                    handleMessage(message);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        });
        actorThread.start();
    }
    
    public void stop() {
        running = false;
    }
    
    @Override
    public void receive(OrderMessage message) {
        try {
            mailbox.put(message);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
    
    private void handleMessage(OrderMessage message) {
        switch (message.getType()) {
            case PLACE_ORDER:
                System.out.println("Order placed: " + message.getOrder());
                break;
            case UPDATE_STATUS:
                System.out.println("Status updated to: " + message.getStatus());
                break;
            case ASSIGN_DELIVERY:
                System.out.println("Delivery assigned to: " + message.getDriver());
                break;
        }
    }
}