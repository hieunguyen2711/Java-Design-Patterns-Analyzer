package restaurant.actor;

public class OrderMessage {
    public enum MessageType {
        PLACE_ORDER,
        UPDATE_STATUS,
        ASSIGN_DELIVERY
    }
    
    private final MessageType type;
    private final Object payload;
    
    public OrderMessage(MessageType type, Object payload) {
        this.type = type;
        this.payload = payload;
    }
    
    public MessageType getType() {
        return type;
    }
    
    public Object getPayload() {
        return payload;
    }
    
    public String getOrder() {
        return (String) payload;
    }
    
    public String getStatus() {
        return (String) payload;
    }
    
    public String getDriver() {
        return (String) payload;
    }
}