package restaurant.actor;

public class RestaurantSystem {
    private final OrderActor orderActor = new OrderActor();
    
    public void start() {
        orderActor.start();
    }
    
    public void