package restaurant.actor;

public interface Actor<T> {
    void receive(T message);
}