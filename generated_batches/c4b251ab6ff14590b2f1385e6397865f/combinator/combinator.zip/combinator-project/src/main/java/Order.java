package restaurant.order;

import java.util.List;
import java.util.ArrayList;
import java.math.BigDecimal;

public class Order {
    private final List<OrderItem> items;
    private final String customerId;
    private final BigDecimal totalAmount;
    
    public Order(List<OrderItem> items, String customerId) {
        this.items = new ArrayList<>(items);
        this.customerId = customerId;
        this.totalAmount = calculateTotal();
    }
    
    private BigDecimal calculateTotal() {
        return items.stream()
                   .map(item -> item.getPrice().multiply(BigDecimal.valueOf(item.getQuantity())))
                   .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    
    public List<OrderItem> getItems() {
        return new ArrayList<>(items);
    }
    
    public String getCustomerId() {
        return customerId;
    }
    
    public BigDecimal getTotalAmount() {
        return totalAmount;
    }
}