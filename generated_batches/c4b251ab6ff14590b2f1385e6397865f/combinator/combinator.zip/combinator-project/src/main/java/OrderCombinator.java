package restaurant.order;

import java.util.List;
import java.util.ArrayList;
import java.math.BigDecimal;

public class OrderCombinator {
    
    public static Order combineOrders(List<Order> orders) {
        if (orders == null || orders.isEmpty()) {
            throw new IllegalArgumentException("Orders list cannot be null or empty");
        }
        
        List<OrderItem> combinedItems = new ArrayList<>();
        String customerId = orders.get(0).getCustomerId();
        BigDecimal totalAmount = BigDecimal.ZERO;
        
        for (Order order : orders) {
            if (!order.getCustomerId().equals(customerId)) {
                throw new IllegalArgumentException("All orders must belong to the same customer");
            }
            
            combinedItems.addAll(order.getItems());
            totalAmount = totalAmount.add(order.getTotalAmount());
        }
        
        return new Order(combinedItems, customerId);
    }
}