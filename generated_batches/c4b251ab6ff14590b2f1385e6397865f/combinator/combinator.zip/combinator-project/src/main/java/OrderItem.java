package restaurant.order;

import java.math.BigDecimal;

public class OrderItem {
    private final String menuItemId;
    private final String name;
    private final BigDecimal price;
    private final int quantity;
    
    public OrderItem(String menuItemId, String name, BigDecimal price, int quantity) {
        this.menuItemId = menuItemId;
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }
    
    public String getMenuItemId() {
        return menuItemId;
    }
    
    public String getName() {
        return name;
    }
    
    public BigDecimal getPrice() {
        return price;
    }
    
    public