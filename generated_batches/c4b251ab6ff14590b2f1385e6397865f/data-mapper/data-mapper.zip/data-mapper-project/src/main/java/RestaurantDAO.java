package com.restaurant.dao;

import com.restaurant.model.Restaurant;
import com.restaurant.mapper.RestaurantMapper;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RestaurantDAO {
    
    private Connection connection;
    
    public RestaurantDAO(Connection connection) {
        this.connection = connection;
    }
    
    public List<Restaurant> findAll() throws SQLException {
        List<Restaurant> restaurants = new ArrayList<>();
        String sql = "SELECT id, name, address FROM restaurants";
        
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                Restaurant restaurant = RestaurantMapper.mapRowToRestaurant(rs);
                restaurants.add(restaurant);
            }
        }
        return restaurants;
    }
    
    public Restaurant findById(int id) throws SQLException {
        String sql = "SELECT id, name, address FROM restaurants WHERE id = ?";
        
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return RestaurantMapper.mapRowToRestaurant(rs);
                }
            }
        }
        return null;
    }
}