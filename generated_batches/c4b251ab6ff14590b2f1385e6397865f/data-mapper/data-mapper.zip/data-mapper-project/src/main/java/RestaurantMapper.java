package com.restaurant.mapper;

import com.restaurant.model.Restaurant;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RestaurantMapper {
    
    public static Restaurant mapRowToRestaurant(ResultSet rs) throws SQLException {
        Restaurant restaurant = new Restaurant();
        restaurant.setId(rs.getInt("id"));
        restaurant.setName(rs.getString("name"));
        restaurant.setAddress(rs.getString("address"));
        return restaurant;
    }
}