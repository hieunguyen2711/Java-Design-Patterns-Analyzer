package restaurant.backend;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class OrderProcessor {
    private final BlockingQueue<Order> orderQueue;
    
    public OrderProcessor() {
        this.orderQueue = new LinkedBlockingQueue<>();
    }
    
    public void submitOrder(Order order) {
        try {
            // Guarded suspension - only add if queue is not full
            synchronized (orderQueue) {
                while (orderQueue.size() >= 10) { // Simple guard condition
                    orderQueue.wait(); // Suspension until space available
                }
                orderQueue.offer(order);
                orderQueue.notifyAll();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
    
    public Order getNextOrder() throws InterruptedException {
        synchronized (orderQueue) {
            while (orderQueue.isEmpty()) { // Guard condition
                orderQueue.wait(); // Suspension until order available
            }
            Order order = orderQueue.poll();
            orderQueue.notifyAll();
            return order;
        }
    }
}