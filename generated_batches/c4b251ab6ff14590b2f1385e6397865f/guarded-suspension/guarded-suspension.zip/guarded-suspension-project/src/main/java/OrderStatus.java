package restaurant.backend;

public enum OrderStatus {
    PENDING,
    PREPARING,
    READY,
    DELIVERED
}