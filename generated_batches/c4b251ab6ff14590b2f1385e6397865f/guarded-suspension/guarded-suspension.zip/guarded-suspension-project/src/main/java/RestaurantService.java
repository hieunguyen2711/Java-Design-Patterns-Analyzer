package restaurant.backend;

public class RestaurantService {
    private final OrderProcessor orderProcessor;
    
    public RestaurantService() {
        this.orderProcessor = new OrderProcessor();
    }
    
    public void processOrder(String orderId) {
        Order order = new Order(orderId);
        orderProcessor.submitOrder(order);
        
        // Simulate processing
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
    
    public Order getNextPendingOrder() throws InterruptedException {
        return orderProcessor.getNextOrder();
    }
}