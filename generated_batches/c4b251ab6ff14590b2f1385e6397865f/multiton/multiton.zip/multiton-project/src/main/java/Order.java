package com.restaurant;

import java.util.List;

public class Order {
    private String orderId;
    private List<String> items;
    private OrderStatus status;
    private Restaurant restaurant;
    private DeliveryDriver assignedDriver;
    
    public Order(String orderId, List<String> items, Restaurant restaurant) {
        this.orderId = orderId;
        this.items = items;
        this.restaurant = restaurant;
        this.status = OrderStatus.PENDING;
    }
    
    public String getOrderId() {
        return orderId;
    }
    
    public List<String> getItems() {
        return items;
    }
    
    public OrderStatus getStatus() {
        return status;
    }
    
    public void setStatus(OrderStatus status) {
        this.status = status;
    }
    
    public Restaurant getRestaurant() {
        return restaurant;
    }
    
    public DeliveryDriver getAssignedDriver() {
        return assignedDriver;
    }
    
    public void setAssignedDriver(DeliveryDriver driver) {
        this.assignedDriver = driver;
    }
}