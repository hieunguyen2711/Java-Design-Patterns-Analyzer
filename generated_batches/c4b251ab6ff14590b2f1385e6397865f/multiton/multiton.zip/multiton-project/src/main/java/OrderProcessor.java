package com.restaurant;

import java.util.HashMap;
import java.util.Map;

public class OrderProcessor {
    private static final Map<String, OrderProcessor> instances = new HashMap<>();
    private String processorId;
    
    private OrderProcessor(String processorId) {
        this.processorId = processorId;
    }
    
    public static synchronized OrderProcessor getInstance