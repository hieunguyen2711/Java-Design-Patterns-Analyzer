package com.restaurant;

public class DeliveryDriver {
    private String name;
    private String driverId;
    
    public DeliveryDriver(String name, String driverId) {
        this.name = name;
        this.driverId = driverId;
    }
    
    public String getName() {
        return name;
    }
    
    public String getDriverId() {
        return driverId;
    }
}