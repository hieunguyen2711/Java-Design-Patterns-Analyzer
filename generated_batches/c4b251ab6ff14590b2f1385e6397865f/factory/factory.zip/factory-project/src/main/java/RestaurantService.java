public class RestaurantService {
    public static void main(String[] args) {
        Order deliveryOrder = OrderFactory.createOrder("delivery", "D001", 45.99, "123 Main St");
        Order pickupOrder = OrderFactory.createOrder("pickup", "P001", 25.50, "Counter 5");
        
        deliveryOrder.processOrder();
        pickupOrder.processOrder();
    }
}