public class DeliveryOrder extends Order {
    private String deliveryAddress;
    
    public DeliveryOrder(String orderId, double totalAmount, String deliveryAddress) {
        super(orderId, totalAmount);
        this.deliveryAddress = deliveryAddress;
    }
    
    @Override
    public void processOrder() {
        System.out.println("Processing delivery order #" + orderId + 
                          " to address: " + deliveryAddress);
    }
}