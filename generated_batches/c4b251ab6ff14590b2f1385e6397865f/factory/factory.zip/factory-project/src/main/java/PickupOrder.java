public class PickupOrder extends Order {
    private String pickupLocation;
    
    public PickupOrder(String orderId, double totalAmount, String pickupLocation) {
        super(orderId, totalAmount);
        this.pickupLocation = pickupLocation;
    }
    
    @Override
    public void processOrder() {
        System.out.println("Processing pickup order #" + orderId + 
                          " at location: " + pickupLocation);
    }
}