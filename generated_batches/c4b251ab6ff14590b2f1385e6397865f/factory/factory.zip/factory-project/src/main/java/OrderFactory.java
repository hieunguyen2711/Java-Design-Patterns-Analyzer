public class OrderFactory {
    public static Order createOrder(String type, String orderId, double amount, String details) {
        switch (type.toLowerCase()) {
            case "delivery":
                return new DeliveryOrder(orderId, amount, details);
            case "pickup":
                return new PickupOrder(orderId, amount, details);
            default:
                throw new IllegalArgumentException("Unknown order type: " + type);
        }
    }
}