import java.util.HashMap;
import java.util.Map;

public class DatabaseOrderRepository implements OrderRepository {
    private Map<String, Order> orders = new HashMap<>();
    
    @Override
    public void save(Order order) {
        orders.put(order.getId(), order);
    }
    
    @Override
    public Order findById(String id) {
        return orders.get(id);
    }
    
    @Override
    public void update(Order order) {
        orders.put(order.getId(), order);
    }
}