public class OrderController {
    private OrderService orderService;
    
    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }
    
    public void handleOrderCreation(String customerId, String menuItemId) {
        Order order = new Order(customerId, menuItemId);
        orderService.createOrder(order);
    }
    
    public void handleOrderStatusUpdate(String orderId, String status) {
        orderService.updateOrderStatus(orderId, status);
    }
}