public class Order {
    private String id;
    private String customerId;
    private String menuItemId;
    private String status;
    
    public Order(String customerId, String menuItemId) {
        this.id = java.util.UUID.randomUUID().toString();
        this.customerId = customerId;
        this.menuItemId = menuItemId;
        this.status = "CREATED";
    }
    
    // Getters and setters
    public String getId() { return id; }
    public String getCustomerId() { return customerId; }
    public String getMenuItemId() { return menuItemId; }
    public String getStatus() { return status; }
    public void setStatus(String status) {