package restaurant.order;

import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;

public class OrderMonad {
    
    public static Optional<Order> bind(Optional<Order> order, Function<Order, Optional<Order>> function) {
        if (order.isPresent()) {
            return function.apply(order.get());
        }
        return Optional.empty();
    }
    
    public static CompletableFuture<Optional<Order>> bindAsync(
            CompletableFuture<Optional<Order>> orderFuture,
            Function<Order, CompletableFuture<Optional<Order>>> function) {
        
        return