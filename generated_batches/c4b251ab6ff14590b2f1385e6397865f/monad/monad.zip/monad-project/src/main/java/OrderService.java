package restaurant.order;

import java.util.Optional;
import java.util.concurrent.CompletableFuture;

public class OrderService {
    
    public Optional<Order> findOrder(String orderId) {
        // Simulate database lookup
        if (orderId != null && orderId.startsWith("ORD")) {
            return Optional.of(new Order(orderId, "CUST123", 45.99));
        }
        return Optional.empty();
    }
    
    public CompletableFuture<Optional<Order>> findOrderAsync(String orderId) {
        return CompletableFuture.supplyAsync(() -> findOrder(orderId));
    }
    
    public Optional<Order> processPayment(Order order) {
        if (order != null && order.getTotalAmount() > 0) {
            return Optional.of(new Order(order.getOrderId(), order.getCustomerId(), order.getTotalAmount()));
        }
        return Optional.empty();
    }
    
    public CompletableFuture<Optional<Order>> processPaymentAsync(Order order) {
        return CompletableFuture.supplyAsync(() -> processPayment(order));
    }
}