public class BusinessDelegate {
    private OrderService orderService;
    private MenuService menuService;
    private DeliveryService deliveryService;

    public void setOrderService(OrderService orderService) {
        this.orderService = orderService;
    }

    public void setMenuService(MenuService menuService) {
        this.menuService = menuService;
    }

    public void setDeliveryService(DeliveryService deliveryService) {
        this.deliveryService = deliveryService;
    }

    public String processOrder(String customerId, String menuItemId) {
        return orderService.placeOrder(customerId, menuItemId);
    }

    public String getMenuDetails(String menuItemId) {
        return menuService.getMenuItem(menuItemId);
    }

    public String assignDelivery(String orderId) {
        return deliveryService.assignDelivery(orderId);
    }
}