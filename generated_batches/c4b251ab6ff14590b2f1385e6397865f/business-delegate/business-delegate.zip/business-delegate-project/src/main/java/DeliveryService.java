public class DeliveryService {
    public String assignDelivery(String orderId) {
        // Simulate delivery assignment
        return "Delivery assigned to order: " + orderId;
    }
}