public class Client {
    public static void main(String[] args) {
        BusinessDelegate businessDelegate = new BusinessDelegate();
        
        businessDelegate.setOrderService(new OrderService());
        businessDelegate.setMenuService(new MenuService());
        businessDelegate.setDeliveryService(new DeliveryService());
        
        System.out.println(businessDelegate.processOrder("CUST001", "ITEM001"));
        System.out.println(businessDelegate.getMenuDetails("ITEM001"));
        System.out.println(businessDelegate.assignDelivery("ORDER001"));
    }
}