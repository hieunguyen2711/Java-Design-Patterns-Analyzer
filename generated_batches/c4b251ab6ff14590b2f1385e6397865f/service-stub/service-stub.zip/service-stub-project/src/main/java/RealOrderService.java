package com.restaurant.service;

public class RealOrderService implements OrderService {
    @Override
    public void processOrder(String orderId) {
        System.out.println("Processing order: " + orderId);
        // Simulate actual order processing logic
    }
    
    @Override
    public String getOrderStatus(String orderId) {
        return "ORDER_CONFIRMED";
    }
}