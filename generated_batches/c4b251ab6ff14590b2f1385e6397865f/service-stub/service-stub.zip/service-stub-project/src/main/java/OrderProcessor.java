package com.restaurant.service;

public class OrderProcessor {
    private final OrderService orderService;
    
    public OrderProcessor(OrderService orderService) {
        this.orderService = orderService;
    }
    
    public void handleOrder(String orderId) {
        System.out.println("Processing order through service stub pattern");
        orderService.processOrder(orderId);
        String status = orderService.getOrderStatus(orderId);
        System.out.println("Order " + orderId + " status: " + status);
    }
}