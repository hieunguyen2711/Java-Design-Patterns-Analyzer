package com.restaurant.service;

public class Main {
    public static void main(String[] args) {
        // Using real service in production
        OrderService realService = new RealOrderService();
        OrderProcessor processor1 = new OrderProcessor(realService);
        processor1.handleOrder("ORD-001");
        
        System.out.println("---");
        
        // Using stub service for testing
        OrderService stubService = new OrderServiceStub(realService);
        OrderProcessor processor2 = new OrderProcessor(stubService);
        processor2.handleOrder("ORD-002");
    }
}