package com.restaurant.service;

public class OrderServiceStub implements OrderService {
    private final OrderService realService;
    
    public OrderServiceStub(OrderService realService) {
        this.realService = realService;
    }
    
    @Override
    public void processOrder(String orderId) {
        // Stub implementation - does not actually process order
        System.out.println("Stub: Order processing skipped for " + orderId);
    }
    
    @Override
    public String getOrderStatus(String orderId) {
        // Return predefined status instead of querying real system
        return "STUB_STATUS";
    }
}