package com.restaurant.dto;

public class OrderItemDTO {
    private Long menuItemId;
    private String itemName;
    private Double price;
    private Integer quantity;
    
    // Default constructor
    public OrderItemDTO() {}
    
    // Constructor with parameters
    public Order