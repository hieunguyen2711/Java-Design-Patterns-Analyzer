package com.restaurant.repository;

import com.restaurant.model.Order;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class InMemoryOrderRepository implements OrderRepository {
    private List<Order> orders = new ArrayList<>();
    private int nextId = 1;

    @Override
    public Order findById(int id) {
        return orders.stream()
                .filter(order -> order.getId() == id)
                .findFirst()
                .orElse(null);
    }

    @Override
    public List<Order> findByCustomerId(String customerId) {
        return orders.stream()
                .filter(order -> order.getCustomerId().equals(customerId))
                .collect(Collectors.toList());
    }

    @Override
    public void save(Order order) {
        order.setId(nextId++);
        orders.add(order);
    }

    @Override
    public void update(Order order) {
        for (int i = 0; i < orders.size(); i++) {
            if (orders.get(i).getId() == order.getId()) {
                orders.set(i, order);
                break;
            }
        }
    }

    @Override
    public void delete