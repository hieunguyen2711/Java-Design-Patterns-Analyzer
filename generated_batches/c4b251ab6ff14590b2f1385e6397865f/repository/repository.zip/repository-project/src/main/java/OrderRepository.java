package com.restaurant.repository;

import com.restaurant.model.Order;
import java.util.List;

public interface OrderRepository {
    Order findById(int id);
    List<Order> findByCustomerId(String customerId);
    void save(Order order);
    void update(Order order);
    void delete(int id);
}