package restaurant.order;

import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

public class OrderService {
    private final Map<String, Order> orders = new ConcurrentHashMap<>();
    
    // Double buffering - using two maps to avoid concurrent modification issues
    private volatile Map<String, Order> activeOrders = new ConcurrentHashMap<>();
    private volatile Map<String, Order> pendingOrders = new ConcurrentHashMap<>();
    
    public void createOrder(String orderId, String customerId) {
        Order order = new Order(orderId, customerId);
        orders.put(orderId, order);
        pendingOrders.put(orderId, order);
    }
    
    public void processOrder(String orderId) {
        // Double buffering: move from pending to active
        Order order = pendingOrders.remove(orderId);
        if (order != null) {
            activeOrders.put(orderId, order);
            order.setStatus(OrderStatus.CONFIRMED);
        }
    }
    
    public void updateOrderStatus(String orderId, OrderStatus status) {
        // Double buffering: ensure we're working with current state
        Order order = activeOrders.get(orderId);
        if (order != null) {
            order.setStatus(status);
            
            // Move to completed when delivered
            if (status == OrderStatus.DELIVERED) {
                activeOrders.remove(orderId);
            }
        }
    }
    
    public Order getOrder(String orderId) {
        return orders.get(orderId);
    }
}