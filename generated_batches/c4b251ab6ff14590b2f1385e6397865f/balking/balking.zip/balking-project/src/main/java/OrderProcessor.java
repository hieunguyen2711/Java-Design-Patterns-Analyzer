package restaurant.order;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;

public class OrderProcessor {
    private final ConcurrentHashMap<String, Order> orders;
    private final ReentrantLock lock;
    
    public OrderProcessor() {
        this.orders = new ConcurrentHashMap<>();
        this.lock = new ReentrantLock();
    }
    
    public void processOrder(String orderId) {
        // Balking pattern: only proceed if order is in PENDING state
        Order order = orders.get(orderId);
        if (order == null || order.getStatus() != OrderStatus.PENDING) {
            return; // Balking - don't process if not in correct state
        }
        
        try {
            lock.lock();
            
            // Double-check after acquiring lock
            if (order.getStatus() != OrderStatus.PENDING) {
                return; // Balking - another thread changed the status
            }
            
            order.setStatus(OrderStatus.CONFIRMED);
            System.out.println("Order " + orderId + " confirmed");
            
        } finally {
            lock.unlock();
        }
    }
    
    public void createOrder(String orderId) {
        orders.put(orderId, new Order(orderId));
    }
}