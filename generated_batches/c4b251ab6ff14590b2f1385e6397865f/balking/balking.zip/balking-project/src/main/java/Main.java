package restaurant.order;

public class Main {
    public static void main(String[] args) {
        OrderProcessor processor = new OrderProcessor();
        
        // Create an order
        processor.createOrder("ORD-001");
        
        // Process the order (will succeed)
        processor.processOrder("ORD-001");
        
        // Try to process again (will be ignored due to balking)
        processor.processOrder("ORD-001