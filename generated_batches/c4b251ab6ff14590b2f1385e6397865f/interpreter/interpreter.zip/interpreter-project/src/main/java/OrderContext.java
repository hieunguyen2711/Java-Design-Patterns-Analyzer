public class OrderContext {
    private String orderDetails;
    
    public OrderContext(String orderDetails) {
        this.orderDetails = orderDetails;
    }
    
    public String getOrderDetails() {
        return orderDetails;
    }
}