public class OrderInterpreter {
    public static Expression getTerminalExpression() {
        return new TerminalExpression("ORDER");
    }
    
    public static Expression getCustomerExpression() {
        return new TerminalExpression("CUSTOMER");
    }
    
    public static Expression getStatusExpression() {
        return new TerminalExpression("STATUS");
    }
    
    public static Expression getDeliveryExpression() {
        return new TerminalExpression("DELIVERY");
    }
}