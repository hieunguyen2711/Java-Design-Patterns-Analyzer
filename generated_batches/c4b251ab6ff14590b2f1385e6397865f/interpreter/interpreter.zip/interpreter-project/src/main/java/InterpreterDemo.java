public class InterpreterDemo {
    public static void main(String[] args) {
        Expression orderExpression = OrderInterpreter.getTerminalExpression();
        Expression customerExpression = OrderInterpreter.getCustomerExpression();
        Expression statusExpression = OrderInterpreter.getStatusExpression();
        
        // Create complex expressions using interpreter pattern
        Expression orExpression = new OrExpression(orderExpression, customerExpression);