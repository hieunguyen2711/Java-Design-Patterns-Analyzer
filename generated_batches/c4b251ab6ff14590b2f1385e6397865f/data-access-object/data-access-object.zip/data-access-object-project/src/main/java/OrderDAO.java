import java.util.List;

public interface OrderDAO {
    List<Order> getAllOrders();
    Order getOrderById(int id);
    void saveOrder(Order order);
    void updateOrder(Order order);
    void deleteOrder(int id);
}