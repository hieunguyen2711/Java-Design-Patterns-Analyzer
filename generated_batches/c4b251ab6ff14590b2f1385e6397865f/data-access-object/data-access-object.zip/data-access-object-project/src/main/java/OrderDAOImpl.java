import java.util.ArrayList;
import java.util.List;

public class OrderDAOImpl implements OrderDAO {
    private List<Order> orders;
    
    public OrderDAOImpl() {
        this.orders = new ArrayList<>();
        // Initialize with some sample data
        orders.add(new Order(1, "C001", "PREPARING"));
        orders.add(new Order(2, "C002", "READY"));
        orders.add(new Order(3, "C003", "DELIVERED"));
    }
    
    @Override
    public List<Order> getAllOrders() {
        return new ArrayList<>(orders);
    }
    
    @Override
    public Order getOrderById(int id) {
        for (Order order : orders) {
            if (order.getId() == id) {
                return order;
            }
        }
        return null;
    }
    
    @Override
    public void saveOrder(Order order) {
        orders.add(order);
    }
    
    @Override
    public void updateOrder(Order order) {
        for (int i = 0; i < orders.size(); i++) {
            if (orders.get(i).getId() == order.getId()) {
                orders.set(i, order);
                break;
            }
        }
    }
    
    @Override
    public void deleteOrder(int id) {
        orders.removeIf(order -> order.getId() == id