public class ItalianRestaurantFactory implements RestaurantFactory {
    @Override
    public Kitchen createKitchen() {
        return new ItalianKitchen();
    }
    
    @Override
    public DeliveryService createDeliveryService() {
        return new ItalianDeliveryService();
    }
}