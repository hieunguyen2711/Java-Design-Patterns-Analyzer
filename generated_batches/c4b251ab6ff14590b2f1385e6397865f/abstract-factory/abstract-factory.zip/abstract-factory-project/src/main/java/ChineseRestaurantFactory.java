public class ChineseRestaurantFactory implements RestaurantFactory {
    @Override
    public Kitchen createKitchen() {
        return new ChineseKitchen();
    }
    
    @Override
    public DeliveryService createDeliveryService() {
        return new ChineseDeliveryService();
    }
}