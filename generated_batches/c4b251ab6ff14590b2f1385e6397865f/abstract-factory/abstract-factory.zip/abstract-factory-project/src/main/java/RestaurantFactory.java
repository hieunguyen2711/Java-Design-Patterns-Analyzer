public interface RestaurantFactory {
    Kitchen createKitchen();
    DeliveryService createDeliveryService();
}