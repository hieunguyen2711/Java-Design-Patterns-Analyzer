public class ItalianKitchen implements Kitchen {
    @Override
    public void prepareFood(String order) {
        System.out.println("Preparing " + order + " in Italian style");
    }
    
    @Override
    public String getSpecialty() {
        return "Pasta";
    }
}