public interface Kitchen {
    void prepareFood(String order);
    String getSpecialty();
}