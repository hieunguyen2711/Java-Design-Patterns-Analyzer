public interface DeliveryService {
    void assignDelivery(String orderId);
    String getDeliveryMethod();
}