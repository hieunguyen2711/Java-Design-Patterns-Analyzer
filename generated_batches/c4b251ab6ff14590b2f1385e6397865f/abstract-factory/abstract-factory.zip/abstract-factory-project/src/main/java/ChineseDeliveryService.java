public class ChineseDeliveryService implements DeliveryService {
    @Override
    public void assignDelivery(String orderId) {
        System.out.println("Assigning delivery for " + orderId + " via Chinese courier");
    }
    
    @Override
    public String getDeliveryMethod() {
        return "Motorcycle";