public class ChineseKitchen implements Kitchen {
    @Override
    public void prepareFood(String order) {
        System.out.println("Preparing " + order + " in Chinese style");
    }
    
    @Override
    public String getSpecialty() {
        return "Dim Sum";
    }
}