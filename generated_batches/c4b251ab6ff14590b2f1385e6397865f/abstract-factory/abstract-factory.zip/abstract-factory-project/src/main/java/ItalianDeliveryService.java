public class ItalianDeliveryService implements DeliveryService {
    @Override
    public void assignDelivery(String orderId) {
        System.out.println("Assigning delivery for " + orderId + " via Italian courier");
    }
    
    @Override
    public String getDeliveryMethod() {
        return "Bicycle";
    }
}