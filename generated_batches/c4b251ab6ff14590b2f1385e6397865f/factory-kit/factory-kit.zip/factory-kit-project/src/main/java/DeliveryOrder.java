public class DeliveryOrder extends Order {
    private String deliveryAddress;
    
    public DeliveryOrder(String customerId) {
        super(customerId);
    }
    
    @Override
    public void processOrder() {
        System.out.println("Processing delivery order for customer " + customerId);
        this.status = OrderStatus.CONFIRMED;
    }
    
    public void setDeliveryAddress(String address) {
        this.deliveryAddress = address;
    }
}