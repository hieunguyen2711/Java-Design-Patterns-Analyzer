public abstract class Order {
    protected String customerId;
    protected OrderStatus status;
    
    public Order(String customerId) {
        this.customerId = customerId;
        this.status = OrderStatus.PENDING;
    }
    
    public abstract void processOrder();
    
    public void setStatus(OrderStatus status) {
        this.status = status;
    }
    
    public OrderStatus getStatus() {
        return status;
    }
}