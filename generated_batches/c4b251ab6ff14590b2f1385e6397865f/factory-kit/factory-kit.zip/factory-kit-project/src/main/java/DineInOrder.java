public class DineInOrder extends Order {
    private int tableNumber;
    
    public DineInOrder(String customerId) {
        super(customerId);
    }
    
    @Override
    public void processOrder() {
        System.out.println("Processing dine-in order for customer " + customerId);
        this.status = OrderStatus.CONFIRMED