public class PickupOrder extends Order {
    private String pickupTime;
    
    public PickupOrder(String customerId) {
        super(customerId);
    }
    
    @Override
    public void processOrder() {
        System.out.println("Processing pickup order for customer " + customerId);
        this.status = OrderStatus.CONFIRMED;
    }
    
    public void setPickupTime(String time) {
        this.pickupTime = time;
    }
}