public class OrderFactory {
    public static Order createOrder(OrderType type, String customerId) {
        switch (type) {
            case DELIVERY:
                return new DeliveryOrder(customerId);
            case PICKUP:
                return new PickupOrder(customerId);
            case DINE_IN:
                return new DineInOrder(customerId);
            default:
                throw new IllegalArgumentException("Unknown order type: " + type);
        }
    }
}