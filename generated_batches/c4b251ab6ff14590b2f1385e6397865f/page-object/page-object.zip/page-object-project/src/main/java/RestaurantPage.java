package com.restaurant.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RestaurantPage {
    private WebDriver driver;
    
    @FindBy(id = "restaurant-name")
    private WebElement restaurantName;
    
    @FindBy(id = "menu-button")
    private WebElement menuButton;
    
    @FindBy(id = "order-button")
    private WebElement orderButton;
    
    public RestaurantPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    public String getRestaurantName() {
        return restaurantName.getText();
    }
    
    public MenuPage navigateToMenu() {
        menuButton.click();
        return new MenuPage(driver);
    }
    
    public OrderPage navigateToOrder() {
        orderButton.click();
        return new OrderPage(driver);
    }
}