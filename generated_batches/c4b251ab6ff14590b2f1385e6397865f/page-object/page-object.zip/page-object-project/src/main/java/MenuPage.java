package com.restaurant.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MenuPage {
    private WebDriver driver;
    
    @FindBy(id = "menu-items")
    private WebElement menuItemsContainer;
    
    @FindBy(id = "back-button")
    private WebElement backButton;
    
    public MenuPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    public boolean isMenuLoaded() {
        return menuItemsContainer.isDisplayed();
    }
    
    public RestaurantPage navigateBack() {
        backButton.click();
        return new RestaurantPage(driver);
    }
}