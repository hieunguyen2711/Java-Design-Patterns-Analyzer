package com.restaurant.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OrderPage {
    private WebDriver driver;
    
    @FindBy(id = "order-summary")
    private WebElement orderSummary;
    
    @FindBy(id = "confirm-button")
    private WebElement confirmButton;
    
    @FindBy(id = "cancel-button")
    private WebElement cancelButton;
    
    public OrderPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    public boolean isOrderSummaryVisible() {
        return orderSummary.isDisplayed();
    }
    
    public void confirmOrder() {
        confirmButton.click();
    }