package restaurant.backend;

import java.util.Arrays;
import java.util.List;

public class RestaurantService {
    
    public void processOrders() {
        // Create sample orders