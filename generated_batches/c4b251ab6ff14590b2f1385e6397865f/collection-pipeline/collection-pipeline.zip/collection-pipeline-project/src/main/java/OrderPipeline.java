package restaurant.backend;

import java.util.List;
import java.util.stream.Collectors;

public class OrderPipeline {
    
    public static List<Order> filterByStatus(List<Order> orders, OrderStatus status) {
        return orders.stream()
                .filter(order -> order.getStatus() == status)
                .collect(Collectors.toList());
    }
    
    public static List<Order> sortByAmountDescending(List<Order> orders) {
        return orders.stream()
                .sorted((o1, o2) -> Double.compare(o2.getTotalAmount(), o1.getTotalAmount()))
                .collect(Collectors.toList());
    }
    
    public static double calculateTotalRevenue(List<Order> orders) {
        return orders.stream()
                .mapToDouble(Order::getTotalAmount)
                .sum();
    }
    
    public static List<String> extractCustomerIds(List<Order> orders) {
        return orders.stream()
                .map(Order::getCustomerId)
                .distinct()
                .collect(Collectors.toList());
    }
}