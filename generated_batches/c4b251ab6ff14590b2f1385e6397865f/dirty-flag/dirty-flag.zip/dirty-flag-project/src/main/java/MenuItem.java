package restaurant.menu;

public class MenuItem {
    private String name;
    private double price;
    private boolean isDirty;
    
    public MenuItem(String name, double price) {
        this.name = name;
        this.price = price;
        this.isDirty = false;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
        markAsDirty();
    }
    
    public double getPrice() {
        return price;
    }
    
    public void setPrice(double price) {
        this.price = price;
        markAsDirty();
    }
    
    public boolean isDirty() {
        return isDirty;
    }
    
    public void markAsDirty() {
        this.isDirty = true;
    }
    
    public void clearDirtyFlag() {
        this.isDirty = false;
    }
}