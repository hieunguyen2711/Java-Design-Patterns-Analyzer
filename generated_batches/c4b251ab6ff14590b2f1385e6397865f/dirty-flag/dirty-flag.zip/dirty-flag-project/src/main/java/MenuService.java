package restaurant.menu;

import java.util.ArrayList;
import java.util.List;

public class MenuService {
    private List<MenuItem> menuItems;
    
    public MenuService() {
        this.menuItems = new ArrayList<>();
    }
    
    public void addMenuItem(MenuItem item) {
        menuItems.add(item);
    }
    
    public void updateMenuItem(String itemName, String newName, double newPrice) {
        MenuItem item = findItemByName(itemName);
        if (item != null) {
            // Only mark as dirty if changes actually occur
            boolean nameChanged = !item.getName().equals(newName);
            boolean priceChanged = item.getPrice() != newPrice;
            
            if (nameChanged || priceChanged) {
                item.setName(newName);
                item.setPrice(newPrice);
            }
        }
    }
    
    public List<MenuItem> getDirtyItems() {
        List<MenuItem> dirtyItems = new ArrayList<>();
        for (MenuItem item : menuItems) {
            if (item.isDirty()) {
                dirtyItems.add(item);
            }
        }
        return dirtyItems;
    }
    
    public void processDirtyItems() {
        for (MenuItem item : getDirtyItems()) {
            // Simulate database update or other processing
            System.out.println("Processing dirty item: " + item.getName());
            item.clearDirtyFlag();
        }
    }
    
    private MenuItem findItemByName(String name) {
        for (MenuItem item : menuItems) {
            if (item.getName().equals(name)) {
                return item;