public class OrderServiceImpl implements OrderService {
    @Override
    public void processOrder(Order order) {
        System.out.println("Processing order: " + order.getId());
    }

    @Override
    public Order getOrderById(String orderId) {
        return new Order(orderId);
    }
}