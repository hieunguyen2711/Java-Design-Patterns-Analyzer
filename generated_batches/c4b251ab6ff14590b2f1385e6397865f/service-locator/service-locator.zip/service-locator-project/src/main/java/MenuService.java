public interface MenuService {
    MenuItem getMenuItem(String itemId);
    void updateMenuItem(MenuItem item);
}