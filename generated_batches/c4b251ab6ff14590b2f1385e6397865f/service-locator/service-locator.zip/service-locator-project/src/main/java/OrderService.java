public interface OrderService {
    void processOrder(Order order);
    Order getOrderById(String orderId);
}