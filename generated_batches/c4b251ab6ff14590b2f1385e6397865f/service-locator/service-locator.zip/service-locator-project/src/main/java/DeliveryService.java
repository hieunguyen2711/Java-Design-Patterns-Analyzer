public interface DeliveryService {
    void assignDelivery(Delivery delivery);
    Delivery getDeliveryById(String deliveryId);
}