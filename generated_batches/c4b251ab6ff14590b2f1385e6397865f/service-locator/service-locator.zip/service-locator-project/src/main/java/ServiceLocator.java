public class ServiceLocator {
    private static ServiceLocator instance;
    private Map<String, Object> services;

    private ServiceLocator() {
        services = new HashMap<>();
        loadServices();
    }

    public static synchronized ServiceLocator getInstance() {
        if (instance == null) {
            instance = new ServiceLocator();
        }
        return instance;
    }

    private void loadServices() {
        services.put("OrderService", new OrderServiceImpl());
        services.put("MenuService", new MenuServiceImpl());
        services.put("DeliveryService", new DeliveryServiceImpl());
    }

    public Object getService(String serviceName) {
        return services.get(serviceName);
    }
}