public class DeliveryServiceImpl implements DeliveryService {
    @Override
    public void assignDelivery(Delivery delivery) {
        System.out.println("Assigning delivery: " + delivery.getId());
    }

    @Override
    public Delivery getDeliveryById(String deliveryId) {
        return new Delivery(deliveryId);
    }
}