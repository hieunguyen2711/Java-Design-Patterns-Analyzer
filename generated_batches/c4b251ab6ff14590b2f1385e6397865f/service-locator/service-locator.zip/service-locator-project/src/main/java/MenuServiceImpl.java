public class MenuServiceImpl implements MenuService {
    @Override
    public MenuItem getMenuItem(String itemId) {
        return new MenuItem(itemId);
    }

    @Override
    public void updateMenuItem(MenuItem item) {
        System.out.println("Updating menu item: " + item.getId());
    }
}