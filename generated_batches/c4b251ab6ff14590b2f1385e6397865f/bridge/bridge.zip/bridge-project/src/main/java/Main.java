public class Main {
    public static void main(String[] args) {
        // Using credit card processor
        OrderService restaurantOrder = new RestaurantOrderService(new CreditCardProcessor());
        restaurantOrder.completeOrder(45.99);
        
        System.out.println();
        
        // Using PayPal processor
        OrderService deliveryOrder = new DeliveryOrderService(new PayPalProcessor());
        deliveryOrder.completeOrder(23.50);
    }
}