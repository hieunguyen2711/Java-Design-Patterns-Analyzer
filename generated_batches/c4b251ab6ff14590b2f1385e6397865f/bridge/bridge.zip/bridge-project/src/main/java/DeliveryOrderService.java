public class DeliveryOrderService extends OrderService {
    public DeliveryOrderService(PaymentProcessor paymentProcessor) {
        super(paymentProcessor);
    }
    
    @Override
    public void completeOrder(double amount) {
        System.out.println("Delivery order processing:");
        super.completeOrder(amount);
    }
}