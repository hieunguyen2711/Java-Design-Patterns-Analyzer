public class RestaurantOrderService extends OrderService {
    public RestaurantOrderService(PaymentProcessor paymentProcessor) {
        super(paymentProcessor);
    }
    
    @Override
    public void completeOrder(double amount) {
        System.out.println("Restaurant order processing:");
        super.completeOrder(amount);
    }
}