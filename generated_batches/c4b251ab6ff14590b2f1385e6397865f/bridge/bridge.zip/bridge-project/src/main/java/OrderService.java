public abstract class OrderService {
    protected PaymentProcessor paymentProcessor;
    
    public OrderService(PaymentProcessor paymentProcessor) {
        this.paymentProcessor = paymentProcessor;
    }
    
    public void completeOrder(double amount) {
        System.out.println("Completing order...");
        paymentProcessor.processPayment(amount);
        System.out.println("Order completed successfully!");
    }
}