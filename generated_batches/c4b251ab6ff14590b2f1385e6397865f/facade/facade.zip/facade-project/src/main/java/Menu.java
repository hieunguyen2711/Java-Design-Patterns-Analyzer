import java.util.HashMap;
import java.util.Map;

public class Menu {
    private Map<String, MenuItem> menuItems;
    
    public Menu() {
        menuItems = new HashMap<>();
        menuItems.put("burger", new MenuItem("Burger", 12.99));
        menuItems.put("pizza", new MenuItem("Pizza", 15.50));
        menuItems.put("salad", new MenuItem("Salad", 8.75));
    }
    
    public MenuItem[] getMenuItems(String[] itemNames) {
        MenuItem[] items = new MenuItem[itemNames.length];
        for (int i = 0; i < itemNames.length; i++) {
            items[i] = menuItems.get(itemNames[i]);
        }
        return items;
    }
}