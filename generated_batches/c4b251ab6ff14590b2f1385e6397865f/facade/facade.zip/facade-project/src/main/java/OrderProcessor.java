public class OrderProcessor {
    
    public double calculateTotal(MenuItem[] items) {
        double total = 0.0;
        for (MenuItem item : items) {
            if (item != null) {
                total += item.getPrice();
            }
        }
        return total;
    }
    
    public String processOrder(String customerName, MenuItem[] items) {
        // Simulate order processing
        StringBuilder orderIdBuilder = new StringBuilder();
        orderIdBuilder.append("ORD-");
        orderIdBuilder.append(System.currentTimeMillis() % 10000);
        
        System.out.println("Processing order for: " + customerName);
        return orderIdBuilder.toString();
    }
}