public class RestaurantFacade {
    private Menu menu;
    private OrderProcessor orderProcessor;
    private DeliveryService deliveryService;
    
    public RestaurantFacade() {
        this.menu = new Menu();
        this.orderProcessor = new OrderProcessor();
        this.deliveryService = new DeliveryService();
    }
    
    public String placeOrder(String customerName, String[] items) {
        // Abstracted complex process
        MenuItem[] menuItems = menu.getMenuItems(items);
        double total = orderProcessor.calculateTotal(menuItems);
        String orderId = orderProcessor.processOrder(customerName, menuItems);
        deliveryService.assignDelivery(orderId);
        
        return "Order placed successfully. Order ID: " + orderId;
    }
}