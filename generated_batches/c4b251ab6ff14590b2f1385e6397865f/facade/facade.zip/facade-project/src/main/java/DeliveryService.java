public class DeliveryService {
    
    public void assignDelivery(String orderId) {
        // Simulate delivery assignment
        System.out.println("