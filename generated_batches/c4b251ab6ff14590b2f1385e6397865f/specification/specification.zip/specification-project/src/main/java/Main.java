package restaurant.order;

public class Main {
    public static void main(String[] args) {
        // Using the singleton pattern through factory
        OrderProcessor processor = OrderProcessorFactory.getInstance();
        
        // Create some orders
        Order order1 = new Order("ORD001", "CUST001", 25.50);
        Order order2 =