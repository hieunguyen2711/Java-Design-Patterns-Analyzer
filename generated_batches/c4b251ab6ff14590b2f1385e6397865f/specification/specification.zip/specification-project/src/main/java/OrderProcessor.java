package restaurant.order;

import java.util.ArrayList;
import java.util.List;

public class OrderProcessor {
    private List<Order> orders;
    
    public OrderProcessor() {
        this.orders = new ArrayList<>();
    }
    
    public void processOrder(Order order) {
        // Simulate processing steps
        order.updateStatus(OrderStatus.CONFIRMED);
        order.updateStatus(OrderStatus.PREPARING);
        order.updateStatus(OrderStatus.READY);
        order.updateStatus(OrderStatus.DELIVERED);
        
        orders.add(order);
    }
    
    public List<Order> getOrders() {
        return new ArrayList<>(orders);
    }
}