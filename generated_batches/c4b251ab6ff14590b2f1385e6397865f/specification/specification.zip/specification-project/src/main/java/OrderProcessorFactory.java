package restaurant.order;

public class OrderProcessorFactory {
    private static OrderProcessor instance;
    
    private OrderProcessorFactory() {}
    
    public static synchronized OrderProcessor getInstance() {
        if (instance == null) {
            instance = new OrderProcessor();
        }
        return instance;
    }
}