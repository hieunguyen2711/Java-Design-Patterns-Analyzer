public class TaxDecorator extends OrderDecorator {
    private static final double TAX_RATE = 0.08;
    
    public TaxDecorator(Order order) {
        super(order);
    }
    
    @Override
    public double calculateTotal() {
        return order.calculateTotal() * (1 + TAX_RATE);
    }
}