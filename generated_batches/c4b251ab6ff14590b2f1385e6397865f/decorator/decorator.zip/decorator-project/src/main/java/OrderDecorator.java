public abstract class OrderDecorator extends Order {
    protected Order order;
    
    public OrderDecorator(Order order) {
        super(order.getOrderId(), order.basePrice);
        this.order = order;
    }
    
    @Override
    public abstract double calculateTotal();
}