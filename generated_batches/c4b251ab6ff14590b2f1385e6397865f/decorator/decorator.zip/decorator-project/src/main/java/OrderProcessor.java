public class OrderProcessor {
    public static void main(String[] args) {
        // Create basic order
        Order order = new BasicOrder("ORD001", 25.00);
        
        // Add decorators to enhance the order
        order = new TaxDecorator(order);
        order = new DeliveryFeeDecorator(order);
        
        System.out.println("Total cost: $" + String.format("%.2f", order.calculateTotal()));
    }
}