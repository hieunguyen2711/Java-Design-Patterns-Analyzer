public abstract class Order {
    protected String orderId;
    protected double basePrice;
    
    public Order(String orderId, double basePrice) {
        this.orderId = orderId;
        this.basePrice = basePrice;
    }
    
    public abstract double calculateTotal();
    
    public String getOrderId() {
        return orderId;
    }
}