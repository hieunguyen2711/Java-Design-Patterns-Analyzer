public class DeliveryFeeDecorator extends OrderDecorator {
    private static final double DELIVERY_FEE = 2.50;
    
    public DeliveryFeeDecorator(Order order) {
        super(order);
    }
    
    @Override
    public double calculateTotal() {
        return order.calculateTotal() + DELIVERY_FEE;
    }
}