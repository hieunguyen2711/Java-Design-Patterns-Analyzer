public class BasicOrder extends Order {
    public BasicOrder(String orderId, double basePrice) {
        super(orderId, basePrice);
    }
    
    @Override
    public double calculateTotal() {
        return basePrice;
    }
}