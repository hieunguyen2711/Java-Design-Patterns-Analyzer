public class RestaurantManager {
    private static volatile RestaurantManager instance;
    
    private RestaurantManager() {
        // Private constructor to prevent instantiation
    }
    
    public static RestaurantManager getInstance() {
        if (instance == null) {
            synchronized (RestaurantManager.class) {
                if (instance == null) {
                    instance = new RestaurantManager();
                }
            }
        }
        return instance;
    }
    
    public void processOrder(Order order) {
        System.out.println("Processing order: " + order.getId());
        // Business logic for order processing
    }
}