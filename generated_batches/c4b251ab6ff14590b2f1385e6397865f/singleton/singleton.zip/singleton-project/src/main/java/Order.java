public class Order {
    private String id;
    private String customerId;
    private double totalAmount;
    
    public Order(String id, String customerId, double totalAmount) {
        this.id = id;
        this.customerId = customerId;
        this.totalAmount = totalAmount;
    }
    
    public String getId() {
        return id;
    }
    
    public String getCustomerId() {
        return customerId;
    }
    
    public double getTotalAmount() {
        return totalAmount;
    }
}