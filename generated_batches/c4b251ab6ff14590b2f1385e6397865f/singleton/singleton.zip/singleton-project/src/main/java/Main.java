public class Main {
    public static void main(String[] args) {
        // Get the singleton instance
        RestaurantManager manager1 = RestaurantManager.getInstance();
        RestaurantManager manager2 = RestaurantManager.getInstance();
        
        // Verify it's the same instance
        System.out.println("Same instance: " + (manager1 == manager2));
        
        // Process an order using the singleton
        Order order = new Order("ORD001", "CUST001", 45.99);
        manager1.processOrder(order);
    }
}