package restaurant.model;

public class DeliveryOrder extends Order {
    private String deliveryAddress;
    private double deliveryFee;
    
    public DeliveryOrder(String orderId, double totalAmount, String deliveryAddress, double deliveryFee) {
        super(orderId, totalAmount);
        this.deliveryAddress = deliveryAddress;
        this.deliveryFee = deliveryFee;
    }
    
    @Override
    public void processOrder() {
        System.out.println("Processing delivery order #" + orderId + " to " + deliveryAddress);
        status = OrderStatus.PROCESSING;
    }
    
    public String getDeliveryAddress() {
        return deliveryAddress;
    }
    
    public double getDeliveryFee() {
        return deliveryFee;
    }
}