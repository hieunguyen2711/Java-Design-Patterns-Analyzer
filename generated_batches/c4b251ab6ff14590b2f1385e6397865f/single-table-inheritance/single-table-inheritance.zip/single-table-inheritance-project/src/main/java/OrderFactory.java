package restaurant.model;

public class OrderFactory {
    public static Order createOrder(OrderType type, String orderId, double totalAmount, 
                                  String details1, String details2) {
        switch (