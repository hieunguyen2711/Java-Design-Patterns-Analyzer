package restaurant.model;

public class PickupOrder extends Order {
    private String pickupTime;
    private String customerName;
    
    public PickupOrder(String orderId, double totalAmount, String pickupTime, String customerName) {
        super(orderId, totalAmount);
        this.pickupTime = pickupTime;
        this.customerName = customerName;
    }
    
    @Override
    public void processOrder() {
        System.out.println("Processing pickup order #" + orderId + " for " + customerName);
        status = OrderStatus.PROCESSING;
    }
    
    public String getPickupTime() {
        return pickupTime;
    }
    
    public String getCustomerName() {
        return customerName;
    }
}