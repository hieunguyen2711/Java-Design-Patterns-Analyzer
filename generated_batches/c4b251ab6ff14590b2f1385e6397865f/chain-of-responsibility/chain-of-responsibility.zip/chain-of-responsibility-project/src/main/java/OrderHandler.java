public abstract class OrderHandler {
    protected OrderHandler nextHandler;

    public void setNext(OrderHandler handler) {
        this.nextHandler = handler;
    }

    public abstract boolean handleOrder(Order order);

    protected boolean processNext(Order order) {
        if (nextHandler != null) {
            return nextHandler.handleOrder(order);
        }
        return false;
    }
}