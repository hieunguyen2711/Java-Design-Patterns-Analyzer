public class CustomerVerificationHandler extends OrderHandler {
    @Override
    public boolean handleOrder(Order order) {
        // Simulate customer verification logic
        if (order.getOrderId() == null || order.getOrderId().isEmpty()) {
            System.out.println("Customer verification failed: Invalid order ID");
            return false;
        }
        
        System.out.println("Customer verification passed");
        return processNext(order);
    }
}