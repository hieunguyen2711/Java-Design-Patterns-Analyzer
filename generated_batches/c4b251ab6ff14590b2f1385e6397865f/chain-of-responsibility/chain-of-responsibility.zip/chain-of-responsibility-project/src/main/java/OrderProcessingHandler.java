public class OrderProcessingHandler extends OrderHandler {
    @Override
    public boolean handleOrder(Order order) {
        if (order.getStatus().equals("PENDING")) {
            order.setStatus("PROCESSING");
            System.out.println("Order processing started");
            return true;
        }
        
        System.out.println("Order already processed");
        return false;
    }
}