package restaurant.service;

import restaurant.model.MenuItem;
import restaurant.repository.MenuRepository;

public class OrderService {
    
    public MenuItem getMenuItem(String id) {
        MenuItem item = MenuRepository.findById(id);
        if (item == null) {
            // Simulate loading from database
            item = new MenuItem(id, "Item " + id, 10.0);
            MenuRepository.save(item);
        }
        return item;
    }
    
    public void processOrder(String menuItemId) {
        MenuItem item1 = getMenuItem(menuItemId);
        MenuItem item2 = getMenuItem(menuItemId);
        
        // Identity map ensures same object reference
        System.out.println("Same object? " + (item1 == item2));
        System.out.println("Item name: " + item1.getName());
    }
}