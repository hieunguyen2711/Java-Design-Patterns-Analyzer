package restaurant.repository;

import restaurant.model.MenuItem;
import java.util.HashMap;
import java.util.Map;

public class MenuRepository {
    private static final Map<String, MenuItem> menuItems = new HashMap<>();
    
    public static MenuItem findById(String id) {
        return menuItems.get(id);
    }
    
    public static MenuItem save(MenuItem item) {
        menuItems.put(item.getId(), item);
        return item;
    }
    
    public static void clearCache() {
        menuItems.clear();
    }
}