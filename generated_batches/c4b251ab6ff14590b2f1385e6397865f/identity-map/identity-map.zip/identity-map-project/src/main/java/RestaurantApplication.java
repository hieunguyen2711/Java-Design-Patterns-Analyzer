package restaurant;

import restaurant.service.OrderService;

public class RestaurantApplication {
    public static void main(String[] args) {
        OrderService