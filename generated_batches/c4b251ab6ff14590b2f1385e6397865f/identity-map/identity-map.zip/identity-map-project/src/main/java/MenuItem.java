package restaurant.model;

public class MenuItem {
    private final String id;
    private final String name;
    private final double price;
    
    public MenuItem(String id, String name, double price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }
    
    public String getId() {
        return id;
    }
    
    public String getName() {
        return name;
    }
    
    public double getPrice() {
        return price;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        MenuItem menuItem = (MenuItem) obj;
        return id.equals(menuItem.id);
    }
    
    @Override
    public int hashCode() {
        return id.hashCode();
    }
}