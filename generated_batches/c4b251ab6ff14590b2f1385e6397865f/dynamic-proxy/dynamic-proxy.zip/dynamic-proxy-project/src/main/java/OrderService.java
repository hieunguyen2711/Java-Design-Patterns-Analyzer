public interface OrderService {
    void placeOrder(String customerId, String menuItem);
    void updateOrderStatus(String orderId, String status);
    String getOrderStatus(String orderId);
}