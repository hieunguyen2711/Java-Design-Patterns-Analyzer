public class RealOrderService implements OrderService {
    @Override
    public void placeOrder(String customerId, String menuItem) {
        System.out.println("Placing order for customer " + customerId + 
                          " with menu item: " + menuItem);
    }
    
    @Override
    public void updateOrderStatus(String orderId, String status) {
        System.out.println("Updating order " + orderId + " status to: " + status);
    }
    
    @Override
    public String getOrderStatus(String orderId) {
        return "Order " + orderId + " is being processed";
    }
}