import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class OrderServiceInvocationHandler implements InvocationHandler {
    private final OrderService realService;
    
    public OrderServiceInvocationHandler(OrderService realService) {
        this.realService = realService;
    }
    
    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        System.out.println("Before method: " + method.getName());
        
        Object result = method.invoke(realService, args);
        
        System.out.println("After method: " + method.getName());
        return result;
    }
}