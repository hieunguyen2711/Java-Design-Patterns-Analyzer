import java.lang.reflect.Proxy;

public class OrderServiceProxyFactory {
    public static OrderService createOrderServiceProxy(OrderService realService) {
        return (OrderService) Proxy.newProxyInstance(
            OrderService.class.getClassLoader(),
            new Class[]{OrderService.class},
            new OrderServiceInvocationHandler(realService)
        );
    }
}