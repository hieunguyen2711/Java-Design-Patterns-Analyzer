public class Main {
    public static void main(String[] args) {
        OrderService realService = new RealOrderService();
        OrderService proxyService = OrderServiceProxyFactory.createOrderServiceProxy(realService);
        
        System.out.println("=== Using Proxy Service ===");
        proxyService.placeOrder("CUST001", "Margherita Pizza");
        proxyService.updateOrderStatus("ORD001", "PREPARING");
        String status = proxyService.getOrderStatus("ORD001");