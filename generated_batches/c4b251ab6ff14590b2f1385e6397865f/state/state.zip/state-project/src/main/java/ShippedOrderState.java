package restaurant.order;

public class ShippedOrderState implements OrderState {
    @Override
    public void process(Order order) {
        System.out.println("Order is already processed and shipped");
    }
    
    @Override
    public void ship(Order order) {
        System.out.println("Order is already shipped");
    }
    
    @Override
    public void deliver(Order order) {
        System.out.println("Order is being delivered...");
        order.setState(new DeliveredOrderState());
    }
}