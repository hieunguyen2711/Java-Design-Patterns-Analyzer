package restaurant.order;

public class NewOrderState implements OrderState {
    @Override
    public void process(Order order) {
        System.out.println("Order is being processed...");
        order.setState(new ProcessingOrderState());
    }
    
    @Override
    public void ship(Order order) {
        System.out.println("Cannot ship unprocessed order");
    }
    
    @Override
    public void deliver(Order order) {
        System.out.println("Cannot deliver unprocessed order");
    }
}