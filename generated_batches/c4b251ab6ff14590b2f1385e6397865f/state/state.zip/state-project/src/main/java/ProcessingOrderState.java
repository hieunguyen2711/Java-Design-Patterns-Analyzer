package restaurant.order;

public class ProcessingOrderState implements OrderState {
    @Override
    public void process(Order order) {
        System.out.println("Order is already being processed...");
    }
    
    @Override
    public void ship(Order order) {
        System.out.println("Order is being shipped...");
        order.setState(new ShippedOrderState());
    }
    
    @Override
    public void deliver(Order order) {
        System.out.println("Cannot deliver unshipped order");
    }
}