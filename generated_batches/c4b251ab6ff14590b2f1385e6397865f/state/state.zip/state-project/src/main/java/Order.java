package restaurant.order;

public class Order {
    private OrderState state;
    
    public Order() {
        this.state = new NewOrderState();
    }
    
    public void setState(OrderState state) {
        this.state = state;
    }
    
    public void process() {
        state.process(this);
    }
    
    public void ship() {
        state.ship(this);
    }
    
    public void deliver() {
        state.deliver(this);
    }
    
    public String getStatus() {
        return state.getClass().getSimpleName();
    }
}