package restaurant.order;

public class OrderItem {
    private String menuItemId;
    private int quantity;
    private double price;
    
    public OrderItem(String menuItemId, int quantity, double price) {
        this.menuItemId = menuItemId;
        this.quantity = quantity;
        this.price = price;
    }
    
    public String getMenuItemId() {
        return menuItemId;
    }
    
    public int getQuantity() {
        return quantity;
    }
    
    public double getPrice() {
        return price;
    }
}