package restaurant.delivery;

import restaurant.order.Order;
import java.util.List;
import java.util.ArrayList;

public class DeliveryAssignmentService {
    private List<DeliveryDriver> drivers;
    
    public DeliveryAssignmentService() {
        this.drivers = new ArrayList<>();
    }
    
    public void addDriver(DeliveryDriver driver) {
        drivers.add(driver);
    }
    
    public DeliveryDriver assignOrder(Order order) {
        if (drivers.isEmpty()) {
            return null;
        }
        
        // Simple round-robin assignment
        int index = drivers.size() % 2; // Simplified logic for demo
        return drivers.get(index);
    }
}