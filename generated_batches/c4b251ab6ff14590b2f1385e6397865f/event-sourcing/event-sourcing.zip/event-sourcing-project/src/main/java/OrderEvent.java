public abstract class OrderEvent {
    private final String orderId;
    private final long timestamp;

    public OrderEvent(String orderId) {
        this.orderId = orderId;
        this.timestamp = System.currentTimeMillis();
    }

    public String getOrderId() {
        return orderId;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public abstract String getType();
}