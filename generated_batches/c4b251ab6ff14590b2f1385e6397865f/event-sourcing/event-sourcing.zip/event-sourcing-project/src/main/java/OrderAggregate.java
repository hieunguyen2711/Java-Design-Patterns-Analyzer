import java.util.*;

public class OrderAggregate {
    private final String orderId;
    private String status = "CREATED";
    private String customerId;
    private List<String> menuItems = new ArrayList<>();
    private final EventStore eventStore;

    public OrderAggregate(String orderId, EventStore eventStore) {
        this.orderId = orderId;
        this.eventStore = eventStore;
    }

    public void createOrder(String customerId, List<String> items) {
        this.customerId = customerId;