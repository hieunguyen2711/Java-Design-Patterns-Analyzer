import java.util.*;

public class EventStore {
    private final Map<String, List<OrderEvent>> events = new HashMap<>();

    public void save(String orderId, OrderEvent event) {
        events.computeIfAbsent(orderId, k -> new ArrayList<>()).add(event);
    }

    public List<OrderEvent> getEventsForOrder(String orderId) {
        return events.getOrDefault(orderId, Collections.emptyList());
    }

    public void clear() {
        events.clear();
    }
}