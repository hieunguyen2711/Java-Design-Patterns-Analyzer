public class OrderStatusUpdatedEvent extends OrderEvent {
    private final String status;

    public OrderStatusUpdatedEvent(String orderId, String status) {
        super(orderId);
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    @Override
    public String getType() {
        return "ORDER_STATUS_UPDATED";
    }
}