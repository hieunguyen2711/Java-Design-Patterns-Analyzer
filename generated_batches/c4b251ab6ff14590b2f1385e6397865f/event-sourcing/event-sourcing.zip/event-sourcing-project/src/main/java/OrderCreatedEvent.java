public class OrderCreatedEvent extends OrderEvent {
    private final String customerId;
    private final String menuItems;

    public OrderCreatedEvent(String orderId, String customerId, String menuItems) {
        super(orderId);
        this.customerId = customerId;
        this.menuItems = menuItems;
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getMenuItems() {
        return menuItems;
    }

    @Override
    public String getType() {
        return "ORDER_CREATED";
    }
}