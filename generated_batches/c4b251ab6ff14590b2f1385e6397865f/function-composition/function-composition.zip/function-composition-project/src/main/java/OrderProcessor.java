package restaurant.backend;

import java.util.function.Function;
import java.util.List;
import java.util.ArrayList;

public class OrderProcessor {
    private final List<Function<Order, Order>> processors;
    
    public OrderProcessor() {
        this.processors = new ArrayList<>();
    }
    
    public void addProcessor(Function<Order, Order> processor) {
        processors.add(processor);
    }
    
    public Order process(Order order) {
        Order result = order;
        for (Function<Order, Order> processor : processors) {
            result = processor.apply(result);
        }
        return result;
    }
}