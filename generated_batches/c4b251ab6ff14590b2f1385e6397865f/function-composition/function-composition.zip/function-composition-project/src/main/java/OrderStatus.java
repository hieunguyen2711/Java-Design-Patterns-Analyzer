package restaurant.backend;

public enum OrderStatus {
    RECEIVED,
    PREPARING,
    READY,
    DELIVERING,
    DELIVERED
}