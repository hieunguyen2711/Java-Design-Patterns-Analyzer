package restaurant.backend;

import java.util.function.Function;

public class CookingProcessor {
    public static final Function<Order, Order> START_COOKING = 
        order -> {
            // Simulate cooking process
            System.out.println("Starting to cook order " + order.getId());
            order.setStatus(OrderStatus.PREPARING);
            return order;
        };
    
    public static final Function<Order, Order> MARK_READY = 
        order -> {
            // Simulate