package restaurant.backend;

import java.util.function.Function;

public class PaymentProcessor {
    public static final Function<Order, Order> PROCESS_PAYMENT = 
        order -> {
            // Simulate payment processing
            System.out.println("Processing payment for order " + order.getId());
            return order;
        };
}