package restaurant.backend;

import java.util.List;
import java.util.ArrayList;

public class Order {
    private final String id;
    private final List<String> items;
    private OrderStatus status;
    
    public Order(String id) {
        this.id = id;
        this.items = new ArrayList<>();
        this.status = OrderStatus.RECEIVED;
    }
    
    public void addItem(String item) {
        items.add(item);
    }
    
    public String getId() {
        return id;
    }
    
    public List<String> getItems() {
        return items;
    }
    
    public OrderStatus getStatus() {
        return status;
    }
    
    public void setStatus(OrderStatus status) {
        this.status = status;
    }
}