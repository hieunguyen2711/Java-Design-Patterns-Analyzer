package com.restaurant.service;

public enum OrderStatus {
    PENDING,
    PREPARING,
    READY,
    DELIVERED
}