package com.restaurant.service;

import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

public class OrderService {
    private static volatile OrderService instance;
    private final Map<String, Order> activeOrders;
    
    private OrderService() {
        this.activeOrders = new ConcurrentHashMap<>();
    }
    
    public static OrderService getInstance() {
        if (instance == null) {
            synchronized (OrderService.class) {
                if (instance == null) {
                    instance = new OrderService();
                }
            }
        }
        return instance;
    }
    
    public void addOrder(Order order) {
        activeOrders.put(order.getId(), order);
    }
    
    public Order getOrder(String orderId) {
        return activeOrders.get(orderId);
    }
}