import java.util.ArrayList;
import java.util.List;

public class RestaurantBackend {
    private final OrderProcessor orderProcessor;
    private final List<Order> orders;
    
    public RestaurantBackend() {
        this.orderProcessor = new OrderProcessor();
        this.orders = new ArrayList<>();
    }
    
    public void submitOrder(String orderId) {
        Order order = new Order(orderId);
        orders.add(order);
        orderProcessor.processOrder(order);
    }
    
    public void shutdown() {
        orderProcessor.shutdown();
    }
    
    public static void main(String[] args) {
        RestaurantBackend backend = new RestaurantBackend();
        
        // Submit several orders
        for (int i = 1; i <= 5; i++) {
            backend.submitOrder("ORDER-" + i);