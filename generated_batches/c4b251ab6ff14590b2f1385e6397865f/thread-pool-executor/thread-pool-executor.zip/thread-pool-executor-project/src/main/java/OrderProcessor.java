import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class OrderProcessor {
    private final ExecutorService executorService;
    
    public OrderProcessor() {
        this.executorService = Executors.newFixedThreadPool(3);
    }
    
    public void processOrder(Order order) {
        executorService.submit(() -> {
            System.out.println("Processing order: " + order.getId());
            try {
                Thread.sleep(1000); // Simulate processing time
                order.setStatus(OrderStatus.PROCESSED);
                System.out.println("Order processed: " + order.getId());
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
    }
    
    public void shutdown() {
        executorService.shutdown();
        try {
            if (!executorService.awaitTermination(60, TimeUnit.SECONDS)) {
                executorService.shutdownNow();
            }
        } catch (InterruptedException e) {
            executorService.shutdownNow();
        }
    }
}