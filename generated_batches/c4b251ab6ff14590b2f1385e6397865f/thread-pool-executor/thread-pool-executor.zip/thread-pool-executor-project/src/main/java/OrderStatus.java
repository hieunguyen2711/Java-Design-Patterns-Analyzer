public enum OrderStatus {
    PENDING,
    PROCESSED,
    DELIVERED
}