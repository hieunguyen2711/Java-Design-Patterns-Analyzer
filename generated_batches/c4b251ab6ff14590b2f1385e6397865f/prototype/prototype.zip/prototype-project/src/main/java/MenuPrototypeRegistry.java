package restaurant.menu;

import java.util.HashMap;
import java.util.Map;

public class MenuPrototypeRegistry {
    private Map<String, MenuItem> prototypes = new HashMap<>();
    
    public MenuPrototypeRegistry() {
        initializePrototypes();
    }
    
    private void initializePrototypes() {
        prototypes.put("pizza", new MenuItem("Margherita Pizza", 12.99, "Main Course"));
        prototypes.put("salad", new MenuItem("Caesar Salad", 8.50, "Appetizer"));
        prototypes.put("coffee", new MenuItem("Espresso", 3.25, "Beverage"));
    }
    
    public MenuItem createMenuItem(String type) {
        try {
            MenuItem prototype = prototypes.get(type);
            if (prototype != null) {
                return prototype.clone();
            }
            return null;
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException("Failed to clone menu item", e);
        }
    }
}