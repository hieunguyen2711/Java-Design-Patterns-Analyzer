package restaurant.menu;

public class MenuItem implements Cloneable {
    private String name;
    private double price;
    private String category;
    
    public MenuItem(String name, double price, String category) {
        this.name = name;
        this.price = price;
        this.category = category;
    }
    
    @Override
    public MenuItem clone() throws CloneNotSupportedException {
        return (MenuItem) super.clone();
    }
    
    // Getters and setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
}