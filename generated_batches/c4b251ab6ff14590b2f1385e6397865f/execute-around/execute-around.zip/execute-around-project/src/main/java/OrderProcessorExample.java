package restaurant.backend;

import java.util.concurrent.CompletableFuture;

public class OrderProcessorExample {
    public static void main(String[] args) {
        OrderProcessor processor = new OrderProcessor();
        OrderValidator validator = new OrderValidator();
        
        // Example 1: Synchronous processing with execute-around pattern
        Order order1 = new