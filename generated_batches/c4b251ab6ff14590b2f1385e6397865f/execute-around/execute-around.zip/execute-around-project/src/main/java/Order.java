package restaurant.backend;

public class Order {
    private final String id;
    private final String customerName;
    private final double totalAmount;
    
    public Order(String id, String customerName, double totalAmount) {
        this.id = id;
        this.customerName = customerName;
        this.totalAmount = totalAmount;
    }
    
    public String getId() {
        return id;
    }
    
    public String getCustomerName() {
        return customerName;
    }
    
    public double getTotalAmount() {
        return totalAmount;
    }
}