package restaurant.backend;

import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

public class OrderProcessor {
    public void processOrder(Order order, Consumer<Order> processor) {
        // Simulate order processing with execute-around pattern
        System.out.println("Starting order processing for: " + order.getId());
        
        try {
            // Execute-around pattern - wrap the actual processing
            processor.accept(order);
            
            System.out.println("Completed order processing for: " + order.getId());
        } catch (Exception e) {
            System.err.println("Error processing order: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }
    
    public CompletableFuture<Order> processOrderAsync(Order order, Consumer<Order> processor) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                processor.accept(order);
                return order;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
    }
}