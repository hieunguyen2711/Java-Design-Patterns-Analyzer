package restaurant.backend;

public class OrderValidator {
    public void validate(Order order) throws IllegalArgumentException {
        if (order == null) {
            throw new IllegalArgumentException("Order cannot be null");
        }
        if (order.getId() == null || order.getId().isEmpty()) {
            throw new IllegalArgumentException("Order ID is required");
        }
        if (order.getTotalAmount() <= 0) {
            throw new IllegalArgumentException("Order total must be positive");
        }
    }
}