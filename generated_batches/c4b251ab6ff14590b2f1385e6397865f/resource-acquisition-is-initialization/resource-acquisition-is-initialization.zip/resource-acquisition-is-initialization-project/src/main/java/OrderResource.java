package restaurant;

public class OrderResource implements AutoCloseable {
    private final Order order;
    private boolean isOpen = true;
    
    public OrderResource(Order order) {
        this.order = order;
        System.out.println("Acquiring resources for order: " + order.getOrderId());
    }
    
    @Override
    public void close() {
        if (isOpen) {
            isOpen = false;
            System.out.println("Releasing resources for order: " + order.getOrderId());
        }
    }
}