package restaurant;

public class RestaurantService {
    public static void main(String[] args) {
        try {
            Order order1 = new Order("ORD-001", "CUST-123");
            OrderProcessor processor1 = new OrderProcessor(order1);
            
            Order order2 = new Order("ORD-002", "CUST-456");
            OrderProcessor processor2 = new OrderProcessor(order2);
            
            processor1.process();
            processor2.process();