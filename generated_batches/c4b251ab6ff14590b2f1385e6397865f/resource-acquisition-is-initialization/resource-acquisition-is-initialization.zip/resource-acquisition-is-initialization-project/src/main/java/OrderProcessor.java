package restaurant;

import java.util.concurrent.atomic.AtomicBoolean;

public class OrderProcessor {
    private final Order order;
    private final AtomicBoolean isProcessing = new AtomicBoolean(false);
    
    public OrderProcessor(Order order) {
        this.order = order;
    }
    
    public void process() throws Exception {
        // RAII pattern: acquire resources at construction and release at cleanup
        try (OrderResource resource = new OrderResource(order)) {
            if (!isProcessing.compareAndSet(false, true)) {
                throw new IllegalStateException("Order already being processed");
            }
            
            // Simulate processing work
            Thread.sleep(100);
            System.out.println("Processing order: " + order.getOrderId());
        } catch (Exception e) {
            throw new Exception("Failed to process order: " + order.getOrderId(), e);
        } finally {
            isProcessing.set(false);
        }
    }
}