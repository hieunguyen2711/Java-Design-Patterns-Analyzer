public interface OrderService {
    void placeOrder(String customerId, String menuItem);
    String getOrderStatus(String orderId);
}