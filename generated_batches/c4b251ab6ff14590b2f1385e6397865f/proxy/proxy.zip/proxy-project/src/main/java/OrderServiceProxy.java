public class OrderServiceProxy implements OrderService {
    private RealOrderService realOrderService;
    private String currentUser;
    
    public OrderServiceProxy(String currentUser) {
        this.currentUser = currentUser;
    }
    
    @Override
    public void placeOrder(String customerId, String menuItem) {
        if (canAccess(customerId)) {
            System.out.println("Proxy: Validating access for user " + currentUser);
            getRealOrderService().placeOrder(customerId, menuItem);
        } else {
            System.out.println("Proxy: Access denied for user " + currentUser + 
                             " to place order for customer " + customerId);
        }
    }
    
    @Override
    public String getOrderStatus(String orderId) {
        if (canAccess(orderId)) {
            System.out.println("Proxy: Validating access for user " + currentUser);
            return getRealOrderService().getOrderStatus(orderId);
        } else {
            System.out.println("Proxy: Access denied for user " + currentUser + 
                             " to check order status for " + orderId);
            return "Access Denied";
        }
    }
    
    private RealOrderService getRealOrderService() {
        if (realOrderService == null) {
            realOrderService = new RealOrderService