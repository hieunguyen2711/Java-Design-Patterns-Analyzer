public class RealOrderService implements OrderService {
    private static int orderCounter = 1000;
    
    @Override
    public void placeOrder(String customerId, String menuItem) {
        System.out.println("Placing order for customer " + customerId + 
                          " with menu item: " + menuItem);
        // Simulate order processing
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        System.out.println("Order placed successfully. Order ID: " + (++orderCounter));
    }
    
    @Override
    public String getOrderStatus(String orderId) {
        System.out.println("Checking status for order: " + orderId);
        // Simulate database lookup
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return "Order " + orderId + " is being prepared";
    }
}