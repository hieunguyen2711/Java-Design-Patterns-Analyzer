package restaurant.order;

public class OrderService {
    
    public static void main(String[] args) {
        // Using the builder pattern to create an order
        Order order = new Order.Builder()
                .setOrderId("ORD-001")
                .setCustomerId("CUST-123")
                .setMenuItems("Pizza Margherita, Coca Cola")
                .setDeliveryAddress("123 Main St, Cityville")
                .build();
        
        System.out.println("Order created: " + order.getOrderId());
        System.out.println("Customer: " + order.getCustomerId());
        System.out.println("Items: " + order.getMenu