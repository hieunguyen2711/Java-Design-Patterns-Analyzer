package restaurant.order;

public class Order {
    private final String orderId;
    private final String customerId;
    private final String menuItems;
    private final String deliveryAddress;
    private final boolean isDelivered;
    
    private Order(Builder builder) {
        this.orderId = builder.orderId;
        this.customerId = builder.customerId;
        this.menuItems = builder.menuItems;
        this.deliveryAddress = builder.deliveryAddress;
        this.isDelivered = builder.isDelivered;
    }
    
    public String getOrderId() {
        return orderId;
    }
    
    public String getCustomerId() {
        return customerId;
    }
    
    public String getMenuItems() {
        return menuItems;
    }
    
    public String getDeliveryAddress() {
        return deliveryAddress;
    }
    
    public boolean isDelivered() {
        return isDelivered;
    }
    
    public static class Builder {
        private String orderId;
        private String customerId;
        private String menuItems;
        private String deliveryAddress;
        private boolean isDelivered = false;
        
        public Builder setOrderId(String orderId) {
            this.orderId = orderId;
            return this;
        }
        
        public Builder setCustomerId(String customerId) {
            this.customerId = customerId;
            return this;
        }
        
        public Builder setMenuItems(String menuItems) {
            this.menuItems = menuItems;
            return this;
        }
        
        public Builder setDeliveryAddress(String deliveryAddress) {
            this.deliveryAddress = deliveryAddress;
            return this;
        }
        
        public Builder setDelivered(boolean delivered) {
            isDelivered = delivered;
            return this;
        }
        
        public Order build() {
            return new Order(this);
        }
    }
}