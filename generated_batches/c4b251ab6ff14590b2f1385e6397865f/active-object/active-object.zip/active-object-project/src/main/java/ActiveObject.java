public interface ActiveObject {
    void submitOrder(String orderId, String customerId);
    void updateOrderStatus(String orderId, String status);
    void assignDelivery(String orderId, String driverId);
}