package restaurant.order;

import java.util.HashMap;
import java.util.Map;

public class OrderService {
    private static Map<Integer, Order> orders = new HashMap<>();
    private static int nextOrderId = 1;

    public static void createOrder(String customerId, double amount) {
        // Transaction script: all order creation logic in one method
        Order order = new Order(nextOrderId++, customerId, amount);
        orders.put(order.getOrderId(), order);
        
        System.out.println("Order created with ID: " + order.getOrderId());
    }

    public static void confirmOrder(int orderId) {
        // Transaction script: all order confirmation logic in one method
        Order order = orders.get(orderId);
        if (order != null && order.getStatus() == OrderStatus.PENDING) {
            order.setStatus(OrderStatus.CONFIRMED);
            System.out.println("Order " + orderId + " confirmed");
        }
    }

    public static void prepareOrder(int orderId) {
        // Transaction script: all order preparation logic in one method
        Order order = orders.get(orderId);
        if (order != null && order.getStatus() == OrderStatus.CONFIRMED) {
            order.setStatus(OrderStatus.P