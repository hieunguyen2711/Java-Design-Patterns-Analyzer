package restaurant.converter;

import java.util.List;

public class OrderProcessor {
    
    public RestaurantOrder processMenuItems(List<MenuItem> menuItems) {
        RestaurantOrder order = new RestaurantOrder();
        
        for (MenuItem item : menuItems) {
            OrderItem orderItem = MenuItemConverter.convert(item);
            order.addItem(orderItem);
        }
        
        return order;
    }
    
    public RestaurantOrder processMenuItemsWithQuantities(List<MenuItem> menuItems, List<Integer> quantities) {
        RestaurantOrder order = new RestaurantOrder();
        
        for (int i = 0; i < menuItems.size(); i++) {
            MenuItem