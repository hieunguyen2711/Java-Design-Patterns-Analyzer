package restaurant.converter;

import java.util.ArrayList;
import java.util.List;

public class RestaurantOrder {
    private List<OrderItem> items;
    
    public RestaurantOrder() {
        this.items = new ArrayList<>();
    }
    
    public void addItem(OrderItem item) {
        items.add(item);
    }
    
    public List<OrderItem> getItems() {
        return items;
    }
}