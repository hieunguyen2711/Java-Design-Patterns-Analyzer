package restaurant.converter;

public class MenuItemConverter {
    
    public static OrderItem convert(MenuItem menuItem) {
        return new OrderItem(menuItem.getName(), 1, menuItem.getPrice());
    }
    
    public static OrderItem convert(MenuItem menuItem, int quantity) {
        return new OrderItem(menuItem.getName(), quantity, menuItem.getPrice());
    }
}