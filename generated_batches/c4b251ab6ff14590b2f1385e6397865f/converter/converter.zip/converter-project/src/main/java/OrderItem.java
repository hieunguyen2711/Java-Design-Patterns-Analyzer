package restaurant.converter;

public class OrderItem {
    private String itemName;
    private int quantity;
    private double itemPrice;
    
    public OrderItem(String itemName, int quantity, double itemPrice) {
        this.itemName = itemName;
        this.quantity = quantity;
        this.itemPrice = itemPrice;
    }
    
    public String getItemName() {
        return itemName;
    }
    
    public int getQuantity() {
        return quantity;
    }
    
    public double getItemPrice() {
        return itemPrice;
    }
}