package restaurant.order;

public class Order {
    private String orderId;
    private OrderStatus status;
    
    public Order(String orderId) {
        this.orderId = orderId;
        this.status = new PendingOrderStatus();
    }
    
    public void setStatus(OrderStatus status) {
        this.status = status;
    }
    
    public void process() {
        status.handle(this);
    }
    
    public String getOrderId() {
        return orderId;
    }
}