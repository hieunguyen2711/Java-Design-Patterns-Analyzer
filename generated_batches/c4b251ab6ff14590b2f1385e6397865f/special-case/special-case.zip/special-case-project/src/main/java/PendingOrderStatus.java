package restaurant.order;

public class PendingOrderStatus implements OrderStatus {
    @Override
    public void handle(Order order) {
        System.out.println("Processing pending order " + order.getOrderId());
        // Transition to preparing status
        order.setStatus(new PreparingOrderStatus());
    }
}