package restaurant.order;

public class SpecialCasePatternDemo {
    public static void main(String[] args) {
        Order order = new Order("ORD-001");
        
        // Process the order through its lifecycle
        order.process();  // Pending -> Preparing
        order.process();  // Preparing -> Ready
        order.process();  // Ready -> Completed
        order.process();  // Completed (special case - no transition)
    }