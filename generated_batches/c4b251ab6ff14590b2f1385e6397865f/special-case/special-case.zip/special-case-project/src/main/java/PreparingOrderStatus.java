package restaurant.order;

public class PreparingOrderStatus implements OrderStatus {
    @Override
    public void handle(Order order) {
        System.out.println("Preparing order " + order.getOrderId());
        // Transition to ready status
        order.setStatus(new ReadyOrderStatus());
    }
}