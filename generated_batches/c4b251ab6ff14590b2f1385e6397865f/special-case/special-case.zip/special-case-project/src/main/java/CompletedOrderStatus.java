package restaurant.order;

public class CompletedOrderStatus implements OrderStatus {
    @Override
    public void handle(Order order) {
        System.out.println("Order " + order.getOrderId() + " has been completed");
    }
}