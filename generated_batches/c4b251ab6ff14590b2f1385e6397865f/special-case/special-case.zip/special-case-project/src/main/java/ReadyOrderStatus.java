package restaurant.order;

public class ReadyOrderStatus implements OrderStatus {
    @Override
    public void handle(Order order) {
        System.out.println("Order " + order.getOrderId() + " is ready for pickup");
        // Transition to completed status
        order.setStatus(new CompletedOrderStatus());
    }
}