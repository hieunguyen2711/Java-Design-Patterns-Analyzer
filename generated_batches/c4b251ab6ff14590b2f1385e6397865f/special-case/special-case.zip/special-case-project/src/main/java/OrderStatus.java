package restaurant.order;

public interface OrderStatus {
    void handle(Order order);
}