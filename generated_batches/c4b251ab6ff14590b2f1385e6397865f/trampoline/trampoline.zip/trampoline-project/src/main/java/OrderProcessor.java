package restaurant.order;

import java.util.List;
import java.util.ArrayList;

public class OrderProcessor {
    
    public static Trampoline<OrderStatus> processOrder(Order order) {
        if (order.getItems().isEmpty()) {
            return Trampoline.done(new OrderStatus("ORDER_CANCELLED", "No items in order"));
        }
        
        List<Trampoline<OrderStatus>> steps = new ArrayList<>();
        steps.add(verifyInventory(order));
        steps.add(prepareFood(order));
        steps.add(packOrder(order));
        steps.add(assignDelivery(order));
        
        return processSteps(steps, 0);
    }
    
    private static Trampoline<OrderStatus> processSteps(List<Trampoline<OrderStatus>> steps, int index) {
        if (index >= steps.size()) {
            return Trampoline.done(new OrderStatus("ORDER_COMPLETED", "Order processed successfully"));
        }
        
        return Trampoline.suspend(() -> 
            steps.get(index).run().done() ? 
                processSteps(steps, index + 1) : 
                steps.get(index)
        );
    }
    
    private static Trampoline<OrderStatus> verifyInventory(Order order) {
        // Simulate