package restaurant.order;

@FunctionalInterface
public interface Trampoline<T> {
    Result<T> run();
    
    static <T> Trampoline<T> done(T value) {
        return () -> new Result<>(true, value, null);
    }
    
    static <T> Trampoline<T> suspend(Trampoline<T> trampoline) {
        return () -> new Result<>(false, null, trampoline);
    }
    
    default T getResult() {
        Trampoline<T> current = this;
        while (true) {
            Result<T> result = current.run();
            if (result.done()) {
                return result.value();
            } else {
                current = result.next();
            }
        }
    }
    
    class Result<T> {
        private final boolean done;
        private final T value;
        private final Trampoline<T> next;
        
        public Result(boolean done, T value, Trampoline<T> next) {
            this.done = done;
            this.value = value;
            this.next = next;
        }
        
        public boolean done() {
            return done;
        }
        
        public T value() {
            return value;
        }
        
        public Trampoline<T> next() {
            return next;
        }
    }
}