import java.util.List;
import java.util.ArrayList;

public class Order {
    private String orderId;
    private List<String> items;
    private double totalAmount;
    private OrderStatus status;
    private DeliveryDriver assignedDriver;

    public Order(String orderId, List<String> items, double totalAmount) {
        this.orderId = orderId;
        this.items = new ArrayList<>(items);
        this.totalAmount = totalAmount;
        this.status = OrderStatus.PENDING;
        this.assignedDriver = null;
    }

    public String getOrderId() {
        return orderId;
    }

    public List<String> getItems() {
        return new ArrayList<>(items);
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }

    public DeliveryDriver getAssignedDriver() {
        return assignedDriver;
    }

    public void setAssignedDriver(DeliveryDriver driver) {
        this.assignedDriver = driver;
    }
}