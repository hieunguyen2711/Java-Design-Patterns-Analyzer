import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class OrderPromise {
    private final ExecutorService executor = Executors.newFixedThreadPool(2);
    
    public CompletableFuture<Order> processOrder(Order order) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                // Simulate processing time
                Thread.sleep(1000);
                order.setStatus(OrderStatus.CONFIRMED);