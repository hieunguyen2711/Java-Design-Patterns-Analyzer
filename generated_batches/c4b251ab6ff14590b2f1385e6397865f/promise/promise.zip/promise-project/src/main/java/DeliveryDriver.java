public class DeliveryDriver {
    private String driverId;
    private String name;
    private boolean isAvailable;

    public DeliveryDriver(String driverId, String name) {
        this.driverId = driverId;
        this.name = name;
        this.isAvailable = true;
    }

    public String getDriverId() {
        return driverId;
    }

    public String getName() {
        return name;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }
}