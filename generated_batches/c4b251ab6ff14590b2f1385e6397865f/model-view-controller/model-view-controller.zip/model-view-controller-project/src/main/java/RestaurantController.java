import java.util.List;

public class RestaurantController {
    private final RestaurantModel model;
    private final RestaurantView view;
    
    public RestaurantController(RestaurantModel model, RestaurantView view) {
        this.model = model;
        this.view = view;
    }
    
    public void updateOrderStatus(int orderId, String status) {
        model.updateOrderStatus(orderId, status);
        view.displayOrderStatus(orderId, status);
    }
    
    public void addMenuItem(String name, double price) {
        model.addMenuItem(name, price);
        view.displayMenu(model.getMenu());
    }
    
    public List<MenuItem> getMenu() {
        return model.getMenu();
    }
    
    public Order createOrder(List<Integer> itemIds) {
        return model.createOrder(itemIds);
    }
}