public class AlcoholCheckVisitor implements OrderItemVisitor {
    private boolean hasAlcoholic = false;
    
    @Override
    public void visit(MenuItem menuItem) {
        // Do nothing for non-beverages
    }
    
    @Override
    public void visit(Beverage beverage) {
        if (beverage.isAlcoholic()) {
            hasAlcoholic = true;
        }
    }
    
    @Override
    public void visit(Food food) {
        // Do nothing for food items