public interface OrderItem {
    void accept(OrderItemVisitor visitor);
}