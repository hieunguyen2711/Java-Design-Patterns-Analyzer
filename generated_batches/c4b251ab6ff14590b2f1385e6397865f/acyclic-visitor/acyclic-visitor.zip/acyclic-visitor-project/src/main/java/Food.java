public class Food extends MenuItem {
    private String category;
    
    public Food(String name, double price, String category) {
        super(name, price);
        this.category = category;
    }
    
    public String getCategory() {
        return category;
    }
}