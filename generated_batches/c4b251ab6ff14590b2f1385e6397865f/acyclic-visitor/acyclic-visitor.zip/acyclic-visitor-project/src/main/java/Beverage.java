public class Beverage extends MenuItem {
    private boolean isAlcoholic;
    
    public Beverage(String name, double price, boolean isAlcoholic) {
        super(name, price);
        this.isAlcoholic = isAlcoholic;
    }
    
    public boolean isAlcoholic() {
        return isAlcoholic;
    }
}