public interface OrderItemVisitor {
    void visit(MenuItem menuItem);
    void visit(Beverage beverage);
    void visit(Food food);
}