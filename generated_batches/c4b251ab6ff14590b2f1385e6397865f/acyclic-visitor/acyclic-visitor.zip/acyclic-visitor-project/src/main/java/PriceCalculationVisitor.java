public class PriceCalculationVisitor implements OrderItemVisitor {
    private double totalPrice = 0.0;
    
    @Override
    public void visit(MenuItem menuItem) {
        totalPrice += menuItem.getPrice();
    }
    
    @Override
    public void visit(Beverage beverage) {
        totalPrice += beverage.getPrice();
    }
    
    @Override
    public void visit(Food food) {
        totalPrice += food.getPrice();
    }
    
    public double getTotalPrice() {
        return totalPrice;
    }
}