package restaurant;

public class RestaurantNotificationService implements OrderObserver {
    @Override
    public void update(Order order) {
        System.out.println("Restaurant Notification: Order " + 
                          order.getOrderId() + " is now " + order.getStatus());
    }
}