package restaurant;

public class Customer implements OrderObserver {
    private String customerId;
    private String name;

    public Customer(String customerId, String name) {
        this.customerId = customerId;
        this.name = name;
    }

    @Override
    public void update(Order order) {
        System.out.println("Customer "