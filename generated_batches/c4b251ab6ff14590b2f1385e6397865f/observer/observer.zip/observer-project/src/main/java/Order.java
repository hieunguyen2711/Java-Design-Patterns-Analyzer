package restaurant;

import java.util.ArrayList;
import java.util.List;

public class Order {
    private String orderId;
    private List<OrderObserver> observers;
    private OrderStatus status;

    public Order(String orderId) {
        this.orderId = orderId;
        this.observers = new ArrayList<>();
        this.status = OrderStatus.PENDING;
    }

    public void attach(OrderObserver observer) {
        observers.add(observer);
    }

    public void detach(OrderObserver observer) {
        observers.remove(observer);
    }

    public void notifyObservers() {
        for (OrderObserver observer : observers) {
            observer.update(this);
        }
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
        notifyObservers();
    }

    public String getOrderId() {
        return orderId;
    }
}