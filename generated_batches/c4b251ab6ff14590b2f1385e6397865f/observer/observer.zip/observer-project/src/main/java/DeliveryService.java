package restaurant;

public class DeliveryService implements OrderObserver {
    @Override
    public void update(Order order) {
        if (order.getStatus() == OrderStatus.CONFIRMED) {
            System.out.println("Delivery Service: Assigning delivery driver for order " + 
                              order.getOrderId());
        } else if (order.getStatus() == OrderStatus.READY) {
            System.out.println("Delivery Service: Order " + order.getOrderId() + 
                              " is ready for pickup");
        }
    }
}