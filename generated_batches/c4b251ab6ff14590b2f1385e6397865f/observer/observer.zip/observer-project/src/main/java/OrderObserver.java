package restaurant;

public interface OrderObserver {
    void update(Order order);
}