public class FoodOrderFactory extends OrderFactory {
    @Override
    public Order createOrder(String orderId, double totalAmount, String details) {
        return new FoodOrder(orderId, totalAmount, details);
    }
}