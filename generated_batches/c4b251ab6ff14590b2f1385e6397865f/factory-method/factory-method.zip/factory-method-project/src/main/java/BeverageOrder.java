public class BeverageOrder extends Order {
    private String beverages;
    
    public BeverageOrder(String orderId, double totalAmount, String beverages) {
        super(orderId, totalAmount);
        this.beverages = beverages;
    }
    
    @Override
    public void processOrder() {
        System.out.println("Processing beverage order: " + orderId + 
                          " with drinks: " + beverages);
    }
}