public class FoodOrder extends Order {
    private String menuItems;
    
    public FoodOrder(String orderId, double totalAmount, String menuItems) {
        super(orderId, totalAmount);
        this.menuItems = menuItems;
    }
    
    @Override
    public void processOrder() {
        System.out.println("Processing food order: " + orderId + 
                          " with items: " + menuItems);
    }
}