public abstract class OrderFactory {
    public abstract Order createOrder(String orderId, double totalAmount, String details);
    
    public Order createFoodOrder(String orderId, double totalAmount, String menuItems) {
        return createOrder(orderId, totalAmount, menuItems);
    }
    
    public Order createBeverageOrder(String orderId, double totalAmount, String beverages) {
        return createOrder(orderId, totalAmount, beverages);
    }
}