public class BeverageOrderFactory extends OrderFactory {
    @Override
    public Order createOrder(String orderId, double totalAmount, String details) {
        return new BeverageOrder(orderId, totalAmount, details);
    }
}