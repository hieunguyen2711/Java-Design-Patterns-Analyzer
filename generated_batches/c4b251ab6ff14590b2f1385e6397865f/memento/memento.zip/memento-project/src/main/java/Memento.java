package restaurant;

import java.util.List;

public class Memento {
    private List<String> items;
    private String status;
    
    public Memento(List<String> items, String status) {
        this.items = new ArrayList<>(items);
        this.status = status;
    }
    
    public List<String> getItems() {
        return new ArrayList<>(items);
    }
    
    public String getStatus() {
        return status;
    }
}