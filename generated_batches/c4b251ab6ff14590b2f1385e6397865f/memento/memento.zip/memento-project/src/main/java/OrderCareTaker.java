package restaurant;

import java.util.ArrayList;
import java.util.List;

public class OrderCareTaker {
    private List<Memento> mementos;
    
    public OrderCareTaker() {
        this.mementos = new ArrayList<>();
    }
    
    public void addMemento(Memento memento) {
        mementos.add(memento);
    }
    
    public Memento getMemento(int index) {
        return mementos.get(index);
    }
}