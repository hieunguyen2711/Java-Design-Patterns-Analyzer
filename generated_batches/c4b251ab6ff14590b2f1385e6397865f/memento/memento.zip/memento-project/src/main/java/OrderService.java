package restaurant;

public class OrderService {
    private Order order;
    private OrderCareTaker careTaker;
    
    public OrderService() {
        this.order = new Order();
        this.careTaker = new OrderCareTaker();
    }
    
    public void addItem(String item) {
        order.addItem(item);
    }
    
    public void updateStatus(String status) {
        order.setStatus(status);
    }
    
    public void saveState() {
        careTaker.addMemento(order.createMemento());