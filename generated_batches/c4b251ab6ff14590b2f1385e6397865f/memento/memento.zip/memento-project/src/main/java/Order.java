package restaurant;

import java.util.ArrayList;
import java.util.List;

public class Order {
    private List<String> items;
    private String status;
    
    public Order() {
        this.items = new ArrayList<>();
        this.status = "CREATED";
    }
    
    public void addItem(String item) {
        items.add(item);
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public List<String> getItems() {
        return new ArrayList<>(items);
    }
    
    public String getStatus() {
        return status;
    }
    
    public Memento createMemento() {
        return new Memento(new ArrayList<>(items), status);
    }
    
    public void restoreFromMemento(Memento memento) {
        this.items = memento.getItems();
        this.status = memento.getStatus();
    }
}