package restaurant.monitor;

public class RestaurantService {
    private final OrderMonitor monitor;
    
    public RestaurantService() {
        this.monitor = new OrderMonitor();
    }
    
    public void processOrder(String orderId, String customerId, double amount) {
        Order order = new Order(orderId, customerId, amount);
        monitor.addOrder(order);
        
        // Simulate processing
        System.out.println("Order " + orderId + " created with status: " + order.getStatus