package restaurant.monitor;

import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Collections;

public class OrderMonitor {
    private final Map<String, Order> orders;
    
    public OrderMonitor() {
        this.orders = new ConcurrentHashMap<>();
    }
    
    public void addOrder(Order order) {
        orders.put(order.getOrderId(), order);
    }
    
    public Order getOrder(String orderId) {
        return orders.get(orderId);
    }
    
    public Set<String> getAllOrderIds() {
        return Collections.unmodifiableSet(orders.keySet());
    }
    
    public int getTotalOrders() {
        return orders.size();
    }
    
    public void updateOrderStatus(String orderId, OrderStatus status) {
        Order order = orders.get(orderId);
        if (order != null) {
            order.setStatus(status);
        }
    }
}