public class DeliveryDriver {
    private String driverId;
    private String name;
    private boolean isAvailable;

    public DeliveryDriver(String driverId, String name) {
        this.driverId = driverId;
        this.name = name;
        this.isAvailable = true;
    }

    // Getters and setters
    public String getDriverId() { return driverId; }
    public void setDriverId(String driverId) { this.driverId = driverId; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public boolean isAvailable() { return isAvailable; }
    public void setAvailable(boolean available) { isAvailable = available; }
}