import java.util.*;

public class RestaurantMediator {
    private List<Customer> customers;
    private List<Order> orders;
    private List<DeliveryDriver> drivers;

    public Restaurant