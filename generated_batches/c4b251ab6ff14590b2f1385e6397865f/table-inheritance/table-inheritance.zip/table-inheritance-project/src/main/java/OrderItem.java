package restaurant.order;

import restaurant.menu.MenuItem;

public class OrderItem {
    private MenuItem menuItem;
    private int quantity;
    
    public OrderItem(MenuItem menuItem, int quantity) {
        this.menuItem = menuItem;
        this.quantity = quantity;
    }
    
    public double getTotalCost() {
        return menuItem.calculateCost() * quantity;
    }
    
    public MenuItem getMenuItem() {
        return menuItem;
    }
    
    public int getQuantity() {
        return quantity;
    }
}