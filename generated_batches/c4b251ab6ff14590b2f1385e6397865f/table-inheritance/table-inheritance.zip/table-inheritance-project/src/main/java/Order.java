package restaurant.order;

import java.util.ArrayList;
import java.util.List;

public class Order {
    private List<OrderItem> items;
    private String orderId;
    private String status;
    
    public Order(String orderId) {
        this.orderId = orderId;
        this.items = new ArrayList<>();
        this.status = "pending";
    }
    
    public void addItem(OrderItem item) {
        items.add(item);
    }
    
    public double getTotalAmount() {
        return items.stream()
                   .mapToDouble(OrderItem::getTotalCost