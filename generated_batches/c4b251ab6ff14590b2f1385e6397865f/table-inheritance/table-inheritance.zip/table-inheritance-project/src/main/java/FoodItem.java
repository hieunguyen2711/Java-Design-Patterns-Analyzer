package restaurant.menu;

public class FoodItem extends MenuItem {
    private int calories;
    
    public FoodItem(String name, double price, int calories) {
        super(name, price);
        this.calories = calories;
    }
    
    @Override
    public double calculateCost() {
        return price;
    }
    
    public int getCalories() {
        return calories;
    }
}