package restaurant.menu;

public class BeverageItem extends MenuItem {
    private boolean isAlcoholic;
    
    public BeverageItem(String name, double price, boolean isAlcoholic) {
        super(name, price);
        this.isAlcoholic = isAlcoholic;
    }
    
    @Override
    public double calculateCost() {
        return price;
    }
    
    public boolean isAlcoholic() {
        return isAlcoholic;
    }
}