package restaurant.order;

import java.math.BigDecimal;
import java.util.Objects;

public final class OrderItem {
    private final String menuItemId;
    private final String name;
    private final BigDecimal price;
    private final int quantity;
    
    public OrderItem(String menuItemId, String name, BigDecimal price, int quantity) {
        this.menuItemId = Objects.requireNonNull(menuItemId);
        this.name = Objects.requireNonNull(name);
        this.price = Objects.requireNonNull(price);
        this.quantity = quantity;
    }
    
    public String getMenuItemId() {
        return menuItemId;
    }
    
    public String getName() {
        return name;
    }
    
    public BigDecimal getPrice() {
        return price;
    }
    
    public int getQuantity() {
        return quantity;
    }
    
    public BigDecimal getTotalPrice() {
        return price.multiply(BigDecimal.valueOf(quantity));
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;