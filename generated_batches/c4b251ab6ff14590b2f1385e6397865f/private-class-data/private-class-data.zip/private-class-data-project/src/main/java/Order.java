package restaurant.backend;

import java.util.List;
import java.util.ArrayList;
import java.time.LocalDateTime;

public class Order {
    private final List<OrderItem> items;
    private final String customerId;
    private final LocalDateTime timestamp;
    
    public Order(String customerId) {
        this.items = new ArrayList<>();
        this.customerId = customerId;
        this.timestamp = LocalDateTime.now();
    }
    
    public void addItem(MenuItem menuItem, int quantity) {
        items.add(new OrderItem(menuItem, quantity));
    }
    
    public List<OrderItem> getItems() {
        return new ArrayList<>(items); // Return defensive copy
    }
    
    public String getCustomerId() {
        return customerId;
    }
    
    public LocalDateTime getTimestamp() {
        return timestamp;
    }
}