package restaurant.backend;

import java.util.List;
import java.util.ArrayList;

public class OrderProcessor {
    private final List<Order> orders;
    
    public OrderProcessor() {
        this.orders = new ArrayList<>();
    }
    
    public void processOrder(Order order) {
        // Process the order by adding it to internal collection
        orders.add(order);
        
        // In a real implementation, we would do more processing here
        System.out.println("Processing order for customer: " + order.getCustomerId());
    }
    
    public List<Order> getOrders() {
        return new ArrayList<>(orders); // Return defensive copy
    }
}