public class Order {
    private double totalAmount;
    private PaymentStrategy paymentStrategy;
    
    public Order(double totalAmount) {
        this.totalAmount = totalAmount;
    }
    
    public void setPaymentStrategy(PaymentStrategy strategy) {
        this.paymentStrategy = strategy;
    }
    
    public boolean processOrder() {
        if (paymentStrategy == null) {
            throw new IllegalStateException("No payment strategy set");
        }
        return paymentStrategy.processPayment(totalAmount);
    }
}