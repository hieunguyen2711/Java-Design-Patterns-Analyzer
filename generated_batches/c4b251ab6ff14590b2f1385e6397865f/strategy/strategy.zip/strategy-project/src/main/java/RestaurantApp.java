public class RestaurantApp {
    public static void main(String[] args) {
        Order order1 = new Order(50.0);
        order1.setPaymentStrategy(new CreditCardPayment("1234-5678-9012-3456", "123"));
        order1.processOrder();
        
        Order order2 = new Order(75.0);
        order2.setPaymentStrategy(new PayPalPayment("customer@example.com"));
        order2.processOrder();
    }
}