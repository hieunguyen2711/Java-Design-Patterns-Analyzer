public class OrderService {
    private CustomerService customerService;
    
    public OrderService(CustomerService customerService) {
        this.customerService = customerService;
    }
    
    public Order createOrder(String customerId) {
        Customer customer = customerService.findCustomer(customerId);
        return new Order("ORD-" + System.currentTimeMillis(), customer);
    }
}