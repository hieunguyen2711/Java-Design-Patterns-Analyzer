public class Order {
    private String orderId;
    private Customer customer;
    
    public Order(String orderId, Customer customer) {
        this.orderId = orderId;
        this.customer = customer;
    }
    
    public String getOrderId() {
        return orderId;
    }
    
    public Customer getCustomer() {
        return customer;
    }
}