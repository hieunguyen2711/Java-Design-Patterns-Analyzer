public class Main {
    public static void main(String[] args) {
        CustomerService customerService = new CustomerService();
        OrderService orderService = new OrderService(customerService);
        
        // Valid customer
        Order validOrder = orderService.createOrder("123");
        System.out.println("Customer: