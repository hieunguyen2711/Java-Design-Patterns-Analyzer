public class NullCustomer extends Customer {
    
    public NullCustomer() {
        super("Unknown Customer", "unknown@restaurant.com");
    }
    
    @Override
    public String getName() {
        return "Unknown Customer";
    }
    
    @Override
    public String getEmail() {
        return "unknown@restaurant.com";
    }
}