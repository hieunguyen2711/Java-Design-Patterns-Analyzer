public class CustomerService {
    
    public Customer findCustomer(String customerId) {
        // Simulate database lookup
        if (customerId == null || customerId.isEmpty()) {
            return new NullCustomer();
        }
        
        // In a real system, this would query a database
        // For demo purposes, we'll just return null for invalid IDs
        if ("123".equals(customerId)) {
            return new Customer("John Doe", "john@example.com");
        }
        
        return new NullCustomer();
    }
}