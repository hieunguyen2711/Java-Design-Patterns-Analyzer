package restaurant.view;

import restaurant.model.Menu;
import restaurant.model.Order;
import java.util.List;

public class RestaurantView {
    
    public void displayMenu(List<Menu> menuItems) {
        System.out.println("=== MENU ===");
        for (Menu item : menuItems) {
            System.out.println(item.getName() + "