package restaurant.model;

import java.util.ArrayList;
import java.util.List;

public class RestaurantModel {
    private List<Menu> menuItems;
    private List<Order> orders;
    
    public RestaurantModel() {
        this.menuItems = new ArrayList<>();
        this.orders = new ArrayList<>();
        initializeMenu();
    }
    
    private void initializeMenu() {
        menuItems.add(new Menu("Burger", 12.99));
        menuItems.add(new Menu("Pizza", 15.50));
        menuItems.add(new Menu("Salad", 8.75));
    }
    
    public List<Menu> getMenuItems() {
        return new ArrayList<>(menuItems);
    }
    
    public void addOrder(Order order) {
        orders.add(order);
    }
    
    public List<Order> getOrders() {
        return new ArrayList<>(orders);
    }
}