public class MenuItemWrapper extends MenuComponent {
    private MenuItem menuItem;

    public MenuItemWrapper(MenuItem menuItem) {
        this.menuItem = menuItem;
    }

    @Override
    public String getName() {
        return menuItem.getName();
    }

    @Override
    public double getPrice() {
        return menuItem.getPrice();
    }

    @Override
    public void print() {
        System.out.println("  " + menuItem.getName() + " - $" + menuItem.getPrice());
    }
}