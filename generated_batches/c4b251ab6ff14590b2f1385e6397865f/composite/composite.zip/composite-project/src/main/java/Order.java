import java.util.ArrayList;
import java.util.List;

public class Order {
    private List<MenuComponent> items;
    
    public Order() {
        this.items = new ArrayList<>();