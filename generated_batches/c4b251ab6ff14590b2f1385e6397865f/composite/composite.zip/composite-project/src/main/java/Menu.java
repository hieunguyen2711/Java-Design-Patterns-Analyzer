import java.util.ArrayList;
import java.util.List;

public class Menu extends MenuComponent {
    private String name;
    private List<MenuComponent> items;

    public Menu(String name) {
        this.name = name;
        this.items = new ArrayList<>();
    }

    @Override
    public void add(MenuComponent component) {
        items.add(component);
    }

    @Override
    public void remove(MenuComponent component) {
        items.remove(component);
    }

    @Override
    public List<MenuComponent> getChildren() {
        return items;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void print() {
        System.out.println("Menu: " + name);
        for (MenuComponent item : items) {
            item.print();
        }
    }
}