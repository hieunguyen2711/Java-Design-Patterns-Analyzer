public class Restaurant {
    private Menu menu;
    
    public Restaurant() {
        this.menu = new Menu();
        initializeMenu();
    }
    
    private void initializeMenu() {
        menu.addItem(new MenuItem("Burger", 12.99));
        menu.addItem(new MenuItem("Pizza", 15.50));
        menu.addItem(new MenuItem("Salad", 8.75));
        menu.addItem(new MenuItem("Pasta", 14.25));
    }
    
    public void displayMenu() {
        System.out.println("Restaurant Menu:");
        for (MenuItem item : menu) {
            System.out.println("- " + item.getName() + ": $" + item.getPrice());
        }
    }
}