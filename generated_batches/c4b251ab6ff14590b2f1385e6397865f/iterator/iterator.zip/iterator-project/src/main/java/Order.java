import java.util.*;

public class Order {
    private List<MenuItem> items;
    
    public Order() {
        this.items = new ArrayList<>();
    }
    
    public void addItem(MenuItem item) {
        items.add(item);
    }
    
    public Iterator<MenuItem> getItemsIterator() {
        return items.iterator();
    }
}