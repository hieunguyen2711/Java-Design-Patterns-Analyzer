import java.util.*;

public class Menu implements Iterable<MenuItem> {
    private List<MenuItem> items;
    
    public Menu() {
        this.items = new ArrayList<>();
    }
    
    public void addItem(MenuItem item) {
        items.add(item);
    }
    
    public Iterator<MenuItem> iterator() {
        return items.iterator();
    }
}