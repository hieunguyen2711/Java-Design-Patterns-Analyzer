public class Main {
    public static void main(String[] args) {
        Restaurant restaurant = new Restaurant();
        restaurant.displayMenu();
        
        Order order = new Order();
        order.addItem(new MenuItem("Burger", 12.99));
        order.addItem(new MenuItem("Pizza", 15.50));
        
        System.out.println("\nOrder items:");
        for (MenuItem item : order.getItemsIterator()) {
            System.out.println("- " + item.getName() + ": $" + item.getPrice());
        }
    }
}