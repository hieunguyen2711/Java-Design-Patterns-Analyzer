package restaurant.order;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public class Order implements Trackable {
    private final String orderId;
    private final List<OrderItem> items;
    private final BigDecimal totalAmount;
    private final LocalDateTime orderTime;
    private OrderStatus status;

    public Order(String orderId, List<OrderItem> items, BigDecimal totalAmount) {
        this.orderId = orderId;
        this.items = items;
        this.totalAmount = totalAmount;
        this.orderTime = LocalDateTime.now();
        this.status = OrderStatus.PENDING;
    }

    // Getters and setters
    public String getOrderId() { return orderId; }
    public List<OrderItem> getItems() { return items; }
    public BigDecimal getTotalAmount() { return totalAmount; }
    public LocalDateTime getOrderTime() { return orderTime; }
    public OrderStatus getStatus() { return status; }
    public void setStatus(OrderStatus status) { this.status = status; }

    @Override
    public String toString() {
        return "Order{" +
                "orderId='" + orderId + '\'' +
                ", totalAmount=" + totalAmount +
                ", status=" + status +
                '}';
    }
}