package restaurant.order;

public interface Trackable {
    // Marker interface - no methods to implement
    // Used for type safety and identification purposes
}
``