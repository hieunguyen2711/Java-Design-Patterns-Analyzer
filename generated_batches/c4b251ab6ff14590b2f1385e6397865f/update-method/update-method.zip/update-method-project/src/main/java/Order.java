package restaurant.backend;

public class Order {
    private String orderId;
    private OrderStatus status;
    
    public Order(String orderId) {
        this.orderId = orderId;
        this.status = OrderStatus.RECEIVED;
    }
    
    public void updateStatus(OrderStatus newStatus) {
        this.status = newStatus;
    }
    
    public String getOrderId() {
        return orderId;
    }
    
    public OrderStatus getStatus() {
        return status;
    }
}