package restaurant.backend;

public class RestaurantBackendApplication {
    
    public static void main(String[] args) {
        Order order = new Order("ORD-001");
        OrderUpdateService service = new OrderUpdateService();
        
        System.out.println("Initial status: " + order.getStatus());
        
        // Update order status through the service
        service.updateOrder(order, OrderStatus.PREPARING);
        System.out.println("After preparing: " + order.getStatus());
        
        service.updateOrder(order, OrderStatus.READY);
        System.out.println("After ready: " + order.getStatus());
    }
}