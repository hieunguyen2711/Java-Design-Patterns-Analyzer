package restaurant.backend;

public enum OrderStatus {
    RECEIVED,
    PREPARING,
    READY,
    DELIVERED,
    CANCELLED
}