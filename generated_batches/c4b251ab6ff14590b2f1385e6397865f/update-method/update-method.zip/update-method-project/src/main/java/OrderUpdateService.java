package restaurant.backend;

public class OrderUpdateService {
    
    public void updateOrder(Order order, OrderStatus newStatus) {
        // Business logic for updating order status
        if (order.getStatus() == OrderStatus.CANCELLED) {
            throw new IllegalStateException("Cannot update cancelled order");
        }
        
        // Update the order with new status
        order.updateStatus(newStatus);
    }
}