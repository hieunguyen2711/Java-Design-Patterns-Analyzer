package restaurant.backend;

public class Main {
    public static void main(String[] args) {
        OrderService service = new OrderService();
        
        // Add some sample orders
        service.addOrder(new Order("ORD001", "CUST001"));
        service.addOrder(new Order("ORD002", "CUST