package restaurant.backend;

import java.util.ArrayList;
import java.util.List;

public class OrderService {
    private List<Order> orders;
    
    public OrderService() {
        this.orders = new ArrayList<>();
    }
    
    public void addOrder(Order order) {
        orders.add(order);
    }
    
    public OrderViewHelper createViewHelper() {
        return new OrderViewHelper(orders);
    }
}