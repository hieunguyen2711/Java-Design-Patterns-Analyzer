package restaurant.backend;

import java.util.List;
import java.util.stream.Collectors;

public class OrderViewHelper {
    private List<Order> orders;
    
    public OrderViewHelper(List<Order> orders) {
        this.orders = orders;
    }
    
    public String generateOrderSummary() {
        StringBuilder summary = new StringBuilder();
        summary.append("Order Summary:\n");
        
        for (Order order : orders) {
            summary.append(String.format("Order ID: %s, Customer: %s, Status: %s\n", 
                order.getOrderId(), order.getCustomerId(), order.getStatus()));
        }
        
        return summary.toString();
    }
    
    public List<Order> getOrdersByStatus(String status) {
        return orders.stream()
            .filter(order -> order.getStatus().equals(status))
            .collect(Collectors.toList());
    }
}