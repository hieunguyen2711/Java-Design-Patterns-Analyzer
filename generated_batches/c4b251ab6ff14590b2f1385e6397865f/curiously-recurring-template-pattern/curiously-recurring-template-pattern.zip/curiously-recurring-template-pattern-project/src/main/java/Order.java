package com.restaurant.order;

public abstract class Order<T extends Order<T>> {
    protected String orderId;
    protected double totalAmount;
    
    public Order(String orderId, double totalAmount) {
        this.orderId = orderId;
        this.totalAmount = totalAmount;
    }
    
    public abstract T withTotalAmount(double amount);
    
    public String getOrderId() {
        return orderId;
    }
    
    public double getTotalAmount() {
        return totalAmount;
    }
}