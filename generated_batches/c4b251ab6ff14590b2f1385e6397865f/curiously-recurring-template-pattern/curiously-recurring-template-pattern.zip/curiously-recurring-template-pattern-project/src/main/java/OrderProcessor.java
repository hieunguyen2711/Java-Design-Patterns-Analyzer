package com.restaurant.order;

public class OrderProcessor {
    public static void processOrder(Order<?> order) {
        System.out.println("Processing order " + order.getOrderId() + 
                          " with amount $" + order.getTotalAmount());
    }
    
    public static void main(String[] args) {
        FoodOrder foodOrder = new FoodOrder("FO-001", 45.99);
        BeverageOrder beverageOrder = new BeverageOrder("BO-001", 12.50);
        
        processOrder(foodOrder);
        processOrder(beverageOrder);
    }
}