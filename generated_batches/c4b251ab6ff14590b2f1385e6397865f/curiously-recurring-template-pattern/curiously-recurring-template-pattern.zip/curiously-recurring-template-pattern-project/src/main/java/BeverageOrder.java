package com.restaurant.order;

public class BeverageOrder extends Order<BeverageOrder> {
    private int numberOfDrinks;
    
    public BeverageOrder(String orderId, double totalAmount) {
        super(orderId, totalAmount);
        this.numberOfDrinks = 0;
    }
    
    @Override
    public BeverageOrder withTotalAmount(double amount) {
        this.totalAmount = amount;
        return this;
    }
    
    public int getNumberOfDrinks() {
        return numberOfDrinks;
    }
    
    public void setNumberOfDrinks(int numberOfDrinks) {
        this.numberOfDrinks = numberOfDrinks;
    }
}