package com.restaurant.order;

public class FoodOrder extends Order<FoodOrder> {
    private boolean isDelivery;
    
    public FoodOrder(String orderId, double totalAmount) {
        super(orderId, totalAmount);
        this.isDelivery = false;
    }
    
    @Override
    public FoodOrder withTotalAmount(double amount) {
        this.totalAmount = amount;
        return this;
    }
    
    public boolean isDelivery() {
        return isDelivery;
    }
    
    public void setDelivery(boolean delivery) {
        isDelivery = delivery;
    }
}