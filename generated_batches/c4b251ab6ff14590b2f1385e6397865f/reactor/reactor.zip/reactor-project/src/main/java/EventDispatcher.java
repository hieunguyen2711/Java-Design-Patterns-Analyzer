import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;

public class EventDispatcher {
    private final Map<Class<?>, Set<EventHandler<?>>> handlers = new ConcurrentHashMap<>();

    public <T> void registerHandler(Class<T> eventType, EventHandler<T> handler) {
        handlers.computeIfAbsent(eventType, k -> new HashSet<>()).add(handler);
    }

    @SuppressWarnings("unchecked")
    public <T> void dispatch(T event) {
        Set<EventHandler<?>> eventHandlers = handlers.get(event.getClass());
        if (eventHandlers != null) {
            for (EventHandler<?> handler : eventHandlers) {
                ((EventHandler<T>) handler).handle(event);
            }
        }
    }
}