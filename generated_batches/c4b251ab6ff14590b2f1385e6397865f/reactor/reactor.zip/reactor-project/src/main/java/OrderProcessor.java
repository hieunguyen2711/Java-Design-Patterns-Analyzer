public class OrderProcessor {
    private final EventDispatcher dispatcher;

    public OrderProcessor(EventDispatcher dispatcher) {
        this.dispatcher = dispatcher;
        setupEventHandlers();
    }

    private void setupEventHandlers() {
        // Handle order creation events
        dispatcher.registerHandler(OrderCreatedEvent