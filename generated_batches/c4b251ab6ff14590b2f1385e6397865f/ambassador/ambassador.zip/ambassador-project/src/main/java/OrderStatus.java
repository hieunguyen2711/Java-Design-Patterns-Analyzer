package com.restaurant;

public enum OrderStatus {
    PENDING,
    CONFIRMED,
    PREPARING,
    READY_FOR_PICKUP,
    ON_DELIVERY,
    DELIVERED,
    CANCELLED
}