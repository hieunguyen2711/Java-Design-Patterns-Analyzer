package com.restaurant;

public class DeliveryDriver {
    private String name;
    private String vehicle;
    
    public DeliveryDriver(String name, String vehicle) {
        this.name = name;
        this.vehicle = vehicle;
    }
    
    public String getName() {
        return name;
    }