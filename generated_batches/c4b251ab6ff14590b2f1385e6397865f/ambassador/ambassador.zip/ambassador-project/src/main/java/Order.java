package com.restaurant;

import java.util.List;

public class Order {
    private int orderId;
    private List<String> items;
    private double totalAmount;
    private OrderStatus status;
    
    public Order(int orderId, List<String> items, double totalAmount) {
        this.orderId = orderId;
        this.items = items;
        this.totalAmount = totalAmount;
        this.status = OrderStatus.PENDING;
    }
    
    public int getOrderId() {
        return orderId;
    }
    
    public List<String> getItems() {
        return items;
    }
    
    public double getTotalAmount() {
        return totalAmount;
    }
    
    public OrderStatus getStatus() {
        return status;
    }
    
    public void setStatus(OrderStatus status) {
        this.status = status;
    }
}