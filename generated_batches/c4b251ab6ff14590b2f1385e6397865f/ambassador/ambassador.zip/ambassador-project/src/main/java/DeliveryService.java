package com.restaurant;

import java.util.ArrayList;
import java.util.List;

public class DeliveryService {
    private List<DeliveryDriver> drivers;
    
    public DeliveryService() {
        this.drivers = new ArrayList<>();
    }
    
    public void addDriver(DeliveryDriver driver) {
        drivers.add(driver);
    }
    
    public DeliveryDriver assignDriver(Order order) {
        if (drivers.isEmpty()) {
            return null;
        }
        
        // Simple round-robin assignment
        int index = order.getOrderId() % drivers.size();
        return drivers.get(index);
    }
}