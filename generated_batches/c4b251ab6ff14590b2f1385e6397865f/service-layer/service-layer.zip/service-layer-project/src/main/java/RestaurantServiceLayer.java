package com.restaurant.service;

import com.restaurant.model.Order;
import com.restaurant.repository.OrderRepository;
import com.restaurant.service.strategy.PaymentStrategy;

public class RestaurantServiceLayer {
    private final OrderService orderService;
    private final PaymentService paymentService;
    private final OrderProcessingService processingService;
    
    public RestaurantServiceLayer(OrderRepository repository, PaymentStrategy paymentStrategy) {
        this.orderService = new OrderService(repository, paymentStrategy);
        this.paymentService = new PaymentService(paymentStrategy);
        this.processingService = new OrderProcessingService(repository);
    }
    
    public Order placeOrder(Order order) {
        return orderService.createOrder(order);
    }
    
    public boolean processOrderPayment(Order order, double amount) {
        return paymentService.processPayment(order, amount);
    }
    
    public void updateOrderStatus