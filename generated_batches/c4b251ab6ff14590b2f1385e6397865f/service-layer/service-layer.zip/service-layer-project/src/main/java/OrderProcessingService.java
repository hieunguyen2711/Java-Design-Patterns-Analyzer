package com.restaurant.service;

import com.restaurant.model.Order;
import com.restaurant.repository.OrderRepository;

public class OrderProcessingService {
    private final OrderRepository repository;
    
    public OrderProcessingService(OrderRepository repository) {
        this.repository = repository;
    }
    
    public void updateOrderStatus(Long orderId, String status) {
        Order order = repository.findById(orderId);
        if (order != null) {
            order.setStatus(status);
            repository.save(order);
        }
    }
}