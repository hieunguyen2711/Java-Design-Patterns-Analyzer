package com.restaurant.service;

import com.restaurant.model.Order;
import com.restaurant.repository.OrderRepository;
import com.restaurant.service.strategy.PaymentStrategy;

public class OrderService {
    private final OrderRepository repository;
    private final PaymentStrategy paymentStrategy;
    
    public OrderService(OrderRepository repository, PaymentStrategy paymentStrategy) {
        this.repository = repository;
        this.paymentStrategy = paymentStrategy;
    }
    
    public Order createOrder(Order order) {
        order.setStatus("PENDING");
        return repository.save(order);
    }
    
    public boolean processPayment(Order order, double amount) {
        return paymentStrategy.processPayment(order, amount);
    }
}