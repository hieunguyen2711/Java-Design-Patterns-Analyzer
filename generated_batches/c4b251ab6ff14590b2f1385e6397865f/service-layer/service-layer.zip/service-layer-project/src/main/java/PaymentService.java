package com.restaurant.service;

import com.restaurant.model.Order;
import com.restaurant.service.strategy.PaymentStrategy;

public class PaymentService {
    private final PaymentStrategy strategy;
    
    public PaymentService(PaymentStrategy strategy) {
        this.strategy = strategy;
    }
    
    public boolean processPayment(Order order, double amount) {
        return strategy.processPayment(order, amount);
    }
}