package restaurant.command;

import restaurant.Order;
import restaurant.OrderStatus;

public class OrderProcessor {
    public void processOrder(Order order, OrderStatus status) {
        Command command = new OrderCommand(order, status);
        command.execute();
    }
}