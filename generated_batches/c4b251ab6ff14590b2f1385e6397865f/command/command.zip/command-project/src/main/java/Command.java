package restaurant.command;

public interface Command {
    void execute();
}