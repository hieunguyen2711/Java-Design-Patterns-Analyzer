package restaurant;

import restaurant.command.OrderProcessor;
import restaurant.Order;
import restaurant.OrderStatus;

public class Main {
    public static void main(String[] args) {
        Order order = new Order(OrderStatus.PLACED);
        OrderProcessor processor = new OrderProcessor();
        
        System.out.println("Order status: " + order.getStatus());
        
        processor.processOrder(order, OrderStatus.PREPARING);
        System.out.println("Order status after command: " + order.getStatus());
    }
}