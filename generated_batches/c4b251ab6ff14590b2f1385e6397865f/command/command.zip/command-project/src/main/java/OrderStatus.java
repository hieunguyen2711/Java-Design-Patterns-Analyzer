package restaurant;

public enum OrderStatus {
    PLACED,
    PREPARING,
    READY,
    DELIVERED
}