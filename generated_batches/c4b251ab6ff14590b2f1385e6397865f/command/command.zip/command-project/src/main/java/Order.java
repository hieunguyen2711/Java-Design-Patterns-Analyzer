package restaurant;

import java.util.UUID;

public class Order {
    private final String id;
    private OrderStatus status;
    
    public Order(OrderStatus status) {
        this.id = UUID.randomUUID().toString();
        this.status = status;
    }
    
    public void setStatus(OrderStatus status) {
        this.status = status;
    }
    
    public OrderStatus getStatus() {
        return status;
    }
    
    public String getId() {
        return id;
    }
}