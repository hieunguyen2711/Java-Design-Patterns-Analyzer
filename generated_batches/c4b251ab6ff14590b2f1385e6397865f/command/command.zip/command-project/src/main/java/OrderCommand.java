package restaurant.command;

import restaurant.Order;
import restaurant.OrderStatus;

public class OrderCommand implements Command {
    private final Order order;
    private final OrderStatus status;
    
    public OrderCommand(Order order, OrderStatus status) {
        this.order = order;
        this.status = status;
    }
    
    @Override
    public void execute() {
        order.setStatus(status);
    }
}