package restaurant;

public class StatusUpdateServant {
    public static void updateStatus(Order order, String status) {
        // Servant performs the actual work of updating order status
        order.setStatus(status);
        System.out.println("Order " + order.getOrderId() + " status updated to: " + status);
    }
}