package restaurant;

public class OrderService {
    private OrderRepository orderRepository;
    
    public OrderService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }
    
    public void processOrder(String orderId, String customerId) {
        Order order = new Order(orderId, customerId);
        orderRepository.save(order);
        
        // Servant pattern: delegate to servant for status update
        StatusUpdateServant.updateStatus(order, "PREPARING");
        StatusUpdateServant.updateStatus(order, "READY");
        StatusUpdateServant.updateStatus(order, "DELIVERED");
    }
}