package restaurant;

public class RestaurantApplication {
    public static void main(String[] args) {
        OrderRepository repository = new OrderRepository();
        OrderService service = new OrderService(repository);
        
        // Process an order through the servant pattern
        service.processOrder("ORD-001", "CUST-123");
    }
}