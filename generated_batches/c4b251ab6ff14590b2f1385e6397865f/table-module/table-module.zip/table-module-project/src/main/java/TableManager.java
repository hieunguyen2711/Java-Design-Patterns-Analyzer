package restaurant.table;

public class TableManager {
    private static volatile TableModule instance;
    private final TableModule module;
    
    private TableManager(TableModule module) {
        this.module = module;
    }
    
    public static synchronized TableModule getInstance() {
        if (instance == null) {
            instance = new RestaurantTableModule(20);
        }
        return instance;
    }
    
    public void assignTable(int tableNumber) {
        module.assignTable(tableNumber);
    }
    
    public void releaseTable(int tableNumber) {
        module.releaseTable(tableNumber);
    }
    
    public boolean