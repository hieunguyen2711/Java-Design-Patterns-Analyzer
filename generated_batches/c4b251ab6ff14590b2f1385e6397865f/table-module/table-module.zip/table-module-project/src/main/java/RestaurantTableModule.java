package restaurant.table;

import java.util.HashMap;
import java.util.Map;

public class RestaurantTableModule implements TableModule {
    private final Map<Integer, Boolean> tables;
    private final Map<Integer, Integer> tableAssignments;
    
    public RestaurantTableModule(int totalTables) {
        this.tables = new HashMap<>();
        this.tableAssignments = new HashMap<>();
        
        for (int i = 1; i <= totalTables; i++) {
            tables.put(i, true); // All tables start as available
            tableAssignments.put(i, 0);
        }
    }
    
    @Override
    public void assignTable(int tableNumber) {
        if (tables.getOrDefault(tableNumber, false)) {
            tables.put(tableNumber, false);
        } else {
            throw new IllegalStateException("Table " + tableNumber + " is already assigned");
        }
    }
    
    @Override
    public void releaseTable(int tableNumber) {
        if (!tables.getOrDefault(tableNumber, true)) {
            tables.put(tableNumber, true);
            tableAssignments.put(tableNumber, 0);
        } else {
            throw new IllegalStateException("Table " + tableNumber + " is already available");
        }
    }
    
    @Override
    public boolean isTableAvailable(int tableNumber) {
        return tables.getOrDefault(tableNumber, false);
    }
    
    @Override
    public int getAssignedCustomerCount(int tableNumber) {
        return tableAssignments.getOrDefault(tableNumber, 0);
    }
}