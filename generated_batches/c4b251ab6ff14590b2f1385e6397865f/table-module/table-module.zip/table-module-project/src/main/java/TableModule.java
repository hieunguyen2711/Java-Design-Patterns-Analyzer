package restaurant.table;

public interface TableModule {
    void assignTable(int tableNumber);
    void releaseTable(int tableNumber);
    boolean isTableAvailable(int tableNumber);
    int getAssignedCustomerCount(int tableNumber);
}