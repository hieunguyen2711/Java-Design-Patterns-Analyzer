package restaurant.backend;

public class OrderManager {
    private static volatile OrderManager instance;
    
    // Shared state - all instances share these variables
    private int totalOrdersProcessed = 0;
    private double totalRevenue = 0.0;
    private String currentStatus = "Operational";
    
    // Private constructor to prevent instantiation
    private OrderManager() {}
    
    public static OrderManager getInstance() {
        if (instance == null) {
            synchronized (OrderManager.class) {
                if (instance == null) {
                    instance = new OrderManager();
                }
            }
        }
        return instance;
    }
    
    // Methods that modify shared state
    public void processOrder(double amount) {
        totalOrdersProcessed++;
        totalRevenue += amount;
        System.out.println("Order processed. Total orders: " + totalOrdersProcessed);
    }
    
    public void updateStatus(String status) {
        currentStatus = status;
        System.out.println("System status updated to: " + status);
    }
    
    // Methods that read shared state
    public int getTotalOrdersProcessed() {
        return totalOrdersProcessed;
    }
    
    public double getTotalRevenue() {
        return totalRevenue;
    }
    
    public String getCurrentStatus() {
        return currentStatus;
    }
}