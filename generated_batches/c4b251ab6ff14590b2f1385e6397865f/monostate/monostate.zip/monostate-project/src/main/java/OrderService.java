package restaurant.backend;

public class OrderService {
    private OrderManager orderManager;
    
    public OrderService() {
        // All services share the same instance through singleton pattern
        this.orderManager = OrderManager.getInstance();
    }
    
    public void handleOrder(double amount) {
        System.out.println("Processing order of $" + amount);
        orderManager.processOrder(amount);
    }
    
    public void checkSystemStatus() {
        System.out.println("Current system status: " + orderManager.getCurrentStatus());
        System.out.println("Total orders processed: " + orderManager.getTotalOrdersProcessed());
        System.out.println("Total revenue: $" + orderManager.getTotalRevenue());
    }
}