package restaurant.backend;

public class RestaurantApplication {
    public static void main(String[] args) {
        // Create multiple services that share the same state
        OrderService service1 = new OrderService();
        OrderService service2 = new OrderService();
        OrderService service3 = new OrderService();
        
        // Process orders through different services
        service1.handleOrder(25