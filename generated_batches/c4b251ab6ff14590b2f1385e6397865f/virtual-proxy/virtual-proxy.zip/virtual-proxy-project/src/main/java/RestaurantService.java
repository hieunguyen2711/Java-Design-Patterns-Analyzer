public class RestaurantService {
    private Menu menu;
    
    public RestaurantService() {
        this.menu = new VirtualMenuProxy();
    }
    
    public String getAvailableMenu() {
        return "Current Menu: " + menu.getMenuItems();
    }
}