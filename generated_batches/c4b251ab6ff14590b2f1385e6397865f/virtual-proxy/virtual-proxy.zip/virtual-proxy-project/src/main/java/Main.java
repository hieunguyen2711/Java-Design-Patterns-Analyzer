public class Main {
    public static void main(String[] args) {
        RestaurantService service = new RestaurantService();
        
        System.out.println("Loading restaurant menu...");
        long startTime = System.currentTimeMillis();
        
        String menu = service.getAvailableMenu();
        
        long endTime = System.currentTimeMillis();
        System.out.println(menu);
        System.out.println("Load time: " + (endTime - startTime) + "ms");
    }
}