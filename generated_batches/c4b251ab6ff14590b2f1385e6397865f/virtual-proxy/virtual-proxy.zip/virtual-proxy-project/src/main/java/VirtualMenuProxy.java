public class VirtualMenuProxy implements Menu {
    private RealMenu realMenu;
    private boolean loaded = false;
    
    @Override
    public String getMenuItems() {
        if (!loaded) {
            realMenu = new RealMenu();
            loaded = true;
        }
        return realMenu.getMenuItems();
    }
}