import java.util.Arrays;
import java.util.List;

public class RealMenu implements Menu {
    private List<String> items;
    
    public RealMenu() {
        // Simulate expensive operation to load menu data
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        this.items = Arrays.asList(
            "Margherita Pizza", 
            "Pepperoni Pizza", 
            "Caesar Salad", 
            "Garlic Bread",
            "Tiramisu"
        );
    }
    
    @Override
    public String getMenuItems() {
        return String.join(", ", items);
    }
}