public interface Menu {
    String getMenuItems();
}