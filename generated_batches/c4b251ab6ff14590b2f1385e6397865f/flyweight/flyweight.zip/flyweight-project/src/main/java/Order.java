import java.util.ArrayList;
import java.util.List;

public class Order {
    private List<OrderItem> items;
    private String orderId;
    
    public Order(String orderId) {
        this.orderId = orderId;
        this.items = new ArrayList<>();
    }
    
    public void addItem(MenuItem menuItem, int quantity) {
        items.add(new OrderItem(menuItem, quantity));
    }
    
    public double getTotalAmount() {
        return items.stream().mapToDouble(OrderItem::getTotalPrice).sum();
    }
    
    public String getOrderId() {
        return orderId;
    }
}