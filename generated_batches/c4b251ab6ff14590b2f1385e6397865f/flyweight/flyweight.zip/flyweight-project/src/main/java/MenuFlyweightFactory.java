import java.util.HashMap;
import java.util.Map;

public class MenuFlyweightFactory {
    private static final Map<String, MenuItem> menuItems = new HashMap<>();
    
    public static MenuItem getMenuItem(String name, double price) {
        String key = name + "_" + price;
        if (!menuItems.containsKey(key)) {
            menuItems.put(key, new MenuItem(name, price));
        }
        return menuItems.get(key);
    }
    
    public static int getTotalUniqueItems() {
        return menuItems.size();
    }
}