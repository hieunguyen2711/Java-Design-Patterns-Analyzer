import java.util.ArrayList;
import java.util.List;

public class RestaurantMenu {
    private List<MenuItem> menuItems;
    
    public RestaurantMenu() {
        this.menuItems = new ArrayList<>();
    }
    
    public void addMenuItem(String name, double price) {
        MenuItem item = MenuFlyweightFactory.getMenuItem(name, price);
        menuItems.add(item