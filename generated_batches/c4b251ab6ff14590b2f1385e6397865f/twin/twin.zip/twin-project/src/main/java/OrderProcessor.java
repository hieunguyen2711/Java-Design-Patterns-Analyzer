package restaurant.order;

public class OrderProcessor {
    private Order order;
    
    public OrderProcessor(Order order) {
        this.order = order;
    }
    
    public void processOrder() {
        // Create twin for processing operations
        Order.ProcessingTwin twin = new Order.ProcessingTwin(order);
        
        twin.processPayment();
        twin.updateStatus("PREPARING");
        
        System.out.println("Order " + order.getOrderId() + " processed successfully");
    }
}