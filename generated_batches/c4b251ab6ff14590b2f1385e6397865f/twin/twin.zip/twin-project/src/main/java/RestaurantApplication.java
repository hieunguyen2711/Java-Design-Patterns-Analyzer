package restaurant;

import restaurant.order.Order;
import restaurant.order.OrderProcessor;

public class RestaurantApplication {
    public static void main(String[] args) {
        // Create an order
        Order order = new Order("ORD001", "CUST123", 45.99);
        
        // Process the order using twin pattern
        OrderProcessor processor = new OrderProcessor(order);
        processor.processOrder();
    }
}