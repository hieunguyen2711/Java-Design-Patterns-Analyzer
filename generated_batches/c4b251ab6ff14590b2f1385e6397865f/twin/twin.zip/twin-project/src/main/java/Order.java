package restaurant.order;

public class Order {
    private String orderId;
    private String customerId;
    private double totalAmount;
    
    public Order(String orderId, String customerId, double totalAmount) {
        this.orderId = orderId;
        this.customerId = customerId;
        this.totalAmount = totalAmount;
    }
    
    // Twin pattern - companion object for order processing
    public static class ProcessingTwin {
        private Order order;
        
        public ProcessingTwin(Order order) {
            this.order = order;
        }
        
        public void processPayment() {
            System.out.println("Processing payment for order: " + order.getOrderId());
        }
        
        public void updateStatus(String status) {
            System.out.println("Updating order " + order.getOrderId() + " status to: " + status);
        }
    }
    
    // Getters
    public String getOrderId() { return orderId; }
    public String getCustomerId() { return customerId; }
    public double getTotalAmount() { return totalAmount; }
}