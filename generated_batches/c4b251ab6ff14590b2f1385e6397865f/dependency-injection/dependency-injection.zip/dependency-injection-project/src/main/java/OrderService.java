package restaurant.backend;

public class OrderService {
    private final PaymentProcessor paymentProcessor;
    private final DeliveryService deliveryService;
    
    public OrderService(PaymentProcessor paymentProcessor, DeliveryService deliveryService) {
        this.paymentProcessor = paymentProcessor;
        this.deliveryService = deliveryService;
    }
    
    public void processOrder(Order order) {
        if (paymentProcessor.processPayment(order.getCustomer(), order.getTotal())) {
            deliveryService.assignDelivery(order);
        }
    }
}