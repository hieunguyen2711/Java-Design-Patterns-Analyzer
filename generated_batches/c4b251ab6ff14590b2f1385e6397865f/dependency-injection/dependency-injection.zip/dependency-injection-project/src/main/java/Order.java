package restaurant.backend;

public class Order {
    private final String id;
    private final Customer customer;
    private final double total;
    
    public Order(String id, Customer customer, double total) {
        this.id = id;
        this.customer = customer;
        this.total = total;
    }
    
    public String getId() {
        return id;
    }
    
    public Customer getCustomer() {
        return customer;
    }
    
    public double getTotal() {
        return total;
    }
}