package restaurant.backend;

public class GoogleMapsDeliveryService implements DeliveryService {
    @Override
    public void assignDelivery(Order order) {
        // Simulate delivery assignment
        System.out.println("Assigning delivery for order " + order.getId());
    }
}