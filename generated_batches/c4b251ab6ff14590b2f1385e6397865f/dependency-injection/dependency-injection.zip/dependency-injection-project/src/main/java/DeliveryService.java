package restaurant.backend;

public interface DeliveryService {
    void assignDelivery(Order order);
}