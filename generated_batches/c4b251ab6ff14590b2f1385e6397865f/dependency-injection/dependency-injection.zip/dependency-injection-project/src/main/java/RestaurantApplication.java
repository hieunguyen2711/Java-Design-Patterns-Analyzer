package restaurant.backend;

public class RestaurantApplication {
    public static void main(String[] args) {
        // Dependency