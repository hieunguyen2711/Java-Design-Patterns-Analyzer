package restaurant.backend;

public class StripePaymentProcessor implements PaymentProcessor {
    @Override
    public boolean processPayment(Customer customer, double amount) {
        // Simulate payment processing
        System.out.println("Processing payment of $" + amount + " for customer " + customer.getName());
        return true;
    }
}