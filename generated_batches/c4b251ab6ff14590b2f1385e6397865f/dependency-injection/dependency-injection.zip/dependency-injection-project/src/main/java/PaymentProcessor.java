package restaurant.backend;

public interface PaymentProcessor {
    boolean processPayment(Customer customer, double amount);
}