public class OrderService {
    private PaymentProcessor paymentProcessor;
    
    public OrderService(PaymentProcessor paymentProcessor) {
        this.paymentProcessor = paymentProcessor;
    }
    
    public boolean completeOrder(double amount) {
        System.out.println("Completing order for $" + amount);
        return paymentProcessor.processPayment(amount);
    }
}