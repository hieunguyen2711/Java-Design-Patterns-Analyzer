public class Main {
    public static void main(String[] args) {
        // Using the adapter pattern to make CreditCardProcessor work with PaymentProcessor interface
        CreditCardProcessor creditCardProcessor = new CreditCardProcessor();
        PaymentProcessor paymentAdapter = new PaymentAdapter(creditCardProcessor);
        
        OrderService orderService = new OrderService(paymentAdapter);
        orderService.completeOrder(50.00);
    }
}