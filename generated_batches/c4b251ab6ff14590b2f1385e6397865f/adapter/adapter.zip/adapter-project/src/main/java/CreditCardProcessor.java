public class CreditCardProcessor {
    public boolean chargeCard(String cardNumber, double amount) {
        // Simulate credit card processing
        System.out.println("Charging $" + amount + " to credit card ending in " + 
                          cardNumber.substring(cardNumber.length() - 4));
        return true;
    }
}