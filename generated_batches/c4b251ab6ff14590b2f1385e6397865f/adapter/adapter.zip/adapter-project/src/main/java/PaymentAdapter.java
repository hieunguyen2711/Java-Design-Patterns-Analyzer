public class PaymentAdapter implements PaymentProcessor {
    private CreditCardProcessor creditCardProcessor;
    
    public PaymentAdapter(CreditCardProcessor creditCardProcessor) {
        this.creditCardProcessor = creditCardProcessor;
    }
    
    @Override
    public boolean processPayment(double amount) {
        // Adapter converts PaymentProcessor interface to CreditCardProcessor method
        return creditCardProcessor.chargeCard("1234567890123456", amount);
    }
}