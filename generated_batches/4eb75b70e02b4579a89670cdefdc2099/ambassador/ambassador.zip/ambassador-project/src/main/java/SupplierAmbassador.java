package com.example.stock;

public class SupplierAmbassador {
    private Supplier supplier;