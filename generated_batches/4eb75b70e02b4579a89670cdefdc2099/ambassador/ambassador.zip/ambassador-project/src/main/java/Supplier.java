package com.example.stock;

public class Supplier {
    private String supplierId;
    private String name;
    
    public Supplier(String supplierId, String name) {
        this.supplierId = supplierId;
        this.name = name;
    }
    
    // Getters and setters
    public String getSupplierId() { return supplierId; }
    public String getName() { return name; }
}