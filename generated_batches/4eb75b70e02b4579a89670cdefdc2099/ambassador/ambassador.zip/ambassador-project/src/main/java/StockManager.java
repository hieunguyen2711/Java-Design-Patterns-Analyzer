package com.example.stock;

import java.util.ArrayList;
import java.util.List;

public class StockManager {
    private List<StockItem> stockItems;
    
    public StockManager() {
        this.stockItems = new ArrayList<>();
    }
    
    public void addItem(StockItem item) {
        stockItems.add(item);
    }
    
    public void processReorders() {
        for (StockItem item : stockItems) {
            if (item.needsReorder()) {
                // Ambassador pattern: delegate to supplier
                SupplierAmbassador ambassador = new SupplierAmbassador(item.getSupplier());
                ambassador.placeOrder(item);
            }
        }
    }
    
    public void logMovement(String itemId, int quantity) {
        System.out.println("Item " + itemId + " moved by " + quantity);
    }
}