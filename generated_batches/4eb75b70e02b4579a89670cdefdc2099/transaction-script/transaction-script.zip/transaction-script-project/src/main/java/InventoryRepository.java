import java.util.HashMap;
import java.util.Map;

public class InventoryRepository {
    private final Map<String, Item> items = new HashMap<>();
    private final Map<String, Supplier> suppliers = new HashMap<>();
    private final Map<String, MovementLog> movementLogs = new HashMap<>();
    
    public Item findItem(String itemId) {
        return items.get(itemId);
    }
    
    public void save(Item item) {
        items.put(item.getId(), item);
    }
    
    public Supplier findSupplier(String supplierId) {
        return suppliers.get(supplierId);
    }
    
    public void createReorderRequest(String itemId, String supplierId, int quantity) {
        // Reorder request logic
    }
    
    public void saveMovementLog(MovementLog log) {
        movementLogs.put(log.getId(), log);
    }
}