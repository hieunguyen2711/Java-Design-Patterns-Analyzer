public class StockIntakeService {
    private final InventoryRepository repository;
    
    public StockIntakeService(InventoryRepository repository) {
        this.repository = repository;
    }
    
    public void processStockIntake(String itemId, int quantity, String supplierId) {
        // Transaction Script: All logic in single method
        Item item = repository.findItem(itemId);
        
        if (item == null) {
            item = new Item(itemId, 0, 0);
            repository.save(item);
        }
        
        int currentQuantity = item.getQuantity();
        item.setQuantity(currentQuantity + quantity);
        
        // Check reorder threshold
        if (item.getQuantity() <= item.getReorderThreshold()) {
            Supplier supplier = repository.findSupplier(supplierId);
            if (supplier != null) {
                repository.createReorderRequest(itemId, supplierId, 
                    item.getReorderThreshold() - item.getQuantity());
            }
        }
        
        // Log movement
        MovementLog log = new MovementLog(
            itemId, 
            "STOCK_INTAKE", 
            quantity, 
            currentQuantity, 
            item.getQuantity()
        );
        repository.saveMovementLog(log);
        
        repository.save(item);
    }
}