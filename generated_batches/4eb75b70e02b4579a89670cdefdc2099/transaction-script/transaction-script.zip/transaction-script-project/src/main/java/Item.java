public class Item {
    private final String id;
    private int quantity;
    private final int reorderThreshold;
    
    public Item(String id, int quantity, int reorderThreshold) {
        this.id = id;
        this.quantity = quantity;
        this.reorderThreshold = reorderThreshold;