import java.util.ArrayList;
import java.util.List;

public class StockModel {
    private List<StockItem> stockItems;
    private ModelListener listener;

    public interface ModelListener {
        void onStockUpdate();
    }

    public StockModel() {
        this.stockItems = new ArrayList<>();
    }

    public void setModelListener(ModelListener listener) {
        this.listener = listener;
    }

    public List<StockItem> getAllItems() {
        return new ArrayList<>(stockItems);
    }

    public void addItem(StockItem item) {
        stockItems.add(item);
        notifyListeners();
    }

    public void updateItem(StockItem item) {
        for (int i = 0; i < stockItems.size(); i++) {
            if (stockItems.get(i).getItemId().equals(item.getItemId())) {
                stockItems.set(i, item);
                break;
            }
        }
        notifyListeners();
    }

    public void removeItem(String itemId) {
        stockItems.removeIf(item -> item.getItemId().equals(itemId));
        notifyListeners();
    }

    public StockItem getItemById(String itemId) {
        return stockItems.stream()
                .filter(item -> item.getItemId().equals(itemId))
                .