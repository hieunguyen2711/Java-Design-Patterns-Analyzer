public class StockItem {
    private String itemId;
    private String itemName;
    private int currentStock;
    private int reorderThreshold;
    private String location;

    public StockItem(String itemId, String itemName, int currentStock, int reorderThreshold, String location) {
        this.itemId = itemId;
        this.itemName = itemName;
        this.currentStock = currentStock;
        this.reorderThreshold = reorderThreshold;
        this.location = location;
    }

    // Getters and setters
    public String getItemId() { return itemId; }
    public void setItemId(String itemId) { this.itemId = itemId; }

    public String getItemName() { return itemName; }
    public void setItemName(String itemName) { this.itemName = itemName; }

    public int getCurrentStock() { return currentStock; }
    public void setCurrentStock(int currentStock) { this.currentStock = currentStock; }

    public int getReorderThreshold() { return reorderThreshold; }
    public void setReorderThreshold(int reorderThreshold) { this.reorderThreshold = reorderThreshold; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
}