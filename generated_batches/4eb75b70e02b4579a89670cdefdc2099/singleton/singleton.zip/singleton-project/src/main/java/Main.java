public class Main {
    public static void main(String[] args) {
        InventorySystem system1 = new InventorySystem();
        InventorySystem system2 = new InventorySystem();
        
        system1.addStock("Widget A", 100, "Aisle 5");
        system2.addStock("Gadget B", 50, "Shelf 3");
        
        System.out.println("Singleton instance check: " + 
                          (system1 == system2 ? "Same instance" : "Different instances"));
    }
}