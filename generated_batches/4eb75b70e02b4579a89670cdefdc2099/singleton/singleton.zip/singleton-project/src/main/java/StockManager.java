public class StockManager {
    private static volatile StockManager instance;
    
    private StockManager() {
        // Private constructor to prevent instantiation
    }
    
    public static StockManager getInstance() {
        if (instance == null) {
            synchronized (StockManager.class) {
                if (instance == null) {
                    instance = new StockManager();
                }
            }
        }
        return instance;
    }
    
    public void processStockMovement(String item, int quantity, String location) {
        System.out.println("Processing movement: " + quantity + " units of " + item + 
                          " moved to " + location);
    }
}