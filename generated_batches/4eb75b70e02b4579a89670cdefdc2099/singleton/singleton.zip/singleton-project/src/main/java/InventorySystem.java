public class InventorySystem {
    private StockManager stockManager;
    
    public InventorySystem() {
        this.stockManager = StockManager.getInstance();
    }
    
    public void addStock(String item, int quantity, String location) {
        stockManager.processStockMovement(item, quantity, location);
    }
}