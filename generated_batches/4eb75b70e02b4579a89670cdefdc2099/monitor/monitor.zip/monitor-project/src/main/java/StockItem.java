package com.example.stock;

public class StockItem {
    private String itemId;
    private String name;
    private int currentStock;
    private int reorderThreshold;
    private Supplier supplier;
    
    public StockItem(String itemId, String name, int currentStock, int reorderThreshold) {
        this.itemId = itemId;
        this.name = name;
        this.currentStock = currentStock;
        this.reorderThreshold = reorderThreshold;
    }
    
    public synchronized void updateStock(int quantity) {
        this.currentStock += quantity;
        if (this.currentStock < reorderThreshold) {
            supplier.notifyReorder(this);
        }
    }
    
    public synchronized int getCurrentStock() {
        return currentStock;
    }
    
    public String getItemId() {
        return itemId;
    }
    
    public String getName() {
        return name;
    }
    
    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }
}