package com.example.stock;

import java.util.HashMap;
import java.util.Map;

public class StockManager {
    private Map<String, StockItem> items;
    private Supplier supplier;
    
    public StockManager() {
        this.items = new HashMap<>();
        this.supplier = new Supplier("SUP001", "Primary Supplier");
    }
    
    public synchronized void addItem(String itemId, String name, int initialStock, int reorderThreshold) {
        StockItem item = new StockItem(itemId, name, initialStock, reorderThreshold);
        item.setSupplier(supplier);
        items.put(itemId, item);
    }
    
    public synchronized void updateStock(String itemId, int quantity) {
        StockItem