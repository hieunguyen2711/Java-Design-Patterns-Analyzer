package com.example.stock;

public class Supplier {
    private String supplierId;
    private String name;
    
    public Supplier(String supplierId, String name) {
        this.supplierId = supplierId;
        this.name = name;
    }
    
    public synchronized void notifyReorder(StockItem item) {
        System.out.println("Supplier " + name + " notified to reorder item: " + item.getName());
        // In a real implementation, this would trigger an actual reorder process
        item.updateStock(100); // Simulate restocking
    }
    
    public String getSupplierId() {
        return supplierId;
    }
    
    public String getName() {
        return name;
    }
}