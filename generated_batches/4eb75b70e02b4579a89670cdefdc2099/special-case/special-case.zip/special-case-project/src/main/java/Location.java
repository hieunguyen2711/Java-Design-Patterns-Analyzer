package com.example.stock;

public class Location {
    private String locationId;
    private String description;
    
    public Location(String locationId, String description) {
        this.locationId = locationId;
        this.description = description;
    }
    
    // Getters and setters
    public String getLocationId() { return locationId; }
    public void setLocationId(String locationId) { this.locationId = locationId; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}