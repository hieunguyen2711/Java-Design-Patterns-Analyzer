import java.util.ArrayList;
import java.util.List;

public class Category extends StockItem {
    private List<StockItem> items;
    
    public Category(String name, int quantity) {
        super(name, quantity);
        this.items = new ArrayList<>();
    }
    
    @Override
    public void add(StockItem item) {
        items.add(item);
    }
    
    @Override
    public void remove(StockItem item) {
        items.remove(item);
    }
    
    @Override
    public int getQuantity() {
        int total = quantity;
        for (StockItem item : items) {
            total += item.getQuantity();
        }
        return total;
    }
    
    @Override
    public void display(int depth) {
        StringBuilder indent = new StringBuilder();
        for (int i = 0; i < depth; i++) {
            indent.append("  ");
        }
        System.out.println(indent + "Category: "