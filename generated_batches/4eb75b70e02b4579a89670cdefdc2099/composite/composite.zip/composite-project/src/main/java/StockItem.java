public abstract class StockItem {
    protected String name;
    protected int quantity;
    
    public StockItem(String name, int quantity) {
        this.name = name;
        this.quantity = quantity;
    }
    
    public abstract void add(StockItem item);
    public abstract void remove(StockItem item);
    public abstract int getQuantity();
    public abstract void display(int depth);
}