public class Product extends StockItem {
    private String sku;
    
    public Product(String name, int quantity, String sku) {
        super(name, quantity);
        this.sku = sku;
    }
    
    @Override
    public void add(StockItem item) {
        // Products cannot contain other items
        throw new UnsupportedOperationException("Products cannot contain other items");
    }
    
    @Override
    public void remove(StockItem item) {
        // Products cannot contain other items
        throw new UnsupportedOperationException("Products cannot contain other items");
    }
    
    @Override
    public int getQuantity() {
        return quantity;
    }
    
    @Override
    public void display(int depth) {
        StringBuilder indent = new StringBuilder();
        for (int i = 0; i < depth; i++) {
            indent.append("  ");
        }
        System.out.println(indent + "Product: " + name + " (SKU: " + sku + ") - Quantity: " + quantity);
    }
}