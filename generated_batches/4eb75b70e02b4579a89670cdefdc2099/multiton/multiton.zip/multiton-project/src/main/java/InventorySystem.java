public class InventorySystem {
    public static void main(String[] args) {
        // Using multiton pattern - only one instance per warehouse ID
        WarehouseManager warehouseA = WarehouseManager.getInstance("WH-A");
        WarehouseManager warehouseB = WarehouseManager.getInstance("WH-B");
        
        // Configure locations for warehouse A
        warehouseA.addLocation("A1", 50, 20);
        warehouseA.addLocation("A2", 10, 1