public class StockLocation {
    private final String locationId;
    private int currentStock;
    private final int reorderThreshold;
    
    public StockLocation(String locationId, int initialStock, int reorderThreshold) {
        this.locationId = locationId;
        this.currentStock = initialStock;
        this.reorderThreshold = reorderThreshold;
    }
    
    public String getLocationId() {
        return locationId;
    }
    
    public int getCurrentStock() {
        return currentStock;
    }
    
    public void setCurrentStock(int currentStock) {
        this.currentStock = currentStock;
    }
    
    public int getReorderThreshold() {
        return reorderThreshold;
    }
    
    public boolean needsRestock() {
        return currentStock <= reorderThreshold;
    }
}