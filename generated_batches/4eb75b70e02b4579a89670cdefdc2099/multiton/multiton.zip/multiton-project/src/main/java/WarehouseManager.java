import java.util.HashMap;
import java.util.Map;

public class WarehouseManager {
    private static final Map<String, WarehouseManager> instances = new HashMap<>();
    private final String warehouseId;
    private final Map<String, StockLocation> locations;
    
    private WarehouseManager(String warehouseId) {
        this.warehouseId = warehouseId;
        this.locations = new HashMap<>();
    }
    
    public static synchronized WarehouseManager getInstance(String warehouseId) {
        if (!instances.containsKey(warehouseId)) {
            instances.put(warehouseId, new WarehouseManager(warehouseId));
        }
        return instances.get(warehouseId);
    }
    
    public void addLocation(String locationId, int initialStock, int reorderThreshold) {
        locations.put(locationId, new StockLocation(locationId, initialStock, reorderThreshold));
    }
    
    public StockLocation getLocation(String locationId) {
        return locations.get(locationId);
    }
    
    public String getWarehouseId() {
        return warehouseId;
    }
    
    public Map<String, StockLocation> getAllLocations() {
        return new HashMap<>(locations);
    }
}