package com.example.stock;

public class Supplier {
    private String supplierId;
    private String name;
    private String contactEmail;
    
    public Supplier(String supplierId, String name, String contactEmail) {
        this.supplierId = supplierId;
        this.name = name;
        this.contactEmail = contactEmail;
    }
    
    // Getters and setters
    public String getSupplierId() { return supplierId; }
    public void setSupplierId(String supplierId) { this.supplierId =