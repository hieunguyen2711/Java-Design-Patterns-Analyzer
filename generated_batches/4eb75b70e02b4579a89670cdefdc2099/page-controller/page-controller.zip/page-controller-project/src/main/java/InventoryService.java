import java.util.*;

public class InventoryService {
    private final Map<String, Item> items;
    private final List<MovementLog> movementLogs;
    
    public InventoryService() {
        this.items = new HashMap<>();
        this.movementLogs = new ArrayList<>();
    }
    
    public void updateStock(String itemId, int quantity) {
        Item item = items.get(itemId);
        if (item == null) {
            item = new Item(itemId, 0, 0);
            items.put(itemId, item);
        }
        
        item.setQuantity(item.getQuantity() + quantity);
    }
    
    public void logMovement(MovementLog log) {
        movementLogs.add(log);
    }
    
    public List<MovementLog> getMovementLogs(String itemId) {
        return movementLogs.stream()
                .filter(log -> log.getItemId().equals(itemId))
                .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }
    
    public Item getItem(String itemId) {
        return items.get(itemId);
    }
}