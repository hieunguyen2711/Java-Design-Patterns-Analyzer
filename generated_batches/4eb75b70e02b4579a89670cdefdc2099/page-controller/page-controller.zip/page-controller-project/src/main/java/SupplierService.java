import java.util.*;

public class SupplierService {
    private final Map<String, Supplier> suppliers;
    
    public SupplierService() {
        this.suppliers = new HashMap<>();
        // Initialize with sample data
        suppliers.put("SUP001",