import java.util.*;

public class StockIntakeController {
    private final InventoryService inventoryService;
    private final SupplierService supplierService;
    
    public StockIntakeController(InventoryService inventoryService, SupplierService supplierService) {
        this.inventoryService = inventoryService;
        this.supplierService = supplierService;
    }
    
    public void processStockIntake(String itemId, int quantity, String supplierId) {
        // Validate input
        if (itemId == null || itemId.trim().isEmpty() || quantity <= 0) {
            throw new IllegalArgumentException("Invalid item ID or quantity");
        }
        
        // Check if supplier exists
        Supplier supplier = supplierService.getSupplier(supplierId);
        if (supplier == null) {
            throw new IllegalArgumentException("Supplier not found: " + supplierId);
        }
        
        // Update inventory
        inventoryService.updateStock(itemId, quantity);
        
        // Log the movement
        MovementLog log = new MovementLog(itemId, quantity, "STOCK_INTAKE", supplierId);
        inventoryService.logMovement(log);
    }
}