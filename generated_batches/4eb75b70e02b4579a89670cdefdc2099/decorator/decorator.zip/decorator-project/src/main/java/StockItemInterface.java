public interface StockItemInterface {
    String getName();
    int getQuantity();
    double getPrice();
}