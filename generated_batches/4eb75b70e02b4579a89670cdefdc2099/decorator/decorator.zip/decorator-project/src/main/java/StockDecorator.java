public abstract class StockDecorator implements StockItemInterface {
    protected StockItemInterface stockItem;
    
    public StockDecorator(StockItemInterface stockItem) {
        this.stockItem = stockItem;
    }
    
    @Override
    public String getName() {
        return stockItem.getName();
    }
    
    @Override
    public int getQuantity() {
        return stockItem.getQuantity();
    }
    
    @Override
    public double getPrice() {
        return stockItem.getPrice();
    }
}