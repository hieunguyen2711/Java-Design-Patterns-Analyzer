public class BasicStockItem implements StockItemInterface {
    private StockItem stockItem;
    
    public BasicStockItem(StockItem stockItem) {
        this.stockItem = stockItem;
    }
    
    @Override
    public String getName() {
        return stockItem.getName();
    }
    
    @Override
    public int getQuantity() {
        return stockItem.getQuantity();
    }
    
    @Override
    public double getPrice() {
        return stockItem.getPrice();
    }
}