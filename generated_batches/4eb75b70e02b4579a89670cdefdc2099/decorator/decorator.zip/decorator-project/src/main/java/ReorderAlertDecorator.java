public class ReorderAlertDecorator extends StockDecorator {
    private static final int REORDER_THRESHOLD = 10;
    
    public ReorderAlertDecorator(StockItemInterface stockItem) {
        super(stockItem);
    }
    
    @Override
    public String getName() {
        return super.getName();
    }
    
    @Override
    public int getQuantity() {
        return super.getQuantity();
    }
    
    @Override