public class InventoryReportVisitor implements StockVisitor {
    private StringBuilder report = new StringBuilder();
    
    @Override
    public void visit(Electronics electronics) {
        report.append("Electronics Item: ").append(electronics.getName())
              .append(", Brand: ").append(electronics.getBrand())