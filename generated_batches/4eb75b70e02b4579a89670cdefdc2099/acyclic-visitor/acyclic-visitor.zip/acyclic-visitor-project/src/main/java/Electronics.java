public class Electronics extends StockItem {
    private String brand;
    
    public Electronics(String name, int currentStock, int reorderThreshold, String brand) {
        super(name, currentStock, reorderThreshold);
        this.brand = brand;
    }
    
    @Override
    public void accept(StockVisitor visitor) {
        visitor.visit(this);
    }
    
    // Getters and setters
    public String getBrand() { return brand; }
    public void setBrand(String brand) { this.brand = brand; }
}