public interface StockVisitor {
    void visit(Electronics electronics);
    void visit(Clothing clothing);
}