public abstract class StockItem {
    protected String name;
    protected int currentStock;
    protected int reorderThreshold;
    
    public StockItem(String name, int currentStock, int reorderThreshold) {
        this.name = name;
        this.currentStock = currentStock;
        this.reorderThreshold = reorderThreshold;
    }
    
    public abstract void accept(StockVisitor visitor);
    
    // Getters and setters
    public String getName() { return name; }
    public int getCurrentStock() { return currentStock; }
    public void setCurrentStock(int currentStock) { this.currentStock = currentStock; }
    public int getReorderThreshold() { return reorderThreshold; }
    public void setReorderThreshold(int reorderThreshold) { this.reorderThreshold = reorderThreshold; }
}