public class Clothing extends StockItem {
    private String size;
    
    public Clothing(String name, int currentStock, int reorderThreshold, String size) {
        super(name, currentStock, reorderThreshold);
        this.size = size;
    }
    
    @Override
    public void accept(StockVisitor visitor) {
        visitor.visit(this);
    }
    
    // Getters and setters
    public String getSize() { return size; }
    public void setSize(String size) { this.size = size; }
}