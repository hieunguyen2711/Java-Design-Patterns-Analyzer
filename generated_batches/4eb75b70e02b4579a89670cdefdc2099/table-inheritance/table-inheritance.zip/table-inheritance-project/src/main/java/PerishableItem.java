package com.example.stock;

public class PerishableItem extends StockItem {
    private String expiryDate;
    
    public PerishableItem(String itemId, String name, int currentStock, int reorderThreshold, String expiryDate) {
        super(itemId, name, currentStock, reorderThreshold);
        this.expiryDate = expiryDate;
    }
    
    @Override
    public void processMovement(int quantity) {
        // Special handling for perishable items - check expiration before movement
        if (quantity < 0 && isExpired()) {
            throw new IllegalStateException("Cannot remove expired item: " + name);
        }
        this.currentStock += quantity;
    }
    
    private boolean isExpired() {
        // Simplified expiration check logic
        return false; // In real implementation, would compare with current date
    }
    
    public String getExpiryDate() { return expiryDate; }
    public void setExpiryDate(String expiryDate) { this.expiryDate = expiryDate; }
}