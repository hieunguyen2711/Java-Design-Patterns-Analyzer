package com.example.stock;

public abstract class StockItem {
    protected String itemId;
    protected String name;
    protected int currentStock;
    protected int reorderThreshold;
    
    public StockItem(String itemId, String name, int currentStock, int reorderThreshold) {
        this.itemId = itemId;
        this.name = name;
        this.currentStock = currentStock;
        this.reorderThreshold = reorderThreshold;
    }
    
    public abstract void processMovement(int quantity);
    
    public boolean needsReorder() {
        return currentStock <= reorderThreshold;
    }
    
    // Getters and setters
    public String getItemId() { return itemId; }
    public String getName() { return name; }
    public int getCurrentStock() { return currentStock; }
    public void setCurrentStock(int currentStock) { this.currentStock = currentStock; }
    public int getReorderThreshold() { return reorderThreshold; }
    public void setReorderThreshold(int reorderThreshold) { this.reorderThreshold = reorderThreshold; }
}