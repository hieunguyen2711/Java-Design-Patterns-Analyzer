package com.example.stock;

public class NonPerishableItem extends StockItem {
    private String category;
    
    public NonPerishableItem(String itemId, String name, int currentStock, int reorderThreshold, String category) {
        super(itemId, name, currentStock, reorderThreshold);