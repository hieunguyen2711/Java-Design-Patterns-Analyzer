package com.example.stock;

import java.util.ArrayList;
import java.util.List;

public class StockItem {
    private String itemId;
    private int currentStock;
    private int reorderThreshold;
    private String location;
    private List<String> movementLog;
    
    public StockItem(String itemId, int initialStock, int reorderThreshold, String location) {
        this.itemId = itemId;
        this.currentStock = initialStock;
        this.reorderThreshold = reorderThreshold;
        this.location = location;
        this.movementLog = new ArrayList<>();
        logMovement("Initial stock created: " + initialStock);
    }
    
    public void updateStock(int quantity) {
        int oldStock = this.currentStock;
        this.currentStock += quantity;
        String action = quantity > 0 ? "Added" : "Removed";
        logMovement(action + " " + Math.abs(quantity) + " units. Old: " + oldStock + ", New: " + this.currentStock);
    }
    
    public void setLocation(String location) {
        String oldLocation = this.location;
        this.location = location;
        logMovement("Location changed from " + oldLocation + " to " + location);
    }
    
    private void logMovement(String message) {
        movementLog.add(message);
    }
    
    public Memento createMemento() {
        return new Memento(itemId, currentStock, reorderThreshold, location, new ArrayList<>(movementLog));
    }
    
    public void restoreFromMemento(Memento memento) {
        this.itemId = memento.getItemId();
        this.currentStock = memento.getCurrentStock();
        this.reorderThreshold = memento.getReorderThreshold();
        this.location = memento.getLocation();
        this.movementLog = new ArrayList<>(memento.getMovementLog());
    }
    
    public String getItemId() {
        return itemId;
    }
    
    public int getCurrentStock() {
        return currentStock;
    }
    
    public int getReorderThreshold() {
        return reorderThreshold;
    }
    
    public String getLocation() {
        return location;
    }
    
    public List<String> getMovementLog() {
        return new ArrayList<>(movementLog);
    }
}