package com.example.stock;

import java.util.List;

public class Memento {
    private String itemId;
    private int currentStock;
    private int reorderThreshold;
    private String location;
    private List<String> movementLog;