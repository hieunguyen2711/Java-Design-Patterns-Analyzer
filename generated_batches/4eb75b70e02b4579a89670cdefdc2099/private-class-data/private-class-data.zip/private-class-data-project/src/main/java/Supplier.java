package com.example.stock;

public class Supplier {
    private final String supplierId;
    private final String name;
    
    public Supplier(String supplierId, String name) {
        this.supplierId = supplierId;
        this.name = name;
    }
    
    public void processOrder(StockItem item) {
        System.out.println("Processing order for " + item.getName() + 
                          " from supplier " + name);
    }
    
    // Private class data accessors
    public String getSupplierId() { return supplierId; }
    public String getName() { return name; }
}