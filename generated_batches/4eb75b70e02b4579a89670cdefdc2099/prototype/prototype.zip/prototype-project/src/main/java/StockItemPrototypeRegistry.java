package com.example.stock;

import java.util.HashMap;
import java.util.Map;

public class StockItemPrototypeRegistry {
    private static final Map<String, StockItem> prototypes = new HashMap<>();
    
    static {
        // Register prototype items
        prototypes.put("LAPTOP", new StockItem("LAPTOP", "Laptop Computer", 0, 10, "A-01", "Tech