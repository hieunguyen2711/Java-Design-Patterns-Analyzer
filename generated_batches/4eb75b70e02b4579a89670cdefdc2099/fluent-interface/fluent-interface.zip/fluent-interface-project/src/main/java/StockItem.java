package com.example.stock;

public class StockItem {
    private String name;
    private int quantity;
    private String location;
    private int reorderThreshold;
    private String supplier;
    
    public StockItem(String name) {
        this.name = name;
    }
    
    public StockItem withQuantity(int quantity) {
        this.quantity = quantity;
        return this;
    }
    
    public StockItem atLocation(String location) {
        this.location = location;
        return this;
    }
    
    public StockItem withReorderThreshold(int reorderThreshold) {
        this.reorderThreshold = reorderThreshold;
        return this;
    }
    
    public StockItem fromSupplier(String supplier) {
        this.supplier = supplier;
        return this;
    }
    
    // Getters for testing
    public String getName() { return name; }
    public int getQuantity() { return quantity; }
    public String getLocation() { return location; }
    public int getReorderThreshold() { return reorderThreshold; }
    public String getSupplier() { return supplier; }
}