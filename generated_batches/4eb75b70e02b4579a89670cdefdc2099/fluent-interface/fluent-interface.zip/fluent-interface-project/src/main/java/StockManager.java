package com.example.stock;

public class StockManager {
    
    public static void main(String[] args) {
        // Fluent interface usage example
        StockItem item = new StockItem("Laptop")
                .withQuantity(25)
                .atLocation("A-3-12")
                .withReorderThreshold(5)
                .fromSupplier("TechCorp Inc.");
        
        System.out.println("Item: " + item.getName());
        System.out.println("Quantity: " + item.getQuantity());
        System.out.println("Location: " + item.getLocation());
        System.out.println("Reorder Threshold: " + item.getReorderThreshold());
        System.out.println("Supplier: " + item.getSupplier());
    }
}