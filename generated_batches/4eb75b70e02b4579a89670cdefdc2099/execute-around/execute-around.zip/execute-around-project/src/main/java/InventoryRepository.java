package com.example.stock;

public interface InventoryRepository {
    InventoryItem findById(String id);
    void save(InventoryItem item);
}