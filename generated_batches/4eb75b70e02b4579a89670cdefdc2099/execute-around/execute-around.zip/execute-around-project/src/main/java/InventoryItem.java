package com.example.stock;

public class InventoryItem {
    private String id;
    private int quantity;
    private int reorderThreshold;
    
    public InventoryItem(String id, int quantity, int reorderThreshold) {
        this.id = id;
        this.quantity = quantity;
        this.reorderThreshold = reorderThreshold;
    }
    
    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    
    public int getReorderThreshold() { return