package com.example.stock;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseTransaction implements AutoCloseable {
    private Connection connection;
    private boolean committed = false;
    
    public void begin() throws SQLException {
        connection = DriverManager.getConnection(
            "jdbc:sqlite:test.db", "", "");
        connection.setAutoCommit(false);
    }
    
    public void commit() throws SQLException {
        if (connection != null && !committed) {
            connection.commit();
            committed = true;
        }
    }
    
    @Override
    public void close() throws SQLException {
        if (!committed && connection != null) {
            connection.rollback();
        }
        if (connection != null) {
            connection.close();
        }
    }
}