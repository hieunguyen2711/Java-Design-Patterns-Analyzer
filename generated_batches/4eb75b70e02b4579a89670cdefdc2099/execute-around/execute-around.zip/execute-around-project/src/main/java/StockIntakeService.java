package com.example.stock;

public class StockIntakeService {
    private final InventoryRepository repository;
    
    public StockIntakeService(InventoryRepository repository) {
        this.repository = repository;
    }
    
    public void processStockIntake(String itemId, int quantity) {
        // Execute-around pattern: acquire resources, perform operation, release resources
        try (DatabaseTransaction transaction = new DatabaseTransaction()) {
            transaction.begin();
            
            InventoryItem item = repository.findById(itemId);
            item.setQuantity(item.getQuantity() + quantity);
            repository.save(item);
            
            transaction.commit();
        } catch (Exception e) {
            // Handle exception appropriately
            throw new RuntimeException("Failed to process stock intake", e);
        }
    }
}