package com.example.stock;

public class Location {
    private String locationId;
    private String aisle;
    private String shelf;
    
    public Location(String locationId, String aisle, String shelf) {
        this.locationId = locationId;
        this.aisle = aisle;
        this