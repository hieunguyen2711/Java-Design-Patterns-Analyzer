public class ElectronicsItem extends StockItem {
    
    public ElectronicsItem(String name, int currentStock, int reorderThreshold) {
        super(name, currentStock, reorderThreshold);
    }
    
    @Override
    public void processReorder() {
        System.out.println("Processing reorder for electronics item: " + name);
        // Specific logic for electronics items
    }
}