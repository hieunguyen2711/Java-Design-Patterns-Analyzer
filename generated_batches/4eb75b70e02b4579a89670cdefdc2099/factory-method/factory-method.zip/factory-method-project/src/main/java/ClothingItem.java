public class ClothingItem extends StockItem {
    
    public ClothingItem(String name, int currentStock, int reorderThreshold) {
        super(name, currentStock, reorderThreshold);
    }
    
    @Override
    public void processReorder() {
        System.out.println("Processing reorder for clothing item: " + name);
        // Specific logic for clothing items
    }
}