public abstract class StockItemFactory {
    
    public abstract StockItem createStockItem(String name, int currentStock, int reorderThreshold);
    
    public StockItem createElectronicsItem(String name, int currentStock, int reorderThreshold) {
        return createStockItem(name, currentStock, reorderThreshold);
    }
    
    public StockItem createClothingItem(String name, int currentStock, int reorderThreshold) {
        return createStockItem(name, currentStock, reorderThreshold);
    }
}