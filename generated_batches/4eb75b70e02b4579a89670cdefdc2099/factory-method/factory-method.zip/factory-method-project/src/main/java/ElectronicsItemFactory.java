public class ElectronicsItemFactory extends StockItemFactory {
    
    @Override
    public StockItem createStockItem(String name, int currentStock, int reorderThreshold) {
        return new ElectronicsItem(name, currentStock, reorderThreshold);
    }
}