package com.example.stock.service.impl;

import com.example.stock.service.StockIntakeService;
import java.util.Map;
import java.util.HashMap;

public class InventoryServiceImpl implements StockIntakeService {
    private final Map<String, Integer> inventory = new HashMap<>();
    
    @Override
    public void processStockIntake(String itemId, int quantity) {
        inventory.put(itemId, inventory.getOrDefault(itemId, 0) + quantity);
    }
    
    @Override
    public Map<String, Integer> getInventory() {
        return new HashMap<>(inventory);
    }
}