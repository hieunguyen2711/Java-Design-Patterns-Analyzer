package com.example.stock.service;

import java.util.Map;
import java.util.HashMap;

public interface ReorderThresholdService {
    void setReorderThreshold(String itemId, int threshold);
    Map<String, Integer> getReorderThresholds();
}