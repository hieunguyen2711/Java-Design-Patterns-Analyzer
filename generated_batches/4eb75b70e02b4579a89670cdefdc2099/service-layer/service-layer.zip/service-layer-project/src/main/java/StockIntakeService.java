package com.example.stock.service;

import java.util.List;
import java.util.Map;
import java.util.HashMap;

public interface StockIntakeService {
    void processStockIntake(String itemId, int quantity);
    Map<String, Integer> getInventory();
}