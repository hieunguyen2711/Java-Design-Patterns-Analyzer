package com.example.stock.service.impl;

import com.example.stock.service.ItemLocationService;
import java.util.Map;
import java.util.HashMap;

public class LocationServiceImpl implements ItemLocationService {
    private final Map<String, String> itemLocations = new HashMap<>();
    
    @Override
    public void updateItemLocation(String itemId, String location) {
        itemLocations.put(itemId, location);
    }
    
    @Override
    public Map<String, String> getItemLocations() {
        return new HashMap<>(itemLocations);
    }
}