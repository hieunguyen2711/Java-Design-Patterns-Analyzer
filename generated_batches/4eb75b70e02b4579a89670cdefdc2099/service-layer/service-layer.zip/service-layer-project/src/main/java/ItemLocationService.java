package com.example.stock.service;

import java.util.Map;
import java.util.HashMap;

public interface ItemLocationService {
    void updateItemLocation(String itemId, String location);
    Map<String, String> getItemLocations();
}