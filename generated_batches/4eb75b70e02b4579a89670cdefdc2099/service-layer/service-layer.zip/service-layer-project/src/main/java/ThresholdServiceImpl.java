package com.example.stock.service.impl;

import com.example.stock.service.ReorderThresholdService;
import java.util.Map;
import java.util.HashMap;

public class ThresholdServiceImpl implements ReorderThresholdService {
    private final Map<String, Integer> thresholds = new HashMap<>();
    
    @Override
    public void setReorderThreshold(String itemId, int threshold) {
        thresholds.put(itemId, threshold);