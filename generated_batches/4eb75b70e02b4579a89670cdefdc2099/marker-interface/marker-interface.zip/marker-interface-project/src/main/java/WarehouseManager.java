package com.example.stock;

import java.util.ArrayList;
import java.util.List;

public class WarehouseManager {
    private List<Identifiable> inventory;
    
    public WarehouseManager() {
        this.inventory = new ArrayList<>();
    }
    
    public void addItem(Identifiable item) {
        inventory.add(item);
    }
    
    public Identifiable findItemById(String id) {
        return inventory.stream()
                .filter(item -> item instanceof StockItem)
                .map(item -> (StockItem) item)
                .filter(stockItem -> stockItem.getId().equals(id))
                .findFirst()
                .orElse(null);
    }
}