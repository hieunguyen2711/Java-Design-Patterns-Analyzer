package com.example.stock;

public class StockItem implements Identifiable {
    private final String id;
    private String name;
    private int currentStock;
    private int reorderThreshold;
    
    public StockItem(String id, String name, int currentStock, int reorderThreshold) {
        this.id = id;
        this.name = name;
        this.currentStock = currentStock;
        this.reorderThreshold = reorderThreshold;
    }
    
    // Getters and setters
    public String getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getCurrentStock() { return currentStock; }
    public void setCurrentStock(int currentStock) { this.currentStock = currentStock; }
    public int getReorderThreshold() { return reorderThreshold; }
    public void setReorderThreshold(int reorderThreshold) { this.reorderThreshold = reorderThreshold; }
}