package com.example.stock;

public class Main {
    public static void main(String[] args) {
        WarehouseManager manager = new WarehouseManager();
        
        // Create stock items - they implement the marker interface Identifiable
        StockItem item1 = new StockItem("S001", "Laptop", 25, 10);
        StockItem item2 = new StockItem("S002", "Mouse", 100, 20);
        
        // Add items to warehouse - they are identifiable
        manager.addItem(item