package com.example.stock;

public interface Identifiable {
    // Marker interface - no methods required
    // Used to identify stock items that can be tracked
}