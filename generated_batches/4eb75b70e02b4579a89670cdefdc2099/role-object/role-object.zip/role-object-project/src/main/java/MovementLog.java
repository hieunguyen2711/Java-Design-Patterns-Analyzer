package com.example.stock;

public class MovementLog {
    private String itemId;
    private int quantity;
    private String action;
    
    public MovementLog(String itemId, int quantity, String action) {
        this.itemId = itemId;
        this.quantity = quantity;
        this.action