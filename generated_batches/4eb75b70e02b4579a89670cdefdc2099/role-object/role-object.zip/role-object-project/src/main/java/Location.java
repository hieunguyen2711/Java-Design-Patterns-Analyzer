package com.example.stock;

public class Location {
    private String aisle;
    private String warehouse;
    
    public Location(String aisle, String warehouse) {
        this.aisle = aisle;
        this.warehouse = warehouse;
    }
    
    // Getters and setters
    public String getAisle() { return aisle; }
    public String getWarehouse() { return warehouse; }
}