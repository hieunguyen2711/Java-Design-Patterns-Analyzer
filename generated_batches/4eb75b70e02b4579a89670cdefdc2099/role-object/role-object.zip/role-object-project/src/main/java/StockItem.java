package com.example.stock;

public class StockItem {
    private String itemId;
    private String name;
    private int currentStock;
    private int reorderThreshold;
    private Location location;
    
    public StockItem(String itemId, String name, int currentStock, int reorderThreshold) {
        this.itemId = itemId;
        this.name = name;
        this.currentStock = currentStock;
        this.reorderThreshold = reorderThreshold;
        this.location = new Location("A-01", "Warehouse");
    }
    
    public void updateStock(int quantity) {
        this.currentStock += quantity;
        if (currentStock < reorderThreshold) {
            Supplier.notifyReorder(this);
        }
    }
    
    // Getters and setters
    public String getItemId() { return itemId; }
    public String getName() { return name; }
    public int getCurrentStock() { return currentStock; }
    public int getReorderThreshold() { return reorderThreshold; }
    public Location getLocation() { return location; }
}