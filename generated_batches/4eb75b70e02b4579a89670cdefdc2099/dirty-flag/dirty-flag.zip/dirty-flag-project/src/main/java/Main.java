package com.example.inventory;

public class Main {
    public static void main(String[] args) {
        InventoryManager manager = new InventoryManager();
        
        StockItem item1 = new StockItem("ITEM001", "Laptop", 50,