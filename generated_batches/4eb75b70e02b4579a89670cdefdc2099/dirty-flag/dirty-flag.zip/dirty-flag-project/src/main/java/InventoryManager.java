package com.example.inventory;

import java.util.ArrayList;
import java.util.List;

public class InventoryManager {
    private List<StockItem> items;
    
    public InventoryManager() {
        this.items = new ArrayList<>();
    }
    
    public void addItem(StockItem item) {
        items.add(item);
    }
    
    public void processDirtyItems() {
        for (StockItem item : items) {
            if (item.isDirty()) {
                System.out.println("Processing dirty item: " + item.getItemId());
                // In a real system, this would save to database
                item.clearDirtyFlag();
            }
        }
    }
    
    public void updateStock(String itemId, int quantity) {
        for (StockItem item : items) {
            if (item.getItemId().equals(itemId)) {
                item.updateStock(quantity);
                break;
            }
        }
    }
}