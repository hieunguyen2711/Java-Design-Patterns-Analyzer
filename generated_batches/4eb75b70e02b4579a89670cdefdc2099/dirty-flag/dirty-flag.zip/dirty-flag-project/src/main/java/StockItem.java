package com.example.inventory;

public class StockItem {
    private String itemId;
    private String name;
    private int currentStock;
    private int reorderThreshold;
    private boolean dirtyFlag = false;
    
    public StockItem(String itemId, String name, int currentStock, int reorderThreshold) {
        this.itemId = itemId;
        this.name = name;
        this.currentStock = currentStock;
        this.reorderThreshold = reorderThreshold;
    }
    
    public void updateStock(int quantity) {
        this.currentStock += quantity;
        setDirty(true);
    }
    
    public void setReorderThreshold(int threshold) {
        this.reorderThreshold = threshold;
        setDirty(true);
    }
    
    public boolean isDirty() {
        return dirtyFlag;
    }
    
    public void setDirty(boolean dirty) {
        this.dirtyFlag = dirty;
    }
    
    public void clearDirtyFlag() {
        this.dirtyFlag = false;
    }
    
    // Getters
    public String getItemId() { return itemId; }
    public String getName() { return name; }
    public int getCurrentStock() { return currentStock; }
    public int getReorderThreshold() { return reorderThreshold; }
}