public class Main {
    public static void main(String[] args) {
        StockIntakeFacade facade = new StockIntakeFacade();
        
        //