public class StockIntakeFacade {
    private InventoryManager inventoryManager;
    private ReorderManager reorderManager;
    private SupplierManager supplierManager;
    private MovementLogger movementLogger;

    public StockIntakeFacade() {
        this.inventoryManager = new InventoryManager();
        this.reorderManager = new ReorderManager();
        this.supplierManager = new SupplierManager();
        this.movementLogger = new MovementLogger();
    }

    public void processStockIntake(String itemId, int quantity, String location) {
        inventoryManager.updateInventory(itemId, quantity, location);
        reorderManager.checkReorderThreshold(itemId, quantity);
        movementLogger.logMovement(itemId, quantity, "INTAKE", location);
    }

    public void processStockRestock(String itemId, int quantity) {
        inventoryManager.updateInventory(itemId, quantity, "RESTOCK");
        supplierManager.notifySupplier(itemId, quantity);
        movementLogger.logMovement(itemId, quantity, "RESTOCK", "SUPPLIER");
    }
}