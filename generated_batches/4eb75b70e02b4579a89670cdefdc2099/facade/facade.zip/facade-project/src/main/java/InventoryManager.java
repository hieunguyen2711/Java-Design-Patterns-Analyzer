public class InventoryManager {
    public void updateInventory(String itemId, int quantity, String location) {
        System.out.println("Updating inventory for item " + itemId + 
                          " with quantity " + quantity + " at location " + location);
    }
}