public class MovementLogger {
    public void logMovement(String itemId, int quantity, String type, String location) {
        System.out.println("Logging movement - Item: " + itemId + 
                          ", Quantity: " + quantity + 
                          ", Type: " + type + 
                          ", Location: " + location);
    }
}