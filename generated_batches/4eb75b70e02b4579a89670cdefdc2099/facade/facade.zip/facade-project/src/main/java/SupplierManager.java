public class SupplierManager {
    public void notifySupplier(String itemId, int quantity) {
        System.out.println("Notifying supplier to restock item " + itemId + 
                          " with quantity " + quantity);
    }
}