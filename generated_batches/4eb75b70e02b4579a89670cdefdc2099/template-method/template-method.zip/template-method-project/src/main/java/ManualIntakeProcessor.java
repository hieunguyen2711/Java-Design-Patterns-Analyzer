package com.example.stock;

public class ManualIntakeProcessor extends StockIntakeProcessor {
    
    @Override
    protected void validateItem(StockItem item) {
        System.out.println("Manually validating item: " + item.getName());
        // Manual validation logic here
    }
    
    @Override
    protected void updateInventory(StockItem item) {
        System.out.println("Updating inventory manually for: " + item.getName());
        // Manual inventory update logic here
    }
    
    @Override
    protected void checkReorderThreshold(StockItem item) {
        System.out.println("Checking reorder threshold manually for: " + item.getName());
        // Manual reorder logic here
    }
    
    @Override
    protected void logMovement(StockItem item) {
        System.out.println("Logging manual movement for: " + item.getName());
        // Manual logging logic here
    }
}