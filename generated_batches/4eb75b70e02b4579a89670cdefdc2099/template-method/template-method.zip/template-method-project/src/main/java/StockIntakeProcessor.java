package com.example.stock;

public abstract class StockIntakeProcessor {
    
    public final void processStockIntake(StockItem item) {
        System.out.println("Processing stock intake for " + item.getName());
        
        validateItem(item);
        updateInventory(item);
        checkReorderThreshold(item);
        logMovement(item);
    }
    
    protected abstract void validateItem(StockItem item);
    
    protected abstract void updateInventory(StockItem item);
    
    protected abstract void checkReorderThreshold(StockItem item);
    
    protected abstract void logMovement(StockItem item);
}