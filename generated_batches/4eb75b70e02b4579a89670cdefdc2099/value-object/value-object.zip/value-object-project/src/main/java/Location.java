package com.example.stock;

public class Location {
    private final String aisle;
    private final String shelf;
    private final String bin;
    
    public Location(String aisle, String shelf, String bin) {
        this.aisle = aisle;
        this.shelf = shelf;
        this.bin = bin;
    }
    
    public String getAisle() {
        return aisle;
    }
    
    public String getShelf() {
        return shelf;
    }
    
    public String getBin() {
        return bin;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        
        Location location = (Location) obj;
        return aisle.equals(location.aisle) &&
               shelf.equals(location.shelf) &&
               bin.equals(location.bin);
    }
    
    @Override
    public int hashCode() {
        int result = aisle.hashCode();
        result =