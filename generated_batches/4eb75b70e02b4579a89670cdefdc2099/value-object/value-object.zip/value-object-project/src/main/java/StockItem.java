package com.example.stock;

public class StockItem {
    private final String itemId;
    private final String name;
    private final int currentStock;
    private final int reorderThreshold;
    
    public StockItem(String itemId, String name, int currentStock, int reorderThreshold) {
        this.itemId = itemId;
        this.name = name;
        this.currentStock = currentStock;
        this.reorderThreshold = reorderThreshold;
    }
    
    public String getItemId() {
        return itemId;
    }
    
    public String getName() {
        return name;
    }
    
    public int getCurrentStock() {
        return currentStock;
    }
    
    public int getReorderThreshold() {
        return reorderThreshold;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        
        StockItem stockItem = (StockItem) obj;
        return itemId.equals(stockItem.itemId);
    }
    
    @Override
    public int hashCode() {
        return itemId.hashCode();
    }
    
    @Override
    public String toString() {
        return "StockItem{" +
                "itemId='" + itemId + '\'' +
                ", name='" + name + '\'' +
                ", currentStock=" + currentStock +
                ", reorderThreshold=" + reorderThreshold +
                '}';
    }
}