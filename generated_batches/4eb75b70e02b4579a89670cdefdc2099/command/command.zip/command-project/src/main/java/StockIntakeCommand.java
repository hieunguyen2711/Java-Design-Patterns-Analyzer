public interface StockIntakeCommand {
    void execute();
}