import java.util.HashMap;
import java.util.Map;

public class InventoryManager {
    private final Map<String, Integer> stockLevels;
    private final Map<String, Integer> reorderThresholds;
    private final MovementLog movementLog;

    public InventoryManager() {
        this.stockLevels = new HashMap<>();
        this.reorderThresholds = new HashMap<>();
        this.movementLog = new MovementLog();
    }

    public void addStock(String itemId, int quantity) {
        stockLevels.put(itemId, stockLevels.getOrDefault(itemId, 0) + quantity);
        movementLog.logMovement("ADD", itemId, quantity);
        checkReorderThreshold(itemId);
    }

    public void removeStock(String itemId, int quantity) {
        int current = stockLevels.getOrDefault(itemId, 0);
        if (current >= quantity) {
            stockLevels.put(itemId, current - quantity);
            movementLog.logMovement("REMOVE", itemId, quantity);
            checkReorderThreshold(itemId);
        } else {
            throw new IllegalArgumentException("Insufficient stock for item: " + itemId);
        }
    }

    public void setReorderThreshold(String itemId, int threshold) {
        reorderThresholds.put(itemId, threshold);
    }

    private void checkReorderThreshold(String itemId) {
        Integer currentStock = stockLevels.get(itemId