public class RemoveStockCommand implements StockIntakeCommand {
    private final InventoryManager inventoryManager;
    private final String itemId;
    private final int quantity;

    public RemoveStockCommand(InventoryManager inventoryManager, String itemId, int quantity) {
        this.inventoryManager = inventoryManager;
        this.itemId = itemId;
        this.quantity = quantity;
    }

    @Override
    public void execute() {
        inventoryManager.removeStock(itemId, quantity);
    }
}