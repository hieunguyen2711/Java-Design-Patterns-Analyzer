package com.example.stock;

public abstract class Request {
    protected final String itemId;
    protected final int quantity;
    
    public Request(String itemId, int quantity) {
        this.itemId = itemId;
        this.quantity = quantity;
    }
    
    public String getItemId() { return itemId; }
    public int getQuantity() { return quantity; }
    
    public abstract void execute(StockManager manager);
}