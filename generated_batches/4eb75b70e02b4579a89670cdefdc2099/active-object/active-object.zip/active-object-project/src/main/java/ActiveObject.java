package com.example.stock;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public interface ActiveObject {
    void submitRequest(Request request);
}