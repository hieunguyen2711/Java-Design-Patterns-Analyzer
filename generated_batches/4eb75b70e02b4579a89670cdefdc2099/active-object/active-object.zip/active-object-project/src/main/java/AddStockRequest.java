package com.example.stock;

public class AddStockRequest extends Request {
    private final String location;
    
    public AddStockRequest(String itemId, int quantity