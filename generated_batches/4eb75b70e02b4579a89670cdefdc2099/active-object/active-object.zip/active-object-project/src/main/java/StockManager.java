package com.example.stock;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;

public class StockManager {
    private final Map<String, Integer> inventory = new HashMap<>();
    private final Map<String, Integer> reorderThresholds = new HashMap<>();
    private final ReentrantLock lock = new ReentrantLock();
    
    public void addItem(String itemId, int initialQuantity) {
        lock.lock();
        try {
            inventory.put(itemId, initialQuantity);
        } finally {
            lock.unlock();
        }
    }
    
    public boolean updateStock(String itemId, int quantityChange) {
        lock.lock();
        try {
            Integer current = inventory.get(itemId);
            if (current == null || current + quantityChange < 0) {
                return false;
            }
            
            int newQuantity = current + quantityChange;
            inventory.put(itemId, newQuantity);
            
            // Check reorder threshold
            Integer threshold = reorderThresholds.get(itemId);
            if (threshold != null && newQuantity <= threshold) {
                System.out.println("ALERT: Item " + itemId + " is below reorder threshold of " + threshold);
            }
            
            return true;
        } finally {
            lock.unlock();
        }
    }
    
    public int getStock(String itemId) {
        lock.lock();
        try {
            return inventory.getOrDefault(itemId, 0);
        } finally {
            lock.unlock();
        }
    }
    
    public void setReorderThreshold(String itemId, int threshold) {
        reorderThresholds.put(itemId, threshold);
    }
}