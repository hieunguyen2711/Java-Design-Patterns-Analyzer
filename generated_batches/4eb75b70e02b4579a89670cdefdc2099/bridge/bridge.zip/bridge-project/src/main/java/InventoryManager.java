public class InventoryManager {
    private StockItem[] items;
    
    public InventoryManager(StockItem[] items) {
        this.items = items;
    }
    
    public void updateInventory(String itemName, int quantity) {
        for (StockItem item : items) {
            if (item.getName().equals(itemName)) {
                item.updateStock(quantity);
                break;
            }
        }
    }