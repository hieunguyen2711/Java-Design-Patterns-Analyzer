public abstract class Supplier {
    protected String name;
    
    public Supplier(String name) {
        this.name = name;
    }
    
    public abstract void orderRestock(StockItem item);
    
    public String getName() { return name; }
}