public class StockItem {
    private String name;
    private int currentStock;
    private int reorderThreshold;
    private Supplier supplier;
    
    public StockItem(String name, int currentStock, int reorderThreshold, Supplier supplier) {
        this.name = name;
        this.currentStock = currentStock;
        this.reorderThreshold = reorderThreshold;
        this.supplier = supplier;
    }
    
    public void updateStock(int quantity) {
        this.currentStock += quantity;
        if (currentStock <= reorderThreshold) {
            supplier.orderRestock(this);
        }
    }
    
    public String getName() { return name; }
    public int getCurrentStock() { return currentStock; }
    public int getReorderThreshold() { return reorderThreshold; }
    public Supplier getSupplier() { return supplier; }
}