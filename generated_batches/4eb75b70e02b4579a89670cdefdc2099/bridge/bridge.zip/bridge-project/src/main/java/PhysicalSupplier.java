public class PhysicalSupplier extends Supplier {
    
    public PhysicalSupplier(String name) {
        super(name);
    }
    
    @Override
    public void orderRestock(StockItem item) {
        System.out.println("Physical supplier " + name + 
                          " ordering restock for " + item.getName() + 
                          ". Current stock: " + item.getCurrentStock());
    }
}