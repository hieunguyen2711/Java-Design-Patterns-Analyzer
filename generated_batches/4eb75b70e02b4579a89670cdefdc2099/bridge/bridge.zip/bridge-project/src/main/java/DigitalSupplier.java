public class DigitalSupplier extends Supplier {
    
    public DigitalSupplier(String name) {
        super(name);
    }
    
    @Override
    public void orderRestock(StockItem item) {
        System.out.println("Digital supplier " + name + 
                          " placing digital order for " + item.getName() + 
                          ". Current stock: " + item.getCurrentStock());
    }
}