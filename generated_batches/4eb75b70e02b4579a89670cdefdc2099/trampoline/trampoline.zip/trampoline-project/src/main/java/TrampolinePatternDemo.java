public class TrampolinePatternDemo {
    public static void main(String[] args) {
        // Demonstrating trampoline pattern with recursive Fibonacci calculation
        System.out.println("Fibonacci(10): " + fibonacci(10));
        System.out.println("Fibonacci(20): " + fibonacci(20));
    }
    
    private static long fibonacci(int n) {
        return fibHelper(n, 0, 1).result();
    }
    
    private static Trampoline<Long> fibHelper(int n, long acc, long current) {
        if (n == 0) {
            return Trampoline.done(acc);
        } else {
            return Trampoline.continueWith(() -> fibHelper(n - 1, current, acc + current));
        }
    }
}