@FunctionalInterface
public interface Trampoline<T> {
    T result();
    
    static <T> Trampoline<T> done(T value) {
        return () -> value;
    }
    
    static <T> Trampoline<T> continueWith(java.util.function.Supplier<Trampoline<T>> computation) {
        return new Trampoline<T>() {
            @Override
            public T result() {
                Trampoline<T> current = this;
                while (current instanceof Continue<T>) {
                    current = ((Continue<T>) current).computation.get();
                }
                return current.result();
            }
        };
    }
    
    class Continue<T> implements Trampoline<T> {
        final java.util.function.Supplier<Trampoline<T>> computation;
        
        Continue(java.util.function.Supplier<Trampoline<T>> computation) {
            this.computation = computation;
        }
        
        @Override
        public T result() {
            throw new UnsupportedOperationException("Use result() on the outer trampoline");
        }
    }
}