public abstract class StockIntakeHandler {
    protected StockIntakeHandler nextHandler;
    
    public void setNext(StockIntakeHandler handler) {
        this.nextHandler = handler;
    }
    
    public abstract boolean handleRequest(StockItem item);
}