public class SupplierRestockHandler extends StockIntakeHandler {
    @Override
    public boolean handleRequest(StockItem item) {
        if (item.getQuantity() <= 0) {
            System.out.println("Contacting supplier for " + item.getName());
            return true;
        }
        
        if (nextHandler != null) {
            return nextHandler.handleRequest(item);
        }
        
        return false;
    }
}