public class MovementLogHandler extends StockIntakeHandler {
    @Override
    public boolean handleRequest(StockItem item) {
        System.out.println("Logging movement for " + item.getName() + ". New quantity: " + item.getQuantity());
        
        if (nextHandler != null) {
            return nextHandler.handleRequest(item);
        }
        
        return true;
    }
}