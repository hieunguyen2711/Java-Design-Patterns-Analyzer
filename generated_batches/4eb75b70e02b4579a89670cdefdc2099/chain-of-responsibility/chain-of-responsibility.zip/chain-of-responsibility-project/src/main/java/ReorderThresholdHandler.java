public class ReorderThresholdHandler extends StockIntakeHandler {
    @Override
    public boolean handleRequest(StockItem item) {
        if (item.getQuantity() <= item.getReorderThreshold()) {
            System.out.println("Alert: " + item.getName() + " is below reorder threshold. Current quantity: " + item.getQuantity());
            return true;
        }
        
        if (nextHandler != null) {
            return nextHandler.handleRequest(item);
        }
        
        return false;
    }
}