import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class StockActor {
    private final BlockingQueue<StockMessage> messageQueue = new LinkedBlockingQueue<>();
    private volatile boolean running = true;
    
    public void start() {
        Thread actorThread = new Thread(() -> {
            while (running) {
                try {
                    StockMessage message = messageQueue.take();
                    handleMessage(message);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        });
        actorThread.start();
    }
    
    public void stop() {
        running = false;
    }
    
    public void send(StockMessage message) {
        try {
            messageQueue.put(message);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
    
    private void handleMessage(StockMessage message) {
        switch (message.getType()) {
            case INCREASE:
                increaseStock(message.getItem(), message.getQuantity());
                break;
            case DECREASE:
                decreaseStock(message.getItem(), message.getQuantity());
                break;
            case CHECK_REORDER:
                checkReorderThreshold(message.getItem());
                break;
        }
    }
    
    private void increaseStock(String item, int quantity) {
        System.out.println("Increasing stock for " + item + " by " + quantity);
    }
    
    private void decreaseStock(String item, int quantity) {
        System.out.println("Decreasing stock for " + item + " by " + quantity);
    }
    
    private void checkReorderThreshold(String item) {
        System.out.println("Checking reorder threshold for " + item);
    }
}