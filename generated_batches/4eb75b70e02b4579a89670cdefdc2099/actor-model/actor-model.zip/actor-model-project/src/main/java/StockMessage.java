public class StockMessage {
    public enum MessageType {
        INCREASE, DECREASE, CHECK_REORDER
    }
    
    private final MessageType type;
    private final String item;
    private final int quantity;
    
    public StockMessage(MessageType type, String item, int quantity) {
        this.type = type;
        this.item = item;
        this.quantity = quantity;
    }
    
    public MessageType getType() {
        return type;
    }
    
    public String getItem() {
        return item;
    }
    
    public int getQuantity() {
        return quantity;
    }
}