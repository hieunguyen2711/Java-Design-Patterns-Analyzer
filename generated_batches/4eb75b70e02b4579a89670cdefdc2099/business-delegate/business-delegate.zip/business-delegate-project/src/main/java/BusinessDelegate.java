public class BusinessDelegate {
    private StockIntakeService stockIntakeService;
    private ItemLocationService itemLocationService;
    private ReorderThresholdService reorderThresholdService;
    private SupplierRestockingService supplierRestockingService;
    private MovementLogService movementLogService;

    public void setStockIntakeService(StockIntakeService stockIntakeService) {
        this.stockIntakeService = stockIntakeService;
    }

    public void setItemLocationService(ItemLocationService itemLocationService) {
        this.itemLocationService = itemLocationService;
    }

    public void setReorderThresholdService(ReorderThresholdService reorderThresholdService) {
        this.reorderThresholdService = reorderThresholdService;
    }

    public void setSupplierRestockingService(SupplierRestockingService supplierRestockingService) {
        this.supplierRestockingService = supplierRestockingService;
    }

    public void setMovementLogService(MovementLogService movementLogService) {
        this.movementLogService = movementLogService;
    }

    public void processStockIntake(String itemId, int quantity) {
        stockIntakeService.processIntake(itemId, quantity);
    }

    public void updateItemLocation(String itemId, String location) {
        itemLocationService.updateLocation(itemId, location);
    }

    public void checkReorderThreshold(String itemId) {
        reorderThresholdService.checkThreshold(itemId);
    }

    public void restockFromSupplier(String itemId, int quantity) {
        supplierRestockingService.restock(itemId, quantity);
    }

    public void logMovement(String itemId, String fromLocation, String toLocation) {
        movementLogService.logMovement(itemId, fromLocation, toLocation);
    }
}