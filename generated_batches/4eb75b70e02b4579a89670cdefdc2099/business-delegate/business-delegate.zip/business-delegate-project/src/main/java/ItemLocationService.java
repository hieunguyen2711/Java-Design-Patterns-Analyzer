public class ItemLocationService {
    public void updateLocation(String itemId, String location) {
        System.out.println("Updating location for item " + itemId + " to " + location);
    }
}