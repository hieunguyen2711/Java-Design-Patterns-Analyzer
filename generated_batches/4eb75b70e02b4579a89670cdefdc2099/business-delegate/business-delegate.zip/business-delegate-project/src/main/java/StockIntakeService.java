public class StockIntakeService {
    public void processIntake(String itemId, int quantity) {
        System.out.println("Processing stock intake for item " + itemId + ", quantity: " + quantity);
    }
}