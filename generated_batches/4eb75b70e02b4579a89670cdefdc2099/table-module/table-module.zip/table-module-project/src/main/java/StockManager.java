package com.example.stock;

import java.util.*;

public class StockManager {
    private Map<String, StockItem> stockItems;
    private List<StockMovementLog> movementLogs;
    
    public StockManager() {
        this.stockItems = new HashMap<>();
        this.movementLogs = new ArrayList<>();
    }
    
    public void addItem(StockItem item) {
        stockItems.put(item.getItemId(), item);
    }
    
    public void updateStock(String itemId, int quantity) {
        StockItem item = stockItems.get(itemId);
        if (item != null) {
            int oldQuantity = item.getCurrentStock();
            item.setCurrentStock(item.getCurrentStock() + quantity);
            logMovement(itemId, "STOCK_UPDATE", oldQuantity, item.getCurrentStock());
            
            // Check if reorder is needed
            if (item.getCurrentStock() <= item.getReorderThreshold()) {
                System.out.println("ALERT: Item " + item.getName() + " needs reordering. Current stock: " + 
                                 item.getCurrentStock());
            }
        }
    }
    
    public void moveItem(String itemId, String newLocation) {
        StockItem item = stockItems.get(itemId);
        if (