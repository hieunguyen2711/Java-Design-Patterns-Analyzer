package com.example.stock;

public class StockItem {
    private String itemId;
    private int currentStock;
    private int reorderThreshold;
    
    public StockItem(String itemId, int initialStock, int reorderThreshold) {
        this.itemId = itemId;
        this.currentStock = initialStock;
        this.reorderThreshold = reorderThreshold;
    }
    
    public void addStock(int quantity) {
        this.currentStock += quantity;
    }
    
    public boolean removeStock(int quantity) {
        if (this.currentStock >= quantity) {
            this.currentStock -= quantity;
            return true;
        }
        return false;
    }
    
    public String getItemId() {
        return itemId;
    }
    
    public int getCurrentStock() {
        return currentStock;
    }
    
    public int getReorderThreshold() {
        return reorderThreshold;
    }
}