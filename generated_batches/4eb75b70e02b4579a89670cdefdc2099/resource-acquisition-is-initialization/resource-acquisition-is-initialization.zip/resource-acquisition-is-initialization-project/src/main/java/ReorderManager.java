package com.example.stock;

public class ReorderManager {
    private InventoryManager inventoryManager;
    
    public ReorderManager(InventoryManager inventoryManager) {
        this.inventoryManager = inventoryManager;
    }
    
    public boolean shouldReorder(String itemId) {
        StockItem item = inventoryManager.getItem(itemId);
        return item != null && item.getCurrentStock() <= item.getReorderThreshold();
    }
    
    public void processReorder(String itemId, int reorderQuantity) {
        if (shouldReorder(itemId)) {
            inventoryManager.add