package com.example.stock;

import java.util.HashMap;
import java.util.Map;

public class InventoryManager {
    private Map<String, StockItem> inventory;
    
    public InventoryManager() {
        this.inventory = new HashMap<>();
    }
    
    public void addItem(String itemId, int initialStock, int reorderThreshold) {
        inventory.put(itemId, new StockItem(itemId, initialStock, reorderThreshold));
    }
    
    public boolean addStock(String itemId, int quantity) {
        StockItem item = inventory.get(itemId);
        if (item != null) {
            item.addStock(quantity);
            return true;
        }
        return false;
    }
    
    public boolean removeStock(String itemId, int quantity) {
        StockItem item = inventory.get(itemId);
        if (item != null) {
            return item.removeStock(quantity);
        }
        return false;
    }
    
    public StockItem getItem(String itemId) {
        return inventory.get(itemId);
    }
}