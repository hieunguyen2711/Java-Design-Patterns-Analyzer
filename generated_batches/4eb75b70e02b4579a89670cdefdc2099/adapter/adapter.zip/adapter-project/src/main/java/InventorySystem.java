import java.util.*;

public class InventorySystem {
    private Map<String, StockItem> stockItems;
    
    public InventorySystem() {
        this.stockItems = new HashMap<>();
    }
    
    public void addItem(StockItem item) {
        stockItems.put(item.getItemId(), item);
    }
    
    public StockItem getItem(String itemId) {
        return stockItems.get(itemId);
    }
    
    public List<StockItem> getLowStockItems() {
        List<StockItem> lowStock = new ArrayList<>();
        for (StockItem item :