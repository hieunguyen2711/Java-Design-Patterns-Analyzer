public class Main {
    public static void main(String[] args) {
        StockInventory inventory = new StockInventory();
        
        inventory.addItem(new StockItem("Laptop", 10, 5));
        inventory.addItem(new StockItem("Mouse", 25, 10));
        inventory.addItem(new StockItem("Keyboard", 15, 8));
        
        System.out.println("Iterating through stock items:");
        for (StockItem item : inventory) {
            System.out.println("- " + item.getName() + ": " + item.getQuantity());
        }
    }
}