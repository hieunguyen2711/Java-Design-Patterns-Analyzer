import java.util.ArrayList;
import java.util.Iterator;

public class StockInventory implements Iterable<StockItem> {
    private ArrayList<StockItem> items;
    
    public StockInventory() {
        this.items = new ArrayList<>();
    }
    
    public void addItem(StockItem item) {
        items.add(item);
    }
    
    public void removeItem(StockItem item) {
        items.remove(item);
    }
    
    @Override
    public Iterator<StockItem> iterator() {
        return new StockInventoryIterator();
    }
    
    private class StockInventoryIterator implements Iterator<StockItem> {
        private int currentIndex = 0;
        
        @Override
        public boolean hasNext() {
            return currentIndex < items.size();
        }
        
        @Override
        public StockItem next() {
            if (!hasNext()) {
                throw new java.util.NoSuchElementException();
            }
            return items.get(currentIndex++);
        }
    }
}