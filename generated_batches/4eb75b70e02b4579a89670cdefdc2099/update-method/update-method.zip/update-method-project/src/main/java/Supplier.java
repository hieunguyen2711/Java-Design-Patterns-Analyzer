package com.example.stock;

public interface Supplier {
    void notifyReorder(StockItem item);
}