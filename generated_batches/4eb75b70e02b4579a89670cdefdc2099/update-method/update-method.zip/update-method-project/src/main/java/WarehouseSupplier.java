package com.example.stock;

import java.util.ArrayList;
import java.util.List;

public class WarehouseSupplier implements Supplier {
    private String supplierId;
    private String name;
    private List<StockItem> itemsToRestock;
    
    public WarehouseSupplier(String supplierId, String name) {
        this.supplierId = supplierId;
        this.name = name;
        this.itemsToRestock = new ArrayList<>();
    }
    
    @Override
    public void notifyReorder(StockItem item) {
        System.out.println("Supplier " + name + " notified of reorder for item: " + item.getName());
        itemsToRestock.add(item);
        restockItem(item);
    }
    
    private void restockItem(StockItem item) {
        // Simulate restocking process
        int restockQuantity = Math.max(10, item.getReorderThreshold() - item.getCurrentStock() + 20);
        System.out.println("Restocking " + restockQuantity + " units of " + item.getName());
        item.updateStock(restockQuantity);
    }
    
    public String getSupplierId() { return supplierId; }
    public String getName() { return name; }
    public List<StockItem> getItemsToRest