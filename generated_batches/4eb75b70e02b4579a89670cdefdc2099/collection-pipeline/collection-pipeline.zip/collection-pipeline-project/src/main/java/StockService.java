package com.example.stock;

import java.util.*;
import java.util.stream.Collectors;

public class StockService {
    private List<StockItem> stockItems;
    
    public StockService() {
        this.stockItems = new ArrayList<>();
    }
    
    public void addStockItem(StockItem item) {
        stockItems.add(item);
    }
    
    // Collection-pipeline pattern: filter, map, collect
    public List<String> getLowStockItemsByLocation(String location) {
        return stockItems.stream()
                .filter(item -> item.getCurrentStock() <= item.getReorderThreshold())
                .filter(item -> location.equals(item.getLocation()))
                .map(StockItem::getName)
                .collect(Collectors.toList());
    }
    
    // Collection-pipeline pattern: filter, map, sorted, collect
    public List<StockItem> getItemsBelowThresholdSortedByStock() {
        return stockItems.stream()
                .filter(item -> item.getCurrentStock() <= item.getReorderThreshold())
                .sorted(Comparator.comparingInt(StockItem::getCurrentStock))
                .collect(Collectors.toList());
    }
    
    // Collection-pipeline pattern: filter, map, reduce
    public int