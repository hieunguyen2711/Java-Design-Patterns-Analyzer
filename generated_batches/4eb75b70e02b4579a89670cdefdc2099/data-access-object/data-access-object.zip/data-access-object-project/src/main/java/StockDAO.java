package com.example.stock;

import java.util.List;

public interface StockDAO {
    StockItem getItemById(int id);
    List<StockItem> getAllItems();
    void saveItem(StockItem item);
    void updateItem(StockItem item);
    void deleteItem(int id);
}