package com.example.stock;

import java.util.ArrayList;
import java.util.List;

public class StockDAOImpl implements StockDAO {
    private List<StockItem> items = new ArrayList<>();
    
    @Override
    public StockItem getItemById(int id) {
        for (StockItem item : items) {
            if (item.getId() == id) {
                return item;
            }
        }
        return null;
    }
    
    @Override
    public List<StockItem> getAllItems() {
        return new ArrayList<>(items);
    }
    
    @Override
    public void saveItem(StockItem item) {
        items.add(item);
    }
    
    @Override
    public void updateItem(StockItem item) {
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).getId() == item.getId()) {
                items.set(i, item);
                break;
            }
        }
    }
    
    @Override
    public void deleteItem(int id) {
        items.removeIf(item -> item.getId