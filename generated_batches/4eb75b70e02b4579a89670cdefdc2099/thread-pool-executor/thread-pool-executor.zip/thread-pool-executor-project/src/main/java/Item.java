package com.example.stock;

public class Item {
    private String name;
    private int quantity;
    private int reorderThreshold;
    
    public Item(String name, int quantity, int reorderThreshold) {
        this.name = name;
        this.quantity = quantity;
        this.reorderThreshold = reorderThreshold;
    }
    
    // Getters and setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    
    public int getReorderThreshold() { return reorderThreshold; }
    public void setReorderThreshold(int reorderThreshold) { this.reorderThreshold = reorderThreshold; }
}