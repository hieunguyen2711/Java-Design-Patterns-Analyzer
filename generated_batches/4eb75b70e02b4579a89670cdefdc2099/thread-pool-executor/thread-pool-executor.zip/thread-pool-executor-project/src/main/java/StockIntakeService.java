package com.example.stock;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class StockIntakeService {
    private final ExecutorService executorService;
    
    public StockIntakeService() {
        this.executorService = Executors.newFixedThreadPool(3);
    }
    
    public void processStockIntake(Item item, int quantity) {
        executorService.submit(() -> {
            try {
                // Simulate stock intake processing
                Thread.sleep(1000);
                System.out.println("Processing intake for " + item.getName() + 
                                 ": " + quantity + " units");
                
                // Update inventory logic here
                item.setQuantity(item.getQuantity() + quantity);
                
                // Log movement
                MovementLog.logMovement(item, quantity, "INTAKE");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
    }
    
    public void shutdown() {
        executorService.shutdown();
        try {
            if (!executorService.awaitTermination(60, TimeUnit.SECONDS)) {
                executorService.shutdownNow();
            }
        } catch (InterruptedException e) {
            executorService.shutdownNow();
        }
    }
}