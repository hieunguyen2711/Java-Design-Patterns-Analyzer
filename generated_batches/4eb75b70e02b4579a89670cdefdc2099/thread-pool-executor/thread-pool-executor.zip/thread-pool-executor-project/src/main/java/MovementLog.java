package com.example.stock;

public class MovementLog {
    public static void logMovement(Item item, int quantity, String type) {
        System.out.println("LOG [" + type + "] " + 
                          item.getName() + ": " + quantity + 
                          " units (Total: " + item.getQuantity() + ")");
    }
}