package com.example.inventory;

public class StockEvent {
    private final String eventType;
    private final int quantity;
    private final long timestamp;

    public StockEvent(String eventType, int quantity) {
        this.eventType = eventType;
        this.quantity = quantity;
        this.timestamp = System.currentTimeMillis();
    }

    public String getEventType() {
        return eventType;
    }

    public int getQuantity() {
        return quantity;
    }

    public long getTimestamp() {
        return timestamp;
    }
}