package com.example.inventory;

import java.util.ArrayList;
import java.util.List;

public class StockItem {
    private final String itemId;
    private int quantity;
    private final int reorderThreshold;
    private final List<StockEvent> eventHistory;

    public StockItem(String itemId, int initialQuantity, int reorderThreshold) {
        this.itemId = itemId;
        this.quantity = initialQuantity;
        this.reorderThreshold = reorderThreshold;
        this.eventHistory = new ArrayList<>();
        eventHistory.add(new StockEvent("INITIAL_STOCK", initialQuantity));
    }

    public void addStock(int amount) {
        quantity += amount;
        eventHistory.add(new StockEvent("STOCK_ADDED", amount));
    }

    public boolean removeStock(int amount) {
        if (quantity >= amount) {
            quantity -= amount;
            eventHistory.add(new StockEvent("STOCK_REMOVED", amount));
            return true;
        }
        return false;
    }

    public String getItemId() {
        return itemId;
    }

    public int getQuantity() {
        return quantity;
    }

    public int getReorderThreshold() {
        return reorderThreshold;
    }

    public List<StockEvent> getEventHistory() {
        return new ArrayList<>(eventHistory);
    }
}