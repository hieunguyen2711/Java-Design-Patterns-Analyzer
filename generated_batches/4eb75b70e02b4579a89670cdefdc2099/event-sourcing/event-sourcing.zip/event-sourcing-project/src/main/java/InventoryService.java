package com.example.inventory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class InventoryService {
    private final Map<String, StockItem> inventory;
    
    public InventoryService() {
        this.inventory = new HashMap<>();
    }

    public void addItem(String itemId, int initialQuantity, int reorderThreshold) {
        inventory.put(itemId, new StockItem(itemId, initialQuantity, reorderThreshold));
    }

    public void addStock(String itemId, int amount) {
        StockItem item = inventory.get(itemId);
        if (item != null) {
            item.addStock