public interface StockService {
    void updateStock(String itemId, int quantity);
    int getStock(String itemId);
    boolean needsReorder(String itemId);
    void logMovement(String itemId, String action, int quantity);
}