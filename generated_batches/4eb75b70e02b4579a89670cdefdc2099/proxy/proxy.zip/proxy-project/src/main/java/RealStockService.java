import java.util.HashMap;
import java.util.Map;

public class RealStockService implements StockService {
    private Map<String, StockItem> inventory;
    
    public RealStockService() {
        this.inventory = new HashMap<>();
    }
    
    @Override
    public void updateStock(String itemId, int quantity) {
        if (inventory.containsKey(itemId)) {
            StockItem item = inventory.get(itemId);
            item.setCurrentStock(item.getCurrentStock() + quantity);
        } else {
            throw new IllegalArgumentException("Item not found: " + itemId);
        }
    }
    
    @Override
    public int getStock(String itemId) {
        return inventory.get(itemId).getCurrentStock();
    }
    
    @Override
    public boolean needsReorder(String itemId) {
        StockItem item = inventory.get(itemId);
        return item.getCurrentStock() <= item.getReorderThreshold();
    }
    
    @Override
    public void logMovement(String itemId, String action, int quantity) {
        System.out.println("LOG: " + action + " " + quantity + " units of " + itemId);
    }