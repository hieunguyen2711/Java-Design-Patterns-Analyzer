public class StockItem {
    private String itemId;
    private String name;
    private int currentStock;
    private int reorderThreshold;
    
    public StockItem(String itemId, String name, int currentStock, int reorderThreshold) {
        this.itemId = itemId;
        this.name = name;
        this.currentStock = currentStock;
        this.reorderThreshold = reorderThreshold;
    }
    
    // Getters and setters
    public String getItemId() { return itemId; }
    public String getName() { return name; }
    public int getCurrentStock() { return currentStock; }
    public void setCurrentStock(int currentStock) { this.currentStock = currentStock; }
    public int getReorderThreshold() { return reorderThreshold; }
    
    @Override
    public String toString() {
        return "StockItem{" +
                "itemId='" + itemId + '\'' +
                ", name='" + name + '\'' +
                ", currentStock=" + currentStock +
                ", reorderThreshold=" + reorderThreshold +
                '}';
    }
}