public interface Expression {
    boolean interpret(StockContext context);
}