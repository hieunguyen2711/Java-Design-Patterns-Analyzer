public class LowStockExpression implements Expression {
    @Override
    public boolean interpret(StockContext context) {
        return context.getItem().getCurrentStock() <= context.getItem().getReorderThreshold();
    }
}