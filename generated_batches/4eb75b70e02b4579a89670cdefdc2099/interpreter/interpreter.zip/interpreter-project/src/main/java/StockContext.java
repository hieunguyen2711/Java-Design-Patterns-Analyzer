public class StockContext {
    private StockItem item;
    
    public StockContext(StockItem item) {
        this.item = item;
    }
    
    public StockItem getItem() {
        return item;
    }
    
    public void setItem(StockItem item) {
        this.item = item;
    }
}