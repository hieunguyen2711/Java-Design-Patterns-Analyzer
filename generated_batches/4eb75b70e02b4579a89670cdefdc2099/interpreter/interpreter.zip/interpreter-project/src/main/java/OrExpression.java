public class OrExpression implements Expression {
    private Expression expr1;
    private Expression expr2;