package com.example.stock;

import java.util.concurrent.locks.ReentrantLock;
import java.util.List;
import java.util.ArrayList;

public class InventoryManager {
    private final ReentrantLock lock = new ReentrantLock();
    
    // Double buffering - two lists to avoid concurrent modification issues
    private volatile List<StockItem> activeInventory = new ArrayList<>();
    private List<StockItem> pendingUpdates = new ArrayList<>();
    
    public void addItem(StockItem item) {
        lock.lock();
        try {
            pendingUpdates.add(item);
        } finally {
            lock.unlock();
        }
    }
    
    public void updateInventory() {
        lock.lock();
        try {
            // Double buffer swap - atomically switch to new inventory state
            List<StockItem> temp = activeInventory;
            activeInventory = pendingUpdates;
            pendingUpdates = temp;
            pendingUpdates.clear();
        } finally {
            lock.unlock();
        }
    }
    
    public List<StockItem> getActiveInventory() {
        return new ArrayList<>(activeInventory);
    }
}