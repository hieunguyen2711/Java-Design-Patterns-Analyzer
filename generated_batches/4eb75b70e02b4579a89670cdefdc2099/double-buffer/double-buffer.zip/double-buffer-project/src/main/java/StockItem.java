package com.example.stock;

public class StockItem {
    private String itemId;
    private int currentStock;
    private int reorderThreshold;
    
    public StockItem(String itemId, int currentStock, int reorderThreshold) {
        this.itemId = itemId;
        this.currentStock = currentStock;
        this.reorderThreshold = reorderThreshold;
    }
    
    // Getters and setters
    public String getItemId() { return itemId; }
    public int getCurrentStock() { return currentStock; }
    public void setCurrentStock(int currentStock) { this.currentStock = currentStock; }
    public int getReorderThreshold() { return reorderThreshold; }
    public void setReorderThreshold(int reorderThreshold) { this.reorderThreshold = reorderThreshold; }
}