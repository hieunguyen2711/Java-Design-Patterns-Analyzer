public class StockIntakeContext {
    private StockItem item;

    public StockIntakeContext(StockItem item) {
        this.item = item;
    }

    public void executeIntake(int quantity, String type) {
        if ("urgent".equalsIgnoreCase(type)) {
            item.setIntakeStrategy(new Urgent