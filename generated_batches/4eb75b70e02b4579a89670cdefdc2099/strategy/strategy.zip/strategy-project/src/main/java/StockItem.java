public class StockItem {
    private String name;
    private int quantity;
    private int reorderThreshold;
    private StockIntakeStrategy intakeStrategy;

    public StockItem(String name, int quantity, int reorderThreshold) {
        this.name = name;
        this.quantity = quantity;
        this.reorderThreshold = reorderThreshold;
        this.intakeStrategy = new RegularStockIntake();
    }

    public void setIntakeStrategy(StockIntakeStrategy strategy) {
        this.intakeStrategy = strategy;
    }

    public void processIntake(int quantity) {
        intakeStrategy.processStockIntake(this, quantity);
    }

    // Getters and setters
    public String getName() { return name; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public int getReorderThreshold() { return reorderThreshold; }
}