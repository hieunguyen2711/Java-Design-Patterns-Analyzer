public class UrgentStockIntake implements StockIntakeStrategy {
    @Override
    public void processStockIntake(StockItem item, int quantity) {
        item.setQuantity(item.getQuantity() + quantity);
        System.out.println("Urgent intake of " + quantity + " units for " + item.getName());
        if (item.getQuantity() > item.getReorderThreshold()) {
            System.out.println("Warning: Item " + item.getName() + " is now above reorder threshold");
        }
    }
}