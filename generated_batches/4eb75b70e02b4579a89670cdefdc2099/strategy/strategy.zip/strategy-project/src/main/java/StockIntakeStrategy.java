public interface StockIntakeStrategy {
    void processStockIntake(StockItem item, int quantity);
}