public class RegularStockIntake implements StockIntakeStrategy {
    @Override
    public void processStockIntake(StockItem item, int quantity) {
        item.setQuantity(item.getQuantity() + quantity);
        System.out.println("Regular intake of " + quantity + " units for " + item.getName());
    }
}