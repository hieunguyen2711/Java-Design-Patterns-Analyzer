package com.example.stock;

public class StockItemDTO {
    private String itemId;
    private String itemName;
    private int currentStock;
    private int reorderThreshold;
    private String location;
    
    public StockItemDTO() {}
    
    public StockItemDTO(String itemId, String itemName, int currentStock, 
                       int reorderThreshold, String location) {
        this.itemId = itemId;
        this.itemName = itemName;
        this.currentStock = currentStock;
        this.reorderThreshold = reorderThreshold;
        this.location = location;
    }
    
    // Getters and setters
    public String getItemId() { return itemId; }
    public void setItemId(String itemId) { this.itemId = itemId; }
    
    public String getItemName() { return itemName; }
    public void setItemName(String itemName) { this.itemName = itemName;