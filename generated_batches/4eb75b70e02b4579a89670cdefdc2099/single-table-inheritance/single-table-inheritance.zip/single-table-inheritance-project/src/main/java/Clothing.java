package com.example.stock;

import java.math.BigDecimal;

public class Clothing extends StockItem {
    private String size;
    private String color;
    
    public