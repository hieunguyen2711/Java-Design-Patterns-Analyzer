package com.example.stock;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public abstract class StockItem {
    protected String id;
    protected String name;
    protected BigDecimal price;
    protected int currentStock;
    protected int reorderThreshold;
    
    public StockItem(String id, String name, BigDecimal price, int currentStock, int reorderThreshold) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.currentStock = currentStock;
        this.reorderThreshold = reorderThreshold;
    }
    
    public abstract String getItemType();
    
    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) { this.price = price; }
    public int getCurrentStock() { return currentStock; }
    public void setCurrentStock(int currentStock) { this.currentStock = currentStock; }
    public int getReorderThreshold() { return reorderThreshold; }
    public void setReorderThreshold(int reorderThreshold) { this.reorderThreshold = reorderThreshold; }
}