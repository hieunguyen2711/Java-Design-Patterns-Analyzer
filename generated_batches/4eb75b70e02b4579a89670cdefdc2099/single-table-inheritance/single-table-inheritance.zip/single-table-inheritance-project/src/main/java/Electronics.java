package com.example.stock;

import java.math.BigDecimal;

public class Electronics extends StockItem {
    private String brand;
    private int warrantyMonths;
    
    public Electronics(String id, String name, BigDecimal price, int currentStock, 
                     int reorderThreshold, String brand, int warrantyMonths) {
        super(id, name, price, currentStock, reorderThreshold);
        this.brand = brand;
        this.warrantyMonths = warrantyMonths;
    }
    
    @Override
    public String getItemType() {
        return "ELECTRONICS";
    }
    
    // Getters and setters for electronics-specific fields
    public String getBrand() { return brand; }
    public void setBrand(String brand) { this.brand = brand; }
    public int getWarrantyMonths() { return warrantyMonths; }
    public void setWarrantyMonths(int warrantyMonths) { this.warrantyMonths = warrantyMonths; }
}