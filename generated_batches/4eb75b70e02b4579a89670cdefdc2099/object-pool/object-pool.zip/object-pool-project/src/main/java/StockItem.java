public class StockItem {
    private String itemId;
    private int quantity;
    private int reorderThreshold;
    
    public StockItem(String itemId, int quantity, int reorderThreshold) {
        this.itemId = itemId;
        this.quantity = quantity;
        this.reorderThreshold = reorderThreshold;
    }
    
    // Getters and setters
    public String getItemId() { return itemId; }
    public void setItemId(String itemId) { this.itemId = itemId; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public int getReorderThreshold() { return reorderThreshold; }
    public void setReorderThreshold(int reorderThreshold) { this.reorderThreshold = reorderThreshold; }
}