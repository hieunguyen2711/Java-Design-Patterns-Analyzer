public class InventoryManager {
    private StockItemPool itemPool;
    
    public InventoryManager() {
        this.itemPool = StockItemPool.getInstance(