package com.example.stock;

public class StockMovement {
    private String movementId;
    private String itemId;
    private int quantity;
    private String fromLocation;
    private String toLocation;
    
    public StockMovement(String movementId, String itemId, int quantity, String fromLocation, String toLocation) {
        this.movementId = movementId;
        this.itemId = itemId;
        this.quantity = quantity;
        this.fromLocation = fromLocation;
        this.toLocation = toLocation;
    }
    
    // Getters and setters
    public String getMovementId() { return movementId; }
    public void setMovementId(String movementId) { this.movementId = movementId; }
    
    public String getItemId() { return itemId