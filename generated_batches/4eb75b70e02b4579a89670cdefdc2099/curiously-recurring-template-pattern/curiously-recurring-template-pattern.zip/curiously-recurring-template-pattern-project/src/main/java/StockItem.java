package com.example.stock;

public abstract class StockItem<T extends StockItem<T>> {
    protected String itemId;
    protected String itemName;
    protected int currentStock;
    protected int reorderThreshold;
    
    public StockItem(String itemId, String itemName, int currentStock, int reorderThreshold) {
        this.itemId = itemId;
        this.itemName = itemName;
        this.currentStock = currentStock;
        this.reorderThreshold = reorderThreshold;
    }
    
    public abstract T withStock(int stock);
    public abstract T withReorderThreshold(int threshold);
    
    public String getItemId() {
        return itemId;
    }
    
    public String getItemName() {
        return itemName;
    }
    
    public int getCurrentStock() {
        return currentStock;
    }
    
    public int getReorderThreshold() {
        return reorderThreshold;
    }
}