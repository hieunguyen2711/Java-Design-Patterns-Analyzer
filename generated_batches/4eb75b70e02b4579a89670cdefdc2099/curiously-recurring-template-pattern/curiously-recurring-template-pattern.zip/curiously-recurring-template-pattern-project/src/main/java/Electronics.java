package com.example.stock;

public class Electronics extends StockItem<Electronics> {
    private String brand;
    private String model;
    
    public Electronics(String itemId, String itemName, int currentStock, int reorderThreshold, 
                      String brand, String model) {
        super(itemId, itemName, currentStock, reorderThreshold);
        this.brand = brand;
        this.model = model;
    }
    
    @Override
    public Electronics withStock(int stock) {
        return new Electronics(this.itemId, this.itemName, stock, this.reorderThreshold, 
                              this.brand, this.model);
    }
    
    @Override
    public Electronics withReorderThreshold(int threshold) {
        return new Electronics(this.itemId, this.itemName, this.currentStock, threshold, 
                              this.brand, this.model);
    }
    
    public String getBrand() {
        return brand;
    }
    
    public String getModel() {
        return model;
    }
}