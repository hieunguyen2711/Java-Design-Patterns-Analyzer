package com.example.stock;

public class Clothing extends StockItem<Clothing> {
    private String size;
    private String color;
    
    public Clothing(String itemId, String itemName, int currentStock, int reorderThreshold, 
                   String size, String color) {
        super(itemId, itemName, currentStock, reorderThreshold);
        this.size = size;
        this.color = color;
    }
    
    @Override
    public Clothing withStock(int stock) {
        return new Clothing(this.itemId, this.itemName, stock, this.reorderThreshold, 
                           this