public class InventorySystem {
    public static void main(String[] args) {
        // Using the monostate pattern - all references point to same instance
        StockManager manager1 = StockManager.getInstance();
        StockManager manager2 = StockManager.getInstance();
        
        System.out.println("Testing Monostate Pattern:");
        System.out.println("manager1 == manager2: " + (manager1 == manager2));
        
        // Modify through first reference
        manager1.addStock(50);
        manager1.setLocation("Warehouse B");
        
        // Check that second reference sees the changes
        System.out.println("Manager 2 current stock: " + manager2.getCurrentStock());
        System.out.println("Manager 2 location: " + manager2.getLocation());
        
        // Test reorder threshold
        manager1.setReorderThreshold(