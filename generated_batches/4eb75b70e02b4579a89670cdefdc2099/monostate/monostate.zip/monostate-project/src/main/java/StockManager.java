public class StockManager {
    private static StockManager instance;
    private int currentStock;
    private int reorderThreshold;
    private String lastLocation;
    
    // Private constructor to prevent instantiation
    private StockManager() {
        this.currentStock = 0;
        this.reorderThreshold = 10;
        this.lastLocation = "Warehouse A";
    }
    
    // Get the single instance (monostate pattern)
    public static synchronized StockManager getInstance() {
        if (instance == null) {
            instance = new StockManager();
        }
        return instance;
    }
    
    // Methods to manage stock
    public void addStock(int quantity) {
        currentStock += quantity;
        logMovement("Added", quantity);
    }
    
    public boolean removeStock(int quantity) {
        if (currentStock >= quantity) {
            currentStock -= quantity;
            logMovement("Removed", quantity);
            return true;
        }
        return false;
    }
    
    public int getCurrentStock() {
        return currentStock;
    }
    
    public void setReorderThreshold(int threshold) {
        this.reorderThreshold = threshold;
    }
    
    public int getReorderThreshold() {
        return reorderThreshold;
    }
    
    public void setLocation(String location) {
        this.lastLocation = location;
    }
    
    public String getLocation() {
        return lastLocation;
    }
    
    private void logMovement(String action, int quantity) {
        System.out.println(action + " " + quantity + " items. Current stock: " + currentStock);
    }
}