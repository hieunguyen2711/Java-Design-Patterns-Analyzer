import java.util.ArrayList;
import java.util.List;

public class InventoryManager {
    private List<StockItem> items = new ArrayList<>();
    
    public void addItem(String itemId, String name, int quantity, int reorderThreshold) {
        StockItem item = ItemFactory.getItem(itemId, name, reorderThreshold);
        item.setQuantity(item.getQuantity() + quantity);
        if (!items.contains(item)) {
            items.add(item);
        }
    }
    
    public void removeItem(String itemId, int quantity) {
        StockItem item = ItemFactory.getItem(itemId, "", 0);
        if (items.contains(item)) {
            item.setQuantity(Math.max(0, item.getQuantity() - quantity));
        }
    }
    
    public List<StockItem> getItems() {
        return new ArrayList<>(items);
    }
    
    public StockItem getItem(String itemId) {
        return items.stream()
                .filter(item ->