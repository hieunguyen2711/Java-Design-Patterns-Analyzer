public class StockItem {
    private String itemId;
    private String name;
    private int quantity;
    private int reorderThreshold;
    
    public StockItem(String itemId, String name, int quantity, int reorderThreshold) {
        this.itemId = itemId;
        this.name = name;
        this.quantity = quantity;
        this.reorderThreshold = reorderThreshold;
    }
    
    // Getters and setters
    public String getItemId() { return itemId; }
    public String getName() { return name; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public int getReorderThreshold() { return reorderThreshold; }
    
    @Override
    public String toString() {
        return "StockItem{" +
                "itemId='" + itemId + '\'' +
                ", name='" + name + '\'' +
                ", quantity=" + quantity +
                ", reorderThreshold=" + reorderThreshold +
                '}';
    }
}