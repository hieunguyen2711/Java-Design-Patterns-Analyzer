import java.util.HashMap;
import java.util.Map;

public class ItemFactory {
    private static final Map<String, StockItem> itemCache = new HashMap<>();
    
    public static StockItem getItem(String itemId, String name, int reorderThreshold) {
        return itemCache.computeIfAbsent(itemId, k -> new StockItem(itemId, name, 0, reorderThreshold));
    }
    
    public static void clearCache() {
        itemCache.clear();
    }
}