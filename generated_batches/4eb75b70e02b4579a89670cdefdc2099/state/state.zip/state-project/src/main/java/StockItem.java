public class StockItem {
    private String itemId;
    private int currentStock;
    private int reorderThreshold;
    private StockState state;
    
    public StockItem(String itemId, int initialStock, int reorderThreshold) {
        this.itemId = itemId;
        this.currentStock = initialStock;
        this.reorderThreshold = reorderThreshold;
        this.state = new InStockState(this);
    }
    
    public void updateStock(int quantity) {
        currentStock += quantity;
        state.handleStockUpdate();
    }
    
    public String getItemId() {
        return itemId;
    }
    
    public int getCurrentStock() {
        return currentStock;
    }
    
    public int getReorderThreshold() {
        return reorderThreshold;
    }
    
    public void setState(StockState state) {
        this.state = state;
    }
}