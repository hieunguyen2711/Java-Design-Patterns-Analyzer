public abstract class StockState {
    protected StockItem stockItem;
    
    public StockState(StockItem stockItem) {
        this.stockItem = stockItem;
    }
    
    public abstract void handleStockUpdate();
    public abstract String getStateName();
}