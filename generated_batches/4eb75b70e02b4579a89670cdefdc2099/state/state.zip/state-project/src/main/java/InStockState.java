public class InStockState extends StockState {
    
    public InStockState(StockItem stockItem) {
        super(stockItem);
    }
    
    @Override
    public void handleStockUpdate() {
        if (stockItem.getCurrentStock() <= 0) {
            stockItem.setState(new OutOfStockState(stockItem));
        } else if (stockItem.getCurrentStock() <= stockItem.getReorderThreshold()) {
            stockItem.setState(new LowStockState(stockItem));
        }
    }
    
    @Override
    public String getStateName() {
        return "In Stock";
    }
}