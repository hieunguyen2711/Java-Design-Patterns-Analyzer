public class LowStockState extends StockState {
    
    public LowStockState(StockItem stockItem) {
        super(stockItem);
    }
    
    @Override
    public void handleStockUpdate() {
        if (stockItem.getCurrentStock() <= 0) {
            stockItem.setState(new OutOfStockState(stockItem));
        } else if (stockItem.getCurrentStock() > stockItem.getReorderThreshold()) {
            stockItem.setState(new InStockState(stockItem));
        }
    }
    
    @Override
    public String getStateName() {
        return "Low Stock";