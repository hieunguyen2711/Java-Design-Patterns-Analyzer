public class StockItem {
    private String name;
    private int currentStock;
    private int reorderThreshold;
    
    public StockItem(String name, int currentStock, int reorderThreshold) {
        this.name = name;
        this.currentStock = currentStock;
        this.reorderThreshold = reorderThreshold;
    }
    
    public void updateStock(int quantity) {
        this.currentStock += quantity;
        System.out.println("Updated " + name + " stock to: " + currentStock);
    }
    
    public int getCurrentStock() {
        return currentStock;
    }
    
    public String getName() {
        return name;
    }
    
    public int getReorderThreshold() {
        return reorderThreshold;
    }
}