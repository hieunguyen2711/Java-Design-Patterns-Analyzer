public interface StockService {
    void updateStock(String itemName, int quantity);
    int getCurrentStock(String itemName);
    boolean needsRestock(String itemName);
}