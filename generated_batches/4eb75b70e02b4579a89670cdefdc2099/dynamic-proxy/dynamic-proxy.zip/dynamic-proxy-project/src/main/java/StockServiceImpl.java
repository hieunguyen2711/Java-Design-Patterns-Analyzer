import java.util.HashMap;
import java.util.Map;

public class StockServiceImpl implements StockService {
    private Map<String, StockItem> inventory = new HashMap<>();
    
    public StockServiceImpl() {
        inventory.put("Laptop", new StockItem("Laptop", 15, 5));
        inventory.put("Mouse", new StockItem("Mouse", 30, 10));
        inventory.put("Keyboard", new StockItem("Keyboard", 20, 8));
    }
    
    @Override
    public void updateStock(String itemName, int quantity) {
        if (inventory.containsKey(itemName)) {
            inventory.get(itemName).updateStock(quantity);
        } else {
            System.out.println("Item " + itemName + " not found in inventory");
        }
    }
    
    @Override
    public int getCurrentStock(String itemName) {
        return inventory.containsKey(itemName) ? 
               inventory.get(itemName).getCurrentStock() : 0;
    }
    
    @Override
    public boolean needsRestock(String itemName) {
        if (inventory.containsKey(itemName)) {
            StockItem item = inventory.get(itemName);
            return item.getCurrentStock() <= item.getReorderThreshold();
        }
        return false;
    }
}