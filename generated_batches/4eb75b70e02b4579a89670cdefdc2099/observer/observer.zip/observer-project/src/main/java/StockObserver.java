public interface StockObserver {
    void update(StockItem item);
}