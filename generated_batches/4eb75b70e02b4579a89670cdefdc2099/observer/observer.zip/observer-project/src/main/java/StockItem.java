import java.util.ArrayList;
import java.util.List;

public class StockItem {
    private String name;
    private int currentStock;
    private int reorderThreshold;
    private List<StockObserver> observers;

    public StockItem(String name, int initialStock, int reorderThreshold) {
        this.name = name;
        this.currentStock = initialStock;
        this.reorderThreshold = reorderThreshold;
        this.observers = new ArrayList<>();
    }

    public void addObserver(StockObserver observer) {
        observers.add(observer);
    }

    public void removeObserver(StockObserver observer) {
        observers.remove(observer);
    }

    public void setStock(int stock) {
        this.currentStock = stock;
        notifyObservers();
    }

    private void notifyObservers() {
        for (StockObserver observer : observers) {
            observer.update(this);
        }
    }

    public String getName() {
        return name;
    }

    public int getCurrentStock() {
        return currentStock;
    }

    public int getReorderThreshold() {
        return reorderThreshold;
    }

    public boolean needsRestock() {
        return currentStock <= reorderThreshold;
    }
}