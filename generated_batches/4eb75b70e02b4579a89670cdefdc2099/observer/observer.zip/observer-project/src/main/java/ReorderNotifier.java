public class ReorderNotifier implements StockObserver {

    @Override
    public void update(StockItem item) {
        if (item.needsRestock()) {
            System.out.println("ALERT: " + item.getName() + 
                " is below reorder threshold. Current stock: " + 
                item.getCurrentStock());
        }
    }
}