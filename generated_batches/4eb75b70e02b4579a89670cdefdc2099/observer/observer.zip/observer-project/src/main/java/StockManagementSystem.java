public class StockManagementSystem {
    public static void main(String[] args) {
        // Create a stock item
        StockItem laptop = new StockItem("Laptop