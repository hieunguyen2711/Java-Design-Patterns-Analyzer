import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class InventoryLogger implements StockObserver {
    private static final DateTimeFormatter formatter = 
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    @Override
    public void update(StockItem item) {
        String timestamp = LocalDateTime.now().format(formatter);
        System.out.println(String.format("[%s] %s stock updated to: %d", 
            timestamp, item.getName(), item.getCurrentStock()));
    }
}