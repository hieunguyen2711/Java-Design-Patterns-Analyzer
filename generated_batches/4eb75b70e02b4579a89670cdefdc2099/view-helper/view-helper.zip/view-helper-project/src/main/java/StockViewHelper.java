package com.example.stock;

import java.util.List;
import java.util.stream.Collectors;

public class StockViewHelper {
    private List<StockItem> stockItems;
    
    public StockViewHelper(List<StockItem> stockItems) {
        this.stockItems = stockItems;
    }
    
    public String generateInventoryReport() {
        StringBuilder report = new StringBuilder();
        report.append("=== INVENTORY REPORT ===\n");
        
        for (StockItem item : stockItems) {
            report.append(String.format("ID: %s | Name: %s | Stock: %d | Location: %s\n", 
                item.getItemId(), item.getName(), item.getCurrentStock(), item.getLocation()));
        }
        
        return report.toString();
    }
    
    public List<StockItem> getLowStockItems() {
        return stockItems.stream()
            .filter(item -> item.getCurrentStock() <= item.getReorderThreshold())
            .collect(Collectors.toList());
    }
    
    public String generateReorderReport() {
        List<StockItem> lowStock = getLowStockItems();
        
        if (lowStock.isEmpty()) {
            return "No items require reordering.";
        }