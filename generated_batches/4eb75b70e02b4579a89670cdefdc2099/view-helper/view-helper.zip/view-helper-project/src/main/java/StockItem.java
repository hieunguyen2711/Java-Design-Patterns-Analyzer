package com.example.stock;

public class StockItem {
    private String itemId;
    private String name;
    private int currentStock;
    private int reorderThreshold;
    private String location;
    
    public StockItem(String itemId, String name, int currentStock, int reorderThreshold, String location) {
        this.itemId = itemId;
        this.name = name;
        this.currentStock = currentStock;
        this.reorderThreshold = reorderThreshold;
        this.location = location;
    }
    
    // Getters and setters
    public String getItemId() { return itemId; }
    public void setItemId(String itemId) { this.itemId = itemId; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public int getCurrentStock() { return currentStock; }
    public void setCurrentStock(int currentStock) { this.currentStock = currentStock; }
    
    public int getReorderThreshold() { return reorderThreshold; }
    public void setReorderThreshold(int reorderThreshold) { this.reorderThreshold = reorderThreshold; }
    
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
}