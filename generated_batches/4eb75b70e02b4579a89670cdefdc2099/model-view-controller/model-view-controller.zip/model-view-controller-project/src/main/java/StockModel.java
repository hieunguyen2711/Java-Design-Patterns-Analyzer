package com.example.stock;

import java.util.ArrayList;
import java.util.List;

public class StockModel {
    private List<StockItem> stockItems;
    
    public StockModel() {
        this.stockItems = new ArrayList<>();
    }
    
    public void addItem(StockItem item) {
        stockItems.add(item);
    }
    
    public void removeItem(String itemId) {
        stockItems.removeIf(item -> item.getItemId().equals(itemId));
    }
    
    public List<StockItem> getAllItems() {
        return new ArrayList<>(stockItems);
    }
    
    public StockItem getItemById(String itemId) {
        return stockItems.stream()
                .filter(item -> item.getItemId().equals(itemId))
                .findFirst()
                .orElse(null);
    }
    
    public void updateStock(String itemId, int quantity) {
        StockItem item = getItemById(itemId);
        if (item != null) {
            item.setCurrentStock(quantity);
        }
    }
    
    public List<StockItem> getItemsBelowThreshold() {
        return stockItems.stream()
                .filter(item -> item.getCurrentStock() <= item.getReorderThreshold())
                .collect(ArrayList::new, ArrayList::add, ArrayList