package com.example.stock;

import java.util.List;
import java.util.ArrayList;
import java.util.stream.Collectors;

public class InMemoryStockRepository implements StockRepository {
    private List<StockItem> items = new ArrayList<>();
    private int nextId = 1;
    
    @Override
    public StockItem findById(int id) {
        return items.stream()
                   .filter(item -> item.getId() == id)
                   .findFirst()
                   .orElse(null);
    }
    
    @Override
    public List<StockItem> findAll() {
        return new ArrayList<>(items);
    }
    
    @Override
    public void save(StockItem item) {
        if (item.getId() == 0) {
            item.setId(nextId++);
        } else {
            // Update existing item
            items.removeIf(i -> i.getId() == item.getId());
        }
        items.add(item);
    }
    
    @Override
    public void delete(int id) {
        items.removeIf(item -> item.getId() == id);
    }
}