package com.example.stock;

import java.util.List;
import java.util.ArrayList;

public interface StockRepository {
    StockItem findById(int id);
    List<StockItem> findAll();
    void save(StockItem item);
    void delete(int id);
}