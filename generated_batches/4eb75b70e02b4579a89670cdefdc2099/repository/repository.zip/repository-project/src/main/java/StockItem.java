package com.example.stock;

public class StockItem {
    private int id;
    private String name;
    private int currentStock;
    private int reorderThreshold;
    
    public StockItem(int id, String name, int currentStock, int reorderThreshold) {
        this.id = id;
        this.name = name;
        this.currentStock = currentStock;
        this.reorderThreshold = reorderThreshold;
    }
    
    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public int getCurrentStock() { return currentStock; }
    public void setCurrentStock(int currentStock) { this.currentStock = currentStock; }
    
    public int getReorderThreshold() { return reorderThreshold; }
    public void setReorderThreshold(int reorderThreshold) { this.reorderThreshold = reorderThreshold; }
}