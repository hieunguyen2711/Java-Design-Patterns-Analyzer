public class InventoryService {
    private final StockManager stockManager;
    
    public InventoryService() {
        this.stockManager = StockManager.getInstance();
    }
    
    public void addStock(String item, int quantity) {
        stockManager.processStockUpdate(item, quantity);
    }
}