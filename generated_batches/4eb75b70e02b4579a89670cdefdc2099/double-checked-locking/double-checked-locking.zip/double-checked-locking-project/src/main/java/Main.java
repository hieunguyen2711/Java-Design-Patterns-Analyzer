public class Main {
    public static void main(String[] args) {
        InventoryService service1 = new InventoryService();
        InventoryService service2 = new InventoryService();
        
        service1.addStock("Laptop", 10);
        service2.addStock("Mouse", 50);
        
        System.out.println("Singleton instance check: " + 
            (service1.getClass().getDeclaredField("stockManager").get(null) == 
             service2.getClass().getDeclaredField("stockManager").get(null)));
    }
}