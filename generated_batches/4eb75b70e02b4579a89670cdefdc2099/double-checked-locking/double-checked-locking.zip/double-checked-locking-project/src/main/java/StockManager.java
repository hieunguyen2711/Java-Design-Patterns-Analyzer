public class StockManager {
    private static volatile StockManager instance;
    
    private StockManager() {
        // Private constructor to prevent instantiation
    }
    
    public static StockManager getInstance() {
        if (instance == null) {
            synchronized (StockManager.class) {
                if (instance == null) {
                    instance = new StockManager();
                }
            }
        }
        return instance;
    }
    
    public void processStockUpdate(String item, int quantity) {
        System.out.println("Processing stock update for " + item + ": " + quantity);
    }
}