public class Location {
    private String locationId;
    private String aisle;
    private String shelf;
    
    public Location(String locationId, String aisle, String shelf) {
        this.locationId = locationId;
        this.aisle = aisle;
        this.shelf = shelf;
    }
    
    // Getters and setters
    public String getLocationId() { return locationId; }
    public void setLocationId(String locationId) { this.locationId = locationId; }
    
    public String getAisle() { return aisle; }