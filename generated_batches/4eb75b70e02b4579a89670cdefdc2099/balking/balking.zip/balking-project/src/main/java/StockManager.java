package com.example.stock;

public class StockManager {
    private int currentStock;
    private final int reorderThreshold;
    private boolean isProcessing = false;
    
    public StockManager(int initialStock, int reorderThreshold) {
        this.currentStock = initialStock;
        this.reorderThreshold = reorderThreshold;
    }
    
    public void updateStock(int quantity) {
        // Balking pattern: if already processing, don't accept new updates
        if (isProcessing) {
            return; // Ignore the update request
        }
        
        isProcessing = true;
        try {
            currentStock += quantity;
            
            // Check if reorder is needed
            if (currentStock < reorderThreshold) {
                System.out.println("Reorder triggered: " + currentStock + " items remaining");
                SupplierService.restock(this);
            } else {
                System.out.println("Stock updated to: " + currentStock);
            }
        } finally {
            isProcessing = false;
        }
    }
    
    public int getCurrentStock() {
        return currentStock;
    }
}