package com.example.stock;

public class SupplierService {
    public static void restock(StockManager manager) {
        // Simulate supplier restocking process
        System.out.println("Supplier is restocking...");
        
        try {
            Thread.sleep(100); // Simulate processing time
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        manager.updateStock(50); // Add 50 items from supplier
    }
}