package com.example.stock;

public class StockIntakeSystem {
    public static void main(String[] args) {
        StockManager stockManager = new StockManager(20, 10);
        
        // Simulate multiple concurrent updates that might trigger balking
        Thread thread1 = new Thread(() -> {
            stockManager.updateStock(5); // This should work
        });
        
        Thread thread2 = new Thread(() -> {
            stockManager.updateStock(-3); // This might be ignored if processing
        });
        
        thread1.start();
        thread2.start();
        
        try {
            thread1.join();
            thread2.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        System.out.println("Final stock: " + stockManager