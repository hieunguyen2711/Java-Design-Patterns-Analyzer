public interface ItemLocationService {
    String getLocation(String itemId);
    void updateLocation(String itemId, String location);
}