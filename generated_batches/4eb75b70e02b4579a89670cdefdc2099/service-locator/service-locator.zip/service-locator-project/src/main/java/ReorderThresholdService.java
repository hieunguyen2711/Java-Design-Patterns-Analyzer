public interface ReorderThresholdService {
    int getReorderThreshold(String itemId);
    void setReorderThreshold(String itemId, int threshold);
}