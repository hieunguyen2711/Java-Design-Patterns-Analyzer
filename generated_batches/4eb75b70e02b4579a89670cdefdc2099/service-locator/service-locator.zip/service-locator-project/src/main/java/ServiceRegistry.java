import java.util.HashMap;
import java.util.Map;

public class ServiceRegistry {
    private Map<String, Object> services;

    public ServiceRegistry() {
        services = new HashMap<>();
        initializeServices();
    }

    private void initializeServices() {
        services.put("StockIntakeService", new StockIntakeServiceImpl());
        services.put("ItemLocationService", new ItemLocationServiceImpl());
        services.put("ReorderThresholdService", new ReorderThresholdServiceImpl());
        services.put("SupplierRestockingService", new SupplierRestockingServiceImpl());
        services.put("MovementLogService", new MovementLogServiceImpl());
    }

    public Object getService(String serviceName) {
        return services.get(serviceName);
    }
}