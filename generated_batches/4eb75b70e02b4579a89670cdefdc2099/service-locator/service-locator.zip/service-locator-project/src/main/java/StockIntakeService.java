public interface StockIntakeService {
    void recordStockIntake(String itemId, int quantity);
}