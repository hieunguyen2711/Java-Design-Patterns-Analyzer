public interface SupplierRestockingService {
    void triggerRestock(String supplierId, String itemId, int quantity);
}