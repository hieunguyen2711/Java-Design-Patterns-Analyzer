public class StockIntakeServiceImpl implements StockIntakeService {
    @Override
    public void recordStockIntake(String itemId, int quantity) {
        System.out.println("Recording stock intake for item " + itemId + ": " + quantity);
    }
}