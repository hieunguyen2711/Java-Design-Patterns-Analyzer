public interface MovementLogService {
    void logMovement(String itemId, String fromLocation, String toLocation);
}