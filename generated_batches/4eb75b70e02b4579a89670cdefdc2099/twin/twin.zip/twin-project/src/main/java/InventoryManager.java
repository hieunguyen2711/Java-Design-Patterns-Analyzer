package com.example.stock;

import java.util.ArrayList;
import java.util.List;

public class InventoryManager {
    private List<StockItem> items;
    
    public InventoryManager() {
        this.items = new ArrayList<>();
    }
    
    public void addItem(StockItem item) {
        items.add(item);
    }
    
    // Twin pattern - returns a twin list with added item
    public InventoryManager addItemTwin(StockItem item) {
        List<StockItem> newItems = new ArrayList<>(this.items);
        newItems.add(item);
        InventoryManager newManager = new InventoryManager();
        newManager.items = newItems;
        return newManager;
    }
    
    // Twin pattern - returns a twin list with removed item
    public InventoryManager removeItemTwin(String itemId) {
        List<StockItem> newItems = new ArrayList<>(this.items);
        newItems.removeIf(item -> item.getItemId().equals(itemId));
        InventoryManager newManager = new InventoryManager();
        newManager.items = newItems;
        return newManager;
    }
    
    public StockItem findItem(String itemId) {
        return items.stream()
                .filter(item -> item.getItemId().equals(itemId))
                .findFirst()
                .orElse(null);
    }
    
    public List<StockItem> getItems() {
        return new ArrayList<>(items);
    }
}