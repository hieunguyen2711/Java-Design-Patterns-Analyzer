package com.example.stock;

public class Supplier {
    private String supplierId