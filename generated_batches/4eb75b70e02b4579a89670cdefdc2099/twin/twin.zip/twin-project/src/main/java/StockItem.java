package com.example.stock;

public class StockItem {
    private String itemId;
    private String name;
    private int currentStock;
    private int reorderThreshold;
    
    public StockItem(String itemId, String name, int currentStock, int reorderThreshold) {
        this.itemId = itemId;
        this.name = name;
        this.currentStock = currentStock;
        this.reorderThreshold = reorderThreshold;
    }
    
    // Twin pattern - returns a twin instance with updated stock
    public StockItem updateStock(int newStock) {
        return new StockItem(this.itemId, this.name, newStock, this.reorderThreshold);
    }
    
    public String getItemId() {
        return itemId;
    }
    
    public String getName() {
        return name;
    }
    
    public int getCurrentStock() {
        return currentStock;
    }
    
    public int getReorderThreshold() {
        return reorderThreshold;
    }
}