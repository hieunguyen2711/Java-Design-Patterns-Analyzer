public interface Location {
    String getCode();
    void setCode(String code);
    String getDescription();
    void setDescription(String description);
}