public interface Item {
    String getName();
    void setName(String name);
    int getQuantity();
    void setQuantity(int quantity);
}