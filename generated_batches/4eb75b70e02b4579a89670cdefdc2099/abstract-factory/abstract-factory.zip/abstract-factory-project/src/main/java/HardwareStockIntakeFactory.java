public class HardwareStockIntakeFactory implements StockIntakeFactory {
    @Override
    public Item createItem() {
        return new HardwareItem();
    }
    
    @Override
    public Location createLocation() {
        return new HardwareLocation();
    }
    
    @Override
    public ReorderThreshold createReorderThreshold() {
        return new HardwareReorderThreshold();
    }
    
    @Override
    public Supplier createSupplier() {
        return new HardwareSupplier();
    }
}