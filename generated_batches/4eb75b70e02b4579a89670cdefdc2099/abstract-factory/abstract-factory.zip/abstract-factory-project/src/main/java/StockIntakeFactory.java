public interface StockIntakeFactory {
    Item createItem();
    Location createLocation();
    ReorderThreshold createReorderThreshold();
    Supplier createSupplier();
}