public class SoftwareStockIntakeFactory implements StockIntakeFactory {
    @Override
    public Item createItem() {
        return new SoftwareItem();
    }
    
    @Override
    public Location createLocation() {
        return new SoftwareLocation();
    }
    
    @Override
    public ReorderThreshold createReorderThreshold() {
        return new SoftwareReorderThreshold();
    }
    
    @Override
    public Supplier createSupplier() {
        return new SoftwareSupplier();
    }
}