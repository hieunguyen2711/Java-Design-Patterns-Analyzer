public class HardwareItem implements Item {
    private String name;
    private int quantity;
    
    @Override
    public String getName() {
        return name;
    }
    
    @Override
    public void setName(String name) {
        this.name = name;
    }
    
    @Override
    public int getQuantity