public interface ReorderThreshold {
    int getLevel();
    void setLevel(int level);
    boolean shouldReorder(int currentStock);
}