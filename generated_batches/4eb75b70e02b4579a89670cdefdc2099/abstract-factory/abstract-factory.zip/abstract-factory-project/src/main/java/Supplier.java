public interface Supplier {
    String getName();
    void setName(String name);
    String getEmail();
    void setEmail(String email);
    void restock(Item item, int quantity);
}