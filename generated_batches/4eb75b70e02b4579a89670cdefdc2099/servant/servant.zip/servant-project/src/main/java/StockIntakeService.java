package com.example.stock;

public class StockIntakeService {
    private final InventoryManager inventoryManager;
    private final ReorderService reorderService;
    
    public StockIntakeService(InventoryManager inventoryManager, ReorderService reorderService) {
        this.inventoryManager = inventoryManager;
        this.reorderService = reorderService;
    }
    
    public void processStockIntake(Item item, int quantity, String supplierName) {
        inventoryManager.updateItemQuantity(item, quantity);
        inventoryManager.logMovement(new MovementLog(item, quantity, "INTAKE", supplierName));
        
        if (inventoryManager.shouldReorder(item)) {
            reorderService.placeOrder(item, inventoryManager.getReorderThreshold(item));
        }
    }
}