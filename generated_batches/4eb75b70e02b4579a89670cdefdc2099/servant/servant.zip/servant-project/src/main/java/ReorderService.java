package com.example.stock;

public class ReorderService {
    private final SupplierManager supplierManager;
    private final MovementLogger movementLogger;
    
    public ReorderService(SupplierManager supplierManager, MovementLogger movementLogger) {
        this.supplierManager = supplierManager;
        this.movementLogger = movementLogger;
    }
    
    public void placeOrder(Item item, int reorderQuantity) {
        Supplier supplier = supplierManager.findBestSupplier(item);
        Order order = new Order(item, reorderQuantity, supplier);
        
        supplierManager.processOrder(order);
        movementLogger.log(new MovementLog(item, reorderQuantity, "ORDER