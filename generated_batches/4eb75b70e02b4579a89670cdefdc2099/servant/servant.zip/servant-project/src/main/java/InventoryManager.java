package com.example.stock;

import java.util.HashMap;
import java.util.Map;

public class InventoryManager {
    private final Map<Item, Integer> itemQuantities = new HashMap<>();
    private final Map<Item, Integer> reorderThresholds = new HashMap<>();
    private final MovementLogger movementLogger;
    
    public InventoryManager(MovementLogger movementLogger) {
        this.movementLogger = movementLogger;
    }
    
    public void updateItemQuantity(Item item, int quantity) {
        itemQuantities.put(item, itemQuantities.getOrDefault(item, 0) + quantity);
    }
    
    public boolean shouldReorder(Item item) {
        return itemQuantities.getOrDefault(item, 0) <= reorderThresholds.getOrDefault(item, 0);
    }
    
    public int getReorderThreshold(Item item) {
        return reorderThresholds.getOrDefault(item, 0);
    }
    
    public void logMovement(MovementLog movement) {
        movementLogger.log(movement);
    }
}