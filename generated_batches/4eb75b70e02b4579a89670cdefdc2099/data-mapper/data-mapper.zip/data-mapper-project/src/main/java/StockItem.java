package com.example.stock;

public class StockItem {
    private int id;
    private String name;
    private int quantity;
    private int reorderThreshold;
    private String location;
    private int supplierId;

    public StockItem() {}

    public StockItem(int id, String name, int quantity, int reorderThreshold, String location, int supplierId) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.reorderThreshold = reorderThreshold;
        this.location = location;
        this.supplierId = supplierId;
    }

    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public int getReorderThreshold() { return reorderThreshold; }
    public void setReorderThreshold(int reorderThreshold) { this.reorderThreshold = reorderThreshold; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public int getSupplierId() { return supplierId; }
    public void setSupplierId(int supplierId) { this.supplierId = supplierId; }
}