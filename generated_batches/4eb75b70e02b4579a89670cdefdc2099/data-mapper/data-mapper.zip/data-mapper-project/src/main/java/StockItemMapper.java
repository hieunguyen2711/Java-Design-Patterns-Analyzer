package com.example.stock;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StockItemMapper {
    private final Connection connection;

    public StockItemMapper(Connection connection) {
        this.connection = connection;
    }

    public StockItem findById(int id) throws SQLException {
        String sql = "SELECT * FROM stock_items WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapRowToStockItem(rs);
            }
        }
        return null;
    }

    public List<StockItem> findAll() throws SQLException {
        List<StockItem> items = new ArrayList<>();
        String sql = "SELECT * FROM stock_items";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                items.add(mapRowToStockItem(rs));
            }