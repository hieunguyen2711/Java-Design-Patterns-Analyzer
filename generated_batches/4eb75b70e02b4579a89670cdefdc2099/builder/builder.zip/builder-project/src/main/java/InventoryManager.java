package com.example.stock;

import java.util.ArrayList;
import java.util.List;

public class InventoryManager {
    private final List<StockItem> items = new ArrayList<>();
    
    public void addItem(StockItem item) {
        items.add(item);
    }
    
    public StockItem createNewItem(String itemId, String name, int currentStock, 
                                 int reorderThreshold, String location, String supplier) {
        return new StockItem.Builder()
                .setItemId(itemId)
                .setName(name)
                .setCurrentStock(currentStock)
                .setReorder