package com.example.stock;

import java.util.HashMap;
import java.util.Map;

public interface StockRepository {
    StockItem findByName(String name);
    void save(StockItem item);
}