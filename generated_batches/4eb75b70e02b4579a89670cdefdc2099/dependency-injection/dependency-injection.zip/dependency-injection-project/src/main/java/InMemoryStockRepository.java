package com.example.stock;

import java.util.HashMap;
import java.util.Map;

public class InMemoryStockRepository implements StockRepository {
    private Map<String, StockItem> items = new HashMap<>();
    
    public InMemoryStockRepository() {
        // Initialize with some sample data
        items.put("Laptop", new StockItem("Laptop", 10, 5));
        items.put("Mouse", new StockItem("Mouse", 25, 10));
    }
    
    @Override
    public StockItem findByName(String name) {
        return items