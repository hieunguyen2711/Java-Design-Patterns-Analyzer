package com.example.stock;

public class InventoryService {
    private StockRepository stockRepository;
    
    // Constructor injection
    public InventoryService(StockRepository stockRepository) {
        this.stockRepository = stockRepository;
    }
    
    public void updateStock(String itemName, int quantity) {
        StockItem item = stockRepository.findByName(itemName);
        if (item != null) {
            item.setCurrentStock(item.getCurrentStock() + quantity);
            stockRepository.save(item);
        }
    }
    
    public boolean needsReorder(String itemName) {
        StockItem item = stockRepository.findByName(itemName);
        return item != null && item.getCurrentStock() <= item.getReorderThreshold();
    }
}