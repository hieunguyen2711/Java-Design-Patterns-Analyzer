package com.example.stock;

public class StockItem {
    private final String itemId;
    private final int quantity;
    private final String location;
    
    public StockItem(String itemId, int quantity, String location) {
        this.itemId = itemId;
        this.quantity = quantity;
        this.location = location;
    }
    
    public String getItemId() {
        return itemId;
    }
    
    public int getQuantity() {
        return quantity;
    }
    
    public String getLocation() {
        return location;
    }
}