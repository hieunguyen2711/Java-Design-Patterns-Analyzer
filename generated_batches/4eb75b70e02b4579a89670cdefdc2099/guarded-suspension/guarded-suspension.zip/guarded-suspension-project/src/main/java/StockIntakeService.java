package com.example.stock;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class StockIntakeService {
    private final BlockingQueue<StockItem> intakeQueue = new LinkedBlockingQueue<>();
    
    public void addStock(StockItem item) {
        try {
            intakeQueue.put(item);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Interrupted while adding stock", e);
        }
    }
    
    public StockItem takeStock() throws InterruptedException {
        return intakeQueue.take(); // This blocks until an item is available
    }
}