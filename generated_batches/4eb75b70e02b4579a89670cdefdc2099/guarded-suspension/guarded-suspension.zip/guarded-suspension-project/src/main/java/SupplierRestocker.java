package com.example.stock;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class SupplierRestocker {
    private final StockIntakeService intakeService;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    
    public SupplierRestocker(StockIntakeService intakeService) {
        this.intakeService = intakeService;
    }
    
    public void startRestocking() {
        executor.submit(() -> {
            try {
                while (!Thread.currentThread().isInterrupted()) {
                    // Guarded suspension: wait until there's stock to process
                    StockItem item = intakeService.takeStock();
                    
                    // Process the restock
                    System.out.println("Processing restock for item " + 
                        item.getItemId() + " at location " + item.getLocation());
                    
                    TimeUnit.SECONDS.sleep(2); // Simulate processing time
                    
                    System.out.println("Restock completed for item " + item.getItemId());
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.out.println("Supplier restocker interrupted");
            }
        });
    }
    
    public void shutdown() throws InterruptedException {
        executor.shutdown();
        if