package com.example.stock;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;

public class StockService {
    private final List<StockItem> inventory;
    
    public StockService(List<StockItem> inventory) {
        this.inventory = inventory;
    }
    
    // Monad-like operation: chain operations that might fail
    public Optional<Integer> processStockMovement(String itemId, int quantityChange) {
        return findItem(itemId)
                .map(item -> updateQuantity(item, quantityChange))
                .filter(item -> item.getQuantity() >= 0)
                .map(this::checkReorderThreshold);
    }
    
    private Optional<StockItem> findItem(String itemId) {
        return inventory.stream()
                .filter(item -> item.getItemId().equals(itemId))
                .findFirst();
    }
    
    private StockItem updateQuantity(StockItem item, int quantityChange) {
        item.setQuantity(item.getQuantity() + quantityChange);
        return item;
    }
    
    private StockItem checkReorderThreshold(StockItem item) {
        if (item.getQuantity() <= item.getReorderThreshold()) {
            System.out.println("WARNING: Item " + item.getItemId() + 
                             " below reorder threshold of " + item.getReorderThreshold());
        }
        return item;
    }
}