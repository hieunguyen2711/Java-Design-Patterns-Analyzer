package com.example.stock;

import java.util.Optional;
import java.util.function.Function;

public class StockMonad {
    
    public static void main(String[] args) {
        // Create sample inventory
        var stockService = new StockService(List.of(
            new StockItem("LAPTOP-001", 15, 5),
            new StockItem("MOUSE-0