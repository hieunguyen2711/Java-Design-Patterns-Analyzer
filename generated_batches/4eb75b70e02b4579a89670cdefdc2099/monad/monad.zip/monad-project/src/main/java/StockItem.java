package com.example.stock;

public class StockItem {
    private final String itemId;
    private int quantity;
    private final int reorderThreshold;
    
    public StockItem(String itemId, int quantity, int reorderThreshold) {
        this.itemId = itemId;
        this.quantity = quantity;
        this.reorderThreshold = reorderThreshold;
    }
    
    public String getItemId() {
        return itemId;
    }
    
    public int getQuantity() {
        return quantity;
    }
    
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    public int getReorderThreshold() {
        return reorderThreshold;
    }
}