package com.example.inventory;

public class StockMovementLog {
    private final String itemId;
    private final String action;
    private final int quantity;
    private final String timestamp;
    
    public StockMovementLog(String itemId, String action, int quantity) {
        this.itemId = itemId;
        this