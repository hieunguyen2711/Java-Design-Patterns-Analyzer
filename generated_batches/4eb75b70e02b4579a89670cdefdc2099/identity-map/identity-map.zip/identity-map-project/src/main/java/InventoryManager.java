package com.example.inventory;

import java.util.HashMap;
import java.util.Map;

public class InventoryManager {
    private static final Map<String, StockItem> identityMap = new HashMap<>();
    
    public static StockItem getStockItem(String itemId) {
        return identityMap.computeIfAbsent(itemId, id -> new StockItem(id, "", 0, 0));
    }
    
    public static void updateStockItem(StockItem item) {
        identityMap.put(item.getItemId(), item);
    }
    
    public static void removeStockItem(String itemId) {
        identityMap.remove(itemId);
    }
    
    public static boolean containsItem(String itemId) {
        return identityMap.containsKey(itemId);
    }
}