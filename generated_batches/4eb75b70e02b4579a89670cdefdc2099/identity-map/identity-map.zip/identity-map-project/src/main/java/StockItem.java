package com.example.inventory;

public class StockItem {
    private final String itemId;
    private String name;
    private int quantity;
    private int reorderThreshold;
    
    public StockItem(String itemId, String name, int quantity, int reorderThreshold) {
        this.itemId = itemId;
        this.name = name;
        this.quantity = quantity;
        this.reorderThreshold = reorderThreshold;
    }
    
    public String getItemId() {
        return itemId;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public int getQuantity() {
        return quantity;
    }
    
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    public int getReorderThreshold() {
        return reorderThreshold;
    }
    
    public void setReorderThreshold(int reorderThreshold) {
        this.reorderThreshold = reorderThreshold;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        StockItem stockItem = (StockItem) obj;
        return itemId.equals(stockItem.itemId);
    }
    
    @Override
    public int hashCode() {
        return itemId.hashCode();
    }
}