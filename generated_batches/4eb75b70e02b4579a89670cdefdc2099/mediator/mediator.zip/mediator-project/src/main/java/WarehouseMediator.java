import java.util.ArrayList;
import java.util.List;

public class WarehouseMediator implements StockMediator {
    private List<StockItem> items;
    
    public WarehouseMediator() {
        this.items = new ArrayList<>();
    }
    
    @Override
    public void registerItem(StockItem item) {
        items.add(item);
        System.out.println("Item registered: " + item.getName());
    }
    
    @Override
    public void requestRestock(StockItem item) {
        if (item.getQuantity() < item.getReorderThreshold()) {
            System.out.println("Restocking requested for: " + item.getName());
            item.setQuantity(item.getReorderThreshold() * 2);
            logMovement("Restocked " + item.getName() + " to " + item.getQuantity());
        }
    }
    
    @Override
    public void updateLocation(StockItem item, String newLocation) {
        item.setLocation(newLocation);
        logMovement("Moved " + item.getName() + " to location: " + newLocation);
    }
    
    @Override
    public void logMovement(String message) {
        System.out.println("[LOG] " + message);
    }
}