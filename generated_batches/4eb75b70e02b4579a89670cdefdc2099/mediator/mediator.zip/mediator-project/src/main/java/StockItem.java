public class StockItem {
    private String name;
    private int quantity;
    private String location;
    private int reorderThreshold;
    private WarehouseMediator mediator;
    
    public StockItem(String name, int quantity, String location, int reorderThreshold, 
                     WarehouseMediator mediator) {
        this.name = name;
        this.quantity = quantity;
        this.location = location;
        this.reorderThreshold = reorderThreshold;
        this.mediator = mediator;
        
        mediator.registerItem(this);
    }
    
    public void updateQuantity(int newQuantity) {
        this.quantity = newQuantity;
        if (newQuantity < reorderThreshold) {
            mediator.requestRestock(this);
        }
    }
    
    public void moveItem(String newLocation) {
        mediator.updateLocation(this, newLocation);
    }
    
    // Getters and setters
    public String getName() { return name; }
    public int getQuantity