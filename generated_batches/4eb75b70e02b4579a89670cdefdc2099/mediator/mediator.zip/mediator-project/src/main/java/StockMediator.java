public interface StockMediator {
    void registerItem(StockItem item);
    void requestRestock(StockItem item);
    void updateLocation(StockItem item, String newLocation);
    void logMovement(String message);
}