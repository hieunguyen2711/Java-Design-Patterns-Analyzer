package com.example.stock;

public class Location {
    private String aisle;
    private String shelf;
    private String bin;
    
    public Location(String aisle, String shelf, String bin) {
        this.aisle = aisle;
        this.shelf = shelf;
        this.bin = bin;
    }
    
    // Getters and setters
    public String getAisle() { return aisle; }
    public void setAisle(String aisle) { this.aisle = aisle; }
    public String getShelf() { return shelf; }
    public void setShelf(String shelf) { this.shelf = shelf; }
    public String getBin() { return bin; }
    public void setBin(String bin) { this.bin = bin; }
    
    @Override
    public String toString() {
        return aisle + "-" + shelf + "-" + bin;
    }
}