package com.example.stock;

public class StockItem {
    private String name;
    private int currentStock;
    private int reorderThreshold;
    
    public StockItem(String name, int currentStock, int reorderThreshold) {
        this.name = name;
        this.currentStock = currentStock;
        this.reorderThreshold = reorderThreshold;
    }
    
    // Getters and setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getCurrentStock() { return currentStock; }
    public void setCurrentStock(int currentStock) { this.currentStock = currentStock; }
    public int getReorderThreshold() { return reorderThreshold; }
    public void setReorderThreshold(int reorderThreshold) { this.reorderThreshold = reorderThreshold; }
    
    @Override
    public String toString() {
        return "StockItem{name='" + name + "', currentStock=" + currentStock + 
               ", reorderThreshold=" + reorderThreshold + '}';
    }
}