package com.example.stock;

public class Supplier {
    private String name;
    private String contactInfo;
    
    public Supplier(String name, String contactInfo) {
        this.name = name;
        this.contactInfo = contactInfo;
    }
    
    // Getters and setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getContactInfo() { return contact