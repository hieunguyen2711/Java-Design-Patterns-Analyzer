package com.example.stock;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class StockIntakeService {
    private final ExecutorService executor = Executors.newFixedThreadPool(4);
    
    public CompletableFuture<StockUpdateResult> processStockIntake(String itemId, int quantity) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                // Simulate processing delay
                Thread.sleep(1000);
                
                // Process the stock intake
                StockItem item = InventoryManager.getItem(itemId);
                if (item == null) {
                    throw new IllegalArgumentException("Item not found: " + itemId);
                }
                
                int newQuantity = item.getQuantity() + quantity;
                item.setQuantity(newQuantity);
                
                // Check reorder threshold
                if (newQuantity <= item.getReorderThreshold()) {
                    CompletableFuture<Void> restockPromise = triggerRestock(itemId, 
                        item.getReorderThreshold() - newQuantity + 10);
                    return new StockUpdateResult(true, "Stock updated and restock triggered", 
                        item, restockPromise);
                }
                
                return new StockUpdateResult(true, "Stock updated successfully", item, null);
            } catch (Exception e) {
                return new StockUpdateResult(false, "Failed to update stock: " + e.getMessage(), null, null);
            }
        }, executor);
    }
    
    private CompletableFuture<Void> triggerRestock(String itemId, int quantity) {
        return CompletableFuture.runAsync(() -> {
            try {
                Thread.sleep(500);
                SupplierService.restockItem(itemId, quantity);
                MovementLog.logMovement("RESTOCK", itemId, quantity);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }, executor);
    }
    
    public void shutdown() {
        executor.shutdown();
    }
}