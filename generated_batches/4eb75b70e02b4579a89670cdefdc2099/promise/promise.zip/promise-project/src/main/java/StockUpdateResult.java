package com.example.stock;

import java.util.concurrent.CompletableFuture;

public class StockUpdateResult {
    private final boolean success;
    private final String message;
    private final StockItem item;
    private final CompletableFuture<Void> restockPromise;
    
    public StockUpdateResult(boolean success, String message, StockItem item, 
                           CompletableFuture<Void> restockPromise) {
        this.success = success;
        this.message = message;
        this.item = item;
        this.restockPromise = restockPromise;