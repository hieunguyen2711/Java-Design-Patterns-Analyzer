public class StockItemProxy implements StockItemInterface {
    private String itemId;
    private StockItem realStockItem;
    
    public StockItemProxy(String itemId) {
        this.itemId = itemId;
    }
    
    @Override
    public String getItemId() {
        return getRealStockItem().getItemId();
    }
    
    @Override
    public String getItemName()