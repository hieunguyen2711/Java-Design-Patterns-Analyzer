public class StockItem {
    private String itemId;
    private String itemName;
    private int currentStock;
    private int reorderThreshold;
    
    public StockItem(String itemId, String itemName, int currentStock, int reorderThreshold) {
        this.itemId = itemId;
        this.itemName = itemName;
        this.currentStock = currentStock;
        this.reorderThreshold = reorderThreshold;
    }
    
    // Getters and setters
    public String getItemId() { return itemId; }
    public String getItemName() { return itemName; }
    public int getCurrentStock() { return currentStock; }
    public void setCurrentStock(int currentStock) { this.currentStock = currentStock; }
    public int getReorderThreshold() { return reorderThreshold; }
    
    @Override
    public String toString() {
        return "StockItem{" +
                "itemId='" + itemId + '\'' +
                ", itemName='" + itemName + '\'' +
                ", currentStock=" + currentStock +
                ", reorderThreshold=" + reorderThreshold +
                '}';
    }
}