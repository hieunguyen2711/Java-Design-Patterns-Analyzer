import java.util.HashMap;
import java.util.Map;

public class StockDatabase {
    private static final Map<String, StockItem> database = new HashMap<>();
    
    static {
        // Initialize with some sample data
        database.put("ITEM001", new StockItem("ITEM001", "Laptop", 25, 10));
        database.put("ITEM002", new StockItem("ITEM002", "Mouse", 100, 20));
        database.put("ITEM003", new StockItem("ITEM003", "Keyboard", 75, 15));
    }
    
    public static StockItem getItem(String itemId) {
        // Simulate expensive database operation
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return database.get(itemId);
    }
}