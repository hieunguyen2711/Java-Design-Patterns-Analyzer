package com.example.stock;

public class StockIntakePage {
    private final String pageUrl;
    
    public StockIntakePage(String url) {
        this.pageUrl = url;
    }
    
    public void navigateTo() {
        System.out.println("Navigating to " + pageUrl);
    }
    
    public void enterItemCode(String code) {
        System.out.println("Entering item code: " + code);
    }
    
    public void enterQuantity(int quantity) {
        System.out.println("Entering quantity: " + quantity);
    }
    
    public void clickSave() {
        System.out.println("Clicking save button");
    }
}