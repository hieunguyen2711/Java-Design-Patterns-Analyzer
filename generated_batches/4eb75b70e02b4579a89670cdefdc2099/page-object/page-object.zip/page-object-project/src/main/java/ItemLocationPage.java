package com.example.stock;

public class ItemLocationPage {
    private final String pageUrl;
    
    public ItemLocationPage(String url) {
        this.pageUrl = url;
    }
    
    public void navigateTo() {
        System.out.println("Navigating to " + pageUrl);
    }
    
    public void searchItem(String itemCode) {
        System.out.println("Searching for item: " + itemCode);
    }
    
    public void updateLocation(String location) {
        System.out.println("Updating location to: " + location);
    }
    
    public void clickUpdate() {
        System.out.println("Clicking update button");
    }
}