package com.example.stock;

public class SupplierRestockPage {
    private final String pageUrl;
    
    public SupplierRestockPage(String url) {
        this.pageUrl = url;
    }
    
    public void navigateTo() {
        System.out.println("Navigating to " + pageUrl);
    }
    
    public void selectSupplier(String supplier