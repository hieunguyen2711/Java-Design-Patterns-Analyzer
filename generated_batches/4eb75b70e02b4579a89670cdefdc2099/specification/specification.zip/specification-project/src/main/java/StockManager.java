package com.example.stock;

import java.util.ArrayList;
import java.util.List;

public class StockManager {
    private List<StockItem> stockItems;
    
    public StockManager() {
        this.stockItems = new ArrayList<>();
    }
    
    public void addItem(StockItem item) {
        stockItems.add(item);
    }
    
    public void processReorders() {
        for (StockItem item : stockItems) {
            if (item.needsReorder()) {
                System.out.println("Reordering " + item.getName() + " from supplier: " + item.getSupplier().getName());
                // In a real implementation, this would trigger actual reordering logic
            }
        }
    }
    
    public void logMovement(String itemId, int quantity) {
        for (StockItem item : stockItems) {
            if (item.getItemId().equals(itemId)) {
                System.out.println("Movement logged: " + item.getName() + " changed by "