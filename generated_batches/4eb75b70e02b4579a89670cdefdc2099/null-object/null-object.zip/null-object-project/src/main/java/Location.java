package com.example.stock;

public class Location {
    private String aisle;
    private String shelf;
    private String bin;
    
    public static final Location NULL_LOCATION = new NullLocation();
    
    public Location(String aisle, String shelf, String bin) {
        this.aisle = aisle;
        this.shelf = shelf;
        this.bin = bin;
    }
    
    public String getAisle() {
        return aisle;
    }
    
    public String getShelf() {
        return shelf;
    }
    
    public String getBin() {
        return bin;
    }
    
    @Override
    public String toString() {
        return "Location{" +
                "aisle='" + aisle + '\'' +
                ", shelf='" + shelf + '\'' +
                ", bin='" + bin + '\'' +