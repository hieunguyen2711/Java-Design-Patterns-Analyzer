package com.example.stock.service;

public interface StockIntakeService {
    void processStockIntake(String itemId, int quantity);
}