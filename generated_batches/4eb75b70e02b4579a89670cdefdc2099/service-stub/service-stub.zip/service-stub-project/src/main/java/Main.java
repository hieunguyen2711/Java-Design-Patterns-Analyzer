package com.example.stock;

import com.example.stock.service.StockIntakeServiceStub;

public class Main {
    public static void main(String[] args) {
        InventoryManager manager = new InventoryManager();
        
        // Using real implementation
        System.out.println("Using real service:");
        manager.handleStockArrival("ITEM-001", 50);
        
        // Using stub implementation for testing
        System.out.println("\nUsing stub service:");
        manager.setStockIntakeService(new StockIntakeServiceStub());
        manager.handleStockArrival("ITEM-002", 30);