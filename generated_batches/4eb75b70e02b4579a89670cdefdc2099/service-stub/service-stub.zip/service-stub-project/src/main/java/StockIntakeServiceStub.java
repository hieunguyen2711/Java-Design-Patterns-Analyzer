package com.example.stock.service;

public class StockIntakeServiceStub implements StockIntakeService {
    
    @Override
    public void processStockIntake(String itemId, int quantity) {
        // Stub implementation - does nothing but logs the call
        System.out.println("STUB: Stock intake processed for item " + itemId + 
                          " with quantity " + quantity);
    }
}