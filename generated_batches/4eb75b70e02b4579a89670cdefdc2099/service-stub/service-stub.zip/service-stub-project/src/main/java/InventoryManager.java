package com.example.stock;

import com.example.stock.service.StockIntakeService;
import com.example.stock.service.StockIntakeServiceImpl;

public class InventoryManager {
    private StockIntakeService stockIntakeService;
    
    public InventoryManager() {
        this.stockIntakeService = new StockIntakeServiceImpl();
    }
    
    public void setStockIntakeService(StockIntakeService service) {
        this.stockIntakeService = service;
    }
    
    public void handleStockArrival(String itemId, int quantity) {
        stockIntakeService.processStockIntake(itemId, quantity);
    }
}