public enum MovementType {
    INBOUND,
    OUTBOUND,
    TRANSFER
}