import java.time.LocalDateTime;

public class StockMovementLog {
    private String logId;
    private String itemId;
    private MovementType type;
    private int quantity;
    private LocalDateTime timestamp;
    private String locationFrom;
    private String locationTo;
    
    public StockMovementLog(String logId, String itemId, MovementType type, int quantity, 
                          LocalDateTime timestamp, String locationFrom, String