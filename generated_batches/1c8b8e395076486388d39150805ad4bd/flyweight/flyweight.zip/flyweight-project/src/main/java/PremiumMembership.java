public class PremiumMembership implements Membership {
    private static final String TYPE = "Premium";
    private static final double MONTHLY_FEE = 59.99;
    private static final int GYM_ACCESS = 3;
    private static final String BENEFITS = "Gym access, premium equipment, personal training session";
    
    @Override
    public String getType() {
        return TYPE;
    }
    
    @Override
    public double getMonthlyFee() {
        return MONTHLY_FEE;
    }
    
    @Override
    public int getGymAccess() {
        return GYM_ACCESS;
    }
    
    @Override