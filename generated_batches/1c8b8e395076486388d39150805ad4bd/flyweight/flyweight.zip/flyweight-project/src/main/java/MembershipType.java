public enum MembershipType {
    BASIC, PREMIUM, VIP
}