public interface Membership {
    String getType();
    double getMonthlyFee();
    int getGymAccess();
    String getBenefits();
}