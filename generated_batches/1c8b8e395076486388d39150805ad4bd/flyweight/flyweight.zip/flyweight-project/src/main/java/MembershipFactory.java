import java.util.HashMap;
import java.util.Map;

public class MembershipFactory {
    private static final Map<MembershipType, Membership> cache = new HashMap<>();
    
    public static Membership getMembership(MembershipType type) {
        return cache.computeIfAbsent(type, MembershipFactory::createMembership);
    }
    
    private static Membership createMembership(MembershipType type) {
        switch (type) {
            case BASIC:
                return new BasicMembership();
            case PREMIUM:
                return new PremiumMembership();
            case VIP:
                return new VipMembership();
            default:
                throw new IllegalArgumentException("Unknown membership type: " + type);
        }
    }
}