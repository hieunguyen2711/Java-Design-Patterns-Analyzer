public class BasicMembership implements Membership {
    private static final String TYPE = "Basic";
    private static final double MONTHLY_FEE = 29.99;
    private static final int GYM_ACCESS = 1;
    private static final String BENEFITS = "Gym access, basic equipment";
    
    @Override
    public String getType() {
        return TYPE;
    }
    
    @Override
    public double getMonthlyFee() {
        return MONTHLY_FEE;
    }
    
    @Override
    public int getGymAccess() {
        return GYM_ACCESS;
    }
    
    @Override
    public String getBenefits() {
        return BENEFITS;
    }
}