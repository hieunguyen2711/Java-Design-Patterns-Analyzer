package com.example.membership.service;

public class Membership {
    private Long id;
    private String memberName;
    private String membershipType;
    private double monthlyFee;

    public Membership() {}

    public Membership(Long id, String memberName, String membershipType, double monthlyFee) {
        this.id = id;
        this.memberName = memberName;
        this.membershipType = membershipType;
        this.monthlyFee = monthlyFee;
    }

    // Getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getMemberName() { return memberName; }
    public void setMemberName(String memberName) { this.memberName = memberName; }
    
    public String getMembershipType() { return membershipType; }
    public void setMembership