package com.example.membership.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

public class MembershipServiceImpl implements MembershipService {
    private final ConcurrentHashMap<Long, Membership> memberships = new ConcurrentHashMap<>();
    private long nextId = 1L;

    @Override
    public Membership createMembership(Membership membership) {
        membership.setId(nextId++);
        memberships.put(membership.getId(), membership);
        return membership;
    }

    @Override
    public Optional<Membership> getMembershipById(Long id) {
        return Optional.ofNullable(memberships.get(id));
    }

    @Override
    public List<Membership> getAllMemberships() {
        return new ArrayList<>(memberships.values());
    }

    @Override
    public Membership updateMembership(Long id, Membership membership) {
        if (memberships.containsKey(id)) {
            membership.setId(id);
            memberships.put(id, membership);
            return membership;
        }
        throw new RuntimeException("Membership not found with id: " + id);
    }

    @Override
    public void deleteMembership(Long id) {
        memberships.remove(id);
    }
}