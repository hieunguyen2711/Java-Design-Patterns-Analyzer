package com.example.membership.service;

import java.util.List;
import java.util.Optional;

public interface MembershipService {
    Membership createMembership(Membership membership);
    Optional<Membership> getMembershipById(Long id);
    List<Membership> getAllMemberships();
    Membership updateMembership(Long id, Membership membership);
    void deleteMembership(Long id);
}