import java.util.*;

public class PaymentTracker {
    private Map<String, List<PaymentRecord>> paymentRecords;
    
    public PaymentTracker() {
        this.paymentRecords = new HashMap<>();
    }
    
    public void addPayment(PaymentRecord record) {
        paymentRecords.computeIfAbsent(record.getMemberId(), k -> new ArrayList<>()).add(record);
    }
    
    public List<PaymentRecord> getPaymentsForMember(String memberId) {
        return paymentRecords.getOrDefault(memberId, Collections.emptyList());
    }
}