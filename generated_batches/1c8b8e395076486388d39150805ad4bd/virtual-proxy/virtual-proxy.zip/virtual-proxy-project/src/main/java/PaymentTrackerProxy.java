public class PaymentTrackerProxy implements PaymentTrackerInterface {
    private PaymentTracker realTracker;
    private String currentUser;
    
    public PaymentTrackerProxy(String currentUser) {
        this.currentUser = currentUser;
    }
    
    @Override
    public List<PaymentRecord> getPaymentsForMember(String memberId) {
        // Lazy initialization - only create real object when needed
        if (realTracker == null) {
            realTracker = new PaymentTracker();
            loadSampleData(realTracker);
        }
        
        // Security check - only allow access to own records or admin
        if (!currentUser.equals(memberId) && !isAdmin()) {
            throw new