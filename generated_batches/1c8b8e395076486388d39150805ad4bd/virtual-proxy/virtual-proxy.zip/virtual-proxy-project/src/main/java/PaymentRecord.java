public class PaymentRecord {
    private String paymentId;
    private String memberId;
    private double amount;
    private String date;
    
    public PaymentRecord(String paymentId, String memberId, double amount, String date) {
        this.paymentId = paymentId;
        this.memberId = memberId;
        this.amount = amount;
        this.date = date;
    }
    
    // Getters
    public String getPaymentId() { return paymentId; }
    public String getMemberId() { return memberId; }
    public double getAmount() { return amount; }
    public String getDate() { return date; }
}