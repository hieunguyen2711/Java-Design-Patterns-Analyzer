package com.example.membership;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MembershipMapper {
    private Connection connection;
    
    public MembershipMapper(Connection connection) {
        this.connection = connection;
    }
    
    public Membership findById(int id) throws SQLException {
        String sql = "SELECT * FROM memberships WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapRowToMembership(rs);
            }
        }
        return null;
    }
    
    public List<Membership> findAll() throws SQLException {
        List<Membership> memberships = new ArrayList<>();
        String sql = "SELECT * FROM memberships";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                memberships.add(mapRowToMembership(rs));
            }
        }
        return memberships;
    }
    
    public void save(Membership membership) throws SQLException {
        if (membership.getId() > 0) {
            update(membership);
        } else {
            insert(membership);