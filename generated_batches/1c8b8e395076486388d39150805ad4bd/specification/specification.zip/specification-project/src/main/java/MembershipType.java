package com.membership;

public enum MembershipType {
    BASIC,
    PREMIUM,
    VIP
}