package com.membership;

public class PremiumMembership extends Membership {
    
    public PremiumMembership(String memberId, String name) {
        super(memberId, name, MembershipType.PREMIUM);
    }
    
    @Override
    public String toString() {
        return "PremiumMembership{" +
                "memberId='" + getMemberId() + '\'' +
                ", name='" + getName() + '\'' +
                '}';
    }
}