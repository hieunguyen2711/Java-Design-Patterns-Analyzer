package com.membership;

public class BasicMembership extends Membership {
    
    public BasicMembership(String memberId, String name) {
        super(memberId, name, MembershipType.BASIC);
    }
    
    @Override
    public String toString() {
        return "BasicMembership{" +
                "memberId='" + getMemberId() + '\'' +
                ", name='" + getName() + '\'' +
                '}';
    }
}