package com.membership;

public class Membership {
    private String memberId;
    private String name;
    private MembershipType type;
    
    public Membership(String memberId, String name, MembershipType type) {
        this.memberId = memberId;
        this.name = name;
        this.type = type;
    }
    
    public String getMemberId() {
        return memberId;
    }
    
    public String getName() {
        return name;
    }
    
    public MembershipType getType() {
        return type;
    }
}