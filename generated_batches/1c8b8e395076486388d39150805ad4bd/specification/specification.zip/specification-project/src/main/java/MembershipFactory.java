package com.membership;

public class MembershipFactory {
    
    public static Membership createMembership(String memberId, String name, String type) {
        MembershipType membershipType = MembershipType.valueOf(type.toUpperCase());
        
        switch (membershipType) {
            case BASIC:
                return new BasicMembership(memberId, name);
            case PREMIUM:
                return new PremiumMembership(memberId, name);
            case VIP:
                return new VipMembership(memberId, name);
            default:
                throw new IllegalArgumentException("Unknown membership type: " + type);
        }
    }
}