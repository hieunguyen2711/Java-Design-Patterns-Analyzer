package com.membership;

public class VipMembership extends Membership {
    
    public VipMembership(String memberId, String name) {
        super(memberId, name