public class ClassSchedule {
    private String classId;
    private String className;
    private String trainerName;
    private String date;
    private int maxCapacity;
    
    public ClassSchedule(String classId, String className, String trainerName, String date, int maxCapacity) {
        this.classId = classId;
        this.className = className;
        this.trainerName = trainerName;
        this.date = date;
        this.maxCapacity = maxCapacity;
    }
    
    // Getters and setters
    public String getClassId() { return classId; }
    public void setClassId(String classId) { this.classId = classId; }
    public String getClassName() { return className; }
    public void setClassName(String className) { this.className = className; }
    public String getTrainerName() { return trainerName; }
    public void setTrainerName(String trainerName) { this.trainerName = trainerName; }
    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }
    public int getMaxCapacity() { return maxCapacity; }
    public void setMaxCapacity(int maxCapacity) { this.maxCapacity = maxCapacity; }
}