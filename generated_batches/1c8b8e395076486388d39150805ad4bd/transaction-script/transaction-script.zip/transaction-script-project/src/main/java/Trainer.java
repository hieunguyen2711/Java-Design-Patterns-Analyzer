public class Trainer {
    private String trainerId;
    private String name;
    private String specialty;
    
    public Trainer(String trainerId, String name, String specialty) {
        this.trainerId = trainerId;
        this.name = name;
        this.specialty = specialty;
    }
    
    // Getters and setters
    public String getTrainerId() { return trainerId; }
    public void setTrainer