package com.example.membership;

public class MembershipService {
    private static MembershipService instance;
    
    private MembershipService() {}
    
    public static synchronized MembershipService getInstance() {
        if (instance == null) {
            instance = new MembershipService();
        }
        return instance;
    }
    
    public Member createMember(String name, String membershipType) {
        Membership membership = MembershipFactory.createMembership(membershipType);
        return new Member(name,