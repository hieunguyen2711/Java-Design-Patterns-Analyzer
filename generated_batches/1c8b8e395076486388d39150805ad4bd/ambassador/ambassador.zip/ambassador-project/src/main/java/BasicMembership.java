package com.example.membership;

public class BasicMembership implements Membership {
    @Override
    public String getMembershipType() {
        return "Basic";
    }

    @Override
    public double getMonthlyFee() {
        return 29.99;
    }

    @Override
    public boolean isEligibleForDiscount() {
        return false;
    }
}