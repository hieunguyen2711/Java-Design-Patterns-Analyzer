public class Main {
    public static void main(String[] args) {
        Membership goldMember = new Membership("John Doe", new CreditCardPayment("1234567890123456", "John Doe"));
        goldMember.processPayment(99.99);
        
        goldMember.setPaymentStrategy(new PayPalPayment("john.doe@example.com"));
        goldMember.processPayment(149.99);
    }
}