public class Membership {
    private String memberName;
    private PaymentStrategy paymentStrategy;
    
    public Membership(String memberName, PaymentStrategy paymentStrategy) {
        this.memberName = memberName;
        this.paymentStrategy = paymentStrategy;
    }
    
    public void setPaymentStrategy(PaymentStrategy paymentStrategy) {
        this.paymentStrategy = paymentStrategy;
    }
    
    public void processPayment(double amount) {
        System.out.println("Processing payment for " + memberName);
        paymentStrategy.pay(amount);
    }
}