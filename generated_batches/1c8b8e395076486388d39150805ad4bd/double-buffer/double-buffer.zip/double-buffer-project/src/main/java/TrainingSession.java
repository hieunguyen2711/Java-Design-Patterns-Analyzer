package com.gym.schedule;

import java.time.LocalDateTime;
import java.util.List;
import com.gym.membership.Membership;

public class TrainingSession {
    private String sessionId;
    private String sessionName;
    private LocalDateTime dateTime;
    private List<Membership> enrolledMembers;
    
    public TrainingSession(String sessionId, String sessionName, LocalDateTime dateTime) {
        this.sessionId = sessionId;
        this.sessionName = sessionName;
        this.dateTime = dateTime;