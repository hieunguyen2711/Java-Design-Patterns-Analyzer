package com.gym.membership;

public class Membership {
    private String memberId;
    private String name;
    private MembershipType type;
    
    public Membership(String memberId, String name, MembershipType type) {
        this.memberId = memberId;
        this.name = name;
        this.type = type;
    }
    
    // Getters and setters
    public String getMemberId() { return memberId; }
    public void setMemberId(String memberId) { this.memberId = memberId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public MembershipType getType() { return type; }
    public void setType(MembershipType type) { this.type = type; }
}