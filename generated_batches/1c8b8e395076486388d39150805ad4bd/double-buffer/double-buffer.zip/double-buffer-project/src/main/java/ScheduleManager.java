package com.gym.schedule;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import com.gym.membership.Membership;

public class ScheduleManager {
    private final Map<String, List<TrainingSession>> scheduleBuffer = new ConcurrentHashMap<>();
    private final Map<String, List<TrainingSession>> activeSchedule = new ConcurrentHashMap<>();
    
    public void addSession(String day, TrainingSession session) {
        // Double buffering: write to buffer first
        scheduleBuffer.computeIfAbsent(day, k -> new ArrayList<>()).add(session);
    }
    
    public void commitChanges() {
        // Atomic switch of buffers
        activeSchedule.clear();
        activeSchedule.putAll(scheduleBuffer);
        scheduleBuffer.clear();
    }
    
    public List<TrainingSession> getSessionsForDay(String day) {
        return activeSchedule.getOrDefault(day, Collections.emptyList());
    }
    
    public Map<String, List<TrainingSession>> getAllSchedules() {
        return new HashMap<>(activeSchedule);
    }
}