package com.example.membership;

import java.util.ArrayList;
import java.util.List;

public class MembershipDAOImpl implements MembershipDAO {
    private List<Membership> memberships;
    
    public MembershipDAOImpl() {
        this.memberships = new ArrayList<>();
        // Initialize with some sample data
        memberships.add(new Membership(1, "John Doe", "john@example.com", "Premium"));
        memberships.add(new Membership(2, "Jane Smith", "jane@example.com", "Basic"));
    }
    
    @Override
    public Membership getMembershipById(int id) {
        for (Membership membership : memberships) {
            if (membership.getId() == id) {
                return membership;
            }
        }
        return null;
    }
    
    @Override
    public List<Membership> getAllMemberships() {
        return new ArrayList<>(memberships);
    }
    
    @Override
    public void saveMembership(Membership membership) {
        memberships.add(membership);
    }
    
    @Override
    public void updateMembership(Members