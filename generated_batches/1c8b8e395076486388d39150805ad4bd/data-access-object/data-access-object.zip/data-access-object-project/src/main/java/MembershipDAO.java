package com.example.membership;

import java.util.List;

public interface MembershipDAO {
    Membership getMembershipById(int id);
    List<Membership> getAllMemberships();
    void saveMembership(Membership membership);
    void updateMembership(Membership membership);
    void deleteMembership(int id);
}