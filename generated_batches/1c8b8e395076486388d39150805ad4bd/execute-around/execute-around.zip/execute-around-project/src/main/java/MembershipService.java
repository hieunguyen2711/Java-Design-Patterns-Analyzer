package com.membership;

import java.util.concurrent.Callable;

public class MembershipService {
    public <T> T executeWithMembershipValidation(Callable<T> operation) throws Exception {
        // Simulate membership validation
        if (!isMemberValid()) {
            throw new IllegalStateException("Membership is not valid");
        }
        
        return operation.call();
    }
    
    private boolean isMemberValid() {
        // Simulate validation logic
        return true;
    }
}