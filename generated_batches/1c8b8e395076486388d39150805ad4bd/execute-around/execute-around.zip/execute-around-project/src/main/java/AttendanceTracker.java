package com.membership;

import java.util.concurrent.Callable;

public class AttendanceTracker {
    public <T> T executeWithAttendanceTracking(Callable<T> operation) throws Exception {
        // Simulate attendance tracking setup
        startTracking();
        
        try {
            return operation.call();
        } finally {
            // Always finalize attendance record
            endTracking();
        }
    }
    
    private void startTracking() {
        System.out.println("Starting attendance tracking...");
    }
    
    private void endTracking() {
        System.out.println("Ending attendance tracking...");
    }
}