package com.membership;

import java.util.concurrent.Callable;

public class PaymentProcessor {
    public <T> T executeWithPaymentProcessing(Callable<T> operation) throws Exception {
        // Simulate payment processing setup
        beginPaymentProcess();
        
        try {
            return operation.call();
        } finally {
            // Always clean up payment resources
            cleanupPaymentProcess();
        }
    }
    
    private void beginPaymentProcess() {
        System.out.println("Starting payment process...");
    }
    
    private void cleanupPaymentProcess() {
        System.out.println("Cleaning up payment process...");
    }
}