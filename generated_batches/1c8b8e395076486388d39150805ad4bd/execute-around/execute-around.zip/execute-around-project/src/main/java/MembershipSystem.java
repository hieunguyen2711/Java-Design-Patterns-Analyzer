package com.membership;

import java.util.concurrent.Callable;

public class MembershipSystem {
    private final MembershipService membershipService = new MembershipService();
    private final PaymentProcessor paymentProcessor = new PaymentProcessor();
    private final AttendanceTracker attendanceTracker = new AttendanceTracker();
    
    public void enrollMember(String memberName) {
        try {
            membershipService.executeWithMembershipValidation(() -> {
                System.out.println("Enrolling member: " + memberName);
                return null;
            });
        } catch (Exception e) {
            System.err.println("Enrollment failed: " + e.getMessage());
        }
    }
    
    public void processPayment(String memberId, double amount)