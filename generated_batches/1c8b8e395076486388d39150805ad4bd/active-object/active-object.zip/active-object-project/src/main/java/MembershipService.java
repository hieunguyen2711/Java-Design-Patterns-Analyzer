import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class MembershipService implements ActiveObject {
    private final BlockingQueue<Runnable> queue = new LinkedBlockingQueue<>();
    private final Thread workerThread;

    public MembershipService() {
        this.workerThread = new Thread(this::processTasks);
        this.workerThread.start();
    }

    @Override
    public void scheduleClass(String className, String time) {
        queue.add(() -> {
            System.out.println("Scheduling class: " + className + " at " + time);
            // Simulate processing delay
            try { Thread.sleep(100); } catch (InterruptedException e) {}
        });
    }

    @Override
    public void bookTrainer(String trainerName, String time) {
        queue.add(() -> {
            System.out.println("Booking trainer: " + trainerName + " at " + time);
            // Simulate processing delay
            try { Thread.sleep(100); } catch (InterruptedException e) {}
        });
    }

    @Override
    public void checkInMember(String memberName) {
        queue.add(() -> {
            System.out.println("Checking in member: " + memberName);
            // Simulate processing delay
            try { Thread.sleep(100); } catch (InterruptedException e) {}
        });
    }

    @Override
    public void processPayment(String memberName, double amount) {
        queue.add(() -> {
            System.out.println("Processing payment of $" + amount + " for member: " + memberName);
            // Simulate processing delay
            try { Thread.sleep(100); } catch (InterruptedException e) {}
        });
    }

    private void processTasks() {
        while (!Thread.currentThread().isInterrupted()) {
            try {
                Runnable task = queue.take();
                task.run();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }

    public void shutdown() {
        workerThread.interrupt();
    }
}