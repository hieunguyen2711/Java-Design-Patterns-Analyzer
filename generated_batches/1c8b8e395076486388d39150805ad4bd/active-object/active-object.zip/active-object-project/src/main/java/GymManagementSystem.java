public class GymManagementSystem {
    private final MembershipService