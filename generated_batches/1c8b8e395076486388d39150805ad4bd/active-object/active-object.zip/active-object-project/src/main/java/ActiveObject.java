public interface ActiveObject {
    void scheduleClass(String className, String time);
    void bookTrainer(String trainerName, String time);
    void checkInMember(String memberName);
    void processPayment(String memberName, double amount);
}