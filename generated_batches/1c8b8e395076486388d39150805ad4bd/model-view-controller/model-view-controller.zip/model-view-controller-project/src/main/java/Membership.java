package com.membership.model;

public class Membership {
    private String memberId;
    private String name;
    private String email;
    private MembershipType type;
    
    public Membership(String memberId, String name, String email, MembershipType type) {
        this.memberId = memberId;
        this.name = name;
        this.email = email;
        this.type = type;
    }
    
    // Getters and setters
    public String getMemberId() { return memberId; }
    public void setMemberId(String memberId) { this.memberId = memberId; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public MembershipType getType() { return type; }
    public void setType(MembershipType type) { this.type = type; }
}