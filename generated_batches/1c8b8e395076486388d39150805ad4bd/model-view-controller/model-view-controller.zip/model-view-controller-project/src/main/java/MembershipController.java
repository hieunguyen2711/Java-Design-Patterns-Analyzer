package com.membership.controller;

import com.membership.model.Membership;
import com.membership.view.MembershipView;
import java.util.ArrayList;
import java.util.List;

public class MembershipController {
    private List<Membership> memberships;
    private MembershipView view;
    
    public MembershipController() {
        this.memberships = new ArrayList<>();
        this.view = new MembershipView();
    }
    
    public void addMembership(Membership membership) {
        memberships.add(membership);
    }
    
    public void updateMembership(String memberId, String name, String email, 
                               com.membership.model.MembershipType type) {
        for (Membership m : memberships) {
            if (m.getMemberId().equals(memberId)) {
                m.setName(name);
                m.setEmail(email);
                m.setType(type);
                break;
            }
        }
    }
    
    public void displayMemberships() {
        view.printMemberships(memberships);
    }
    
    public Membership findMembership(String memberId) {
        for (Membership m : memberships) {
            if (m.getMemberId().equals(memberId)) {
                return m;
            }
        }
        return null;
    }
}