package com.membership.model;

import java.util.ArrayList;
import java.util.List;

public class MembershipModel {
    private List<Membership> memberships;
    
    public MembershipModel() {
        this.memberships = new ArrayList<>();
    }