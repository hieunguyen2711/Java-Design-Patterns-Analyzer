package com.membership;

public class MembershipFactory {
    
    public static <T extends Membership> T createMembership(Class<T> membershipClass, String name, int id) {
        try {
            return membershipClass.getDeclaredConstructor(String.class, int.class)
                                .newInstance(name, id);
        } catch (Exception e) {
            throw new RuntimeException("Failed to create membership", e);
        }
    }
}