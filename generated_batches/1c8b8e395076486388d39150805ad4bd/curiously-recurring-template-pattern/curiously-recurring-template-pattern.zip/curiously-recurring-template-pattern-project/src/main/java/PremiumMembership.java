package com.membership;

public class PremiumMembership extends Membership {
    private double monthlyFee;
    
    public PremiumMembership(String memberName, int memberId) {
        super(memberName, memberId);
        this.monthlyFee = 79.99;
    }
    
    @Override
    public <T extends Membership> T getMembershipType() {
        return (T) this;
    }
    
    public double getMonthlyFee() {
        return monthlyFee;
    }
}