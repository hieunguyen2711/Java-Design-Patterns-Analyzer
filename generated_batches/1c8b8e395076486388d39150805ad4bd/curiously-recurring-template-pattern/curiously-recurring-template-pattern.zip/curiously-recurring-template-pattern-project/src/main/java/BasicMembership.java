package com.membership;

public class BasicMembership extends Membership {
    private double monthlyFee;
    
    public BasicMembership(String memberName, int memberId) {
        super(memberName, memberId);
        this.monthlyFee = 29.99;
    }
    
    @Override
    public <T extends Membership> T getMembershipType() {
        return (T) this;
    }
    
    public double getMonthlyFee() {
        return monthlyFee;
    }
}