package com.membership;

public class Main {
    public static void main(String[] args) {
        // Using CRTP to get type-safe membership instances
        BasicMembership basic = MembershipFactory.createMembership(BasicMembership.class, "John Doe", 1);
        PremiumMembership premium = MembershipFactory.createMembership(PremiumMembership.class, "Jane Smith", 2);
        
        // Demonstrating the curiously recurring template