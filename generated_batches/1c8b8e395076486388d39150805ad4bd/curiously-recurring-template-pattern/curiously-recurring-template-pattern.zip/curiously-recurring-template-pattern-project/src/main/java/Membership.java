package com.membership;

public abstract class Membership {
    protected String memberName;
    protected int memberId;
    
    public Membership(String memberName, int memberId) {
        this.memberName = memberName;
        this.memberId = memberId;
    }
    
    public abstract <T extends Membership> T getMembershipType();
    
    public String getMemberName() {
        return memberName;
    }
    
    public int getMemberId() {
        return memberId;
    }
}