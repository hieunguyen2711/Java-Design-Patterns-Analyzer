package com.membership.system;

public enum MembershipType {
    BASIC,
    PREMIUM,
    VIP
}