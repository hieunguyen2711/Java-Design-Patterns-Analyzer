package com.membership.system.pageobject;

import com.membership.system.Membership;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class ClassSchedulePage {
    private WebDriver driver;
    private WebDriverWait wait;
    
    // Page elements
    private By scheduleTable = By.id("schedule-table");
    private By registerButton = By.className("register-btn");
    private By membershipDropdown = By.id("membership-select");
    private By logoutLink = By.linkText("Logout");
    
    public ClassSchedulePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, 10);
        PageFactory.initElements(driver, this);
    }
    
    // Page actions
    public void navigateToSchedule() {
        driver.get("https://membership-system.com/schedule");
    }
    
    public boolean isPageLoaded() {
        return wait.until(ExpectedConditions.presenceOfElementLocated(scheduleTable)) != null;
    }
    
    public void selectMembership(Membership membership) {
        WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(membershipDropdown));
        dropdown.sendKeys(membership.getType().