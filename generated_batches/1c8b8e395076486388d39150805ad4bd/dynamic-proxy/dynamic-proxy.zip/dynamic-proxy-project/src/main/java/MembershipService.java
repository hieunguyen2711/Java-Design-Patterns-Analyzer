public interface MembershipService {
    void registerMember(String memberName);
    void cancelMembership(String memberName);
    boolean isMemberActive(String memberName);
}