public class Main {
    public static void main(String[] args) {
        MembershipService membershipService = MembershipServiceProxy.createMembershipService();
        
        membershipService.registerMember("John Doe");
        membershipService.isMemberActive("John Doe");
        membershipService.cancelMembership("John Doe");
    }
}