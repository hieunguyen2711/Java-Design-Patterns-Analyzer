public class MembershipServiceImpl implements MembershipService {
    
    @Override
    public void registerMember(String memberName) {
        System.out.println("Registering member: " + memberName);
    }
    
    @Override
    public void cancelMembership(String memberName) {
        System.out.println("Canceling membership for: " + memberName);
    }
    
    @Override
    public boolean isMemberActive(String memberName) {
        System.out.println("Checking if " + memberName + " is active");
        return true;
    }
}