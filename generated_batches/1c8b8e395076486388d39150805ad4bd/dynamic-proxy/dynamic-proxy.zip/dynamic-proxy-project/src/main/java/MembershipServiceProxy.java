import java.lang.reflect.Proxy;

public class MembershipServiceProxy {
    
    public static MembershipService createMembershipService() {
        MembershipService target = new MembershipServiceImpl();
        return (MembershipService) Proxy.newProxyInstance(
            MembershipService.class.getClassLoader(),
            new Class[]{MembershipService.class},
            new LoggingHandler(target)
        );
    }
}