public class MembershipProxy implements Membership {
    private BasicMembership basicMember;
    private PremiumMembership premiumMember;
    private String memberType;
    private String memberName;
    
    public MembershipProxy(String memberName, String memberType) {
        this.memberName = memberName;
        this.memberType = memberType;
    }
    
    @Override
    public void accessGym() {
        getRealMembership().accessGym();
    }
    
    @Override
    public void bookTrainer(String trainerName) {
        if ("premium".equalsIgnoreCase(memberType)) {