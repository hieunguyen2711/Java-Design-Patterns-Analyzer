public class BasicMembership implements Membership {
    private String memberName;
    
    public BasicMembership(String memberName) {
        this.memberName = memberName;
    }
    
    @Override
    public void accessGym() {
        System.out.println(memberName + " is accessing the gym.");
    }
    
    @Override
    public void bookTrainer(String trainerName) {
        System.out.println(memberName + " is booking trainer: " + trainerName);
    }
    
    @Override
    public void checkAttendance() {
        System.out.println(memberName + " is checking attendance.");
    }
    
    @Override
    public void makePayment(double amount) {
        System.out.println(memberName + " is making payment of $" + amount);
    }
}