public interface Membership {
    void accessGym();
    void bookTrainer(String trainerName);
    void checkAttendance();
    void makePayment(double amount);
}