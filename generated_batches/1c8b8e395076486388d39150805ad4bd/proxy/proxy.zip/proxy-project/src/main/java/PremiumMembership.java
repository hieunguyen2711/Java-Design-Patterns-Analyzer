public class PremiumMembership implements Membership {
    private String memberName;
    
    public PremiumMembership(String memberName) {
        this.memberName = memberName;
    }
    
    @Override
    public void accessGym() {
        System.out.println(memberName + " is accessing the premium gym with special facilities.");
    }
    
    @Override
    public void bookTrainer(String trainerName) {
        System.out.println(memberName + " is booking premium trainer: " + trainerName);
    }
    
    @Override
    public void checkAttendance() {
        System.out.println(memberName + " is checking attendance with detailed report.");
    }
    
    @Override
    public void makePayment(double amount) {
        System.out.println(memberName + " is making premium payment of $" + amount);
    }
}