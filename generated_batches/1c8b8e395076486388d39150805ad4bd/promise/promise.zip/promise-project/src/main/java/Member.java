package com.example.membership;

public class Member {
    private final String name;
    private Membership membership;
    
    public Member(String name) {
        this.name = name;
    }
    
    public void setMembership(Membership membership) {
        this.membership = membership;
    }
    
    public Membership getMembership() {
        return membership;
    }
    
    public String getName() {
        return name;
    }
}