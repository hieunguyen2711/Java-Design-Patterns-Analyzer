package com.example.membership;

public interface Membership {
    String getMembershipType();
    double getMonthlyFee();
    boolean isActive();
}