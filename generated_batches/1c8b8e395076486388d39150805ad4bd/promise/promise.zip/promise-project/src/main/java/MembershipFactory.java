package com.example.membership;

public class MembershipFactory {
    public static Membership createMembership(String type) {
        switch (type.toLowerCase()) {
            case "basic":
                return new BasicMembership();
            case "premium":
                return new PremiumMembership();
            default:
                throw new IllegalArgumentException("Unknown membership type: " + type);
        }
    }
}