package com.example.membership;

import java.util.concurrent.CompletableFuture;

public class PaymentProcessor {
    public CompletableFuture<Double> processPayment(Membership membership) {