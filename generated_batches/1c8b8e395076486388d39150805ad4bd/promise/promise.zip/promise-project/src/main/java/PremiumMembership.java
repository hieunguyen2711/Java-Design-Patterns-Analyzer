package com.example.membership;

public class PremiumMembership implements Membership {
    private final String type = "Premium";
    private final double fee = 79.99;
    private boolean active = true;
    
    @Override
    public String getMembershipType() {
        return type;
    }
    
    @Override
    public double getMonthlyFee() {
        return fee;
    }
    
    @Override
    public boolean isActive() {
        return active;
    }
    
    public void deactivate() {
        this.active = false;
    }
}