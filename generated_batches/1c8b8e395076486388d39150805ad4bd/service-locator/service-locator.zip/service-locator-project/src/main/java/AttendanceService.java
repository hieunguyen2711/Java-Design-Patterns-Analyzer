public interface AttendanceService {
    void checkIn(String memberId, String classId);
    boolean isPresent(String memberId, String classId);
}