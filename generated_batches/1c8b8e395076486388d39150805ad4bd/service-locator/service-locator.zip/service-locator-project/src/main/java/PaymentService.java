public interface PaymentService {
    void processPayment(String memberId, double amount);
    boolean validatePayment(String transactionId);
}