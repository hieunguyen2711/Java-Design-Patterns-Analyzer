public class ScheduleServiceImpl implements ScheduleService {
    @Override
    public void updateSchedule(String classId, String timeSlot) {
        System.out.println("Schedule updated for class " + classId + " at " + timeSlot);
    }

    @Override
    public String getSchedule(String classId) {
        return "Class " + classId + "