public interface MembershipService {
    void registerMember(String memberName);
    boolean validateMembership(String memberId);
}