public class MembershipServiceImpl implements MembershipService {
    @Override
    public void registerMember(String memberName) {
        System.out.println("Membership registered for: " + memberName);
    }

    @Override
    public boolean validateMembership(String memberId) {
        return memberId != null && !memberId.isEmpty();
    }
}