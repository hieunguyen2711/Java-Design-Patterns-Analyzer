public class ServiceLocator {
    private static ServiceLocator instance;
    private Map<String, Object> services;

    private ServiceLocator() {
        services = new HashMap<>();
        loadServices();
    }

    public static synchronized ServiceLocator getInstance() {
        if (instance == null) {
            instance = new ServiceLocator();
        }
        return instance;
    }

    private void loadServices() {
        services.put("MembershipService", new MembershipServiceImpl());
        services.put("ScheduleService", new ScheduleServiceImpl());
        services.put("TrainerService", new TrainerServiceImpl());
        services.put("AttendanceService", new AttendanceServiceImpl());
        services.put("PaymentService", new PaymentServiceImpl());
    }

    public Object getService(String serviceName) {
        return services.get(serviceName);
    }
}