public interface TrainerService {
    void bookTrainer(String trainerId, String memberId);
    boolean isAvailable(String trainerId);
}