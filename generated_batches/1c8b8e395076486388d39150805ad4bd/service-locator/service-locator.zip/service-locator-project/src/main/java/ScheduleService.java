public interface ScheduleService {
    void updateSchedule(String classId, String timeSlot);
    String getSchedule(String classId);
}