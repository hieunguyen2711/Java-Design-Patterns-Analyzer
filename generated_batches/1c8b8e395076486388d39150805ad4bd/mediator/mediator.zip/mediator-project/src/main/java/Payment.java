public class Payment {
    private String paymentId;
    private String memberId;
    private double amount;
    
    public Payment(String paymentId, String memberId, double amount) {
        this.paymentId = paymentId;
        this.memberId = memberId;
        this.amount = amount;