public class Trainer {
    private String trainerId;
    private String name;
    
    public Trainer(String trainerId, String name) {
        this.trainerId = trainerId;
        this.name = name;
    }
    
    // Getters and setters
    public String getTrainerId() { return trainerId; }
    public void setTrainerId(String trainerId) { this.trainerId = trainerId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
}