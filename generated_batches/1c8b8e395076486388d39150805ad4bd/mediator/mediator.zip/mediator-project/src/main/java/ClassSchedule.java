public class ClassSchedule {
    private String classId;
    private String className;
    private String timeSlot;
    
    public ClassSchedule(String classId, String className, String timeSlot) {
        this.classId = classId;
        this.className = className;
        this.timeSlot = timeSlot;
    }
    
    // Getters and setters
    public String getClassId() { return classId; }
    public void setClassId(String classId) { this.classId = classId; }
    public String getClassName() { return className; }
    public void setClassName(String className) { this.className = className; }
    public String getTimeSlot() { return timeSlot; }
    public void setTimeSlot(String timeSlot) { this.timeSlot = timeSlot; }
}