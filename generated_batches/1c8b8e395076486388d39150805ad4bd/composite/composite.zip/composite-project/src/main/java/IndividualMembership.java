public class IndividualMembership extends Membership {
    
    public IndividualMembership(String name) {
        super(name);
    }
    
    @Override
    public double calculateCost() {
        return 50.0;
    }
    
    @Override
    public void display() {
        System.out.println("Individual Membership: " + name);
    }
}