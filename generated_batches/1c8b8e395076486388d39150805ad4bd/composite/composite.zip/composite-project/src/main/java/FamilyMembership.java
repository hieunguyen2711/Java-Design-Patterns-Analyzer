public class FamilyMembership extends Membership {
    
    private java.util.List<Membership> members;
    
    public FamilyMembership(String name) {
        super(name);
        this.members = new java.util.ArrayList<>();
    }
    
    public void addMember(Membership member) {
        members.add(member);
    }
    
    public void removeMember(Membership member) {
        members.remove(member);
    }
    
    @Override
    public double calculateCost() {
        double total = 0;
        for (Membership member : members) {
            total += member.calculateCost();
        }
        return total * 0.8; // 20% discount for family plan
    }
    
    @Override
    public void display() {
        System.out.println("Family Membership: " + name);
        for (Membership member : members) {
            member.display();
        }
    }
}