public abstract class Membership {
    protected String name;
    
    public Membership(String name) {
        this.name = name;
    }
    
    public abstract double calculateCost();
    public abstract void display();
}