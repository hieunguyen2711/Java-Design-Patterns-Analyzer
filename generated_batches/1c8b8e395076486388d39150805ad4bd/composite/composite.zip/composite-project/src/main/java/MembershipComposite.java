import java.util.ArrayList;
import java.util.List;

public class MembershipComposite extends Membership {
    private List<Membership> memberships;
    
    public MembershipComposite(String name) {
        super(name);
        this.memberships = new ArrayList<>();
    }
    
    public void add(Membership membership) {
        memberships.add(membership);
    }
    
    public void remove(Membership membership) {
        memberships.remove(membership);
    }
    
    @Override
    public double calculateCost() {
        double total = 0;
        for (Membership membership : memberships) {
            total += membership.calculateCost();
        }
        return total;
    }
    
    @Override
    public void display() {
        System.out.println("Composite: " + name);
        for (Membership membership : memberships) {
            membership.display();
        }
    }
}