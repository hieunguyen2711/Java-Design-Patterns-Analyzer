package com.membership.system;

import java.util.HashMap;
import java.util.Map;

public class MembershipRepository {
    private static final Map<String, Membership> identityMap = new HashMap<>();
    
    public static Membership findMembershipById(String id) {
        return identityMap.get(id);
    }
    
    public static void saveMembership(Membership membership) {
        identityMap.put(membership.getMemberId(), membership);
    }
    
    public static void clearCache() {
        identityMap.clear();
    }
}