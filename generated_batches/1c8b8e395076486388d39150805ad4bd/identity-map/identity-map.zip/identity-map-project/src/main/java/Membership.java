package com.membership.system;

public class Membership {
    private final String memberId;
    private final String name;
    private final String email;
    
    public Membership(String memberId, String name, String email) {
        this.memberId = memberId;
        this.name = name;
        this.email = email;
    }
    
    public String getMemberId() {
        return memberId;
    }
    
    public String getName() {
        return name;
    }
    
    public String getEmail() {
        return email;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Membership that = (Membership) obj;
        return memberId.equals(that.memberId);
    }
    
    @Override
    public int hashCode() {
        return memberId.hashCode();
    }
}