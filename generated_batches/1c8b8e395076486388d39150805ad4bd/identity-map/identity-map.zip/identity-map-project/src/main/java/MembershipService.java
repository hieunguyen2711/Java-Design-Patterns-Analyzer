package com.membership.system;

public class MembershipService {
    
    public Membership getMembership(String memberId) {
        // First check if membership already exists in cache
        Membership cached = MembershipRepository.findMembershipById(memberId);
        if (cached != null) {
            System.out.println("Retrieved from identity map cache");
            return cached;
        }
        
        // Simulate database lookup
        Membership newMember = createNewMembership(memberId);
        MembershipRepository.saveMembership(newMember);
        System.out.println("Created and stored in identity map");
        return newMember;
    }
    
    private Membership createNewMembership(String memberId) {
        // In a real system, this would query a database
        return new Membership(memberId, "John Doe", "john.doe@example.com");
    }
}