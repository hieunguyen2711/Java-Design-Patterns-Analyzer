package com.gym.membership;

public class MembershipService {
    private PaymentProcessor paymentProcessor;
    
    public MembershipService(PaymentProcessor paymentProcessor) {
        this.paymentProcessor = paymentProcessor;
    }
    
    public boolean processMembershipPayment(double amount) {
        return paymentProcessor.processPayment(amount);
    }
}