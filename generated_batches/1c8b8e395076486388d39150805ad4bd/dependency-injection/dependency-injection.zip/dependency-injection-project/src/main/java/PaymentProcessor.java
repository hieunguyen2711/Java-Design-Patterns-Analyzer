package com.gym.membership;

public interface PaymentProcessor {
    boolean processPayment(double amount);
}