package com.gym.membership;

public class MainApplication {
    public static void main(String[] args) {
        // Dependency injection - injecting different implementations at runtime
        PaymentProcessor creditCardProcessor = new CreditCardProcessor();
        MembershipService membershipService1 = new MembershipService(creditCardProcessor);
        
        PaymentProcessor payPalProcessor = new PayPalProcessor();
        MembershipService membershipService2 = new MembershipService(payPalProcessor);
        
        // Using the services with different payment processors
        membershipService1.processMembershipPayment(99.99);
        membershipService2.processMembershipPayment(149.99);
    }
}