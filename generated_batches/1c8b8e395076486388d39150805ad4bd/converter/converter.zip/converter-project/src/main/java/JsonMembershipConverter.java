package com.membership;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;

public class JsonMembershipConverter implements MembershipConverter {
    private final ObjectMapper objectMapper = new ObjectMapper();
    
    @Override
    public Membership convertToMembership(Object source) {
        if (source instanceof String) {
            try {
                return objectMapper.readValue((String) source, Membership.class);
            } catch (IOException e) {
                throw new RuntimeException("Failed to convert JSON to Membership", e);
            }
        }
        throw new IllegalArgumentException("Unsupported source type for conversion");
    }
    
    @Override
    public Object convertFromMembership(Membership membership) {
        try {
            return objectMapper.writeValueAsString(membership);
        } catch (IOException e) {
            throw new RuntimeException("Failed to convert Membership to JSON", e);
        }
    }
}