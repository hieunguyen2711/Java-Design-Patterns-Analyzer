package com.membership;

public interface MembershipConverter {
    Membership convertToMembership(Object source);
    Object convertFromMembership(Membership membership);
}