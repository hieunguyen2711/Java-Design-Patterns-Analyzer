package com.membership;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.StringReader;
import java.io.StringWriter;

public class XmlMembershipConverter implements MembershipConverter {
    private final JAXBContext jaxbContext;
    
    public XmlMembershipConverter() throws JAXBException {
        this.jaxbContext = JAXBContext.newInstance(Membership.class);
    }
    
    @Override
    public Membership convertToMembership(Object source) {
        if (source instanceof String) {
            try {