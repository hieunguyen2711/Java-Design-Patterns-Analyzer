package com.membership;

public abstract class Membership {
    protected String memberId;
    protected String name;
    protected double monthlyFee;
    
    public Membership(String memberId, String name, double monthlyFee) {
        this.memberId = memberId;
        this.name = name;
        this.monthlyFee = monthlyFee;
    }
    
    public abstract double calculateDiscount();
    
    public void displayMembershipInfo() {
        System.out.println("Member ID: " + memberId);
        System.out.println("Name: " + name);
        System.out.println("Monthly Fee: $" + monthlyFee);
        System.out.println("Discount: $" + calculateDiscount());
    }
}