package com.membership;

public class MembershipFactory {
    
    public static Membership createMembership(String type, String memberId, String name) {
        switch (type.toLowerCase()) {
            case "basic":
                return new BasicMembership(memberId, name);
            case "premium":
                return new PremiumMembership(memberId, name);
            case "vip":
                return new VIPMembership(memberId, name);
            default:
                throw new IllegalArgumentException("Unknown membership type: " + type);
        }
    }
}