package com.membership;

public class VIPMembership extends Membership {
    
    public VIPMembership(String memberId, String name) {
        super(memberId, name, 99.99);
    }
    
    @Override
    public double calculateDiscount() {
        return 25.0;
    }
}