package com.membership;

public class BasicMembership extends Membership {
    
    public BasicMembership(String memberId, String name) {
        super(memberId, name, 29.99);
    }
    
    @Override
    public double calculateDiscount() {
        return 0.0;
    }
}