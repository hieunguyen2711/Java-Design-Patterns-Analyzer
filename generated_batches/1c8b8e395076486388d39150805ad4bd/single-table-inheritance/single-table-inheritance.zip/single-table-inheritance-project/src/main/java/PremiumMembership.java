package com.membership;

public class PremiumMembership extends Membership {
    
    public PremiumMembership(String memberId, String name) {
        super(memberId, name, 59.99);
    }
    
    @Override
    public double calculateDiscount() {
        return 10.0;
    }
}