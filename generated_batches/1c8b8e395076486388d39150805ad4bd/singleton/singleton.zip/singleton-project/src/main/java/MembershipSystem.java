public class MembershipSystem {
    private static MembershipSystem instance;
    
    private MembershipSystem() {
        // Private constructor to prevent instantiation
    }
    
    public static synchronized MembershipSystem getInstance() {
        if (instance == null) {
            instance = new MembershipSystem();
        }
        return instance;
    }
    
    public void registerMember(String memberName) {
        System.out.println("Registered member: " + memberName);
    }
    
    public void scheduleClass(String className, String time) {
        System.out.println("Scheduled class " + className + " at " + time);
    }
    
    public void bookTrainer(String trainerName, String memberName) {
        System.out.println("Booked trainer " + trainerName + " for member " + memberName);
    }
    
    public void checkInMember(String memberName) {
        System.out.println("Checked in member: " + memberName);
    }
    
    public void processPayment(String memberName, double amount) {
        System.out.println("Processed payment of $" + amount + " for member " + memberName);
    }
}