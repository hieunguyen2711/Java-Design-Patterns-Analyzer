public class Main {
    public static void main(String[] args) {
        // Get the singleton instance
        MembershipSystem system1 = MembershipSystem.getInstance();
        
        // Create another reference to the same instance
        MembershipSystem system2 = MembershipSystem.getInstance();
        
        // Verify they are the same instance
        System.out.println("Are instances equal? " + (system1 == system2));
        
        // Use the singleton to perform operations
        system1.registerMember("John Doe");
        system1.scheduleClass("Yoga", "10:00 AM");
        system1.bookTrainer("Jane Smith", "John Doe");
        system1.checkInMember("John Doe");
        system1.processPayment("John Doe", 99.99);
        
        // Show that the second reference works the same way
        system2.registerMember("Jane Doe");
    }
}