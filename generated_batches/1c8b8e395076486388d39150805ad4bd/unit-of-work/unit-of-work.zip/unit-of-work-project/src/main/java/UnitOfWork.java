package com.example.membership;

import java.util.ArrayList;
import java.util.List;

public class UnitOfWork {
    private List<Membership> addedEntities;
    private List<Membership> updatedEntities;
    private List<Membership> deletedEntities;
    private MembershipRepository repository;
    
    public UnitOfWork(MembershipRepository repository) {
        this.repository = repository;
        this.addedEntities = new ArrayList<>();
        this.updatedEntities = new ArrayList<>();
        this.deletedEntities = new ArrayList<>();
    }
    
    public void registerAdded(Membership membership) {
        addedEntities.add(membership);
    }
    
    public void registerUpdated(Membership membership) {
        updatedEntities.add(membership);
    }
    
    public void registerDeleted(Membership membership) {
        deletedEntities