package com.example.membership;

import java.util.ArrayList;
import java.util.List;

public class MembershipRepository {
    private List<Membership> memberships;
    
    public MembershipRepository() {
        this.memberships = new ArrayList<>();
    }
    
    public void save(Membership membership) {
        memberships.add(membership);
    }
    
    public void update(Membership membership) {
        for (int i = 0; i < memberships.size(); i++) {
            if (memberships.get(i).getId() == membership.getId()) {
                memberships.set(i, membership);
                break;
            }
        }
    }
    
    public Membership findById(int id) {
        for (Membership m : memberships) {
            if (m.getId() == id) {
                return m;
            }
        }
        return null;
    }
}