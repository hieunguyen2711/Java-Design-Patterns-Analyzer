package com.example.membership;

public class Main {
    public static void main(String[] args) {
        MembershipService service = new MembershipService();
        Membership membership = new Membership("MEM-001");
        
        // Simulate concurrent access - only one update will succeed
        Thread t1 = new Thread(() -> service.updateMembership(membership));
        Thread t2 = new Thread(() -> service.updateMembership(membership));
        
        t1.start();
        t2.start();
        
        try {
            t1.join();
            t2.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}