package com.example.membership;

public class Membership {
    private String id;
    private long lastUpdated;
    
    public Membership(String id) {
        this.id = id;
    }
    
    public String getId() {
        return id;
    }
    
    public long getLastUpdated() {
        return lastUpdated;
    }
    
    public void setLastUpdated(long lastUpdated) {
        this.lastUpdated = lastUpdated;
    }
}