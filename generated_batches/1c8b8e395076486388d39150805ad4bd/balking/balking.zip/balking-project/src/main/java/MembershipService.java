package com.example.membership;

public class MembershipService {
    private boolean isUpdating = false;
    
    public void updateMembership(Membership membership) {
        if (isUpdating) {
            // Balking - don't allow concurrent updates
            return;
        }
        
        try {
            isUpdating = true;
            // Simulate time-consuming update operation
            Thread.sleep(1000);
            membership.setLastUpdated(System.currentTimeMillis());
            System.out.println("Membership updated: " + membership.getId());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            isUpdating = false;
        }
    }
}