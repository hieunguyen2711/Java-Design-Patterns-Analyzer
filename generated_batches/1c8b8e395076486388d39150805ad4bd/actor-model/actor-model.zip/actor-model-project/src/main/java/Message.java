public class Message {
    private Object content;
    private Actor sender;
    private String type;
    
    public Message(Object content, Actor sender, String type) {
        this.content = content;
        this.sender = sender;
        this.type = type;
    }
    
    public Object getContent() {
        return content;
    }
    
    public Actor getSender() {
        return sender;
    }
    
    public String getType() {
        return type;
    }
}