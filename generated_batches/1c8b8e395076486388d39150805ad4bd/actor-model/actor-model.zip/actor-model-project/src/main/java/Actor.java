public abstract class Actor {
    protected String id;
    protected String name;
    
    public Actor(String id, String name) {
        this.id = id;
        this.name = name;
    }
    
    public abstract void handleMessage(Object message);
    
    public String getId() {
        return id;
    }
    
    public String getName() {
        return name;
    }
}