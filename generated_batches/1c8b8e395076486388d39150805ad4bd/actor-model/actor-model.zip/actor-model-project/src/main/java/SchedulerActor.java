public class SchedulerActor extends Actor {
    private String schedule;
    
    public SchedulerActor(String id, String name) {
        super(id, name);
        this.schedule = "default";
    }
    
    @Override
    public void handleMessage(Object message) {
        if (message instanceof String) {
            String msg = (String) message;
            System.out.println("SchedulerActor " + id + " received: " + msg);
            
            if ("update".equals(msg)) {
                schedule = "updated";
                System.out.println("Schedule updated for class");
            } else if ("view".equals(msg)) {