public class MembershipActor extends Actor {
    private int membershipId;
    private String status;
    
    public MembershipActor(String id, String name) {
        super(id, name);
        this.membershipId = Integer.parseInt(id);
        this.status = "active";
    }
    
    @Override
    public void handleMessage(Object message) {
        if (message instanceof String) {
            String msg = (String) message;
            System.out.println("MembershipActor " + id + " received: " + msg);
            
            if ("cancel".equals(msg)) {
                status = "cancelled";
                System.out.println("Membership " + membershipId + " cancelled");
            } else if ("renew".equals(msg)) {
                status = "active";
                System.out.println("Membership " + membershipId + " renewed");
            }
        }
    }
}