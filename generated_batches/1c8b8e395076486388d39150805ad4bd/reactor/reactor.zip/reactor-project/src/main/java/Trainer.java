public class Trainer {
    private String trainerId;
    private String name;
    
    public Trainer(String trainerId, String name) {
        this.trainerId = trainerId;
        this.name = name;