import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ClassSchedule {
    private String classId;
    private String className;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private List<Membership> enrolledMembers;
    
    public ClassSchedule(String classId, String className, LocalDateTime startTime, LocalDateTime endTime) {
        this.classId = classId;
        this.className = className;
        this.startTime = startTime;
        this.endTime = endTime;
        this.enrolledMembers = new ArrayList<>();
    }
    
    public void enrollMember(Membership member) {
        enrolledMembers.add(member);
    }
    
    // Getters and setters
    public String getClassId() { return classId; }
    public void setClassId(String classId) { this.classId = classId; }
    public String getClassName() { return className; }
    public void setClassName(String className) { this.className = className; }
    public LocalDateTime getStartTime() { return startTime; }
    public void setStartTime(LocalDateTime startTime) { this.startTime = startTime; }
    public LocalDateTime getEndTime() { return endTime; }
    public void setEndTime(LocalDateTime endTime) { this.endTime = endTime; }
    public List<Membership> getEnrolledMembers() { return enrolledMembers; }
}