public interface MembershipState {
    void activate(Membership membership);
    void suspend(Membership membership);
    void cancel(Membership membership);
}