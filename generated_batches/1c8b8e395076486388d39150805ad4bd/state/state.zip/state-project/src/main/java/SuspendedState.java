public class SuspendedState implements MembershipState {
    
    @Override
    public void activate(Membership membership) {
        membership.setState(new ActiveState());
        System.out.println("Membership reactivated");
    }
    
    @Override
    public void suspend(Membership membership) {
        System.out.println("Membership already suspended");
    }
    
    @Override
    public void cancel(Membership membership) {
        membership.setState(new Cancel