public class Membership {
    private String memberId;
    private MembershipState state;
    
    public Membership(String memberId) {
        this.memberId = memberId;
        this.state = new PendingState();
    }
    
    public void setState(MembershipState state) {
        this.state = state;
    }
    
    public void activate() {
        state.activate(this);
    }
    
    public void suspend() {
        state.suspend(this);
    }
    
    public void cancel() {
        state.cancel(this);
    }
    
    public String getMemberId() {
        return memberId;
    }
    
    public MembershipState getState() {
        return state;
    }
}