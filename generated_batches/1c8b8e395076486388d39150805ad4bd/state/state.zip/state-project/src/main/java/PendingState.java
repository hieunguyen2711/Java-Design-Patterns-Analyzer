public class PendingState implements MembershipState {
    
    @Override
    public void activate(Membership membership) {
        membership.setState(new ActiveState());
        System.out.println("Membership activated");
    }
    
    @Override
    public void suspend(Membership membership) {
        System.out.println("Cannot suspend pending membership");
    }
    
    @Override
    public void cancel(Membership membership) {
        membership.setState(new CancelledState());
        System.out.println("Membership cancelled");
    }
}