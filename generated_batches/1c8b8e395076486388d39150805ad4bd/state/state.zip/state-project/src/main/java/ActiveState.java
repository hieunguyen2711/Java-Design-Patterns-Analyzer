public class ActiveState implements MembershipState {
    
    @Override
    public void activate(Membership membership) {
        System.out.println("Membership already active");
    }
    
    @Override
    public void suspend(Membership membership) {
        membership.setState(new SuspendedState());
        System.out.println("Membership suspended");
    }
    
    @Override
    public void cancel(Membership membership) {
        membership.setState(new CancelledState());
        System.out.println("Membership cancelled");
    }
}