package com.membership.system;

import java.util.List;
import java.util.stream.Collectors;

public class ScheduleViewHelper {
    
    public String generateScheduleDisplay(List<TrainingClass> classes) {
        StringBuilder display = new StringBuilder();
        display.append("=== TRAINING SCHEDULE ===\n");
        
        for (TrainingClass cls : classes) {
            display.append(String.format("%s - %s (%s)\n", 
                cls.getName(), 
                cls.getTimeSlot().toString(),
                cls.getTrainer().getName()));
        }
        
        return display.toString();
    }
    
    public String generateMemberScheduleDisplay(List<TrainingClass> classes, Membership member) {
        StringBuilder display = new StringBuilder();
        display.append(String.format("=== %s'S SCHEDULE ===\n", member.getName()));
        
        List<TrainingClass> memberClasses = classes.stream()
            .filter(cls -> cls.getEnrolledMembers().contains(member))
            .collect(Collectors.toList());
            
        for (TrainingClass cls : memberClasses) {
            display.append(String.format("%s - %s (%s)\n", 
                cls.getName(), 
                cls.getTimeSlot().toString(),
                cls.getTrainer().getName()));
        }
        
        return display.toString();
    }
}