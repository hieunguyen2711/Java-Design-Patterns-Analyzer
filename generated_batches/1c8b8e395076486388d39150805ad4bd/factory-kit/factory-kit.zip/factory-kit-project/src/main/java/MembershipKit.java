public class MembershipKit {
    private MembershipFactory factory;
    
    public MembershipKit() {
        this.factory = new MembershipFactory();
    }
    
    public Membership createBasicMembership() {
        return factory.createMembership(MembershipType.BASIC);
    }
    
    public Membership createPremiumMembership() {
        return factory.createMembership(MembershipType.PREMIUM);
    }
    
    public Membership createVipMembership() {
        return factory.create