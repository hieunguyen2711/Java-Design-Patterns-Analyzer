public class MembershipFactory {
    public static Membership createMembership(MembershipType type) {
        switch (type) {
            case BASIC:
                return new BasicMembership();
            case PREMIUM:
                return new PremiumMembership();
            case VIP:
                return new VipMembership();
            default:
                throw new IllegalArgumentException("Unknown membership type: " + type);
        }
    }
}