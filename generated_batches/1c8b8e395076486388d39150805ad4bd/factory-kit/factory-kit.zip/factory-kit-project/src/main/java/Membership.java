public abstract class Membership {
    protected String name;
    protected double price;
    
    public abstract void describe();
    
    public String getName() {
        return name;
    }
    
    public double getPrice() {
        return price;
    }
}