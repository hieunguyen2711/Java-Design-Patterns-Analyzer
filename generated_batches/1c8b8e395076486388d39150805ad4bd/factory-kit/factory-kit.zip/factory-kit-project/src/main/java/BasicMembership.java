public class BasicMembership extends Membership {
    public BasicMembership() {
        this.name = "Basic Membership";
        this.price = 29.99;
    }
    
    @Override
    public void describe() {
        System.out.println("Basic membership with limited access to classes.");
    }
}