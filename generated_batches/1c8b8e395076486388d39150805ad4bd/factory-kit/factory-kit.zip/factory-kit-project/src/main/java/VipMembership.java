public class VipMembership extends Membership {
    public VipMembership() {
        this.name = "VIP Membership";
        this.price = 99.99;
    }
    
    @Override
    public void describe() {
        System.out.println("VIP membership with exclusive access, personal trainer sessions, and priority booking.");
    }
}