package com.membership;

public class BasicMembership extends Membership {
    @Override
    public boolean canAccessTrainer() {
        return false;
    }
    
    @Override
    public boolean canBookClasses() {
        return true;
    }
    
    @Override
    public double getDiscountRate() {
        return 0.0;
    }
}