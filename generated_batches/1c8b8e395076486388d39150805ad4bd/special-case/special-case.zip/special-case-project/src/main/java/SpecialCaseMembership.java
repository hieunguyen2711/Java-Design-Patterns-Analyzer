package com.membership;

public class SpecialCaseMembership extends Membership {
    private final String reason;
    
    public SpecialCaseMembership(String reason) {
        this.reason = reason;
    }
    
    @Override
    public boolean canAccessTrainer() {
        return true;
    }
    
    @Override
    public boolean canBookClasses() {
        return true;
    }
    
    @Override
    public double getDiscountRate() {
        return 0.5;
    }
    
    public String getReason() {
        return reason;
    }
}