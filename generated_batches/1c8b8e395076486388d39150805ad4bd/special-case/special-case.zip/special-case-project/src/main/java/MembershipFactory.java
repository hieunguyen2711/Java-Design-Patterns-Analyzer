package com.membership;

public class MembershipFactory {
    public static Membership createMembership(String type) {
        switch (type.toLowerCase()) {
            case "basic":
                return new BasicMembership();
            case "premium":
                return new PremiumMembership();
            default:
                return new SpecialCaseMembership("Special case membership for exceptional circumstances");
        }
    }
}