package com.membership;

public class PremiumMembership extends Membership {
    @Override
    public boolean canAccessTrainer() {
        return true;
    }
    
    @Override
    public boolean canBookClasses() {
        return true;
    }
    
    @Override
    public double getDiscountRate() {
        return 0.2;
    }
}