package com.membership;

public class Member {
    private final String name;
    private Membership membership;
    
    public Member(String name, Membership membership) {
        this.name = name;
        this.membership = membership;
    }
    
    public void setMembership(Membership membership) {
        this.membership = membership;
    }
    
    public boolean canAccessTrainer()