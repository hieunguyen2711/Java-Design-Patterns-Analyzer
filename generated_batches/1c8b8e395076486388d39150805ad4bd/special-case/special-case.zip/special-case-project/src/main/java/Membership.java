package com.membership;

public abstract class Membership {
    public abstract boolean canAccessTrainer();
    public abstract boolean canBookClasses();
    public abstract double getDiscountRate();
}