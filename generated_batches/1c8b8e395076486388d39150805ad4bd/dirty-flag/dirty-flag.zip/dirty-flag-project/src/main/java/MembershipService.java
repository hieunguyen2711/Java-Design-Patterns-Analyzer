package com.membership;

import java.util.ArrayList;
import java.util.List;

public class MembershipService {
    private List<Membership> memberships;
    
    public MembershipService() {
        this.memberships = new ArrayList<>();
    }
    
    public void addMembership(Membership membership) {
        memberships.add(membership);
    }
    
    public void updateMemberName(String memberId, String newName) {
        for (Membership member : memberships) {
            if (member.getMemberId().equals(memberId)) {
                member.setName(newName);
                break;
            }
        }
    }
    
    public List<Membership> getDirtyMemberships() {
        List<Membership> dirtyMembers = new ArrayList<>();
        for (Membership member : memberships) {
            if (member.isDirty()) {
                dirtyMembers.add(member);
            }
        }
        return dirtyMembers;
    }
    
    public void saveAllDirtyMemberships() {
        for (Membership member : getDirtyMemberships()) {
            // Simulate saving to database
            System.out.println("Saving membership: " + member.getMemberId() + 
                             " with name: " + member.getName());
            member.clearDirtyFlag();
        }
    }
}