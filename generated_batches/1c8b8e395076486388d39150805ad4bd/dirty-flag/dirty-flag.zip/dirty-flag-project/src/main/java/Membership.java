package com.membership;

public class Membership {
    private String memberId;
    private String name;
    private boolean isDirty = false;
    
    public Membership(String memberId, String name) {
        this.memberId = memberId;
        this.name = name;
    }
    
    public String getMemberId() {
        return memberId;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
        setDirty(true);
    }
    
    public boolean isDirty() {
        return isDirty;
    }
    
    public void setDirty(boolean dirty) {
        isDirty = dirty;
    }
    
    public void clearDirtyFlag() {
        isDirty = false;
    }
}