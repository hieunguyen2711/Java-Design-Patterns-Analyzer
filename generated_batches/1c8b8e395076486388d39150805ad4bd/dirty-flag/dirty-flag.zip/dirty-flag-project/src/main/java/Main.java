package com.membership;

public class Main {
    public static void main(String[] args) {
        MembershipService service = new MembershipService();
        
        // Create memberships
        Membership member1 = new Membership("M001", "John Doe");
        Membership member2 = new Membership("M002", "Jane Smith");
        
        service.addMembership(member1);
        service.addMembership(member