public class MembershipManager {
    private static volatile MembershipManager instance;
    
    private MembershipManager() {
        // Private constructor to prevent instantiation
    }
    
    public static MembershipManager getInstance() {
        if (instance == null) {
            synchronized (MembershipManager.class) {
                if (instance == null) {
                    instance = new MembershipManager();
                }
            }
        }
        return instance;
    }
    
    public void processMembership(String memberId) {
        System.out.println("Processing membership for member: " + memberId);
    }
}