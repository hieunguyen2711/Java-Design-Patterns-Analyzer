public class PaymentProcessor {
    private static volatile PaymentProcessor instance;
    
    private PaymentProcessor() {
        // Private constructor to prevent instantiation
    }
    
    public static PaymentProcessor getInstance() {
        if (instance == null) {
            synchronized (PaymentProcessor.class) {
                if (instance == null) {
                    instance = new PaymentProcessor();
                }
            }
        }
        return instance;
    }
    
    public void processPayment(String memberId, double amount) {
        System.out.println("Processing payment of $" + amount + " for member: " + memberId);
    }
}