public class AttendanceTracker {
    private static volatile AttendanceTracker instance;
    
    private AttendanceTracker() {
        // Private constructor to prevent instantiation
    }
    
    public static AttendanceTracker getInstance() {
        if (instance == null) {
            synchronized (AttendanceTracker.class) {
                if (instance == null) {
                    instance = new AttendanceTracker();
                }
            }
        }
        return instance;
    }
    
    public void markAttendance(String memberId, String classId) {
        System.out.println("Marking attendance for member " + memberId + " in class " +