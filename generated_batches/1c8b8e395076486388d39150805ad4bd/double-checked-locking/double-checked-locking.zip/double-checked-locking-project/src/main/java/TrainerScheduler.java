public class TrainerScheduler {
    private static volatile TrainerScheduler instance;
    
    private TrainerScheduler() {
        // Private constructor to prevent instantiation
    }
    
    public static TrainerScheduler getInstance() {
        if (instance == null) {
            synchronized (TrainerScheduler.class) {
                if (instance == null) {
                    instance = new TrainerScheduler();
                }
            }
        }
        return instance;
    }
    
    public void scheduleClass(String trainerId, String classTime) {
        System.out.println("Scheduling class for trainer " + trainerId + " at " + classTime);
    }
}