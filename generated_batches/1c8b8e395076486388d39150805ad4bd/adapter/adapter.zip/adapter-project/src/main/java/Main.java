public class Main {
    public static void main(String[] args) {
        StripePaymentService stripeService = new StripePaymentService();
        PaymentProcessor adapter = new PaymentAdapter(stripeService);
        MembershipSystem system = new MembershipSystem(adapter);
        
        boolean success = system.enrollMember(99.99);
        System.out.println("Enrollment " + (success ? "successful" : "failed"));
    }
}