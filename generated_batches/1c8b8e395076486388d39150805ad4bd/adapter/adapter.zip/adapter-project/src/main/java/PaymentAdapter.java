public class PaymentAdapter implements PaymentProcessor {
    private StripePaymentService stripeService;
    
    public PaymentAdapter(StripePaymentService stripeService) {
        this.stripeService = stripeService;
    }
    
    @Override
    public boolean processPayment(double amount) {
        return stripeService.chargeCustomer("customer_123", amount);
    }
}