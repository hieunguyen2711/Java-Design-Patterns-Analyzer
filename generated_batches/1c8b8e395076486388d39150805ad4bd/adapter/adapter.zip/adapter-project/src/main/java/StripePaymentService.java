public class StripePaymentService {
    public boolean chargeCustomer(String customerId, double amount) {
        // Simulate stripe payment processing
        System.out.println("Processing $" + amount + " through Stripe for customer " + customerId);
        return true;
    }
}