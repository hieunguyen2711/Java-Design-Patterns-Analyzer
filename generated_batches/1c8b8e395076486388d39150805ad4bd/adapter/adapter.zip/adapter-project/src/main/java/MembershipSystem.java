public class MembershipSystem {
    private PaymentProcessor paymentProcessor;
    
    public MembershipSystem(PaymentProcessor paymentProcessor) {
        this.paymentProcessor = paymentProcessor;
    }
    
    public boolean enrollMember(double fee) {
        System.out.println("Enrolling member with fee: $" + fee);
        return paymentProcessor.processPayment(fee);
    }
}