public class Membership {
    private String memberId;
    private String name;
    private boolean isActive;

    public Membership(String memberId, String name) {
        this.memberId = memberId;
        this.name = name;
        this.isActive = true;
    }

    // Getters and setters
    public String getMemberId() { return memberId; }
    public String getName() { return name; }
    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }
}