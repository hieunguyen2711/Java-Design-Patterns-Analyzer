import java.time.LocalDateTime;

public class Schedule {
    private String scheduleId;
    private Course course;
    private Trainer trainer;
    private LocalDateTime dateTime;

    public Schedule(String scheduleId, Course course, Trainer trainer, LocalDateTime dateTime) {
        this.scheduleId = scheduleId;
        this.course = course;
        this.trainer = trainer;
        this.dateTime = dateTime;
    }

    // Getters and setters
    public String getScheduleId() { return scheduleId; }
    public Course getCourse() { return course; }
    public Trainer getTrainer() { return trainer; }
    public LocalDateTime getDateTime() { return dateTime; }
}