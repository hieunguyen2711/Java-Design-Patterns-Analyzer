public class Course {
    private String courseId;
    private String title;
    private int maxCapacity;

    public Course(String courseId, String title, int maxCapacity) {
        this.courseId = courseId;
        this.title = title;
        this.maxCapacity = maxCapacity;
    }

    // Getters and setters
    public String getCourseId() { return courseId; }
    public String getTitle() { return title; }
    public int getMaxCapacity() { return maxCapacity; }
}