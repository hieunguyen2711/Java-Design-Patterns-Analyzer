import java.time.LocalDateTime;

public class AttendanceRecord {
    private String recordId;
    private String memberId;
    private String scheduleId;
    private LocalDateTime checkInTime;
    private boolean isCheckedIn;

    public AttendanceRecord(String recordId, String