public class ScheduleClassCommand implements Command {
    private String className;
    private String timeSlot;
    private MembershipManager manager;
    
    public ScheduleClassCommand(String className, String timeSlot, MembershipManager manager) {
        this.className = className;
        this.timeSlot = timeSlot;
        this.manager = manager;
    }
    
    @Override
    public void execute() {
        System.out.println("Scheduling class: " + className + " at " + timeSlot);
        // In a real implementation, this would update the schedule system
    }
}