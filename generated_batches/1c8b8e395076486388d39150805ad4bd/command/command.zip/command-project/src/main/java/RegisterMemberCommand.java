public class RegisterMemberCommand implements Command {
    private String memberName;
    private MembershipManager manager;
    
    public RegisterMemberCommand(String memberName, MembershipManager manager) {
        this.memberName = memberName;
        this.manager = manager;
    }
    
    @Override
    public void execute() {
        System.out.println("Registering new member: " + memberName);
        // In a real implementation, this would interact with a database
    }
}