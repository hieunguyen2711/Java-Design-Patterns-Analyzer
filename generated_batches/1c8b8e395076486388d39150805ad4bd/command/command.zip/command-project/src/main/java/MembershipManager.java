import java.util.ArrayList;
import java.util.List;

public class MembershipManager {
    private List<Command> commandHistory = new ArrayList<>();
    
    public void executeCommand(Command command) {
        command.execute();
        commandHistory.add(command);
    }
    
    public void undoLastCommand() {
        if (!commandHistory.isEmpty()) {
            Command lastCommand = commandHistory.remove(commandHistory.size() - 1);
            // In a real implementation, we would need to track undo operations
            System.out.println("Command undone: " + lastCommand.getClass().getSimpleName());
        }
    }
}