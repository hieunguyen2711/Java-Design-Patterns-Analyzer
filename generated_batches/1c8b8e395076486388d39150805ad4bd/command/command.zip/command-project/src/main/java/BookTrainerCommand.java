public class BookTrainerCommand implements Command {
    private String trainerName;
    private String memberName;
    private MembershipManager manager;
    
    public BookTrainerCommand(String trainerName, String memberName, MembershipManager manager) {
        this.trainerName = trainerName;
        this.memberName = memberName;
        this.manager = manager;
    }
    
    @Override
    public void execute() {
        System.out.println("Booking trainer " + trainerName + " for member " + memberName);
        // In a real implementation, this would handle booking logic