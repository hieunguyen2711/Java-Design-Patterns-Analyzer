public class Member {
    private String name;
    private Membership membership;
    
    public Member(String name, Membership membership) {
        this.name = name;
        this.membership = membership != null ? membership : new NullMembership();
    }
    
    public String getName() {
        return name;
    }
    
    public Membership getMembership() {
        return membership;
    }
}