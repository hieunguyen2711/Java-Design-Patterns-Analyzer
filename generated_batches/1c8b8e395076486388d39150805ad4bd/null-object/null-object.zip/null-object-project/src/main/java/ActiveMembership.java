public class ActiveMembership extends Membership {
    private String type;
    private double fee;
    
    public ActiveMembership(String type, double fee) {
        this.type = type;
        this.fee = fee;
    }
    
    @Override
    public boolean isActive() {
        return true;
    }
    
    @Override
    public String getMembershipType() {
        return type;
    }
    
    @Override
    public double getMonthlyFee() {
        return fee;
    }
}