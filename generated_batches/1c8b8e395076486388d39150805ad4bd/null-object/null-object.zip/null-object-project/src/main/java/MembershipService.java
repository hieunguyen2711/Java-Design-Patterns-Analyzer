public class MembershipService {
    public static Membership findMembership(String memberId) {
        // Simulate database lookup
        if ("valid-member".equals(memberId)) {
            return new ActiveMembership("Premium", 99.99);
        }
        return null; // This would normally be a null return from DB
    }
    
    public static Member getMember(String memberId) {
        Membership membership = findMembership(memberId);
        return new Member(memberId, membership);
    }
}