public class Main {
    public static void main(String[] args) {
        // Test with valid member
        Member member1 = MembershipService.getMember("valid-member");
        System.out.println("Member: " + member1.getName());
        System.out.println("Membership Type: " + member1.getMembership().getMembershipType());
        System.out.println("Is Active