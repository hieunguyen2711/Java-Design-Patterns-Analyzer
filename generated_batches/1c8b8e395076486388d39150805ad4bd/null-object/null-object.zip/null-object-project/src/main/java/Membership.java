public abstract class Membership {
    public abstract boolean isActive();
    public abstract String getMembershipType();
    public abstract double getMonthlyFee();
}