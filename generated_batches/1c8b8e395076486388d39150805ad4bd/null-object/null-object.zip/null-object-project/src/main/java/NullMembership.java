public class NullMembership extends Membership {
    
    @Override
    public boolean isActive() {
        return false;
    }
    
    @Override
    public String getMembershipType() {
        return "No membership";
    }
    
    @Override
    public double getMonthlyFee() {
        return 0.0;
    }
}