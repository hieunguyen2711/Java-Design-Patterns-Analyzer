package com.membership;

public class GoldMembership implements Membership {
    private final String memberId;
    private final String name;
    
    public GoldMembership(String memberId, String name) {
        this.memberId = memberId;
        this.name = name;
    }
    
    @Override
    public String getMemberId() {
        return memberId;
    }
    
    @Override
    public String getName() {
        return name;
    }
    
    @Override
    public boolean isActive() {
        return true;
    }
}