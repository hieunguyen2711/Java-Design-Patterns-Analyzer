package com.membership;

import java.util.ArrayList;
import java.util.List;

public class MembershipService {
    private final List<Membership> memberships = new ArrayList<>();
    
    public void addMembership(Membership membership) {
        memberships.add(membership);
    }
    
    public boolean isGoldMember(Membership membership) {
        return membership instanceof GoldMembership;
    }
    
    public List<Membership> getAllMemberships() {
        return new ArrayList<>(memberships);
    }
}