package com.membership;

public interface Membership {
    String getMemberId();
    String getName();
    boolean isActive();
}