package com.membership;

public class Membership {
    private String memberId;
    private String name;
    private boolean isActive;
    
    public Membership(String memberId, String name) {
        this.memberId = memberId;
        this.name = name;
        this.isActive = false;
    }
    
    public void activate() {
        this.isActive = true;
    }
    
    public boolean isActive() {
        return isActive;
    }
    
    public String getMemberId() {
        return memberId;
    }
    
    public String getName() {
        return name;
    }
}