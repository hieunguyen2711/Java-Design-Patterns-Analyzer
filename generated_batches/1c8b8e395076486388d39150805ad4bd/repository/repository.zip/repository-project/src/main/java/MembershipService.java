import java.util.List;
import java.util.Optional;

public class MembershipService {
    private final MembershipRepository repository;
    
    public MembershipService(MembershipRepository repository) {
        this.repository = repository;
    }
    
    public Membership createMembership(String name, String email