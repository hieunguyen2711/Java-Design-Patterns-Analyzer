import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class InMemoryMembershipRepository implements MembershipRepository {
    private final Map<Integer, Membership> memberships = new ConcurrentHashMap<>();
    private int nextId = 1;
    
    @Override
    public Membership save(Membership membership) {
        if (membership.getId() == 0) {
            membership.setId(nextId++);
        }
        memberships.put(membership.getId(), membership);
        return membership;
    }
    
    @Override
    public Optional<Membership> findById(int id) {
        return Optional.ofNullable(memberships.get(id));
    }
    
    @Override
    public List<Membership> findAll() {
        return new ArrayList<>(memberships.values());
    }
    
    @Override
    public void deleteById(int id) {
        memberships.remove(id);
    }
}