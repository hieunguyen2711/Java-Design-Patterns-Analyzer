public class Membership {
    private int id;
    private String memberName;
    private String email;
    private String membershipType;
    
    public Membership(int id, String memberName, String email, String membershipType) {
        this.id = id;
        this.memberName = memberName;
        this.email = email;
        this.membershipType = membershipType;
    }
    
    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getMemberName() { return memberName; }
    public void setMemberName(String memberName) { this.memberName = memberName; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public String getMembershipType() { return membershipType; }
    public void setMembershipType(String membershipType) { this.membershipType = membershipType; }
}