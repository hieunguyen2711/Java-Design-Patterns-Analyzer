import java.util.*;

public interface MembershipRepository {
    Membership save(Membership membership);
    Optional<Membership> findById(int id);
    List<Membership> findAll();
    void deleteById(int id);
}