package com.membership;

import java.util.function.Function;
import java.util.function.Predicate;

public class PaymentService {
    
    public static void main(String[] args) {
        // Function composition example for payment processing
        Membership membership = new Membership("M001", "John Doe", MembershipType.PREMIUM);
        
        // Compose functions to create a complex payment validation and processing pipeline
        Function<Membership, Boolean> validateAndProcessPayment = 
            compose(
                PaymentService::validateMembership,
                PaymentService::processPaymentWithFee
            );
        
        boolean result = validateAndProcessPayment.apply(membership);
        System.out.println("Payment processed: " + result);
    }
    
    // Simple validation function
    public static Boolean validateMembership(Membership membership) {
        return membership != null && membership.getMemberId() != null;
    }
    
    // Payment processing with fee calculation
    public static Boolean processPaymentWithFee(Membership membership) {
        if (membership == null) return false;
        
        double baseAmount = 0;
        switch (membership.getType()) {
            case BASIC: baseAmount = 10.0; break;
            case PREMIUM: baseAmount = 25.0; break;
            case VIP: baseAmount = 50.0; break;
        }
        
        // Add processing fee
        double totalAmount = baseAmount * 1.05; // 5% fee
        
        return new PaymentProcessor() {
            @Override