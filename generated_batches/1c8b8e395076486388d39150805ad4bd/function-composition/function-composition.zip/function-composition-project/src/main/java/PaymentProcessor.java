package com.membership;

@FunctionalInterface
public interface PaymentProcessor {
    boolean processPayment(Membership membership, double amount);
}