public class MembershipInterpreter {
    public static void main(String[] args) {
        MembershipContext context = new MembershipContext();
        
        // Basic membership interpretation
        context.setMembership(new BasicMembership());
        System.out.println("Basic member eligible: " + context.checkEligibility("basic"));
        System.out.println("Premium member eligible: " + context.checkEligibility("premium"));
        
        // Premium membership interpretation
        context.setMembership(new PremiumMembership());
        System.out.println("Basic member eligible: " + context.checkEligibility("basic"));
        System.out.println("Premium member eligible: " + context.checkEligibility("premium"));
    }
}