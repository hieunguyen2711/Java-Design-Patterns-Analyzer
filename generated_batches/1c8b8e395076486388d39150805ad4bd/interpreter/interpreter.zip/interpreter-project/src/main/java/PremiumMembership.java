public class PremiumMembership implements Membership {
    @Override
    public boolean isEligible(String memberType) {
        return "premium".equalsIgnoreCase(memberType);
    }
}