public interface Membership {
    boolean isEligible(String memberType);
}