public class BasicMembership implements Membership {
    @Override
    public boolean isEligible(String memberType) {
        return "basic".equalsIgnoreCase(memberType);
    }
}