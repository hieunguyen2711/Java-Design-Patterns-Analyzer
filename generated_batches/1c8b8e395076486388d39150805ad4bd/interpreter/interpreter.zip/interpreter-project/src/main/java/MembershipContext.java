public class MembershipContext {
    private Membership membership;
    
    public void setMembership(Membership membership) {
        this.membership = membership;
    }
    
    public boolean checkEligibility(String memberType) {
        return membership.isEligible(memberType);
    }
}