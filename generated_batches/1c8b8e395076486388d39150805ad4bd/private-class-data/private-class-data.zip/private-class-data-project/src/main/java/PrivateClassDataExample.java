package com.membership;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class PrivateClassDataExample {
    
    public static void main(String[] args) {
        // Demonstrating private-class-data pattern with Membership objects
        List<Membership> memberships = new ArrayList<>();
        
        memberships.add(new Membership("M001", "John Doe", LocalDate.now().minusDays(30), MembershipType.PREMIUM));
        memberships.add(new Membership("M002", "Jane Smith", LocalDate.now().minusDays(15), MembershipType.BASIC));
        memberships.add(new Membership("M003", "Bob Johnson", LocalDate.now().minusDays(45), MembershipType.VIP));
        
        // Accessing data through public methods - private fields are encapsulated
        for (Membership membership : memberships) {
            System.out.println("Member: " + membership.getName() + 
                             ", ID: " + membership.getMemberId() +
                             ", Type: " + membership.getType());
        }
    }
}