package com.membership;

import java.time.LocalDate;
import java.util.Objects;

public final class Membership {
    private final String memberId;
    private final String name;
    private final LocalDate startDate;
    private final MembershipType type;
    
    public Membership(String memberId, String name, LocalDate startDate, MembershipType type) {
        this.memberId = Objects.requireNonNull(memberId);
        this.name = Objects.requireNonNull(name);
        this.startDate = Objects.requireNonNull(startDate);
        this.type = Objects.requireNonNull(type);
    }
    
    public String getMemberId() {
        return memberId;
    }
    
    public String getName() {
        return name;
    }
    
    public LocalDate getStartDate() {
        return startDate;
    }
    
    public MembershipType getType() {
        return type;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Membership that = (Membership) o;
        return Objects.equals(memberId, that.memberId);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(memberId);
    }
}