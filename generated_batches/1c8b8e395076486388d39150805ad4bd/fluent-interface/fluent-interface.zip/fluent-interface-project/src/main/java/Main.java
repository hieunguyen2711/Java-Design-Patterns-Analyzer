package com.membership;

public class Main {
    public static void main(String[] args) {
        // Using fluent interface to create a membership
        Membership premiumMember = new MembershipBuilder("John Doe")
            .withMembershipType("Premium")
            .withMonthlyFee(150)
            .activate()
            .build();
            
        System.out.println("Member: " + premiumMember.getMemberName());
        System.out.println("Type: " + premiumMember.getMembershipType());
        System.out.println("Fee: $" + premiumMember.getMonthlyFee());
        System.out.println("Active: " + premiumMember.isActive());
    }
}