package com.membership;

public class Membership {
    private String memberName;
    private String membershipType;
    private int monthlyFee;
    private boolean isActive;
    
    public Membership(String memberName) {
        this.memberName = memberName;
    }
    
    public Membership setMembershipType(String membershipType) {
        this.membershipType = membershipType;
        return this;
    }
    
    public Membership setMonthlyFee(int monthlyFee) {
        this.monthlyFee = monthlyFee;
        return this;
    }
    
    public Membership activate() {
        this.isActive = true;
        return this;
    }
    
    public Membership deactivate() {
        this.isActive = false;
        return this;
    }
    
    // Getters
    public String getMemberName() { return memberName; }
    public String getMembershipType() { return membershipType; }
    public int getMonthlyFee() { return monthlyFee; }
    public boolean isActive() { return isActive; }
}