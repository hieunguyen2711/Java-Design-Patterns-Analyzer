package com.membership;

public class MembershipBuilder {
    private Membership membership;
    
    public MembershipBuilder(String memberName) {
        this.membership = new Membership(memberName);
    }
    
    public MembershipBuilder withMembershipType(String type) {
        membership.setMembershipType(type);
        return this;
    }
    
    public MembershipBuilder withMonthlyFee(int fee) {
        membership.setMonthlyFee(fee);
        return this;
    }
    
    public MembershipBuilder activate() {
        membership.activate();
        return this;
    }
    
    public Membership build() {
        return membership;
    }
}