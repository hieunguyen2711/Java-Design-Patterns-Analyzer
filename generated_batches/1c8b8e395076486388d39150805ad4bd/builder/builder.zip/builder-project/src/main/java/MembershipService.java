public class MembershipService {
    public static void main(String[] args) {
        // Using the builder pattern to create membership objects
        Membership premiumMember = new Membership.Builder()
                .setMemberId("MEM-001")
                .setName("John Doe")
                .setEmail("john.doe@example.com")
                .setMembershipType("Premium")
                .setActive(true)
                .build();
        
        Membership basicMember = new Membership.Builder()
                .setMemberId("MEM-002")
                .setName("Jane Smith")
                .setEmail("jane.smith@example.com")
                .setMembershipType("Basic")
                .build();
        
        System.out.println("Created membership: " + premiumMember.getName() + 
                          " with type: " + premiumMember.getMembershipType());