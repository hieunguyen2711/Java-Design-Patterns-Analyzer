public class Trainer {
    private String trainerId;
    private String name;
    private String specialty;
    
    public Trainer(String trainerId, String name, String specialty) {
        this.trainerId = trainerId;
        this.name = name;
        this.specialty = specialty;
    }
    
    public String getTrainerId() {
        return trainerId;
    }
    
    public String getName() {
        return name;
    }
    
    public String getSpecialty() {
        return specialty;
    }
}