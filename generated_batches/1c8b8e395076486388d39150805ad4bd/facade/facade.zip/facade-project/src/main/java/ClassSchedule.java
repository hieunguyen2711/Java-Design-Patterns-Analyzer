import java.time.LocalDateTime;

public class ClassSchedule {
    private String className;
    private LocalDateTime dateTime;
    private int maxCapacity;
    
    public ClassSchedule(String className, LocalDateTime dateTime, int maxCapacity) {
        this.className = className;
        this.dateTime = dateTime;
        this.maxCapacity = maxCapacity;
    }
    
    public String getClassName() {
        return className;
    }
    
    public LocalDateTime getDateTime() {
        return dateTime;
    }
    
    public int getMaxCapacity() {
        return maxCapacity;
    }
}