import java.time.LocalDateTime;

public class Attendance {
    private String memberId;
    private String className;
    private LocalDateTime checkInTime;
    
    public Attendance(String memberId, String className, LocalDateTime checkInTime) {
        this.memberId = memberId;
        this.className = className;
        this.checkInTime = checkInTime;
    }
    
    public String getMemberId() {
        return memberId;
    }
    
    public String getClassName() {
        return className;
    }
    
    public LocalDateTime getCheckInTime() {
        return checkInTime;
    }
}