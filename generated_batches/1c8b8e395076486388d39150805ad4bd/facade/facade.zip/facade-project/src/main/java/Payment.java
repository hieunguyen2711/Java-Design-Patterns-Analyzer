import java.math.BigDecimal;
import java.time.LocalDateTime;

public class Payment {
    private String memberId;
    private BigDecimal amount;
    private LocalDateTime paymentDate;
    private String