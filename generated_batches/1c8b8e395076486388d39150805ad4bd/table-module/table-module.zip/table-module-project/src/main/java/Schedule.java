package com.example.schedule;

import java.time.LocalDateTime;
import java.util.List;

public class Schedule {
    private String scheduleId;
    private String className;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private List<String> trainerIds;
    
    public Schedule(String scheduleId, String className, LocalDateTime startTime, 
                   LocalDateTime endTime, List<String> trainerIds) {
        this.scheduleId = scheduleId;
        this.className = className;
        this.startTime = startTime;
        this.endTime = endTime;
        this.trainerIds = trainerIds;
    }
    
    // Getters and setters
    public String getScheduleId() { return scheduleId; }
    public void setScheduleId(String scheduleId) { this.scheduleId = scheduleId; }
    
    public String getClassName() { return className; }
    public void setClassName(String className) { this.className = className; }
    
    public LocalDateTime getStartTime() { return startTime; }
    public void setStartTime(LocalDateTime startTime) { this.startTime = startTime; }
    
    public LocalDateTime getEndTime() { return endTime; }
    public void setEndTime(LocalDateTime endTime) { this.endTime = endTime; }
    
    public List<String> getTrainerIds() { return trainerIds; }
    public void setTrainerIds(List<String> trainerIds) { this.trainerIds = trainerIds; }
}