package com.example.trainer;

import java.util.List;

public class Trainer {