public class MembershipService {
    private MembershipFactory factory;
    
    public MembershipService(MembershipFactory factory) {
        this.factory = factory;
    }
    
    public void displayMembershipInfo() {
        Membership membership = factory.createMembership();
        System.out.println("Membership Type: " + membership.getMembershipType());
        System.out.println("Monthly Fee: $" + membership.getMonthlyFee());
        System.out.println("Factory Used: " + factory.getFactoryName());
    }
}