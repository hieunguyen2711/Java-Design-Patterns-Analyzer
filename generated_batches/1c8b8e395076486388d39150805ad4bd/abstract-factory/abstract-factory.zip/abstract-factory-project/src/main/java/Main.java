public class Main {
    public static void main(String[] args) {
        // Using Basic Membership Factory
        MembershipService basicService = new MembershipService(new BasicMembershipFactory());
        basicService.displayMembershipInfo();
        
        System.out.println();
        
        // Using Premium Membership Factory
        MembershipService premiumService = new MembershipService(new PremiumMembershipFactory());
        premiumService.displayMembershipInfo();
    }
}