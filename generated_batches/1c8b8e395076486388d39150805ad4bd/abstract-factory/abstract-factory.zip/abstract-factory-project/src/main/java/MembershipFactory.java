public interface MembershipFactory {
    Membership createMembership();
    String getFactoryName();
}