public class BasicMembershipFactory implements MembershipFactory {
    @Override
    public Membership createMembership() {
        return new BasicMembership();
    }
    
    @Override
    public String getFactoryName() {
        return "Basic Membership Factory";
    }
}