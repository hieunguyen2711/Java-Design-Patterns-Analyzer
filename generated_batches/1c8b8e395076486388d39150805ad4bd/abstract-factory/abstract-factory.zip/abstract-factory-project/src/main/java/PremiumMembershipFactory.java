public class PremiumMembershipFactory implements MembershipFactory {
    @Override
    public Membership createMembership() {
        return new PremiumMembership();
    }
    
    @Override
    public String getFactoryName() {
        return "Premium Membership Factory";
    }
}