package com.membership;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Membership {
    private String memberId;
    private String name;
    private LocalDate startDate;
    private List<String> classesAttended;
    
    public Membership(String memberId, String name) {
        this.memberId = memberId;
        this.name = name;
        this.startDate = LocalDate.now();
        this.classesAttended = new ArrayList<>();
    }
    
    public void attendClass(String className) {
        classesAttended.add(className);
    }
    
    public Memento saveToMemento() {
        return new Memento(memberId, name, startDate, new ArrayList<>(classesAttended));
    }
    
    public void restoreFromMemento(Memento memento) {
        this.memberId = memento.getMemberId();
        this.name = memento.getName();
        this.startDate = memento.getStartDate();
        this.classesAttended = new ArrayList<>(memento.getClassesAttended());
    }
    
    // Getters
    public String getMemberId() { return memberId; }
    public String getName() { return name; }
    public LocalDate getStartDate() { return startDate; }
    public List<String> getClassesAttended() { return new ArrayList<>(classesAttended); }
}