package com.membership;

import java.util.ArrayList;
import java.util.List;

public class MembershipCareTaker {
    private final List<Memento> mementos;
    
    public MembershipCareTaker() {
        this.mementos = new ArrayList<>();
    }
    
    public void