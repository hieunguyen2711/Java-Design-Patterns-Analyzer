package com.membership;

import java.time.LocalDate;
import java.util.List;

public class Memento {
    private final String memberId;
    private final String name;
    private final LocalDate startDate;
    private final List<String> classesAttended;
    
    public Memento(String memberId, String name, LocalDate startDate, List<String> classesAttended) {
        this.memberId = memberId;
        this.name = name;
        this.startDate = startDate;
        this.classesAttended = classesAttended;
    }
    
    // Getters
    public String getMemberId() { return memberId; }
    public String getName() { return name; }
    public LocalDate getStartDate() { return startDate; }
    public List<String> getClassesAttended() { return classesAttended; }
}