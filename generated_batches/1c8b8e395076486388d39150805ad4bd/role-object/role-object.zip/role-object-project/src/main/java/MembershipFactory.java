package com.example.membership;

public class MembershipFactory {
    public static RoleObject createMembership(String type) {
        switch (type.toLowerCase()) {
            case "basic":
                return new RoleObject(new BasicMembership());
            case "premium":
                return new RoleObject(new PremiumMembership());
            default:
                throw new IllegalArgumentException("Unknown membership type: " + type);
        }
    }
}