package com.example.membership;

public class RoleObject {
    private Membership membership;
    
    public RoleObject(Membership membership) {
        this.membership = membership;
    }
    
    public String getMembershipType() {
        return membership.getMembershipType();
    }
    
    public double getMonthlyFee() {
        return membership.getMonthlyFee();
    }
    
    public boolean canAccessTrainer() {
        return membership.canAccessTrainer();
    }
}