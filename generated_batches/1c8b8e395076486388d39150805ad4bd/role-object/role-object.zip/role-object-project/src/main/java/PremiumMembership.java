package com.example.membership;

public class PremiumMembership implements Membership {
    @Override
    public String getMembershipType() {
        return "Premium";
    }
    
    @Override
    public double getMonthlyFee() {
        return 79.99;
    }
    
    @Override
    public boolean canAccessTrainer() {
        return true;
    }
}