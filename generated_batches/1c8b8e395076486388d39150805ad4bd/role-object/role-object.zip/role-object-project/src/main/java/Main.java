package com.example.membership;

public class Main {
    public static void main(String[] args) {
        RoleObject basicMember = MembershipFactory.createMembership("basic");
        RoleObject premiumMember = MembershipFactory.createMembership("premium");
        
        System.out.println("Basic Member - Type: " + basicMember.getMembershipType() 
                          + ", Fee: $" + basicMember.getMonthlyFee()
                          + ", Trainer Access: " + basic