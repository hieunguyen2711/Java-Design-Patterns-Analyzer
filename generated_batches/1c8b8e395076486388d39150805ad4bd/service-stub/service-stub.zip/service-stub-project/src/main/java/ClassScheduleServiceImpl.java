package com.example.schedule;

import java.util.Arrays;
import java.util.List;

public class ClassScheduleServiceImpl implements ClassScheduleService {
    @Override
    public List<String> getAvailableClasses() {
        return Arrays.asList("Yoga", "Spinning", "Swimming", "Weight Training");
    }

    @Override
    public void bookClass(String className, String userId) {
        System.out.println("Booking class " + className + " for user " + userId);
    }
}