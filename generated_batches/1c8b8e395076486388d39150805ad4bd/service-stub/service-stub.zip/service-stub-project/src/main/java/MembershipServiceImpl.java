package com.example.membership;

public class MembershipServiceImpl implements MembershipService {
    @Override
    public boolean validateMembership(String userId) {
        // Simulate membership validation logic
        return userId != null && userId.length() > 3;
    }

    @Override
    public void updateMembershipStatus(String userId, String status) {
        System.out.println("Updating membership status for user " + userId + " to " + status);
    }
}