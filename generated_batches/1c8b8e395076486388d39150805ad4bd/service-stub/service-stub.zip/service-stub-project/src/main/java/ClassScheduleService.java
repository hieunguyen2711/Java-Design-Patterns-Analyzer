package com.example.schedule;

import java.util.List;

public interface ClassScheduleService {
    List<String> getAvailableClasses();
    void bookClass(String className, String userId);
}