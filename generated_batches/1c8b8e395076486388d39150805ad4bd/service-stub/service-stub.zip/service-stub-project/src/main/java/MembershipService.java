package com.example.membership;

public interface MembershipService {
    boolean validateMembership(String userId);
    void updateMembershipStatus(String userId, String status);
}