package com.example.schedule;

import java.util.Arrays;
import java.util.List;

public class ClassScheduleServiceStub implements ClassScheduleService {
    @Override
    public List<String> getAvailableClasses() {
        // Stub implementation - returns predefined classes
        return Arrays.asList("Yoga", "Spinning");
    }

    @Override
    public void bookClass(String className, String userId) {
        // Stub implementation - does nothing
        System.out.println("Stub: