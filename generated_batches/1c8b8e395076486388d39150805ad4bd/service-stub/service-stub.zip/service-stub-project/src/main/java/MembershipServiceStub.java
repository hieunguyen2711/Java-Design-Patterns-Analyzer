package com.example.membership;

public class MembershipServiceStub implements MembershipService {
    @Override
    public boolean validateMembership(String userId) {
        // Stub implementation - always returns true for testing
        return true;
    }

    @Override
    public void updateMembershipStatus(String userId, String status) {
        // Stub implementation - does nothing
        System.out.println("Stub: Membership status updated for user " + userId);
    }
}