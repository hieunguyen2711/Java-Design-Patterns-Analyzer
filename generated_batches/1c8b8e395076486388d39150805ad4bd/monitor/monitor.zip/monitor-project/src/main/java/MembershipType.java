package com.gym.membership;

public enum MembershipType {
    BASIC,
    PREMIUM,
    VIP
}