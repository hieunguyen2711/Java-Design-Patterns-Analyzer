package com.gym.schedule;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class ScheduleManager {
    private final Map<String, List<TrainingClass>> schedule = new ConcurrentHashMap<>();
    private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
    
    public void addClass(String day, TrainingClass trainingClass) {
        lock.writeLock().lock();
        try {
            schedule.computeIfAbsent(day, k -> new ArrayList<>()).add(trainingClass);
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    public List<TrainingClass> getClassesForDay(String day) {
        lock.readLock().lock();
        try {
            return new ArrayList<>(schedule.getOrDefault(day, Collections.emptyList()));
        } finally {
            lock.readLock().unlock();
        }
    }
}