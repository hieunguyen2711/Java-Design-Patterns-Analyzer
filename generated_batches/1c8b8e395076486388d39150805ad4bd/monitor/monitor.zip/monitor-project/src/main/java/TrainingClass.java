package com.gym.schedule;

import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class TrainingClass {
    private String className;
    private LocalDateTime dateTime;
    private List<String> enrolledMembers;
    private int maxCapacity;
    
    public TrainingClass(String className, LocalDateTime dateTime, int maxCapacity) {
        this.className = className;
        this.dateTime = dateTime;
        this.maxCapacity = maxCapacity;
        this.enrolledMembers = new CopyOnWriteArrayList<>();
    }
    
    public boolean enrollMember(String memberId) {
        if (enrolledMembers.size() < maxCapacity && !enrolledMembers.contains(memberId)) {
            enrolledMembers.add(memberId);
            return true;
        }
        return false;
    }
    
    public String getClassName