package com.example.membership;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

public class Main {
    public static void main(String[] args) {
        MembershipRepository repository = new MembershipRepository();
        
        // Add sample memberships
        repository.addMembership(new Membership("1", "Basic Plan", 50.0));
        repository.addMembership(new Membership("2", "Premium Plan", 150.0));
        repository.addMembership(new Membership("3", "VIP Plan", 200.0));
        
        // Collection-pipeline pattern demonstration
        Collection<Membership> premiumMemberships = repository.findPremiumMemberships();
        List<String> membershipNames = repository.getMembershipNames();
        Optional<Membership> foundMembership = repository.findMembershipById("2");
        double totalRevenue = repository.getTotalRevenue