package com.example.membership;

public class Membership {
    private String id;
    private String name;
    private double monthlyFee;
    
    public Membership(String id, String name, double monthlyFee) {
        this.id = id;
        this.name = name;
        this.monthlyFee = monthlyFee;
    }
    
    public String getId() { return id; }
    public String getName() { return name; }
    public double getMonthlyFee() { return monthlyFee; }
}