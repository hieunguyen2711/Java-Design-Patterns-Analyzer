package com.example.membership;

import java.util.*;
import java.util.stream.Collectors;

public class MembershipRepository {
    private List<Membership> memberships;
    
    public MembershipRepository() {
        this.memberships = new ArrayList<>();
    }
    
    public void addMembership(Membership membership) {
        memberships.add(membership);
    }
    
    public Collection<Membership> findPremiumMemberships() {
        return memberships.stream()
                .filter(m -> m.getMonthlyFee() > 100)
                .collect(Collectors.toList());
    }
    
    public List<String> getMembershipNames() {
        return memberships.stream()
                .map(Membership::getName)
                .collect(Collectors.toList());
    }
    
    public Optional<Membership> findMembershipById(String id) {
        return memberships.stream()
                .filter(m -> m.getId().equals(id))
                .findFirst();
    }
    
    public double getTotalRevenue() {
        return memberships.stream()
                .mapToDouble(Membership::getMonthlyFee)
                .sum();
    }
}