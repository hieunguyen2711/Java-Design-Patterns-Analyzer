package com.gym.service;

import com.gym.membership.Membership;
import java.util.List;

public class AttendanceService {
    
    public void checkIn(Membership member) {
        System.out.println(member.getName() + " checked in");
    }
    
    public void viewAttendanceHistory(Membership member) {
        System.out.println("Viewing attendance history for " + member.getName());
    }
}