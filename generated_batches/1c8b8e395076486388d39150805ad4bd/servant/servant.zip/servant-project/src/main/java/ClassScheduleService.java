package com.gym.service;

import com.gym.membership.Membership;
import java.util.List;

public class ClassScheduleService {
    
    public void viewSchedule(Membership member) {
        System.out.println("Viewing schedule for " + member.getName());
        // Servant pattern: this service acts as a servant to the membership
        // by providing schedule information without being directly tied to it
    }
    
    public void enrollInClass(Membership member, String className) {
        System.out.println(member.getName() + " enrolled in " + className);
    }
}