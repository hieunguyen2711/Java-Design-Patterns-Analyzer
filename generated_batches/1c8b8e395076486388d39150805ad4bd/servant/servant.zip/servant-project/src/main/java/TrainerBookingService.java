package com.gym.service;

import com.gym.membership.Membership;
import java.util.List;

public class TrainerBookingService {
    
    public void bookTrainer(Membership member, String trainerName) {
        System.out.println(member.getName() + " booked trainer " + trainerName);
    }
    
    public void viewBookings(Membership member) {
        System.out.println("Viewing bookings for " + member.getName());
    }
}