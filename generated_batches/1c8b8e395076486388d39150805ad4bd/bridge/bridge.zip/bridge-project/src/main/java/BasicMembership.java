public class BasicMembership extends Membership {
    
    public BasicMembership(PaymentProcessor paymentProcessor) {
        super(paymentProcessor);
    }
    
    @Override
    public void joinMembership() {
        System.out.println("Joined Basic Membership");
    }
}