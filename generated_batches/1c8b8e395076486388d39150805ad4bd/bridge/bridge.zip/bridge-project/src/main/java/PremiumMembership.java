public class PremiumMembership extends Membership {
    
    public PremiumMembership(PaymentProcessor paymentProcessor) {
        super(paymentProcessor);
    }
    
    @Override
    public void joinMembership() {
        System.out.println("Joined Premium Membership");
    }
}