public class PayPalProcessor extends PaymentProcessor {
    
    @Override
    public void processPayment(double amount) {
        System.out.println("Processing $" + amount + " via PayPal");
    }
}