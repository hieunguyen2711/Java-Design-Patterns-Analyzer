public class MembershipSystem {
    public static void main(String[] args) {
        // Using bridge pattern to separate membership types from payment methods
        Membership basicWithCredit = new BasicMembership(new CreditCardProcessor());
        Membership premiumWithPayPal = new PremiumMembership(new PayPalProcessor());
        
        basicWithCredit.joinMembership();
        basicWithCredit.processPayment(29.99);
        
        premiumWithPayPal.joinMembership();
        premiumWithPayPal.processPayment(79.99);
    }
}