public abstract class Membership {
    protected PaymentProcessor paymentProcessor;
    
    public Membership(PaymentProcessor paymentProcessor) {
        this.paymentProcessor = paymentProcessor;
    }
    
    public abstract void joinMembership();
    
    public void processPayment(double amount) {
        paymentProcessor.processPayment(amount);
    }
}