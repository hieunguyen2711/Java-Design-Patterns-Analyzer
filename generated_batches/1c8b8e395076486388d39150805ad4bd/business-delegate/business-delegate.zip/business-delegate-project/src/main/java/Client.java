public class Client {
    public static void main(String[] args) {
        BusinessDelegate delegate = new BusinessDelegate();
        
        delegate.handleMembershipRequest("MEM001");
        delegate.handleTrainerBookingRequest("TRN001", "2023-12-01 18:00");
        delegate.handlePaymentRequest("MEM001", 99.99);
    }
}