public class TrainerServiceImpl implements TrainerService {
    @Override
    public void bookTrainer(String trainerId, String classTime) {
        System.out.println("Booking trainer: " + trainerId + " for class at: " + classTime);
    }
}