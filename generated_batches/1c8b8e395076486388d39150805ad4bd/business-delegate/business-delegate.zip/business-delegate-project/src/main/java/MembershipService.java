public interface MembershipService {
    void processMembership(String memberId);
}