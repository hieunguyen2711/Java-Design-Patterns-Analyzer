public interface TrainerService {
    void bookTrainer(String trainerId, String classTime);
}