public class MembershipServiceImpl implements MembershipService {
    @Override
    public void processMembership(String memberId) {
        System.out.println("Processing membership for member: " + memberId);
    }
}