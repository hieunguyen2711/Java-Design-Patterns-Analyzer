public class PaymentServiceImpl implements PaymentService {
    @Override
    public void processPayment(String memberId, double amount) {
        System.out.println("Processing payment of $" + amount + " for member: " + memberId);
    }
}