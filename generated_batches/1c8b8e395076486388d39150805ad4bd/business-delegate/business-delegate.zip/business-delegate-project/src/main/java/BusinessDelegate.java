public class BusinessDelegate {
    private MembershipService membershipService;
    private TrainerService trainerService;
    private PaymentService paymentService;
    
    public void handleMembershipRequest(String memberId) {
        membershipService = new MembershipServiceImpl();
        membershipService.processMembership(memberId);
    }
    
    public void handleTrainerBookingRequest(String trainerId, String classTime) {
        trainerService = new TrainerServiceImpl();
        trainerService.bookTrainer(trainerId, classTime);
    }
    
    public void handlePaymentRequest(String memberId, double amount) {
        paymentService = new PaymentServiceImpl();
        paymentService.processPayment(memberId, amount);
    }
}