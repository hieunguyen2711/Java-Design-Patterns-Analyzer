public class PremiumMembership extends Membership {
    public PremiumMembership() {
        this.name = "Premium Membership";
        this.price = 59.99;
    }
    
    @Override
    public void describe() {
        System.out.println("Premium membership with full access and additional benefits.");
    }
}