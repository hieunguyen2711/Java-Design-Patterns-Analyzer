public class Main {
    public static void main(String[] args) {
        Membership basic = MembershipFactory.createMembership(MembershipType.BASIC);
        Membership premium = MembershipFactory.createMembership(MembershipType.PREMIUM);
        Membership vip = MembershipFactory.createMembership(MembershipType.VIP);
        
        basic.describe();
        System.out.println("Price: $" + basic.getPrice());
        
        premium.describe();
        System.out.println("Price: $" + premium.getPrice());
        
        vip