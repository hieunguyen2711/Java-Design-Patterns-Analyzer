public class CreditCardProcessor extends PaymentProcessor {
    private static final double MAX_AMOUNT = 1000.0;
    
    @Override
    protected boolean canProcess(double amount) {
        return amount <= MAX_AMOUNT;
    }
    
    @Override
    protected void doProcess(double amount) {
        System.out.println("Processing $" + amount + " via Credit Card");
    }
}