public abstract class PaymentProcessor {
    protected PaymentProcessor next;
    
    public void setNext(PaymentProcessor processor) {
        this.next = processor;
    }
    
    public void processPayment(double amount) {
        if (canProcess(amount)) {
            doProcess(amount);
        } else if (next != null) {
            next.processPayment(amount);
        } else {
            System.out.println("No payment processor available for amount: $" + amount);
        }
    }
    
    protected abstract boolean canProcess(double amount);
    protected abstract void doProcess(double amount);
}