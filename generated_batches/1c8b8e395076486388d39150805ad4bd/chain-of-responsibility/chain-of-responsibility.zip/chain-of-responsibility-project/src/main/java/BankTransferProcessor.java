public class BankTransferProcessor extends PaymentProcessor {
    private static final double MIN_AMOUNT = 5000.0;
    
    @Override
    protected boolean canProcess(double amount) {
        return amount >= MIN_AMOUNT;
    }
    
    @Override
    protected void doProcess(double amount) {
        System.out.println("Processing $" + amount + " via Bank Transfer");
    }
}