public class PaymentSystem {
    private PaymentProcessor processorChain;
    
    public PaymentSystem() {
        initializeChain();
    }
    
    private void initializeChain() {
        PaymentProcessor creditCard = new CreditCardProcessor();
        PaymentProcessor payPal = new PayPalProcessor();
        PaymentProcessor bankTransfer = new BankTransferProcessor();
        
        creditCard.setNext(payPal);
        payPal.setNext(bankTransfer);
        
        processorChain = creditCard;
    }
    
    public void