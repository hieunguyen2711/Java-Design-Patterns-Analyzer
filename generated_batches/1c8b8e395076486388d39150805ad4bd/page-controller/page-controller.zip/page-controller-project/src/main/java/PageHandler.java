package com.membership.system;

public interface PageHandler {
    void handle(Object data);
}