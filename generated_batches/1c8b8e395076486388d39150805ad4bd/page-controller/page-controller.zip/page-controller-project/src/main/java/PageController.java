package com.membership.system;

import java.util.HashMap;
import java.util.Map;

public class PageController {
    private static PageController instance;
    private Map<String, PageHandler> handlers;
    
    private PageController() {
        handlers = new HashMap<>();
        initializeHandlers();
    }
    
    public static PageController getInstance() {
        if (instance == null) {
            instance = new PageController();
        }
        return instance;
    }
    
    private void initializeHandlers() {
        handlers.put("membership", new MembershipPageHandler());
        handlers.put("schedule", new SchedulePageHandler());
        handlers.put("booking", new BookingPageHandler());
        handlers.put("attendance", new AttendancePageHandler());
        handlers.put("payment", new PaymentPageHandler());
    }
    
    public void handleRequest(String page, Object data) {
        PageHandler handler = handlers.get(page);
        if (handler != null) {
            handler.handle(data);
        } else {
            System.out.println("Unknown page: " + page);
        }
    }
}