package com.membership;

public class ScheduleObserver implements Observer {
    private String observerName;
    
    public ScheduleObserver(String observerName) {
        this.observerName = observerName;
    }
    
    @Override
    public void update(String message) {
        System.out.println("Schedule Notification for " + observerName + ": " + message);
    }
}