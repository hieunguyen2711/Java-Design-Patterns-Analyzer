package com.membership;

import java.util.ArrayList;
import java.util.List;

public class Membership {
    private String memberId;
    private String name;
    private List<Observer> observers;
    
    public Membership(String memberId, String name) {
        this.memberId = memberId;
        this.name = name;
        this.observers = new ArrayList<>();
    }
    
    public void addObserver(Observer observer) {
        observers.add(observer);
    }
    
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }
    
    public void notifyObservers(String message) {
        for (Observer observer : observers) {
            observer.update(message);
        }
    }
    
    public String getMemberId() {
        return memberId;
    }
    
    public String getName() {
        return name;
    }
}