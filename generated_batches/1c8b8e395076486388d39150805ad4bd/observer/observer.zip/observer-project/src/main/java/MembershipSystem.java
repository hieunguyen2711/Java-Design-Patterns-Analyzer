package com.membership;

public class MembershipSystem {
    public static void main(String[] args) {
        // Create membership
        Membership membership = new Membership("M001", "John Doe");
        
        // Add observers
        PaymentObserver paymentObserver = new PaymentObserver("Accounting Dept");
        ScheduleObserver scheduleObserver = new ScheduleObserver("Training Coordinator");
        
        membership.addObserver(paymentObserver);
        membership.addObserver(scheduleObserver);
        
        // Notify observers about a change
        membership.notifyObservers("Membership updated with new payment method");
        membership.notifyObservers("New class schedule available for next week");
    }
}