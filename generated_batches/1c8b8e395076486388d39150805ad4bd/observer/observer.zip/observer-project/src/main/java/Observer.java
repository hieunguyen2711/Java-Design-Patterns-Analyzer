package com.membership;

public interface Observer {
    void update(String message);
}