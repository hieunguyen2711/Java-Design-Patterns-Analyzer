package com.membership;

public class PaymentObserver implements Observer {
    private String observerName;
    
    public PaymentObserver(String observerName) {
        this.observerName = observerName;
    }
    
    @Override
    public void update(String message) {
        System.out.println("Payment Notification for " + observerName + ": " + message);
    }
}