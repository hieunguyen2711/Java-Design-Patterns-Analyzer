package com.membership.presenter;

import com.membership.model.Membership;
import com.membership.view.MembershipView;
import com.membership.service.MembershipService;
import java.util.List;

public class MembershipPresenter {
    private MembershipView view;
    private MembershipService service;
    
    public MembershipPresenter(MembershipView view, MembershipService service) {
        this.view = view;
        this.service = service;
    }
    
    public void loadMemberships() {
        List<Membership> memberships = service.getAllMemberships();
        view.displayMemberships(memberships);
    }
    
    public void showMemberDetails(String id) {
        Membership member = service.getMembershipById(id);
        if (member != null) {
            view.showMemberDetails(member);
        } else {
            view.showMessage("Member not found");
        }
    }
    
    public void addNewMember(String name, String email, String membershipType) {
        Membership newMember = new Membership(
            generateId(), 
            name, 
            email, 
            membershipType
        );
        service.addMembership(newMember);
        view.showMessage("Member added successfully