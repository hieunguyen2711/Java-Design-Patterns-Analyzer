package com.membership.view;

import com.membership.model.Membership;
import java.util.List;

public interface MembershipView {
    void displayMemberships(List<Membership> memberships);
    void showMemberDetails(Membership member);
    void showMessage(String message);
    String getInput();
}