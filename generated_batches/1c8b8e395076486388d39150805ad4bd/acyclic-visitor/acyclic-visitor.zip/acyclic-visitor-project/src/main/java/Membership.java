public abstract class Membership {
    public abstract void accept(MembershipVisitor visitor);
}