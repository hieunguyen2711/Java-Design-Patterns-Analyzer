public interface MembershipVisitor {
    void visit(BasicMembership membership);
    void visit(PremiumMembership membership);
}