public class PaymentTrackingVisitor implements MembershipVisitor {
    private double totalPayments = 0.0;
    
    @Override
    public void visit(BasicMembership membership) {
        totalPayments += 50.0; // Basic membership fee
    }
    
    @Override
    public void visit(PremiumMembership membership) {
        totalPayments += 150.0; // Premium membership fee
    }
    
    public double getTotalPayments() {
        return totalPayments;
    }
}