public class AttendanceReportingVisitor implements MembershipVisitor {
    private int basicMembersPresent = 0;
    private int premiumMembersPresent = 0;
    
    @Override
    public void visit(BasicMembership membership) {
        basicMembersPresent++;
    }
    
    @Override
    public void visit(PremiumMembership membership) {
        premiumMembersPresent++;
    }
    
    public String getReport() {
        return "Attendance Report - Basic: " + basicMembersPresent + 
               ", Premium: " + premiumMembersPresent;
    }
}