public class BasicMembership extends Membership {
    private String memberName;
    
    public BasicMembership(String memberName) {
        this.memberName = memberName;
    }
    
    @Override
    public void accept(MembershipVisitor visitor) {
        visitor.visit(this);
    }
    
    public String getMemberName() {
        return memberName;
    }
}