public class PremiumMembership extends Membership {
    private String memberName;
    private int gymAccessLevel;
    
    public PremiumMembership(String memberName, int gymAccessLevel) {
        this.memberName = memberName;
        this.gymAccessLevel = gymAccessLevel;
    }
    
    @Override
    public void accept(MembershipVisitor visitor) {
        visitor.visit(this);
    }
    
    public String getMemberName() {
        return memberName;
    }
    
    public int getGymAccessLevel() {
        return gymAccessLevel;
    }
}