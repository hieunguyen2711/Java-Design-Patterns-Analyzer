public abstract class MembershipDecorator implements Membership {
    protected Membership membership;

    public MembershipDecorator(Membership membership) {
        this.membership = membership;
    }

    @Override
    public double getCost() {
        return membership.getCost();
    }

    @Override
    public String getDescription() {
        return membership.getDescription();
    }
}