public class Main {
    public static void main(String[] args) {
        Membership basicMembership = new BasicMembership();
        System.out.println(basicMembership.getDescription() + " - $" + basicMembership.getCost());

        Membership premiumWithTraining = new PersonalTrainingDecorator(new PremiumMembership());
        System.out.println(premiumWithTraining.getDescription() + " - $" + premiumWithTraining.getCost());

        Membership basicWithClasses = new ClassPassDecorator(new BasicMembership());
        System.out