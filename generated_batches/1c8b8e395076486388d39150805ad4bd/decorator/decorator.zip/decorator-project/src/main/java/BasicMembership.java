public class BasicMembership implements Membership {
    @Override
    public double getCost() {
        return 50.0;
    }

    @Override
    public String getDescription() {
        return "Basic Membership";
    }
}