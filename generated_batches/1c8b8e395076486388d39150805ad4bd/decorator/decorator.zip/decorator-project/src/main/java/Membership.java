public interface Membership {
    double getCost();
    String getDescription();
}