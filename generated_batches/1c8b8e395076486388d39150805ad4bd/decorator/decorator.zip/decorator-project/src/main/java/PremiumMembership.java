public class PremiumMembership implements Membership {
    @Override
    public double getCost() {
        return 100.0;
    }

    @Override
    public String getDescription() {
        return "Premium Membership";
    }
}