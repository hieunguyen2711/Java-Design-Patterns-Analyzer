public class PersonalTrainingDecorator extends MembershipDecorator {
    public PersonalTrainingDecorator(Membership membership) {
        super(membership);
    }

    @Override
    public double getCost() {
        return membership.getCost() + 30.0;
    }

    @Override
    public String getDescription() {
        return membership.getDescription() + " with Personal Training";
    }
}