public class ClassPassDecorator extends MembershipDecorator {
    public ClassPassDecorator(Membership membership) {
        super(membership);
    }

    @Override
    public double getCost() {
        return membership.getCost() + 20.0;
    }

    @Override
    public String getDescription() {
        return membership.getDescription() + " with Class Passes";
    }
}