package membership;

public class PremiumMembership extends Membership {
    
    public PremiumMembership(String name, int id) {
        super(name, id);
    }
    
    @Override
    protected void registerMember() {
        System.out.println("Registering premium member: " + memberName);
    }
    
    @Override
    protected void setupPaymentPlan() {
        System.out.println("Setting up premium payment plan for " + memberName);
    }
    
    @Override
    protected void assignTrainer() {
        System.out.println("Assigning personal trainer to " + memberName);
    }
    
    @Override
    protected void scheduleClasses() {
        System.out.println("Scheduling 5 premium classes per week for " + memberName);
    }
}