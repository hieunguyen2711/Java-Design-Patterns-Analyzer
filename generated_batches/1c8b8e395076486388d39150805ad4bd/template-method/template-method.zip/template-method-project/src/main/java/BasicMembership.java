package membership;

public class BasicMembership extends Membership {
    
    public BasicMembership(String name, int id) {
        super(name, id);
    }
    
    @Override
    protected void registerMember() {
        System.out.println("Registering basic member: " + memberName);
    }
    
    @Override
    protected void setupPaymentPlan() {
        System.out.println("Setting up basic payment plan for " + memberName);
    }
    
    @Override
    protected void assignTrainer() {
        System.out.println("Assigning standard trainer to " + memberName);
    }
    
    @Override
    protected void scheduleClasses() {
        System.out.println("Scheduling 3 basic classes per week for " + memberName);
    }
}