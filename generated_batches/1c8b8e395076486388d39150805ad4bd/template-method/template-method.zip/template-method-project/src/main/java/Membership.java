package membership;

public abstract class Membership {
    protected String memberName;
    protected int memberId;
    
    public Membership(String name, int id) {
        this.memberName = name;
        this.memberId = id;
    }
    
    // Template method
    public final void processMembership() {
        registerMember();
        setupPaymentPlan();
        assignTrainer();
        scheduleClasses();
        System.out.println("Membership processing complete for " + memberName);
    }
    
    protected abstract void registerMember();
    protected abstract void setupPaymentPlan();
    protected abstract void assignTrainer();
    protected abstract void scheduleClasses();
}