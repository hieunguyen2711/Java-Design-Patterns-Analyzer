package membership;

public class MembershipProcessor {
    
    public static void main(String[] args) {
        Membership basicMember = new BasicMembership("John Doe",