public class TrainerBookedEvent extends Event {
    private final String bookingId;
    private final String trainerId;
    private final String classId;

    public TrainerBookedEvent(String eventId, long timestamp, String bookingId, String trainerId, String classId) {
        super(timestamp, eventId);
        this.bookingId = bookingId;
        this.trainerId = trainerId;
        this.classId = classId;
    }

    public String getBookingId() {
        return bookingId;
    }

    public String getTrainerId() {
        return trainerId;
    }

    public String getClassId() {
        return classId;
    }
}