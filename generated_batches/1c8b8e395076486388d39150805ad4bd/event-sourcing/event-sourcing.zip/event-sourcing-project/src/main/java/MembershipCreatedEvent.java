public class MembershipCreatedEvent extends Event {
    private final String memberId;
    private final String memberName;
    private final String membershipType;

    public MembershipCreatedEvent(String eventId, long timestamp, String memberId, String memberName, String membershipType) {
        super(timestamp, eventId);
        this.memberId = memberId;
        this.memberName = memberName;
        this.membershipType = membershipType;
    }

    public String getMemberId() {
        return memberId;
    }

    public String getMemberName() {
        return memberName;
    }

    public String getMembershipType() {
        return membershipType;
    }
}