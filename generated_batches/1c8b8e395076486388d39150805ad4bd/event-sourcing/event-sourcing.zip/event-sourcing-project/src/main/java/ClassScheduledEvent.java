public class ClassScheduledEvent extends Event {
    private final String classId;
    private final String className;
    private final long scheduledTime;

    public ClassScheduledEvent(String eventId, long timestamp, String classId, String className, long scheduledTime) {
        super(timestamp, eventId);
        this.classId = classId;
        this.className = className;
        this.scheduledTime = scheduledTime;
    }

    public String getClassId() {
        return classId;
    }

    public String getClassName() {
        return className;
    }

    public long getScheduledTime() {
        return scheduledTime;
    }
}