public abstract class Event {
    private final long timestamp;
    private final String eventId;

    public Event(long timestamp, String eventId) {
        this.timestamp = timestamp;
        this.eventId = eventId;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public String getEventId() {
        return eventId;
    }
}