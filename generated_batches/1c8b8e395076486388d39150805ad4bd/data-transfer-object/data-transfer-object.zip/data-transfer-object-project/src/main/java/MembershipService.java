package com.example.membership.service;

import com.example.membership.dto.MembershipDTO;
import java.util.ArrayList;
import java.util.List;

public class MembershipService {
    
    public List<MembershipDTO> getActiveMemberships() {
        // Simulate fetching data from database
        List<MembershipDTO> memberships = new ArrayList<>();
        
        memberships.add(new MembershipDTO("M001", "John Smith", "Premium", "2023-01-15", "2024-01-15", 99.99));
        memberships.add(new MembershipDTO("M002", "Jane Doe", "Basic", "2