package com.gym.booking;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class TrainerBookingService {
    private final ExecutorService executorService;
    
    public TrainerBookingService() {
        this