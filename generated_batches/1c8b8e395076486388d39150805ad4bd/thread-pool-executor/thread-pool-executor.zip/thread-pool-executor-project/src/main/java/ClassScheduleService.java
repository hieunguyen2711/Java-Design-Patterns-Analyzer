package com.gym.schedule;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ClassScheduleService {
    private final ExecutorService executorService;
    
    public ClassScheduleService() {
        this.executorService = Executors.newCachedThreadPool();
    }
    
    public void updateClassSchedule(String className, String newTime) {
        executorService.submit(() -> {
            try {
                System.out.println("Updating schedule for class: " + className);
                Thread.sleep(500); // Simulate database update
                System.out.println("Updated class " + className + " to time: " + newTime);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
    }
    
    public void shutdown() {
        executorService.shutdown();
        try {
            if (!executorService.awaitTermination(60, TimeUnit.SECONDS)) {
                executorService.shutdownNow();
            }
        } catch (InterruptedException e) {
            executorService.shutdownNow();
        }
    }
}