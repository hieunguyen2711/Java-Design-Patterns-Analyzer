package com.gym.membership;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class MembershipService {
    private final ExecutorService executorService;
    
    public MembershipService() {
        this.executorService = Executors.newFixedThreadPool(3);
    }
    
    public void processMembershipRequest(String memberId, String action) {
        executorService.submit(() -> {
            try {
                System.out.println("Processing " + action + " for member: " + memberId);
                Thread.sleep(1000); // Simulate processing time
                System.out.println("Completed " + action + " for member: " + memberId);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
    }
    
    public void shutdown() {
        executorService.shutdown();
        try {
            if (!executorService.awaitTermination(60, TimeUnit.SECONDS)) {
                executorService.shutdownNow();
            }
        } catch (InterruptedException e) {
            executorService.shutdownNow();
        }
    }
}