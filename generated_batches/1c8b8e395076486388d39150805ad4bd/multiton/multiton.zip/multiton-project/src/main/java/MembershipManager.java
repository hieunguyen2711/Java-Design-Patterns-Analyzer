public class MembershipManager {
    private static final String[] MEMBERSHIP_TYPES = {"BASIC", "PREMIUM", "VIP"};
    private static final MembershipManager[] INSTANCES = new MembershipManager[3];
    
    private final String membershipType;
    private int activeMembers;
    
    private MembershipManager(String membershipType) {
        this.membershipType = membershipType;
        this.activeMembers = 0;
    }
    
    public static MembershipManager getInstance(String membershipType) {
        int index = -1;
        for (int i = 0; i < MEMBERSHIP_TYPES.length; i++) {
            if (MEMBERSHIP_TYPES[i].equals(membershipType)) {
                index = i;
                break;
            }
        }
        
        if (index == -1) {
            throw new IllegalArgumentException("Invalid membership type: " + membershipType);
        }
        
        if (INSTANCES[index] == null) {
            INSTANCES[index] = new MembershipManager(membershipType);
        }
        
        return INSTANCES[index];
    }
    
    public void addMember() {
        activeMembers++;
        System.out.println("Added member to " + membershipType + " plan. Total: " + activeMembers);
    }
    
    public int getActiveMembers() {
        return activeMembers;
    }
    
    public String getMembershipType() {
        return membershipType;
    }
}