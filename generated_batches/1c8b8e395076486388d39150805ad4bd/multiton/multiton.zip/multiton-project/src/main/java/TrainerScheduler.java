public class TrainerScheduler {
    private static final String[] TRAINER_LEVELS = {"JUNIOR", "SENIOR", "MASTER"};
    private static final TrainerScheduler[] INSTANCES = new TrainerScheduler[3];
    
    private final String trainerLevel;
    private int scheduledClasses;
    
    private TrainerScheduler(String trainerLevel) {
        this.trainerLevel = trainerLevel;
        this.scheduledClasses = 0;
    }
    
    public static TrainerScheduler getInstance(String trainerLevel) {
        int index = -1;
        for (int i = 0; i < TRAINER_LEVELS.length; i++) {
            if (TRAINER_LEVELS[i].equals(trainerLevel)) {
                index = i;
                break;
            }
        }
        
        if (index == -1) {
            throw new IllegalArgumentException("Invalid trainer level: " + trainerLevel);
        }
        
        if (INSTANCES[index] == null) {
            INSTANCES[index] = new TrainerScheduler