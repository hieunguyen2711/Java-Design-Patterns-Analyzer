public interface Membership {
    String getMembershipType();
    double getMonthlyFee();
}