import java.util.*;

public class MembershipCombinator {
    public static Membership combine(Membership m1, Membership m2) {
        return new Membership() {
            @Override
            public String getMembershipType() {
                return m1.getMembershipType() + "+" + m2.getMembershipType();
            }
            
            @Override
            public double getMonthlyFee() {
                return m1.getMonthlyFee() + m2.getMonthlyFee();
            }
        };
    }
    
    public static Membership combine(List<Membership> memberships) {
        if (memberships == null || memberships.isEmpty()) {
            throw new IllegalArgumentException("Memberships list cannot be null or empty");
        }
        
        return memberships.stream()
                .reduce((m1, m2) -> combine(m1, m2))
                .orElseThrow();
    }
}