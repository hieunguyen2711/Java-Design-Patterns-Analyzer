public class PremiumMembership implements Membership {
    @Override
    public String getMembershipType() {
        return "Premium";
    }
    
    @Override
    public double getMonthlyFee() {
        return 59.99;
    }
}