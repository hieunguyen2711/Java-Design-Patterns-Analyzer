import java.util.*;

public class Main {
    public static void main(String[] args) {
        Membership basic = new BasicMembership();
        Membership premium = new PremiumMembership();
        
        // Combine two memberships
        Membership combined = MembershipCombinator.combine(basic, premium);
        System.out.println("Combined membership: " + combined.getMembershipType() 
                          + " - Fee: $" + combined.getMonthlyFee());
        
        // Combine multiple memberships
        List<Membership> memberships = Arrays.asList(
            new BasicMembership(),
            new PremiumMembership()
        );
        
        Membership multiCombined = MembershipCombinator.combine(memberships);
        System.out.println("Multi-combined membership: " + multiCombined.getMembershipType() 
                          + " - Fee: $" + multiCombined.getMonthlyFee());