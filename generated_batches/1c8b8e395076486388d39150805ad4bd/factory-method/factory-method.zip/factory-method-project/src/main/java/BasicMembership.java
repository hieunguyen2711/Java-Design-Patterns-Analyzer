public class BasicMembership extends Membership {
    
    public BasicMembership() {
        super("Basic", 29.99);
    }
    
    @Override
    public void showBenefits() {
        System.out.println("Basic Membership Benefits:");
        System.out.println("- Access to gym facilities");
        System.out.println("- Basic workout equipment");
        System.out.println("- 1 free personal training session per month");
    }
}