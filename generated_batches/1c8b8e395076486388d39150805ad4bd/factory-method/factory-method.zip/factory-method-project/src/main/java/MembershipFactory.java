public abstract class MembershipFactory {
    
    public abstract Membership createMembership();
    
    public Membership getMembership(String membershipType) {
        Membership membership = null;
        
        if ("basic".equalsIgnoreCase(membershipType)) {
            membership = new BasicMembership();
        } else if ("premium".equalsIgnoreCase(membershipType)) {
            membership