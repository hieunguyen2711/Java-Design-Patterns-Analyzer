public class VIPMembership extends Membership {
    
    public VIPMembership() {
        super("VIP", 149.99);
    }
    
    @Override
    public void showBenefits() {
        System.out.println("VIP Membership Benefits:");
        System.out.println("- All Premium benefits");
        System.out.println("- Personal trainer for every workout session");
        System.out.println("- Private locker room access");
        System.out.println("- Priority booking for classes and trainers");
        System.out.println("- Monthly wellness consultation");
        System.out.println("- Complimentary spa access");
    }
}