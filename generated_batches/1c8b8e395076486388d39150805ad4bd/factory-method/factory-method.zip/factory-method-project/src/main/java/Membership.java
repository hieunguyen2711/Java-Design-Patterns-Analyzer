public abstract class Membership {
    protected String membershipType;
    protected double price;
    
    public Membership(String membershipType, double price) {
        this.membershipType = membershipType;
        this.price = price;
    }
    
    public abstract void showBenefits();
    
    public String getMembershipType() {
        return membershipType;
    }
    
    public double getPrice() {
        return price;
    }
}