public class PremiumMembership extends Membership {
    
    public PremiumMembership() {
        super("Premium", 79.99);
    }
    
    @Override
    public void showBenefits() {
        System.out.println("Premium Membership Benefits:");
        System.out.println("- Full gym access 24/7");
        System.out.println("- All workout equipment");
        System.out.println("- Unlimited personal training sessions");
        System.out.println("- Access to exclusive classes");
        System.out.println("- Nutrition consultation");
    }
}