package com.example.membership;

import java.util.*;

public class AttendanceTracker {
    private static volatile AttendanceTracker instance;
    private Map<String, List<Date>> attendanceRecords;
    
    private AttendanceTracker() {
        this.attendanceRecords = new HashMap<>();
    }
    
    public static AttendanceTracker getInstance() {
        if (instance == null) {
            synchronized (AttendanceTracker.class) {
                if (instance == null) {
                    instance = new AttendanceTracker();
                }
            }
        }
        return instance;
    }
    
    public void markAttendance(String memberId, Date date) {
        attendanceRecords.computeIfAbsent(memberId, k -> new ArrayList<>()).add(date);
        System.out.println("Marked attendance for member: " + memberId + " on " + date);
    }
    
    public List<Date> getAttendanceRecord(String memberId) {
        return attendanceRecords.getOrDefault(memberId, new ArrayList<>());
    }
}