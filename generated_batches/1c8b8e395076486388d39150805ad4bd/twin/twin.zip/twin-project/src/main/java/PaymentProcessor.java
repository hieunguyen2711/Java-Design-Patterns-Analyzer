package com.example.membership;

public class PaymentProcessor {
    private static volatile PaymentProcessor instance;
    
    private PaymentProcessor() {}
    
    public static PaymentProcessor getInstance() {
        if (instance == null) {
            synchronized (PaymentProcessor.class) {
                if (instance == null) {
                    instance = new PaymentProcessor();
                }
            }
        }
        return instance;
    }
    
    public void processPayment(Membership membership, double amount) {
        System.out.println("Processing payment of $" + amount + " for member: " + membership.getName());
    }
}