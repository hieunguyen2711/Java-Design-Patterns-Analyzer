package com.example.membership;

public class Trainer {
    private String trainerId;
    private String name;
    private