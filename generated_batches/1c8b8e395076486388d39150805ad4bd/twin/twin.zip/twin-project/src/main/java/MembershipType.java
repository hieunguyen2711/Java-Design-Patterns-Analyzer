package com.example.membership;

public enum MembershipType {
    BASIC,
    PREMIUM,
    VIP
}