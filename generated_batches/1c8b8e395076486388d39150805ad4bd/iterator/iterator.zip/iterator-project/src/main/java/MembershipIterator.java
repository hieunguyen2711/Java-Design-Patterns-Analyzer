import java.util.Iterator;

public interface MembershipIterator extends Iterator<Membership> {
    boolean hasNext();
    Membership next();
    void remove();
}