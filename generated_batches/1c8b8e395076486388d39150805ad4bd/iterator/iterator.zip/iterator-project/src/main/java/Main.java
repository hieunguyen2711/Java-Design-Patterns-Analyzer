public class Main {
    public static void main(String[] args) {
        MembershipCollection collection = new MembershipCollection();
        
        collection.addMembership(new Membership("M001", "John Doe", "john@example.com"));
        collection.addMembership(new Membership("M002", "Jane Smith", "jane@example.com"));