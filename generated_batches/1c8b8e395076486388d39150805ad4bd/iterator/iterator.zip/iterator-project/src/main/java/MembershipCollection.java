import java.util.ArrayList;
import java.util.List;

public class MembershipCollection {
    private List<Membership> memberships;
    
    public MembershipCollection() {
        this.memberships = new ArrayList<>();
    }
    
    public void addMembership(Membership membership) {
        memberships.add(membership);
    }
    
    public MembershipIterator createIterator() {
        return new MembershipIteratorImpl(memberships);
    }
    
    private class MembershipIteratorImpl implements MembershipIterator {
        private List<Membership> memberships;
        private int position = 0;
        
        public MembershipIteratorImpl(List<Membership> memberships) {
            this.memberships = memberships;
        }
        
        @Override
        public boolean hasNext() {
            return position < memberships.size();
        }
        
        @Override
        public Membership next() {
            if (!hasNext()) {
                throw new RuntimeException("No more elements");
            }
            return memberships.get(position++);
        }
        
        @Override
        public void remove() {
            if (position <= 0) {
                throw new IllegalStateException("remove() called before next()");
            }
            memberships.remove(--position);
        }
    }
}