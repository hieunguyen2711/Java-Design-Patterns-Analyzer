package com.example.membership;

import java.time.LocalDateTime;
import java.util.Objects;

public final class ScheduleEntry {
    private final String classId;
    private final String className;
    private final LocalDateTime startTime;
    private final LocalDateTime endTime;
    private final String trainerName;
    
    public ScheduleEntry(String classId, String className, LocalDateTime startTime, 
                        LocalDateTime endTime, String trainerName) {
        this.classId = classId;
        this.className = className;
        this.startTime = startTime;
        this.endTime = endTime;
        this.trainerName = trainerName;
    }
    
    public String getClassId() {
        return classId;
    }
    
    public String getClassName() {
        return className;
    }
    
    public LocalDateTime getStartTime() {
        return startTime;
    }
    
    public LocalDateTime getEndTime() {
        return endTime;
    }
    
    public