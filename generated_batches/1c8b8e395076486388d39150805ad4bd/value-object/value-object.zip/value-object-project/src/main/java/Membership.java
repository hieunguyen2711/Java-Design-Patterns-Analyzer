package com.example.membership;

public final class Membership {
    private final String memberId;
    private final String memberName;
    private final String email;
    private final MembershipType type;
    
    public Membership(String memberId, String memberName, String email, MembershipType type) {
        this.memberId = memberId;
        this.memberName = memberName;
        this.email = email;
        this.type = type;
    }
    
    public String getMemberId() {
        return memberId;
    }
    
    public String getMemberName() {
        return memberName;
    }
    
    public String getEmail() {
        return email;
    }
    
    public MembershipType getType() {
        return type;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        
        Membership that = (Membership) obj;
        return memberId.equals(that.memberId);
    }
    
    @Override
    public int hashCode() {
        return memberId.hashCode();
    }
    
    @Override
    public String toString() {
        return "Membership{" +
                "memberId='" + memberId + '\'' +
                ", memberName='" + memberName + '\'' +
                ", email='" + email + '\'' +
                ", type=" + type +
                '}';
    }
}