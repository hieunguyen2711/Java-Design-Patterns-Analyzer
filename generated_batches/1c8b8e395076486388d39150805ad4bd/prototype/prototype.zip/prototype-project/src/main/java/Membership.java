package com.membership;

public class Membership implements Cloneable {
    private String memberId;
    private String memberName;
    private String membershipType;
    private double monthlyFee;
    
    public Membership(String memberId, String memberName, String membershipType, double monthlyFee) {
        this.memberId = memberId;
        this.memberName = memberName;
        this.membershipType = membershipType;
        this.monthlyFee = monthlyFee;
    }
    
    @Override
    public Membership clone() throws CloneNotSupportedException {
        return (Membership) super.clone();
    }
    
    // Getters and setters
    public String getMemberId() { return memberId; }
    public void setMemberId(String memberId) { this.memberId = memberId; }
    
    public String getMemberName() { return memberName; }
    public void setMemberName(String memberName) { this.memberName = memberName; }
    
    public String getMembershipType() { return membershipType; }
    public void setMembershipType(String membershipType) { this.membershipType = membershipType; }
    
    public double getMonthlyFee() { return monthlyFee; }
    public void setMonthlyFee(double monthlyFee) { this.monthlyFee = monthlyFee; }
    
    @Override
    public String toString() {
        return "Membership{" +
                "memberId='" + memberId + '\'' +
                ", memberName='" + memberName + '\'' +
                ", membershipType='" + membershipType + '\'' +
                ", monthlyFee=" + monthlyFee +
                '}';
    }
}