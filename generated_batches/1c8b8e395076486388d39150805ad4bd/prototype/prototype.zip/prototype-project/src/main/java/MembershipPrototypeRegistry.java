package com.membership;

import java.util.HashMap;
import java.util.Map;

public class MembershipPrototypeRegistry {
    private static Map<String, Membership> prototypeMap = new HashMap<>();
    
    static {
        // Register prototype instances
        prototypeMap.put("basic", new Membership("B001", "Basic Member", "Basic", 29.99));
        prototypeMap.put("premium", new Membership("P001", "Premium Member", "Premium", 59.99));
        prototypeMap.put("vip", new Membership("V001", "VIP Member", "VIP", 99.99));
    }
    
    public static Membership getPrototype(String type) {
        try {
            return prototypeMap.get(type).clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException("Failed to clone