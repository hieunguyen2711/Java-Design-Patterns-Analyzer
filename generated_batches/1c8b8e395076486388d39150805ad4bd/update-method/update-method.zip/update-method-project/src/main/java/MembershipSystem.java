package com.membership;

public class MembershipSystem {
    
    public static void main(String[] args) {
        // Create different types of memberships
        Membership basicMember = MembershipFactory.createMembership("B001", "John Doe",