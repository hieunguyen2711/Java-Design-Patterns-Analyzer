package com.membership;

public class MembershipFactory {
    
    public static Membership createMembership(String type, String memberId, String name, double monthlyFee) {
        switch (type.toLowerCase()) {
            case "basic":
                return new BasicMembership(memberId, name, monthlyFee);
            case "premium":
                return new PremiumMembership(memberId, name, monthlyFee);
            default:
                throw new IllegalArgumentException("Unknown membership type: " + type);
        }
    }
}