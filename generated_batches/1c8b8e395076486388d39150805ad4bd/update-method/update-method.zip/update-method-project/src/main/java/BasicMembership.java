package com.membership;

public class BasicMembership extends Membership {
    
    public BasicMembership(String memberId, String name, double monthlyFee) {
        super(memberId, name, monthlyFee);
    }
    
    @Override
    public void updateMembership() {
        System.out.println("Updating basic membership for " + name);
        this.monthlyFee = 29.99;
        System.out.println("New monthly fee: $" + monthlyFee);
    }
}