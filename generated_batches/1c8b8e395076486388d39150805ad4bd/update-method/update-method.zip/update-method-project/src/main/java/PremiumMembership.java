package com.membership;

public class PremiumMembership extends Membership {
    
    public PremiumMembership(String memberId, String name, double monthlyFee) {
        super(memberId, name, monthlyFee);
    }
    
    @Override
    public void updateMembership() {
        System.out.println("Updating premium membership for " + name);
        this.monthlyFee = 79.99;
        System.out.println("New monthly fee: $" + monthlyFee);
    }
}