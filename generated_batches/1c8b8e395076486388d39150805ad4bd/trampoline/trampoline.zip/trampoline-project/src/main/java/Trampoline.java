@FunctionalInterface
public interface Trampoline<T> {
    Result<T> apply();
    
    static <T> Trampoline<T> done(T value) {
        return () -> new Result.Done<>(value);
    }
    
    static <T> Trampoline<T> more(Trampoline<T> trampoline) {
        return () -> new Result.More<>(trampoline);
    }
    
    interface Result<T> {
        class Done<T> implements Result<T> {
            private final T value;
            
            public Done(T value) {
                this.value = value;
            }
            
            @Override
            public boolean isDone() {
                return true;
            }
            
            @Override
            public T getValue() {
                return value;
            }
        }
        
        class More<T> implements Result<T> {
            private final Trampoline<T> trampoline;
            
            public More(Trampoline<T> trampoline) {
                this.trampoline = trampoline;
            }
            
            @Override
            public boolean isDone() {
                return false;
            }
            
            @Override
            public T getValue() {
                return null; // Should never be called for more
            }
            
            public Trampoline<T> getTrampoline() {
                return trampoline;
            }
        }
        
        boolean isDone();
        T getValue();
    }
}