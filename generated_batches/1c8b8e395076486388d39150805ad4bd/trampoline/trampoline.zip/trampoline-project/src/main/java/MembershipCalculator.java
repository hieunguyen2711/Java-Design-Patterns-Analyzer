public class MembershipCalculator {
    
    public long calculateMembershipCost(int years) {
        // Using trampoline to avoid stack overflow for large recursion
        Trampoline<Long> trampoline = buildTrampoline(0, 0L, years);
        
        return evaluateTrampoline(trampoline);
    }
    
    private Trampoline<Long> buildTrampoline(int currentYear, long accumulatedCost, int targetYears) {
        if (currentYear >= targetYears) {
            return Trampoline.done(accumulatedCost);
        }
        
        // Calculate