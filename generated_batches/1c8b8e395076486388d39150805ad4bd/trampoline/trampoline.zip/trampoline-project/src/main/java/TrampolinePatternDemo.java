public class TrampolinePatternDemo {
    public static void main(String[] args) {
        // Demonstrating trampoline pattern with membership calculation
        MembershipCalculator calculator = new MembershipCalculator();
        
        // Calculate total cost for 5 years of membership
        int totalYears = 5;
        long result = calculator.calculateMembershipCost(totalYears);
        System.out.println("Total cost for " + totalYears + " years: $" + result);
    }
}