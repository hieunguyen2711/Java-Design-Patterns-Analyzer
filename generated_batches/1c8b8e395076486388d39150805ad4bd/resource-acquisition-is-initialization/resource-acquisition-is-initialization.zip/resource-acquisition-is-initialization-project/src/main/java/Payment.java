package com.gym.payment;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class Payment {
    private String paymentId;
    private BigDecimal amount;
    private LocalDateTime timestamp;
    
    public Payment(String paymentId, BigDecimal amount, LocalDateTime timestamp) {
        this.paymentId = paymentId;
        this.amount = amount;
        this.timestamp = timestamp;
    }
    
    public String getPaymentId() {
        return paymentId;
    }
    
    public BigDecimal get