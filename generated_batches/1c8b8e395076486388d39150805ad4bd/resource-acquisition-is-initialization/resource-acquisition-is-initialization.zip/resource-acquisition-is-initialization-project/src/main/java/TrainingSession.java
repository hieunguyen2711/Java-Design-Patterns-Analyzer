package com.gym.schedule;

import java.time.LocalDateTime;

public class TrainingSession {
    private String sessionId;
    private LocalDateTime dateTime;
    private String trainerName;
    
    public TrainingSession(String sessionId, LocalDateTime dateTime, String trainerName) {
        this.sessionId = sessionId;
        this.dateTime = dateTime;
        this.trainerName = trainerName;
    }
    
    public String getSessionId() {
        return sessionId;
    }
    
    public LocalDateTime getDateTime() {
        return dateTime;
    }
    
    public String getTrainerName() {
        return trainerName;
    }
}