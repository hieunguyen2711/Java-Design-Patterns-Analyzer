package com.gym.schedule;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Schedule {
    private List<TrainingSession> sessions;
    
    public Schedule() {
        this.sessions = new ArrayList<>();
    }
    
    public void addSession(TrainingSession session) {
        sessions.add(session);
    }
    
    public List<TrainingSession> getSessions() {
        return sessions;
    }
}