package com.gym.membership;

public class Membership {
    private String memberId;
    private String name;
    
    public Membership(String memberId, String name) {
        this.memberId = memberId;
        this.name = name;
    }
    
    public String getMemberId() {
        return memberId;
    }
    
    public String getName() {
        return name;
    }
}