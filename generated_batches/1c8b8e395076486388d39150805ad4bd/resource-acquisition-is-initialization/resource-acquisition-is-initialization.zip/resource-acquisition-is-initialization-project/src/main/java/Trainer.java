package com.gym.trainer;

public class Trainer {
    private String trainerId;
    private String name;
    
    public Trainer(String trainerId, String name) {
        this.trainerId = trainerId;
        this.name = name;
    }
    
    public String getTrainerId() {
        return trainerId;
    }
    
    public String getName() {
        return name;
    }
}