package com.membership;

public class BasicMembership extends Membership {
    
    public BasicMembership(String memberId, String name) {
        super(memberId, name);
        this.monthlyFee = 29.99;
    }
    
    @Override
    public double calculateDiscount() {
        return 0.0; // No discount for basic membership
    }
}