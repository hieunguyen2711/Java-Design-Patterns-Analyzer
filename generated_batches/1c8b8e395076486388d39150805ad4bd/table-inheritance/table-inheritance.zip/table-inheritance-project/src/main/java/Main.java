package com.membership;

public class Main {
    public static void main(String[] args) {
        Membership basic = MembershipFactory.createMembership("basic", "M001", "John Doe");
        Membership premium = MembershipFactory.createMembership("premium", "M002", "Jane Smith");
        
        System.out.println("Basic Membership:");
        System.out.println("Member: " + basic.getName());
        System.out.println("Fee