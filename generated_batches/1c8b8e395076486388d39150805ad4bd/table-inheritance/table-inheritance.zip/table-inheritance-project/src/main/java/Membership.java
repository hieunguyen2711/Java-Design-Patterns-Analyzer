package com.membership;

public abstract class Membership {
    protected String memberId;
    protected String name;
    protected double monthlyFee;
    
    public Membership(String memberId, String name) {
        this.memberId = memberId;
        this.name = name;
    }
    
    public abstract double calculateDiscount();
    
    public double getMonthlyFee() {
        return monthlyFee;
    }
    
    public void setMonthlyFee(double monthlyFee) {
        this.monthlyFee = monthlyFee;
    }
    
    public String getMemberId() {
        return memberId;
    }
    
    public String getName() {
        return name;
    }
}