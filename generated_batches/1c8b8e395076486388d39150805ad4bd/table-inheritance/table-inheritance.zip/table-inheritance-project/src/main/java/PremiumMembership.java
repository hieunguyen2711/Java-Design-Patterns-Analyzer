package com.membership;

public class PremiumMembership extends Membership {
    
    public PremiumMembership(String memberId, String name) {
        super(memberId, name);
        this.monthlyFee = 79.99;
    }
    
    @Override
    public double calculateDiscount() {
        return 0.15; // 15% discount for premium membership
    }
}