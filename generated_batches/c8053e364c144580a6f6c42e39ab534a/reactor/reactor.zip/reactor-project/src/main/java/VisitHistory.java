public class VisitHistory {
    private String id;
    private Patient patient;
    private Doctor doctor;
    private long visitTime;
    
    public VisitHistory(String id, Patient patient, Doctor doctor, long visitTime) {
        this.id = id;
        this.patient = patient;
        this.doctor = doctor;
        this.visitTime = visitTime;