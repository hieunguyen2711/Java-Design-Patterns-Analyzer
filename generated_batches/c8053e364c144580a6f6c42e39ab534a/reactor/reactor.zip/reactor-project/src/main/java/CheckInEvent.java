public class CheckInEvent {
    private String appointmentId;
    private long timestamp;
    
    public CheckInEvent(String appointmentId, long timestamp) {
        this.appointmentId = appointmentId;
        this.timestamp = timestamp;
    }
    
    public String getAppointmentId() {
        return appointmentId;
    }
    
    public long getTimestamp() {
        return timestamp;
    }
}