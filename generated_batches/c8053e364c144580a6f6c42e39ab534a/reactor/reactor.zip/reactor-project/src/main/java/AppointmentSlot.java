public class AppointmentSlot {
    private String id;
    private Doctor doctor;
    private Patient patient;
    private long timestamp;
    private boolean isAvailable;
    
    public AppointmentSlot(String id, Doctor doctor, long timestamp) {
        this.id = id;
        this.doctor = doctor;
        this.timestamp = timestamp;
        this.isAvailable = true;
    }
    
    public String getId() {
        return id;
    }
    
    public Doctor getDoctor() {
        return doctor;
    }
    
    public Patient getPatient() {
        return patient;
    }
    
    public long getTimestamp() {
        return timestamp;
    }
    
    public boolean isAvailable() {
        return isAvailable;
    }
    
    public void setPatient(Patient patient) {
        this.patient = patient;
        this.isAvailable = false;
    }
}