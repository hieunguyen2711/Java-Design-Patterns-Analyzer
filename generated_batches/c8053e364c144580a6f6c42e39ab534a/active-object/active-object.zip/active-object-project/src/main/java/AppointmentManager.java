public class AppointmentManager {
    private final ActiveObject activeObject;

    public AppointmentManager(ActiveObject activeObject) {
        this.activeObject = activeObject;
    }

    public void scheduleAppointment(String patientName, String doctorName, long timestamp) {
        activeObject.scheduleAppointment(patientName, doctorName, timestamp);
    }

    public void checkInPatient(String patientName, String doctorName, long timestamp) {
        activeObject.checkInPatient(patientName, doctorName, timestamp);
    }

    public void