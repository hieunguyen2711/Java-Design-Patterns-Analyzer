public interface ActiveObject {
    void scheduleAppointment(String patientName, String doctorName, long timestamp);
    void checkInPatient(String patientName, String doctorName, long timestamp);
    void recordVisit(String patientName, String doctorName, long timestamp);
}