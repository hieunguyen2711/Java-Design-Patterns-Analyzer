import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class ClinicService implements ActiveObject {
    private final BlockingQueue<Runnable> queue = new LinkedBlockingQueue<>();
    private final Thread workerThread;

    public ClinicService() {
        this.workerThread = new Thread(this::processRequests);
        this.workerThread.start();
    }

    @Override
    public void scheduleAppointment(String patientName, String doctorName, long timestamp) {
        queue.offer(() -> {
            System.out.println("Scheduled appointment: " + patientName + 
                " with " + doctorName + " at " + timestamp);
        });
    }

    @Override
    public void checkInPatient(String patientName, String doctorName, long timestamp) {
        queue.offer(() -> {
            System.out.println("Checked in patient: " + patientName + 
                " for " + doctorName + " at " + timestamp);
        });
    }

    @Override
    public void recordVisit(String patientName, String doctorName, long timestamp) {
        queue.offer(() -> {
            System.out.println("Recorded visit: " + patientName + 
                " with " + doctorName + " at " + timestamp);
        });
    }

    private void processRequests() {
        while (!Thread.currentThread().isInterrupted()) {
            try {
                Runnable task = queue.take();
                task.run();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }

    public void shutdown() {
        workerThread.interrupt();
    }
}