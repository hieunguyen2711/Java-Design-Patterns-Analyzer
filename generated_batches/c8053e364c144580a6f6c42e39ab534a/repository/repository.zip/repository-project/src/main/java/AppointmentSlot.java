import java.time.LocalDateTime;

public class AppointmentSlot {
    private int id;
    private LocalDateTime dateTime;
    private int doctorId;
    private boolean isAvailable;

    public AppointmentSlot(int id, LocalDateTime dateTime, int doctorId) {
        this.id = id;
        this.dateTime =