import java.util.ArrayList;
import java.util.List;

public class ClinicModel {
    private List<Doctor> doctors;
    private List<Patient> patients;
    private List<Appointment> appointments;
    
    public ClinicModel() {
        this.doctors = new ArrayList<>();
        this.patients = new ArrayList<>();
        this.appointments = new ArrayList<>();
    }
    
    public void addDoctor(String name, String specialty) {
        doctors.add(new Doctor(name, specialty));
    }
    
    public void addPatient(String name, int age) {
        patients.add(new Patient(name, age));
    }
    
    public void addAppointment(int doctorIndex, int patientIndex, String dateTime) {
        if (doctorIndex < doctors.size() && patientIndex < patients.size()) {
            appointments.add(new Appointment(doctors.get(doctorIndex), 
                                           patients.get(patientIndex), 
                                           dateTime));
        }
    }
    
    public List<Doctor> getDoctors() {
        return doctors;
    }
    
    public List<Patient> getPatients() {
        return patients;
    }
    
    public List<Appointment> getAppointments() {
        return appointments;
    }
}