public class ClinicApp {
    public static void main(String[] args) {
        // Create model
        ClinicModel model = new ClinicModel();
        
        // Create view
        ClinicView view = new ClinicView();
        
        // Create controller
        ClinicController controller = new ClinicController(model, view);
        
        // Initialize with sample data
        controller.addDoctor("Dr. Smith", "Cardiology");
        controller.addPatient("John Doe", 30);
        controller.addAppointment(0, 0, "2023-12-01 10:00");
        
        // Display current state
        controller.displayAppointments();
    }
}