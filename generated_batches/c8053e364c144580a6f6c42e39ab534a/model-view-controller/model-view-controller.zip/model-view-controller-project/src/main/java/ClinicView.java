import java.util.List;

public class ClinicView {
    
    public void displayDoctors(List<Doctor> doctors) {
        System.out.println("Doctors:");
        for (int i = 0; i < doctors.size(); i++) {
            Doctor doctor = doctors.get(i);
            System.out.println(i + ": " + doctor.getName() + " - " + doctor.getSpecialty());
        }
    }
    
    public void displayPatients(List<Patient> patients) {
        System.out.println("Patients:");
        for (