package clinic;

public class Patient {
    private final String name;
    private final int patientId;
    
    public Patient(String name, int patientId) {
        this.name = name;
        this.patientId = patientId;
    }
    
    public String getName() {
        return name;
    }
    
    public int getPatientId() {
        return patientId;
    }
}