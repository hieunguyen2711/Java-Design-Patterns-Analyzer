package clinic;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ClinicScheduler {
    private final AppointmentSlot[] slots;
    private final ExecutorService executor;
    
    public ClinicScheduler(int numberOfSlots) {
        this.slots = new AppointmentSlot[numberOfSlots];
        for (int i = 0; i < numberOfSlots; i++) {
            slots[i] = new AppointmentSlot