package clinic;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class AppointmentSlot {
    private final int slotId;
    private boolean isAvailable;
    private BlockingQueue<Patient> waitingList;
    
    public AppointmentSlot(int slotId) {
        this.slotId = slotId;
        this.isAvailable = true;
        this.waitingList = new LinkedBlockingQueue<>();
    }
    
    public synchronized boolean bookAppointment(Patient patient) throws InterruptedException {
        if (isAvailable) {
            isAvailable = false;
            return true;
        } else {
            // Guarded suspension - wait until slot becomes available
            waitingList.put(patient);
            while (!isAvailable) {
                this.wait();
            }
            return true;
        }
    }
    
    public synchronized void releaseSlot() {
        isAvailable = true;
        
        // Notify one waiting patient that the slot is now available
        if (!waitingList.isEmpty()) {
            notify();
        }
    }
    
    public int getSlotId() {
        return slotId;
    }
}