package clinic;

public class Doctor {
    private final String name;
    private final int doctorId;
    
    public Doctor(String name, int doctorId) {
        this.name = name;
        this.doctorId = doctorId;
    }
    
    public String getName() {
        return name;
    }
    
    public int getDoctorId() {
        return doctorId;
    }
}