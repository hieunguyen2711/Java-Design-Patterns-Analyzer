public class AppointmentSlot {
    private Doctor doctor;
    private Patient patient;
    private String date;
    private String time;
    private AppointmentState state;
    
    public AppointmentSlot(Doctor doctor, Patient patient, String date, String time) {
        this.doctor = doctor;
        this.patient = patient;
        this.date = date;
        this.time = time;
        this.state = new AvailableState();
    }
    
    public void checkIn() {
        state.checkIn(this);
    }
    
    public void completeVisit() {
        state.completeVisit(this);
    }
    
    public void cancel() {
        state.cancel(this);
    }
    
    public AppointmentState getState() {
        return state;
    }
    
    public void setState(AppointmentState state) {
        this.state = state;
    }
    
    public Doctor getDoctor() {
        return doctor;
    }
    
    public Patient getPatient() {
        return patient;
    }
    
    public String getDate() {
        return date;
    }
    
    public String getTime() {
        return time;
    }
}