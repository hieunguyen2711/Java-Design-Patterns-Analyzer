public abstract class AppointmentState {
    public abstract void checkIn(AppointmentSlot slot);
    public abstract void completeVisit(AppointmentSlot slot);
    public abstract void cancel(AppointmentSlot slot);
}