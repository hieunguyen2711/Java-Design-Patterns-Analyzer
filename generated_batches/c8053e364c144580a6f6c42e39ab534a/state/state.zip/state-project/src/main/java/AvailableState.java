public class AvailableState extends AppointmentState {
    @Override
    public void checkIn(AppointmentSlot slot) {
        System.out.println("Patient checked in for appointment");
        slot.setState(new CheckedInState());
    }
    
    @Override
    public void completeVisit(AppointmentSlot slot) {