package clinic;

import java.util.HashMap;
import java.util.Map;

public class CheckInSystem {
    private static CheckInSystem instance;
    private Map<String, AppointmentSlot> checkIns;
    
    private CheckInSystem() {
        checkIns = new HashMap<>();
    }
    
    public static CheckInSystem getInstance() {
        if (instance == null) {
            synchronized (CheckInSystem.class) {
                if (instance == null) {
                    instance = new CheckInSystem();
                }
            }
        }
        return instance;
    }
    
    public void checkIn(AppointmentSlot slot, Patient patient) {
        String key = slot.getDoctor().getName() + "_" + slot.getDateTime();
        checkIns.put(key, slot);
        System.out.println("Patient " + patient.getName() +