package clinic;

import java.time.LocalDateTime;

public class AppointmentSlot {
    private LocalDateTime dateTime;
    private Doctor doctor;
    private Patient patient;
    
    public AppointmentSlot(LocalDateTime dateTime, Doctor doctor) {
        this.dateTime = dateTime;
        this.doctor = doctor;
    }
    
    public LocalDateTime getDateTime() {
        return dateTime;
    }
    
    public Doctor getDoctor() {
        return doctor;
    }
    
    public Patient getPatient() {
        return patient;
    }
    
    public void setPatient(Patient patient) {
        this.patient = patient;
    }
}