package clinic;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Clinic {
    private List<Doctor> doctors = new ArrayList<>();
    private List<Patient> patients = new ArrayList<>();
    private List<AppointmentSlot> appointmentSlots = new ArrayList<>();
    
    public void addDoctor(Doctor doctor) {
        doctors.add(doctor);
    }
    
    public void addPatient(Patient patient) {
        patients.add(patient);
    }
    
    public void addAppointmentSlot(AppointmentSlot slot) {
        appointmentSlots.add(slot);
    }
    
    public List<Doctor> getDoctors() {
        return doctors;
    }
    
    public List<Patient> getPatients() {
        return patients;
    }
    
    public List<AppointmentSlot> getAppointmentSlots() {
        return appointmentSlots;
    }
}