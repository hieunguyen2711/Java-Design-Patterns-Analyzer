package clinic;

import java.time.LocalDateTime;

public class CheckIn {
    private AppointmentSlot slot;
    private LocalDateTime checkInTime;
    
    public CheckIn(AppointmentSlot slot) {
        this.slot = slot;
        this.checkInTime = LocalDateTime.now();
    }
    
    public AppointmentSlot getSlot() {
        return slot;
    }
    
    public LocalDateTime getCheckInTime() {
        return checkInTime;
    }
}