package clinic;

import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

public class CheckInSystem {
    private static volatile CheckInSystem instance;
    private Map<String, AppointmentSlot> checkIns;
    
    private CheckInSystem() {
        this.checkIns = new ConcurrentHashMap<>();
    }
    
    public static synchronized CheckInSystem getInstance() {
        if (instance == null) {
            instance = new CheckInSystem();
        }
        return instance;
    }
    
    public synchronized void checkIn(String appointmentId, Patient patient) {
        AppointmentSlot slot = checkIns.get(appointmentId);
        if (slot != null && !