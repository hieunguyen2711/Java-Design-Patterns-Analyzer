package clinic;

import java.time.LocalDateTime;

public class CheckInManager {
    private AppointmentSlot slot;
    
    public CheckInManager(AppointmentSlot slot) {
        this.slot = slot;
    }
    
    public void checkInPatient(Patient patient) {
        if (slot.getPatient() == null) {
            slot.assignPatient(patient);
        }
    }
    
    public boolean isCheckInComplete() {
        return slot.getPatient() != null;
    }
    
    public LocalDateTime getAppointmentTime() {
        return slot.getDateTime();
    }
}