package clinic;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class VisitHistory {
    private List<VisitRecord> records;
    
    public VisitHistory() {
        this.records = new ArrayList<>();
    }
    
    public void addVisit(Doctor doctor, Patient patient, LocalDateTime visitTime) {
        records.add(new VisitRecord(doctor, patient