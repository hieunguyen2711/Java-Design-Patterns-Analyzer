package clinic;

public class CheckIn {
    private AppointmentSlot appointment;
    private boolean isCheckedIn;
    private String checkInTime;
    
    public CheckIn(AppointmentSlot appointment, String checkInTime) {
        this.appointment = appointment;
        this.checkInTime = checkInTime;
        this.isCheckedIn