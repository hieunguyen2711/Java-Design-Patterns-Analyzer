package clinic;

public class Doctor extends Person {
    private String specialty;
    private String licenseNumber;
    
    public Doctor(String name, int age, String specialty, String licenseNumber) {
        super(name, age);
        this.specialty = specialty;
        this.licenseNumber = licenseNumber;
    }
    
    public String getSpecialty() {
        return specialty;
    }
    
    public String getLicenseNumber() {
        return licenseNumber;
    }
}