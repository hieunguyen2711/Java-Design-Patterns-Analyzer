package clinic;

public class Patient extends Person {
    private String medicalRecordNumber;
    private String phoneNumber;
    
    public Patient(String name, int age, String medicalRecordNumber, String phoneNumber) {
        super(name, age);
        this.medicalRecordNumber = medicalRecordNumber;
        this.phoneNumber = phoneNumber;
    }
    
    public String getMedicalRecordNumber() {
        return medicalRecordNumber;
    }
    
    public String getPhoneNumber() {
        return phoneNumber;
    }
}