package clinic.model;

import java.time.LocalDateTime;

public class AppointmentSlot {
    private int id;
    private int doctorId;
    private int patientId;
    private LocalDateTime dateTime;
    
    public AppointmentSlot(int id, int doctorId, int patientId, LocalDateTime dateTime) {
        this.id = id;
        this.doctorId = doctorId;
        this.patientId = patientId;
        this.dateTime = dateTime;
    }
    
    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getDoctorId() { return doctorId; }
    public void setDoctorId(int doctorId) { this.doctorId = doctorId; }
    
    public int getPatientId() { return patientId; }
    public void setPatientId(int patientId) { this.patientId = patientId; }
    
    public LocalDateTime getDateTime()