public class ClinicManager {
    private static volatile ClinicManager instance;
    
    private ClinicManager() {
        // Private constructor to prevent instantiation
    }
    
    public static ClinicManager getInstance() {
        if (instance == null) {
            synchronized (ClinicManager.class) {
                if (instance == null) {
                    instance = new ClinicManager();
                }
            }
        }
        return instance;
    }
    
    public void scheduleAppointment(String patientName, String doctorName, String slotTime) {
        System.out.println("Appointment scheduled for " + patientName + 
                          " with " + doctorName + " at " + slotTime);
    }
    
    public void checkInPatient(String patientName) {
        System.out.println(patientName + " has checked in");
    }
    
    public void recordVisit(String patientName, String doctorName) {
        System.out.println("Visit recorded: " + patientName + " seen by " + doctorName);
    }
}