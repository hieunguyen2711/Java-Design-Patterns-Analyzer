public class Main {
    public static void main(String[] args) {
        ClinicManager manager1 = ClinicManager.getInstance();
        ClinicManager manager2 = ClinicManager.getInstance();
        
        System.out.println("Are both instances the same? " + (manager1 == manager2));
        
        manager1.scheduleAppointment("John Doe", "Dr. Smith", "10:00 AM");
        manager2.checkInPatient("Jane Smith");
        manager1.recordVisit("John Doe", "Dr. Smith");
    }
}