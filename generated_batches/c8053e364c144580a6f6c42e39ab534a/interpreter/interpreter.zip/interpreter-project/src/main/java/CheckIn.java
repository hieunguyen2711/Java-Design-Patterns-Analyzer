public class CheckIn {
    private String patientName;
    private String checkInTime;

    public CheckIn(String patientName, String checkInTime) {
        this.patientName = patientName;
        this.checkInTime = checkInTime;
    }

    public String getPatientName() {
        return patientName;
    }

    public String getCheckInTime() {
        return checkInTime;
    }
}