public class Visit {
    private String doctorName;
    private String patientName;
    private String visitDate;

    public Visit(String doctorName, String patientName, String visitDate) {
        this.doctorName = doctorName;
        this.patientName = patientName;
        this.visitDate = visitDate;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public String getPatientName() {
        return patientName;
    }

    public String getVisitDate() {
        return visitDate;
    }
}