public class Appointment {
    private String doctorName;
    private String patientName;
    private String slotTime;

    public Appointment(String doctorName, String patientName, String slotTime) {
        this.doctorName = doctorName;
        this.patientName = patientName;
        this.slotTime = slotTime;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public String getPatientName() {
        return patientName;
    }

    public String getSlotTime() {
        return slotTime;
    }
}