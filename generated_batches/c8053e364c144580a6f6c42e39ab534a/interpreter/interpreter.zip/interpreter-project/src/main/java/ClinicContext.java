import java.util.ArrayList;
import java.util.List;

public class ClinicContext {
    private List<Appointment> appointments;
    private List<CheckIn> checkIns;
    private List<Visit> visits;

    public ClinicContext() {
        this.appointments = new ArrayList<>();
        this.checkIns = new ArrayList<>();
        this.visits = new ArrayList<>();
    }

    public void addAppointment(Appointment appointment) {
        appointments.add(appointment);
    }

    public void addCheckIn(CheckIn checkIn) {
        checkIns.add(checkIn);
    }

    public void addVisit(Visit visit) {
        visits.add(visit);
    }

    public List<Appointment> getAppointments() {
        return appointments;
    }

    public List<CheckIn> getCheckIns() {