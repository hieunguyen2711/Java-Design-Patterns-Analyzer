public class AppointmentSlot {
    private String id;
    private Doctor doctor;
    private Patient patient;
    private String dateTime;
    private boolean isBooked;
    
    public AppointmentSlot(String id, Doctor doctor, String dateTime) {
        this.id = id;
        this.doctor = doctor;
        this.dateTime = dateTime;
        this.isBooked = false;
    }
    
    public String getId() {
        return id;
    }
    
    public Doctor getDoctor() {
        return doctor;
    }
    
    public Patient getPatient() {
        return patient;
    }
    
    public void setPatient(Patient patient) {
        this.patient = patient;
    }
    
    public String getDateTime() {
        return dateTime;
    }
    
    public boolean isBooked() {
        return isBooked;
    }
    
    public void bookAppointment(Patient patient) {
        if (!isBooked) {
            this.patient = patient;
            this.isBooked = true;
        }
    }
}