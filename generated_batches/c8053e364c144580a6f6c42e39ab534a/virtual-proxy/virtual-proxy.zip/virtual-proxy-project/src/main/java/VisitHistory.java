import java.util.ArrayList;
import java.util.List;

public class VisitHistory {
    private String id;
    private Patient patient;
    private Doctor doctor;
    private String visitDate;
    private String notes;
    
    public VisitHistory(String id, Patient patient, Doctor doctor, String visitDate) {
        this.id = id;