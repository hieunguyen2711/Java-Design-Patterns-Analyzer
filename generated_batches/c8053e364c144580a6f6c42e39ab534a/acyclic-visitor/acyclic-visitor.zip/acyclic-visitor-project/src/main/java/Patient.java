public class Patient implements ClinicElement {
    private String name;
    private int age;
    
    public Patient(String name, int age) {
        this.name = name;
        this.age = age;
    }
    
    @Override
    public void accept(ClinicVisitor visitor) {
        visitor.visit(this);
    }
    
    public String getName() {
        return name;
    }
    
    public int getAge() {
        return age;
    }
}