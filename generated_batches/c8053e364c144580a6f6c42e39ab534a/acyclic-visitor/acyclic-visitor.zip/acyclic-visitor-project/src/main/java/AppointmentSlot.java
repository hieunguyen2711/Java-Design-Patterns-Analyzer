public class AppointmentSlot implements ClinicElement {
    private String date;
    private String time;
    private Doctor doctor;
    private Patient patient;
    
    public AppointmentSlot(String date, String time, Doctor doctor, Patient patient) {
        this.date = date;
        this.time = time;
        this.doctor = doctor;
        this.patient = patient;
    }
    
    @Override
    public void accept(ClinicVisitor visitor) {
        visitor.visit(this);
    }
    
    public String getDate() {
        return date;
    }
    
    public String getTime() {
        return time;
    }
    
    public Doctor getDoctor() {
        return doctor;
    }
    
    public Patient getPatient() {
        return patient;
    }
}