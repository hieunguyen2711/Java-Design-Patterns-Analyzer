public class CheckIn implements ClinicElement {
    private AppointmentSlot appointment;
    private String checkInTime;
    
    public CheckIn(AppointmentSlot appointment, String checkInTime) {
        this.appointment = appointment;
        this.checkInTime = checkInTime;
    }
    
    @Override
    public void accept(ClinicVisitor visitor) {
        visitor.visit(this);
    }
    
    public AppointmentSlot getAppointment() {
        return appointment;
    }
    
    public String getCheckIn