public interface ClinicElement {
    void accept(ClinicVisitor visitor);
}