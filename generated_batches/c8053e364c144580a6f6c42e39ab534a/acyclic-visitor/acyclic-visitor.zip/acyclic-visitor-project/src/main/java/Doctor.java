public class Doctor implements ClinicElement {
    private String name;
    private String specialty;
    
    public Doctor(String name, String specialty) {
        this.name = name;
        this.specialty = specialty;
    }
    
    @Override
    public void accept(ClinicVisitor visitor) {
        visitor.visit(this);
    }
    
    public String getName() {
        return name;
    }
    
    public String getSpecialty() {
        return specialty;
    }
}