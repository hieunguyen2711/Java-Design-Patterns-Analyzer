public class NullDoctor extends Doctor {
    private static final NullDoctor INSTANCE = new NullDoctor();
    
    private NullDoctor() {
        super("Unknown Doctor", "N/A");
    }
    
    public static NullDoctor getInstance() {
        return INSTANCE;
    }
    
    @Override
    public String getName() {
        return "Unknown Doctor";
    }
    
    @Override
    public String getSpecialty() {
        return "N/A";
    }
}