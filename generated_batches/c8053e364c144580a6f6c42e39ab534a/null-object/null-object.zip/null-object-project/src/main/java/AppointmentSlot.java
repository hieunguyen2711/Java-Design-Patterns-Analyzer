public class AppointmentSlot {
    private Doctor doctor;
    private Patient patient;
    private String timeSlot;
    
    public AppointmentSlot(Doctor doctor, Patient patient, String timeSlot) {
        this.doctor = doctor;
        this.patient = patient;
        this.timeSlot = timeSlot;
    }
    
    public Doctor getDoctor() {
        return doctor;
    }
    
    public Patient getPatient() {
        return patient;
    }
    
    public String getTimeSlot() {
        return timeSlot;
    }
}