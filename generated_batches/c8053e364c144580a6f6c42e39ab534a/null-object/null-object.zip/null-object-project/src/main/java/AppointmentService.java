public class AppointmentService {
    
    public AppointmentSlot findAppointment(String timeSlot) {
        // Simulate finding an appointment - in real scenario this would query a database
        if ("10:00".equals(timeSlot)) {
            return new AppointmentSlot(
                new Doctor("Dr. Smith", "Cardiology"),
                new Patient("John Doe", 45),
                "10:00"
            );
        }
        // Return null object instead of null for unknown slots
        return new AppointmentSlot(
            NullDoctor.getInstance(),
            new Patient("Unknown Patient",