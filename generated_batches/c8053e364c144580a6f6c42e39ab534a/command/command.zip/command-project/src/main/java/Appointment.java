public class Appointment {
    private final String patientName;
    private boolean isCheckedIn;
    private boolean isCancelled;
    
    public Appointment(String patientName) {
        this.patientName = patientName;
        this.isCheckedIn = false;
        this.isCancelled = false;
    }
    
    public void checkIn() {
        if (!isCancelled) {
            isCheckedIn = true;
            System.out.println("Patient " + patientName + " checked in.");
        } else {
            System.out.println("Cannot check in cancelled appointment for " + patientName);
        }
    }
    
    public void undoCheckIn() {
        isCheckedIn = false;
        System.out.println("Check-in undone for " + patientName);
    }
    
    public void cancel() {
        isCancelled = true;
        System.out.println("Appointment for " + patientName + " cancelled.");
    }
    
    public void restore() {
        isCancelled = false;
        System.out.println("Appointment for " + patientName + " restored.");
    }
    
    public boolean isCheckedIn() {
        return isCheckedIn;
    }
    
    public boolean isCancelled() {
        return isCancelled;
    }
}