public class CancelAppointmentCommand implements AppointmentCommand {
    private final Appointment appointment;
    
    public CancelAppointmentCommand(Appointment appointment) {
        this.appointment = appointment;
    }
    
    @Override
    public void execute() {
        appointment.cancel();
    }
    
    @Override
    public void undo() {
        appointment.restore();
    }
}