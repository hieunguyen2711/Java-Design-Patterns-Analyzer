public interface AppointmentCommand {
    void execute();
    void undo();
}