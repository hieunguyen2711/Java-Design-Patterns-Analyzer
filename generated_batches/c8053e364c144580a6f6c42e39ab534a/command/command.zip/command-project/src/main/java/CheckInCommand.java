public class CheckInCommand implements AppointmentCommand {
    private final Appointment appointment;
    
    public CheckInCommand(Appointment appointment) {
        this.appointment = appointment;
    }
    
    @Override
    public void execute() {
        appointment.checkIn();
    }
    
    @Override
    public void undo() {
        appointment.undoCheckIn();
    }
}