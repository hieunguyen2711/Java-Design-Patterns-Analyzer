import java.util.ArrayList;
import java.util.List;

public class AppointmentCommandExecutor {
    private final List<AppointmentCommand> commandHistory = new ArrayList<>();
    
    public void executeCommand(AppointmentCommand command) {
        command.execute();
        commandHistory.add(command);
    }