public class PatientCheckInHandler extends CheckInHandler {
    @Override
    public boolean handleCheckIn(AppointmentSlot slot)