public class AppointmentSlot {
    private Doctor doctor;
    private Patient patient;
    private String date;
    private boolean isAvailable;

    public AppointmentSlot(Doctor doctor, String date) {
        this.doctor = doctor;
        this.date = date;
        this.isAvailable = true;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public String getDate() {
        return date;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }
}