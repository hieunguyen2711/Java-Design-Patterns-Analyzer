public class DoctorCheckInHandler extends CheckInHandler {
    @Override
    public boolean handleCheckIn(AppointmentSlot slot) {
        if (slot.getDoctor() == null) {
            System.out.println("Error: No doctor assigned to appointment");
            return false;
        }
        
        if (nextHandler != null) {
            return nextHandler.handleCheckIn(slot);
        }
        return true;
    }
}