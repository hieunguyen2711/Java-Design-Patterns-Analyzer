public abstract class CheckInHandler {
    protected CheckInHandler nextHandler;

    public void setNext(CheckInHandler handler) {
        this.nextHandler = handler;
    }

    public abstract boolean handleCheckIn(AppointmentSlot slot);
}