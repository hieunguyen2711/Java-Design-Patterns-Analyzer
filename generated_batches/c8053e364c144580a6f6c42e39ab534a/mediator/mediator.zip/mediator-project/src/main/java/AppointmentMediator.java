public interface AppointmentMediator {
    void scheduleAppointment(Patient patient, Doctor doctor, String slot);
    void checkInPatient(Patient patient);
    void recordVisit(Patient patient, Doctor doctor, String notes);
}