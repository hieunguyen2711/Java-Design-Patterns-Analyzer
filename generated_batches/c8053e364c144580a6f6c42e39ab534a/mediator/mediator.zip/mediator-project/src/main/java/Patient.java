public class Patient {
    private String name;
    private int