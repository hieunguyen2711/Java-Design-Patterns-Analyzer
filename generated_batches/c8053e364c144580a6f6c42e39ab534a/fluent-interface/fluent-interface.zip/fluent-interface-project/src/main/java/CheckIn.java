package clinic;

import java.time.LocalDateTime;

public class CheckIn {
    private LocalDateTime checkInTime;
    private AppointmentSlot appointment;
    private boolean isCheckedIn;
    
    public CheckIn(AppointmentSlot appointment) {
        this.appointment = appointment;
        this.isCheckedIn = false;