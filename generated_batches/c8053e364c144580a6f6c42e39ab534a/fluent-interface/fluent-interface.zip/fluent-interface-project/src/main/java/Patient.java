package clinic;

public class Patient {
    private String name;
    private int id;
    private String medicalRecordNumber;
    
    public Patient(String name, int id, String medicalRecordNumber) {
        this.name = name;
        this.id = id;
        this.medicalRecordNumber = medicalRecordNumber;
    }
    
    public String getName() {
        return name;
    }
    
    public int getId() {
        return id;
    }
    
    public String getMedicalRecordNumber() {
        return medicalRecordNumber;
    }
}