package clinic;

public class Doctor {
    private String name;
    private String specialty;
    private int licenseNumber;
    
    public Doctor(String name, String specialty, int licenseNumber) {
        this.name = name;
        this.specialty = specialty;
        this.licenseNumber = licenseNumber;
    }
    
    public String getName() {
        return name;
    }
    
    public String getSpecialty() {
        return specialty;
    }
    
    public int getLicenseNumber() {
        return licenseNumber;
    }
}