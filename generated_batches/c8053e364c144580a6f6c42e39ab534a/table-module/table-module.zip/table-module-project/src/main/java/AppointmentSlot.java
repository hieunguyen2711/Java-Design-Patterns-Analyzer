package clinic;

import java.time.LocalDateTime;

public class AppointmentSlot {
    private String id;
    private Doctor doctor;
    private Patient patient;
    private LocalDateTime dateTime;
    private boolean isAvailable;
    
    public AppointmentSlot(String id, Doctor doctor, LocalDateTime dateTime) {
        this.id = id;
        this.doctor = doctor;
        this.dateTime = dateTime;
        this.isAvailable = true;
    }
    
    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public Doctor getDoctor() { return doctor; }
    public void setDoctor(Doctor doctor) { this.doctor = doctor; }
    
    public Patient getPatient() { return patient; }
    public void setPatient(Patient patient) { this.patient = patient; }
    
    public LocalDateTime getDateTime() { return dateTime; }
    public void setDateTime(LocalDateTime dateTime) {