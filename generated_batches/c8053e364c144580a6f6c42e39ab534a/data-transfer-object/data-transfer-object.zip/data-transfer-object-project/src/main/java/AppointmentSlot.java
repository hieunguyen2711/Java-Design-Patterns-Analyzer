package clinic.model;

import java.time.LocalDateTime;

public class AppointmentSlot {
    private int id;
    private LocalDateTime dateTime;
    private int doctorId;
    private boolean isAvailable;
    
    public AppointmentSlot() {}
    
    public AppointmentSlot(int id, LocalDateTime dateTime, int doctorId, boolean isAvailable) {
        this.id = id;
        this.dateTime = dateTime;
        this.doctorId = doctorId;
        this.isAvailable = isAvailable;
    }
    
    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public LocalDateTime getDateTime() { return dateTime; }
    public