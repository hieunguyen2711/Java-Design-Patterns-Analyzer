import java.time.LocalDateTime;

public class AppointmentSlot {
    private LocalDateTime dateTime;
    private Patient patient;
    private Clinic clinic;
    
    public AppointmentSlot(LocalDateTime dateTime, Patient patient, Clinic clinic) {
        this.dateTime = dateTime;
        this.patient = patient;
        this.clinic = clinic;
    }
    
    public LocalDateTime getDateTime() {
        return dateTime;
    }
    
    public Patient getPatient() {
        return patient;
    }
    
    public Clinic getClinic() {
        return clinic;
    }
}