import java.time.LocalDateTime;

public class CheckIn {
    private LocalDateTime checkInTime;
    private Patient patient;
    private Doctor doctor;
    
    public CheckIn(Patient patient, Doctor doctor) {
        this.patient = patient;
        this.doctor = doctor;
        this.checkInTime = LocalDateTime.now();
    }
    
    public LocalDateTime