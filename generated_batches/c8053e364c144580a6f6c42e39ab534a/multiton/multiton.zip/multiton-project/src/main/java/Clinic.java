import java.util.HashMap;
import java.util.Map;

public class Clinic {
    private static final Map<String, Clinic> instances = new HashMap<>();
    private String clinicName;
    private Doctor doctor;
    
    private Clinic(String clinicName) {
        this.clinicName = clinicName;
    }
    
    public static Clinic getInstance(String clinicName) {
        return instances.computeIfAbsent(clinicName, Clinic::new);
    }
    
    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }
    
    public Doctor getDoctor() {
        return doctor;
    }
    
    public String getClinicName() {
        return clinicName;
    }
}