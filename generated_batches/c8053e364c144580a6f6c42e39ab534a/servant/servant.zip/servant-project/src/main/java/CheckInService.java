package clinic;

public class CheckInService {
    private static CheckInService instance;
    
    private CheckInService() {}
    
    public static CheckInService getInstance() {
        if (instance == null) {
            instance = new CheckInService();
        }
        return instance;
    }
    
    public void checkInPatient(AppointmentSlot slot) {
        System.out.println("Checking in patient " + slot.getPatient().getName() 
                          + " with doctor " + slot.getDoctor().getName());
    }
}