package clinic;

import java.util.ArrayList;
import java.util.List;

public class VisitHistory {
    private List<AppointmentSlot> visits;
    
    public VisitHistory() {
        this.visits = new ArrayList<>();
    }
    
    public void addVisit(AppointmentSlot slot) {
        visits.add(slot);
    }
    
    public List<AppointmentSlot> getVisits() {
        return visits;
    }
}