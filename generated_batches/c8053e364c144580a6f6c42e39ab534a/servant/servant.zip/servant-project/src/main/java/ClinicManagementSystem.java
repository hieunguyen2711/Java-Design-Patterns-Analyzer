package clinic;

public class ClinicManagementSystem