public class AppointmentSlot {
    private String time;
    private boolean isAvailable;
    
    public AppointmentSlot(String time) {
        this.time = time;
        this.isAvailable = true;
    }
    
    public String getTime() {
        return time;
    }
    
    public boolean isAvailable() {
        return isAvailable;
    }
    
    public void setAvailable(boolean available) {
        isAvailable = available;
    }
}