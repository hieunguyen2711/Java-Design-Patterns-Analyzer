import java.util.HashMap;
import java.util.Map;

public class ClinicFlyweightFactory {
    private static final Map<String, Doctor> doctorPool = new HashMap<>();