import java.util.ArrayList;
import java.util.List;

public class VisitHistory {
    private List<CheckIn> visits;
    
    public VisitHistory() {
        this.visits = new ArrayList<>();
    }
    
    public void addVisit(CheckIn visit) {
        visits.add(visit);
    }
    
    public List<CheckIn> getVisits() {
        return visits;
    }
}