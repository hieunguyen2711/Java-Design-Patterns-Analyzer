public interface AppointmentService extends Service {
    void bookAppointment(int doctorId, int patientId, String date);
    void cancelAppointment(int appointmentId);
}