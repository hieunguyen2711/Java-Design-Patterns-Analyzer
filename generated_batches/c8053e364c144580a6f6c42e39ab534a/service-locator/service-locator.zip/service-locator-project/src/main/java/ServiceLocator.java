public class ServiceLocator {
    private static ServiceLocator instance;
    private Map<String, Object> services;

    private ServiceLocator() {
        services = new HashMap<>();
        initializeServices();
    }

    public static ServiceLocator getInstance() {
        if (instance == null) {
            instance = new ServiceLocator();
        }
        return instance;
    }

    private void initializeServices() {
        services.put("DoctorService", new DoctorServiceImpl());
        services.put("PatientService", new PatientServiceImpl());
        services.put("AppointmentService", new AppointmentServiceImpl());
    }

    public Object getService(String serviceName) {
        return services.get(serviceName);
    }
}