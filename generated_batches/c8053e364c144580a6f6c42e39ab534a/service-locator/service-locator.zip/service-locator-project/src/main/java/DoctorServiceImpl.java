public class DoctorServiceImpl implements DoctorService {
    @Override
    public String getName() {
        return "DoctorService";
    }

    @Override
    public void scheduleAppointment(int doctorId, int patientId, String date) {
        System.out.println("Scheduled appointment for doctor " + doctorId + 
                          " and patient " + patientId + " on " + date);
    }

    @Override
    public void updateDoctorInfo(int doctorId, String name, String specialty) {
        System.out.println("Updated doctor " + doctorId + " info: " + name + ", " + specialty);
    }
}