public interface PatientService extends Service {
    void registerPatient(String name, String contact);
    void updatePatientInfo(int patientId, String name, String contact);
}