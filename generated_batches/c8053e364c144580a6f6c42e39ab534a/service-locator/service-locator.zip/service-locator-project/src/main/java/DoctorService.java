public interface DoctorService extends Service {
    void scheduleAppointment(int doctorId, int patientId, String date);
    void updateDoctorInfo(int doctorId, String name, String specialty);
}