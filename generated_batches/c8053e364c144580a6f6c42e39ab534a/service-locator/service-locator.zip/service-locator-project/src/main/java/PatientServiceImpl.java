public class PatientServiceImpl implements PatientService {
    @Override
    public String getName() {
        return "PatientService";
    }

    @Override
    public void registerPatient(String name, String contact) {
        System.out.println("Registered patient: " + name + ", Contact: " + contact);