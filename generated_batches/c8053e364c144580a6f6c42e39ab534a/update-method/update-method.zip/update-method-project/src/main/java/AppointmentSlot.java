package clinic;

public class AppointmentSlot {
    private Doctor doctor;
    private Patient patient;
    private String dateTime;
    private boolean isBooked;
    
    public AppointmentSlot(Doctor doctor, String dateTime) {
        this.doctor = doctor;
        this.dateTime = dateTime;
        this.isBooked = false;
    }
    
    public void bookAppointment(Patient patient) {
        if (!isBooked) {
            this.patient = patient;
            this.isBooked = true;
        }
    }
    
    public void cancelAppointment() {
        if (isBooked) {
            this.patient = null;
            this.isBooked = false;
        }
    }
    
    public Doctor getDoctor() {
        return doctor;
    }
    
    public Patient getPatient() {
        return patient;
    }
    
    public String getDateTime() {
        return dateTime;
    }
    
    public boolean isBooked() {
        return isBooked;
    }
}