package clinic;

public class CheckIn {
    private AppointmentSlot appointment;
    private long checkInTime;
    private boolean isCheckedIn;
    
    public CheckIn(AppointmentSlot appointment) {
        this.appointment = appointment;
        this.isCheckedIn = false;
    }