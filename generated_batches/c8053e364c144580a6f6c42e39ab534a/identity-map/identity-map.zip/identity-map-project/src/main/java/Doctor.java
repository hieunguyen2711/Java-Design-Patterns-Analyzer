package clinic;

public class Doctor {
    private final String id;
    private final String name;
    
    public Doctor(String id, String name) {
        this.id = id;
        this.name = name;
    }
    
    public String getId() {
        return id;
    }
    
    public String getName() {
        return name;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Doctor doctor = (Doctor) obj;
        return id.equals(doctor.id);
    }
    
    @Override
    public int hashCode() {
        return id.hashCode();
    }
}