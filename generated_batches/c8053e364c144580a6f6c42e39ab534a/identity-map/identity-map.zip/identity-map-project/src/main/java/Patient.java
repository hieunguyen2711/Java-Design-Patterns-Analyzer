package clinic;

public class Patient {
    private final String id;
    private final String name;
    
    public Patient(String id, String name) {
        this.id = id;
        this.name = name;
    }
    
    public String getId() {
        return id;
    }
    
    public String getName() {
        return name;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Patient patient = (Patient) obj;
        return id.equals(patient.id);
    }
    
    @Override
    public int hashCode() {
        return id.hashCode();
    }
}