package clinic;

import java.time.LocalDateTime;

public class AppointmentSlot {
    private final String id;
    private final LocalDateTime dateTime;
    private final Doctor doctor;
    private final Patient patient;
    
    public AppointmentSlot(String id, LocalDateTime dateTime, Doctor doctor, Patient patient) {
        this.id = id;
        this.dateTime = dateTime;
        this.doctor = doctor;
        this.patient = patient;
    }
    
    public String getId() {
        return id;
    }
    
    public LocalDateTime getDateTime() {
        return dateTime;
    }
    
    public Doctor getDoctor() {
        return doctor;
    }
    
    public Patient getPatient() {
        return patient;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        AppointmentSlot that = (AppointmentSlot) obj