package clinic;

public interface CheckInStrategy {
    void performCheckIn(AppointmentSlot slot);
}