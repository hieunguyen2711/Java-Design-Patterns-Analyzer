package clinic;

public class StandardCheckIn implements CheckInStrategy {
    @Override
    public void performCheckIn(AppointmentSlot slot) {
        System.out.println("Standard check-in for " + slot.getPatient().getName() + 
                          " with Dr. " + slot.getDoctor().getName());
    }
}