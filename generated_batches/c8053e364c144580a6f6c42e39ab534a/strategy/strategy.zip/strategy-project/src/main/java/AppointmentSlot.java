package clinic;

public class AppointmentSlot {
    private Doctor doctor;
    private Patient patient;
    private String dateTime;
    private CheckInStrategy checkInStrategy;
    
    public AppointmentSlot(Doctor doctor, Patient patient, String dateTime) {
        this.doctor = doctor;
        this.patient = patient;
        this.dateTime = dateTime;
        this.checkInStrategy = new StandardCheckIn();
    }
    
    public void setCheckInStrategy(CheckInStrategy strategy) {
        this.checkInStrategy = strategy;
    }
    
    public void checkIn() {
        checkInStrategy.performCheckIn(this);
    }
    
    // Getters
    public Doctor getDoctor() { return doctor; }
    public Patient getPatient() { return patient; }
    public String getDateTime() { return dateTime; }
}