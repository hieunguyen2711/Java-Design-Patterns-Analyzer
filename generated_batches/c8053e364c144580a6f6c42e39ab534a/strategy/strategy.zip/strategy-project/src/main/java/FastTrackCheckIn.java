package clinic;

public class FastTrackCheckIn implements CheckInStrategy {
    @Override
    public void performCheckIn(AppointmentSlot slot) {
        System.out.println("Fast-track check-in for " + slot.getPatient().getName() +