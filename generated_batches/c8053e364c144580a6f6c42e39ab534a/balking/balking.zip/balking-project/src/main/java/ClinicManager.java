package clinic;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ClinicManager {
    private List<AppointmentSlot> appointmentSlots;
    
    public ClinicManager() {
        this.appointmentSlots = new ArrayList<>();
    }
    
    public void addAppointmentSlot(AppointmentSlot slot) {
        appointmentSlots.add(slot);
    }
    
    public AppointmentSlot findAvailableSlot(Doctor doctor, LocalDateTime dateTime) {
        for