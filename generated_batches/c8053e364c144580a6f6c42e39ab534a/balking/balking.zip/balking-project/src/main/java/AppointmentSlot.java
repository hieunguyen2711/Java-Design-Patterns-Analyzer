package clinic;

import java.time.LocalDateTime;

public class AppointmentSlot {
    private LocalDateTime dateTime;
    private Doctor doctor;
    private Patient patient;
    private boolean isBooked;
    private boolean isCheckedIn;
    
    public AppointmentSlot(LocalDateTime dateTime, Doctor doctor) {
        this.dateTime = dateTime;
        this.doctor = doctor;
        this.isBooked = false;
        this.isCheckedIn = false;
    }
    
    public LocalDateTime getDateTime() {
        return dateTime;
    }
    
    public Doctor getDoctor() {
        return doctor;
    }
    
    public Patient getPatient() {
        return patient;
    }
    
    public boolean isBooked() {
        return isBooked;
    }
    
    public void book(Patient patient) {
        if (!isBooked) {
            this.patient = patient;
            this.isBooked = true;
        }
    }
    
    public boolean isCheckedIn() {
        return isCheckedIn;
    }
    
    public void checkIn() {
        // Balking pattern: only allow check-in if not already checked in
        if (!isCheckedIn) {
            isCheckedIn = true;
        }
    }
}