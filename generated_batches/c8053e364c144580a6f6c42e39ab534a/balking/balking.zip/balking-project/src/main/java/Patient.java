package clinic;

public class Patient {
    private String name;
    private int id;
    
    public Patient(String name, int id) {
        this.name = name;
        this.id = id;
    }
    
    public String getName() {
        return name;
    }
    
    public int getId() {
        return id;
    }
}