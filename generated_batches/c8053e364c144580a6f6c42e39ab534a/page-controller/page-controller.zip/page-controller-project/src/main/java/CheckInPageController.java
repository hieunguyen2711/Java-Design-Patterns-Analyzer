public class CheckInPageController implements PageController {
    @Override
    public void handleRequest(String method, String path) {
        if ("POST".equals(method) && "/checkin".equals(path)) {
            System.out.println("Processing patient check-in");
        } else {
            System.out.println("Check-in page not found");
        }
    }
}