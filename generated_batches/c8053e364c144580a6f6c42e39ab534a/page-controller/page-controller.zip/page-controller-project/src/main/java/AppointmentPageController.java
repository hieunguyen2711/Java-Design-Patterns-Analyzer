public class AppointmentPageController implements PageController {
    @Override
    public void handleRequest(String method, String path) {
        if ("GET".equals(method) && "/appointments".equals(path)) {
            System.out.println("Displaying appointment scheduling page");
        } else {
            System.out.println("Appointment page not found");
        }
    }
}