public class ClinicApp {
    public static void main(String[] args) {
        PageController controller = new AppointmentPageController();
        controller.handleRequest("GET", "/appointments");
        
        controller = new CheckInPageController();
        controller.handleRequest("POST", "/checkin");
    }
}