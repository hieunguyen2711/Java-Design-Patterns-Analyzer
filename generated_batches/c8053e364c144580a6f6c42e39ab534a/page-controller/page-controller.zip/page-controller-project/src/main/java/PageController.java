public interface PageController {
    void handleRequest(String method, String path);
}