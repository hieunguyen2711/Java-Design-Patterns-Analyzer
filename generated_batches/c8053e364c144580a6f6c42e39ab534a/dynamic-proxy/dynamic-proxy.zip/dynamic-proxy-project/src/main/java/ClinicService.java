public interface ClinicService {
    void scheduleAppointment(AppointmentSlot slot);
    void checkInPatient(AppointmentSlot slot);
    void recordVisitHistory(AppointmentSlot slot);
}