import java.time.LocalDateTime;

public class ClinicServiceImpl implements ClinicService {
    
    @Override
    public void scheduleAppointment(AppointmentSlot slot) {
        System.out.println("Scheduling appointment for " + 
            slot.getDoctor().getName() + " at " + slot.getDateTime());
    }
    
    @Override
    public void checkInPatient(AppointmentSlot slot) {
        if (slot.getPatient() != null) {
            System.out.println("Checking in patient: " + slot.getPatient().getName());
        } else {
            System.out.println("No patient assigned to this appointment");
        }
    }
    
    @Override
    public void recordVisitHistory(AppointmentSlot slot) {
        if (slot.getPatient() !=