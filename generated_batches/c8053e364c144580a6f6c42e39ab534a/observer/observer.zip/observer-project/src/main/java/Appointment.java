package clinic;

public class Appointment {
    private Doctor doctor;
    private Patient patient;
    private String dateTime;
    private boolean isCheckedIn;
    
    public Appointment(Doctor doctor, Patient patient, String dateTime) {
        this.doctor = doctor;
        this.patient = patient;
        this.dateTime = dateTime;
        this.isCheckedIn = false;
    }
    
    public void checkIn() {
        this.isCheckedIn = true;
        doctor.notifyObservers(this);
    }
    
    public Doctor getDoctor() {
        return doctor;
    }
    
    public Patient getPatient() {
        return patient;
    }
    
    public String getDateTime() {
        return dateTime;
    }
    
    public boolean isCheckedIn() {
        return isCheckedIn;
    }
}