package clinic;

public class Patient {
    private String name;
    private String email;
    
    public Patient(String name, String email) {
        this.name = name;
        this.email = email;
    }
    
    public String getName() {
        return name;
    }
    
    public String getEmail() {
        return email;
    }
}