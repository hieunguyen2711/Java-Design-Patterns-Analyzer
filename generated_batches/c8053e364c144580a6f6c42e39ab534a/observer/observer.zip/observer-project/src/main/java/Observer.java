package clinic;

public interface Observer {
    void update(Appointment appointment);
}