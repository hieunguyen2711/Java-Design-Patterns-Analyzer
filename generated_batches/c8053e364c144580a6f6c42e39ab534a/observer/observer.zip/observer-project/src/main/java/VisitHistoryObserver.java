package clinic;

import java.util.ArrayList;
import java.util.List;

public class VisitHistoryObserver implements Observer {
    private List<String> visitHistory;
    
    public VisitHistoryObserver() {
        this.visitHistory = new ArrayList<>();
    }
    
    @Override
    public void update(Appointment appointment) {
        if (appointment.isCheckedIn()) {
            String record = String.format("Patient %s checked in for appointment with Dr. %