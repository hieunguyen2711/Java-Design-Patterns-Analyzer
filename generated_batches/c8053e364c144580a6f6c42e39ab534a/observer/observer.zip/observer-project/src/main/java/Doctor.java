package clinic;

import java.util.ArrayList;
import java.util.List;

public class Doctor {
    private String name;
    private List<Observer> observers;
    
    public Doctor(String name) {
        this.name = name;
        this.observers = new ArrayList<>();
    }
    
    public void addObserver(Observer observer) {
        observers.add(observer);
    }
    
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }
    
    public void notifyObservers(Appointment appointment) {
        for (Observer observer : observers) {
            observer.update(appointment);
        }
    }
    
    public String getName() {
        return name;
    }
}