package clinic;

import java.util.ArrayList;
import java.util.List;

public class VisitHistory {
    private List<CheckIn> visits;
    
    public VisitHistory() {
        this.visits = new ArrayList<>();
    }
    
    public void addVisit(CheckIn checkIn) {
        visits.add(checkIn);
    }