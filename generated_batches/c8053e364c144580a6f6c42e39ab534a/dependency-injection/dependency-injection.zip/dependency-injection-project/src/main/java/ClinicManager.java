public class ClinicManager {
    private Doctor doctor;
    private Patient patient;
    private AppointmentSlot appointment;
    
    public ClinicManager(Doctor doctor, Patient patient) {
        this.doctor = doctor;
        this.patient = patient;
        this.appointment = new AppointmentSlot(doctor, patient, "2023-12-01 10:00");
    }
    
    public void processVisit() {
        CheckInService checkInService = new CheckInService(appointment);
        checkInService.checkInPatient();
    }
}