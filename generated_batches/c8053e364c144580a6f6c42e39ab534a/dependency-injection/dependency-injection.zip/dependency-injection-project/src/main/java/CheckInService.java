public class CheckInService {
    private AppointmentSlot appointment;
    
    public CheckInService(AppointmentSlot appointment) {
        this.appointment = appointment;
    }
    
    public void checkInPatient() {
        System.out.println("Checking in patient " + 
            appointment.getPatient().getName() + 
            " for doctor " + 
            appointment.getDoctor().getName());
    }
}