public class AppointmentSlot {
    private Doctor doctor;
    private Patient patient;
    private String dateTime;
    
    public AppointmentSlot(Doctor doctor, Patient patient, String dateTime) {
        this.doctor = doctor;
        this.patient = patient;
        this.dateTime = dateTime;
    }
    
    public Doctor getDoctor() {
        return doctor;
    }
    
    public Patient getPatient() {
        return patient;
    }
    
    public String getDateTime() {
        return dateTime;
    }
}