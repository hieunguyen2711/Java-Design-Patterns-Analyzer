public class VisitHistory {
    private Patient patient;
    private Doctor doctor;
    private String visitDate;
    private String notes;
    
    public VisitHistory(Patient patient, Doctor doctor, String visitDate, String notes) {
        this.patient = patient;
        this.doctor = doctor;
        this.visitDate = visitDate;
        this.notes = notes;
    }
    
    public Patient getPatient() {
        return patient;
    }
    
    public Doctor getDoctor() {
        return doctor;
    }