public class CheckIn {
    private Patient patient;
    private AppointmentSlot slot;
    private boolean isCheckedIn;
    
    public CheckIn(Patient patient, AppointmentSlot slot) {
        this.patient = patient;
        this.slot = slot;
        this.isCheckedIn = false;
    }
    
    public void checkIn() {
        this.isCheckedIn = true;
    }
    
    public Patient getPatient() {
        return patient;
    }
    
    public AppointmentSlot getSlot() {
        return slot;
    }
    
    public boolean isCheckedIn() {
        return isCheckedIn;
    }
}