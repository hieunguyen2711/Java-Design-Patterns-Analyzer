public class AppointmentSlot {
    private String date;
    private String time;
    private Doctor doctor;
    
    public AppointmentSlot(String date, String time, Doctor doctor) {
        this.date = date;
        this.time = time;
        this.doctor = doctor;
    }
    
    public String getDate() {
        return date;
    }
    
    public String getTime() {
        return time;
    }
    
    public Doctor getDoctor() {
        return doctor;
    }
}