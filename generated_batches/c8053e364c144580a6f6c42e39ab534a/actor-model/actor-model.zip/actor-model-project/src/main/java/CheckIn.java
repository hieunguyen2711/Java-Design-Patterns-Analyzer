public class CheckIn {
    private AppointmentSlot appointment;
    private long checkInTime;
    
    public CheckIn(AppointmentSlot appointment) {
        this.appointment = appointment;
        this.checkInTime = System.currentTimeMillis();
    }
    
    public AppointmentSlot getAppointment() {
        return appointment;
    }
    
    public long getCheckInTime() {
        return checkInTime;
    }
}