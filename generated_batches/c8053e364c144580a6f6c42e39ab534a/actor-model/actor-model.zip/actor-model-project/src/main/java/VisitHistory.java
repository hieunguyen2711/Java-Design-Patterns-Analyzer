public class VisitHistory {
    private CheckIn checkIn;
    private String diagnosis;
    private String treatment;
    
    public VisitHistory(CheckIn checkIn, String diagnosis, String treatment) {
        this.checkIn = checkIn;
        this.diagnosis = diagnosis;
        this.treatment = treatment;
    }
    
    public CheckIn getCheckIn() {
        return checkIn;
    }
    
    public String getDiagnosis() {
        return diagnosis;
    }
    
    public String getTreatment() {
        return treatment;
    }
}