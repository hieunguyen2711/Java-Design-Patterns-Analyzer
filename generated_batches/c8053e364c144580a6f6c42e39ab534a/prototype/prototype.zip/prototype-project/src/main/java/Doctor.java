package clinic;

public class Doctor implements Cloneable {
    private String name;
    private String specialty;
    private int yearsOfExperience;
    
    public Doctor(String name, String specialty, int yearsOfExperience) {
        this.name = name;
        this.specialty = specialty;
        this.yearsOfExperience = yearsOfExperience;
    }
    
    @Override
    public Doctor clone() throws CloneNotSupportedException {
        return (Doctor) super.clone();
    }
    
    // Getters and setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getSpecialty() { return specialty; }
    public void setSpecialty(String specialty) { this.specialty = specialty; }
    
    public int getYearsOfExperience() { return yearsOfExperience; }
    public void setYearsOfExperience(int yearsOfExperience) { this.yearsOfExperience = yearsOfExperience; }
}