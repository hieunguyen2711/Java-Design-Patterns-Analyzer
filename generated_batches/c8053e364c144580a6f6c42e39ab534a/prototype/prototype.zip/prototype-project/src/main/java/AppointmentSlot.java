package clinic;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class AppointmentSlot implements Cloneable {
    private LocalDateTime dateTime;
    private Doctor doctor;
    private Patient patient;
    private List<String> notes;
    
    public AppointmentSlot(LocalDateTime dateTime, Doctor doctor) {
        this.dateTime = dateTime;
        this.doctor = doctor;
        this.notes = new ArrayList<>();
    }
    
    @Override
    public AppointmentSlot clone() throws CloneNotSupportedException {
        AppointmentSlot