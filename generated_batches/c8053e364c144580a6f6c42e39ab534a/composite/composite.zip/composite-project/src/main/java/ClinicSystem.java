package clinic;

import java.util.ArrayList;
import java.util.List;

public class ClinicSystem implements ClinicComponent {
    private List<ClinicComponent> components;
    private String name;
    
    public ClinicSystem(String name) {
        this.name = name;
        this.components = new ArrayList<>();
    }
    
    public void addComponent(ClinicComponent