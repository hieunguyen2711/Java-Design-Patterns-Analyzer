package clinic;

import java.util.ArrayList;
import java.util.List;

public class Doctor implements ClinicComponent {
    private String name;
    private List<Patient> patients;
    
    public Doctor(String name) {
        this.name = name;
        this.patients = new ArrayList<>();
    }
    
    public void addPatient(Patient patient) {
        patients.add(patient);
    }
    
    @Override
    public void display() {
        System.out.println("Doctor: " + name);
        for (Patient patient : patients) {
            patient.display();
        }
    }
    
    @Override
    public String getName() {
        return name;
    }
}