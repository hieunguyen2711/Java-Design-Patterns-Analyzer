package clinic;

public class AppointmentSlot implements ClinicComponent {
    private String time;
    private String type;
    
    public AppointmentSlot(String time, String type) {
        this.time = time;
        this.type = type;
    }
    
    @Override
    public void display() {
        System.out.println("    Slot: " + time + " - " + type);
    }
    
    @Override
    public String getName() {
        return time;
    }
}