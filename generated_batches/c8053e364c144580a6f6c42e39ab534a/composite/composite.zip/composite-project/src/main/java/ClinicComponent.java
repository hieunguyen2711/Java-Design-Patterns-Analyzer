package clinic;

public interface ClinicComponent {
    void display();
    String getName();
}