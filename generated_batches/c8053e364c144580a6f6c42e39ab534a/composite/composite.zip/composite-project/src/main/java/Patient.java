package clinic;

import java.util.ArrayList;
import java.util.List;

public class Patient implements ClinicComponent {
    private String name;
    private List<AppointmentSlot> appointmentSlots;
    
    public Patient(String name) {
        this.name = name;
        this.appointmentSlots = new ArrayList<>();
    }
    
    public void addAppointment(AppointmentSlot slot) {
        appointmentSlots.add(slot);
    }
    
    @Override
    public void display() {
        System.out.println("  Patient: " + name);
        for (AppointmentSlot slot : appointmentSlots) {
            slot.display();
        }
    }
    
    @Override
    public String getName() {
        return name;
    }
}