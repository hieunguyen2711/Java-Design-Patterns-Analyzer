package clinic;

public class Doctor {
    private String name;
    private String specialty;
    private boolean isDirty = false;
    
    public Doctor(String name, String specialty) {
        this.name = name;
        this.specialty = specialty;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
        markAsDirty();
    }
    
    public String getSpecialty() {
        return specialty;
    }
    
    public void setSpecialty(String specialty) {
        this.specialty = specialty;
        markAsDirty();
    }
    
    public boolean isDirty() {
        return isDirty;
    }
    
    public void markAsDirty() {
        this.isDirty = true;
    }
    
    public void clearDirtyFlag() {
        this.isDirty = false;
    }
}