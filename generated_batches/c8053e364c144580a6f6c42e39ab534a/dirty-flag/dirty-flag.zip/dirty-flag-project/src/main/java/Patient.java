package clinic;

public class Patient {
    private String name;
    private int age;
    private boolean isDirty = false;
    
    public Patient(String name, int age) {
        this.name = name;
        this.age = age;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
        markAsDirty();
    }
    
    public int getAge() {
        return age;
    }
    
    public void setAge(int age) {
        this.age = age;
        markAsDirty();
    }
    
    public boolean isDirty() {
        return isDirty;
    }
    
    public void markAsDirty() {
        this.isDirty = true;
    }
    
    public void clearDirtyFlag() {
        this.isDirty = false;
    }
}