package clinic;

public class AppointmentSlot {
    private Doctor doctor;
    private Patient patient;
    private String dateTime;
    private boolean isDirty = false;
    
    public AppointmentSlot(Doctor doctor, Patient patient, String dateTime) {
        this.doctor = doctor;
        this.patient = patient;
        this.dateTime = dateTime;
    }
    
    public Doctor getDoctor() {
        return doctor;
    }
    
    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
        markAsDirty();
    }
    
    public Patient getPatient() {
        return patient;
    }
    
    public void setPatient