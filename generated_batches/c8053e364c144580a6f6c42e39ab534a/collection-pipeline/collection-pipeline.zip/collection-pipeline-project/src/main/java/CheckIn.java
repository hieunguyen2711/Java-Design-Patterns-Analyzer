package clinic;

import java.time.LocalDateTime;

public class CheckIn {
    private String id;
    private AppointmentSlot slot;
    private LocalDateTime checkInTime;
    
    public CheckIn(String id, AppointmentSlot slot) {
        this.id = id;
        this.slot = slot;
        this.checkInTime = LocalDateTime.now();
    }
    
    public String getId() {
        return id;
    }
    
    public AppointmentSlot getSlot() {
        return slot;
    }
    
    public LocalDateTime getCheckInTime() {
        return checkInTime;
    }
}