package clinic;

import java.time.LocalDateTime;

public class AppointmentSlot {
    private String id;
    private Doctor doctor;
    private Patient patient;
    private LocalDateTime dateTime;
    private boolean isBooked;
    
    public AppointmentSlot(String id, Doctor doctor, LocalDateTime dateTime) {
        this.id = id;
        this.doctor = doctor;
        this.dateTime = dateTime;
        this.isBooked = false;
    }
    
    public String getId() {
        return id;
    }
    
    public Doctor getDoctor() {
        return doctor;
    }
    
    public Patient getPatient() {
        return patient;
    }
    
    public LocalDateTime getDateTime() {
        return dateTime;
    }
    
    public boolean isBooked() {
        return isBooked;
    }
    
    public void book(Patient patient) {
        this.patient = patient;
        this.isBooked = true;
    }
}