public class Doctor {
    private String name;
    private String specialty;
    
    public Doctor(String name, String specialty) {
        this.name = name;
        this.specialty = specialty;
    }
    
    public void conductVisit() {
        ClinicManager manager = ClinicManager.getInstance();
        System.out.println(name + " is conducting a visit at " + manager.getClinicName());
    }
    
    public String getName() {
        return name;
    }
    
    public String getSpecialty() {
        return specialty;
    }
}