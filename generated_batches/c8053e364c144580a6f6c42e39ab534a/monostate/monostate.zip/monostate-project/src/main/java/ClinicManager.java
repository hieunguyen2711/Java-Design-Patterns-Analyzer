public class ClinicManager {
    private static ClinicManager instance;
    private String clinicName;
    private int totalAppointments;
    private int checkedInPatients;
    
    // Private constructor to prevent instantiation
    private ClinicManager() {
        this.clinicName = "City Medical Clinic";
        this.totalAppointments = 0;
        this.checkedInPatients = 0;
    }
    
    // Static method to get the single instance
    public static synchronized ClinicManager getInstance() {
        if (instance == null) {
            instance = new ClinicManager();
        }
        return instance;
    }
    
    // Methods to manage clinic data
    public void scheduleAppointment() {
        totalAppointments++;
        System.out.println("Appointment scheduled. Total appointments: " + totalAppointments);
    }
    
    public void checkInPatient() {
        checkedInPatients++;
        System.out.println("Patient checked in. Total checked-in patients: " + checkedInPatients);
    }
    
    public String getClinicName() {
        return clinicName;
    }
    
    public int getTotalAppointments() {
        return totalAppointments;
    }
    
    public int getCheckedInPatients() {
        return checkedInPatients;
    }
}