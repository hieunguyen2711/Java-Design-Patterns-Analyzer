public class Patient {
    private String name;
    private int patientId;
    
    public Patient(String name, int patientId) {
        this.name = name;
        this.patientId = patientId;
    }
    
    public void scheduleAppointment() {
        ClinicManager manager = ClinicManager.getInstance();
        manager.scheduleAppointment();
    }
    
    public void checkIn() {
        ClinicManager manager = ClinicManager.getInstance();
        manager.checkInPatient();
    }
    
    public String getName() {
        return name;
    }
    
    public int getPatientId() {
        return patientId;