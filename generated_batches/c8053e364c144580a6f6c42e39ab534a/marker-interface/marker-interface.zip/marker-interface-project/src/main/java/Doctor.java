package clinic;

public class Doctor implements HealthcareWorker {
    private String name;
    private String specialty;
    
    public Doctor(String name, String specialty) {
        this.name = name;
        this.specialty = specialty;
    }
    
    public String getName() {
        return name;
    }
    
    public String getSpecialty() {
        return specialty;
    }
}