package clinic;

import java.time.LocalDateTime;

public class AppointmentSlot {
    private LocalDateTime dateTime;
    private HealthcareWorker healthcareWorker;
    
    public AppointmentSlot(LocalDateTime dateTime, HealthcareWorker healthcareWorker) {
        this.dateTime = dateTime;
        this.healthcareWorker = healthcareWorker;
    }
    
    public LocalDateTime getDateTime() {
        return dateTime;
    }
    
    public HealthcareWorker getHealthcareWorker() {
        return healthcareWorker;
    }
}