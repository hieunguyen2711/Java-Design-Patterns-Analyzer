package clinic;

import java.time.LocalDateTime;

public class CheckIn {
    private Patient patient;
    private LocalDateTime checkInTime;
    
    public CheckIn(Patient patient, LocalDateTime checkInTime) {
        this.patient = patient;
        this.checkInTime = checkInTime;
    }
    
    public Patient getPatient() {
        return patient;
    }
    
    public LocalDateTime getCheckInTime() {
        return checkInTime;
    }
}