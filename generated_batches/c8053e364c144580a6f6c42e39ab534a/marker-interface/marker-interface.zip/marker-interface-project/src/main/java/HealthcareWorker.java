package clinic;

public interface HealthcareWorker {
    // Marker interface - no methods, just type safety
}