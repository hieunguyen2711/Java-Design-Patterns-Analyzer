package clinic;

public class ClinicApplication {
    public static void main(String[] args) {
        System.out.println("=== General Practice Visit ===");
        ClinicService generalPractice = new GeneralPracticeService();
        generalPractice.processPatientVisit();
        
        System.out.println("\n=== Specialist Visit ===");
        ClinicService specialist = new SpecialistService();
        specialist.processPatientVisit();
    }
}