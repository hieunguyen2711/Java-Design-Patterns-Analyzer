package clinic;

public class SpecialistService extends ClinicService {
    @Override
    protected void performCheckIn() {
        System.out.println("Checking in patient for specialist appointment");
    }
    
    @Override
    protected void conductMedicalExamination() {
        System.out.println("Conducting specialized medical examination with tests");
    }
    
    @Override
    protected void provideTreatment() {
        System.out.println("Providing specialized treatment and referrals");
    }
}