package clinic;

public class GeneralPracticeService extends ClinicService {
    @Override
    protected void performCheckIn() {
        System.out.println("Checking in patient for general practice appointment");
    }
    
    @Override
    protected void conductMedicalExamination() {
        System.out.println("Conducting basic medical examination");
    }
    
    @Override
    protected void provideTreatment() {
        System.out.println("Providing general treatment and prescriptions");
    }
}