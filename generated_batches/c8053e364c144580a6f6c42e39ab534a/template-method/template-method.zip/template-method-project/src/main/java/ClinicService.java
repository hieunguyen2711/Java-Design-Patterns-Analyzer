package clinic;

public abstract class ClinicService {
    // Template method
    public final void processPatientVisit() {
        prepareForVisit();
        performCheckIn();
        conductMedicalExamination();
        provideTreatment();
        completeVisit();
    }
    
    protected void prepareForVisit() {
        System.out.println("Preparing for patient visit...");
    }
    
    protected abstract void performCheckIn();
    protected abstract void conductMedicalExamination();
    protected abstract void provideTreatment();
    
    private void completeVisit() {
        System.out.println("Patient visit completed successfully.");
    }
}