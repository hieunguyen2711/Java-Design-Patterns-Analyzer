public class PremiumCheckIn implements CheckInSystem {
    @Override
    public void checkIn(AppointmentSlot slot) {
        System.out.println("Premium check-in for " + slot.getPatient().getName() 
            + " with Dr. " + slot.getDoctor().getName());
    }
}