public class StandardCheckIn implements CheckInSystem {
    @Override
    public void checkIn(AppointmentSlot slot) {
        System.out.println("Standard check-in for " + slot.getPatient().getName() 
            + " with Dr. " + slot.getDoctor().getName());
    }
}