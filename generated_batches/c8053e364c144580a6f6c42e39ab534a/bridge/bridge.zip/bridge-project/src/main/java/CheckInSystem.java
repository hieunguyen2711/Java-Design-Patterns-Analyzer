public interface CheckInSystem {
    void checkIn(AppointmentSlot slot);
}