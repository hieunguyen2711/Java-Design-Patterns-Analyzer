public class Clinic {
    private CheckInSystem checkInSystem;
    
    public Clinic(CheckInSystem checkInSystem) {
        this.checkInSystem = checkInSystem;
    }
    
    public void performCheckIn(AppointmentSlot slot) {
        checkInSystem.checkIn