import java.time.LocalDateTime;

public class AppointmentSlot {
    private LocalDateTime dateTime;
    private Doctor doctor;
    private Patient patient;
    private boolean isAvailable;
    
    public AppointmentSlot(LocalDateTime dateTime, Doctor doctor) {
        this.dateTime = dateTime;
        this.doctor = doctor;
        this.isAvailable = true;
    }
    
    public LocalDateTime getDateTime() {
        return dateTime;
    }
    
    public Doctor getDoctor() {
        return doctor;
    }
    
    public Patient getPatient() {
        return patient;
    }
    
    public boolean isAvailable() {
        return isAvailable;
    }
    
    public void setPatient(Patient patient) {
        this.patient = patient;
        this.isAvailable = false;
    }
}