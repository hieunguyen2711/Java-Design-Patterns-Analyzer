import java.util.concurrent.ConcurrentHashMap;

public class CheckInManager {
    private static volatile CheckInManager instance;
    private ConcurrentHashMap<String, Boolean> checkIns;
    
    private CheckInManager() {
        checkIns = new ConcurrentHashMap<>();
    }
    
    public static CheckInManager getInstance() {
        if (instance == null) {
            synchronized (CheckInManager.class) {
                if (instance == null) {
                    instance = new CheckInManager();
                }
            }
        }
        return instance;
    }
    
    public boolean checkIn(String appointmentId) {
        return checkIns.putIfAbsent(appointmentId, true) == null;
    }
    
    public boolean isCheckInComplete(String appointmentId) {
        return checkIns.containsKey(appointmentId);
    }
}