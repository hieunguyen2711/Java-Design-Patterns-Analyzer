public class SpecialistSlot extends AppointmentSlot {
    private Doctor doctor;
    
    public SpecialistSlot(String date, String time) {
        super(date, time);
        this.doctor = new Doctor("Dr. Johnson", "Cardiology");
    }
    
    @Override
    public Doctor getDoctor() {
        return doctor;
    }
}