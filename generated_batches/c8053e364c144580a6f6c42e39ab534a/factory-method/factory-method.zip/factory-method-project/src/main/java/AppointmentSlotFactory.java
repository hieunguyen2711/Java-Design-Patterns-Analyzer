public abstract class AppointmentSlotFactory {
    public abstract AppointmentSlot createAppointmentSlot(String date, String time);
}