public abstract class AppointmentSlot {
    protected String date;
    protected String time;
    protected boolean isAvailable;
    
    public AppointmentSlot(String date, String time) {
        this.date = date;
        this.time = time;
        this.isAvailable = true;
    }
    
    public abstract Doctor getDoctor();
    
    public String getDate() {
        return date;
    }
    
    public String getTime() {
        return time;
    }
    
    public boolean isAvailable() {
        return isAvailable;
    }
    
    public void setAvailable(boolean available) {
        isAvailable = available;
    }
}