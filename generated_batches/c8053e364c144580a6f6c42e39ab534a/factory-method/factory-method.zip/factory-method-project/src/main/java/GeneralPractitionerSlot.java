public class GeneralPractitionerSlot extends AppointmentSlot {
    private Doctor doctor;
    
    public GeneralPractitionerSlot(String date, String time) {
        super(date, time);
        this.doctor = new Doctor("Dr. Smith", "General Practice");
    }
    
    @Override
    public Doctor getDoctor() {
        return doctor;
    }
}