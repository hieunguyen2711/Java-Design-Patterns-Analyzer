package clinic;

import java.time.LocalDateTime;

public class CheckIn {
    private AppointmentSlot appointment;
    private LocalDateTime checkInTime;
    
    public CheckIn(AppointmentSlot appointment) {
        this.appointment = appointment;
        this.checkInTime = LocalDateTime.now();
    }
    
    public AppointmentSlot getAppointment() {
        return appointment;
    }
    
    public LocalDateTime getCheckInTime() {
        return checkInTime;
    }
}