public class Memento {
    private String name;
    private String specialty;
    
    public Memento(String name, String specialty) {
        this.name = name;
        this.specialty = specialty;
    }
    
    public String getName() {
        return name;
    }
    
    public String getSpecialty() {
        return specialty;
    }
}