public class ClinicApplication {
    public static void main(String[] args) {
        Doctor doctor = new Doctor("Dr. Smith", "Cardiology");
        
        System.out.println("Initial state:");
        System.out.println("Name: " + doctor.getName() + ", Specialty: " + doctor.getSpecialty());
        
        DoctorCareTaker careTaker = new DoctorCareTaker();
        
        // Save current state
        careTaker.addMemento(doctor.saveToMemento());
        
        // Modify the doctor's specialty
        doctor.setSpecialty("Neurology");
        
        System.out.println("\nAfter modification:");
        System.out.println("Name: " + doctor.getName() + ", Specialty: " + doctor.getSpecialty());
        
        // Restore to original state
        doctor.restoreFromMemento(careTaker.getMemento