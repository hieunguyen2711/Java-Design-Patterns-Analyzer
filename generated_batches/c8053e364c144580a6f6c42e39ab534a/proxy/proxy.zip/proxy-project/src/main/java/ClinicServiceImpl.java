import java.util.ArrayList;
import java.util.List;

public class ClinicServiceImpl implements ClinicService {
    private List<AppointmentSlot> slots;
    
    public ClinicServiceImpl() {
        this.slots = new ArrayList<>();
    }
    
    @Override
    public void bookAppointment(AppointmentSlot slot, Patient patient) {
        if (slot.isAvailable()) {
            slot.bookAppointment(patient);
            System.out.println("Appointment booked for " + patient.getName() + 
                             " with Dr. "