public interface ClinicService {
    void bookAppointment(AppointmentSlot slot, Patient patient);
    AppointmentSlot findAvailableSlot(Doctor doctor);
    void checkInPatient(AppointmentSlot slot);
    void recordVisitHistory(AppointmentSlot slot);
}