package clinic.model;

import java.time.LocalDateTime;

public class AppointmentSlot {
    private String id;
    private LocalDateTime dateTime;
    private Doctor doctor;
    private boolean isAvailable;
    
    public AppointmentSlot(String id, LocalDateTime dateTime, Doctor doctor) {
        this.id = id;
        this.dateTime = dateTime;
        this.doctor = doctor;
        this.isAvailable = true;
    }
    
    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public LocalDateTime getDateTime() { return dateTime; }
    public void setDateTime(LocalDateTime dateTime) { this.dateTime = dateTime; }
    
    public Doctor getDoctor() { return doctor; }
    public void setDoctor(Doctor doctor) { this.doctor = doctor; }
    
    public boolean isAvailable() { return isAvailable; }
    public void setAvailable(boolean available) { isAvailable = available