public abstract class VisitHistoryDecorator extends VisitHistory {
    protected VisitHistory visitHistory;