public class VisitHistory {
    private CheckIn checkIn;
    private String notes;
    
    public VisitHistory(CheckIn checkIn) {
        this.checkIn = checkIn;
        this.notes = "";
    }
    
    public void addNotes(String notes) {
        this.notes += notes + " ";
    }
    
    public String getNotes() {
        return notes;
    }
    
    public CheckIn getCheckIn() {
        return checkIn;
    }
}