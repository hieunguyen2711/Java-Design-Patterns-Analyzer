public class CheckIn {
    private AppointmentSlot appointment;
    private boolean isCheckedIn;
    
    public CheckIn(AppointmentSlot appointment) {
        this.appointment = appointment;
        this.isCheckedIn = false;
    }
    
    public void checkIn() {
        this.isCheckedIn = true;
    }
    
    public boolean isCheckedIn() {
        return isCheckedIn;
    }
    
    public AppointmentSlot getAppointment() {
        return appointment;
    }
}