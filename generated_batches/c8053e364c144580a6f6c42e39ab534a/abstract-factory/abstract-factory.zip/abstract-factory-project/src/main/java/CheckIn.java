public class CheckIn {
    private Patient patient;
    private Doctor doctor;
    private AppointmentSlot slot;
    
    public CheckIn(Patient patient, Doctor doctor, AppointmentSlot slot) {
        this.patient = patient;
        this.doctor = doctor;
        this.slot = slot;
    }
    
    public Patient getPatient() {
        return patient;
    }
    
    public Doctor getDoctor() {
        return doctor;
    }
    
    public AppointmentSlot getSlot() {
        return slot;
    }
}