public class AppointmentSlot {
    private String date;
    private String time;
    private boolean isAvailable;
    
    public AppointmentSlot(String date, String time) {
        this.date = date;
        this.time = time;
        this.isAvailable = true;
    }
    
    public String getDate() {
        return date;
    }
    
    public String getTime() {
        return time;
    }
    
    public boolean isAvailable() {
        return isAvailable;
    }
    
    public void setAvailable(boolean available) {
        isAvailable = available;
    }
}