package clinic;

import java.util.Optional;
import java.util.function.Function;

public class Option<T> {
    private final T value;
    private final boolean isEmpty;
    
    private Option(T value, boolean isEmpty) {
        this.value = value;
        this.isEmpty = isEmpty;
    }