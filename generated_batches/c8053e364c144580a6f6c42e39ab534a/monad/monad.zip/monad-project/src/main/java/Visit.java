package clinic;

import java.time.LocalDateTime;

public class Visit {
    private LocalDateTime checkInTime;
    private LocalDateTime checkOutTime;
    private AppointmentSlot slot;
    
    public Visit(AppointmentSlot slot) {
        this.slot = slot;
        this.checkInTime = LocalDateTime.now();
    }
    
    public LocalDateTime getCheckInTime() {
        return checkInTime;
    }
    
    public LocalDateTime getCheckOutTime() {
        return checkOutTime;
    }
    
    public void setCheckOutTime(LocalDateTime checkOutTime) {
        this.checkOutTime = checkOutTime;
    }
    
    public AppointmentSlot getSlot() {
        return slot;
    }
}