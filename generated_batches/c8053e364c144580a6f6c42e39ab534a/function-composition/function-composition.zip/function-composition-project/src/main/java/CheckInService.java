package clinic;

import java.time.LocalDateTime;

public class CheckInService {
    private AppointmentSlot slot;
    
    public CheckInService(AppointmentSlot slot) {
        this.slot = slot;
    }
    
    public boolean checkIn() {
        if (slot.getPatient() == null) {
            return false;
        }
        // Simulate check-in process
        System.out.println("Patient " + slot.getPatient().getName() + 
                          " checked in for appointment with Dr. " + 
                          slot.getDoctor().getName());
        return true;
    }
}