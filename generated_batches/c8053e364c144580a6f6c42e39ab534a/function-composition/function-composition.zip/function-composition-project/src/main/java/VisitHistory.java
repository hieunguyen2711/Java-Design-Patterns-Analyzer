package clinic;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class VisitHistory {
    private List<VisitRecord> records;
    
    public VisitHistory() {
        this.records = new ArrayList<>();
    }
    
    public void addRecord(VisitRecord record) {
        records.add(record);
    }
    
    public List<VisitRecord> getRecords() {