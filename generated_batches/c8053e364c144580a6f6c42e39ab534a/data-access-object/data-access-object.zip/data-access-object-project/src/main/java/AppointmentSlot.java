public class AppointmentSlot {
    private int id;
    private int doctorId;
    private String date;
    private String time;

    public AppointmentSlot(int id, int doctorId, String date, String time) {
        this.id = id;
        this.doctorId = doctorId;
        this.date = date;
        this.time = time;
    }

    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getDoctorId() { return doctorId; }
    public void setDoctorId(int doctorId) { this.doctorId = doctorId; }
    
    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }
    
    public String getTime() { return time; }
    public void setTime(String time) { this.time = time; }
}