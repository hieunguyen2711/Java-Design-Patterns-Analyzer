package clinic.model;

import java.time.LocalDateTime;
import java.util.Objects;

public class AppointmentSlot {
    private final String id;
    private final