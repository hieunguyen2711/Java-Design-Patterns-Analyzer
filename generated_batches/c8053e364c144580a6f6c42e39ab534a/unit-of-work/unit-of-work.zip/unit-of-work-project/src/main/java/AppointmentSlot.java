public class AppointmentSlot {
    private int id;
    private int doctorId;
    private String dateTime;
    private boolean isAvailable;

    public AppointmentSlot(int id, int doctorId, String dateTime) {
        this.id = id;
        this.doctorId = doctorId;
        this.dateTime = dateTime;
        this.isAvailable = true;
    }

    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getDoctorId() { return doctorId; }
    public void setDoctorId(int doctorId) { this.doctorId = doctorId; }
    
    public String getDateTime() { return dateTime; }
    public void setDateTime(String dateTime) { this.dateTime = dateTime; }
    
    public boolean isAvailable() { return isAvailable; }
    public void setAvailable(boolean available) { isAvailable = available; }
}