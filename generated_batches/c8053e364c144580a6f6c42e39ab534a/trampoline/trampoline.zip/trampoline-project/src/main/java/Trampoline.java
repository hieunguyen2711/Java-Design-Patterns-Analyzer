package clinic;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class Trampoline<T> {
    private final Function<Trampoline<T>, T> computation;
    
    public Trampoline(Function<Trampoline<T>, T> computation) {
        this.computation = computation;
    }
    
    public static <T> Trampoline<T> of(T value) {
        return new Trampoline<>(trampoline -> value);
    }
    
    public static <T> Trampoline<T> from(Function<Trampoline<T>, T> computation) {
        return new Trampoline<>(computation);
    }
    
    public T evaluate() {
        Trampoline<T> current = this;
        while (current.computation != null) {
            T result = current.computation.apply(current);