import java.util.ArrayList;
import java.util.List;

public class AppointmentService {
    private List<Appointment> appointments;
    private List<Visit> visits;
    
    public AppointmentService() {
        this.appointments = new ArrayList<>();
        this.visits = new ArrayList<>();
    }
    
    // Transaction Script: Single method orchestrating multiple operations
    public void scheduleAppointment(Doctor doctor, Patient patient, String dateTime) {
        // Business logic for scheduling appointment
        Appointment appointment = new Appointment(doctor, patient, dateTime);
        appointments.add(appointment);
        
        System.out.println("Appointment scheduled for " + patient.getName() + 
                          " with " + doctor.getName() + " at " + dateTime);
    }
    
    public void checkInPatient(Patient patient) {
        // Business logic for checking in patient
        System.out.println(patient.getName() + " has been checked in");
    }
    
    public void recordVisit(Patient patient, Doctor doctor, String notes