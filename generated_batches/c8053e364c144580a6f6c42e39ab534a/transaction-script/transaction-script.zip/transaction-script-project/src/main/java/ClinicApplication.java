public class ClinicApplication {
    public static void main(String[] args) {
        AppointmentService service = new AppointmentService();
        
        // Create doctor
        Doctor doctor = new Doctor("Dr. Smith", "Cardiology");
        
        // Create patient
        Patient patient = new Patient("John Doe", 35);
        
        // Schedule appointment
        service.scheduleAppointment(doctor, patient, "2023-12-01 10:00");
        
        // Check in patient
        service.checkInPatient(patient);
        
        // Record visit
        service.recordVisit(patient, doctor, "Blood pressure check");
    }
}