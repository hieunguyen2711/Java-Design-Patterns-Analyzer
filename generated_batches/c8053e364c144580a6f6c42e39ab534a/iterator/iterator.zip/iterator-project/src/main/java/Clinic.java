import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Clinic {
    private List<AppointmentSlot> appointmentSlots;
    
    public Clinic() {
        this.appointmentSlots = new ArrayList<>();
    }
    
    public void addAppointment(AppointmentSlot slot) {
        appointmentSlots.add(slot);
    }
    
    public Iterator<AppointmentSlot> getAppointmentIterator() {
        return appointmentSlots.iterator();
    }
}