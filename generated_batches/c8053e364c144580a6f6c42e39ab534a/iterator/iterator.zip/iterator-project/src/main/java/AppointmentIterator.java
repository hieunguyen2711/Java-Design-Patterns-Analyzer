import java.util.Iterator;

public class AppointmentIterator implements Iterator<AppointmentSlot> {
    private Clinic clinic;
    private int currentIndex = 0;
    
    public AppointmentIterator(Clinic clinic) {
        this.clinic = clinic;
    }
    
    @Override
    public boolean hasNext() {
        return currentIndex < clinic.getAppointmentIterator().nextIndex();
    }
    
    @Override
    public AppointmentSlot next() {
        if (!hasNext()) {
            throw new java.util.NoSuchElementException();
        }
        // This is a simplified implementation for demonstration purposes
        Iterator<AppointmentSlot> iterator = clinic.getAppointmentIterator