public class LegacyVisitSystem {
    public void recordVisit(String patientName, String doctorName, String details) {
        System.out.println("Recording visit for " + patientName + 
            " with " + doctorName + ": " + details);
    }
}