public class VisitHistory {
    private String visitDetails;
    
    public VisitHistory(String visitDetails) {
        this.visitDetails = visitDetails;
    }
    
    public String getVisitDetails() {
        return visitDetails;
    }
}