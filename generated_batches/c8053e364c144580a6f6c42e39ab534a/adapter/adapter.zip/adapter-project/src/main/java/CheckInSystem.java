public class CheckInSystem {
    private AppointmentSlot appointment;
    
    public CheckInSystem(AppointmentSlot appointment) {
        this.appointment = appointment;
    }
    
    public void checkInPatient() {
        System.out.println("Checking in patient " + 
            appointment.getPatient().getName() + 
            " for doctor " + 
            appointment.getDoctor().getName());
    }
}