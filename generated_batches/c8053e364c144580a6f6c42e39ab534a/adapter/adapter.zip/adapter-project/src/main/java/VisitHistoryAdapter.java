public class VisitHistoryAdapter {
    private LegacyVisitSystem legacy