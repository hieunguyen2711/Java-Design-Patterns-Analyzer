import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class CheckInService {
    private final ExecutorService executorService;
    
    public CheckInService() {
        this.executorService = Executors.newFixedThreadPool(3);
    }
    
    public void processCheckIn(AppointmentSlot slot) {
        executorService.submit(() -> {
            try {
                // Simulate check-in processing
                Thread.sleep(1000);
                System.out.println("Checked in patient for appointment with " + 
                    slot.getDoctor().getName() + " at " + slot.getDateTime());
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
    }
    
    public void shutdown() {
        executorService.shutdown();
        try {
            if (!executorService.awaitTermination