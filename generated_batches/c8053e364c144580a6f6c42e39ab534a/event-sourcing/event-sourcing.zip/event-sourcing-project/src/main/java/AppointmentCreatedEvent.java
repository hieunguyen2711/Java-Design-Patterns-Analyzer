public class AppointmentCreatedEvent extends AppointmentEvent {
    private final String doctorId;
    private final String patientId;
    private final long slotStartTime;
    private final long slotEndTime;
    
    public AppointmentCreatedEvent(String eventId, String doctorId, String patientId, 
                                 long slotStartTime, long slotEndTime) {
        super(eventId);
        this.doctorId = doctorId;
        this.patientId = patientId;
        this.slotStartTime = slotStartTime;
        this.slotEndTime = slotEndTime;
    }
    
    public String getDoctorId() {
        return doctorId;
    }
    
    public String getPatientId() {
        return patientId;
    }
    
    public long getSlotStartTime() {
        return slotStartTime;
    }
    
    public long getSlotEndTime() {
        return slotEndTime;
    }
    
    @Override
    public String getType() {
        return "APPOINTMENT_CREATED";
    }
}