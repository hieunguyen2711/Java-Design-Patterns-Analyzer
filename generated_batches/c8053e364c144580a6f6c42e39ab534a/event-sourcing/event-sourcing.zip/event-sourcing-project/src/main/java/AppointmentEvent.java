public abstract class AppointmentEvent {
    protected final String eventId;
    protected final long timestamp;
    
    public AppointmentEvent(String eventId) {
        this.eventId = eventId;
        this.timestamp = System.currentTimeMillis();
    }
    
    public String getEventId() {
        return eventId;
    }
    
    public long getTimestamp() {
        return timestamp;
    }
    
    public abstract String getType();
}