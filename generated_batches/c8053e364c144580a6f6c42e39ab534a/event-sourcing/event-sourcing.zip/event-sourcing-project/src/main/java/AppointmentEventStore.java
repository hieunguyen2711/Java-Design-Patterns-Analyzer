import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class AppointmentEventStore {
    private final Map<String, List