public class AppointmentCheckedInEvent extends AppointmentEvent {
    private final String doctorId;
    private final String patientId;
    private final long checkInTime;
    
    public AppointmentCheckedInEvent(String eventId, String doctorId, String patientId, 
                                   long checkInTime) {
        super(eventId);
        this.doctorId = doctorId;
        this.patientId = patientId;
        this.checkInTime = checkInTime;
    }
    
    public String getDoctorId() {
        return doctorId;
    }
    
    public String getPatientId() {
        return patientId;
    }
    
    public long getCheckInTime() {
        return checkInTime;
    }
    
    @Override
    public String getType() {
        return "APPOINTMENT_CHECKED_IN";
    }
}