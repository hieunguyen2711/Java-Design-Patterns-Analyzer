public class Doctor {
    private final String firstName;
    private final String lastName;
    private final String specialty;
    private final int yearsOfExperience;
    
    private Doctor(Builder builder) {
        this.firstName = builder.firstName;
        this.lastName = builder.lastName;
        this.specialty = builder.specialty;
        this.yearsOfExperience = builder.yearsOfExperience;
    }
    
    public String getFirstName() {
        return firstName;
    }
    
    public String getLastName() {
        return lastName;
    }
    
    public String getSpecialty() {
        return specialty;
    }
    
    public int getYearsOfExperience() {
        return yearsOfExperience;
    }
    
    public static class Builder {
        private String firstName;
        private String lastName;
        private String specialty;
        private int yearsOfExperience;
        
        public Builder setFirstName(String firstName) {
            this.firstName = firstName;
            return this;
        }
        
        public Builder setLastName(String lastName) {
            this.lastName = lastName;
            return this;
        }
        
        public Builder setSpecialty(String specialty) {
            this.specialty = specialty;
            return this;
        }
        
        public Builder setYearsOfExperience(int yearsOfExperience) {
            this.yearsOfExperience = yearsOfExperience;
            return this;
        }
        
        public Doctor build() {
            return new Doctor(this);
        }
    }
}