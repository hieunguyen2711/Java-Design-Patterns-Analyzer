public class AppointmentSlot {
    private String id;
    private Doctor doctor;
    private Patient patient;
    private long timestamp;
    
    public AppointmentSlot(String id, Doctor doctor, Patient patient, long timestamp) {
        this.id = id;
        this.doctor = doctor;
        this.patient = patient;
        this.timestamp = timestamp;
    }
    
    public String getId() {
        return id;
    }
    
    public Doctor getDoctor() {
        return doctor;
    }
    
    public Patient getPatient() {
        return patient;
    }
    
    public long getTimestamp() {
        return timestamp;
    }
}