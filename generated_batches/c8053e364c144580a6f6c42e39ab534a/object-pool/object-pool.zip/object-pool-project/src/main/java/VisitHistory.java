public class VisitHistory {
    private String id;
    private Patient patient;
    private Doctor doctor;
    private long visitDate;
    
    public VisitHistory(String id, Patient patient, Doctor doctor, long visitDate) {
        this.id = id;
        this.patient = patient;
        this.doctor = doctor;
        this.visitDate = visitDate;
    }
    
    public String getId() {
        return id