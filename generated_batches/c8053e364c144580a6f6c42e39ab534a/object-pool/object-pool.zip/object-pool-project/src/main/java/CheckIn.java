public class CheckIn {
    private String id;
    private AppointmentSlot appointment;
    private long checkInTime;
    
    public CheckIn(String id, AppointmentSlot appointment, long checkInTime) {
        this.id = id;
        this.appointment = appointment;
        this.checkInTime = checkInTime;
    }
    
    public String getId() {
        return id;
    }
    
    public AppointmentSlot getAppointment() {
        return appointment;
    }
    
    public long getCheckInTime() {
        return checkInTime;
    }
}