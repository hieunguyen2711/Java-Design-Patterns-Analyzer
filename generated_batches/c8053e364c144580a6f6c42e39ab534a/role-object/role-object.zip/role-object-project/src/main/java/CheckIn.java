package clinic;

import java.time.LocalDateTime;

public class CheckIn {
    private Patient patient;
    private AppointmentSlot slot;
    private LocalDateTime checkInTime;
    
    public CheckIn(Patient patient, AppointmentSlot slot) {
        this.patient = patient;
        this.slot = slot;
        this.checkInTime = LocalDateTime.now();
    }
    
    public Patient getPatient() {
        return patient;
    }
    
    public AppointmentSlot getSlot() {
        return slot;
    }
    
    public LocalDateTime getCheckInTime() {
        return checkInTime;
    }
}