package clinic;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class VisitHistory {
    private List<CheckIn> visits;
    
    public