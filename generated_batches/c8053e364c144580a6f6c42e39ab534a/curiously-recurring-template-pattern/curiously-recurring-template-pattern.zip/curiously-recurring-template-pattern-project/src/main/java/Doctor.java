package clinic;

public class Doctor extends Person {
    private String specialty;
    
    public Doctor(String name, int id, String specialty) {
        super(name, id);
        this.specialty = specialty;
    }
    
    public String getSpecialty() {
        return specialty;
    }
}