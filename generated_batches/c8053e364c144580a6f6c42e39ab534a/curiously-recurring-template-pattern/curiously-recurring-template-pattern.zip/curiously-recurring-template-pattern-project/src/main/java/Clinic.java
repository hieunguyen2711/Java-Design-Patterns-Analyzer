package clinic;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Clinic {
    private List<AppointmentSlot<? extends Person>> appointmentSlots;
    
    public Clinic() {
        this.appointmentSlots = new ArrayList<>();
    }
    
    public void scheduleAppointment(LocalDateTime dateTime, Doctor doctor) {
        AppointmentSlot<Doctor> slot = new AppointmentSlot<>(dateTime, doctor);
        appointmentSlots.add(slot);
    }
    
    public void scheduleAppointment(LocalDateTime dateTime, Patient patient) {
        AppointmentSlot<Patient> slot = new AppointmentSlot<>(dateTime, patient);
        appointmentSlots.add(slot);
    }
    
    public List<AppointmentSlot