package clinic;

import java.time.LocalDateTime;

public class AppointmentSlot<T extends Person> {
    private LocalDateTime dateTime;
    private T person;
    private boolean isAvailable;
    
    public AppointmentSlot(LocalDateTime dateTime, T person) {
        this.dateTime = dateTime;
        this.person = person;
        this.isAvailable = false;
    }
    
    public LocalDateTime getDateTime() {
        return dateTime;
    }
    
    public T getPerson() {
        return person;
    }
    
    public boolean isAvailable() {
        return isAvailable;
    }
    
    public void setAvailable(boolean available) {
        isAvailable = available;
    }
}