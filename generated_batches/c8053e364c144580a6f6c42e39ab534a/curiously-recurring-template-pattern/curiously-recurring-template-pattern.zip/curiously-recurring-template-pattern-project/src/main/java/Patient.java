package clinic;

public class Patient extends Person {
    private String medicalHistory;
    
    public Patient(String name, int id, String medicalHistory) {
        super(name, id);
        this.medicalHistory = medicalHistory;
    }
    
    public String getMedicalHistory() {
        return medicalHistory;
    }
}