package clinic;

import java.util.List;
import java.util.ArrayList;

public class Doctor {
    private final String name;
    private final String specialty;
    private final List<Patient> patients;
    
    public Doctor(String name, String specialty) {
        this.name = name;
        this.specialty = specialty;
        this.patients = new ArrayList<>();
    }
    
    public String getName() {
        return name;
    }
    
    public String getSpecialty() {
        return specialty;
    }
    
    public List<Patient> getPatients() {
        // Return unmodifiable view to protect internal state
        return List.copyOf(patients);
    }
    
    public void addPatient(Patient patient) {
        patients.add(patient);
    }
}