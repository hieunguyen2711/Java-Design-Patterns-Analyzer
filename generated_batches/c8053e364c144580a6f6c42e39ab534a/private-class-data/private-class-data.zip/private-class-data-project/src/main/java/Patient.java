package clinic;

import java.util.List;
import java.util.ArrayList;
import java.time.LocalDateTime;

public class Patient {
    private final String name;
    private final int age;
    private final List<Visit> visits;
    
    public Patient(String name, int age) {
        this.name = name;
        this.age = age;
        this.visits = new ArrayList<>();
    }
    
    public String getName() {
        return name;
    }
    
    public int getAge() {
        return age;
    }
    
    public List<Visit> getVisits() {
        // Return unmodifiable view to protect internal state
        return List.copyOf(visits);
    }
    
    public void addVisit(Visit visit) {
        visits.add(visit);
    }
}