package clinic;

import java.time.LocalDateTime;
import java.util.List;
import java.util.ArrayList;

public class Visit {
    private final LocalDateTime dateTime;
    private final Doctor doctor;
    private final Patient patient;
    private final String notes;
    
    public Visit(Doctor doctor, Patient patient, LocalDateTime dateTime, String notes) {
        this.doctor = doctor;
        this.patient = patient;
        this.dateTime = dateTime;
        this.notes = notes;
    }
    
    public LocalDateTime getDateTime() {
        return dateTime;
    }
    
    public Doctor getDoctor() {
        return doctor;
    }
    
    public Patient getPatient() {
        return patient;
    }
    
    public String getNotes() {
        return notes;
    }
}