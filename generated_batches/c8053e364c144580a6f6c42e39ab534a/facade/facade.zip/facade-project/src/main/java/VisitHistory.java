public class VisitHistory {
    public void recordVisit(Patient patient, Doctor doctor) {
        System.out.println("Recording visit for " + patient.getName() + 
                          " with Dr. " + doctor.getName());
    }
    
    public void printHistory(Patient patient) {
        System.out.println("Printing history for " + patient.getName());
    }
}