public class ClinicFacade {
    private CheckInSystem checkInSystem;
    private VisitHistory visitHistory;
    
    public ClinicFacade() {
        this.checkInSystem = new CheckInSystem();
        this.visitHistory = new VisitHistory();
    }
    
    public void processPatientVisit(Patient patient, AppointmentSlot slot) {
        checkInSystem.checkInPatient(patient, slot);
        visitHistory.recordVisit(patient,