public class CheckInSystem {
    public void checkInPatient(Patient patient, AppointmentSlot slot) {
        System.out.println("Checking in " + patient.getName() + 
                          " for appointment with Dr. " + slot.getDoctor().getName());
    }
}