package clinic;

public class Patient extends Person {
    private String medicalRecordNumber;
    private String phoneNumber;
    
    public Patient(String name, String email, String medicalRecordNumber, String phoneNumber) {
        super(name, email);
        this.medicalRecordNumber = medicalRecordNumber;
        this.phoneNumber = phoneNumber;
    }
    
    public String getMedicalRecordNumber() {
        return medicalRecordNumber;
    }
    
    public String getPhoneNumber() {
        return phoneNumber;
    }
}