package clinic;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PersonDAO {
    private Connection connection;
    
    public PersonDAO(Connection connection) {
        this.connection = connection;
    }
    
    public List<Person> getAllPersons() throws SQLException {
        List<Person> persons = new ArrayList<>();
        String sql = "SELECT * FROM persons";
        
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String email = rs.getString("email");
                String type = rs.getString("type");
                
                if ("Doctor".equals(type)) {
                    String specialty = rs.getString("specialty");
                    int licenseNumber = rs.getInt("license_number");
                    persons.add(new Doctor(name, email, specialty, licenseNumber));
                } else if ("Patient".equals(type)) {
                    String medicalRecordNumber = rs.getString("medical_record_number