package clinic;

public class Doctor extends Person {
    private String specialty;
    private int licenseNumber;
    
    public Doctor(String name, String email, String specialty, int licenseNumber) {
        super(name, email);
        this.specialty = specialty;
        this.licenseNumber = licenseNumber;
    }
    
    public String getSpecialty() {
        return specialty;
    }
    
    public int getLicenseNumber() {
        return licenseNumber;
    }
}