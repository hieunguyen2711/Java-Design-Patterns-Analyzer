package hotel.booking;

import java.time.LocalDateTime;
import java.util.UUID;

public class RoomBooking {
    private final UUID id;
    private final LocalDateTime checkIn;
    private final LocalDateTime checkOut;
    
    public RoomBooking(LocalDateTime checkIn, LocalDateTime checkOut) {
        this.id = UUID.randomUUID();
        this.checkIn = checkIn;
        this.checkOut = checkOut;
    }
    
    public UUID getId() {
        return id;
    }
    
    public LocalDateTime getCheckIn() {
        return checkIn;
    }
    
    public LocalDateTime getCheckOut() {
        return checkOut;
    }
}