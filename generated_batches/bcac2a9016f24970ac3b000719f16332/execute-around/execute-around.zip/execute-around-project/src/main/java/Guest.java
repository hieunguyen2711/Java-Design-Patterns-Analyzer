package hotel.guest;

import java.util.UUID;

public class Guest {
    private final UUID id;
    private final String name;
    
    public Guest(String name) {
        this.id = UUID.randomUUID();
        this.name = name;
    }
    
    public UUID getId() {
        return id;
    }
    
    public String getName() {
        return name;
    }
}