package hotel.demo;

import hotel.booking.RoomBooking;
import hotel.guest.Guest;
import hotel.inventory.RoomInventoryService;
import hotel.billing.BillingService;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.concurrent.atomic.AtomicLong;

public class ExecuteAroundPatternDemo {
    
    public static void main(String