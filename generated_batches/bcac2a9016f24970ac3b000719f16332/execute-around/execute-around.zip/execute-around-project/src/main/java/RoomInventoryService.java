package hotel.inventory;

import java.util.concurrent.atomic.AtomicLong;

public class RoomInventoryService {
    private final AtomicLong availableRooms = new AtomicLong(100);
    
    public long getAvailableRooms() {
        return availableRooms.get();
    }
    
    public boolean bookRoom() {
        long current;
        do {
            current = availableRooms.get();
            if (current <= 0) {
                return false;
            }
        } while (!availableRooms.compareAndSet(current, current - 1));
        return true;
    }
}