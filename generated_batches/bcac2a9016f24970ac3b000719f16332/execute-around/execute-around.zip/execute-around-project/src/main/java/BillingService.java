package hotel.billing;

import java.math.BigDecimal;
import java.util.concurrent.atomic.AtomicLong;

public class BillingService {
    private final AtomicLong totalRevenue = new AtomicLong(0);
    
    public void processPayment(BigDecimal amount) {
        totalRevenue.addAndGet(amount.longValue());
    }
    
    public long getTotalRevenue() {
        return totalRevenue.get();
    }
}