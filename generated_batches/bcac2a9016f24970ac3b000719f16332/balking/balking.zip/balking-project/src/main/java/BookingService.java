package hotel.booking;

import hotel.inventory.RoomInventory;

public class BookingService {
    private final RoomInventory inventory;
    
    public BookingService(RoomInventory inventory) {
        this.inventory = inventory;
    }
    
    public boolean bookRoom(String roomNumber, int quantity) {
        // Balking pattern: if inventory update is in progress, don't proceed
        return inventory.updateInventory(roomNumber, quantity);
    }
}