package hotel.inventory;

import java.util.concurrent.atomic.AtomicBoolean;

public class RoomInventory {
    private final AtomicBoolean isUpdating = new AtomicBoolean(false);
    
    public boolean updateInventory(String roomNumber, int quantity) {
        // Balking pattern: if already updating, don't proceed
        if (isUpdating.get()) {
            return false;
        }
        
        try {
            // Mark as updating
            if (!isUpdating.compareAndSet(false, true)) {
                return false; // Another thread got there first
            }
            
            // Simulate inventory update work
            Thread.sleep(100);
            System.out.println("Updated room " + roomNumber + " inventory to " + quantity);
            return true;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        } finally {
            // Always release the lock
            isUpdating.set(false);
        }
    }
}