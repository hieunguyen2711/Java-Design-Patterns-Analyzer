package hotel;

import hotel.booking.BookingService;
import hotel.inventory.RoomInventory;

public class Main {
    public static void main(String[] args) {
        RoomInventory inventory = new RoomInventory();
        BookingService bookingService = new BookingService(inventory);
        
        // Simulate concurrent booking requests
        Thread t1 = new Thread(() -> {
            boolean result = bookingService.bookRoom("101", 5);
            System.out.println("Booking 101: " + result);
        });
        
        Thread t2 = new Thread(() -> {
            boolean result = bookingService.bookRoom("101", 3);
            System.out.println("Booking 101: " + result);
        });
        
        t1.start();
        t2.start();
        
        try {
            t1.join();
            t2.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}