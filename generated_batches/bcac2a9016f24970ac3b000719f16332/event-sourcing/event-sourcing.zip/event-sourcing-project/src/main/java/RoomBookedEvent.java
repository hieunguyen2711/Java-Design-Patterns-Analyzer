public class RoomBookedEvent extends RoomInventoryEvent {
    private final String roomId;
    private final String guestId;
    private final long checkInDate;
    private final long checkOutDate;

    public RoomBookedEvent(String eventId, String roomId, String guestId, long checkInDate, long checkOutDate) {
        super(eventId);
        this.roomId = roomId;
        this.guestId = guestId;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
    }

    public String getRoomId() {
        return roomId;
    }

    public String getGuestId() {
        return guestId;
    }

    public long getCheckInDate() {
        return checkInDate;
    }

    public long getCheckOutDate() {
        return checkOutDate;
    }

    @Override
    public String getType() {
        return "ROOM_BOOKED";
    }
}