public class RoomCheckedInEvent extends RoomInventoryEvent {
    private final String roomId;
    private final String guestId;

    public RoomCheckedInEvent(String eventId, String roomId, String guestId) {
        super(eventId);
        this.roomId = roomId;
        this.guestId = guestId;
    }

    public String getRoomId() {
        return roomId;
    }

    public String getGuestId() {
        return guestId;
    }

    @Override
    public String getType() {
        return "ROOM_CHECKED_IN";
    }
}