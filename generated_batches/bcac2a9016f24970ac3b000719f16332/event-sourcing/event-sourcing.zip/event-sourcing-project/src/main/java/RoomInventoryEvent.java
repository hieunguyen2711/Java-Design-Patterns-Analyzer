public abstract class RoomInventoryEvent {
    private final String eventId;
    private final long timestamp;

    public RoomInventoryEvent(String eventId) {
        this.eventId = eventId;
        this.timestamp = System.currentTimeMillis();
    }

    public String getEventId() {
        return eventId;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public abstract String getType();
}