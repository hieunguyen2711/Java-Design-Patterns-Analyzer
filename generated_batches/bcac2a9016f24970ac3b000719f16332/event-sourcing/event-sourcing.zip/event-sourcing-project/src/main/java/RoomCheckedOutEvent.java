public class RoomCheckedOutEvent extends RoomInventoryEvent {
    private final String roomId;
    private final String guestId;
    private final double totalAmount;

    public RoomCheckedOutEvent(String eventId, String roomId, String guestId, double totalAmount) {
        super(eventId);
        this.roomId = roomId;
        this.guestId = guestId;