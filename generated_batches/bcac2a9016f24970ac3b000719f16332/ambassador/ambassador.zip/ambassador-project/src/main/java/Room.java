package com.hotel.inventory;

public class Room {
    private String roomId;
    private int capacity;
    private double basePrice;
    
    public Room(String roomId, int capacity, double basePrice) {
        this.roomId = roomId;
        this.capacity = capacity;
        this.basePrice = basePrice;
    }
    
    // Getters and setters
    public String getRoomId() { return roomId; }
    public void setRoomId(String roomId) { this.roomId = roomId; }
    
    public int getCapacity() { return capacity; }
    public void setCapacity(int capacity) { this.capacity = capacity; }
    
    public double getBasePrice() { return basePrice; }
    public void setBasePrice(double basePrice) { this.basePrice = basePrice; }
}