package com.hotel.inventory;

import java.time.LocalDate;
import java.util.List;

public class Booking {
    private String bookingId;
    private String guestName;
    private List<String> roomIds;
    private LocalDate checkInDate;
    private LocalDate checkOutDate;
    
    public Booking(String bookingId, String guestName, List<String> roomIds, 
                  LocalDate checkInDate, LocalDate checkOutDate) {
        this.bookingId = bookingId;
        this.guestName = guestName;
        this.roomIds = roomIds;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
    }
    
    // Getters and setters
    public String getBookingId() { return bookingId; }
    public