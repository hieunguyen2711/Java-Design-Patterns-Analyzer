package com.hotel.inventory;

import java.util.*;

public class RoomInventory {
    private static volatile RoomInventory instance;
    private Map<String, Room> rooms;
    
    private RoomInventory() {
        rooms = new HashMap<>();
    }
    
    public static RoomInventory getInstance() {
        if (instance == null) {
            synchronized (RoomInventory.class) {
                if (instance == null) {
                    instance = new RoomInventory();
                }
            }
        }
        return instance;
    }
    
    public void addRoom(Room room) {
        rooms.put(room.getRoomId(), room);
    }
    
    public Room getRoom(String roomId) {
        return rooms.get(roomId);
    }
    
    public Collection<Room> getAllRooms() {
        return new ArrayList<>(rooms.values());
    }
}