package hotel.system;

public interface PricingPlan {
    double calculatePrice(Room room, int numberOfNights);
}