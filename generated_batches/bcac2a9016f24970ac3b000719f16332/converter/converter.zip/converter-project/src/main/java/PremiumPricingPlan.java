package hotel.system;

public class PremiumPricingPlan implements PricingPlan {
    @Override
    public double calculatePrice(Room room, int numberOfNights) {
        return (room.getBasePrice() * 1.5) * numberOfNights;
    }
}