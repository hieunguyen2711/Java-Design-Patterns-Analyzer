package hotel.system;

public class Room {
    private String roomId;
    private String type;
    private double basePrice;
    
    public Room(String roomId, String type, double basePrice) {
        this.roomId = roomId;
        this.type = type;
        this.basePrice = basePrice;
    }
    
    // Getters and setters
    public String getRoomId() { return roomId; }
    public void setRoomId(String roomId) { this.roomId = roomId; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public double getBasePrice() { return basePrice; }
    public void setBasePrice(double basePrice) { this.basePrice = basePrice; }
}