package hotel.system;

public class StandardPricingPlan implements PricingPlan {
    @Override
    public double calculatePrice(Room room, int numberOfNights) {
        return room.getBasePrice() * numberOfNights;
    }
}