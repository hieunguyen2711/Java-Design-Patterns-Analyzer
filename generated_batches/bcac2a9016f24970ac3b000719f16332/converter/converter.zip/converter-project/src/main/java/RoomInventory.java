package hotel.system;

import java.util.List;
import java.util.ArrayList;

public class RoomInventory {
    private List<Room> rooms = new ArrayList<>();
    
    public void addRoom(Room room) {
        rooms.add(room);
    }
    
    public List<Room> getRooms() {
        return rooms;
    }
}