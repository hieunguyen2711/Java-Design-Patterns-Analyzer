package hotel.system;

public class BillingService {
    private PricingPlan pricingPlan;
    
    public BillingService(PricingPlan pricingPlan) {
        this.pricingPlan = pricingPlan;
    }
    
    public double calculateTotal(Room room, int numberOfNights) {
        return pricingPlan.calculatePrice(room, numberOfNights);
    }
}