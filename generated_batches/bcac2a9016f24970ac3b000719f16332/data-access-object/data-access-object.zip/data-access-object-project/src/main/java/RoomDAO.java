package com.example.hotel;

import java.util.List;

public interface RoomDAO {
    Room getRoomById(int id);
    List<Room> getAllRooms();
    void saveRoom(Room room);
    void updateRoom(Room room);
    void deleteRoom(int id);
}