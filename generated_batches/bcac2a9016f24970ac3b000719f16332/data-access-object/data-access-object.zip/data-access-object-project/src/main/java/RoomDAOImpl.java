package com.example.hotel;

import java.util.ArrayList;
import java.util.List;

public class RoomDAOImpl implements RoomDAO {
    private List<Room> rooms;
    
    public RoomDAOImpl() {
        this.rooms = new ArrayList<>();
        // Initialize with some sample data
        rooms.add(new Room(1, "101", "Single", 100.0));
        rooms.add(new Room(2, "102", "Double", 150.0));
        rooms.add(new Room(3, "103", "Suite", 300.0));
    }
    
    @Override
    public Room getRoomById(int id) {
        for (Room room : rooms) {
            if (room.getRoomId() == id) {
                return room;
            }
        }
        return null;
    }
    
    @Override
    public List<Room> getAllRooms()