public class CheckInRequest extends Request {
    private final String guestName;
    private final String roomNumber;
    
    public CheckInRequest(String guestName, String roomNumber) {
        this.guestName = guestName;
        this.roomNumber = roomNumber;
    }
    
    @Override
    public void execute() {
        System.out.println("Processing check-in for " + guestName + 
                          " in room " + roomNumber);
        // Simulate processing time
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        System.out.println("Check-in completed for " + guestName);
    }
}