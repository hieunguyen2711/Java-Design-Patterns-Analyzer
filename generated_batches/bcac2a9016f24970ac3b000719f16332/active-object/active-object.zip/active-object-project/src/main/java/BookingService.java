import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class BookingService implements ActiveObject {
    private final BlockingQueue<Request> requestQueue = new LinkedBlockingQueue<>();
    
    public BookingService() {
        startProcessing();
    }
    
    @Override
    public void scheduleRequest(Request request) {
        try {
            requestQueue.put(request);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
    
    private void startProcessing() {
        new Thread(() -> {
            while (!Thread.currentThread().isInterrupted()) {
                try {
                    Request request = requestQueue.take();
                    request.execute();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }).start();
    }
}