public class CheckOutRequest extends Request {
    private final String guestName;
    private final String roomNumber;
    
    public CheckOutRequest(String guestName, String roomNumber) {
        this.guestName = guestName;
        this.roomNumber = roomNumber;
    }
    
    @Override
    public void execute() {
        System.out.println("Processing check-out for " + guestName + 
                          " from room " + roomNumber);
        // Simulate processing time
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();