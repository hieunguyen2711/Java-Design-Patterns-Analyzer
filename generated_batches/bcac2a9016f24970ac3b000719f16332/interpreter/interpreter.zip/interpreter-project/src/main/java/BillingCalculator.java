public class BillingCalculator {
    private final PricingPlan pricingPlan;
    
    public BillingCalculator(PricingPlan pricingPlan) {
        this.pricingPlan = pricingPlan;