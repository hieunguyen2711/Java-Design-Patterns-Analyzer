public class RoomInventory {
    private final String roomType;
    private final int capacity;
    
    public RoomInventory(String roomType, int capacity) {
        this.roomType = roomType;
        this.capacity = capacity;
    }
    
    public String getRoomType() {
        return roomType;
    }
    
    public int getCapacity() {
        return capacity;
    }
}