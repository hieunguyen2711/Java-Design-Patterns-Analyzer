public class Booking {
    private final RoomInventory room;
    private final int numberOfNights;
    private final boolean isCheckIn;
    
    public Booking(RoomInventory room, int numberOfNights, boolean isCheckIn) {
        this.room = room;
        this.numberOfNights = numberOfNights;
        this.isCheckIn = isCheckIn;
    }
    
    public RoomInventory getRoom() {
        return room;
    }
    
    public int getNumberOfNights() {
        return numberOfNights;
    }
    
    public boolean isCheckIn() {
        return isCheckIn;
    }
}