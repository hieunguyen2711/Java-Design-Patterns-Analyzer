public class PremiumPricingPlan implements PricingPlan {
    private final double baseRatePerNight;
    private final double premiumSurcharge;
    
    public PremiumPricingPlan(double baseRatePerNight, double premiumSurcharge) {
        this.baseRatePerNight = baseRatePerNight;
        this.premiumSurcharge = premiumSurcharge;
    }
    
    @Override
    public double calculatePrice(Booking booking) {
        return (baseRatePerNight + premiumSurcharge) * booking.getNumberOfNights();
    }
}