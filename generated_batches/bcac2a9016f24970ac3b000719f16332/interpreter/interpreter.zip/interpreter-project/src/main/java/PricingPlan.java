public interface PricingPlan {
    double calculatePrice(Booking booking);
}