public class StandardPricingPlan implements PricingPlan {
    private final double baseRatePerNight;
    
    public StandardPricingPlan(double baseRatePerNight) {
        this.baseRatePerNight = baseRatePerNight;
    }
    
    @Override
    public double calculatePrice(Booking booking) {
        return baseRatePerNight * booking.getNumberOfNights();
    }
}