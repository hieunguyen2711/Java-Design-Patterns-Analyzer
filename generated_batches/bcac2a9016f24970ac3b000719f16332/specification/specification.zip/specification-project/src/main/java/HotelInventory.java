package hotel.inventory;

import java.util.ArrayList;
import java.util.List;

public class HotelInventory {
    private List<Room> rooms;
    
    public HotelInventory() {
        this.rooms = new ArrayList<>();
    }
    
    public void addRoom(Room room) {
        rooms.add(room);
    }
    
    public Room findAvailableRoom(String type) {
        for (Room room : rooms) {
            if (room.isAvailable() && room.getType().equalsIgnoreCase(type)) {
                return room;
            }
        }
        return null;
    }
    
    public List<Room> getAllRooms() {
        return new ArrayList<>(rooms);
    }
}