package hotel.inventory;

public class RoomFactory {
    public static Room createRoom(int roomId, String type) {
        switch (type.toLowerCase()) {
            case "single":
                return new Room(roomId, "Single");
            case "double":
                return new Room(roomId, "Double");
            case "suite":
                return new Room(roomId, "Suite");
            default:
                throw new IllegalArgumentException("Unknown room type: " + type);
        }
    }
}