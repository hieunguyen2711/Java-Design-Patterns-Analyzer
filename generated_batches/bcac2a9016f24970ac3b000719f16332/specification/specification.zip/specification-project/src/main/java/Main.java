package hotel.inventory;

public class Main {
    public static void main(String[] args) {
        HotelInventory inventory = new HotelInventory();
        
        //