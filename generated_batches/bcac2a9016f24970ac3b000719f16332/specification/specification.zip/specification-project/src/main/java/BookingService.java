package hotel.inventory;

public class BookingService {
    private HotelInventory inventory;
    
    public BookingService(HotelInventory inventory) {
        this.inventory = inventory;
    }
    
    public Room bookRoom(String type) {
        Room room = inventory.findAvailableRoom(type);
        if (room != null) {
            room.setAvailable(false);
            return room;
        }
        return null;
    }
}