package com.example.roominventory;

public class BookingPage {
    
    public void display() {
        System.out.println("=== Booking Page ===");
        // Simulate booking logic
        System.out.println("Booking room for guest...");
    }
}