package com.example.roominventory;

public class RoomInventorySystem {
    public static void main(String[] args) {
        // Simulate page controller handling different requests
        PageController controller = new PageController();
        
        // Handle room listing request
        controller.handleRequest("listRooms");
        
        // Handle booking request
        controller.handleRequest("bookRoom");
        
        // Handle check-in request
        controller.handleRequest("checkIn");
    }
}