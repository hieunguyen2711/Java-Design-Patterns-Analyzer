package com.example.roominventory;

public class PageController {
    
    public void handleRequest(String action) {
        switch (action) {
            case "listRooms":
                RoomListingPage page1 = new RoomListingPage();
                page1.display();
                break;
            case "bookRoom":
                BookingPage page2 = new BookingPage();
                page2.display();
                break;
            case "checkIn":
                CheckInPage page3 = new CheckInPage();
                page3.display();
                break;
            default:
                System.out.println("Unknown action: " + action);
        }
    }
}