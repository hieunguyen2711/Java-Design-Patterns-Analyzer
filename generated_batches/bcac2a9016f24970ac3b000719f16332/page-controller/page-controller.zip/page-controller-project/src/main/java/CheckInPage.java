package com.example.roominventory;

public class CheckInPage {
    
    public void display() {
        System.out.println("=== Check-In Page ===");
        // Simulate check-in logic
        System.out.println("Processing guest check-in...");
    }
}