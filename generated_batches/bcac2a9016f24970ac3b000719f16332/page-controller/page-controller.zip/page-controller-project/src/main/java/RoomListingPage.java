package com.example.roominventory;

public class RoomListingPage {
    
    public void display() {
        System.out.println("=== Room Listing Page ===");
        // Simulate room listing logic
        System.out.println("Displaying available rooms...");
    }
}