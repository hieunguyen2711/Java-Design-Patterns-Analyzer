package com.hotel.inventory;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class RoomInventorySystem {
    private final ExecutorService executorService;
    
    public RoomInventorySystem() {
        this.executorService = Executors.newFixedThreadPool(3);
    }
    
    public void processBooking(String bookingId, String guestName) {
        executorService.submit(new BookingTask(bookingId, guestName));
    }
    
    public void processCheckIn(String roomId, String guestName) {
        executorService.submit(new CheckInTask(roomId, guestName));
    }
    
    public void shutdown() {
        executorService.shutdown();
        try {
            if (!executorService.awaitTermination(60, TimeUnit.SECONDS)) {
                executorService.shutdownNow();
            }
        } catch (InterruptedException e) {
            executorService.shutdownNow();
        }
    }
}