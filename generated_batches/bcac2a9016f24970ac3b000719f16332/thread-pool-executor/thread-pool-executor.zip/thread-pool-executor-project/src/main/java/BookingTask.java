package com.hotel.inventory;

public class BookingTask implements Runnable {
    private final String bookingId;
    private final String guestName;
    
    public BookingTask(String bookingId, String guestName) {
        this.bookingId = bookingId;
        this.guestName = guestName;
    }
    
    @Override
    public void run() {
        System.out.println("Processing booking " + bookingId + 
                          " for guest " + guestName);
        
        // Simulate some processing time
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        System.out.println("Booking " + bookingId + " completed");
    }
}