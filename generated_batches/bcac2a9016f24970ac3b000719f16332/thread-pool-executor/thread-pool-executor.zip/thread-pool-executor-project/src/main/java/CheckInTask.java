package com.hotel.inventory;

public class CheckInTask implements Runnable {
    private final String roomId;
    private final String guestName;
    
    public CheckInTask(String roomId, String guestName) {
        this.roomId = roomId;
        this.guestName = guestName;
    }
    
    @Override
    public void run() {
        System.out.println("Processing check-in for room " + roomId + 
                          " guest " + guestName);
        
        // Simulate some processing time
        try {
            Thread.sleep(1500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        System.out.println("Check-in for room " + roomId + "