public class RoomInventorySystem {
    private final RoomService roomService;
    private final BookingService bookingService;
    private final BillingService billingService;
    
    public RoomInventorySystem() {
        this.roomService = new RoomService();
        this.bookingService = new BookingService();
        this.billingService = new BillingService();
    }
    
    public void processGuestCheckIn(String guestName, int roomId) {
        roomService.assignRoom(roomId);
        bookingService.createBooking(guestName, roomId);
        billingService.setupBillingAccount(guestName, roomId);
    }
    
    public void processGuestCheckOut(String guestName, int roomId) {
        billingService.processPayment(guestName, roomId);
        bookingService.completeBooking(guestName, roomId);
        roomService.releaseRoom(roomId);
    }
}