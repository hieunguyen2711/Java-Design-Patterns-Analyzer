public class RoomService {
    public void assignRoom(int roomId) {
        System.out.println("Room " + roomId + " assigned to guest");
    }
    
    public void releaseRoom(int roomId) {
        System.out.println("Room " + roomId + " released");
    }
}