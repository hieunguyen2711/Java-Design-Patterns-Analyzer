public class BookingService {
    public void createBooking(String guestName, int roomId) {
        System.out.println("Booking created for " + guestName + " in room " + roomId);
    }
    
    public void completeBooking(String guestName, int roomId) {
        System.out.println("Booking completed for " + guestName + " in room " + roomId);
    }
}