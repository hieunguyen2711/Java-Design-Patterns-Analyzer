public class Main {
    public static void main(String[] args) {
        RoomInventorySystem system = new RoomInventorySystem();
        
        System.out.println("=== Guest Check-In ===");
        system.processGuestCheckIn("John Doe", 101);
        
        System.out.println("\n=== Guest Check-Out ===");
        system.processGuestCheckOut("John