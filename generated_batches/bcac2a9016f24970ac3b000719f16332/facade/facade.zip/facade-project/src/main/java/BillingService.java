public class BillingService {
    public void setupBillingAccount(String guestName, int roomId) {
        System.out.println("Billing account set up for " + guestName + " in room " + roomId);
    }
    
    public void processPayment(String guestName, int roomId) {
        System.out.println("Payment processed for " + guestName + " in room " + roomId);
    }
}