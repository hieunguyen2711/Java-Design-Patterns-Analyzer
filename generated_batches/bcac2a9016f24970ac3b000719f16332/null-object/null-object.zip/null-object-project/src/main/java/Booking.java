package hotel;

public class Booking {
    private final int bookingId;
    private Guest guest;
    private Room room;
    private boolean isActive;
    
    public Booking(int bookingId) {
        this.bookingId = bookingId;
        this.guest = null;
        this.room = null;
        this.isActive = false;
    }
    
    public int getBookingId() {
        return bookingId;
    }
    
    public Guest getGuest() {
        return guest;
    }
    
    public void setGuest(Guest guest) {
        this.guest = guest;
    }
    
    public Room getRoom() {
        return room;
    }
    
    public void setRoom(Room room) {
        this.room = room;
    }
    
    public boolean isActive() {
        return isActive;
    }
    
    public void setActive(boolean active) {
        isActive = active;
    }
}