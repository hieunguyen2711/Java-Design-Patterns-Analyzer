package hotel;

public class NullBooking extends Booking {
    private static final NullBooking INSTANCE = new NullBooking();
    
    private NullBooking() {
        super(-1);
    }
    
    public static NullBooking getInstance() {
        return INSTANCE;
    }
    
    @Override
    public Guest getGuest() {
        return null;
    }
    
    @Override
    public Room getRoom() {
        return null;
    }
    
    @Override
    public boolean isActive() {
        return false;
    }
}