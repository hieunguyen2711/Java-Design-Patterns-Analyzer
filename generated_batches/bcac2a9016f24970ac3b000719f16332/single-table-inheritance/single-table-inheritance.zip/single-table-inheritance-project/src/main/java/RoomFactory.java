package hotel.inheritance;

public class RoomFactory {
    
    public static Room createRoom(String roomType, int roomId, double basePrice) {
        switch (roomType.toLowerCase()) {
            case "standard":
                return new StandardRoom(roomId, basePrice);
            case "suite":
                return new SuiteRoom(roomId, basePrice);
            case "deluxe":
                return new DeluxeRoom(roomId, basePrice);
            default:
                throw new IllegalArgumentException("Unknown room type: " + roomType);
        }
    }
}