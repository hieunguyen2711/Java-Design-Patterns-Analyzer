package hotel.inheritance;

public abstract class Room {
    protected int roomId;
    protected String roomType;
    protected double basePrice;
    
    public Room(int roomId, String roomType, double basePrice) {
        this.roomId = roomId;
        this.roomType = roomType;
        this.basePrice = basePrice;
    }
    
    public abstract double calculateFinalPrice(int numberOfNights);
    
    // Getters
    public int getRoomId() { return roomId; }
    public String getRoomType() { return roomType; }
    public double getBasePrice() { return basePrice; }
}