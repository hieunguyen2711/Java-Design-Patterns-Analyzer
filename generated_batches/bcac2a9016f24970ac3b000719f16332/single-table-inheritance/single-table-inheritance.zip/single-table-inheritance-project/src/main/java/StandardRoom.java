package hotel.inheritance;

public class StandardRoom extends Room {
    
    public StandardRoom(int roomId, double basePrice) {
        super(roomId, "Standard", basePrice);
    }
    
    @Override
    public double calculateFinalPrice(int numberOfNights) {
        return basePrice * numberOfNights;
    }
}