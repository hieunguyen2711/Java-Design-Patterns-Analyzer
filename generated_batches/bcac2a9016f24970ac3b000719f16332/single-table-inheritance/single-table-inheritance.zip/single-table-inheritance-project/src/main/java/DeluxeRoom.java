package hotel.inheritance;

public class DeluxeRoom extends Room {
    
    public DeluxeRoom(int roomId, double basePrice) {
        super(roomId, "Deluxe", basePrice);
    }
    
    @Override
    public double calculateFinalPrice(int numberOfNights) {
        return basePrice * numberOfNights * 2.0;
    }
}