package hotel.inheritance;

public class SuiteRoom extends Room {
    
    public SuiteRoom(int roomId, double basePrice) {
        super(roomId, "Suite", basePrice);
    }
    
    @Override
    public double calculateFinalPrice(int numberOfNights) {
        return basePrice * numberOfNights * 1.5;
    }
}