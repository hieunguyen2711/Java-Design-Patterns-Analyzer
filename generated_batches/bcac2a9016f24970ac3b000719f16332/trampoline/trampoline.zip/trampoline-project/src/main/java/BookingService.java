package com.hotel.inventory;

import java.util.List;
import java.util.function.Function;

public class BookingService {
    
    public List<RoomInventory.Room> findAvailableRooms(RoomInventory inventory, 
                                                      Function<RoomInventory.Room, Boolean> filter) {
        return inventory.findAvailableRooms(filter).result();
    }
}