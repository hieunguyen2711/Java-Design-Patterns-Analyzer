package com.hotel.inventory;

import java.util.List;
import java.util.ArrayList;
import java.util.function.Function;

public class RoomInventory {
    private List<Room> rooms = new ArrayList<>();
    
    public void addRoom(Room room) {
        rooms.add(room);
    }
    
    public Trampoline<List<Room>> findAvailableRooms(Function<Room, Boolean> filter) {
        return new Trampoline<List<Room>>() {
            @Override
            protected Trampoline<List<Room>> compute() {
                List<Room> available = new ArrayList<>();
                for (Room room : rooms) {
                    if (filter.apply(room)) {
                        available.add(room);
                    }
                }
                return done(available);
            }
        };
    }
    
    public static class Room {
        private String id;
        private int capacity;
        
        public Room(String id, int capacity) {
            this.id = id;
            this.capacity = capacity;
        }
        
        public String getId() { return id; }
        public int getCapacity() { return capacity; }
    }
}