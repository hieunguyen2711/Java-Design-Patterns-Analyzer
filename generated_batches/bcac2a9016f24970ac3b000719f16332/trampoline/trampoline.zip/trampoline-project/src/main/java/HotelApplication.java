package com.hotel.inventory;

import java.util.function.Function;

public class HotelApplication {
    
    public static void main(String[]