package com.hotel.inventory;

public abstract class Trampoline<T> {
    
    protected abstract Trampoline<T> compute();
    
    public T result() {
        Trampoline<T> current = this;
        while (true) {
            if (current instanceof Done) {
                return ((Done<T>) current).value;
            }
            current = current.compute();
        }
    }
    
    public static <T> Trampoline<T> done(T value) {
        return new Done<>(value);
    }
    
    private static class Done<T> extends Trampoline<T> {
        private final T value;
        
        public Done(T value) {
            this.value = value;
        }
        
        @Override
        protected Trampoline<T> compute() {
            return this;
        }
    }
}