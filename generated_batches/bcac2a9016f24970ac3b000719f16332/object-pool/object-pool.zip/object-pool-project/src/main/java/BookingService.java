public class BookingService {
    
    public Room bookRoom() {
        RoomPool pool = RoomPool.getInstance();
        Room room = pool.acquireRoom();
        
        if (room != null) {
            System.out.println("Room " + room.getRoomId() + " booked successfully.");
        } else {
            System.out.println("No rooms available for booking.");
        }
        
        return room;
    }

    public void checkOut(Room room) {
        RoomPool pool = RoomPool.getInstance();
        if (room != null) {