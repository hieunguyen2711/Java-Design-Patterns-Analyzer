import java.util.ArrayDeque;
import java.util.Deque;

public class RoomPool {
    private static RoomPool instance;
    private Deque<Room> availableRooms;
    private Deque<Room> occupiedRooms;

    private RoomPool() {
        availableRooms = new ArrayDeque<>();
        occupiedRooms = new ArrayDeque<>();
        
        // Initialize with some rooms
        for (int i = 1; i <= 5; i++) {
            availableRooms.push(new Room(i, "Standard"));
        }
    }

    public static synchronized RoomPool getInstance() {
        if (instance == null) {
            instance = new RoomPool();
        }
        return instance;
    }

    public Room acquireRoom() {
        Room room = availableRooms.pollLast();
        if (room != null) {
            occupiedRooms.push(room);
            room.setAvailable(false);
        }
        return room;
    }

    public void releaseRoom(Room room) {
        if (room != null && !room.isAvailable()) {
            occupiedRooms.remove(room);
            availableRooms.push(room);
            room.setAvailable(true);
        }
    }

    public int getAvailableRoomsCount() {
        return availableRooms.size();
    }

    public int getOccupiedRoomsCount() {
        return occupiedRooms.size();
    }
}