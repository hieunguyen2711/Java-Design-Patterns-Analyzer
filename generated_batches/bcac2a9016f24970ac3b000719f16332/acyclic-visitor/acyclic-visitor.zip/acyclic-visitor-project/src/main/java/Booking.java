public class Booking {
    private String bookingId;
    private Room room;
    private int nights;
    
    public Booking(String bookingId, Room room, int nights) {
        this.bookingId = bookingId;
        this.room = room;
        this.nights = nights;
    }
    
    public void accept(RoomVisitor visitor) {
        visitor.visit(this);
    }
    
    public String getBookingId() {
        return bookingId;
    }
    
    public Room getRoom() {
        return room;
    }
    
    public int getNights() {
        return nights;
    }
}