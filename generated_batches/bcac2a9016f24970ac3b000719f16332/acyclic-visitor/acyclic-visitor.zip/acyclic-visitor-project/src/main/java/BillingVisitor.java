public class BillingVisitor implements RoomVisitor {
    private double totalAmount;
    
    @Override
    public void visit(Room room) {
        // Calculate price based on room type and base price
        if (room.getRoomId().startsWith("S")) {
            totalAmount += room.getBasePrice() * 1.2; // Suite premium
        } else {
            totalAmount += room.getBasePrice();
        }
    }
    
    @Override
    public void visit(Booking booking) {
        // Apply discount for longer stays
        double baseTotal = booking.getRoom().getBasePrice() * booking