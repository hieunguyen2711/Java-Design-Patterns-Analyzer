public class Guest {
    private String guestId;
    private String name;
    
    public Guest(String guestId, String name) {
        this.guestId = guestId;
        this.name = name;
    }
    
    public void accept(RoomVisitor visitor) {
        visitor.visit(this);
    }
    
    public String getGuestId() {
        return guestId;
    }
    
    public String getName() {
        return name;
    }
}