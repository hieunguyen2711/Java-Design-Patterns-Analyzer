public class Room {
    private String roomId;
    private double basePrice;
    
    public Room(String roomId, double basePrice) {
        this.roomId = roomId;
        this.basePrice = basePrice;
    }
    
    public void accept(RoomVisitor visitor) {
        visitor.visit(this);
    }
    
    public String getRoomId() {
        return roomId;
    }
    
    public double getBasePrice() {
        return basePrice;
    }
}