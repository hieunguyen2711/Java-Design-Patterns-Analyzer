public interface RoomVisitor {
    void visit(Room room);
    void visit(Booking booking);
    void visit(Guest guest);
}