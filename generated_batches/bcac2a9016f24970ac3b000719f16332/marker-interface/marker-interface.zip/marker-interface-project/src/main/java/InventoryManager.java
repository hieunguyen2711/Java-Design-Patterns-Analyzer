package hotel.inventory;

import java.util.ArrayList;
import java.util.List;

public class InventoryManager {
    private final List<Identifiable> items = new ArrayList<>();
    
    public void addItem(Identifiable item) {
        items.add(item);
    }
    
    public Identifiable findItemById(String id) {
        return items.stream()
                .filter(item -> {
                    if (item instanceof Room) {
                        return ((Room) item).getRoomId().equals(id);
                    } else if (item instanceof Booking) {
                        return ((Booking) item).getBookingId().equals(id);
                    }
                    return false;
                })
                .findFirst()
                .orElse(null);
    }
    
    public List<Identifiable> getAllItems() {
        return new ArrayList<>(items);
    }
}