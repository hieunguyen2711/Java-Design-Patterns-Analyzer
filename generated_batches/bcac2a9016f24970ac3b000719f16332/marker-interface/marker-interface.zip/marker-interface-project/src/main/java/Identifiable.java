package hotel.inventory;

public interface Identifiable {
    // Marker interface - no methods required
    // Used to identify objects that can be uniquely identified
}