package hotel.inventory;

public class Room implements Identifiable {
    private final String roomId;
    private final int capacity;
    
    public Room(String roomId, int capacity) {
        this.roomId = roomId;
        this.capacity = capacity;
    }
    
    public String getRoomId() {
        return roomId;
    }
    
    public int getCapacity() {
        return capacity;
    }
}