package hotel.inventory;

public class Booking implements Identifiable {
    private final String bookingId;
    private final Room room;
    private final String guestName;
    
    public Booking(String bookingId, Room room, String guestName) {
        this.bookingId = bookingId;
        this.room = room;
        this.guestName = guestName;
    }
    
    public String getBookingId() {
        return bookingId;
    }
    
    public Room getRoom() {
        return room;
    }
    
    public String getGuestName() {
        return guestName;
    }
}