package hotel.inventory;

public class Room {
    private final int id;
    private volatile RoomState state;
    
    public Room(int id, RoomState initialState) {
        this.id = id;
        this.state = initialState;
    }
    
    public int getId() {
        return id;
    }
    
    public RoomState getState() {
        return state;
    }
    
    public void setState(RoomState newState) {
        this.state = newState;
    }
}