package hotel.inventory;

public enum RoomState {
    AVAILABLE,
    OCCUPIED,
    MAINTENANCE
}