package hotel.inventory;

import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

public class RoomInventory {
    private final Map<Integer, Room> rooms = new ConcurrentHashMap<>();
    
    public void addRoom(Room room) {
        rooms.put(room.getId(), room);
    }
    
    public Room getRoom(int id) {
        return rooms.get(id);
    }
}