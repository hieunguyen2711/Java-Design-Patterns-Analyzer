package hotel.booking;

import hotel.inventory.Room;
import hotel.inventory.RoomInventory;
import java.util.concurrent.atomic.AtomicReference;

public class BookingService {
    private final RoomInventory inventory;
    private final AtomicReference<RoomInventory> doubleBuffer = new AtomicReference<>();
    
    public BookingService(RoomInventory initialInventory) {
        this.inventory = initialInventory;
        this.doubleBuffer.set(initialInventory);
    }
    
    public void updateInventory(Room room, RoomState newState) {
        // Double buffering approach - create new inventory snapshot
        RoomInventory current = doubleBuffer.get();
        RoomInventory updated = new RoomInventory();
        
        // Copy all existing rooms
        for (Room r : current.getRooms()) {
            if (r.getId() == room.getId()) {
                updated.addRoom(new Room(r.getId(), newState));
            } else {
                updated.addRoom(r);
            }
        }
        
        // Atomic swap of inventory reference
        doubleBuffer.set(updated);
    }
    
    public Room getRoom(int id) {
        return doubleBuffer.get().getRoom(id);
    }
}