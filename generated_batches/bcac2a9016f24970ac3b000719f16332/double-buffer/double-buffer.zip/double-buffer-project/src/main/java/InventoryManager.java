package hotel.booking;

import hotel.inventory.Room;
import hotel.inventory.RoomInventory;
import hotel.inventory.RoomState;

public class InventoryManager {
    private final BookingService bookingService;
    
    public InventoryManager(BookingService bookingService) {