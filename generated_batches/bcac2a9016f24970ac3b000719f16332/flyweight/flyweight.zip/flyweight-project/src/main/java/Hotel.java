import java.util.ArrayList;
import java.util.List;

public class Hotel {
    private final List<Room> rooms = new ArrayList<>();
    
    public void addRoom(Room room) {
        rooms.add(room);
    }
    
    public Room findAvailableRoom(RoomType type) {
        return rooms.stream()
                .filter(room -> room.getType() == type)