public class RoomFlyweight {
    private final RoomType type;
    private final int basePrice;
    
    public RoomFlyweight(RoomType type) {
        this.type = type;
        this.basePrice = calculateBasePrice();
    }
    
    private int calculateBasePrice() {
        switch (type) {
            case STANDARD: return 100;
            case DELUXE: return 200;
            case SUITE: return 400;
            default: return 0;
        }
    }
    
    public int getBasePrice() {
        return basePrice;
    }
    
    public RoomType getType() {
        return type;
    }
}