import java.util.HashMap;
import java.util.Map;

public class RoomFlyweightFactory {
    private static final Map<RoomType, RoomFlyweight> flyweights = new HashMap<>();
    
    public static RoomFlyweight getRoomFlyweight(RoomType type) {
        return flyweights.computeIfAbsent(type, RoomFlyweight::new);
    }
}