public class Room {
    private final String roomNumber;
    private final RoomFlyweight flyweight;
    private boolean isAvailable;
    
    public Room(String roomNumber, RoomType type) {
        this.roomNumber = roomNumber;
        this.flyweight = RoomFlyweightFactory.getRoomFlyweight(type);
        this.isAvailable = true;
    }
    
    public String getRoomNumber() {
        return roomNumber;
    }
    
    public int getPrice() {
        return flyweight.getBasePrice();
    }
    
    public boolean isAvailable() {
        return isAvailable;
    }
    
    public void setAvailability(boolean available) {
        isAvailable = available;
    }
    
    public RoomType getType() {
        return flyweight.getType();
    }
}