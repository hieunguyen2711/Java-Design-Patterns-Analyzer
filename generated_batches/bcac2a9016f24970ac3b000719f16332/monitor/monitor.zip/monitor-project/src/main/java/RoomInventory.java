package hotel;

import java.util.ArrayList;
import java.util.List;

public class RoomInventory {
    private List<Room> rooms;
    
    public RoomInventory() {
        this.rooms = new ArrayList<>();
    }
    
    public synchronized void addRoom(Room room) {
        rooms.add(room);
    }
    
    public synchronized Room findAvailableRoom(String type) {
        for (Room room : rooms) {
            if (room.isAvailable() && room.getType().equals(type)) {
                return room;
            }
        }
        return null;
    }
    
    public synchronized int getAvailableRoomsCount(String type) {
        int count = 0;
        for (Room room : rooms) {
            if (room.isAvailable() && room.getType().equals(type)) {
                count++;
            }
        }
        return count;
    }
}