package hotel;

public class Room {
    private int roomId;
    private String type;
    private boolean isAvailable;
    
    public Room(int roomId, String type) {
        this.roomId = roomId;
        this.type = type;
        this.isAvailable = true;
    }
    
    public synchronized boolean book() {
        if (isAvailable) {
            isAvailable = false;
            return true;
        }
        return false;
    }
    
    public synchronized void checkIn() {
        isAvailable = false;
    }
    
    public synchronized void checkOut() {
        isAvailable = true;
    }
    
    public int getRoomId() {
        return roomId;
    }
    
    public String getType() {
        return type;
    }
    
    public boolean isAvailable() {
        return isAvailable;
    }
}