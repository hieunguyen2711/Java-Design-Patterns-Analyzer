package hotel;

public class BookingService {
    private RoomInventory inventory;
    
    public BookingService(RoomInventory inventory) {
        this.inventory = inventory;
    }
    
    public synchronized boolean bookRoom(String type) {
        Room room = inventory.findAvailableRoom(type);
        if (room != null) {
            return room.book();
        }
        return false;
    }
}