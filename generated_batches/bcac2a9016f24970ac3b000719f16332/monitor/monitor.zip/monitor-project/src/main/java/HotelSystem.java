package hotel;

public class HotelSystem {
    public static void main(String[] args) {
        RoomInventory inventory = new RoomInventory();
        
        // Add rooms to inventory
        inventory.addRoom(new Room(101, "single"));
        inventory.addRoom(new Room(