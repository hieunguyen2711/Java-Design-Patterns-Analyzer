package hotel.inventory;

import java.util.HashMap;
import java.util.Map;

public class RoomPrototypeRegistry {
    private static final Map<String, Room> prototypes = new HashMap<>();
    
    static {
        // Register prototype rooms
        prototypes.put("STANDARD", new Room(1, "STANDARD", 100.0));
        prototypes.put("DELUXE", new Room(2, "DELUXE", 150.0));
        prototypes.put("SUITE", new Room(3, "SUITE", 250.0));
    }
    
    public static Room getRoomPrototype(String type) {
        try {
            return prototypes.get(type).clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException("Failed to clone room prototype", e);
        }
    }
    
    public static void registerRoomPrototype(String type, Room room) {
        try {
            prototypes.put(type, room.clone());
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException("Failed to register room prototype", e);
        }
    }
}