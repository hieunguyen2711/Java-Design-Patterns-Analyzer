package hotel.inventory;

public class Room implements Cloneable {
    private int roomId;
    private String type;
    private double basePrice;
    private boolean isAvailable;
    
    public Room(int roomId, String type, double basePrice) {
        this.roomId = roomId;
        this.type = type;
        this.basePrice = basePrice;
        this.isAvailable = true;
    }
    
    @Override
    public Room clone() throws CloneNotSupportedException {
        return (Room) super.clone();
    }
    
    // Getters and setters
    public int getRoomId() { return roomId; }
    public void setRoomId(int roomId) { this.roomId = roomId; }
    
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    
    public double getBasePrice() { return basePrice; }
    public void setBasePrice(double basePrice) { this.basePrice = basePrice; }
    
    public boolean isAvailable() { return isAvailable; }
    public void setAvailable(boolean available) { isAvailable = available; }
}