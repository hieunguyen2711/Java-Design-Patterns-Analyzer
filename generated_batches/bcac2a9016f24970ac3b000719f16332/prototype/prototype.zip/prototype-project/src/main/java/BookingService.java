package hotel.inventory;

public class BookingService {
    
    public Room createBooking(String roomType) {
        // Use prototype pattern to create new room instance