package com.hotel.inventory;

public class Room {
    private final String type;
    private final String number;
    
    public Room(String type, String number) {
        this.type = type;
        this.number = number;
    }
    
    public String getType() {
        return type;
    }
    
    public String getNumber() {
        return number;
    }
}