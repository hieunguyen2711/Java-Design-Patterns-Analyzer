package com.hotel.inventory;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class HotelBookingSystem {
    private final RoomInventoryService