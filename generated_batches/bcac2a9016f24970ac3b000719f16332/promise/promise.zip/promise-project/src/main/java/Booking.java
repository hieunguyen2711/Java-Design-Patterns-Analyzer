package com.hotel.inventory;

public class Booking {
    private final String guestName;
    private final String roomNumber;
    private final long timestamp;
    
    public Booking(String guestName, String roomNumber, long timestamp) {
        this.guestName = guestName;
        this.roomNumber = roomNumber;
        this.timestamp = timestamp;
    }
    
    public String getGuestName() {
        return guestName;
    }
    
    public String getRoomNumber() {
        return roomNumber;
    }
    
    public long getTimestamp() {
        return timestamp;
    }
}