package com.hotel.inventory;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RoomInventoryService {
    private final ExecutorService executor = Executors.newFixedThreadPool(4);
    
    public CompletableFuture<Room> findAvailableRoomAsync(String roomType) {
        return CompletableFuture.supplyAsync(() -> {
            // Simulate async database lookup
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            return new Room(roomType, "ROOM-" + System.currentTimeMillis());
        }, executor);
    }
    
    public CompletableFuture<Booking> createBookingAsync(String guestName, String roomNumber) {
        return findAvailableRoomAsync("DELUXE")
            .thenCompose(room -> {
                // Simulate booking creation
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                return CompletableFuture.completedFuture(
                    new Booking(guestName, roomNumber, System.currentTimeMillis())
                );
            });
    }
    
    public void shutdown() {
        executor.shutdown();
    }
}