package com.example.hotel;

import java.util.List;

public class HotelService {
    private RoomRepository roomRepository;
    
    public HotelService(RoomRepository roomRepository)