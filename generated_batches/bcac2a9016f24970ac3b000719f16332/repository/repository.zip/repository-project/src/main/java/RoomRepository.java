package com.example.hotel;

import java.util.ArrayList;
import java.util.List;

public interface RoomRepository {
    Room findById(int id);
    List<Room> findAll();
    Room save(Room room);
    void deleteById(int id);
}