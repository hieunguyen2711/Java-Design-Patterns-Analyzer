package com.example.hotel;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class InMemoryRoomRepository implements RoomRepository {
    private List<Room> rooms = new ArrayList<>();
    private int nextId = 1;
    
    @Override
    public Room findById(int id) {
        return rooms.stream()
                .filter(room -> room.getRoomId() == id)
                .findFirst()
                .orElse(null);
    }
    
    @Override
    public List<Room> findAll() {
        return new ArrayList<>(rooms);
    }
    
    @Override
    public Room save(Room room) {
        if (room.getRoomId() == 0) {
            room.setRoomId(nextId++);
        } else {
            // Update existing room
            rooms.removeIf(r -> r.getRoomId() == room.getRoomId());
        }
        rooms.add(room);
        return room;
    }
    
    @Override
    public void deleteById(int id) {
        rooms.removeIf(room -> room.getRoomId() == id);
    }
}