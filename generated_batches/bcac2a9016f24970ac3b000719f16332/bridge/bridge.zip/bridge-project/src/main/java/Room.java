public abstract class Room {
    protected RoomType type;
    protected PricingStrategy pricingStrategy;
    
    public Room(RoomType type, PricingStrategy pricingStrategy) {
        this.type = type;
        this.pricingStrategy = pricingStrategy;
    }
    
    public abstract double calculatePrice(int nights);
    public abstract String getRoomDetails();
}