public class SuiteRoom extends Room {
    public SuiteRoom(PricingStrategy pricingStrategy) {
        super(RoomType.SUITE, pricingStrategy);
    }
    
    @Override
    public double calculatePrice(int nights) {
        return pricingStrategy.calculatePrice(250.0, nights);
    }
    
    @Override
    public String getRoomDetails() {
        return "Suite Room";
    }
}