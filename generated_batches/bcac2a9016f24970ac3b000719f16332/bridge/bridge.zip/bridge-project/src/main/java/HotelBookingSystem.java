public class HotelBookingSystem {
    public static void main(String[] args) {
        // Using regular pricing strategy
        Room standardRoom = new