public enum RoomType {
    STANDARD,
    SUITE
}