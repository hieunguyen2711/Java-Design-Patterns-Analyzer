public class StandardRoom extends Room {
    public StandardRoom(PricingStrategy pricingStrategy) {
        super(RoomType.STANDARD, pricingStrategy);
    }
    
    @Override
    public double calculatePrice(int nights) {
        return pricingStrategy.calculatePrice(100.0, nights);
    }
    
    @Override
    public String getRoomDetails() {
        return "Standard Room";
    }
}