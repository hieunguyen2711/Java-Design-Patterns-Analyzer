public class WeekendPricing implements PricingStrategy {
    @Override
    public double calculatePrice(double basePrice, int nights) {
        double weekendNights = Math.ceil(nights / 7.0) * 2;
        double weekdayNights = nights - weekendNights;
        return (basePrice * 1.2 * weekendNights) + (basePrice * weekdayNights);
    }
}