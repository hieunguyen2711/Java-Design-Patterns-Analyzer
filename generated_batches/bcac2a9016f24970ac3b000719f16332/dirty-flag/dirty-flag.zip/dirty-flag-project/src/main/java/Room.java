package hotel.inventory;

public class Room {
    private int roomId;
    private String roomType;
    private boolean isDirty;
    
    public Room(int roomId, String roomType) {
        this.roomId = roomId;
        this.roomType = roomType;
        this.isDirty = false;
    }
    
    public void setRoomType(String roomType) {
        this.roomType = roomType;
        markAsDirty();
    }
    
    public boolean isDirty() {
        return isDirty;
    }
    
    public void markAsDirty() {
        this.isDirty = true;
    }
    
    public void clean() {
        this.isDirty = false;
    }
    
    public int getRoomId() {
        return roomId;
    }
    
    public String getRoomType() {
        return roomType;
    }
}