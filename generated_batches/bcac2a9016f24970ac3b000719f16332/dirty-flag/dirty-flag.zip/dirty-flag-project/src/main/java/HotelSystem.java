package hotel.inventory;

public class HotelSystem {
    public static void main(String[] args) {
        RoomInventoryService inventory = new RoomInventoryService();
        
        Room room1 = new Room(101, "Single");
        Room room2 = new Room(102, "Double");
        
        inventory.addRoom(room1);
        inventory.addRoom(room2);
        
        // Mark rooms as dirty
        room1.setRoomType("Suite");
        room2.setRoomType("King");