package hotel.inventory;

import java.util.*;

public class RoomInventoryService {
    private Map<Integer, Room> rooms;
    private Set<Room> dirtyRooms;
    
    public RoomInventoryService() {
        this.rooms = new HashMap<>();
        this.dirtyRooms = new HashSet<>();
    }
    
    public void addRoom(Room room) {
        rooms.put(room.getRoomId(), room);
        if (room.isDirty()) {
            dirtyRooms.add(room);
        }
    }
    
    public Room getRoom(int roomId) {
        return rooms.get(roomId);
    }
    
    public Set<Room> getDirtyRooms() {
        return new HashSet<>(dirtyRooms);
    }
    
    public void processDirtyRooms() {
        Iterator<Room> iterator = dirtyRooms.iterator();
        while (iterator.hasNext()) {
            Room room = iterator.next();
            System.out.println("Processing dirty room: " + room.getRoomId());
            // Simulate processing
            room.clean();
            iterator.remove();
        }
    }
}