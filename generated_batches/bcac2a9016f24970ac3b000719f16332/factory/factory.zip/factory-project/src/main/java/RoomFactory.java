public class RoomFactory {
    public static Room createRoom(String type, String roomId, double basePrice) {
        switch (type.toLowerCase()) {
            case "standard":
                return new StandardRoom(roomId, basePrice);
            case "deluxe":
                return new DeluxeRoom(roomId, basePrice);
            case "suite":
                return new SuiteRoom(roomId, basePrice);
            default:
                throw new IllegalArgumentException("Unknown room type: " + type);
        }
    }
}