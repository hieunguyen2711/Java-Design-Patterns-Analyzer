public class StandardRoom extends Room {
    public StandardRoom(String roomId, double basePrice) {
        super(roomId, "Standard", basePrice);
    }
}