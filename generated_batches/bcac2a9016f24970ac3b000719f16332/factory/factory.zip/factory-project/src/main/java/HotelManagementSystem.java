public class HotelManagementSystem {
    public static void main(String[] args) {
        Room standardRoom = RoomFactory.createRoom("standard", "S-101", 150.0);
        Room deluxeRoom = RoomFactory.createRoom("deluxe", "D-201", 250.0);
        Room suiteRoom = RoomFactory.createRoom("suite", "SU-301", 400.0);

        System.out.println("Created rooms:");
        System.out.println(standardRoom.getType() + " room " + standardRoom.getRoomId() + 
                          " at $" + standardRoom.getBasePrice() + "/night");
        System.out