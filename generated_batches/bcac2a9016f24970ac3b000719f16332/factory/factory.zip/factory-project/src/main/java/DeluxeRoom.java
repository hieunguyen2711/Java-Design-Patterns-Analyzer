public class DeluxeRoom extends Room {
    public DeluxeRoom(String roomId, double basePrice) {
        super(roomId, "Deluxe", basePrice);
    }
}