public class SuiteRoom extends Room {
    public SuiteRoom(String roomId, double basePrice) {
        super(roomId, "Suite", basePrice);
    }
}