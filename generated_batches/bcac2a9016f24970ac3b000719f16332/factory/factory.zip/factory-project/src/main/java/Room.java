public class Room {
    private String roomId;
    private String type;
    private double basePrice;

    public Room(String roomId, String type, double basePrice) {
        this.roomId = roomId;
        this.type = type;
        this.basePrice = basePrice;
    }

    public String getRoomId() {
        return roomId;
    }

    public String getType() {
        return type;
    }

    public double getBasePrice() {
        return basePrice;
    }
}