public class Client {
    public static void main(String[] args) {
        BusinessDelegate businessDelegate = new BusinessDelegate();
        
        businessDelegate.setRoomInventoryService(new RoomInventoryService());
        businessDelegate.setBookingService(new BookingService());
        businessDelegate.setBillingService(new BillingService());
        
        System.out.println(businessDelegate.processRoomAvailability("Deluxe"));
        System.out.println(businessDelegate.processBooking("John Doe", "Suite"));
        System.out.println("Bill amount: $" + businessDelegate.processBilling("John Doe"));
    }
}