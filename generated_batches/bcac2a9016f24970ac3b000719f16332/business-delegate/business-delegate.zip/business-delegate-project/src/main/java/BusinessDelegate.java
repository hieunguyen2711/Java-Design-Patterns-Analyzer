public class BusinessDelegate {
    private RoomInventoryService roomInventoryService;
    private BookingService bookingService;
    private BillingService billingService;
    
    public void setRoomInventoryService(RoomInventoryService roomInventoryService) {
        this.roomInventoryService = roomInventoryService;
    }
    
    public void setBookingService(BookingService bookingService) {
        this.bookingService = bookingService;
    }
    
    public void setBillingService(BillingService billingService) {
        this.billingService = billingService;
    }
    
    public String processRoomAvailability(String roomType) {
        return roomInventoryService.checkAvailability(roomType);
    }
    
    public String processBooking(String guestName, String roomType) {
        return bookingService.createBooking(guestName, roomType);
    }
    
    public double processBilling(String guestName) {
        return billingService.calculateBill(guestName);
    }
}