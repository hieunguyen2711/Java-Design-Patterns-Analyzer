public class BookingService {
    public String createBooking(String guestName, String roomType) {
        return "Booking confirmed for " + guestName + " in " + roomType;
    }
}