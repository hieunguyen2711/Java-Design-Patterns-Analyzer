public class BillingService {
    public double calculateBill(String guestName) {
        return 250.00;
    }
}