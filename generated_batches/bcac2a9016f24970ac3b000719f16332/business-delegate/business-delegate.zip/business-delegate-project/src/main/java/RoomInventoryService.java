public class RoomInventoryService {
    public String checkAvailability(String roomType) {
        return "Available rooms for " + roomType + ": 5";
    }
}