public class RoomInventorySystem {
    public static void main(String[] args) {
        // Create luxury factory
        RoomFactory luxuryFactory = new LuxuryRoomFactory();
        Room room1 = luxuryFactory.createRoom();
        Bed bed1 = luxuryFactory.createBed();
        
        System.out.println("Luxury Room: " + room1.getRoomType());
        System.out.println("Luxury Bed: " + bed1.getBedType());
        
        // Create standard factory
        RoomFactory standardFactory = new StandardRoomFactory();
        Room room2 = standardFactory.createRoom();
        Bed bed2 = standardFactory.createBed();
        
        System.out.println("Standard Room: " + room2.getRoomType());
        System.out.println("Standard Bed: " + bed2.getBedType());
    }
}