public class LuxuryBed implements Bed {
    @Override
    public String getBedType() {
        return "King Size with Premium Mattress";
    }
}