public interface Bed {
    String getBedType();
}