public class LuxuryRoom implements Room {
    @Override
    public String getRoomType() {
        return "Luxury Suite";
    }
}