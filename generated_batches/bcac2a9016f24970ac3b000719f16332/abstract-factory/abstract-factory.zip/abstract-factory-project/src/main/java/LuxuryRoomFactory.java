public class LuxuryRoomFactory implements RoomFactory {
    @Override
    public Room createRoom() {
        return new LuxuryRoom();
    }
    
    @Override
    public Bed createBed() {
        return new LuxuryBed();
    }
}