public class StandardBed implements Bed {
    @Override
    public String getBedType() {
        return "Queen Size with Standard Mattress";
    }
}