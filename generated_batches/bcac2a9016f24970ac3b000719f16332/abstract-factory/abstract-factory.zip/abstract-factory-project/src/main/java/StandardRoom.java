public class StandardRoom implements Room {
    @Override
    public String getRoomType() {
        return "Standard Room";
    }
}