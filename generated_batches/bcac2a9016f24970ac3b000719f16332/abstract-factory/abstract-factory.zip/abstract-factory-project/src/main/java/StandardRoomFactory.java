public class StandardRoomFactory implements RoomFactory {
    @Override
    public Room createRoom() {
        return