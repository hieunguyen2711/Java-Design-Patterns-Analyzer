public interface RoomFactory {
    Room createRoom();
    Bed createBed();
}