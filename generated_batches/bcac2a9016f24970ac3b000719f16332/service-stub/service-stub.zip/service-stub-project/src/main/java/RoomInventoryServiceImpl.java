package com.hotel.service.impl;

import com.hotel.service.RoomInventoryService;

import java.util.HashSet;
import java.util.Set;

public class RoomInventoryServiceImpl implements RoomInventoryService {
    private Set<Integer> availableRooms;
    
    public RoomInventoryServiceImpl() {
        this.availableRooms = new HashSet<>();
        // Initialize with some sample rooms
        for (int i = 101; i <= 200; i++) {
            availableRooms.add(i);
        }
    }
    
    @Override
    public boolean isRoomAvailable(int roomId) {
        return availableRooms.contains(roomId);
    }
    
    @Override
    public void bookRoom(int roomId) {
        if (availableRooms.remove(roomId)) {
            System.out.println("Room " + roomId + " booked successfully");
        } else {
            System.out.println("Room " + roomId + " is not available");
        }
    }
    
    @Override
    public void releaseRoom(int roomId) {
        availableRooms.add(roomId);
        System.out.println("Room " + roomId + " released back to inventory");
    }
}