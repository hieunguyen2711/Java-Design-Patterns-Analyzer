package com.hotel.service.impl;

import com.hotel.service.BookingService;
import com.hotel.service.RoomInventoryService;

public class BookingServiceImpl implements BookingService {
    private RoomInventoryService inventoryService;
    
    public BookingServiceImpl(RoomInventoryService inventoryService) {
        this.inventoryService = inventoryService;
    }
    
    @Override
    public boolean createBooking(int guestId, int roomId) {
        if (inventoryService.isRoomAvailable(roomId)) {
            inventoryService.bookRoom(roomId);
            System.out.println("Booking created for guest " + guestId + 
                             " in room " + roomId);
            return true;
        }
        System.out.println("Cannot create booking - room " + roomId + " not available