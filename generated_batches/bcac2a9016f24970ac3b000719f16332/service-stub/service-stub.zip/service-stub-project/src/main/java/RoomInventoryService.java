package com.hotel.service;

public interface RoomInventoryService {
    boolean isRoomAvailable(int roomId);
    void bookRoom(int roomId);
    void releaseRoom(int roomId);
}