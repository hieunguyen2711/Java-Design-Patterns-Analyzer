package com.hotel.service;

public interface BookingService {
    boolean createBooking(int guestId, int roomId);
    void cancelBooking(int guestId, int roomId);
    void checkIn(int guestId, int roomId);
    void checkOut(int guestId, int roomId);
}