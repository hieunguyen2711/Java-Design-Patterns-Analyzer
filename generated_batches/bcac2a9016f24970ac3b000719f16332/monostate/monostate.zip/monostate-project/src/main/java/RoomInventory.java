package com.hotel.inventory;

public class RoomInventory {
    private static RoomInventory instance;
    private int availableRooms;
    private int totalRooms;
    
    private RoomInventory() {
        this.totalRooms = 100;
        this.availableRooms = 100;
    }
    
    public static synchronized RoomInventory getInstance() {
        if (instance == null) {
            instance = new RoomInventory();
        }
        return instance;
    }
    
    public synchronized boolean bookRoom() {
        if (availableRooms > 0) {
            availableRooms--;
            return true;
        }
        return false;
    }
    
    public synchronized void checkInGuest() {
        availableRooms--;
    }
    
    public synchronized void checkOutGuest() {
        availableRooms++;
    }
    
    public int getAvailableRooms() {
        return availableRooms;
    }
    
    public int getTotalRooms() {
        return totalRooms;
    }
}