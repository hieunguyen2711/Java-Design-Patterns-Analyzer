package com.hotel.app;

import com.hotel.system.BookingSystem;
import com.hotel.system.BillingSystem;

public class HotelApplication {
    public static void main(String[] args) {
        BookingSystem booking = new BookingSystem();
        BillingSystem billing = new BillingSystem();
        
        System.out.println("Available rooms: " + billing.getAvailableRooms());
        
        booking.bookRoom();
        System.out.println("After booking one room: " + billing.getAvailableRooms());
        
        billing.processCheckOut();