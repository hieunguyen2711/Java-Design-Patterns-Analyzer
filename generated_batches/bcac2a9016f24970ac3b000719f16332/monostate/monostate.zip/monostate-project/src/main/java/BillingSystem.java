package com.hotel.system;

import com.hotel.inventory.RoomInventory;

public class BillingSystem {
    private RoomInventory inventory;
    
    public BillingSystem() {
        this.inventory = RoomInventory.getInstance();
    }
    
    public void processCheckOut() {
        inventory.checkOutGuest();
    }
    
    public int getAvailableRooms() {
        return inventory.getAvailableRooms();
    }
}