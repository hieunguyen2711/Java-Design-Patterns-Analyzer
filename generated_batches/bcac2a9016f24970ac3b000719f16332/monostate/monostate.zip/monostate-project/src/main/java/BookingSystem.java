package com.hotel.system;

import com.hotel.inventory.RoomInventory;

public class BookingSystem {
    private RoomInventory inventory;
    
    public BookingSystem() {
        this.inventory = RoomInventory.getInstance();
    }
    
    public boolean bookRoom() {
        return inventory.bookRoom();
    }
    
    public void checkInGuest() {
        inventory.checkInGuest();
    }
    
    public void checkOutGuest() {
        inventory.checkOutGuest();
    }
}