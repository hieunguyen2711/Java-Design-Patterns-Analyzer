public class BookingServiceImpl implements BookingService {
    private Map<String, String> bookings;

    public BookingServiceImpl() {
        bookings = new HashMap<>();
    }