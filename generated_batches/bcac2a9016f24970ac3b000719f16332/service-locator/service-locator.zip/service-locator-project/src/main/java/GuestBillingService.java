public interface GuestBillingService {
    double generateBill(String bookingId);
    boolean processPayment(String guestName, double amount);
}