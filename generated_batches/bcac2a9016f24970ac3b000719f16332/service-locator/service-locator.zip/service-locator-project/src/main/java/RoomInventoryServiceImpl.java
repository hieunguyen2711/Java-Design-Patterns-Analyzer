public class RoomInventoryServiceImpl implements RoomInventoryService {
    private Map<Integer, Boolean> roomAvailability;

    public RoomInventoryServiceImpl() {
        roomAvailability = new HashMap<>();
        roomAvailability.put(101, true);
        roomAvailability.put(102, false);
        roomAvailability.put(103, true);
    }

    @Override
    public int getAvailableRooms() {
        return (int) roomAvailability.values().stream()
                .filter(Boolean::booleanValue)
                .count();
    }

    @Override
    public void updateRoomAvailability(int roomId, boolean isAvailable) {
        roomAvailability.put(roomId, isAvailable);
    }
}