public interface RoomInventoryService {
    int getAvailableRooms();
    void updateRoomAvailability(int roomId, boolean isAvailable);
}