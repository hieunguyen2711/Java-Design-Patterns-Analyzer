public class ServiceLocator {
    private static ServiceLocator instance;
    private Map<String, Object> services;

    private ServiceLocator() {
        services = new HashMap<>();
        loadServices();
    }

    public static synchronized ServiceLocator getInstance() {
        if (instance == null) {
            instance = new ServiceLocator();
        }
        return instance;
    }

    private void loadServices() {
        services.put("RoomInventoryService", new RoomInventoryServiceImpl());
        services.put("BookingService", new BookingServiceImpl());
        services.put("PricingPlanService", new PricingPlanServiceImpl());
        services.put("GuestBillingService", new GuestBillingServiceImpl());
    }

    public Object getService(String serviceName) {
        return services.get(serviceName);
    }
}