public interface PricingPlanService {
    double calculatePrice(int roomId, int numberOfNights);
    void updatePricingPlan(int roomId, double newRate);
}