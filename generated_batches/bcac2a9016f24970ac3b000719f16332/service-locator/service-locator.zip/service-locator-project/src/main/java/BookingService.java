public interface BookingService {
    String createBooking(String guestName, int roomId);
    boolean cancelBooking(String bookingId);
}