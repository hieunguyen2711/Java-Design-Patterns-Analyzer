package hotel.inventory;

public class RoomInventoryService {
    private final RoomRepository roomRepository;
    
    public RoomInventoryService(RoomRepository roomRepository) {
        this.roomRepository = roomRepository;
    }
    
    public void updateRoomAvailability(int roomId, boolean isAvailable) {
        // Transaction script: single method orchestrating the transaction
        try {
            Room room = roomRepository.findById(roomId);
            if (room == null) {
                throw new RuntimeException("Room not found");
            }
            
            room.setAvailable(isAvailable);
            roomRepository.save(room);
            
        } catch (Exception e) {
            // Transaction script handles rollback logic here
            throw new RuntimeException("Failed to update room availability", e);
        }
    }
}