package hotel.booking;

import hotel.inventory.Room;
import hotel.inventory.RoomRepository;
import java.util.Date;

public class BookingService {
    private final RoomRepository roomRepository;
    
    public BookingService(RoomRepository roomRepository) {
        this.roomRepository = roomRepository;
    }
    
    public void createBooking(int roomId, Date checkInDate, Date checkOutDate) {
        // Transaction script: single method orchestrating the booking transaction
        try {
            Room room = roomRepository.findById(roomId);
            if (room ==