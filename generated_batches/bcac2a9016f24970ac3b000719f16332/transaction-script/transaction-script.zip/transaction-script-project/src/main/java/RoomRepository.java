package hotel.inventory;

import java.util.HashMap;
import java.util.Map;

public class RoomRepository {
    private final Map<Integer, Room> rooms = new HashMap<>();
    
    public Room findById(int id) {
        return rooms.get(id);
    }
    
    public void save(Room room) {
        rooms.put(room.getId(), room);
    }
}