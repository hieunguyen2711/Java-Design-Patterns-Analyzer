public class BookingHandler extends Handler {
    @Override
    public void handle(Request request) {
        if ("BOOKING".equals(request.getType())) {
            System.out.println("Processing booking for " + request.getRoomNumber());
        } else if (next != null) {
            next.handle(request);
        }
    }
}