public class RoomInventorySystem {
    public static void main(String[] args) {
        // Create handlers
        Handler bookingHandler = new BookingHandler();
        Handler checkInHandler = new CheckInHandler();
        Handler checkOutHandler = new CheckOutHandler();
        
        // Chain the handlers
        bookingHandler.setNext(checkInHandler).setNext(checkOutHandler);
        
        // Process requests
        Request request1 = new Request("BOOKING", "Room 101");
        Request request2 = new Request("CHECKIN", "Room 205");
        Request request3 = new Request("CHECKOUT", "Room 101");
        
        bookingHandler.handle(request1);
        bookingHandler.handle(request2);
        bookingHandler.handle(request3);
    }
}