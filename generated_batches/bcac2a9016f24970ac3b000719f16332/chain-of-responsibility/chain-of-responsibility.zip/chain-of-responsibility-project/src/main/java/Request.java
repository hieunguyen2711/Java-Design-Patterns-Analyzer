public class Request {
    private String type;
    private String roomNumber;
    
    public Request(String type, String roomNumber) {
        this.type = type;
        this.roomNumber = roomNumber;
    }
    
    public String getType() {
        return type;
    }
    
    public String getRoomNumber() {
        return roomNumber;
    }
}