public class CheckInHandler extends Handler {
    @Override
    public void handle(Request request) {
        if ("CHECKIN".equals(request.getType())) {
            System.out.println("Processing check-in for " + request.getRoomNumber());
        } else if (next != null) {
            next.handle(request);
        }
    }
}