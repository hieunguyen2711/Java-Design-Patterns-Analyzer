public class CheckOutHandler extends Handler {
    @Override
    public void handle(Request request) {
        if ("CHECKOUT".equals(request.getType())) {
            System