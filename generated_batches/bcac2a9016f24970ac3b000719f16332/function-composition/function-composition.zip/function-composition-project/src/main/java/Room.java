package com.hotel.inventory;

public class Room {
    private final String number;
    private final String type;
    private final boolean available;
    
    public Room(String number, String type, boolean available) {
        this.number = number;
        this.type = type;
        this.available = available;
    }
    
    public String getNumber() {
        return number;
    }
    
    public String getType() {
        return type;
    }
    
    public boolean isAvailable() {
        return available;
    }
}