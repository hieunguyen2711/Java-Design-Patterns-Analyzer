package com.hotel.inventory;

import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Room> rooms = Arrays.asList(
            new Room("101", "single", true),
            new Room("102", "double", false),
            new Room("103", "single", true),
            new Room("104", "suite", true)
        );
        
        RoomInventoryService service = new RoomInventoryService(rooms);
        
        // Demonstrates function composition
        List<String> availableRooms = service