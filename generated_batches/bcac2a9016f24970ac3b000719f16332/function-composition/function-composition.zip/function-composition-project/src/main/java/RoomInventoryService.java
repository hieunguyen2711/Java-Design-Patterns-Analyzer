package com.hotel.inventory;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class RoomInventoryService {
    private final List<Room> rooms;
    
    public RoomInventoryService(List<Room> rooms) {
        this.rooms = rooms;
    }
    
    // Function composition example: chain multiple operations
    public List<String> getAvailableRoomNumbers() {
        Function<List<Room>, List<Room>> filterAvailable = 
            roomList -> roomList.stream()
                .filter(Room::isAvailable)
                .collect(Collectors.toList());
                
        Function<List<Room>, List<String>> extractNumbers = 
            roomList -> roomList.stream()
                .map(Room::getNumber)
                .collect(Collectors.toList());
                
        // Compose functions: first filter, then extract
        return filterAvailable.andThen(extractNumbers).apply(rooms);
    }
    
    public List<Room> getRoomsByType(String type) {
        Function<List<Room>, List<Room>> filterByType = 
            roomList -> roomList.stream()
                .filter(room -> room.getType().equals(type))
                .collect(Collectors.toList());
                
        return filterByType.apply(rooms);
    }
}