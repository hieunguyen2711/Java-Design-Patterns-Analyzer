package hotel.inventory;

import java.util.List;
import java.util.ArrayList;

public interface RoomInventoryService {
    List<Room> getAvailableRooms();
    void bookRoom(int roomId);
    void checkIn(int roomId);
    void checkOut(int roomId);
}