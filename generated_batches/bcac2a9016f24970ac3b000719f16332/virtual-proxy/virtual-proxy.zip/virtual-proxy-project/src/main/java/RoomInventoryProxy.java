package hotel.inventory;

import java.util.List;

public class RoomInventoryProxy implements RoomInventoryService {
    private RealRoomInventoryService realService;
    private boolean serviceLoaded = false;
    
    @Override
    public List<Room> getAvailableRooms()