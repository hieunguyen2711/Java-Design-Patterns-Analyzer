import java.math.BigDecimal;

public class PricingPlan {
    private static final int MAX_PLANS = 3;
    private static PricingPlan[] instances = new PricingPlan[MAX_PLANS];
    
    private RoomType roomType;
    private BigDecimal basePrice;
    private String planName;
    
    private PricingPlan(RoomType roomType, BigDecimal basePrice, String planName) {
        this.roomType = roomType;
        this.basePrice = basePrice;
        this.planName = planName;
    }
    
    public static synchronized PricingPlan getInstance(RoomType roomType, BigDecimal basePrice, String planName) {
        for (int i = 0; i < MAX_PLANS; i++) {
            if (instances[i] != null && instances[i].roomType == roomType) {
                return instances[i];
            }
        }
        
        for (int i = 0; i < MAX_PLANS; i++) {
            if (instances[i] == null) {
                instances[i] = new PricingPlan(roomType, basePrice, planName);
                return instances