public class RoomInventoryManager {
    private static final int MAX_ROOMS = 5;
    private static RoomInventoryManager[] instances = new RoomInventoryManager[MAX_ROOMS];
    
    private String location;
    private int roomCount;
    
    private RoomInventoryManager(String location) {
        this.location = location;
        this.roomCount = 0;
    }
    
    public static synchronized RoomInventoryManager getInstance(String location) {
        for (int i = 0; i < MAX_ROOMS; i++) {
            if (instances[i] != null && instances[i].location.equals(location)) {
                return instances[i];
            }
        }
        
        for (int i = 0; i < MAX_ROOMS; i++) {
            if (instances[i] == null) {
                instances[i] = new RoomInventoryManager(location);
                return instances[i];
            }
        }
        
        throw new RuntimeException("Maximum room inventory managers exceeded");
    }
    
    public void addRoom() {
        roomCount++;
    }
    
    public int getRoomCount() {
        return roomCount;
    }
    
    public String getLocation() {
        return location;
    }
}