package com.hotel.inventory;

import java.util.ArrayList;
import java.util.List;

public class Room extends RoomInventoryItem {
    private List<RoomInventoryItem> items;
    private double basePrice;
    
    public Room(String name, double basePrice) {
        super(name);
        this.basePrice = basePrice;
        this.items = new ArrayList<>();
    }
    
    @Override
    public double getPrice() {
        double total = basePrice;
        for (RoomInventoryItem item : items) {
            total += item.getPrice();
        }
        return total;
    }
    
    @Override
    public void add(RoomInventoryItem item) {
        items.add(item);
    }
    
    @Override
    public void remove(RoomInventoryItem item) {
        items.remove(item);
    }
    
    @Override
    public boolean isComposite() {
        return true;
    }
}