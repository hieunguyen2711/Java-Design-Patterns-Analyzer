package com.hotel.inventory;

public abstract class RoomInventoryItem {
    protected String name;
    
    public RoomInventoryItem(String name) {
        this.name = name;
    }
    
    public abstract double getPrice();
    public abstract void add(RoomInventoryItem item);
    public abstract void remove(RoomInventoryItem item);
    public abstract boolean isComposite();
}