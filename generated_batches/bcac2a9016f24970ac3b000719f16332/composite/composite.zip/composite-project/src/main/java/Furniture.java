package com.hotel.inventory;

public class Furniture extends RoomInventoryItem {
    private double price;
    
    public Furniture(String name, double price) {
        super(name);
        this.price = price;
    }
    
    @Override
    public double getPrice() {
        return price;
    }
    
    @Override
    public void add(RoomInventoryItem item) {
        throw new UnsupportedOperationException("Cannot add items to furniture");
    }
    
    @Override
    public void remove(RoomInventoryItem item) {
        throw new UnsupportedOperationException("Cannot remove items from furniture");
    }
    
    @Override
    public boolean isComposite() {
        return false;
    }
}