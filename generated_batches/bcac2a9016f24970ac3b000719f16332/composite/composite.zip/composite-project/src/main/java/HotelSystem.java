package com.hotel.inventory;

public class HotelSystem {
    public static void main(String[] args) {
        // Create a room with base price
        Room suite = new Room("Deluxe Suite", 200.0);
        
        // Add furniture to the room (leaf nodes)
        Furniture bed = new Furniture("King Size Bed", 50.0);
        Furniture desk = new