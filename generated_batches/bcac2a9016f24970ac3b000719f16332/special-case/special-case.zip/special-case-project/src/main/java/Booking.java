package hotel;

import java.time.LocalDate;

public class Booking {
    private int bookingId;
    private int roomId;
    private LocalDate checkInDate;
    private LocalDate checkOutDate;
    private double totalAmount;
    
    public Booking(int bookingId, int roomId, LocalDate checkInDate, 
                   LocalDate checkOutDate, double totalAmount) {
        this.bookingId = bookingId;
        this.roomId = roomId;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.totalAmount = totalAmount;
    }
    
    public int getBookingId() {
        return bookingId;
    }
    
    public int getRoomId() {
        return roomId;
    }
    
    public LocalDate getCheckInDate() {
        return checkInDate;
    }
    
    public LocalDate getCheckOutDate() {
        return checkOutDate;
    }
    
    public double getTotalAmount() {
        return totalAmount;
    }
}