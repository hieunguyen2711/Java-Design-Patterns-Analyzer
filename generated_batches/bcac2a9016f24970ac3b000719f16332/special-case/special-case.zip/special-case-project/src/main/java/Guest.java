package hotel;

public class Guest {
    private int guestId;
    private String name;
    private String email;
    
    public Guest(int guestId, String name, String email) {
        this.guestId = guestId;
        this.name = name;
        this.email = email;
    }
    
    public int getGuestId() {
        return guestId;
    }
    
    public String getName() {
        return name;
    }
    
    public String getEmail() {
        return email;
    }
}