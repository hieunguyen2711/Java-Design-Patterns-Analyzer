package hotel;

public abstract class PricingPlan {
    protected RoomType room