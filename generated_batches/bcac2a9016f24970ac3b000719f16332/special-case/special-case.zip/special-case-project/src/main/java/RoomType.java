package hotel;

public enum RoomType {
    STANDARD,
    DELUXE,
    SUITE
}