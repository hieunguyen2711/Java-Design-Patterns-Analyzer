package hotel.inventory;

public class Room {
    private int roomId;
    private String roomType;
    private double basePrice;
    
    public Room(int roomId, String roomType, double basePrice) {
        this.roomId = roomId;
        this.roomType = roomType;
        this.basePrice = basePrice;
    }
    
    // Getters and setters
    public int getRoomId() { return roomId; }
    public void setRoomId(int roomId) { this.roomId = roomId; }
    
    public String getRoomType() { return roomType; }
    public void setRoomType(String roomType) { this.roomType = roomType; }
    
    public double getBasePrice() { return basePrice; }
    public void setBasePrice(double basePrice) { this.basePrice = basePrice; }
}