package com.hotel.inventory;

public class Room {
    private final String roomId;
    private final String roomType;
    private final int capacity;
    private final boolean hasBalcony;
    private final boolean isSmokingAllowed;
    private final double nightlyRate;
    
    private Room(Builder builder) {
        this.roomId = builder.roomId;
        this.roomType = builder.roomType;
        this.capacity = builder.capacity;
        this.hasBalcony = builder.hasBalcony;
        this.isSmokingAllowed = builder.isSmokingAllowed;
        this.nightlyRate = builder.nightlyRate;
    }
    
    public String getRoomId() {
        return roomId;
    }
    
    public String getRoomType() {
        return roomType;
    }
    
    public int getCapacity() {
        return capacity;
    }
    
    public boolean hasBalcony() {
        return hasBalcony;
    }
    
    public boolean isSmokingAllowed() {
        return isSmokingAllowed;
    }
    
    public double getNightlyRate() {
        return nightlyRate;
    }
    
    @Override
    public String toString() {
        return "Room{" +
                "roomId='" + roomId + '\'' +
                ", roomType='" + roomType + '\'' +
                ", capacity=" + capacity +
                ", hasBalcony=" + hasBalcony +
                ", isSmokingAllowed=" + isSmokingAllowed +
                ", nightlyRate=" + nightlyRate +
                '}';
    }
    
    public static class Builder {
        private String roomId;
        private String roomType;
        private int capacity;
        private boolean hasBalcony = false;
        private boolean isSmokingAllowed = false;
        private double nightlyRate;
        
        public Builder(String roomId, String roomType, int capacity) {
            this.roomId = roomId;
            this.roomType = roomType;
            this.capacity = capacity;
        }
        
        public Builder withBalcony(boolean hasBalcony) {
            this.hasBalcony = hasBalcony;
            return this;
        }
        
        public Builder smokingAllowed(boolean isSmokingAllowed) {
            this.isSmokingAllowed = isSmokingAllowed;
            return this;
        }
        
        public Builder nightlyRate(double nightlyRate) {
            this.nightlyRate = nightlyRate;
            return this;
        }
        
        public Room build() {
            return new Room(this);
        }