package hotel.inventory;

public class HotelService {
    
    public Room getRoom(int roomId) {
        return RoomRepository.findRoomById(roomId);
    }
    
    public void demonstrateIdentityMap() {
        System.out.println("=== Identity Map Demonstration ===");
        
        Room room1 = getRoom(101);
        Room room2 = getRoom(101);
        
        System.out.println("Same object reference: " + (room1 == room2));
        System.out.println("Room 1 hash code: " + room1.hashCode());
        System.out.println("Room 2 hash code: " + room2.hashCode());
        
        Room room3 = getRoom(102);
        Room room4 = getRoom(102);
        
        System