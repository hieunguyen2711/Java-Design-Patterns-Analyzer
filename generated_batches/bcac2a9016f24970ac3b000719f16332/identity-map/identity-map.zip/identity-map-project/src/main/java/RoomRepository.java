package hotel.inventory;

import java.util.HashMap;
import java.util.Map;

public class RoomRepository {
    private static final Map<Integer, Room> roomCache = new HashMap<>();
    
    public static Room findRoomById(int roomId) {
        return roomCache.computeIfAbsent(roomId, RoomRepository::loadRoom);
    }
    
    private static Room loadRoom(int roomId) {
        // Simulate database lookup
        System.out.println("Loading room " + roomId + " from database");
        return new Room(roomId, "R" + roomId, "Standard");
    }
    
    public static void clearCache() {
        roomCache.clear();
    }
}