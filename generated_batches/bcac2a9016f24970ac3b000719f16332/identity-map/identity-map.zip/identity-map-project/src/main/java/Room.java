package hotel.inventory;

public class Room {
    private final int roomId;
    private final String roomNumber;
    private final String type;
    
    public Room(int roomId, String roomNumber, String type) {
        this.roomId = roomId;
        this.roomNumber = roomNumber;
        this.type = type;
    }
    
    public int getRoomId() {
        return roomId;
    }
    
    public String getRoomNumber() {
        return roomNumber;
    }
    
    public String getType() {
        return type;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Room room = (Room) obj;
        return roomId == room.roomId;
    }
    
    @Override
    public int hashCode() {
        return Integer.hashCode(roomId);
    }
}