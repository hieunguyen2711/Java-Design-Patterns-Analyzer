public class PremiumRoomBooking extends RoomInventorySystem {
    @Override
    protected void validateRoomAvailability() {
        System.out.println("Checking premium room availability...");
        System.out.println("Premium rooms available: 5");
    }
    
    @Override
    protected void calculatePricing() {
        System.out.println("Calculating premium room pricing...");
        System.out.println("Base rate: $250 per night");
        System.out.println("Luxury tax: +$25");
        System.out.println("Service fee: +$15");
    }
}