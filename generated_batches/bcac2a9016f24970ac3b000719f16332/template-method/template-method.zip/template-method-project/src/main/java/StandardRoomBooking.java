public class StandardRoomBooking extends RoomInventorySystem {
    @Override
    protected void validateRoomAvailability() {
        System.out.println("Checking standard room availability...");
        System.out.println("Standard rooms available: 15");
    }
    
    @Override
    protected void calculatePricing() {
        System.out.println("Calculating standard room pricing...");
        System.out.println("Base rate: $120 per night");
        System.out.println("No additional fees applied");
    }
}