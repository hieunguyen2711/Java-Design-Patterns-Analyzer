public class BookingProcessor {
    public static void main(String[] args) {
        System.out.println("=== Standard Room Booking ===");
        RoomInventorySystem standardBooking = new StandardRoomBooking();
        standardBooking.processBooking();
        
        System.out.println("\n=== Premium Room Booking ===");
        RoomInventorySystem premiumBooking = new PremiumRoomBooking();
        premiumBooking.processBooking();
    }
}