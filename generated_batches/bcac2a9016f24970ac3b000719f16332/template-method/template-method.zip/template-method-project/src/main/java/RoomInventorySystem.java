public abstract class RoomInventorySystem {
    // Template method
    public final void processBooking() {
        initialize();
        validateRoomAvailability();
        calculatePricing();
        confirmBooking();
        generateInvoice();
        cleanup();
    }
    
    protected void initialize() {
        System.out.println("Initializing room inventory system...");
    }
    
    protected abstract void validateRoomAvailability();
    
    protected abstract void calculatePricing();
    
    private void confirmBooking() {
        System.out.println("Booking confirmed in database");
    }
    
    private void generateInvoice() {
        System.out.println("Invoice generated and sent to guest");
    }
    
    private void cleanup() {
        System.out.println("Cleaning up temporary booking data");
    }
}