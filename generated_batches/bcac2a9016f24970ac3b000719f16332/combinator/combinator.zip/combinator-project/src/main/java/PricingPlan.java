package com.example.hotel;

import java.math.BigDecimal;
import java.time.LocalDate;

public class PricingPlan {
    private final String planId;
    private final BigDecimal baseRate;
    private final LocalDate startDate;
    private final LocalDate endDate;
    
    public PricingPlan(String planId, BigDecimal baseRate, 
                       LocalDate startDate, LocalDate endDate) {
        this.planId = planId;
        this.baseRate = baseRate;
        this.startDate = startDate;