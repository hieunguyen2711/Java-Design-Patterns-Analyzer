package com.example.hotel;

import java.time.LocalDate;
import java.util.List;

public class Booking {
    private final String bookingId;
    private final Room room;
    private final List<Guest> guests;
    private final LocalDate checkInDate;
    private final LocalDate checkOutDate;
    
    public Booking(String bookingId, Room room, List<Guest> guests, 
                   LocalDate checkInDate, LocalDate checkOutDate) {
        this.bookingId = bookingId;
        this.room = room;
        this.guests = guests;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
    }
    
    public String getBookingId() {
        return bookingId;
    }
    
    public Room getRoom() {
        return room;
    }
    
    public List<Guest> getGuests() {
        return guests;
    }
    
    public LocalDate getCheckInDate() {
        return checkInDate;
    }
    
    public LocalDate getCheckOutDate() {
        return checkOutDate;
    }
}