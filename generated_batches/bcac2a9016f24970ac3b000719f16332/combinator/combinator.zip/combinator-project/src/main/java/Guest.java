package com.example.hotel;

public class Guest {
    private final String guestId;
    private final String name;
    
    public Guest(String guestId, String name) {
        this.guestId = guestId;
        this.name = name;
    }
    
    public String getGuestId() {
        return guestId;
    }
    
    public String getName() {
        return name;
    }
}