package hotel;

public class Booking {
    private int bookingId;
    private Room room;
    private Guest guest;
    private int nights;
    
    public Booking(int bookingId, Room room, Guest guest, int nights) {
        this.bookingId = bookingId;
        this.room = room;
        this.guest = guest;
        this.nights = nights;
    }
    
    public double calculateTotal() {
        return room.getBasePrice() * nights;
    }
    
    public int getBookingId() {
        return bookingId;
    }
    
    public Room getRoom() {
        return room;
    }
    
    public Guest getGuest() {
        return guest;
    }
    
    public int getNights() {
        return nights;
    }
}