package hotel;

public class BillingService {
    private static BillingService instance;
    
    private BillingService() {}
    
    public static BillingService getInstance() {
        if (instance == null) {
            synchronized (BillingService.class) {
                if (instance == null) {
                    instance = new BillingService();
                }
            }
        }
        return instance;
    }
    
    public double calculateBill(Booking booking) {
        return booking.calculateTotal();
    }
}