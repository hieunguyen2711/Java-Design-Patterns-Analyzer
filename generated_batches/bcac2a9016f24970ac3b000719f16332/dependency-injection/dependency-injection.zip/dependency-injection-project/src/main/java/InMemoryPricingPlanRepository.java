package com.hotel.inventory;

import java.util.HashMap;
import java.util.Map;

public class InMemoryPricingPlanRepository implements PricingPlanRepository {
    private final Map<String, PricingPlan> pricingPlans = new HashMap<>();
    
    public InMemoryPricingPlanRepository() {
        pricingPlans.put("STANDARD", new PricingPlan("STANDARD", 100.0));
        pricingPlans.put("SUITE", new PricingPlan("SUITE", 250.0));
        pricingPlans.put("DELUXE", new PricingPlan("DELUXE", 180.0));
    }
    
    @Override
    public PricingPlan findPricingPlan(String roomType) {
        return pricingPlans.get(roomType);
    }
}