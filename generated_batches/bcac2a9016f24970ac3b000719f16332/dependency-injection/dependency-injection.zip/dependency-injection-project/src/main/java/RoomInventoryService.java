package com.hotel.inventory;

public class RoomInventoryService {
    private final PricingPlanRepository pricingPlanRepository;
    
    public RoomInventoryService(PricingPlanRepository pricingPlanRepository) {
        this.pricingPlanRepository = pricingPlanRepository;
    }
    
    public double calculateRoomRate(String roomType, int numberOfNights) {
        return pricingPlanRepository.findPricingPlan(roomType).getRate() * numberOfNights;
    }
}