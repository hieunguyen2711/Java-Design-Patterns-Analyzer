package com.hotel.inventory;

import java.util.HashMap;
import java.util.Map;

public interface PricingPlanRepository {
    PricingPlan findPricingPlan(String roomType);
}