package com.hotel.inventory;

public class HotelBookingSystem {
    private final RoomInventoryService inventoryService;
    
    public HotelBookingSystem(RoomInventoryService inventoryService) {
        this.inventoryService = inventoryService;
    }
    
    public double calculateTotalBill(String roomType, int nights) {
        return inventoryService.calculateRoomRate(roomType, nights);
    }
}