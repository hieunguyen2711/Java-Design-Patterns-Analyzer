package com.hotel.inventory;

public class PricingPlan {
    private final String type;
    private final double rate;
    
    public PricingPlan(String type, double rate) {
        this.type = type;
        this.rate = rate;
    }
    
    public String getType() {
        return type;
    }
    
    public double getRate() {
        return rate;
    }
}