package hotel;

import java.util.List;
import java.util.ArrayList;

public class Guest {
    private final int guestId;
    private final String name;
    private final String email;
    private final List<Booking>