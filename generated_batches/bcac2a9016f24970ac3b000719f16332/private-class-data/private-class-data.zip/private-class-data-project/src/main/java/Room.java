package hotel;

import java.util.List;
import java.util.ArrayList;

public class Room {
    private final int roomId;
    private final String roomType;
    private final double basePrice;
    private final List<Booking> bookings;
    
    public Room(int roomId, String roomType, double basePrice) {
        this.roomId = roomId;
        this.roomType = roomType;
        this.basePrice = basePrice;
        this.bookings = new ArrayList<>();
    }
    
    public int getRoomId() {
        return roomId;
    }
    
    public String getRoomType() {
        return roomType;
    }
    
    public double getBasePrice() {
        return basePrice;
    }
    
    public List<Booking> getBookings() {
        // Return unmodifiable view to protect internal state
        return new ArrayList<>(bookings);
    }
    
    public void addBooking(Booking booking) {
        bookings.add(booking);
    }
}