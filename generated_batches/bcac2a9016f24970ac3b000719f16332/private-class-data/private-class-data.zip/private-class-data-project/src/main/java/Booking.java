package hotel;

import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;

public class Booking {
    private final int bookingId;
    private final Room room;
    private final Guest guest;
    private final LocalDate checkInDate;
    private final LocalDate checkOutDate;
    private final double totalAmount;
    
    public Booking(int bookingId, Room room, Guest guest, 
                   LocalDate checkInDate, LocalDate checkOutDate, double totalAmount) {
        this.bookingId = bookingId;
        this.room = room;
        this.guest = guest;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.totalAmount = totalAmount;
    }
    
    public int getBookingId() {
        return bookingId;
    }
    
    public Room getRoom() {
        return room;
    }
    
    public Guest getGuest() {
        return guest;
    }
    
    public LocalDate getCheckInDate() {
        return checkInDate;
    }
    
    public LocalDate getCheckOutDate() {
        return checkOutDate;
    }
    
    public double getTotalAmount() {
        return totalAmount;
    }
}