package hotel;

public class Room {
    private String roomId;
    private int capacity;
    private double basePrice;
    private boolean isAvailable;
    
    public Room(String roomId) {
        this.roomId = roomId;
        this.isAvailable = true;
    }
    
    public Room setCapacity(int capacity) {
        this.capacity = capacity;
        return this;
    }
    
    public Room setBasePrice(double basePrice) {
        this.basePrice = basePrice;
        return this;
    }
    
    public Room setIsAvailable(boolean isAvailable) {
        this.isAvailable = isAvailable;
        return this;
    }
    
    // Getters
    public String getRoomId() { return roomId; }
    public int getCapacity() { return capacity; }
    public double getBasePrice() { return basePrice; }
    public boolean isAvailable() { return isAvailable; }
}