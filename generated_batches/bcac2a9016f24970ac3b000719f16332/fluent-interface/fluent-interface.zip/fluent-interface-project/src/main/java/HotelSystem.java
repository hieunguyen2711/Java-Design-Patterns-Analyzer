package hotel;

public class HotelSystem {
    public static void main(String[] args) {
        // Fluent interface usage example
        Room room = RoomBuilder.create()
                .withRoomId("101")
                .withCapacity(2)
                .withBasePrice(150.0)
                .available()
                .build();
        
        System.out.println("Room