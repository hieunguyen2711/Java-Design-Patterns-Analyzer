package hotel;

public class RoomBuilder {
    private String roomId;
    private int capacity = 1;
    private double basePrice = 0.0;
    private boolean isAvailable = true;
    
    public static RoomBuilder create() {
        return new RoomBuilder();
    }
    
    public RoomBuilder withRoomId(String roomId) {
        this.roomId = roomId;
        return this;
    }
    
    public RoomBuilder withCapacity(int capacity) {
        this.capacity = capacity;
        return this;
    }
    
    public RoomBuilder withBasePrice(double basePrice) {
        this.basePrice = basePrice;
        return this;
    }
    
    public RoomBuilder available() {
        this.isAvailable = true;
        return this;
    }
    
    public RoomBuilder unavailable() {
        this.isAvailable = false;
        return this;
    }
    
    public Room build() {
        Room room = new Room(roomId);
        room.setCapacity(capacity);
        room.setBasePrice(basePrice);
        room.setIsAvailable(isAvailable);
        return room;
    }
}