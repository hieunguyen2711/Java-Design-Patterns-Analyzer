package com.hotel.inventory;

public class PaymentAdapter implements PaymentProcessor {
    private LegacyPaymentSystem legacySystem;
    
    public PaymentAdapter() {
        this.legacySystem = new LegacyPaymentSystem();
    }
    
    @Override
    public void processPayment(double amount) {
        // Adapting the modern interface to work with legacy system
        String customerName = "Guest123";
        if (legacySystem.validateCard("1234567890123456")) {
            legacySystem.makeCharge(customerName, amount);
        } else {
            System.out.println