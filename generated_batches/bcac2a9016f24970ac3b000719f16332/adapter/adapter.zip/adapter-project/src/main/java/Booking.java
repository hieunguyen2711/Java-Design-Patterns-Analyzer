package com.hotel.inventory;

public class Booking {
    private String roomNumber;
    private int numberOfNights;
    private double nightlyRate;
    
    public Booking(String roomNumber, int numberOfNights, double nightlyRate) {
        this.roomNumber = roomNumber;
        this.numberOfNights = numberOfNights;
        this.nightlyRate = nightlyRate;
    }
    
    public double calculateTotal() {
        return numberOfNights * nightlyRate;
    }
    
    public String getRoomNumber() {
        return roomNumber;
    }
}