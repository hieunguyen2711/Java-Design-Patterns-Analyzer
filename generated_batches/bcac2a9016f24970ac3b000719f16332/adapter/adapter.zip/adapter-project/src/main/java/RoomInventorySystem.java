package com.hotel.inventory;

public class RoomInventorySystem {
    public static void main(String[] args) {
        // Using the adapter pattern to integrate legacy payment system
        PaymentProcessor processor = new PaymentAdapter();
        
        // Process a booking with the adapted payment system
        Booking booking = new Booking("Room101", 2, 150.0);
        double totalAmount = booking.calculateTotal();
        
        System.out.println("Booking for " + booking.getRoomNumber() + 
                          " Total: $" + totalAmount);
        processor.processPayment(totalAmount);
    }
}