package com.hotel.inventory;

public interface PaymentProcessor {
    void processPayment(double amount);
}