package com.hotel.inventory;

public class LegacyPaymentSystem {
    public void makeCharge(String customer, double amount) {
        System.out.println("Charging $" + amount + " to customer " + customer);
    }
    
    public boolean validateCard(String cardNumber) {
        return cardNumber != null && cardNumber.length() == 16;
    }
}