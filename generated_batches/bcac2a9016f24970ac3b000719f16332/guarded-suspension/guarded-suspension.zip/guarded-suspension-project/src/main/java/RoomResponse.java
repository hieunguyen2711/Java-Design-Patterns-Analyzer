package hotel.inventory;

public class RoomResponse {
    private final boolean success;
    private final String message;
    
    public RoomResponse(boolean success, String message) {
        this.success = success;
        this.message = message;
    }
    
    public boolean isSuccess() {
        return success;