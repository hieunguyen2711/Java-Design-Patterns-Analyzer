package hotel.inventory;

public class RoomRequest {
    private final RequestType type;
    private final String guestName;
    private final int roomNumber;
    
    public RoomRequest(RequestType type, String guestName, int roomNumber) {
        this.type = type;
        this.guestName = guestName;
        this.roomNumber = roomNumber;
    }
    
    public RequestType getType() {
        return type;
    }
    
    public String getGuestName() {
        return guestName;
    }
    
    public int getRoomNumber() {
        return roomNumber;
    }
}