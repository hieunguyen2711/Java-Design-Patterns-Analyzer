package com.hotel;

public class Room {
    private int roomNumber;
    private boolean isOccupied;
    private Guest guest;
    
    public Room(int roomNumber) {
        this.roomNumber =