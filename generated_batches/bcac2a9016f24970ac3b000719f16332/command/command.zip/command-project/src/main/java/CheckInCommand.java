package com.hotel.command;

import com.hotel.Room;
import com.hotel.Guest;

public class CheckInCommand implements Command {
    private Room room;
    private Guest guest;
    
    public CheckInCommand(Room room, Guest guest) {
        this.room = room;
        this.guest = guest;
    }
    
    @Override
    public void execute() {
        room.checkIn(guest);
    }
    
    @Override
    public void undo() {
        room.checkOut();
    }
}