package com.hotel.command;

import com.hotel.Room;
import com.hotel.Guest;

public class CheckOutCommand implements Command {
    private Room room;
    private Guest guest;
    
    public CheckOutCommand(Room room, Guest guest) {
        this.room = room;
        this.guest = guest;
    }
    
    @Override
    public void execute() {
        room.checkOut();
    }
    
    @Override
    public void undo() {
        room.checkIn(guest);
    }
}