package com.hotel.command;

public interface Command {
    void execute();
    void undo();
}