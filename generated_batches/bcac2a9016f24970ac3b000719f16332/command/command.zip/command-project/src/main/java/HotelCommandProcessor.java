package com.hotel.command;

import java.util.Stack;

public class HotelCommandProcessor {
    private Stack<Command> commandHistory;
    
    public HotelCommandProcessor() {
        this.commandHistory = new Stack<>();
    }
    
    public void executeCommand(Command command) {
        command.execute();
        commandHistory.push(command);
    }
    
    public void undoLastCommand() {
        if (!commandHistory.isEmpty()) {
            Command lastCommand = commandHistory.pop();
            lastCommand.undo();
        }
    }
}