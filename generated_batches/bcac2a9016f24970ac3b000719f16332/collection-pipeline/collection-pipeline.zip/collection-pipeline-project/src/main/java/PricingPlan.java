package hotel;

public class PricingPlan {
    private String planName;
    private double multiplier;
    
    public PricingPlan(String planName, double multiplier) {
        this.planName = planName;
        this.multiplier = multiplier;
    }
    
    public String getPlanName() { return planName; }
    public double getMultiplier() { return multiplier; }
}