package hotel;

import java.time.LocalDate;
import java.util.List;

public class Booking {
    private int bookingId;
    private int guestId;
    private List<Room> rooms;
    private LocalDate checkInDate;
    private LocalDate checkOutDate;
    
    public Booking(int bookingId, int guestId, List<Room> rooms, 
                   LocalDate checkInDate, LocalDate checkOutDate) {
        this.bookingId = bookingId;
        this.guestId = guestId;
        this.rooms = rooms;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
    }
    
    public int getBookingId() { return bookingId; }
    public int getGuestId() { return guestId; }
    public List<Room> getRooms() { return rooms; }
    public LocalDate getCheckInDate() { return checkInDate; }
    public LocalDate getCheckOutDate() { return checkOutDate; }
}