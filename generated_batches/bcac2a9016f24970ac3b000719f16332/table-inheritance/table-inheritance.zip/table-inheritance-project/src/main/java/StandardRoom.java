package hotel;

public class StandardRoom extends Room {
    private boolean hasBalcony;
    
    public StandardRoom(int roomId, double basePrice, boolean hasBalcony) {
        super(roomId, basePrice);
        this.hasBalcony = hasBalcony;
    }
    
    @Override
    public double calculateFinalPrice() {
        double price = basePrice;
        if (hasBalcony) {
            price += 50.0;
        }
        return price;
    }
}