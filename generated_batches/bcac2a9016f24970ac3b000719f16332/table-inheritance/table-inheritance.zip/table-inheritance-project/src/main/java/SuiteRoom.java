package hotel;

public class SuiteRoom extends Room {
    private boolean hasJacuzzi;
    private int numberOfBeds;
    
    public SuiteRoom(int roomId, double basePrice, boolean hasJacuzzi, int numberOfBeds) {
        super(roomId, basePrice);
        this.hasJacuzzi = hasJacuzzi;
        this.numberOfBeds = numberOfBeds;
    }
    
    @Override
    public double calculateFinalPrice() {
        double price = basePrice;
        if (hasJacuzzi) {
            price += 100.0;
        }
        if (numberOfBeds > 2) {
            price += (numberOfBeds - 2) * 30.0;
        }
        return price;
    }
}