package hotel;

public class RoomFactory {
    
    public static Room createRoom(String type, int roomId, double basePrice, Object... params) {
        switch (type.toLowerCase()) {
            case "standard":
                boolean hasBalcony = (Boolean) params[0];
                return new StandardRoom(roomId, basePrice, hasBalcony);
            case "suite":
                boolean hasJacuzzi = (Boolean) params[0];
                int numberOfBeds = (Integer) params[1];
                return new SuiteRoom(roomId, basePrice, hasJac