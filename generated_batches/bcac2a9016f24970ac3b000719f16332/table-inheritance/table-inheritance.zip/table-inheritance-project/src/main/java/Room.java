package hotel;

public abstract class Room {
    protected int roomId;
    protected double basePrice;
    
    public Room(int roomId, double basePrice) {
        this.roomId = roomId;
        this.basePrice = basePrice;
    }
    
    public abstract double calculateFinalPrice();
    
    public int getRoomId() {
        return roomId;
    }
    
    public double getBasePrice() {
        return basePrice;
    }
}