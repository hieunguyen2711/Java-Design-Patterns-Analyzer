package hotel;

public class Main {
    public static void main(String[] args) {
        RoomInventory inventory = new RoomInventory();
        
        Room room1 = new Room(101, "Single", 100.0);
        Room room2 = new Room(102, "Double", 150.0);
        
        inventory.addRoom(room1);
        inventory.addRoom(room2);
        
        System.out.println("Initial prices:");
        for (Room room : inventory.getRooms()) {
            System.out.println("Room " + room.getRoomId() + ": $" + room.getBasePrice());
        }
        
        // Update method in action
        inventory.updateRoomPrice(101, 120.0);
        inventory.updateRoomPrice(102, 180.0);
        
        System.out.println("\nUpdated prices:");
        for (Room room : inventory.getRooms()) {
            System.out.println("Room " + room.getRoomId() + ": $" + room.getBasePrice());
        }