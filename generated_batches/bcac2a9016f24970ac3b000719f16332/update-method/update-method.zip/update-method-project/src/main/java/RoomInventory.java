package hotel;

import java.util.ArrayList;
import java.util.List;

public class RoomInventory {
    private List<Room> rooms;
    
    public RoomInventory() {
        this.rooms = new ArrayList<>();
    }
    
    public void addRoom(Room room) {
        rooms.add(room);
    }
    
    public void updateRoomPrice(int roomId, double newPrice) {
        for (Room room : rooms) {
            if (room.getRoomId() == roomId) {
                room.updateBasePrice(newPrice);
                break;
            }
        }
    }
    
    public List<Room> getRooms() {
        return new ArrayList<>(rooms);
    }
}