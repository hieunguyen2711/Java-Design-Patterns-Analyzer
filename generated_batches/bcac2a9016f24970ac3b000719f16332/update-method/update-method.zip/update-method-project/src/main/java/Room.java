package hotel;

public class Room {
    private int roomId;
    private String type;
    private double basePrice;
    
    public Room(int roomId, String type, double basePrice) {
        this.roomId = roomId;
        this.type = type;
        this.basePrice = basePrice;
    }
    
    public void updateBasePrice(double newPrice) {
        this.basePrice = newPrice;
    }
    
    public int getRoomId() {
        return roomId;
    }
    
    public String getType() {
        return type;
    }
    
    public double getBasePrice() {
        return basePrice;
    }
}