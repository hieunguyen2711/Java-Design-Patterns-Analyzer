public class SuiteRoom extends Room {
    public SuiteRoom(String roomId, double basePrice) {
        super(roomId, RoomType.SUITE, basePrice);
    }
    
    @Override
    public double calculateFinalPrice(int numberOfNights) {
        return basePrice * numberOfNights * 1.7;
    }
}