import java.util.*;

public class RoomInventory