public class RoomFactory {
    public static Room createRoom(RoomType type, String roomId, double basePrice) {
        switch (type) {
            case STANDARD:
                return new StandardRoom(roomId, basePrice);
            case DELUXE:
                return new DeluxeRoom(roomId, basePrice);
            case SUITE:
                return new SuiteRoom(roomId, basePrice);
            default:
                throw new IllegalArgumentException("Unknown room type: " + type);
        }
    }
}