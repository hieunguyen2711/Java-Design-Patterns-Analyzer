public class StandardRoom extends Room {
    public StandardRoom(String roomId, double basePrice) {
        super(roomId, RoomType.STANDARD, basePrice);
    }
    
    @Override
    public double calculateFinalPrice(int numberOfNights) {
        return basePrice * numberOfNights;
    }
}