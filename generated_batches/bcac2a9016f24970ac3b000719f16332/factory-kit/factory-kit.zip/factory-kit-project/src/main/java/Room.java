public abstract class Room {
    protected String roomId;
    protected RoomType type;
    protected double basePrice;
    
    public Room(String roomId, RoomType type, double basePrice) {
        this.roomId = roomId;
        this.type = type;
        this.basePrice = basePrice;
    }
    
    public abstract double calculateFinalPrice(int numberOfNights);
    
    public String getRoomId() {
        return roomId;
    }
    
    public RoomType getType() {
        return type;
    }
}