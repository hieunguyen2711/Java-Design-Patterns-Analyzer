public class DeluxeRoom extends Room {
    public DeluxeRoom(String roomId, double basePrice) {
        super(roomId, RoomType.DELUXE, basePrice);
    }
    
    @Override
    public double calculateFinalPrice(int numberOfNights) {
        return basePrice * numberOfNights * 1.3;
    }
}