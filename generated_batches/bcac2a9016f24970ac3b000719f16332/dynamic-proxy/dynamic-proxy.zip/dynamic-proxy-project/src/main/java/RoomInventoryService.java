public interface RoomInventoryService {
    void addRoom(int roomId, String type);
    void removeRoom(int roomId);
    boolean isAvailable(int roomId);
}