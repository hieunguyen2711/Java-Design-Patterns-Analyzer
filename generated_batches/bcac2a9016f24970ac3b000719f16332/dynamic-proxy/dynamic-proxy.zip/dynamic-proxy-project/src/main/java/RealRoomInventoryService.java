import java.util.HashMap;
import java.util.Map;

public class RealRoomInventoryService implements RoomInventoryService {
    private Map<Integer, String> rooms = new HashMap<>();
    
    @Override
    public void addRoom(int roomId, String type) {
        rooms.put(roomId, type);
        System.out.println("Added room " + roomId + " of type " + type);
    }
    
    @Override
    public void removeRoom(int roomId) {
        if (rooms.remove(roomId) != null) {
            System.out.println("Removed room " + roomId);
        }
    }
    
    @Override
    public boolean isAvailable(int roomId) {
        return rooms.containsKey(roomId);
    }
}