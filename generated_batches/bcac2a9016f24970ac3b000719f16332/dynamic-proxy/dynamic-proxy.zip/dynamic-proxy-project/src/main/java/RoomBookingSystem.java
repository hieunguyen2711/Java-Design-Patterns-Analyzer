import java.lang.reflect.Proxy;

public class RoomBookingSystem {
    public static void main(String[] args) {
        RoomInventoryService realService = new RealRoomInventoryService();
        
        RoomInventoryService proxy = (RoomInventoryService) Proxy.newProxyInstance(
            RoomInventoryService.class.getClassLoader(),
            new Class[]{RoomInventoryService.class},
            new RoomInventoryServiceProxy(realService)
        );
        
        proxy.addRoom(101, "Single");
        proxy.isAvailable(101);
        proxy.removeRoom(101);
    }
}