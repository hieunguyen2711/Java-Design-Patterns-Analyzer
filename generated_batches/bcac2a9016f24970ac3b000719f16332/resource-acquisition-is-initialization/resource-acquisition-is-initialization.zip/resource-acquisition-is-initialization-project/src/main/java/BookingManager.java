package hotel;

public class BookingManager {
    private final Room[] rooms;
    
    public BookingManager(int numberOfRooms) {
        rooms = new Room[numberOfRooms];
        for (int i = 0; i < numberOfRooms; i++) {
            rooms[i] = new Room(i + 1);
        }
    }
    
    public Booking bookRoom(String guestName) throws IllegalStateException {
        // RAII pattern: acquire resource at construction
        for (Room room : rooms) {
            if (room.isAvailable()) {
                return new Booking(room, guestName);
            }
        }
        throw new IllegalStateException("No available rooms");
    }
    
    public Room[] getRooms() {
        return rooms;
    }
}