package hotel;

public class HotelSystem {
    private final BookingManager bookingManager;
    
    public HotelSystem(int numberOfRooms) {
        this.bookingManager = new BookingManager(numberOfRooms);
    }
    
    public void demonstrateRAII() {
        try (Booking booking1 = bookingManager.bookRoom("John Doe");
             Booking booking2 = bookingManager.bookRoom("Jane Smith")) {
            
            System.out.println("Booked room "