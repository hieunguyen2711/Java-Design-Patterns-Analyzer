package hotel;

public class Booking {
    private final Room room;
    private final String guestName;
    
    public Booking(Room room, String guestName) {
        this.room = room;
        this.guestName = guestName;
        // Resource acquisition - booking the room
        if (!room.isAvailable()) {
            throw new IllegalStateException("Room not available");
        }
        room.setAvailable(false);
    }
    
    public Room getRoom() {
        return room;
    }
    
    public String getGuestName() {
        return guestName;
    }
    
    // Resource release - when booking is closed
    public void close() {
        room.setAvailable(true);
    }
}