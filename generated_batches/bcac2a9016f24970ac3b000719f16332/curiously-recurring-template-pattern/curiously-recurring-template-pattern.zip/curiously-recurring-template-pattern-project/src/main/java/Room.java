package com.hotel.inventory;

public abstract class Room<T extends Room<T>> {
    protected String roomId;
    protected double basePrice;
    
    public Room(String roomId, double basePrice) {
        this.roomId = roomId;
        this.basePrice = basePrice;
    }
    
    public abstract T withFacilities(String... facilities);
    
    public String getRoomId() {
        return roomId;
    }
    
    public double getBasePrice() {
        return basePrice;
    }
}