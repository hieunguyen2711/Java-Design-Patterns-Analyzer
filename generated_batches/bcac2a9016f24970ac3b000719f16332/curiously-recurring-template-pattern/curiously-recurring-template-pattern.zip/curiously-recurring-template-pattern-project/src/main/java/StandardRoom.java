package com.hotel.inventory;

public class StandardRoom extends Room<StandardRoom> {
    private String[] facilities;
    
    public StandardRoom(String roomId, double basePrice) {
        super(roomId, basePrice);
    }
    
    @Override
    public StandardRoom withFacilities(String... facilities) {
        this.facilities = facilities;
        return this;
    }
    
    public String[] getFacilities() {
        return facilities;
    }
}