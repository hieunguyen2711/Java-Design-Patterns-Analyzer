package com.hotel.inventory;

public class DeluxeRoom extends Room<DeluxeRoom> {
    private String[] facilities;
    private boolean hasBalcony;
    
    public DeluxeRoom(String roomId, double basePrice) {
        super(roomId, basePrice);
    }
    
    @Override
    public DeluxeRoom withFacilities(String... facilities) {
        this.facilities = facilities;
        return this;
    }
    
    public String[] getFacilities() {
        return facilities;
    }
    
    public boolean hasBalcony() {
        return hasBalcony;
    }
    
    public void setHasBalcony(boolean hasBalcony) {
        this.hasBalcony = hasBalcony;
    }
}