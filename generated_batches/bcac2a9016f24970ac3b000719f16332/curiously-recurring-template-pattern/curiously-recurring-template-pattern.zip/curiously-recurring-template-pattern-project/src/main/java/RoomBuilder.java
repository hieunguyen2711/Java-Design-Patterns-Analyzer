package com.hotel.inventory;

public class RoomBuilder {
    private String roomId;
    private double basePrice;
    
    public static <T extends Room<T>> T buildRoom(Class<T> roomClass, String roomId, double basePrice) {
        try {
            T room = roomClass.getDeclaredConstructor(String.class, double.class)
                             .newInstance(roomId, basePrice);
            return room;
        } catch (Exception e) {
            throw new RuntimeException("Failed to create room", e);
        }
    }
}