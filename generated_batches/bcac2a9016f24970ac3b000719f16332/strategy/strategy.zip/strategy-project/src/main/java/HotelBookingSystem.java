package hotel;

public class HotelBookingSystem {
    public static void main(String[] args) {
        Room room = new Room(101, "Deluxe", 200.0);
        
        // Using different pricing strategies
        PriceStrategy regular = new RegularPriceStrategy();
        PriceStrategy weekend = new WeekendPriceStrategy();
        PriceStrategy holiday = new HolidayPriceStrategy();
        
        System.out.println("Regular price: $" + room.calculatePrice(regular));
        System.out.println("Weekend price: $" + room.calculatePrice(weekend));
        System.out.println("Holiday price: $" + room.calculatePrice(holiday));
    }
}