package hotel;

public class HolidayPriceStrategy implements PriceStrategy {
    @Override
    public double calculatePrice(double basePrice) {
        return basePrice * 1.5;
    }
}