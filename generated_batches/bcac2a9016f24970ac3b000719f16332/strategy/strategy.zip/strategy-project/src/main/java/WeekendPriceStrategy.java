package hotel;

public class WeekendPriceStrategy implements PriceStrategy {
    @Override
    public double calculatePrice(double basePrice) {
        return basePrice * 1.2;
    }
}