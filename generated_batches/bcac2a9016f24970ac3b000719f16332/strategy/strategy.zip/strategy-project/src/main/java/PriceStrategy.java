package hotel;

public interface PriceStrategy {
    double calculatePrice(double basePrice);
}