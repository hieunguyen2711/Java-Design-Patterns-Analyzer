package hotel;

public class RegularPriceStrategy implements PriceStrategy {
    @Override
    public double calculatePrice(double basePrice) {
        return basePrice;
    }
}