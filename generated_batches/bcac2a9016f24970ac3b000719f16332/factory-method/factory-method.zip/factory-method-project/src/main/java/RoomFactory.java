public abstract class RoomFactory {
    public abstract Room createRoom(String roomId, double basePrice);
    
    public Room createStandardRoom(String roomId, double basePrice) {
        return new StandardRoom(roomId, basePrice);
    }
    
    public Room createDeluxeRoom(String roomId, double basePrice) {
        return new DeluxeRoom(roomId, basePrice);
    }
    
    public Room createSuiteRoom(String roomId, double basePrice) {
        return new SuiteRoom(roomId, basePrice);
    }
}