public class SuiteRoom extends Room {
    public SuiteRoom(String roomId, double basePrice) {
        super(roomId, basePrice);
    }
    
    @Override
    public double calculateFinalPrice(int numberOfNights) {
        return basePrice * numberOfNights * 2.0;
    }
}