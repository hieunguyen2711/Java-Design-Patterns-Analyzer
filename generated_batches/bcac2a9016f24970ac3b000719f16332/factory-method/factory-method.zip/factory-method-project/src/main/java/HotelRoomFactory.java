public class HotelRoomFactory extends RoomFactory {
    @Override
    public Room createRoom(String roomId, double basePrice) {
        // This method demonstrates the factory method pattern
        // by providing a way to create different types of rooms
        return new StandardRoom(roomId, basePrice);
    }