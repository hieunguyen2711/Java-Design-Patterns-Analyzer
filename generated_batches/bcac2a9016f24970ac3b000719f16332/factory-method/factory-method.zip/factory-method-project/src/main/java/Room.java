public abstract class Room {
    protected String roomId;
    protected double basePrice;
    
    public Room(String roomId, double basePrice) {
        this.roomId = roomId;
        this.basePrice = basePrice;
    }
    
    public abstract double calculateFinalPrice(int numberOfNights);
    
    public String getRoomId() {
        return roomId;
    }
    
    public double getBasePrice() {
        return basePrice;
    }
}