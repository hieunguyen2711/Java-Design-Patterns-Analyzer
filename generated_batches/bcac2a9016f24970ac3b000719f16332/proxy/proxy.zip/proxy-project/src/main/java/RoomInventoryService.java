public interface RoomInventoryService {
    boolean isRoomAvailable(int roomId);
    void bookRoom(int roomId);
    void checkoutRoom(int roomId);
}