public class RoomInventoryProxy implements RoomInventoryService {
    private RealRoomInventoryService realService;
    private String currentUser;
    
    public RoomInventoryProxy(String currentUser) {
        this.currentUser = currentUser;
        this.realService = new RealRoomInventoryService();
    }
    
    @Override
    public boolean isRoomAvailable(int roomId) {
        System.out.println("Checking availability for room " + roomId + 
                          " by user: " + currentUser);
        return realService.isRoomAvailable(roomId);
    }
    
    @Override
    public void bookRoom(int roomId) {
        if (isAdmin()) {
            System.out.println("Admin " + currentUser + " booking room " + roomId);
            realService.bookRoom(roomId);
        } else {
            System.out.println("User " + currentUser + " attempting to book room " + 
                             roomId + ". Only admins can book rooms.");
        }