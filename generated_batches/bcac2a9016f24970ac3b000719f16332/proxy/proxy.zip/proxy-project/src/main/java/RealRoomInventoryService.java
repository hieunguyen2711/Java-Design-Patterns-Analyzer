import java.util.HashSet;
import java.util.Set;

public class RealRoomInventoryService implements RoomInventoryService {
    private Set<Integer> availableRooms;
    private Set<Integer> bookedRooms;
    
    public RealRoomInventoryService() {
        this.availableRooms = new HashSet<>();
        this.bookedRooms = new HashSet<>();
        
        // Initialize with some rooms
        for (int i = 1; i <= 10; i++) {
            availableRooms.add(i);
        }
    }
    
    @Override
    public boolean isRoomAvailable(int roomId) {
        return availableRooms.contains(roomId);
    }
    
    @Override
    public void bookRoom(int roomId) {
        if (availableRooms.remove(roomId)) {
            bookedRooms.add(roomId);
            System.out.println("Room " + roomId + " booked successfully.");
        } else {
            System.out.println("Room " + roomId + " is not available.");
        }
    }
    
    @Override
    public void checkoutRoom(int roomId) {
        if (bookedRooms.remove(roomId)) {
            availableRooms.add(roomId);
            System.out.println("Guest checked out from room " + roomId);
        } else {
            System.out.println("Room " + roomId + " was not booked.");
        }
    }
}