package hotel.service;

import java.util.*;

public class BillingService {
    private final Map<String, Bill> bills;
    private final RoomInventoryService inventoryService;
    
    public BillingService(RoomInventoryService inventoryService) {