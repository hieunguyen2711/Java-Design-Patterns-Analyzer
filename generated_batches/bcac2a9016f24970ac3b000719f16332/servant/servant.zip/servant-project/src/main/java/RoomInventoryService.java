package hotel.service;

import java.util.*;

public class RoomInventoryService {
    private final Map<String, Room> rooms;
    
    public RoomInventoryService() {
        this.rooms = new HashMap<>();
        initializeRooms();
    }
    
    private void initializeRooms() {
        rooms.put("101", new Room("101", "Single", 100.0));
        rooms.put("102", new Room("102", "Double", 150.0));
        rooms.put("103", new Room("103", "Suite", 300.0));
    }
    
    public List<Room> getAllRooms() {
        return new ArrayList<>(rooms.values());
    }
    
    public Room getRoom(String roomId) {
        return rooms.get(roomId);
    }
    
    public boolean isAvailable(String roomId) {
        Room room = rooms.get(roomId);
        return room != null && !room.isBooked();
    }
}