package hotel.service;

import java.util.*;

public class BookingService {
    private final Map<String, Booking> bookings;
    private final RoomInventoryService inventoryService;
    
    public BookingService(RoomInventoryService inventoryService) {
        this.inventoryService = inventoryService;
        this.bookings = new HashMap<>();
    }
    
    public String bookRoom(String roomId, Guest guest, Date checkInDate, int nights) {
        if (!inventoryService.isAvailable(roomId)) {
            return "Room not available";
        }
        
        Room room = inventoryService.getRoom(roomId);
        Booking booking = new Booking(roomId, guest, checkInDate, nights);
        bookings.put(booking.getId(), booking);
        room.setBooked(true);
        
        return booking.getId();
    }
    
    public List<Booking> getGuestBookings(Guest guest) {
        List<Booking> guestBookings = new ArrayList<>();
        for (Booking booking : bookings.values()) {
            if (booking.getGuest().equals(guest)) {
                guestBookings.add(booking);
            }
        }
        return guestBookings;
    }
}