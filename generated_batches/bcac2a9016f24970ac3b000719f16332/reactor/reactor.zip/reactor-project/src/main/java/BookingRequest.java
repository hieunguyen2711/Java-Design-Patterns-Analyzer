package com.example.reactor;

public class BookingRequest {
    private final String roomType;
    private final int duration;
    private final String checkIn