package com.example.reactor;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

public class RoomInventorySystem {
    private final ExecutorService executor = Executors.newFixedThreadPool(4);
    
    public static void main(String[] args) {
        RoomInventorySystem system = new RoomInventorySystem();
        
        // Simulate booking request
        CompletableFuture<BookingResponse> bookingFuture = system.processBooking(
            new BookingRequest("Deluxe", 2, "2023-12-01"));
        
        // Handle response asynchronously
        bookingFuture.thenAccept(response -> {
            System.out.println("Booking confirmed: " + response.getConfirmationNumber());
        });
        
        // Simulate check-in request
        CompletableFuture<CheckInResponse> checkinFuture = system.processCheckIn(
            new CheckInRequest("CONF123", "John Doe"));
            
        checkinFuture.thenAccept(response -> {
            System.out.println("Check-in successful: " + response.getGuestName());
        });
        
        // Keep main thread alive to see results
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
    
    public CompletableFuture<BookingResponse> processBooking(BookingRequest request) {
        return CompletableFuture.supplyAsync(() -> {
            // Simulate booking processing delay
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            
            String confirmationNumber = "CONF" + System.currentTimeMillis() % 1000;
            return new BookingResponse(confirmationNumber, request.getRoomType(), 
                                    request.getDuration());
        }, executor);
    }
    
    public CompletableFuture<CheckInResponse> processCheckIn(CheckInRequest request) {
        return CompletableFuture.supplyAsync(() -> {
            // Simulate check-in processing delay
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            
            return new CheckInResponse(request.getConfirmationNumber(), 
                                    request.getGuestName());
        }, executor);
    }
}