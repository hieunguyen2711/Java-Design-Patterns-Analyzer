package com.example.hotel;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RoomMapper {
    
    private Connection connection;
    
    public RoomMapper(Connection connection) {
        this.connection = connection;
    }
    
    public Room findById(int roomId) throws SQLException {
        String sql = "SELECT * FROM rooms WHERE room_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, roomId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapRowToRoom(rs);
            }
        }
        return null;
    }
    
    public List<Room> findAll() throws SQLException {
        List<Room> rooms = new ArrayList<>();
        String sql = "SELECT * FROM rooms";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                rooms.add(mapRowToRoom(rs));
            }
        }
        return rooms;
    }
    
    public void save(Room room) throws SQLException {
        if (room.getRoomId() > 0) {
            update(room);
        } else {
            insert(room);
        }
    }
    
    private void insert(Room room) throws SQLException {