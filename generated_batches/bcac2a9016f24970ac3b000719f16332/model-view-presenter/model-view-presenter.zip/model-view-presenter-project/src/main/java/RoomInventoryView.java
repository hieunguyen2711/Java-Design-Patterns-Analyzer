package com.hotel.inventory.view;

import com.hotel.inventory.model.Room;
import java.util.Map;

public interface RoomInventoryView {
    void displayRooms(Map<Integer, Room> rooms);
    void showRoomDetails(Room room);
    void showMessage(String message);
    int getUserInput();
}