package com.hotel.inventory.model;

import java.util.HashMap;
import java.util.Map;

public class RoomInventoryModel {
    private Map<Integer, Room> rooms;
    
    public RoomInventoryModel() {
        this.rooms = new HashMap<>();
        initializeRooms();
    }
    
    private void initializeRooms() {
        rooms.put(101, new Room(101, "Single", 100.0));
        rooms.put(102, new Room(102, "Double", 150.0));
        rooms.put(103, new Room(103, "Suite", 300.0));
    }
    
    public Map<Integer, Room> getRooms() {
        return rooms;
    }
    
    public Room getRoom(int roomId) {
        return rooms.get(roomId);
    }
    
    public void updateRoom(Room room) {
        rooms.put(room.getId(), room);
    }
}