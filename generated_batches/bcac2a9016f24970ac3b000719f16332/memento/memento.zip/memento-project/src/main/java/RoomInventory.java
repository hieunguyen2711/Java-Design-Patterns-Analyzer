package hotel.inventory;

import java.util.*;

public class RoomInventory {
    private Map<String, Room> rooms;
    
    public RoomInventory() {
        this.rooms = new HashMap<>();
        initializeRooms();
    }
    
    private void initializeRooms() {
        rooms.put("101", new Room("101", "Single", 100.0));
        rooms.put("102", new Room("102", "Double", 150.0));
        rooms.put("103", new Room("103", "Suite", 300.0));
    }
    
    public Room getRoom(String roomId) {
        return rooms.get(roomId);
    }
    
    public List<Room> getAllRooms() {
        return new ArrayList<>(rooms.values());
    }
    
    public Memento saveState() {
        return new Memento(new HashMap<>(rooms));
    }
    
    public void restoreState(Memento memento) {
        this.rooms = memento.getState();
    }
}