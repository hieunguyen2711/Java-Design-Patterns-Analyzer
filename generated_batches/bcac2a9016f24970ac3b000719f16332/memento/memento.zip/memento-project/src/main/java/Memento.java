package hotel.inventory;

import java.util.Map;

public class Memento {
    private final Map<String, Room> state;
    
    public Memento(Map<String, Room> state) {
        this.state = new HashMap<>(state);
    }
    
    public Map<String, Room> getState