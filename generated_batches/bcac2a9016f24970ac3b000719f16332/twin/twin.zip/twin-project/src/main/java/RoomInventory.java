package com.hotel.inventory;

import java.util.*;

public class RoomInventory {
    private final Map<Integer, Room> rooms;
    
    public RoomInventory() {
        this.rooms = new HashMap<>();
    }
    
    public void addRoom(Room room) {
        rooms.put(room.getRoomId(), room);
    }
    
    public Room findAvailableRoom(String type) {
        return rooms.values().stream()
                .filter(room -> room.getType().equals(type))
                .filter(Room::isAvailable)
                .findFirst()
                .orElse(null);
    }
    
    public List<Room> getAllRooms() {
        return new ArrayList<>(rooms.values());
    }
}