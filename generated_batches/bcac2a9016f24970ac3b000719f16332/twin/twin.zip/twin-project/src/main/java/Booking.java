package com.hotel.inventory;

import java.time.LocalDate;
import java.util.Objects;

public class Booking {
    private final int bookingId;
    private final Room room;
    private final LocalDate checkInDate;
    private final LocalDate checkOutDate;
    
    public Booking(int bookingId, Room room, LocalDate checkInDate, LocalDate checkOutDate) {
        this.bookingId = bookingId;
        this.room = room;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
    }
    
    public int getBookingId() {
        return bookingId;
    }
    
    public Room getRoom() {
        return room;
    }
    
    public LocalDate getCheckInDate() {
        return checkInDate;
    }
    
    public LocalDate getCheckOutDate() {
        return checkOutDate;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Booking booking = (Booking) o;
        return booking