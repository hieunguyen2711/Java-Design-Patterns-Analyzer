package com.hotel.inventory;

import java.time.LocalDate;
import java.util.Objects;

public class Booking {
    private final int bookingId;
    private final Room room;
    private final LocalDate checkInDate;
    private final LocalDate checkOutDate;
    private final String guestName;
    
    public Booking(int bookingId, Room room, LocalDate checkInDate, 
                   LocalDate checkOutDate, String guestName) {
        this.bookingId = bookingId;
        this.room = room;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.guestName = guestName;
    }
    
    public int getBookingId() {
        return bookingId;
    }
    
    public Room getRoom() {
        return room;
    }
    
    public LocalDate getCheckInDate() {
        return checkInDate;
    }
    
    public LocalDate getCheckOutDate() {
        return checkOutDate;
    }
    
    public String getGuestName() {
        return guestName;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass()