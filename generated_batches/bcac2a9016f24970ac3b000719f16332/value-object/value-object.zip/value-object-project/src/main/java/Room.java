package com.hotel.inventory;

public class Room {
    private final int roomId;
    private final String roomType;
    private final double nightlyRate;
    
    public Room(int roomId, String roomType, double nightlyRate) {
        this.roomId = roomId;
        this.roomType = roomType;
        this.nightlyRate = nightlyRate;
    }
    
    public int getRoomId() {
        return roomId;
    }
    
    public String getRoomType() {
        return roomType;
    }
    
    public double getNightlyRate() {
        return nightlyRate;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        
        Room room = (Room) obj;
        return roomId == room.roomId;
    }
    
    @Override
    public int hashCode() {
        return Integer.hashCode(roomId);
    }
    
    @Override
    public String toString() {
        return "Room{" +
                "roomId=" + roomId +
                ", roomType='" + roomType + '\'' +
                ", nightlyRate=" + nightlyRate +
                '}';
    }
}