public class Main {
    public static void main(String[] args) {
        RoomInventory inventory = new RoomInventory();
        
        inventory.addRoom(new Room(101, "Single", 100.0));
        inventory.addRoom(new Room(102, "Double", 150.0));
        inventory.addRoom(new Room(103, "Suite", 300.0));
        
        System.out.println("Rooms in inventory:");
        for (Room room : inventory) {
            System.out.println("Room " + room.getRoomId() + 
                             " (" + room.getRoomType() + 
                             ") - $" + room.getPricePerNight() + "/night");
        }
    }
}