import java.util.ArrayList;
import java.util.Iterator;

public class RoomInventory implements Iterable<Room> {
    private ArrayList<Room> rooms;
    
    public RoomInventory() {
        this.rooms = new ArrayList<>();
    }
    
    public void addRoom(Room room) {
        rooms.add(room);
    }
    
    @Override
    public Iterator<Room> iterator() {
        return rooms.iterator();
    }
}