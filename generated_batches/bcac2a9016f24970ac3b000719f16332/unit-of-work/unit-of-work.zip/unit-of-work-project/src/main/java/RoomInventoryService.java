package com.hotel.inventory;

import java.util.*;

public class RoomInventoryService {
    private final Map<Integer, Room> rooms;
    private final UnitOfWork unitOfWork;
    
    public RoomInventoryService() {
        this.rooms = new HashMap<>();
        this.unitOfWork = new UnitOfWork();
        initializeRooms();
    }
    
    private void initializeRooms() {
        rooms.put(101, new Room(101, "Single", 100.0));
        rooms.put(102, new Room(102, "Double", 150.0));
        rooms.put(103, new Room(103, "Suite", 300.0));
    }
    
    public Booking bookRoom(int roomId, String guestName, Date checkIn, Date checkOut) {
        Room room = rooms.get(roomId);
        if (room == null || !room.isAvailable()) {
            throw new IllegalArgumentException("Room not available");
        }
        
        Booking booking = new Booking(roomId, guestName, checkIn, checkOut);
        unitOfWork.registerNew(booking);
        room.setAvailable(false);
        unitOfWork.registerDirty(room);
        
        return booking;
    }
    
    public void checkIn(int roomId) {
        Room room = rooms.get(roomId);
        if (room == null || room.isAvailable()) {
            throw new IllegalArgumentException("Room not booked");
        }
        
        room.setCheckIn(true);
        unitOfWork.registerDirty(room);
    }
    
    public void commit() {
        unitOfWork.commit();
    }
}