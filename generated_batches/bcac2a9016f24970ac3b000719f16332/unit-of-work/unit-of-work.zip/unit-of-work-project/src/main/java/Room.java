package com.hotel.inventory;

import java.util.Date;

public class Room {
    private final int roomId;
    private final String type;
    private final double pricePerNight;
    private boolean available;
    private boolean checkedIn;
    
    public Room(int roomId, String type, double pricePerNight) {
        this.roomId = roomId;
        this.type = type;
        this.pricePerNight = pricePerNight;
        this.available = true;
        this.checkedIn = false;
    }
    
    // Getters and setters
    public int getRoomId() { return roomId; }
    public String getType() { return type; }
    public double getPricePerNight() { return pricePerNight; }
    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available;