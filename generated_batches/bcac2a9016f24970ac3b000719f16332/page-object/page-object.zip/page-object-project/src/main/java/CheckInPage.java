package com.hotel.pages;

import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;

public class CheckInPage {
    private List<Guest> checkedInGuests;
    
    public CheckInPage() {
        this.checkedInGuests = new ArrayList<>();
    }
    
    public boolean checkInGuest(String guestName, String roomId, LocalDate checkInDate) {
        Guest guest = new Guest(guestName, roomId, checkInDate);
        checkedInGuests.add(guest);
        return true;
    }
    
    public List<Guest> getCheckedInGuests() {
        return