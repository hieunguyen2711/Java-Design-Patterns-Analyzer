package com.hotel.pages;

import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;

public class BookingPage {
    private List<Booking> bookings;
    
    public BookingPage() {
        this.bookings = new ArrayList<>();
    }
    
    public Booking createBooking(String guestName, String roomId, 
                               LocalDate checkInDate, LocalDate checkOutDate) {
        Room room = findRoomById(roomId);
        if (room != null && room.isAvailable()) {
            Booking booking = new Booking(guestName, roomId, checkInDate, checkOutDate);
            bookings.add(booking);
            room.setAvailable(false);
            return booking;
        }
        return null;
    }
    
    private Room findRoomById(String roomId) {
        // This would typically be implemented with a repository or service
        return new Room(roomId); // Simplified for example
    }
}