public class Room {
    private String roomId;
    private RoomState state;
    
    public Room(String roomId) {
        this.roomId = roomId;
        this.state = new AvailableState();
    }
    
    public void setState(RoomState state) {
        this.state = state;
    }
    
    public void checkIn() {
        state.checkIn(this);
    }
    
    public void checkOut() {
        state.checkOut(this);
    }
    
    public void updateStatus(String status) {
        System.out.println("Room " + roomId + " status updated to: " + status);
    }
    
    public String getRoomId() {
        return roomId;
    }
}