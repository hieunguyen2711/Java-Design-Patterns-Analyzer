public class CleaningState implements RoomState {
    @Override
    public void checkIn(Room room) {
        System.out.println("Cannot check in to cleaning room " + room.getRoomId());
    }
    
    @Override
    public void checkOut(Room room) {
        System.out.println("Room " + room.getRoomId() + " is being cleaned");
    }
}