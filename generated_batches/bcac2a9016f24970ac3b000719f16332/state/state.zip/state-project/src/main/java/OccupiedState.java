public class OccupiedState implements RoomState {
    @Override
    public void checkIn(Room room) {
        System.out.println("Room " + room.getRoomId() + " is already occupied");
    }
    
    @Override
    public void checkOut(Room room) {
        System.out.println("Checking out guest from room " + room.getRoomId());
        room.updateStatus("Cleaning");
        room.setState(new CleaningState());
    }
}