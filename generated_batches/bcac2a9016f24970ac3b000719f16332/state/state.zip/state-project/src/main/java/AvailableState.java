public class AvailableState implements RoomState {
    @Override
    public void checkIn(Room room) {
        System.out.println("Checking in guest to room " + room.getRoomId());
        room.updateStatus("Occupied");
        room.setState(new OccupiedState());
    }
    
    @Override
    public void checkOut(Room room) {
        System.out.println("Cannot checkout from available room " + room.getRoomId());
    }
}