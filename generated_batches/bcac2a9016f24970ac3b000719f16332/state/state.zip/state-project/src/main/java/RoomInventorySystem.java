public class RoomInventorySystem {
    public static void main(String[] args) {
        Room room1 = new Room("1