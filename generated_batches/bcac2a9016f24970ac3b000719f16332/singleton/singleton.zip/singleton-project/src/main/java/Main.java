public class Main {
    public static void main(String[] args) {
        BookingSystem system1 = new BookingSystem();
        BookingSystem system2 = new BookingSystem();
        
        System.out.println("Initial rooms: " + RoomInventory.getInstance().getAvailableRooms());
        
        system1.bookRoom();
        system2.bookRoom();
        
        System.out.println("After 2 bookings: " + RoomInventory.getInstance().getAvailableRooms());
        
        system1.checkOutRoom();
        System.out.println("After checkout: " + RoomInventory.getInstance().getAvailableRooms());
    }
}