public class RoomInventory {
    private static volatile RoomInventory instance;
    private int availableRooms;
    
    private RoomInventory() {
        this.availableRooms = 100;
    }
    
    public static RoomInventory getInstance() {
        if (instance == null) {
            synchronized (RoomInventory.class) {
                if (instance == null) {
                    instance = new RoomInventory();
                }
            }
        }
        return instance;
    }
    
    public boolean bookRoom() {
        if (availableRooms > 0) {
            availableRooms--;
            return true;
        }
        return false;
    }
    
    public void checkOutRoom() {
        availableRooms++;
    }
    
    public int getAvailableRooms() {
        return availableRooms;
    }
}