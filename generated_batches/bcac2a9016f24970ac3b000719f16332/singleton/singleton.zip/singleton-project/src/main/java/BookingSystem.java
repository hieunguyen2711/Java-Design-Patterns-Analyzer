public class BookingSystem {
    private RoomInventory inventory;
    
    public BookingSystem() {
        this.inventory = RoomInventory.getInstance();
    }
    
    public boolean bookRoom() {
        return inventory.bookRoom();
    }
    
    public void checkOutRoom() {
        inventory.checkOutRoom();
    }
}