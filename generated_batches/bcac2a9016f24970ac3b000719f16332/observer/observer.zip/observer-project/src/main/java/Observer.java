package hotel;

public interface Observer {
    void update(Room room);
}