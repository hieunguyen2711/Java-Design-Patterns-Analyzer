package hotel;

public class NotificationService implements Observer {
    private String serviceName;
    
    public NotificationService(String serviceName) {
        this.serviceName = serviceName;
    }
    
    @Override
    public void update(Room room) {
        System.out.println(serviceName + "