package hotel;

public class BillingSystem implements Observer {
    private String systemName;
    
    public BillingSystem(String systemName) {
        this.systemName = systemName;
    }
    
    @Override
    public void update(Room room) {
        System.out.println(systemName + " notified of room " + 
                          room.getRoomId() + " availability change");
        if (room.isAvailable()) {
            System.out.println("  Room " + room.getRoomId() + " is now available for booking");
        } else {
            System.out.println("  Room " + room.getRoomId() + " has been booked");
        }
    }
}