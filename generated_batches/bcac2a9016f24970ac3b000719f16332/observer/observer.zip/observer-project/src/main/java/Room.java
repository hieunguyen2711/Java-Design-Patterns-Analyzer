package hotel;

import java.util.ArrayList;
import java.util.List;

public class Room {
    private int roomId;
    private String roomType;
    private double basePrice;
    private boolean isAvailable;
    private List<Observer> observers;

    public Room(int roomId, String roomType, double basePrice) {
        this.roomId = roomId;
        this.roomType = roomType;
        this.basePrice = basePrice;
        this.isAvailable = true;
        this.observers = new ArrayList<>();
    }

    public void addObserver(Observer observer) {
        observers.add(observer);
    }

    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(this);
        }
    }

    public void bookRoom() {
        if (isAvailable) {
            isAvailable = false;
            notifyObservers();
        }
    }

    public void checkOut() {
        isAvailable = true;
        notifyObservers();
    }

    // Getters and setters
    public int getRoomId() { return roomId; }
    public String getRoomType() { return roomType; }
    public double getBasePrice() { return basePrice; }
    public boolean isAvailable() { return isAvailable; }
}