package com.hotel.service;

import java.math.BigDecimal;
import java.util.List;

public interface GuestBillingService {
    BigDecimal calculateTotalBill(int guestId);
    List<BillItem> getGuestBillItems(int guestId);
    void processPayment(int guestId, BigDecimal amount);
}