package com.hotel.service;

import java.util.List;
import java.time.LocalDate;

public interface BookingService {
    Booking createBooking(int guestId, int roomId, LocalDate checkInDate, LocalDate checkOutDate);
    void cancelBooking(int bookingId);
    List<Booking> getGuestBookings(int guestId);
}