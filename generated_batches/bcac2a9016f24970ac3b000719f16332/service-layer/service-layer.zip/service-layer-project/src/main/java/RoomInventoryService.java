package com.hotel.service;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.time.LocalDate;

public interface RoomInventoryService {
    List<Room> getAvailableRooms(LocalDate checkInDate, LocalDate checkOutDate);
    boolean isRoomAvailable(int roomId, LocalDate checkInDate, LocalDate checkOutDate);
    void updateRoomAvailability(int roomId, LocalDate checkInDate, LocalDate checkOutDate, boolean available);
}