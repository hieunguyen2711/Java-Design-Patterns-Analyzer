package com.hotel.model;

import java.math.BigDecimal;
import java.util.List;
import java.time.LocalDate;

public class Room {
    private int id;
    private String roomType;
    private BigDecimal baseRate;
    private List<RoomAvailability> availability;
    
    public Room(int id, String roomType, BigDecimal baseRate) {
        this.id = id;
        this.roomType = roomType;
        this.baseRate = baseRate;
    }
    
    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getRoomType() { return roomType; }
    public void setRoomType(String roomType) { this.roomType = roomType; }
    
    public BigDecimal getBaseRate() { return baseRate; }
    public void setBaseRate(BigDecimal baseRate) { this.base