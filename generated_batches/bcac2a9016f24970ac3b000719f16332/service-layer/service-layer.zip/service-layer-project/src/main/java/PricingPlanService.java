package com.hotel.service;

import java.math.BigDecimal;
import java.time.LocalDate;

public interface PricingPlanService {
    BigDecimal calculatePrice(int roomId, LocalDate checkInDate, LocalDate checkOutDate);
    void updatePricingPlan(int roomId, BigDecimal baseRate, LocalDate effectiveDate);
}