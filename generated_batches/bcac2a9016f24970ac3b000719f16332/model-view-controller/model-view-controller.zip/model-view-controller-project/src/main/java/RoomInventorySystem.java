public class RoomInventorySystem {
    public static void main(String[] args) {
        // Create the model
        RoomModel model = new RoomModel();
        
        // Create the view
        RoomView view = new RoomView();
        
        // Create the controller
        RoomController controller = new RoomController(model, view);
        
        // Initialize with some data
        controller.addRoom("Deluxe", 200.0);
        controller.addRoom("Suite", 350.0);
        controller.addRoom("Standard", 150.0);
        
        // Display initial inventory
        controller.displayInventory();
        
        // Make a booking
        controller.bookRoom(0, "John Doe");
        controller.displayInventory();
    }
}