import java.util.ArrayList;
import java.util.List;

public class RoomModel {
    private List<Room> rooms;
    
    public RoomModel() {
        this.rooms = new ArrayList<>();
    }
    
    public void addRoom(String type, double price) {
        rooms.add(new Room(type, price));
    }
    
    public List<Room> getRooms() {
        return rooms;
    }
    
    public void bookRoom(int index, String guestName) {
        if (index >= 0 && index < rooms.size()) {
            rooms.get(index).setBooked(true);
            rooms.get(index).setGuestName(guestName);
        }
    }
    
    public void checkOutRoom(int index) {
        if (index >= 0 && index < rooms.size()) {
            rooms.get(index).setBooked(false);
            rooms.get(index).setGuestName(null);
        }
    }
}