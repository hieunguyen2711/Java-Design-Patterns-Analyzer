import java.util.List;

public class RoomView {
    
    public void displayInventory(List<Room> rooms) {
        System.out.println("=== ROOM INVENTORY ===");
        for (int i = 0; i < rooms.size(); i++) {
            Room room = rooms.get(i);
            String status = room.isBooked() ? "BOOKED by " + room.getGuestName() : "AVAILABLE";
            System.out.printf("%d. %s - $%.2f (%s)%n", 
                i, room.getType(), room.getPrice(), status);
        }
        System.out.println();
    }
    
    public void displayMessage(String message) {
        System.out