public interface RoomService {
    double calculatePrice();
    String getServiceDescription();
}