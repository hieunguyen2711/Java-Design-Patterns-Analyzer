public class BasicRoomService implements RoomService {
    private Room room;
    
    public BasicRoomService(Room room) {
        this.room = room;
    }
    
    @Override
    public double calculatePrice() {
        return room.getBasePrice();
    }
    
    @Override
    public String getServiceDescription() {
        return "Basic room service for room " + room.getRoomId();
    }
}