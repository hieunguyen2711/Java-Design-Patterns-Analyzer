public class RoomBookingSystem {
    public static void main(String[] args) {
        // Create a basic room
        Room room = new Room