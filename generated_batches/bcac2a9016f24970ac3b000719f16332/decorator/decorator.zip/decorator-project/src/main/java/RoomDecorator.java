public abstract class RoomDecorator implements RoomService {
    protected RoomService roomService;
    
    public RoomDecorator(RoomService roomService) {
        this.roomService = roomService;
    }
}