public class Room {
    private String roomId;
    private double basePrice;
    
    public Room(String roomId, double basePrice) {
        this.roomId = roomId;
        this.basePrice = basePrice;
    }
    
    public double getBasePrice() {
        return basePrice;
    }
    
    public String getRoomId() {
        return roomId;
    }
}