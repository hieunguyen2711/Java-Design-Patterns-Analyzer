public class BreakfastDecorator extends RoomDecorator {
    private static final double BREAKFAST_PRICE = 25.0;
    
    public BreakfastDecorator(RoomService roomService) {
        super(roomService);
    }
    
    @Override
    public double calculatePrice() {
        return roomService.calculatePrice() + BREAKFAST_PRICE;
    }
    
    @Override
    public String getServiceDescription() {
        return roomService.getServiceDescription() + " with breakfast";
    }
}