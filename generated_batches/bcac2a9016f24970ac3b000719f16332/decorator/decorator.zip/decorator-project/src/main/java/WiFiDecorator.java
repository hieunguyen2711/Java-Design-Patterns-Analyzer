public class WiFiDecorator extends RoomDecorator {
    private static final double WIFI_PRICE = 15.0;
    
    public WiFiDecorator(RoomService roomService) {
        super(roomService);
    }
    
    @Override
    public double calculatePrice() {
        return roomService.calculatePrice() + WIFI_PRICE;
    }
    
    @Override
    public String getServiceDescription() {
        return roomService.getServiceDescription() + " with WiFi";
    }
}