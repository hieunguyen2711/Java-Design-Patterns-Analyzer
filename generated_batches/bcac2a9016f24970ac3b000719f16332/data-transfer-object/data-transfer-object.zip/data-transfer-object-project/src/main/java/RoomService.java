package hotel.service;

import hotel.model.Room;
import hotel.dto.RoomDTO;

public class RoomService {
    
    public RoomDTO getRoomDetails(int roomId) {
        // Simulate fetching from database
        Room room = new Room(roomId, "Deluxe", true);
        
        // Transform to DTO for transfer
        return new RoomDTO(
            room.getRoomId(),
            room.getRoomType(),
            room.isAvailable()
        );
    }
    
    public void updateRoom(RoomDTO roomDTO) {
        // Simulate updating database with DTO data
        System.out.println("Updating room " + roomDTO.getRoomId() + 
                          " with type: " + roomDTO.getRoomType());
    }
}