import java.util.HashMap;
import java.util.Map;

public class RoomActor extends Actor {
    private final Map<String, Room> rooms = new HashMap<>();
    
    @Override
    protected void handle(Message message) {
        switch (message.getType()) {
            case "CREATE_ROOM":
                createRoom((String) message.getPayload());
                break;
            case "BOOK_ROOM":
                bookRoom((BookingRequest) message.getPayload());
                break;
            case "CHECK_IN":
                checkIn((CheckInRequest) message.getPayload());
                break;
            case "CHECK_OUT":
                checkOut((CheckOutRequest) message.getPayload());
                break;
        }
    }
    
    private void createRoom(String roomId) {
        rooms.put(roomId, new Room(roomId));
        System.out.println("Room " + roomId + " created");
    }
    
    private void bookRoom(BookingRequest request) {
        Room room = rooms.get(request.getRoomId());
        if (room != null && !room.isBooked()) {
            room.book(request.getGuestName(), request.getCheckInDate(), request.getCheckOutDate());
            System.out.println("Room " + request.getRoomId() + " booked for " + request.getGuestName());
        }
    }
    
    private void checkIn(CheckIn