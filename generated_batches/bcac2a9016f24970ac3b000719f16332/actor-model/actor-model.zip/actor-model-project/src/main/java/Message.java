public class Message {
    private final Object payload;
    private final String type;
    
    public Message(Object payload, String type) {
        this.payload = payload;
        this.type = type;
    }
    
    public Object getPayload() {
        return payload;
    }
    
    public String getType() {
        return type;
    }
}