package hotel.inventory;

import java.time.LocalDate;
import java.util.List;

public class Room {
    private final String roomId;
    private final int capacity;
    private final List<String> amenities;
    
    public Room(String roomId, int capacity, List<String> amenities) {
        this.roomId = roomId;
        this.capacity = capacity;
        this.amenities = amenities;
    }
    
    public String getRoomId() {
        return roomId;
    }
    
    public int getCapacity() {
        return capacity;
    }
    
    public List<String> getAmenities() {
        return amenities;
    }
}