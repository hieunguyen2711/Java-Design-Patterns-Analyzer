package hotel.booking;

import hotel.inventory.RoomInventory;
import java.time.LocalDate;
import java.util.Optional;

public class BookingService {
    
    public RoomInventory findAvailableRoom(LocalDate checkIn, LocalDate checkOut) {
        // Simulate finding a room
        return RoomInventory.of(new Room("101", 2, List.of("WiFi", "TV")));
    }
    
    public Optional<Booking> createBooking(RoomInventory inventory, 
                                         LocalDate checkIn, 
                                         LocalDate checkOut) {
        return inventory.map(room -> new Booking(room.getRoomId(), checkIn, checkOut));
    }
}