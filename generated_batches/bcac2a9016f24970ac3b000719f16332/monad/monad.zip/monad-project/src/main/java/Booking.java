package hotel.booking;

import java.time.LocalDate;

public class Booking {
    private final String roomId;
    private final LocalDate checkIn;
    private final LocalDate checkOut;
    
    public Booking(String roomId, LocalDate checkIn, LocalDate checkOut) {
        this.roomId = roomId;
        this.checkIn = checkIn;
        this.checkOut = checkOut;
    }
    
    public String getRoomId() {