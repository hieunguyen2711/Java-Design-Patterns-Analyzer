package hotel.inventory;

import java.util.Optional;
import java.util.function.Function;

public class RoomInventory {
    private final Optional<Room> room;
    
    private RoomInventory(Optional<Room> room) {
        this.room = room;
    }
    
    public static RoomInventory empty() {
        return new RoomInventory(Optional.empty());
    }
    
    public static RoomInventory of(Room room) {
        return new RoomInventory(Optional.ofNullable(room));
    }
    
    public <T> Optional<T> map(Function<Room, T> mapper) {
        return room.map(mapper);
    }
    
    public Optional<Room> get() {
        return room;
    }
}