package hotel.module;

import java.time.LocalDate;
import java.util.*;

public class CheckInOutModule {
    private Map<String, CheckInRecord> checkIns;
    
    public CheckInOutModule() {
        this.checkIns = new HashMap<>();
    }
    
    public String checkIn(String bookingId, LocalDate checkInDate) {
        String recordId = UUID.randomUUID().toString();
        CheckInRecord record = new CheckInRecord(recordId, bookingId, checkInDate);
        checkIns.put(recordId, record);
        return recordId;
    }
    
    public CheckInRecord getCheckIn(String recordId) {
        return checkIns.get(recordId);
    }
    
    public List<CheckInRecord> getAllCheckIns() {
        return new ArrayList<>(checkIns.values());
    }
}