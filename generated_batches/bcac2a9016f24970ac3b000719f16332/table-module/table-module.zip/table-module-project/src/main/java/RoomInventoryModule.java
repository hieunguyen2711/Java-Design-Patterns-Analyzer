package hotel.module;

import java.util.*;

public class RoomInventoryModule {
    private Map<String, Room> rooms;
    
    public RoomInventoryModule() {
        this.rooms = new HashMap<>();
    }
    
    public void addRoom(Room room) {
        rooms.put(room.getRoomNumber(), room);
    }
    
    public Room getRoom(String roomNumber) {
        return rooms.get(roomNumber);
    }
    
    public List<Room> getAllRooms() {
        return new ArrayList<>(rooms.values());
    }
    
    public boolean isAvailable(String roomNumber) {
        Room room = rooms.get(roomNumber);
        return room != null && !room.isOccupied();
    }
}