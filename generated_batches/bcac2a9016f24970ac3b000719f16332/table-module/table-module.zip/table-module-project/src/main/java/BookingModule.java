package hotel.module;

import java.time.LocalDate;
import java.util.*;

public class BookingModule {
    private Map<String, Booking> bookings;
    
    public BookingModule() {
        this.bookings = new HashMap<>();
    }
    
    public String createBooking(String guestName, String roomNumber, 
                               LocalDate checkInDate, LocalDate checkOutDate) {
        String bookingId = UUID.randomUUID().toString();
        Booking booking = new Booking(bookingId, guestName, roomNumber, 
                                    checkInDate, checkOutDate);
        bookings.put(bookingId, booking);
        return bookingId;
    }
    
    public Booking getBooking(String bookingId) {
        return bookings.get(bookingId);
    }
    
    public List<Booking> getAllBookings() {
        return new ArrayList<>(bookings.values());
    }
}