package com.lms.trampoline;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class CourseProgressCalculator {
    
    public static Trampoline<Integer> calculateTotalProgress(
            List<ModuleProgress> modules, 
            AtomicInteger totalPoints) {
        
        return calculateModuleProgress(modules, 0, totalPoints);
    }
    
    private static Trampoline<Integer> calculateModuleProgress(
            List<ModuleProgress> modules,
            int index,
            AtomicInteger totalPoints) {
        
        if (index >= modules.size()) {
            return Trampoline.done(totalPoints.get());
        }
        
        ModuleProgress module = modules.get(index);
        return Trampoline.more(() -> 
            calculateAssignmentProgress(module.assignments(), 0, module.moduleId(), totalPoints)
                .thenCompose(ignored -> calculateModuleProgress(modules, index + 1, totalPoints))
        );
    }
    
    private static Trampoline<Void> calculateAssignmentProgress(
            List<AssignmentProgress> assignments,
            int index,
            String moduleId,
            AtomicInteger totalPoints) {
        
        if (index >= assignments.size()) {
            return Trampoline.done(null);
        }
        
        AssignmentProgress assignment = assignments.get(index);
        return Trampoline.more(() -> 
            processSubmission(assignment.submissions(), 0, assignment.assignmentId(), totalPoints)
                .thenCompose(ignored -> calculateAssignmentProgress(assignments, index + 1,