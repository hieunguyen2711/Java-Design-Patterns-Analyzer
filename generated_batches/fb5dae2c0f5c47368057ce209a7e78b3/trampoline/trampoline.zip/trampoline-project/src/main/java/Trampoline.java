package com.lms.trampoline;

@FunctionalInterface
public interface Trampoline<T> {
    Result<T> compute();
    
    static <T> Trampoline<T> done(T value) {
        return () -> new Result.Done<>(value);
    }
    
    static <T> Trampoline<T> more(Trampoline<T> trampoline) {
        return () -> new Result.More<>(trampoline);
    }
    
    default T run() {
        Result<T> result = compute();
        while (result instanceof Result.More<T> more) {
            result = more.trampoline.compute();
        }
        return ((Result.Done<T>) result).value;
    }
}