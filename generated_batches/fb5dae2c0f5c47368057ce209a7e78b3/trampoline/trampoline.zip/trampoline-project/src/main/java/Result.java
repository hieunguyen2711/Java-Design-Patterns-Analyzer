package com.lms.trampoline;

public sealed interface Result<T> permits Result.Done, Result.More {
    
    record Done<T>(T value) implements Result<T> {}
    
    record More<T>(Trampoline<T> trampoline) implements Result<T> {}
}