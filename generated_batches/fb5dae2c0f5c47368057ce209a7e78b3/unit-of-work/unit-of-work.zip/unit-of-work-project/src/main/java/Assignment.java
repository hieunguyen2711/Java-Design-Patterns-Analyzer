package com.lms.domain;

public class Assignment {
    private String id;
    private String title;
    private LessonModule lessonModule;
    
    public Assignment(String id, String title, LessonModule lessonModule) {
        this.id = id;
        this.title = title;
        this.lessonModule = lessonModule;
    }
    
    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public LessonModule getLessonModule() { return lessonModule; }
    public void setLessonModule(LessonModule lessonModule) { this.lessonModule = lessonModule; }
}