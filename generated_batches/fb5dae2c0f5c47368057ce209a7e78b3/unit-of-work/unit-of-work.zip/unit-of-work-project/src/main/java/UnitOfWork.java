package com.lms.unitofwork;

import java.util.ArrayList;
import java.util.List;

public interface UnitOfWork {
    void registerNew(Object entity);
    void registerDirty(Object entity);
    void registerDeleted(Object entity);
    void commit();
}