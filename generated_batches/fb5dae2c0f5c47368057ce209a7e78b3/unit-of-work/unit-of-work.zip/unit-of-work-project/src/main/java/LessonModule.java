package com.lms.domain;

public class LessonModule {
    private String id;
    private String title;
    private Course course;
    
    public LessonModule(String id, String title, Course course) {
        this.id = id;
        this.title = title;
        this.course = course;
    }
    
    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public Course getCourse() { return course; }
    public void setCourse(Course course) { this.course = course; }
}