public class LMSApplication {
    public static void main(String[] args) {
        //