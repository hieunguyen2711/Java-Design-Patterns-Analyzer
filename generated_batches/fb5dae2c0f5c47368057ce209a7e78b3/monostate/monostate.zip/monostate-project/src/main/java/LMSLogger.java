public class LMSLogger {
    private static LMSLogger instance;
    private String logFile = "lms_system.log";
    private boolean debugMode = false;
    
    // Private constructor to prevent instantiation
    private LMSLogger() {}
    
    // Static method to get the single instance
    public static synchronized LMSLogger getInstance() {
        if (instance == null) {
            instance = new LMSLogger();
        }
        return instance;
    }
    
    public void setLogFile(String logFile) {
        this.logFile = logFile;
    }
    
    public void setDebugMode(boolean debugMode) {
        this.debugMode = debugMode;
    }
    
    public String getLogFile() {
        return logFile;
    }
    
    public boolean isDebugMode() {
        return debugMode;
    }
    
    public void log(String message) {
        System.out.println("[" + logFile + "] " + message);
    }
    
    public void debug(String message) {
        if (debugMode) {
            System.out.println("[DEBUG] " + message);
        }
    }
}