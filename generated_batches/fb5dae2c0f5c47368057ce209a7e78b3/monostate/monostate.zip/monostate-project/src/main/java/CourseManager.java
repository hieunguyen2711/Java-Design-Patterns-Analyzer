public class CourseManager {
    private LMSLogger logger;
    
    public CourseManager() {
        this.logger = LMSLogger.getInstance();
    }
    
    public void createCourse(String courseName) {
        logger.log("Creating course: " + courseName);
        logger.debug("Debug info - Creating new course");
    }
    
    public void updateCourse(String courseName, String newName) {
        logger.log("Updating course: " + courseName + " to " + newName);
        logger.debug("Debug info - Course update operation");
    }
}