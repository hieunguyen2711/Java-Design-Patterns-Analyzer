public class UserManager {
    private LMSLogger logger;
    
    public UserManager() {
        this.logger = LMSLogger.getInstance();
    }
    
    public void createUser(String username) {
        logger.log("Creating user: " + username);
        logger.debug("Debug info - User creation");
    }
    
    public void updateUser(String username, String newEmail) {
        logger.log("Updating user: " + username + " with email: " + newEmail);
        logger.debug("Debug info - User update operation");
    }
}