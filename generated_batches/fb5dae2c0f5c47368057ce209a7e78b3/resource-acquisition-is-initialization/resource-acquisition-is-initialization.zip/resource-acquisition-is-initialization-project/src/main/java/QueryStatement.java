import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class QueryStatement implements AutoCloseable {
    private PreparedStatement statement;
    
    public QueryStatement(PreparedStatement statement) {
        this.statement = statement;
    }
    
    public ResultSet executeQuery() throws SQLException {
        return statement.executeQuery();
    }
    
    @Override
    public void close() {
        try {
            if (statement != null && !statement.isClosed()) {
                statement.close();
                System.out.println("Query statement released");
            }
        } catch (SQLException e) {
            System.err.println("Error closing statement: " + e.getMessage());
        }
    }
}