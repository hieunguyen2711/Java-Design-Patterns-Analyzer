import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection implements AutoCloseable {
    private Connection connection;
    
    public DatabaseConnection() throws SQLException {
        // Resource acquisition in constructor - RAII pattern
        this.connection = DriverManager.getConnection(
            "jdbc:sqlite:test.db", "", "");
        System.out.println("Database connection acquired");
    }
    
    public QueryStatement prepareStatement(String sql) throws SQLException {
        return new QueryStatement(connection.prepareStatement(sql));
    }
    
    @Override
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("Database connection released");
            }
        } catch (SQLException e) {
            System.err.println("Error closing connection: " + e.getMessage());
        }
    }
}