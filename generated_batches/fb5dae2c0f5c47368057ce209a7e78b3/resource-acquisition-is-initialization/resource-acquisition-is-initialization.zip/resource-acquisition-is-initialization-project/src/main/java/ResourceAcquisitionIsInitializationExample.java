public class ResourceAcquisitionIsInitializationExample {
    public static void main(String[] args) {
        // Demonstrating RAII with AutoCloseable resources
        try (DatabaseConnection connection = new DatabaseConnection();
             QueryStatement statement = connection.prepareStatement("SELECT * FROM courses")) {
            
            // Use the resources - they are automatically cleaned up
            statement.executeQuery();
            
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
        
        // Manual cleanup example for comparison
        DatabaseConnection manualConnection = new DatabaseConnection();
        try {
            QueryStatement manualStatement = manualConnection.prepareStatement("SELECT * FROM users");
            manualStatement.executeQuery();
        } finally {
            manualConnection.close(); // Must be manually closed
        }
    }
}