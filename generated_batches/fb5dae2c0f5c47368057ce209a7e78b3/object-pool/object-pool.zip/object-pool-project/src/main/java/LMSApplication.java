public class LMSApplication {
    public static void main(String[] args) {
        // Acquire assignments from pool
        Assignment assignment1 = AssignmentPool.getInstance().acquire();
        Assignment assignment2 = AssignmentPool.getInstance().acquire();
        
        System.out.println("Acquired: " + assignment1.getTitle());
        System.out.println("Acquired: " + assignment