import java.util.ArrayDeque;
import java.util.Deque;

public class AssignmentPool {
    private static AssignmentPool instance;
    private Deque<Assignment> pool;
    private int maxSize;
    
    private AssignmentPool(int maxSize) {
        this.maxSize = maxSize;
        this.pool = new ArrayDeque<>(maxSize);
        initializePool();
    }
    
    public static synchronized AssignmentPool getInstance() {
        if (instance == null) {
            instance = new AssignmentPool(10);
        }
        return instance;
    }
    
    private void initializePool() {
        for (int i = 0; i < maxSize; i++) {
            pool.push(new Assignment("Assignment " + i, "Description for assignment " + i));
        }
    }
    
    public synchronized Assignment acquire() {
        if (pool.isEmpty()) {
            return new Assignment("New Assignment", "Dynamic assignment");
        }
        return pool.pop();
    }
    
    public synchronized void release(Assignment assignment) {
        if (pool.size() < maxSize) {
            pool.push(assignment);
        }
    }
}