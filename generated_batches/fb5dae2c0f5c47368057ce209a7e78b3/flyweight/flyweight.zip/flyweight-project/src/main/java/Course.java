package com.lms.model;

public class Course {
    private String courseId;
    private String courseName;
    private CourseType courseType;
    
    public Course(String courseId, String courseName, CourseType courseType) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.courseType = courseType;
    }
    
    // Getters and setters
    public String getCourseId() { return courseId; }
    public void setCourseId(String courseId) { this.courseId = courseId; }
    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }
    public CourseType getCourseType() { return courseType; }
    public void setCourseType(CourseType courseType) { this.courseType = courseType; }
}