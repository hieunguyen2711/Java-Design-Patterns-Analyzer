package com.lms.model;

public class CourseType {
    private String type;
    private int maxStudents;
    
    public CourseType(String type, int maxStudents) {
        this.type = type;
        this.maxStudents = maxStudents;
    }
    
    // Getters and setters
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public int getMaxStudents() { return maxStudents; }
    public void setMaxStudents(int maxStudents) { this.maxStudents = maxStudents; }
}