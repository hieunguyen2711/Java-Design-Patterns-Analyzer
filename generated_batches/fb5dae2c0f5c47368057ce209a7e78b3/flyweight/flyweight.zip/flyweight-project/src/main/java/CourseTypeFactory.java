package com.lms.factory;

import com.lms.model.CourseType;
import java.util.HashMap;
import java.util.Map;

public class CourseTypeFactory {
    private static final Map<String, CourseType> courseTypes = new HashMap<>();
    
    public static CourseType getCourseType(String type, int maxStudents) {
        return courseTypes.computeIfAbsent(type, key -> new CourseType(key, maxStudents));
    }
}