package com.lms.model;

public abstract class Module<T extends Module<T>> {
    private String moduleId;
    
    protected Module(String moduleId) {
        this.moduleId = moduleId;
    }
    
    public String getModuleId() {
        return moduleId;
    }
    
    public T withTitle(String title) {
        // This method would be implemented in concrete classes
        // to demonstrate the CRTP pattern
        return (T) this;
    }
}