package com.lms.model;

public class LessonModule extends Module<LessonModule> {
    private String lessonTitle;
    
    public LessonModule(String lessonTitle, String moduleId) {
        super(moduleId);
        this.lessonTitle = lessonTitle;
    }
    
    public String getLessonTitle() {
        return lessonTitle;
    }
}