package com.lms.model;

public class Course {
    private String title;
    private String courseId;
    
    public Course(String title, String courseId) {
        this.title = title;
        this.courseId = courseId;
    }
    
    public String getTitle() {
        return title;
    }
    
    public String getCourseId() {
        return courseId;
    }
}