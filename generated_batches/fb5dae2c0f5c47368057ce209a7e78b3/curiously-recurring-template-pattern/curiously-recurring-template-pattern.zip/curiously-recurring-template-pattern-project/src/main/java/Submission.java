package com.lms.model;

public class Submission extends Module<Submission> {
    private String studentId;
    
    public Submission(String studentId, String moduleId) {
        super(moduleId);
        this.studentId = studentId;
    }
    
    public String getStudentId() {
        return studentId;
    }
}