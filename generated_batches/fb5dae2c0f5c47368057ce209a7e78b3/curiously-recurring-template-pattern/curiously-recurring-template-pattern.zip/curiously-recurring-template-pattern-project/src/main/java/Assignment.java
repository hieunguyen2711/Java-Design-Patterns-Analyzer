package com.lms.model;

public class Assignment extends Module<Assignment> {
    private String assignmentTitle;
    
    public Assignment(String assignmentTitle, String moduleId) {
        super(moduleId);
        this.assignmentTitle = assignmentTitle;
    }
    
    public String getAssignmentTitle() {
        return assignmentTitle;
    }
}