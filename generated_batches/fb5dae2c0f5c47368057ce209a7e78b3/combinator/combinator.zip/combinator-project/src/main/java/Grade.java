package com.lms.course;

public class Grade {
    private double score;
    private String letterGrade