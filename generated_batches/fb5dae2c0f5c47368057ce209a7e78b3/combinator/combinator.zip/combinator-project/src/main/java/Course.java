package com.lms.course;

import java.util.ArrayList;
import java.util.List;

public class Course {
    private String name;
    private List<Module> modules;
    
    public Course(String name) {
        this.name = name;
        this.modules = new ArrayList<>();
    }
    
    public void addModule(Module module) {
        modules.add(module);
    }
    
    public List<Module> getModules() {
        return modules;
    }
    
    public String getName() {
        return name;
    }
}