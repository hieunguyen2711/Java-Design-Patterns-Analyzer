package com.lms.course;

import java.util.ArrayList;
import java.util.List;

public class Module {
    private String name;
    private List<Assignment> assignments;
    
    public Module(String name) {
        this.name = name;
        this.assignments = new ArrayList<>();
    }
    
    public void addAssignment(Assignment assignment) {
        assignments.add(assignment);
    }
    
    public List<Assignment> getAssignments() {
        return assignments;
    }
    
    public String getName() {
        return name;
    }
}