package com.lms.course;

public class Submission {
    private String studentId;
    private String content;
    private Grade grade;
    
    public Submission(String studentId, String content) {
        this.studentId = studentId;
        this.content = content;
    }
    
    public void setGrade(Grade grade) {
        this.grade = grade;
    }
    
    public Grade getGrade() {
        return grade;
    }
    
    public String getStudentId() {
        return studentId;
    }
    
    public String getContent() {
        return content;
    }
}