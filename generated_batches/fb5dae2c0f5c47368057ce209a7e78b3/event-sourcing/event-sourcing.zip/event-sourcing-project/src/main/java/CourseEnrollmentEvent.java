public class CourseEnrollmentEvent implements Event {
    private final String eventId;
    private final long timestamp;
    private final String userId;
    private final String courseId;
    private final String type = "COURSE_ENROLLMENT";

    public CourseEnrollmentEvent(String eventId, long timestamp, String userId, String courseId) {
        this.eventId = eventId;
        this.timestamp = timestamp;
        this.userId = userId;
        this.courseId = courseId;
    }

    @Override
    public String getEventId() {
        return eventId;
    }

    @Override
    public long getTimestamp() {
        return timestamp;
    }

    @Override
    public String getType() {
        return type;
    }

    public String getUserId() {
        return userId;
    }

    public String getCourseId() {
        return courseId;
    }
}