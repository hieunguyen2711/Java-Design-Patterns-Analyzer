public class AssignmentSubmittedEvent implements Event {
    private final String eventId;
    private final long timestamp;
    private final String userId;
    private final String assignmentId;
    private final String type = "ASSIGNMENT_SUBMITTED";

    public AssignmentSubmittedEvent(String eventId, long timestamp, String userId, String assignmentId) {
        this.eventId = eventId;
        this.timestamp = timestamp;
        this.userId = userId;
        this.assignmentId = assignmentId;
    }

    @Override
    public String getEventId() {
        return eventId;
    }

    @Override
    public long getTimestamp() {
        return timestamp;
    }

    @Override
    public String getType() {
        return type;
    }

    public String getUserId() {
        return userId;
    }

    public String getAssignmentId() {
        return assignmentId;
    }
}