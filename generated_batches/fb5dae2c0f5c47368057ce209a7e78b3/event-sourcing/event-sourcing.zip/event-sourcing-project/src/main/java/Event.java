public interface Event {
    String getEventId();
    long getTimestamp();
    String getType();
}