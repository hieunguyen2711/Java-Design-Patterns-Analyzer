import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class EventStore {
    private final Map<String, List<Event>> eventsByAggregate = new ConcurrentHashMap<>();
    
    public void saveEvent(Event event) {
        eventsByAggregate.computeIfAbsent(event.getEventId(), k -> new ArrayList<>()).add(event);
    }
    
    public List<Event> getEventsForAggregate(String aggregateId) {
        return eventsByAggregate.getOrDefault(aggregateId, Collections.emptyList());
    }
}