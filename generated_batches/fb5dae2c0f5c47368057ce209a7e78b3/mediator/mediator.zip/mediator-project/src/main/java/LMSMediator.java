import java.util.*;

public class LMSMediator implements Mediator {
    private Map<String, Course> courses;
    private Map<String, Student> students;
    private List<Submission> submissions;

    public LMSMediator() {
        this.courses = new HashMap<>();
        this.students = new HashMap<>();
        this.submissions = new ArrayList<>();
    }

    @Override
    public void submitAssignment(Course course, Assignment assignment) {
        System.out.println("Processing submission for: " + assignment.getName());
        Submission submission = new Submission(course, assignment);
        submissions.add(submission);
        
        // Notify all students about the new assignment
        notifyStudents(course, assignment);
    }

    private void notifyStudents(Course course, Assignment assignment) {
        System.out.println("Notifying students about new assignment: " + assignment.getName());
        for (Student student : students.values()) {
            System.out.println("  - Notifying " + student.getName() + " in " + course.getName());
        }
    }

    public void addCourse(C