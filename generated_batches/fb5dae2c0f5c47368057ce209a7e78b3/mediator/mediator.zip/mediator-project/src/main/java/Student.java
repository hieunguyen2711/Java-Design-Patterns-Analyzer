public class Student {
    private String name;
    private Mediator mediator;

    public Student(String name, Mediator mediator) {
        this.name = name;
        this.mediator = mediator;
    }

    public void submitAssignment(Course course, Assignment assignment) {
        System.out.println("Student " + name + " submitting to course: " + course.getName());
        mediator.submitAssignment(course, assignment);
    }

    public String getName() {
        return name;
    }
}