public class Assignment {
    private String name;
    private int maxPoints;

    public Assignment(String name, int maxPoints) {
        this.name = name;
        this.maxPoints = maxPoints;
    }

    public String getName() {
        return name;
    }

    public int getMaxPoints() {
        return maxPoints;
    }
}