public class Course {
    private String name;
    private Mediator mediator;

    public Course(String name, Mediator mediator) {
        this.name = name;
        this.mediator = mediator;
    }

    public void submitAssignment(Assignment assignment) {
        System.out.println("Submitting assignment: " + assignment.getName());
        mediator.submitAssignment(this, assignment);
    }

    public String getName() {
        return name;
    }
}