package com.lms;

import com.lms.model.Course;
import com.lms.service.CourseManager;

public class Main {
    public static void main(String[] args) {
        CourseManager manager = new CourseManager();
        
        Course course1 = new Course("Java Fundamentals");
        Course course2 = new Course("Advanced Java");
        
        manager.addCourse(course1);
        manager.addCourse(course2);
        
        System.out.println("Initial dirty flags:");
        System.out.println("Course 1 is dirty: " + course1.isDirty());
        System.out.println("Course 2 is dirty: " + course2.isDirty());
        
        manager.updateCourseTitle(0, "Java Fundamentals - Updated");
        
        System.out.println("\nAfter updating first course:");