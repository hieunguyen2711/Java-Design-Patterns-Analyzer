package com.lms.service;

import com.lms.model.Course;
import java.util.ArrayList;
import java.util.List;

public class CourseManager {
    private List<Course> courses = new ArrayList<>();
    
    public void addCourse(Course course) {
        courses.add(course);
    }
    
    public void updateCourseTitle(int index, String newTitle) {
        if (index >= 0 && index < courses.size()) {
            courses.get(index).setTitle(newTitle);
        }
    }
    
    public List<Course> getDirtyCourses() {
        List<Course> dirtyCourses = new ArrayList<>();
        for (Course course : courses) {
            if (course.isDirty()) {
                dirtyCourses.add(course);
            }
        }
        return dirtyCourses;
    }
    
    public void saveAllDirtyCourses() {
        for (Course course : getDirtyCourses()) {
            System.out.println("Saving course: " + course.getTitle());
            course.clearDirtyFlag();
        }
    }
}