package com.lms.model;

public class Course {
    private String title;
    private boolean isDirty = false;
    
    public Course(String title) {
        this.title = title;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
        setDirty(true);
    }
    
    public boolean isDirty() {
        return isDirty;
    }
    
    public void setDirty(boolean dirty) {
        isDirty = dirty;
    }
    
    public void clearDirtyFlag() {
        isDirty = false;
    }
}