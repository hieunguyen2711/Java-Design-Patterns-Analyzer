package com.lms.actor;

public interface Actor {
    void receive(Object message);
}