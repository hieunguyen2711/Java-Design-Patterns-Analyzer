package com.lms.actor;

public interface Message {
    Object getPayload();
}