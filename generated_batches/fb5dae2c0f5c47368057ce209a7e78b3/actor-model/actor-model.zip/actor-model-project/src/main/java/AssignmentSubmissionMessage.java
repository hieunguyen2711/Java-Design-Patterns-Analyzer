package com.lms.actor;

public class AssignmentSubmissionMessage implements Message {
    private final String studentId;
    private final String assignmentId;
    private final String submissionContent;

    public AssignmentSubmissionMessage(String studentId, String assignmentId, String submissionContent) {
        this.studentId = studentId;
        this.assignmentId = assignmentId;
        this.submissionContent = submissionContent;
    }

    @Override
    public Object getPayload() {
        return this;
    }

    public String getStudentId() {
        return studentId;
    }

    public String getAssignmentId() {
        return assignmentId;
    }

    public String getSubmissionContent() {
        return submissionContent;
    }
}