package com.lms.actor;

public class GradeAssignmentMessage implements Message {
    private final String studentId;
    private final String assignmentId;
    private final int grade;

    public GradeAssignmentMessage(String studentId, String assignmentId, int grade) {
        this.studentId = studentId;
        this.assignmentId = assignmentId;
        this.grade = grade;
    }

    @Override
    public Object getPayload() {
        return this;
    }

    public String getStudentId() {
        return studentId;
    }

    public String getAssignmentId() {
        return assignmentId;
    }

    public int getGrade() {
        return grade;
    }
}