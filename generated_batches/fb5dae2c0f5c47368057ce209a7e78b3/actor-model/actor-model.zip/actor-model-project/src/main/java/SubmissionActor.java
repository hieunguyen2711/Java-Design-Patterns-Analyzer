package com.lms.actor;

import java.util.HashMap;
import java.util.Map;

public class SubmissionActor implements Actor {
    private final Map<String, String> submissions = new HashMap<>();
    
    @Override
    public void receive(Object message) {
        if (message instanceof AssignmentSubmissionMessage) {
            AssignmentSubmissionMessage msg = (AssignmentSubmissionMessage) message;
            submissions.put(msg.getStudentId() + "_" + msg.getAssignmentId(), 
                           msg.getSubmissionContent());
            System.out.println("Submission recorded for student: " + msg.getStudentId() + 
                             ", assignment: " + msg.getAssignmentId());
        }
    }

    public String getSubmission(String studentId, String assignmentId