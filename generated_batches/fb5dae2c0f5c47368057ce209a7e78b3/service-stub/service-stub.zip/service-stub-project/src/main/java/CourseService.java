package com.lms.service;

public interface CourseService {
    void enrollStudent(String studentId, String courseId);
    void dropCourse(String studentId, String courseId);
    boolean isEnrolled(String studentId, String courseId);
}