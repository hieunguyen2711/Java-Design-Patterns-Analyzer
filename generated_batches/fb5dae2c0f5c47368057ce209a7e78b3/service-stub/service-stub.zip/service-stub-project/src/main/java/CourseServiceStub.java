package com.lms.service;

public class CourseServiceStub implements CourseService {
    
    @Override
    public void enrollStudent(String studentId, String courseId) {
        // Stub implementation - does nothing
    }
    
    @Override
    public void dropCourse(String studentId, String courseId) {
        // Stub implementation - does nothing
    }
    
    @Override
    public boolean isEnrolled(String studentId, String courseId) {
        // Stub implementation - always returns false
        return false;
    }
}