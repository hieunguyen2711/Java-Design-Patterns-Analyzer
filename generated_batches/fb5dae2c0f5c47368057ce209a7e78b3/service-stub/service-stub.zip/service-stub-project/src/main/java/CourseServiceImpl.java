package com.lms.service;

import java.util.HashMap;
import java.util.Map;

public class CourseServiceImpl implements CourseService {
    private final Map<String, Map<String, Boolean>> enrollmentMap = new HashMap<>();
    
    @Override
    public void enrollStudent(String studentId, String courseId) {
        enrollmentMap.computeIfAbsent(studentId, k -> new HashMap<>()).put(courseId, true);
    }
    
    @Override
    public void dropCourse(String studentId, String courseId) {
        Map<String, Boolean> courses = enrollmentMap.get(studentId);
        if (courses != null) {
            courses.remove(courseId);
        }
    }
    
    @Override
    public boolean isEnrolled(String studentId, String courseId) {
        Map<String, Boolean> courses = enrollmentMap.get(studentId);
        return courses != null && courses.containsKey(courseId);
    }
}