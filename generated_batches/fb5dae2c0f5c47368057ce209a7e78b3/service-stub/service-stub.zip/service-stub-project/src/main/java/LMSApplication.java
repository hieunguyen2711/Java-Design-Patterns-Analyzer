package com.lms;

import com.lms.service.CourseService;
import com.lms.service.CourseServiceImpl;
import com.lms.service.CourseServiceStub;

public class LMSApplication {
    
    public static void main(String[] args) {
        // Production service
        CourseService courseService = new CourseServiceImpl();
        courseService.enrollStudent("student1", "course101");
        
        // Stub for testing
        CourseService stubService = new CourseServiceStub();
        boolean enrolled = stubService.isEnrolled("testStudent", "testCourse");
        
        System.out.println("Enrollment status: " + enrolled);
    }
}