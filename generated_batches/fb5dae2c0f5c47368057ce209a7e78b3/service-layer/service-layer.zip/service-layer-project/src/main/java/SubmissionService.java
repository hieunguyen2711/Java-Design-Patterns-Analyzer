package com.lms.service;

import com.lms.model.Submission;
import com.lms.repository.SubmissionRepository;

public class SubmissionService {
    private final SubmissionRepository submissionRepository;
    
    public SubmissionService(SubmissionRepository submissionRepository) {
        this.submissionRepository = submissionRepository;
    }
    
    public Submission getSubmissionById(Long id) {
        return submissionRepository.findById(id);
    }
    
    public void saveSubmission(Submission submission) {
        submissionRepository.save(submission);
    }
}