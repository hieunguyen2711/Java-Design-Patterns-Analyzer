package com.lms.service;

import com.lms.model.Assignment;
import com.lms.repository.AssignmentRepository;

public class AssignmentService {
    private final AssignmentRepository assignmentRepository;
    
    public AssignmentService(AssignmentRepository assignmentRepository) {
        this.assignmentRepository = assignmentRepository;
    }
    
    public Assignment getAssignmentById(Long id) {
        return assignmentRepository.findById(id);
    }
    
    public void saveAssignment(Assignment assignment) {
        assignmentRepository.save(assignment);
    }
}