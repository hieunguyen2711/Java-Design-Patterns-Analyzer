package com.lms.service;

import com.lms.model.LessonModule;
import com.lms.repository.LessonModuleRepository;

public class LessonModuleService {
    private final LessonModuleRepository lessonModuleRepository;
    
    public LessonModuleService(LessonModuleRepository lessonModuleRepository) {
        this.lessonModuleRepository = lessonModuleRepository;
    }
    
    public LessonModule getLessonModuleById(Long id) {
        return lessonModuleRepository.findById(id);
    }
    
    public void saveLessonModule(LessonModule lessonModule) {
        lessonModuleRepository.save(lessonModule);
    }
}