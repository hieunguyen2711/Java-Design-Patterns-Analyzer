package com.lms.service;

import com.lms.model.Course;
import com.lms.repository.CourseRepository;

public class CourseService {
    private final CourseRepository courseRepository;
    
    public CourseService(CourseRepository courseRepository) {
        this.courseRepository = courseRepository;
    }
    
    public Course getCourseById(Long id) {
        return courseRepository.findById(id);
    }
    
    public void saveCourse(Course course) {
        courseRepository.save(course);
    }
}