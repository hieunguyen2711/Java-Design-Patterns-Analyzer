package com.lms.service;

import com.lms.model.Grade;
import com.lms.repository.GradeRepository;

public class GradingService {
    private final GradeRepository gradeRepository;