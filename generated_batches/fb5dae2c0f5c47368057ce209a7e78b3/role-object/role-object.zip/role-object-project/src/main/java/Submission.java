package com.lms.model;

public class Submission {
    private String content;
    private Grade grade;
    private RoleObject roleObject;
    
    public Submission(String content, RoleObject roleObject) {
        this.content = content;
        this.roleObject = roleObject;
    }
    
    public void setGrade(Grade grade) {