package com.lms.model;

import java.util.List;
import java.util.ArrayList;

public class LessonModule {
    private String title;
    private List<Assignment> assignments;
    private RoleObject roleObject;
    
    public LessonModule(String title, RoleObject roleObject) {
        this.title = title;
        this.roleObject = roleObject;
        this.assignments = new ArrayList<>();
    }
    
    public void addAssignment(Assignment assignment) {
        assignments.add(assignment);
    }
    
    public List<Assignment> getAssignments() {
        return assignments;
    }
    
    public String getTitle() {
        return title;
    }
    
    public RoleObject getRoleObject() {
        return roleObject;
    }
}