package com.lms.model;

import java.util.List;
import java.util.ArrayList;

public class Assignment {
    private String title;
    private List<Submission> submissions;
    private RoleObject roleObject;
    
    public Assignment(String title, RoleObject roleObject) {
        this.title = title;
        this.roleObject = roleObject;
        this.submissions = new ArrayList<>();
    }
    
    public void addSubmission(Submission submission) {
        submissions.add(submission);
    }
    
    public List<Submission> getSubmissions() {
        return submissions;
    }
    
    public String getTitle() {
        return title;
    }
    
    public RoleObject getRoleObject() {
        return roleObject;
    }
}