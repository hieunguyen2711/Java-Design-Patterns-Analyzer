package com.lms.model;

import java.util.List;
import java.util.ArrayList;

public class Course {
    private String title;
    private List<LessonModule> modules;
    
    public Course(String title) {
        this.title = title;
        this.modules = new ArrayList<>();
    }
    
    public void addModule(LessonModule module) {
        modules.add(module);
    }
    
    public List<LessonModule> getModules() {
        return modules;
    }
    
    public String getTitle() {
        return title;
    }
}