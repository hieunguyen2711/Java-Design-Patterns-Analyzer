public class Main {
    public static void main(String[] args) {
        CourseManager manager1 = new CourseManager();
        CourseManager manager2 = new CourseManager();
        
        System.out.println("Are managers the same instance? " + (manager1 == manager2));
        
        manager1.enrollStudent("S001", "C001");
        manager2.addCourse("C002", "Advanced Java");
    }
}