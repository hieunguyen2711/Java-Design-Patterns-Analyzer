public class CourseManager {
    private DatabaseConnection dbConnection;
    
    public CourseManager() {
        this.dbConnection = DatabaseConnection.getInstance();
        this.dbConnection.connect();
    }
    
    public void enrollStudent(String studentId, String courseId) {
        System.out.println("Enrolling student " + studentId + " in course " + courseId);
    }
    
    public void addCourse(String courseId, String courseName) {
        System.out.println("Adding course: " + courseName + " with ID: " + courseId);
    }
}