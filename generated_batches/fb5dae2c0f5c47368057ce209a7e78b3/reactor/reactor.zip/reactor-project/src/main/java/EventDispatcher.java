import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class EventDispatcher {
    private final Map<String, EventHandler> handlers = new HashMap<>();
    private final ExecutorService executor = Executors.newFixedThreadPool(10);

    public void registerHandler(String eventType, EventHandler handler) {
        handlers.put(eventType, handler);
    }

    public void dispatch(Event event) {
        EventHandler handler = handlers.get(event.getType());
        if (handler != null) {
            executor.submit(() -> handler.handle(event));
        }
    }

    public void shutdown() {
        executor.shutdown();
    }
}