public class SubmissionEvent extends Event {
    private final String studentId;
    private final String assignmentId;

    public SubmissionEvent(String studentId, String assignmentId) {
        super("SUBMISSION", null);
        this.studentId = studentId;
        this.assignmentId = assignmentId;
    }

    public String getStudentId() {
        return studentId;
    }

    public String getAssignmentId() {
        return assignmentId;
    }
}