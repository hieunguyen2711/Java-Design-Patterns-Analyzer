public class LMSApplication {
    private final EventDispatcher dispatcher = new EventDispatcher();

    public void start() {