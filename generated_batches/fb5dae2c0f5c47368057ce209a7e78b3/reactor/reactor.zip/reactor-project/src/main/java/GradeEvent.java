public class GradeEvent extends Event {
    private final String studentId;
    private final String assignmentId;
    private final double grade;

    public GradeEvent(String studentId, String assignmentId, double grade) {
        super("GRADE", null);
        this.studentId = studentId;
        this.assignmentId = assignmentId;
        this.grade = grade;
    }

    public String getStudentId() {
        return studentId;
    }

    public String getAssignmentId() {
        return assignmentId;
    }

    public double getGrade() {
        return grade;
    }
}