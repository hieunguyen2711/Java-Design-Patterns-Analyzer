public class LMSApplication {
    public static void main(String[] args) {
        // Demonstrating multiton pattern with CourseManager instances
        CourseManager math = CourseManager.getInstance("Mathematics");
        CourseManager physics = CourseManager.getInstance("Physics");
        CourseManager chemistry = CourseManager.getInstance("Chemistry");
        
        // Accessing same instance through different references
        CourseManager math2 = CourseManager.getInstance("Mathematics");
        
        math.addStudent();
        math.addStudent();
        physics.addStudent();
        chemistry.addStudent();
        
        System.out.println("Math students: " + math.getStudentCount());
        System.out.println("Physics students: " + physics.getStudentCount());
        System.out.println("Chemistry students: " + chemistry.getStudentCount());
        
        // Verify that same instances are returned
        System.out.println("Are math and math2 the same instance? " + (math == math2));
    }
}