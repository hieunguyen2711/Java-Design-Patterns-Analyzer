package com.lms.model;

import java.util.List;
import java.util.ArrayList;

public class Assignment {
    private String assignmentId;
    private String title;
    private List<Submission> submissions;
    
    public Assignment(String assignmentId, String title) {
        this.assignment