package com.lms.model;

import java.util.List;
import java.util.ArrayList;

public class Lesson {
    private String lessonId;
    private String title;
    private List<Assignment> assignments;
    
    public Lesson(String lessonId, String title) {
        this.lessonId = lessonId;
        this.title = title;
        this.assignments = new ArrayList<>();
    }
    
    public void addAssignment(Assignment assignment) {
        assignments.add(assignment);
    }
    
    public List<Assignment> getAssignments() {
        return assignments;
    }
    
    public String getLessonId() {
        return lessonId;
    }
    
    public String getTitle() {
        return title;
    }
}