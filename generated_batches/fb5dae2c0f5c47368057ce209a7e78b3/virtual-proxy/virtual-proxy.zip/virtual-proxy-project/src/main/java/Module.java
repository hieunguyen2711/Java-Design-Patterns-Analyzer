package com.lms.model;

import java.util.List;
import java.util.ArrayList;

public class Module {
    private String moduleId;
    private String title;
    private List<Lesson> lessons;
    
    public Module(String moduleId, String title) {
        this.moduleId = moduleId;
        this.title = title;
        this.lessons = new ArrayList<>();
    }
    
    public void addLesson(Lesson lesson) {
        lessons.add(lesson);
    }
    
    public List<Lesson> getLessons() {
        return lessons;
    }
    
    public String getModuleId() {
        return moduleId;
    }
    
    public String getTitle() {
        return title;
    }
}