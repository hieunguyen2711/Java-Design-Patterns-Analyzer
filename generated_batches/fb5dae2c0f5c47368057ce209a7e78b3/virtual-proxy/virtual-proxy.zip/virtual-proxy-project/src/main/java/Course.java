package com.lms.model;

import java.util.List;
import java.util.ArrayList;

public class Course {
    private String courseId;
    private String title;
    private List<Module> modules;
    
    public Course(String courseId, String title) {
        this.courseId = courseId;
        this.title = title;
        this.modules = new ArrayList<>();
    }
    
    public void addModule(Module module) {
        modules.add(module);
    }
    
    public List<Module> getModules() {
        return modules;
    }
    
    public String getCourseId() {
        return courseId;
    }
    
    public String getTitle() {
        return title;
    }
}