package com.lms.model;

public enum ContentType {
    VIDEO, DOCUMENT, QUIZ, ASSIGNMENT
}