package com.lms.model;

import java.util.List;
import java.util.ArrayList;

public class LessonModule {
    private String title;
    private List<ContentItem> contentItems;
    
    public LessonModule(String title) {
        this.title = title;
        this.contentItems = new ArrayList<>();
    }
    
    public void addContent(ContentItem item) {
        contentItems.add(item);
    }
    
    // Getters and setters
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public List<ContentItem> getContentItems() { return contentItems; }
}