package com.lms.model;

public class ContentItem {
    private String title;
    private ContentType type;
    
    public ContentItem(String title, ContentType type) {
        this.title = title;
        this.type = type;
    }
    
    // Getters and setters
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public ContentType getType() { return type; }
    public void setType(ContentType type) { this.type = type; }
}