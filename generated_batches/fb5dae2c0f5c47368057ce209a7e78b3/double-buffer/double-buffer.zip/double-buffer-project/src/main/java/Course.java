package com.lms.model;

public class Course {
    private String name;
    private String code;
    
    public Course(String name, String code) {
        this.name = name;
        this.code = code;
    }
    
    // Getters and setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
}