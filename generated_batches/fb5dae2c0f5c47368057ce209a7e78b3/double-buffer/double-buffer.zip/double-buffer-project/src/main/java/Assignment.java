package com.lms.model;

import java.time.LocalDateTime;
import java.util.List;
import java.util.ArrayList;

public class Assignment {
    private String title;
    private String description;
    private LocalDateTime dueDate;
    private List<Submission> submissions;
    
    public Assignment(String title, String description, LocalDateTime dueDate) {
        this.title = title;
        this.description = description;
        this.dueDate = dueDate;
        this.submissions = new ArrayList<>();
    }