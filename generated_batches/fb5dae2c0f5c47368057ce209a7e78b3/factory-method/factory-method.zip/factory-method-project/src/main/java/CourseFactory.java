public abstract class CourseFactory {
    public abstract Course createCourse(String title, String description);
    
    public Course getCourse(String type, String title, String description) {
        return createCourse(title, description);
    }
}