public class LMSApplication {
    public static void main(String[] args) {
        // Using factory method to create different types of courses
        CourseFactory programmingFactory = new ProgrammingCourseFactory();
        CourseFactory artFactory