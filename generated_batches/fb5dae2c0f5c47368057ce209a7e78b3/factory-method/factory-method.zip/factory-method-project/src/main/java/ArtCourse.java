public class ArtCourse extends Course {
    
    public ArtCourse(String title, String description) {
        super(title, description);
    }
    
    @Override
    public void enrollStudent() {
        System.out.println("Enrolling student in " + title + " art course");
    }
    
    @Override
    public void startCourse() {
        System.out.println("Starting " + title + " art course with creative projects");
    }
}