public class ProgrammingCourseFactory extends CourseFactory {
    
    @Override
    public Course createCourse(String title, String description) {
        return new ProgrammingCourse(title, description);
    }
}