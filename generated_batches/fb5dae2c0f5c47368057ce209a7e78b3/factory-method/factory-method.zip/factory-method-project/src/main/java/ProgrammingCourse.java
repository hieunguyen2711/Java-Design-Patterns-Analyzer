public class ProgrammingCourse extends Course {
    
    public ProgrammingCourse(String title, String description) {
        super(title, description);
    }
    
    @Override
    public void enrollStudent() {
        System.out.println("Enrolling student in " + title + " programming course");
    }
    
    @Override
    public void startCourse() {
        System.out.println("Starting " + title + " programming course with coding assignments");
    }
}