public class ArtCourseFactory extends CourseFactory {
    
    @Override
    public Course createCourse(String title, String description) {
        return new ArtCourse(title, description);
    }
}