import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Lesson {
    private String lessonName;
    private List<Assignment> assignments;
    
    public Lesson(String lessonName) {
        this.lessonName = lessonName;
        this.assignments = new ArrayList<>();
    }
    
    public void addAssignment(Assignment assignment) {
        assignments.add(assignment);
    }
    
    public Iterator<Assignment> getAssignmentsIterator() {
        return assignments.iterator();
    }
    
    public String getLessonName() {
        return lessonName;
    }
}