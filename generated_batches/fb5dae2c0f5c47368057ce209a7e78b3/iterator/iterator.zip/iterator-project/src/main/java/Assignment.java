import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Assignment {
    private String assignmentName;
    private List<Submission> submissions;
    
    public Assignment(String assignmentName) {
        this.assignmentName = assignmentName;
        this.submissions = new ArrayList<>();
    }
    
    public void addSubmission(Submission submission) {
        submissions.add(submission);
    }
    
    public Iterator<Submission> getSubmissionsIterator() {
        return submissions.iterator();
    }
    
    public String getAssignmentName() {
        return assignmentName;
    }
}