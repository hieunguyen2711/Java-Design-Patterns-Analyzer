import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Course {
    private String courseName;
    private List<Module> modules;
    
    public Course(String courseName) {
        this.courseName = courseName;
        this.modules = new ArrayList<>();
    }
    
    public void addModule(Module module) {
        modules.add(module);
    }
    
    public Iterator<Module> getModulesIterator() {
        return modules.iterator();
    }
    
    public String getCourseName() {
        return courseName;
    }
}