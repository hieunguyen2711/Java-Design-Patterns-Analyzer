import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Module {
    private String moduleName;
    private List<Lesson> lessons;
    
    public Module(String moduleName) {
        this.moduleName = moduleName;
        this.lessons = new ArrayList<>();
    }
    
    public void addLesson(Lesson lesson) {
        lessons.add(lesson);
    }
    
    public Iterator<Lesson> getLessonsIterator() {
        return lessons.iterator();
    }
    
    public String getModuleName() {
        return moduleName;
    }
}