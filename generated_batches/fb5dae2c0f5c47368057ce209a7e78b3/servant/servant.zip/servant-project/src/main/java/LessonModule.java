package com.lms.model;

import java.util.ArrayList;
import java.util.List;

public class LessonModule {
    private String moduleId;
    private String moduleName;
    private List<Assignment> assignments;
    
    public LessonModule(String moduleId, String moduleName) {
        this.moduleId = moduleId;
        this.moduleName = moduleName;
        this.assignments = new ArrayList<>();
    }
    
    public void addAssignment(Assignment assignment) {
        assignments.add(assignment);
    }
    
    public List<Assignment> getAssignments() {
        return assignments;
    }
    
    public String getModuleId() {
        return moduleId;
    }
    
    public String getModuleName() {
        return moduleName;
    }
}