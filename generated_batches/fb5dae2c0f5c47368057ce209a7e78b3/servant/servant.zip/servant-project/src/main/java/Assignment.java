package com.lms.model;

import java.util.ArrayList;
import java.util.List;

public class Assignment {
    private String assignmentId;
    private String title;
    private List<Submission> submissions;
    
    public Assignment(String assignmentId, String title) {
        this.assignmentId = assignmentId;
        this.title = title;
        this.submissions = new ArrayList<>();
    }
    
    public void addSubmission(Submission submission) {
        submissions.add(submission);
    }
    
    public List<Submission> getSubmissions() {
        return submissions;
    }
    
    public String getAssignmentId() {
        return assignmentId;
    }
    
    public String getTitle() {
        return title;
    }
}