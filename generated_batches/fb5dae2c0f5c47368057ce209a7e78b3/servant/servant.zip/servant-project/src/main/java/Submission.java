package com.lms.model;

public class Submission {
    private String submissionId;
    private String studentId;
    private String content;
    private