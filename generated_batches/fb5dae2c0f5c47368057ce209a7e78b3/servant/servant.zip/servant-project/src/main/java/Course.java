package com.lms.model;

import java.util.ArrayList;
import java.util.List;

public class Course {
    private String courseId;
    private String courseName;
    private List<LessonModule> lessonModules;
    
    public Course(String courseId, String courseName) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.lessonModules = new ArrayList<>();
    }
    
    public void addLessonModule(LessonModule lessonModule) {
        lessonModules.add(lessonModule);
    }
    
    public List<LessonModule> getLessonModules() {
        return lessonModules;
    }
    
    public String getCourseId() {
        return courseId;
    }
    
    public String getCourseName() {
        return courseName;
    }
}