public class NullGrade extends Grade {
    @Override
    public boolean isNull() {
        return true;
    }
    
    @Override
    public String getValue() {
        return "Not graded yet";
    }
    
    @Override
    public double getScore() {
        return 0.0;
    }
}