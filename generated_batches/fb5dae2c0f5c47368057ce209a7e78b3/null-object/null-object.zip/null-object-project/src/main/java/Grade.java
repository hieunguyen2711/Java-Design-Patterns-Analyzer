public abstract class Grade {
    public abstract boolean isNull();
    public abstract String getValue();
    public abstract double getScore();
}