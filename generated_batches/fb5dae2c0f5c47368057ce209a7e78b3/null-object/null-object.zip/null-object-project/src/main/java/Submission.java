public class Submission {
    private Assignment assignment;
    private String content;
    private Grade grade;
    
    public Submission(Assignment assignment, String content) {
        this.assignment = assignment;
        this.content = content;
        this.grade = new NullGrade(); // Default to null object
    }
    
    public Assignment getAssignment() {
        return assignment;
    }
    
    public String getContent() {
        return content;
    }
    
    public Grade getGrade() {
        return grade;
    }
    
    public void setGrade(Grade grade) {
        this.grade = grade;
    }
}