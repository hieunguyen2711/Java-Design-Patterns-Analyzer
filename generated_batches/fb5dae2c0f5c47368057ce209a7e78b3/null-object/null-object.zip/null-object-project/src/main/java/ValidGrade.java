public class ValidGrade extends Grade {
    private String value;
    private double score;
    
    public ValidGrade(String value, double score) {
        this.value = value;
        this.score = score;
    }
    
    @Override
    public boolean isNull() {
        return false;
    }
    
    @Override
    public String getValue() {
        return value;
    }
    
    @Override
    public double getScore() {
        return score;
    }
}