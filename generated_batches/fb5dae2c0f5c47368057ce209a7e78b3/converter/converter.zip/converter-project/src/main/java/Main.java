package com.lms;

import com.lms.model.Course;
import com.lms.dto.CourseDTO;
import com.lms.converter.CourseConverter;

public class Main {
    public static void main(String[] args) {
        // Create a course model object
        Course course = new Course("Java Programming", "CS101");
        
        // Convert to DTO using converter
        CourseDTO dto = CourseConverter.toDTO(course);
        
        // Convert back to model
        Course convertedCourse = CourseConverter.fromDTO(dto);
        
        System.out.println("Original: " + course.getTitle() + " - " + course.getCode());
        System.out.println("Converted: " + convertedCourse.getTitle() + " - " + convertedCourse.getCode());
    }
}