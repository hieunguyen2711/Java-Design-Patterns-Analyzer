package com.lms.model;

public class Course {
    private String title;
    private String code;
    
    public Course(String title, String code) {
        this.title = title;
        this.code = code;
    }
    
    // Getters and setters
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
}