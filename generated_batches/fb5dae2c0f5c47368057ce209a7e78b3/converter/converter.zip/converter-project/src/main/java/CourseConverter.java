package com.lms.converter;

import com.lms.model.Course;
import com.lms.dto.CourseDTO;

public class CourseConverter {
    
    public static CourseDTO toDTO(Course course) {
        if (course == null) return null;
        return new CourseDTO(course.getTitle(), course.getCode());
    }
    
    public static Course fromDTO(CourseDTO dto) {
        if (dto == null) return null;
        return new Course(dto.getTitle(), dto.getCode());
    }
}