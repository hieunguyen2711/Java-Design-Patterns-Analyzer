package com.lms.service;

import com.lms.dto.Course;
import com.lms.dto.CourseDTO;

public class CourseService {
    
    public CourseDTO getCourseDTO(int courseId) {
        // Simulate fetching from database
        Course course = new Course(courseId, "Java Programming", "Learn Java fundamentals");
        
        // Transform to DTO for transfer
        return new CourseDTO(
            course.getId(),
            course.getName(),
            course.getDescription()
        );
    }
    
    public void updateCourseFromDTO(CourseDTO dto) {
        // Simulate updating database with data from DTO
        System.out.println("Updating course: " + dto.getName());
    }
}