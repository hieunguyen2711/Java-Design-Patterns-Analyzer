public class LMSApplication {
    
    public static void main(String[] args) {
        // Using the factory kit to create different types of learning resources
        LearningResource course = Resource