public class CourseFactory {
    
    public static LearningResource createCourse(String type, String title, String description) {
        switch (type.toLowerCase()) {
            case "course":
                return new Course(title, description);
            case "lesson":
                return new Lesson(title, description);
            case "assignment":
                return new Assignment(title, description);
            default:
                throw new IllegalArgumentException("Unknown resource type: " + type);
        }
    }
}