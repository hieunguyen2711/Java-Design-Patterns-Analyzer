public interface LearningResource {
    String getType();
    String getTitle();
}