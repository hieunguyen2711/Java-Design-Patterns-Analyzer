public class ResourceFactoryKit {
    
    public static LearningResource createResource(String type, String title, String content) {
        switch (type.toLowerCase()) {
            case "course":
                return new Course(title, content);
            case "lesson":
                return new Lesson(title, content);
            case "assignment":
                return new Assignment(title, content);
            default:
                throw new IllegalArgumentException("Unknown resource type: " + type);
        }
    }
}