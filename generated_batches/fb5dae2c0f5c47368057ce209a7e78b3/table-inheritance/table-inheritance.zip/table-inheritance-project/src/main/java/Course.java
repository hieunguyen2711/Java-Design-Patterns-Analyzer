package com.lms.model;

public abstract class Course {
    protected String title;
    protected String description;
    protected int credits;
    
    public Course(String title, String description, int credits) {
        this.title = title;
        this.description = description;
        this.credits = credits;
    }
    
    public abstract void displayCourseInfo();
    
    public String getTitle() {
        return title;
    }
    
    public String getDescription() {
        return description;
    }
    
    public int getCredits() {
        return credits;
    }
}