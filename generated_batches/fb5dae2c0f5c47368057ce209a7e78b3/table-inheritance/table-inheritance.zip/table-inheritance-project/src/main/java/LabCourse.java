package com.lms.model;

public class LabCourse extends Course {
    private String labLocation;
    private int maxStudents;
    
    public LabCourse(String title, String description, int credits, String labLocation, int maxStudents) {
        super(title, description, credits);
        this.labLocation = labLocation;
        this.maxStudents = maxStudents;
    }
    
    @Override
    public void displayCourseInfo() {
        System.out.println("Lab Course: " + title);
        System.out.println("Lab Location: " + labLocation);
        System.out.println("Max Students: " + maxStudents);
        System.out.println("Credits: " + credits);
    }
    
    public String getLabLocation() {
        return labLocation;
    }
    
    public int getMaxStudents() {
        return maxStudents;
    }
}