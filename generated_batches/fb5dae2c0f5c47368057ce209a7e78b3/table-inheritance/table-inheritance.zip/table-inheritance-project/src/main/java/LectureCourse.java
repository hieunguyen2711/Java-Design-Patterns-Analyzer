package com.lms.model;

public class LectureCourse extends Course {
    private String instructor;
    private String schedule;
    
    public LectureCourse(String title, String description, int credits, String instructor, String schedule) {
        super(title, description, credits);
        this.instructor = instructor;
        this.schedule = schedule;
    }
    
    @Override
    public void displayCourseInfo() {
        System.out.println("Lecture Course: " + title);
        System.out.println("Instructor: " + instructor);
        System.out.println("Schedule: " + schedule);
        System.out.println("Credits: " + credits);
    }
    
    public String getInstructor() {
        return instructor;
    }
    
    public String getSchedule() {
        return schedule;
    }
}