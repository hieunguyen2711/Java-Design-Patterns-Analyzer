public class EnrollmentService {
    public static void enrollStudent(String studentName, Course course) {
        // Transaction script logic for enrolling a student
        System.out.println("Enrolling " + studentName + " in " + course.getName());
        course.addEnrollment(studentName);
    }
}