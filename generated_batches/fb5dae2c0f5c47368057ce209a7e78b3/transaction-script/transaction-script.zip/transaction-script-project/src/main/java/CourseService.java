public class CourseService {
    public static void addLesson(Course course, LessonModule module) {
        // Transaction script logic for adding a lesson
        System.out.println("Adding lesson " + module.getTitle() + " to " + course.getName());
        course.addLesson(module);
    }
    
    public static void createAssignment(Course course, Assignment assignment) {
        // Transaction script logic for creating an assignment
        System.out.println("Creating assignment " + assignment.getTitle() + " in " + course.getName());
        course.addAssignment(assignment);
    }
}