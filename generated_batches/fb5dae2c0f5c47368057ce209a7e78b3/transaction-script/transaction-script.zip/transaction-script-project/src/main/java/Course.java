import java.util.ArrayList;
import java.util.List;

public class Course {
    private String name;
    private String code;
    private List<String> enrollments;
    private List<LessonModule> lessons;
    private List<Assignment> assignments;
    
    public Course(String name, String code) {
        this.name = name;
        this.code = code;
        this.enrollments = new ArrayList<>();
        this.lessons = new ArrayList<>();
        this.assignments = new ArrayList<>();
    }
    
    public void addEnrollment(String studentName) {
        enrollments.add(studentName);
    }
    
    public void addLesson(LessonModule module) {
        lessons.add(module);
    }
    
    public void addAssignment(Assignment assignment) {
        assignments.add(assignment);
    }
    
    public String getName() {
        return name;
    }
}