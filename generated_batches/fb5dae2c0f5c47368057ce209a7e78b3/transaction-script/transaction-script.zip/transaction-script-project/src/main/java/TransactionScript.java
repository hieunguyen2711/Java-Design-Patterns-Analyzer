public class TransactionScript {
    public static void main(String[] args) {
        Course course = new Course("Java Programming", "CS101");
        LessonModule module = new LessonModule("Introduction to Java", 1);
        Assignment assignment = new Assignment("Hello World Program", 1);
        
        // Simulate transaction: enroll student, add lesson, create assignment
        EnrollmentService.enrollStudent("John Doe", course);
        CourseService.addLesson(course, module);
        CourseService.createAssignment(course, assignment);
        
        System.out.println("Transaction completed successfully");
    }
}