public class CoursePageController implements PageController {
    @Override
    public String handleRequest(String request) {
        if (request.equals("/courses")) {
            return "Displaying course list page";
        }
        return "Course page not found";
    }
}