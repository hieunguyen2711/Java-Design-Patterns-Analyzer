public interface PageController {
    String handleRequest(String request);
}