public class SubmissionPageController implements PageController {
    @Override
    public String handleRequest(String request) {
        if (request.equals("/submissions")) {
            return "Displaying submission list page";
        }
        return "Submission page not found";
    }
}