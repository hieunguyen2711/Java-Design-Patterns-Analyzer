public class LMSApplication {
    public static void main(String[] args) {
        LMSDispatcher dispatcher = new LMSDispatcher();
        
        System.out.println(dispatcher.dispatch("/courses"));
        System.out.println(dispatcher.dispatch("/assignments"));
        System.out.println(dispatcher.dispatch("/submissions"));
        System.out.println(dispatcher.dispatch("/invalid"));
    }
}