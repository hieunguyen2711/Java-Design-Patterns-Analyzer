public class AssignmentPageController implements PageController {
    @Override
    public String handleRequest(String request) {
        if (request.equals("/assignments")) {
            return "Displaying assignment list page";
        }
        return "Assignment page not found";
    }
}