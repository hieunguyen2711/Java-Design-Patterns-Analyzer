public class LMSDispatcher {
    private final PageController courseController;
    private final PageController assignmentController;
    private final PageController submissionController;

    public LMSDispatcher() {
        this.courseController = new CoursePageController();
        this.assignmentController = new AssignmentPageController();
        this.submissionController = new SubmissionPageController();
    }

    public String dispatch(String request) {
        if (request.startsWith("/courses")) {
            return courseController.handleRequest(request);
        } else if (request.startsWith("/assignments")) {
            return assignmentController.handleRequest(request);
        } else if (request.startsWith("/submissions")) {
            return submissionController.handleRequest(request);
        }
        return "Page not found";
    }
}