package com.lms.mapper;

import com.lms.model.Course;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CourseMapper {
    
    public static Course mapRowToCourse(ResultSet rs) throws SQLException {
        Course course = new Course();
        course.setId(rs.getInt("id"));
        course.setTitle(rs.getString("title"));
        course.setDescription(rs.getString("description"));
        return course;
    }
}