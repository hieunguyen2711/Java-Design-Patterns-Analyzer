package com.lms.model;

import java.util.List;
import java.util.stream.Collectors;

public class LessonModule {
    private String title;
    private List<Assignment> assignments;
    
    public LessonModule(String title, List<Assignment> assignments) {
        this.title = title;
        this.assignments = assignments;
    }
    
    public List<Submission> getSubmissions() {
        return assignments.stream()
                .flatMap(assignment -> assignment.getSubmissions().stream())
                .collect(Collectors.toList());
    }
    
    public List<Assignment> getAssignments() {
        return assignments;
    }
}