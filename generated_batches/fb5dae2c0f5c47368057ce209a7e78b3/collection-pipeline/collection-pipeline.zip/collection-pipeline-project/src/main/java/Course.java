package com.lms.model;

import java.util.List;
import java.util.stream.Collectors;

public class Course {
    private String name;
    private List<LessonModule> modules;
    
    public Course(String name, List<LessonModule> modules) {
        this.name = name;
        this.modules = modules;
    }
    
    public List<Assignment> getAllAssignments() {
        return modules.stream()
                .flatMap(module -> module.getAssignments().stream())
                .collect(Collectors.toList());
    }
    
    public List<Submission> getSubmissionsForCourse() {
        return getAllAssignments().stream()
                .flatMap(assignment -> assignment.getSubmissions().stream())
                .collect(Collectors.toList());
    }
    
    public String getName() {
        return name;
    }
}