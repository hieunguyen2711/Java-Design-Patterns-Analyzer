package com.lms.model;

import java.util.List;
import java.util.stream.Collectors;

public class Assignment {
    private String title;
    private List<Submission> submissions;
    
    public Assignment(String title, List<Submission> submissions) {
        this.title = title;
        this.submissions = submissions;
    }
    
    public List<Submission> getSubmissions() {
        return submissions;
    }
    
    public int getTotalSubmitted() {
        return submissions.stream()
                .filter(submission -> submission.getStatus().equals("SUBMITTED"))
                .collect(Collectors.toList())
                .size();
    }
}