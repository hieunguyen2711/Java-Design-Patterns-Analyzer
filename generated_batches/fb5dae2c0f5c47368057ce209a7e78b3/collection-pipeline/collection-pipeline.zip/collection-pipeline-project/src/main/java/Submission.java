package com.lms.model;

public class Submission {
    private String studentId;
    private String status;
    
    public Submission(String studentId, String status) {
        this.studentId = studentId;
        this.status = status;
    }
    
    public String getStatus() {
        return status;
    }
    
    public String get