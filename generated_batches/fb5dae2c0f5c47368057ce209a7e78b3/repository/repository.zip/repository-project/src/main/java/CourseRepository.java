package com.lms.repository;

import com.lms.model.Course;
import java.util.List;
import java.util.ArrayList;

public interface CourseRepository {
    Course findById(int id);
    List<Course> findAll();
    void save(Course course);
    void delete(int id);
}