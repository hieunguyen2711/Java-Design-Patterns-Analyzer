package com.lms.service;

import com.lms.model.Course;
import com.lms.repository.CourseRepository;
import java.util.List;

public class CourseService {
    private final CourseRepository repository;
    
    public CourseService(CourseRepository repository) {
        this.repository = repository;
    }
    
    public Course getCourseById(int id) {
        return repository.findById(id);
    }
    
    public