package com.lms.repository.impl;

import com.lms.model.Course;
import com.lms.repository.CourseRepository;
import java.util.List;
import java.util.ArrayList;

public class CourseRepositoryImpl implements CourseRepository {
    private List<Course> courses = new ArrayList<>();
    private int nextId = 1;
    
    @Override
    public Course findById(int id) {
        return courses.stream()
                .filter(course -> course.getId() == id)
                .findFirst()
                .orElse(null);
    }
    
    @Override
    public List<Course> findAll() {
        return new ArrayList<>(courses);
    }
    
    @Override
    public void save(Course course) {
        if (course.getId() == 0) {
            course.setId(nextId++);
        }
        courses.add(course);
    }
    
    @Override
    public void delete(int id) {
        courses.removeIf(course -> course.getId() == id);
    }
}