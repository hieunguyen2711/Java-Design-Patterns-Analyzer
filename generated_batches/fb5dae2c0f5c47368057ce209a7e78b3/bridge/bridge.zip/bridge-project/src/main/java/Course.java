package com.lms.course;

import com.lms.content.ContentManager;
import com.lms.content.CourseContent;

public class Course {
    private String title;
    private ContentManager contentManager;
    
    public Course(String title, ContentManager contentManager) {
        this.title = title;
        this.contentManager = contentManager;
    }
    
    public void displayCourseInfo() {
        System.out.println("Course: " + title);
        contentManager.displayContent();
    }
}