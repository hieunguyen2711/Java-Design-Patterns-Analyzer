package com.lms.content;

public abstract class CourseContent {
    protected String content;
    
    public CourseContent(String content) {
        this.content = content;
    }
    
    public String getContent() {
        return content;
    }
}