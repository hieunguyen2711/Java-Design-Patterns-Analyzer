package com.lms.content;

public class TextContentManager extends ContentManager {
    
    public TextContentManager(CourseContent courseContent) {
        super(courseContent);
    }
    
    @Override
    public void displayContent() {
        System.out.println("Text content: " + courseContent.getContent());
    }
}