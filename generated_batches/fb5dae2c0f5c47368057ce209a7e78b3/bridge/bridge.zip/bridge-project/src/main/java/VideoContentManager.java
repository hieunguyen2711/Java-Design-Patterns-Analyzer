package com.lms.content;

public class VideoContentManager extends ContentManager {
    
    public VideoContentManager(CourseContent courseContent) {
        super(courseContent);
    }
    
    @Override
    public void displayContent() {
        System.out.println("Video content: " + courseContent.getContent());
    }
}