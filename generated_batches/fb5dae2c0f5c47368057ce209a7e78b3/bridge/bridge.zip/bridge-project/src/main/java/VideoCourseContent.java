package com.lms.content;

public class VideoCourseContent extends CourseContent {
    
    public VideoCourseContent(String content) {
        super(content);
    }
}