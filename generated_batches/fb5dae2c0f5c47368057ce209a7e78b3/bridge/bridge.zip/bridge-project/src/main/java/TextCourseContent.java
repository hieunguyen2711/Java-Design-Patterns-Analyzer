package com.lms.content;

public class TextCourseContent extends CourseContent {
    
    public TextCourseContent(String content) {
        super(content);
    }
}