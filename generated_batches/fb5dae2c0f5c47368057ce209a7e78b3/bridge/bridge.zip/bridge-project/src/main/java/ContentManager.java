package com.lms.content;

public abstract class ContentManager {
    protected CourseContent courseContent;
    
    public ContentManager(CourseContent courseContent) {
        this.courseContent = courseContent;
    }
    
    public abstract void displayContent();
}