package com.lms.model;

import java.util.ArrayList;
import java.util.List;

public class Module {
    private String moduleId;
    private String title;
    private Course course;
    private List<Assignment> assignments;
    
    public Module(String moduleId, String title) {
        this.moduleId = moduleId;
        this.title = title;
        this.assignments = new ArrayList<>();
    }
    
    public void update(Course updatedCourse) {
        System.out.println("Module " + this.title + " notified of course update: " + updatedCourse.getTitle());
        // Module can react to course updates here
        this.title = updatedCourse.getTitle() + " - " + this.title;
    }
    
    public void addAssignment(Assignment assignment) {
        assignments.add(assignment);
    }
    
    // Getters
    public String getModuleId() { return moduleId; }
    public String getTitle() { return title; }
    public Course getCourse() { return course; }
    public List<Assignment> getAssignments() { return assignments; }
}