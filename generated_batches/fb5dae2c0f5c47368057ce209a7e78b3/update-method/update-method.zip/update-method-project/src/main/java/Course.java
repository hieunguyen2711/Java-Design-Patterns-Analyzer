package com.lms.model;

import java.util.ArrayList;
import java.util.List;

public class Course {
    private String courseId;
    private String title;
    private List<Module> modules;
    
    public Course(String courseId, String title) {
        this.courseId = courseId;
        this.title = title;
        this.modules = new ArrayList<>();
    }
    
    public void addModule(Module module) {
        modules.add(module);
    }
    
    public void updateCourseTitle(String newTitle) {
        this.title = newTitle;
        notifyObservers();
    }
    
    private void notifyObservers() {
        for (Module module : modules) {
            module.update(this);
        }
    }
    
    // Getters
    public String getCourseId() { return courseId; }
    public String getTitle() { return title; }
    public List<Module> getModules() { return modules; }
}