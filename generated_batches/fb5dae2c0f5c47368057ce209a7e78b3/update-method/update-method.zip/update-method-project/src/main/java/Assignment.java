package com.lms.model;

public class Assignment {
    private String assignmentId;
    private String title;
    private Module module;
    
    public Assignment(String assignmentId, String title) {
        this.assignmentId = assignmentId;
        this.title = title;
    }
    
    // Update method that demonstrates the pattern
    public void update(AssignmentUpdateEvent event) {
        System.out.println("Assignment " +