package com.lms.demo;

import com.lms.model.Course;

public class CourseBuilderDemo {
    public static void main(String[] args) {
        Course course = new Course.Builder()
                .setTitle("Advanced Java Programming")
                .setDescription("Learn advanced concepts in Java programming")
                .setCredits(3)
                .setInstructor("Dr. Smith")
                .build();
        
        System.out.println("Course: " + course.getTitle());
        System.out.println("Description: " + course.getDescription());
        System.out.println("Credits: " + course.getCredits());
        System.out.println("Instructor: " + course.getInstructor());
    }
}