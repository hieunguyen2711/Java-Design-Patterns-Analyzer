package com.lms.promise;

import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import java.util.function.Function;

public class Promise<T> {
    private final CompletableFuture<T> future;
    
    private Promise(CompletableFuture<T> future) {
        this.future = future;
    }
    
    public static <T> Promise<T> resolve(T value) {
        return new Promise<>(CompletableFuture.completedFuture(value));
    }
    
    public static <T> Promise<T> reject(Throwable throwable) {
        CompletableFuture<T> failedFuture = new CompletableFuture<>();
        failedFuture.completeExceptionally(throwable);
        return new Promise<>(failedFuture);
    }
    
    public static <T> Promise<T> async(Function<Consumer<T>, Void> asyncOperation) {
        CompletableFuture<T> future = new CompletableFuture<>();
        asyncOperation.accept(future::complete);
        return new Promise<>(future);
    }
    
    public <U> Promise<U> then(Function<T, U> mapper) {
        return new Promise<>(future.thenApply(mapper));
    }
    
    public Promise<Void> then(Consumer<T> action) {
        return new Promise<>(future.thenAccept(action));
    }
    
    public Promise<T> catchException(Function<Throwable, T> errorHandler) {
        return new Promise<>(future.exceptionally(errorHandler::apply));
    }
    
    public T get() throws InterruptedException, java.util.concurrent.ExecutionException {
        return future.get();
    }
}