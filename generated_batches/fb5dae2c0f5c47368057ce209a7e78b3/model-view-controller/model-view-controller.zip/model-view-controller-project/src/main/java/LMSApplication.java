package lms;

import lms.controller.CourseController;
import lms.model.Course;
import lms.view.CourseView;

public class LMSApplication {
    public static void main(String[] args) {
        // Model
        Course course = new Course("CS101", "Introduction to Computer Science", 
                                  "Learn the fundamentals of computer science");
        
        // View
        CourseView courseView = new CourseView();
        
        // Controller
        CourseController controller = new CourseController(course, courseView);
        
        // Display initial course details
        controller.displayCourse();