package lms.controller;

import lms.model.Course;
import lms.view.CourseView;

public class CourseController {
    private Course model;
    private CourseView view;
    
    public CourseController(Course model, CourseView view) {
        this.model = model;
        this.view = view;
    }
    
    public void updateCourseTitle(String title) {
        model.setTitle(title);
        view.printCourseDetails(model.getTitle(), model.getDescription());
    }
    
    public void updateCourseDescription(String description) {
        model.setDescription(description);
        view.printCourseDetails(model.getTitle(), model.getDescription());
    }
    
    public void displayCourse() {
        view.printCourseDetails(model.getTitle(), model.getDescription());
    }
}