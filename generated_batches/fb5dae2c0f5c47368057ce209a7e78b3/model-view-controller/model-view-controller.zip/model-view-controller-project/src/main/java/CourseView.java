package lms.view;

public class CourseView {
    public void printCourseDetails(String title, String description) {
        System.out.println("Course Details:");
        System.out.println("Title: " + title);
        System.out.println("Description: " + description);
    }
}