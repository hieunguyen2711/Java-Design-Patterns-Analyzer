package com.lms.repository;

import com.lms.model.Course;

public interface CourseRepository {
    Course findById(Long id);
}