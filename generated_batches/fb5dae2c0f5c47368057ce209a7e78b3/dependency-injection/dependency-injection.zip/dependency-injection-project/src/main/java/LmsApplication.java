package com.lms;

import com.lms.service.CourseService;
import com.lms.repository.CourseRepository;
import com.lms.repository.DatabaseCourseRepository;

public class LmsApplication {
    public static void main(String[] args) {
        // Dependency injection - injecting the repository dependency
        CourseRepository courseRepository = new DatabaseCourseRepository();
        CourseService courseService = new CourseService(courseRepository);
        
        // Use the service
        var course = courseService.getCourseById(1L);
        System.out.println("Course: " + course.getName());
    }
}