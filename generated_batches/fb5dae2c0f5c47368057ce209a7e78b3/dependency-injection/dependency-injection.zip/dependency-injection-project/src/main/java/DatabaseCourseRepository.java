package com.lms.repository;

import com.lms.model.Course;

public class DatabaseCourseRepository implements CourseRepository {
    @Override
    public Course findById(Long id) {
        // Simulate database lookup
        return new Course(id, "Java Programming");
    }
}