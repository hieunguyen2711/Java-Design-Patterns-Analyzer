package com.lms.service;

import com.lms.repository.CourseRepository;
import com.lms.model.Course;

public class CourseService {
    private final CourseRepository courseRepository;
    
    public CourseService(CourseRepository courseRepository) {
        this.courseRepository = courseRepository;
    }
    
    public Course getCourseById(Long id) {
        return courseRepository.findById(id);
    }
}