public class PercentageGradeStrategy implements GradingStrategy {
    @Override
    public double calculateGrade(double score, double maxScore) {
        return (score / maxScore) * 100;
    }
}