public class LetterGradeStrategy implements GradingStrategy {
    @Override
    public double calculateGrade(double score, double maxScore) {
        double percentage = (score / maxScore) * 100;
        
        if (percentage >= 90) return 4.0; // A
        else if (percentage >= 80) return 3.0; // B
        else if (percentage >= 70) return 2.0; // C
        else if (percentage >= 60) return 1.0; // D
        else return 0.0; // F
    }
}