public class GradeCalculator {
    public static void main(String[] args) {
        Submission submission1 = new Submission(85, 100, new LetterGradeStrategy());
        Submission submission2 = new Submission(85, 100, new PercentageGradeStrategy());
        
        System.out.println("Letter grade: " + submission1.getGrade());
        System.out.println("Percentage grade: " + submission2.getGrade());
        
        // Change strategy dynamically
        submission1.setGradingStrategy(new PercentageGradeStrategy());
        System.out.println("Updated letter grade to percentage: " + submission1.getGrade());
    }
}