public interface GradingStrategy {
    double calculateGrade(double score, double maxScore);
}