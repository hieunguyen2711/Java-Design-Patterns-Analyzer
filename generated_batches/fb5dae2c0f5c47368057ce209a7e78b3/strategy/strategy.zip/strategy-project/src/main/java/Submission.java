public class Submission {
    private double score;
    private double maxScore;
    private GradingStrategy gradingStrategy;
    
    public Submission(double score, double maxScore, GradingStrategy gradingStrategy) {
        this.score = score;
        this.maxScore = maxScore;
        this.gradingStrategy = gradingStrategy;
    }
    
    public double getGrade() {
        return gradingStrategy.calculateGrade(score, maxScore);
    }
    
    public void setGradingStrategy(GradingStrategy gradingStrategy) {
        this.gradingStrategy = gradingStrategy;
    }
}