public class Submission {
    private Assignment assignment;
    private String studentId;
    private String content;
    private double grade;

    public Submission(Assignment assignment, String studentId, String content) {
        this.assignment = assignment;
        this.studentId = studentId;
        this.content = content;
        this.grade = 0.0;
    }

    // Getters and setters
    public Assignment getAssignment() { return assignment; }
    public void setAssignment(Assignment assignment) { this.assignment = assignment; }
    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    public double getGrade() { return grade; }
    public void setGrade(double grade) { this.grade = grade; }
}