public class Assignment {
    private String title;
    private String description;
    private int maxPoints;

    public Assignment(String title, String description, int maxPoints) {
        this.title = title;
        this.description = description;
        this.maxPoints = maxPoints;
    }

    // Getters and setters
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public int getMaxPoints() { return maxPoints; }
    public void setMaxPoints(int maxPoints) { this.maxPoints = maxPoints; }
}