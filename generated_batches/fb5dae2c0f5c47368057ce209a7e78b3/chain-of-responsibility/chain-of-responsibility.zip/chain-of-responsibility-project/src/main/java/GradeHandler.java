public abstract class GradeHandler {
    protected GradeHandler nextHandler;

    public void setNext(GradeHandler handler) {
        this.nextHandler = handler;
    }

    public abstract double handleRequest(Submission submission);

    protected double processNext(Submission submission) {
        if (nextHandler != null) {
            return nextHandler.handleRequest(submission);
        }
        return 0.0;
    }
}