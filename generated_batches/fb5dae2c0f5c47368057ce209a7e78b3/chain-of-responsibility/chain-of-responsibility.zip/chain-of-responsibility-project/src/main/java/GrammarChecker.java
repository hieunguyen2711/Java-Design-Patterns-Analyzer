public class GrammarChecker extends GradeHandler {
    @Override
    public double handleRequest(Submission submission) {
        String content = submission.getContent();
        
        if (content != null && content.length() > 100) {
            // Simple grammar