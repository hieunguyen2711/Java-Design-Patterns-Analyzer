package com.lms.view;

import com.lms.model.Course;
import com.lms.model.LessonModule;

import java.util.List;

public class CourseViewHelper {
    private Course course;
    private List<LessonModule> modules;
    
    public CourseViewHelper(Course course, List<LessonModule> modules) {
        this.course = course;
        this.modules = modules;
    }
    
    public String generateCourseOverview() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== ").append(course.getTitle()).append(" ===\n");
        sb.append(course.getDescription()).append("\n\n");
        sb.append("Modules:\n");
        
        for (LessonModule module : modules