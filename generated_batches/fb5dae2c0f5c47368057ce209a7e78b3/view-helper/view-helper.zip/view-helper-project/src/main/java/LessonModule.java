package com.lms.model;

public class LessonModule {
    private String title;
    private String content;
    private int moduleId;
    private int courseId;
    
    public LessonModule(int moduleId, int courseId, String title, String content) {
        this.moduleId = moduleId;
        this.courseId = courseId;
        this.title = title;
        this.content = content;
    }
    
    // Getters and setters
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    public int getModuleId() { return moduleId; }
    public void setModuleId(int moduleId) { this.moduleId = moduleId; }
    public int getCourseId() { return courseId; }
    public void setCourseId(int courseId) { this.courseId = courseId; }
}