public class LoginPage implements PageObject {
    private String url = "https://lms.example.com/login";
    
    @Override
    public void navigateTo() {
        System.out.println("Navigating to login page: " + url);
    }
    
    @Override
    public boolean isDisplayed() {
        return true;
    }
    
    public void enterUsername(String username) {
        System.out.println("Entering username: " + username);
    }
    
    public void enterPassword(String password) {
        System.out.println("Entering password: " + password);
    }
    
    public void clickLoginButton() {
        System.out.println("Clicking login button");
    }
}