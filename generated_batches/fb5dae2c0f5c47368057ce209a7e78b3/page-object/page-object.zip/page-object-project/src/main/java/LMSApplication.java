public class LMSApplication {
    public static void main(String[] args) {
        LoginPage loginPage = new LoginPage();
        CoursePage coursePage = new CoursePage();
        AssignmentPage assignmentPage = new AssignmentPage();
        
        // Using page objects to navigate and interact with the application
        loginPage.navigateTo();