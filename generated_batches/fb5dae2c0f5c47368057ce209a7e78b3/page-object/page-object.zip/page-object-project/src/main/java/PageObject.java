public interface PageObject {
    void navigateTo();
    boolean isDisplayed();
}