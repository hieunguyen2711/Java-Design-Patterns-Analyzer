public class AssignmentPage implements PageObject {
    private String url = "https://lms.example.com/assignments";
    
    @Override
    public void navigateTo() {
        System.out.println("Navigating to assignment page: " + url);
    }
    
    @Override
    public boolean isDisplayed() {
        return true;
    }
    
    public void submitAssignment(String fileName) {
        System.out.println("Submitting assignment: " + fileName);
    }
    
    public void viewSubmissionStatus() {
        System.out.println("Viewing submission status");
    }
}