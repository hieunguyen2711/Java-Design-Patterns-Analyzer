public class CoursePage implements PageObject {
    private String url = "https://lms.example.com/courses";
    
    @Override
    public void navigateTo() {
        System.out.println("Navigating to course page: " + url);
    }
    
    @Override
    public boolean isDisplayed() {
        return true;
    }
    
    public void selectCourse(String courseName) {
        System.out.println("Selecting course: " + courseName);
    }
    
    public void viewCourseDetails() {
        System.out.println("Viewing course details");
    }
}