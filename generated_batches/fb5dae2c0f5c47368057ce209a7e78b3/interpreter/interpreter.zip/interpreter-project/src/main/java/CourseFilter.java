public class CourseFilter {
    private Expression expression;
    
    public CourseFilter(Expression expression) {
        this.expression = expression;
    }
    
    public boolean filterCourse(String courseInfo) {
        return expression.interpret(courseInfo);
    }
}