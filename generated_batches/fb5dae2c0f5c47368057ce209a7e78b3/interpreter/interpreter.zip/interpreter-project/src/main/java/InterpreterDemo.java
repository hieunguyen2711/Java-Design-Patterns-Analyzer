public class InterpreterDemo {
    public static void main(String[] args) {
        // Create terminal expressions
        Expression javaCourse = new TerminalExpression("Java");
        Expression advancedCourse = new TerminalExpression("Advanced");
        Expression beginnerCourse = new TerminalExpression("Beginner");
        
        // Combine expressions using interpreter pattern
        Expression advancedOrBeginner = new OrExpression(advancedCourse, beginnerCourse);
        Expression javaAdvanced = new AndExpression(javaCourse, advancedOrBeginner);
        
        // Create filter with complex expression
        CourseFilter filter = new CourseFilter(javaAdvanced);
        
        // Test filtering
        String course1 = "Java Advanced Programming";
        String course2 = "Python Beginner Basics";
        String course3 = "Java Beginner Fundamentals";
        
        System.out.println("Course 1 '" + course1