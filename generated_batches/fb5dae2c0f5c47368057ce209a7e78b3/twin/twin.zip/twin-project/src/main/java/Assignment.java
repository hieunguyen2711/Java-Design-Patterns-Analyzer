package com.lms.model;

public class Assignment {
    private String title;
    private LessonModule lessonModule;
    
    public Assignment(String title, LessonModule lessonModule) {
        this.title = title;
        this.lessonModule = lessonModule;
    }
    
    public String getTitle() {
        return title;
    }
    
    public LessonModule getLessonModule() {
        return lessonModule;
    }
}