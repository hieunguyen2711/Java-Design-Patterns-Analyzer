package com.lms.model;

public class Grade {
    private Submission submission;
    private double score;
    private String feedback;
    
    public Grade(Submission submission, double score, String feedback) {
        this.submission = submission;
        this.score = score;
        this.feedback = feedback;
    }
    
    public Submission getSubmission() {
        return submission;
    }
    
    public double getScore() {
        return score;
    }
    
    public String getFeedback() {
        return feedback;
    }
}