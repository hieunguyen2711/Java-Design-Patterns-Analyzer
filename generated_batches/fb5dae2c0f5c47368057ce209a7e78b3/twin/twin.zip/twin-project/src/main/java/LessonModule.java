package com.lms.model;

public class LessonModule {
    private String title;
    private Course course;
    
    public LessonModule(String title, Course course) {
        this.title = title;
        this.course = course;
    }
    
    public String getTitle() {
        return title;
    }
    
    public Course getCourse() {
        return course;
    }
}