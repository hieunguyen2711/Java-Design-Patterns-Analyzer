package com.lms;

import com.lms.course.Course;
import com.lms.course.CourseManager;

public class Main {
    public static void main(String[] args) {
        Course course = new Course("CS101", "Introduction to Computer Science");
        CourseManager manager = new CourseManager(course);
        
        // First publish attempt - should succeed
        manager.attemptPublish();
        
        // Second publish attempt - should balk
        manager.attemptPublish();
    }
}