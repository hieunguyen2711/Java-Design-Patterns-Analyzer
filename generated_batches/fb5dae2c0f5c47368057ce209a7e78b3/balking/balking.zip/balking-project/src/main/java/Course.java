package com.lms.course;

public class Course {
    private String courseId;
    private String title;
    private boolean isPublished = false;
    
    public Course(String courseId, String title) {
        this.courseId = courseId;
        this.title = title;
    }
    
    public void publish() {
        if (!isPublished) {
            System.out.println("Publishing course: " + title);
            isPublished = true;
        } else {
            System.out.println("Course already published, balking...");
        }
    }
    
    public boolean isPublished() {
        return isPublished;
    }
}