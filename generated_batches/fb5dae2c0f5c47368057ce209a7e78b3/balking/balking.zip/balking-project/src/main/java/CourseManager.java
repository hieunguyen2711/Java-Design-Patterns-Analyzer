package com.lms.course;

public class CourseManager {
    private Course course;
    
    public CourseManager(Course course) {
        this.course = course;
    }
    
    public void attemptPublish() {
        System.out.println("Attempting to publish course...");
        course.publish();
    }
}