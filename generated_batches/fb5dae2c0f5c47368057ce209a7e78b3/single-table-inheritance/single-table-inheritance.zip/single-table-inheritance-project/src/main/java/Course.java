package com.lms.model;

import java.util.ArrayList;
import java.util.List;

public class Course {
    private String courseName;
    private List<ContentItem> contentItems;
    
    public Course(String courseName) {
        this.courseName = courseName;
        this.contentItems = new ArrayList<>();
    }
    
    public void addContentItem(ContentItem item) {
        contentItems.add(item);
    }
    
    public void displayAllContent() {
        System.out