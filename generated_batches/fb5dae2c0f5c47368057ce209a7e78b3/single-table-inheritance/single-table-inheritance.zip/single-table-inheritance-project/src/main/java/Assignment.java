package com.lms.model;

public class Assignment extends ContentItem {
    
    private int maxPoints;
    
    public Assignment(String title, String description, int durationMinutes, int maxPoints) {
        super(title, description, durationMinutes);
        this.maxPoints = maxPoints;
    }
    
    @Override
    public void displayContent() {
        System.out.println("Assignment: " + title + " (Max points: " + maxPoints + ")");
    }
    
    // Getter and setter for maxPoints
    public int getMaxPoints() { return maxPoints; }
    public void setMaxPoints(int maxPoints) { this.maxPoints = maxPoints; }
}