package com.lms.model;

public class Lesson extends ContentItem {
    
    public Lesson(String title, String description, int durationMinutes) {
        super(title, description, durationMinutes);
    }
    
    @Override
    public void displayContent() {
        System.out.println("Lesson: " + title + " (" + durationMinutes + " minutes)");
    }
}