package com.lms.model;

public class Submission {
    private Assignment assignment;
    private String studentId;
    private String content;
    
    public Submission(Assignment assignment, String studentId, String content) {
        this.assignment = assignment;
        this.studentId = studentId;
        this.content = content;
    }
    
    public Assignment getAssignment() {
        return assignment;
    }
    
    public String getStudentId() {
        return studentId;
    }
    
    public String getContent() {
        return content;
    }
}