package com.lms.model;

public class LessonModule {
    private String moduleName;
    private int durationMinutes;
    
    public LessonModule(String moduleName, int durationMinutes) {
        this.moduleName = moduleName;
        this.durationMinutes = durationMinutes;
    }
    
    public String getModuleName() {
        return moduleName;
    }
    
    public int getDurationMinutes() {
        return durationMinutes;
    }
}