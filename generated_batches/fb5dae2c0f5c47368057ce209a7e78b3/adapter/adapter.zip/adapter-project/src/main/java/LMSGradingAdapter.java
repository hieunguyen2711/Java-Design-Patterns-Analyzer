package com.lms.service;

import com.lms.model.Submission;

public class LMSGradingAdapter implements GradingSystem {
    private LegacyGradingService legacyService;
    
    public LMSGradingAdapter(LegacyGradingService legacyService) {
        this.legacyService = legacyService;
    }
    
    @Override
    public double calculateGrade(Submission submission) {