package com.lms.service;

public interface GradingSystem {
    double calculateGrade(Submission submission);
}