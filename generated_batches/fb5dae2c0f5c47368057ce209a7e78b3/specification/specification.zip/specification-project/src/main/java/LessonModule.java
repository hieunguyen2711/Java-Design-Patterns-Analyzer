package com.lms.model;

public class LessonModule {
    private String moduleName;
    private Course course;
    
    public LessonModule(String moduleName, Course course) {
        this.moduleName = moduleName;
        this.course = course;
    }
    
    public String getModuleName() {
        return moduleName;
    }
    
    public Course getCourse() {
        return course;
    }
}