package com.lms.model;

public class Assignment {
    private String title;
    private LessonModule module;
    
    public Assignment(String title, LessonModule module) {
        this.title = title;
        this.module = module;
    }
    
    public String getTitle() {
        return title;
    }
    
    public LessonModule getModule() {
        return module;
    }
}