package com.lms.strategy;

import com.lms.model.Submission;

public interface GradingStrategy {
    double grade(Submission submission);
}