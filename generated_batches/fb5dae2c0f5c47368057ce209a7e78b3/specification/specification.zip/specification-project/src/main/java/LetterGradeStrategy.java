package com.lms.strategy;

import com.lms.model.Submission;

public class LetterGradeStrategy implements GradingStrategy {
    
    @Override
    public double grade(Submission submission) {
        String content = submission.getContent();
        if (content == null || content.isEmpty()) {
            return 0.0;
        }
        
        int length = content.length();
        if (length >= 1