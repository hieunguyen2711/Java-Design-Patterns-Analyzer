public abstract class Lesson {
    protected String title;
    protected int durationMinutes;
    
    public Lesson(String title, int durationMinutes) {
        this.title = title;
        this.durationMinutes = durationMinutes;
    }
    
    public abstract void displayLesson();
    
    public String getTitle() {
        return title;
    }
    
    public int getDurationMinutes() {
        return durationMinutes;
    }
}