public class VideoLesson extends Lesson {
    private String videoUrl;
    
    public VideoLesson(String title, int durationMinutes, String videoUrl) {
        super(title, durationMinutes);
        this.videoUrl = videoUrl;
    }
    
    @Override
    public void displayLesson() {
        System.out.println("Video Lesson: " + title + " (" + durationMinutes + " mins)");
        System.out.println("URL: " + videoUrl);
    }
}