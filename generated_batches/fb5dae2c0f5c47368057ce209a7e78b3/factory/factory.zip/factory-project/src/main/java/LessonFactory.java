public class LessonFactory {
    
    public static Lesson createLesson(String type, String title, int durationMinutes, String content) {
        switch (type.toLowerCase()) {
            case "video":
                return new VideoLesson(title, durationMinutes, content);
            case "reading":
                return new ReadingLesson(title, durationMinutes, content);
            default:
                throw new IllegalArgumentException("Unknown lesson type: " + type);
        }
    }
}