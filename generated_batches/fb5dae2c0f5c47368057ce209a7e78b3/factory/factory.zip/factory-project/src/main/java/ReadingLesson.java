public class ReadingLesson extends Lesson {
    private String content;
    
    public ReadingLesson(String title, int durationMinutes, String content) {
        super(title, durationMinutes);
        this.content = content;
    }
    
    @Override
    public void displayLesson() {
        System.out.println("Reading Lesson: " + title + " (" + durationMinutes + " mins)");
        System.out.println("Content preview: " + content.substring(0, Math.min(50, content.length())) + "...");
    }
}