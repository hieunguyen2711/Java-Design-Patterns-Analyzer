package com.lms.model;

/**
 * Represents a course in the LMS system.
 * Implements Serializable marker interface to indicate
 * that this object can be persisted.
 */
public class Course implements Serializable {
    private String courseId;
    private String title;
    private String description;
    
    public Course(String courseId, String title, String description) {
        this.courseId = courseId;
        this.title = title;
        this.description = description;
    }
    
    // Getters and setters
    public String getCourseId() { return courseId; }
    public void setCourseId(String courseId) { this.courseId = courseId; }
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}