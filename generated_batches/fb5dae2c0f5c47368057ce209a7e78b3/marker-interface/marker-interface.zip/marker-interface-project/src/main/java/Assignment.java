package com.lms.model;

/**
 * Represents an assignment in the LMS system.
 * Implements Serializable marker interface to indicate
 * that this object can be persisted.
 */
public class Assignment implements Serializable {
    private String assignmentId;
    private String title;
    private String description;
    private Course course;
    
    public Assignment(String assignmentId, String title, String description, Course course) {
        this.assignmentId = assignmentId;
        this.title = title;
        this.description = description;
        this.course = course;
    }
    
    // Getters and setters
    public String getAssignmentId() { return assignmentId; }
    public void setAssignmentId(String assignmentId) { this.assignmentId = assignmentId; }
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public Course getCourse() { return course; }
    public void setCourse(Course course) { this.course = course; }
}