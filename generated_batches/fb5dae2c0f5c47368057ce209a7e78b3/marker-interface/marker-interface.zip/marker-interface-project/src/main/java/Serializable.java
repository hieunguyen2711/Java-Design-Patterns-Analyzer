package com.lms.model;

/**
 * Marker interface for serializable objects in the LMS system.
 * This interface indicates that a class can be serialized to persist
 * course data, user progress, and assignment submissions.
 */
public interface Serializable {
    // Marker interface - no methods required
}