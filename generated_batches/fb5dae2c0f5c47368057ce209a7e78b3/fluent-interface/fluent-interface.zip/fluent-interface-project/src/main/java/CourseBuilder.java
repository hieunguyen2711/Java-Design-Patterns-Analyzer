public class CourseBuilder {
    private String title;
    private String description;
    private int credits;
    private String instructor;
    
    public CourseBuilder setTitle(String title) {
        this.title = title;
        return this;
    }
    
    public CourseBuilder setDescription(String description) {
        this.description = description;
        return this;
    }
    
    public CourseBuilder setCredits(int credits) {
        this.credits = credits;
        return this;
    }
    
    public CourseBuilder setInstructor(String instructor) {
        this.instructor = instructor;
        return this;
    }
    
    public Course build() {
        return new Course(title, description, credits, instructor);
    }
}