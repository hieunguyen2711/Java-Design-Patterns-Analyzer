public class LMSApplication {
    public static void main(String[] args) {
        // Using the fluent interface to build a course
        Course course = new CourseBuilder()
                .setTitle("Advanced Java Programming")
                .setDescription("Learn advanced Java concepts and design patterns")
                .setCredits(3)
                .setInstructor("Dr. Smith")
                .build();
        
        System.out.println(course);
    }
}