public class Course {
    private String title;
    private String description;
    private int credits;
    private String instructor;
    
    public Course(String title, String description, int credits, String instructor) {
        this.title = title;
        this.description = description;
        this.credits = credits;
        this.instructor = instructor;
    }
    
    // Getters
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public int getCredits() { return credits; }
    public String getInstructor() { return instructor; }
    
    @Override
    public String toString() {
        return "Course{" +
                "title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", credits=" + credits +
                ", instructor='" + instructor + '\'' +
                '}';
    }
}