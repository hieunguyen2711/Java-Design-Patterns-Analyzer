package com.lms.activeobject;

public class LMS {
    private final ActiveObject activeObject = new ActiveObjectImpl();

    public void