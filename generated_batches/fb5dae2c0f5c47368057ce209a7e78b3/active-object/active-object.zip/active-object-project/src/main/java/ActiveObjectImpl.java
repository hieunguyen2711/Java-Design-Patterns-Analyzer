package com.lms.activeobject;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class ActiveObjectImpl implements ActiveObject {
    private final BlockingQueue<Runnable> queue = new LinkedBlockingQueue<>();
    private final Thread workerThread;

    public ActiveObjectImpl() {
        this.workerThread = new Thread(this::processRequests);
        this.workerThread.start();
    }

    @Override
    public void submitAssignment(String studentId, String assignmentId, byte[] content) {
        queue.offer(() -> {
            // Simulate processing
            try {
                Thread.sleep(100);
                System.out.println("Submitted: " + studentId + " - " + assignmentId);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
    }

    @Override
    public void gradeSubmission(String submissionId, int score) {
        queue.offer(() -> {
            try {
                Thread.sleep(50);
                System.out.println("Graded: " + submissionId + " - Score: " + score);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
    }

    @Override
    public void updateProgress(String studentId, String moduleId, double progress) {
        queue.offer(() -> {
            try {
                Thread.sleep(25);
                System.out.println("Updated Progress: " + studentId + " - Module: " + moduleId + " - " + progress + "%");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
    }

    private void processRequests() {
        while (!Thread.currentThread().isInterrupted()) {
            try {
                Runnable task = queue.take();
                task.run();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }

    public void shutdown() {
        workerThread.interrupt();
    }
}