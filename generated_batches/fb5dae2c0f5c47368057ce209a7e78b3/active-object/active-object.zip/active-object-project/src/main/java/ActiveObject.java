package com.lms.activeobject;

public interface ActiveObject {
    void submitAssignment(String studentId, String assignmentId, byte[] content);
    void gradeSubmission(String submissionId, int score);
    void updateProgress(String studentId, String moduleId, double progress);
}