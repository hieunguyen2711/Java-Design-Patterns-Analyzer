package com.lms.course;

public class DraftState implements CourseState {
    
    @Override
    public void publish(Course course) {
        System.out.println("Publishing course: " + course.getName());
        course.setState(new PublishedState());
    }
    
    @Override
    public void archive(Course course) {
        System.out.println("Archiving draft course: " + course.getName());
        course.setState(new ArchivedState());
    }
}