package com.lms.course;

public class ArchivedState implements CourseState {
    
    @Override
    public void publish(Course course) {
        System.out.println("Cannot publish archived course: " + course.getName());
    }
    
    @Override
    public void archive(Course course) {
        System.out.println("Course already archived: " + course.getName());
    }
}