package com.lms.course;

public class PublishedState implements CourseState {
    
    @Override
    public void publish(Course course) {
        System.out.println("Course already published: " + course.getName());
    }
    
    @Override
    public void archive(Course course) {
        System.out.println("Archiving published course: " + course.getName());
        course.setState(new ArchivedState());
    }
}