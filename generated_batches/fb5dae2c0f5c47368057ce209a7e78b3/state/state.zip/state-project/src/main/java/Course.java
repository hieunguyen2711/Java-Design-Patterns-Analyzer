package com.lms.course;

public class Course {
    private String name;
    private CourseState state;
    
    public Course(String name) {
        this.name = name;
        this.state = new DraftState();
    }
    
    public void setState(CourseState state) {
        this.state = state;
    }
    
    public void publish() {
        state.publish(this);
    }
    
    public void archive() {
        state.archive(this);
    }
    
    public String getName() {
        return name;
    }
    
    public CourseState getState() {
        return state;
    }
}