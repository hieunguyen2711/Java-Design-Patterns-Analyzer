package com.lms.course;

public class CourseManager {
    public static void main(String[] args) {
        Course course = new Course("Java Programming");
        
        System.out.println("Initial state: " + course.getState().getClass().