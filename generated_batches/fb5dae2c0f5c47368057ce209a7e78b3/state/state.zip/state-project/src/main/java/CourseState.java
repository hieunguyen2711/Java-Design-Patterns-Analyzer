package com.lms.course;

public interface CourseState {
    void publish(Course course);
    void archive(Course course);
}