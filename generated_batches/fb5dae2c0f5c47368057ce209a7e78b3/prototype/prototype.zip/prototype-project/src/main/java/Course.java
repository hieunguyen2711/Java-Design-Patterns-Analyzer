package com.lms.model;

import java.util.ArrayList;
import java.util.List;

public class Course implements Cloneable {
    private String title;
    private String description;
    private List<LessonModule> modules;
    
    public Course(String title, String description) {
        this.title = title;
        this.description = description;
        this.modules = new ArrayList<>();
    }
    
    public void addModule(LessonModule module) {
        modules.add(module);
    }
    
    public Course clone() throws CloneNotSupportedException {
        Course clonedCourse = (Course) super.clone();
        clonedCourse.modules = new ArrayList<>();
        for (LessonModule module : this.modules) {
            clonedCourse.addModule(module.clone());
        }
        return clonedCourse;
    }
    
    // Getters and setters
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public List<LessonModule> getModules() { return modules; }
}