package com.lms.model;

import java.util.ArrayList;
import java.util.List;

public class LessonModule implements Cloneable {
    private String moduleName;
    private List<Assignment> assignments;
    
    public LessonModule(String moduleName) {
        this.moduleName = moduleName;
        this.assignments = new ArrayList<>();
    }
    
    public void addAssignment(Assignment assignment) {
        assignments.add(assignment);
    }
    
    public LessonModule clone() throws CloneNotSupportedException {
        LessonModule clonedModule = (LessonModule) super.clone();
        clonedModule.assignments = new ArrayList<>();
        for (Assignment assignment : this.assignments) {
            clonedModule.addAssignment(assignment.clone());
        }
        return clonedModule;
    }
    
    // Getters and setters
    public String getModuleName() { return moduleName; }
    public void setModuleName(String moduleName) { this.moduleName = moduleName; }
    public List<Assignment> getAssignments() { return assignments; }
}