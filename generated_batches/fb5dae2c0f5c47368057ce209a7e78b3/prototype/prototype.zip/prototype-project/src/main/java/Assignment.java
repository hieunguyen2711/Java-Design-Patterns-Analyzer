package com.lms.model;

public class Assignment implements Cloneable {
    private String title;
    private String description;
    private int maxPoints;
    
    public Assignment(String title, String description, int maxPoints) {
        this.title = title;
        this.description = description;
        this.maxPoints =