package com.lms.course;

public class ProgrammingCourse extends Course {
    
    public ProgrammingCourse(String courseName) {
        super(courseName);
    }
    
    @Override
    protected void enrollStudents() {
        System.out.println(courseName + ": Enrolling students with programming background");
    }
    
    @Override
    protected void deliverContent() {
        System.out.println(courseName + ": Delivering coding tutorials and exercises");
    }
    
    @Override
    protected void conductAssessments() {
        System.out.println(courseName + ": Conducting code reviews and project submissions");
    }
}