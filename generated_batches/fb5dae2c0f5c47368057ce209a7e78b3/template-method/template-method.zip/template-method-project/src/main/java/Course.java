package com.lms.course;

public abstract class Course {
    protected String courseName;
    
    public Course(String courseName) {
        this.courseName = courseName;
    }
    
    // Template method
    public final void runCourse() {
        enrollStudents();
        deliverContent();
        conductAssessments();
        provideFeedback();
    }
    
    protected abstract void enrollStudents();
    protected abstract void deliverContent();
    protected abstract void conductAssessments();
    
    // Common implementation
    protected void provideFeedback() {
        System.out.println(courseName + ": Providing feedback to students");
    }
}