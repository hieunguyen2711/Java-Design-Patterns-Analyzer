package com.lms.course;

public class ArtCourse extends Course {
    
    public ArtCourse(String courseName) {
        super(courseName);
    }
    
    @Override
    protected void enrollStudents() {
        System.out.println(courseName + ": Enrolling art enthusiasts and beginners");
    }
    
    @Override
    protected void deliverContent() {
        System.out.println(courseName + ": Delivering drawing techniques and artistic theory");
    }
    
    @Override
    protected void conductAssessments() {
        System.out.println(courseName + ": Conducting portfolio reviews and creative projects");
    }
}