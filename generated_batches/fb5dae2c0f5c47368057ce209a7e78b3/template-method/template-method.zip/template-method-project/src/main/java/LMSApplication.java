package com.lms;

import com.lms.course.Course;
import com.lms.course.ProgrammingCourse;
import com.lms.course.ArtCourse;

public class LMSApplication {
    public static void main(String[] args) {
        Course programmingCourse = new ProgrammingCourse("Advanced Java Programming");
        Course artCourse = new ArtCourse("Digital Art Fundamentals");
        
        System.out.println("=== Running Programming Course ===");
        programmingCourse.runCourse();
        
        System.out.println("\n=== Running