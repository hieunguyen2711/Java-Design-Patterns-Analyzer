package lms;

import java.util.ArrayList;
import java.util.List;

public class Assignment {
    private String name;
    private List<Submission> submissions;
    
    public Assignment(String name) {
        this.name = name;
        this.submissions = new ArrayList<>();
    }
    
    public void addSubmission(Submission submission) {
        submissions.add(submission);
    }
    
    public String getName() {
        return name;
    }
    
    public List<Submission> getSubmissions() {
        return submissions;
    }
}