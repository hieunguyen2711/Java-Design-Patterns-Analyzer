package lms;

import java.util.ArrayList;
import java.util.List;

public class LessonModule {
    private String title;
    private List<Assignment> assignments;
    
    public LessonModule(String title) {
        this.title = title;
        this.assignments = new ArrayList<>();
    }
    
    public void addAssignment(Assignment assignment) {
        assignments.add(assignment);
    }
    
    public String getTitle() {
        return title;
    }
    
    public List<Assignment> getAssignments() {
        return assignments;
    }
}