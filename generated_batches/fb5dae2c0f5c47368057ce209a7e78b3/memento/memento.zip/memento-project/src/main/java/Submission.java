package lms;

public class Submission {
    private String studentId;
    private String content;
    private double grade;
    
    public Submission(String studentId, String content) {
        this.studentId = studentId;
        this.content = content;
        this.grade = -1; // Not graded yet
    }
    
    public void setGrade(double grade) {
        this.grade = grade;
    }
    
    public String getStudentId()