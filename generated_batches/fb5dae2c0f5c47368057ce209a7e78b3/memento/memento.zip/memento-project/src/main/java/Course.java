package lms;

import java.util.ArrayList;
import java.util.List;

public class Course {
    private String name;
    private List<LessonModule> modules;
    
    public Course(String name) {
        this.name = name;
        this.modules = new ArrayList<>();
    }
    
    public void addModule(LessonModule module) {
        modules.add(module);
    }
    
    public Memento saveState() {
        return new Memento(name, new ArrayList<>(modules));
    }
    
    public void restoreState(Memento memento) {
        this.name = memento.getName();
        this.modules = new ArrayList<>(memento.getModules());
    }
    
    public String getName() {
        return name;
    }
    
    public List<LessonModule> getModules() {
        return modules;
    }
}