package com.lms.model;

import java.util.ArrayList;
import java.util.List;

public class Module implements Component {
    private String title;
    private List<Component> components;
    
    public Module(String title) {
        this.title = title;
        this.components = new ArrayList<>();
    }
    
    public void addComponent(Component component) {
        components.add(component);
    }
    
    public void removeComponent(Component component) {
        components.remove(component);
    }
    
    @Override
    public void display() {
        System.out.println("Module: " + title);
        for (Component component : components) {
            component.display();
        }
    }
    
    @Override
    public double getDuration() {
        return components.stream().mapToDouble(Component::getDuration).sum();
    }
    
    @Override
    public int getPoints() {
        return components.stream().mapToInt(Component::getPoints).sum();
    }
}