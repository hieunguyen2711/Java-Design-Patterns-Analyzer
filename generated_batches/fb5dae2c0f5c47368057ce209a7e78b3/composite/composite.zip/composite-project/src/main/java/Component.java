package com.lms.model;

public interface Component {
    void display();
    double getDuration();
    int getPoints();
}