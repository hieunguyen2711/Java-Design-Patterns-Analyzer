package com.lms.model;

public class Lesson implements Component {
    private String title;
    private double duration;
    private int points;
    
    public Lesson(String title, double duration, int points) {
        this.title = title;
        this.duration = duration;
        this.points = points;
    }
    
    @Override
    public void display() {
        System.out.println("  Lesson: " + title);
    }
    
    @Override
    public double getDuration() {
        return duration;
    }
    
    @Override
    public int getPoints() {
        return points;
    }
}