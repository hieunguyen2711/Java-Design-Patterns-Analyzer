package com.lms.model;

import java.util.ArrayList;
import java.util.List;

public class Course implements Component {
    private String title;
    private List<Component> modules;
    
    public Course(String title) {
        this.title = title;
        this.modules = new ArrayList<>();
    }
    
    public void addModule(Module module) {
        modules.add(module);
    }
    
    public void removeModule(Module module) {
        modules.remove(module);
    }
    
    @Override
    public void display() {
        System.out.println("Course: " + title);
        for (Component module : modules) {
            module.display();
        }
    }
    
    @