package com.lms.visitor;

public class Module implements Element {
    private String title;
    
    public Module(String title) {
        this.title = title;
    }
    
    @Override
    public void accept(Visitor visitor) {
        visitor.visit(this);
    }
    
    public String getTitle() {
        return title;
    }
}