package com.lms.visitor;

public class Course implements Element {
    private String name;
    
    public Course(String name) {
        this.name = name;
    }
    
    @Override
    public void accept(Visitor visitor) {
        visitor.visit(this);
    }
    
    public String getName() {
        return name;
    }
}