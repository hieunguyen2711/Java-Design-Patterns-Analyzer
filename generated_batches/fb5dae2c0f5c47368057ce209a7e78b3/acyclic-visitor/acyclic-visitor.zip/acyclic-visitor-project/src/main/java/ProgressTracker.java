package com.lms.visitor;

public class ProgressTracker implements Visitor {
    private int courseCount = 0;
    private int moduleCount = 0;
    private int assignmentCount = 0;
    private int submissionCount = 0;
    
    @Override
    public void visit(Course course) {
        courseCount++;
    }
    
    @Override
    public void visit(Module module) {
        moduleCount++;
    }
    
    @Override
    public void