package com.lms.visitor;

public class Submissions implements Element {
    private int count;
    
    public Submissions(int count) {
        this.count = count;
    }
    
    @Override
    public void accept(Visitor visitor) {
        visitor.visit(this);
    }
    
    public int getCount() {
        return count;
    }
}