package com.lms.visitor;

public class Assignment implements Element {
    private String description;
    
    public Assignment(String description) {
        this.description = description;
    }
    
    @Override
    public void accept(Visitor visitor) {
        visitor.visit(this);
    }
    
    public String getDescription() {
        return description;
    }
}