package com.lms.visitor;

public interface Visitor {
    void visit(Course course);
    void visit(Module module);
    void visit(Assignment assignment);
    void visit(Submissions submissions);
}