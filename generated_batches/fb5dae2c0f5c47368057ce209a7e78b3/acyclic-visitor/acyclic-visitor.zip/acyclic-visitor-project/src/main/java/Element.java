package com.lms.visitor;

public interface Element {
    void accept(Visitor visitor);
}