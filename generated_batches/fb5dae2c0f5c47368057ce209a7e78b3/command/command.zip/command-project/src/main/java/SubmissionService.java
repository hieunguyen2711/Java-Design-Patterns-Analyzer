package com.lms.service;

import com.lms.model.Assignment;

public class SubmissionService {
    public void submit(Assignment assignment) {
        System.out.println("Submitting assignment: " + assignment.getTitle());
    }
}