package com.lms.service;

import com.lms.model.Assignment;

public class GradeService {
    public void grade(Assignment assignment) {
        System.out.println("Grading assignment