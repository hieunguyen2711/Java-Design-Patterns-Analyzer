package com.lms.command;

public interface Command {
    void execute();
}