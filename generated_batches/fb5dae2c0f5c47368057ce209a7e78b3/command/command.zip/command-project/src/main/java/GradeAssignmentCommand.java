package com.lms.command;

import com.lms.model.Assignment;
import com.lms.service.GradeService;

public class GradeAssignmentCommand implements Command {
    private final Assignment assignment;
    private final GradeService gradeService;
    
    public GradeAssignmentCommand(Assignment assignment, GradeService gradeService) {
        this.assignment = assignment;
        this.gradeService = gradeService;
    }
    
    @Override
    public void execute() {
        gradeService.grade(assignment);
    }
}