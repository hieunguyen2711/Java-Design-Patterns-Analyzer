package com.lms.command;

import com.lms.model.Assignment;
import com.lms.service.SubmissionService;

public class SubmitAssignmentCommand implements Command {
    private final Assignment assignment;
    private final SubmissionService submissionService;
    
    public SubmitAssignmentCommand(Assignment assignment, SubmissionService submissionService) {
        this.assignment = assignment;
        this.submissionService = submissionService;
    }
    
    @Override
    public void execute() {
        submissionService.submit(assignment);
    }
}