package com.lms.model;

import java.util.List;
import java.util.function.Function;

public class Module {
    private String title;
    private List<Assignment> assignments;
    
    public Module(String title, List<Assignment> assignments) {
        this.title = title;
        this.assignments = assignments;
    }
    
    public String getTitle() {
        return title;
    }
    
    public List<Assignment> getAssignments() {
        return assignments;
    }
    
    // Function composition for calculating module progress
    public Function<List<Assignment>, Double> calculateModuleProgress = 
        assignments -> assignments.stream()
            .mapToDouble(Assignment::calculateProgress)
            .average()
            .orElse(0.0);
    
    public double calculateProgress() {
        return calculateModuleProgress.apply(assignments);
    }
}