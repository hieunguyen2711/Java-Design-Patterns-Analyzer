package com.lms.model;

import java.util.List;
import java.util.function.Function;

public class Course {
    private String title;
    private List<Module> modules;
    
    public Course(String title, List<Module> modules) {
        this.title = title;
        this.modules = modules;
    }
    
    public String getTitle() {
        return title;
    }
    
    public List<Module> getModules() {
        return modules;
    }
    
    // Function composition for calculating total course progress
    public Function<List<Module>, Double> calculateCourseProgress = 
        modules -> modules.stream()
            .mapToDouble(Module::calculateProgress)
            .average()
            .orElse(0.0);
}