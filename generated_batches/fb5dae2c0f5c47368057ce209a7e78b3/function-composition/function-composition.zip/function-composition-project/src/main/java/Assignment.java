package com.lms.model;

import java.util.List;
import java.util.function.Function;

public class Assignment {
    private String title;
    private List<Submission> submissions;
    
    public Assignment(String title, List<Submission> submissions) {
        this.title = title;
        this.submissions = submissions;
    }
    
    public String getTitle() {
        return title;
    }
    
    public List<Submission> getSubmissions() {
        return submissions;
    }
    
    // Function composition for calculating assignment progress
    public Function<List<Submission>, Double> calculateAssignmentProgress = 
        submissions -> submissions.stream()
            .mapToDouble(Submission::calculateProgress)
            .average()
            .orElse(0.0);
    
    public double calculateProgress() {
        return calculateAssignmentProgress.apply(submissions);
    }