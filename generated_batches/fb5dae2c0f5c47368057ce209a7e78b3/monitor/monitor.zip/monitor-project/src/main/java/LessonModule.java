package com.lms.model;

import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.List;
import java.util.ArrayList;

public class LessonModule {
    private final String moduleId;
    private volatile String moduleName;
    
    private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
    private final List<Assignment> assignments = new ArrayList<>();
    
    public LessonModule(String moduleId, String moduleName) {
        this.moduleId = moduleId;
        this.moduleName = moduleName;
    }
    
    public String getModuleId() {
        return moduleId;
    }
    
    public String getModuleName() {
        lock.readLock().lock();
        try {
            return moduleName;
        } finally {
            lock.readLock().unlock();
        }
    }
    
    public void setModuleName(String moduleName) {
        lock.writeLock().lock();
        try {
            this.moduleName = moduleName;
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    public List<Assignment> getAssignments() {
        lock.readLock().lock();