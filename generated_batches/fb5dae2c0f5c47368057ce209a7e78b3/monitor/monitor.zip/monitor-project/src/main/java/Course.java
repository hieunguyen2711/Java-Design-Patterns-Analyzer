package com.lms.model;

import java.util.concurrent.locks.ReentrantReadWriteLock;

public class Course {
    private final String courseId;
    private volatile String courseName;
    private volatile int totalLessons;
    
    private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
    
    public Course(String courseId, String courseName) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.totalLessons = 0;
    }
    
    public String getCourseId() {
        return courseId;
    }
    
    public String getCourseName() {
        lock.readLock().lock();
        try {
            return courseName;
        } finally {
            lock.readLock().unlock();
        }
    }
    
    public void setCourseName(String courseName) {
        lock.writeLock().lock();
        try {
            this.courseName = courseName;
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    public int getTotalLessons() {
        lock.readLock().lock();
        try {
            return totalLessons;
        } finally {
            lock.readLock().unlock();
        }
    }
    
    public void incrementLessons() {
        lock.writeLock().lock();
        try {
            this.totalLessons++;
        } finally {
            lock.writeLock().unlock();
        }
    }
}