public class CourseServiceProxy implements CourseService {
    private CourseService courseService;
    private int adminUserId = 1;
    
    public CourseServiceProxy(CourseService courseService) {
        this.courseService = courseService;
    }
    
    @Override
    public void enrollStudent(int studentId, int courseId) {
        System.out.println("Checking permissions for enrollment...");
        if (studentId == adminUserId) {
            throw new SecurityException("Admin cannot enroll in courses");
        }
        courseService.enrollStudent(studentId, courseId);
    }
    
    @Override
    public void dropStudent(int studentId, int courseId) {
        System.out.println("Checking permissions for dropping...");
        if (studentId == adminUserId) {
            throw new SecurityException("Admin cannot drop