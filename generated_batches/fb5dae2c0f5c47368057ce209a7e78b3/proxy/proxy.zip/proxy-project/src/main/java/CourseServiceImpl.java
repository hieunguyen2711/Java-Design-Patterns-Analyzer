import java.util.*;

public class CourseServiceImpl implements CourseService {
    private Map<Integer, Set<Integer>> enrollments = new HashMap<>();
    
    @Override
    public void enrollStudent(int studentId, int courseId) {
        enrollments.computeIfAbsent(courseId, k -> new HashSet<>()).add(studentId);
        System.out.println("Enrolled student " + studentId + " in course " + courseId);
    }
    
    @Override
    public void dropStudent(int studentId, int courseId) {
        if (enrollments.containsKey(courseId)) {
            enrollments.get(courseId).remove(Integer.valueOf(studentId));
            System.out.println("Dropped student " + studentId + " from course " + courseId);
        }
    }
    
    @Override
    public boolean isEnrolled(int studentId, int courseId) {
        return enrollments.containsKey(courseId) && 
               enrollments.get(courseId).contains(Integer.valueOf(studentId));
    }
}