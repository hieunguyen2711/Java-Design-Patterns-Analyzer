public interface CourseService {
    void enrollStudent(int studentId, int courseId);
    void dropStudent(int studentId, int courseId);
    boolean isEnrolled(int studentId, int courseId);
}