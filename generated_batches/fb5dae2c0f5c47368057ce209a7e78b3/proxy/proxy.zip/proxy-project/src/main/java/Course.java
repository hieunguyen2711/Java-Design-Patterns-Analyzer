public class Course {
    private String title;
    private int courseId;
    
    public Course(String title, int courseId) {
        this.title = title;
        this.courseId = courseId;
    }
    
    public String getTitle() {
        return title;
    }
    
    public int getCourseId() {
        return courseId;
    }
}