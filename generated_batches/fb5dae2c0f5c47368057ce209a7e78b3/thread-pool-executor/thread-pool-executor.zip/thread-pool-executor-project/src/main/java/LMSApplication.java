import java.util.concurrent.Future;

public class LMSApplication {