import java.util.concurrent.*;

public class AssignmentGradingService {
    private final ThreadPoolExecutor threadPool;
    
    public AssignmentGradingService() {
        this.threadPool = new ThreadPoolExecutor(2, 4);
    }
    
    public Future<GradeResult> gradeAssignmentAsync(Assignment assignment) {
        return threadPool.submitTask(() -> {
            // Simulate grading work
            Thread.sleep(1000);
            double score = Math.random() * 100;
            return new GradeResult(assignment.getId(), score, "Graded");
        });
    }
    
    public void shutdown() {
        threadPool.shutdown();
    }
}