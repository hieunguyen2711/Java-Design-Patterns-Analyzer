public class GradeResult {
    private final String assignmentId;
    private final double score;
    private final String status;
    
    public GradeResult(String assignmentId, double score, String status) {
        this.assignmentId = assignmentId;
        this.score = score;
        this.status = status;
    }
    
    public String getAssignmentId() {
        return assignmentId;
    }
    
    public double getScore() {
        return score;
    }
    
    public String getStatus() {
        return status;
    }
}