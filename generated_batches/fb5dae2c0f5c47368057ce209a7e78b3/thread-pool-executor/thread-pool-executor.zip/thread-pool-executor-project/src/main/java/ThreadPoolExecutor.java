import java.util.concurrent.*;

public class ThreadPoolExecutor {
    private final ExecutorService executor;
    
    public ThreadPoolExecutor(int corePoolSize, int maximumPoolSize) {
        this.executor = new ThreadPoolExecutor(
            corePoolSize,
            maximumPoolSize,
            60L, TimeUnit.SECONDS,
            new LinkedBlockingQueue<Runnable>()
        );
    }
    
    public void submitTask(Runnable task) {
        executor.submit(task);
    }
    
    public <T> Future<T> submitTask(Callable<T> task) {
        return executor.submit(task);
    }
    
    public void shutdown() {
        executor.shutdown();
    }
}