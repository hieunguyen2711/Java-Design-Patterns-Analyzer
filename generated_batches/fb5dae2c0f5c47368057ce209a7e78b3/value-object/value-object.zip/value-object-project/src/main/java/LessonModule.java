package com.lms.model;

public class LessonModule {
    private final String moduleId;
    private final String title;
    private final int durationMinutes;
    
    public LessonModule(String moduleId, String title, int durationMinutes) {
        this.moduleId = moduleId;
        this.title = title;
        this.durationMinutes = durationMinutes;
    }
    
    public String getModuleId() {
        return moduleId;
    }
    
    public String getTitle() {
        return title;
    }
    
    public int getDurationMinutes() {
        return durationMinutes;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        
        LessonModule that = (LessonModule) obj;
        return moduleId.equals(that.moduleId);
    }
    
    @Override
    public int hashCode() {
        return moduleId.hashCode();
    }
    
    @Override
    public String toString() {
        return "LessonModule{" +
                "moduleId='" + moduleId + '\'' +
                ", title='" + title + '\'' +
                ", durationMinutes=" + durationMinutes +
                '}';
    }
}