package com.lms.maybe;

import java.util.Optional;
import java.util.function.Function;

public class Maybe<T> {
    private final Optional<T> value;
    
    private Maybe(Optional<T> value) {
        this.value = value;
    }
    
    public static <T> Maybe<T> of(T value) {
        return new Maybe<>(Optional.ofNullable(value));
    }
    
    public static <T> Maybe<T> empty() {
        return new Maybe<>(Optional.empty());
    }
    
    public <R> Maybe<R> map(Function<? super T, ? extends R> mapper) {
        return new Maybe<>(value.map(mapper));
    }
    
    public <R> Maybe<R> flatMap(Function<? super T, Maybe<R>> mapper) {
        if (value.isPresent()) {
            return mapper.apply(value.get());
        } else {
            return Maybe.empty();
        }
    }
    
    public T orElse(T defaultValue) {
        return value.orElse(defaultValue);
    }
    
    public boolean isPresent() {
        return value.isPresent();
    }
}