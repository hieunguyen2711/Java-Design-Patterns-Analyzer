package com.lms.model;

import java.util.List;
import java.util.ArrayList;
import java.util.Optional;

public class Module {
    private final String id;
    private final String title;
    private final List<Assignment> assignments;
    
    public Module(String id, String title) {
        this.id = id;
        this.title = title;
        this.assignments = new ArrayList<>();
    }
    
    public void addAssignment(Assignment assignment) {
        assignments.add(assignment);
    }
    
    public