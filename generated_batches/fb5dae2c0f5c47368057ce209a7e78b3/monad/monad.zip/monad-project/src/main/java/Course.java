package com.lms.model;

import java.util.List;
import java.util.ArrayList;
import java.util.Optional;

public class Course {
    private final String id;
    private final String title;
    private final List<Module> modules;
    
    public Course(String id, String title) {
        this.id = id;
        this.title = title;
        this.modules = new ArrayList<>();
    }
    
    public void addModule(Module module) {
        modules.add(module);
    }
    
    public Optional<Module> findModuleById(String moduleId) {
        return modules.stream()
                .filter(m -> m.getId().equals(moduleId))
                .findFirst();
    }
    
    public String getId() {
        return id;
    }
    
    public String getTitle() {
        return title;
    }
}