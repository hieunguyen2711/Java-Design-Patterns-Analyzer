public class Main {
    public static void main(String[] args) {
        CourseService service = new CourseService();
        
        service.saveCourse("Java Fundamentals");
        String course = service.getCourseById(123);
        System.out.println("Retrieved: " + course);
    }
}