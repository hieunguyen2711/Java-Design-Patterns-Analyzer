public class DatabaseConnection implements ResourceManager {
    private boolean isOpen = false;
    
    @Override
    public void acquire() {
        if (!isOpen) {
            System.out.println("Opening database connection...");
            isOpen = true;
        }
    }
    
    @Override
    public void release() {
        if (isOpen) {
            System.out.println("Closing database connection...");
            isOpen = false;
        }
    }
}