public interface ResourceManager {
    void acquire();
    void release();
}