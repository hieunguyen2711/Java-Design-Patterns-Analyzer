public class CourseService {
    private final LMSDatabaseManager dbManager = new LMSDatabaseManager();
    
    public void saveCourse(String courseName) {
        dbManager.executeWithResource(new DatabaseConnection(), () -> {
            System.out.println("Saving course: " + courseName);
            // Simulate database operation
            return null;
        });
    }
    
    public String getCourseById(int courseId) {
        return dbManager.executeWithResource(new DatabaseConnection(), () -> {
            System.out.println("Retrieving course with ID: " + courseId);
            return "Course-" + courseId;
        });
    }
}