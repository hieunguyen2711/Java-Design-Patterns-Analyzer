public class LMSDatabaseManager {
    
    public <T> T executeWithResource(ResourceManager resource, ResourceOperation<T> operation) {
        try {
            resource.acquire();
            return operation.execute();
        } finally {
            resource.release();
        }
    }
    
    @FunctionalInterface
    public interface ResourceOperation<T> {
        T execute() throws Exception;
    }
}