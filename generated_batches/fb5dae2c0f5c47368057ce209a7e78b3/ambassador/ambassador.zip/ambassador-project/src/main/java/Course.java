package com.lms.course;

import java.util.List;
import java.util.ArrayList;

public class Course {
    private String courseId;
    private String title;
    private List<LessonModule> modules;
    
    public Course(String courseId, String title) {
        this.courseId = courseId;
        this.title = title;
        this.modules = new ArrayList<>();
    }
    
    public void addModule(LessonModule module) {
        modules.add(module);
    }
    
    public List<LessonModule> getModules() {
        return modules;
    }
    
    public String getCourseId() {
        return courseId;
    }
    
    public String getTitle() {
        return title;
    }
}