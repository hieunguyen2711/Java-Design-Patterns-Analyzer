package com.lms.course;

import java.util.List;
import java.util.ArrayList;

public class LessonModule {
    private String moduleId;
    private String title;
    private List<Assignment> assignments;
    
    public LessonModule(String moduleId, String title) {
        this.moduleId = moduleId;
        this.title = title;
        this.assignments = new ArrayList<>();
    }
    
    public void addAssignment(Assignment assignment) {
        assignments.add(assignment);
    }
    
    public List<Assignment> getAssignments() {
        return assignments;
    }
    
    public String getModuleId() {
        return moduleId;
    }
    
    public String getTitle() {
        return title;
    }
}