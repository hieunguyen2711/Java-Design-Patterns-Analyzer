package com.lms.course;

public class Submission {
    private String submissionId;
    private String studentId;
    private String content;
    private Grade grade;
    
    public Submission(String submissionId, String studentId, String content)