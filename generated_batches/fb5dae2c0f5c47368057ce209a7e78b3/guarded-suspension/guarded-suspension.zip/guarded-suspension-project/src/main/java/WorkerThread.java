public class WorkerThread extends Thread {
    private final RequestQueue requestQueue;

    public WorkerThread(RequestQueue requestQueue) {
        this.requestQueue = requestQueue;
    }

    @Override
    public void run() {
        try {
            while (!Thread.currentThread().isInterrupted()) {
                Request request = requestQueue.take(); // Guarded suspension in action
                processRequest(request);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private void processRequest(Request request) {
        // Simulate processing
        try {
            Thread.sleep(100);
            System.out.println("Processed: " + request.getOperation());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}