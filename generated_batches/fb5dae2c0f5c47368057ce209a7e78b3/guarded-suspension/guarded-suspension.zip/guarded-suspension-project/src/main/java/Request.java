public class Request {
    private final String operation;
    private final Object data;

    public Request(String operation, Object data) {
        this.operation = operation;
        this.data = data;
    }

    public String getOperation() {
        return operation;
    }

    public Object getData() {
        return data;
    }
}