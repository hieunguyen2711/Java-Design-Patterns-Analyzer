public class Response {
    private final Object result;
    private final boolean success;

    public Response(Object result, boolean success) {
        this.result = result;
        this.success = success;
    }

    public Object getResult() {
        return result;
    }

    public boolean isSuccess() {
        return success;
    }
}