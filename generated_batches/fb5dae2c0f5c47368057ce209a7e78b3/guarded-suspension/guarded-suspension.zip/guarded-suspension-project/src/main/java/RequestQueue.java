import java.util.LinkedList;
import java.util.Queue;

public class RequestQueue {
    private final Queue<Request> queue = new LinkedList<>();
    private static final int MAX_QUEUE_SIZE = 100;

    public synchronized void add(Request request) throws InterruptedException {
        while (queue.size() >= MAX_QUEUE_SIZE) {
            wait(); // Guarded suspension - wait until space available
        }
        queue.offer(request);
        notifyAll();
    }

    public synchronized Request take() throws InterruptedException {
        while (queue.isEmpty()) {
            wait(); // Guarded suspension - wait until request available
        }
        Request request = queue.poll();
        notifyAll();
        return request;
    }
}