package com.lms.model;

public class Course {
    private String courseId;
    private String title;
    
    public Course(String courseId, String title) {
        this.courseId = courseId;
        this.title = title;
    }
    
    public String getCourseId() {
        return courseId;
    }
    
    public String getTitle() {
        return title;
    }
}