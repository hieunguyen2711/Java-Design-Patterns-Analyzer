package com.lms.model;

public class LessonModule {
    private String moduleId;
    private String title;
    private Course course;
    
    public LessonModule(String moduleId, String title, Course course) {
        this.moduleId = moduleId;
        this.title = title;
        this.course = course;
    }
    
    public String getModuleId() {
        return moduleId;
    }
    
    public String getTitle() {
        return title;
    }
    
    public Course getCourse() {
        return course;
    }
}