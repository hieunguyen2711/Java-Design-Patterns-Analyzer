package com.lms.model;

public class Assignment {
    private String assignmentId;
    private String title;
    private LessonModule module;
    
    public Assignment(String assignmentId, String title, LessonModule module) {
        this.assignmentId = assignmentId;
        this.title = title;
        this.module = module;
    }
    
    public String getAssignmentId() {
        return assignmentId;
    }
    
    public String getTitle() {
        return title;
    }
    
    public LessonModule getModule() {
        return module;
    }
}