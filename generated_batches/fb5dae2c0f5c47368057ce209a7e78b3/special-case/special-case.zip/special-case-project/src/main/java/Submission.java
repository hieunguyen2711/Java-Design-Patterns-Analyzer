package com.lms.model;

public class Submission {
    private String submissionId;
    private Assignment assignment;
    private String studentId;
    private String content;
    private double grade;
    private boolean graded;
    
    public Submission(String submissionId, Assignment assignment, String studentId, String content) {
        this.submissionId = submissionId;
        this.assignment = assignment;
        this.studentId = studentId;
        this.content = content;
        this.grade = 0.0;
        this.graded = false;
    }
    
    public String getSubmissionId() {
        return submissionId;
    }
    
    public Assignment getAssignment() {
        return assignment;
    }
    
    public String getStudentId() {
        return studentId;
    }
    
    public String getContent() {
        return content;
    }
    
    public double getGrade() {
        return grade