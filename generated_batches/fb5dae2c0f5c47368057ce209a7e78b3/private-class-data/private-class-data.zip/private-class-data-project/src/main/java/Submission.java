package com.lms.model;

import java.time.LocalDateTime;

public class Submission {
    private final String studentId;
    private final LocalDateTime submittedAt;
    private final String content;
    
    public Submission(String studentId, String content) {
        this.studentId = studentId