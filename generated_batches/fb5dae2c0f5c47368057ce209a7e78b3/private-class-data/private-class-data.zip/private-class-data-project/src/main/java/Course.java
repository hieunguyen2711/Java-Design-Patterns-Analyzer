package com.lms.model;

import java.util.ArrayList;
import java.util.List;

public class Course {
    private final String title;
    private final String code;
    private final List<LessonModule> modules;
    
    public Course(String title, String code) {
        this.title = title;
        this.code = code;
        this.modules = new ArrayList<>();
    }
    
    public void addModule(LessonModule module) {
        modules.add(module);
    }
    
    public String getTitle() {
        return title;
    }
    
    public String getCode() {
        return code;
    }
    
    public List<LessonModule> getModules() {
        return new ArrayList<>(modules); // Return defensive copy
    }
}