package com.lms.model;

import java.util.ArrayList;
import java.util.List;

public class Assignment {
    private final String title;
    private final String description;
    private final List<Submission> submissions;
    
    public Assignment(String title, String description) {
        this.title = title;
        this.description = description;
        this.submissions = new ArrayList<>();
    }
    
    public void addSubmission(Submission submission) {
        submissions.add(submission);
    }
    
    public String getTitle() {
        return title;
    }
    
    public String getDescription() {
        return description;
    }
    
    public List<Submission> getSubmissions() {
        return new ArrayList<>(submissions); // Return defensive copy
    }
}