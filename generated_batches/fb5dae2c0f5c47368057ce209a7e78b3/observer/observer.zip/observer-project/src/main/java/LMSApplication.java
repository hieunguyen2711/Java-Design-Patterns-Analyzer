package com.lms;

import com.lms.model.Course;
import com.lms.model.Student;
import com.lms.model.Instructor;

public class LMSApplication {
    public static void main(String[] args) {
        Course javaCourse = new Course("Java Programming");
        
        Student alice = new Student("Alice");
        Student bob = new Student("Bob");
        Instructor john = new Instructor("John Smith");
        
        javaCourse.addObserver(alice);
        javaCourse.addObserver(bob);