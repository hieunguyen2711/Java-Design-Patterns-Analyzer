package com.lms.model;

public class Student implements Observer {
    private String name;
    
    public Student(String name) {
        this.name = name;
    }
    
    @Override
    public void update(String message) {
        System.out.println("Student " + name + " notified: " + message);
    }
    
    public String getName() {
        return name;
    }
}