package com.lms.model;

import java.util.ArrayList;
import java.util.List;

public class Course {
    private String title;
    private List<Observer> observers;
    
    public Course(String title) {
        this.title = title;
        this.observers = new ArrayList<>();
    }
    
    public void addObserver(Observer observer) {
        observers.add(observer);
    }
    
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }
    
    public void notifyObservers(String message) {
        for (Observer observer : observers) {
            observer.update(message);
        }
    }
    
    public void addLesson(String lessonTitle) {
        System.out.println("Adding lesson: " + lessonTitle);
        notifyObservers("New lesson added to course: " + title + " - " + lessonTitle);
    }
    
    public String getTitle() {
        return title;
    }
}