package com.lms.model;

public class Instructor implements Observer {
    private String name;
    
    public Instructor(String name) {
        this.name = name;
    }
    
    @Override
    public void update(String message) {
        System.out.println("Instructor " + name + " notified: " + message);
    }
    
    public String getName() {
        return name;
    }
}