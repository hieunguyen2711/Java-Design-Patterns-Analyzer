package com.lms.model;

public interface Observer {
    void update(String message);
}