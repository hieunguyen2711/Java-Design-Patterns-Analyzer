public class AssignmentServiceImpl implements AssignmentService {
    @Override
    public String getName() {
        return "Assignment