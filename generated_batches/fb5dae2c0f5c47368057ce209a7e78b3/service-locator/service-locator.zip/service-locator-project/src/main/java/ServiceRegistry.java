import java.util.HashMap;
import java.util.Map;

public class ServiceRegistry {
    private Map<String, Object> services;

    public ServiceRegistry() {
        services = new HashMap<>();
        initializeServices();
    }

    private void initializeServices() {
        services.put("CourseService", new CourseServiceImpl());
        services.put("AssignmentService", new AssignmentServiceImpl());
        services.put("GradingService", new GradingServiceImpl());
    }

    public Object getService(String serviceName) {
        return services.get(serviceName);
    }
}