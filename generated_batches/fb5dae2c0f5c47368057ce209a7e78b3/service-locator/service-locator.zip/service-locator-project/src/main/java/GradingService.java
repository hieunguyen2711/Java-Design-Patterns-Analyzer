public interface GradingService extends Service {
    void gradeSubmission(String submissionId, double score);
    double getGrade(String submissionId);
}