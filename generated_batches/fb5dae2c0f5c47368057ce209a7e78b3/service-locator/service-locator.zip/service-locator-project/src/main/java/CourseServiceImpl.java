public class CourseServiceImpl implements CourseService {
    @Override
    public String getName() {
        return "CourseService";
    }

    @Override
    public void enrollStudent(String studentId, String courseId) {
        System.out.println("Enrolling student " + studentId + " in course " + courseId);
    }

    @Override
    public void dropCourse(String studentId, String courseId) {
        System.out.println("Dropping student " + studentId + " from course " + courseId);
    }
}