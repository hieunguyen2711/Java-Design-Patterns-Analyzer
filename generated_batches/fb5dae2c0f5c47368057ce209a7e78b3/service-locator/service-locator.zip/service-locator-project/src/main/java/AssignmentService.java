public interface AssignmentService extends Service {
    void submitAssignment(String studentId, String assignmentId, String submissionData);
    void updateSubmissionStatus(String submissionId, String status);
}