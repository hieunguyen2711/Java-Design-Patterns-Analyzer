public interface CourseService extends Service {
    void enrollStudent(String studentId, String courseId);
    void dropCourse(String studentId, String courseId);
}