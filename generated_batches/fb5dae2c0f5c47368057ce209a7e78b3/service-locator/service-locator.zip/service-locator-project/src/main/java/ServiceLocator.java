public class ServiceLocator {
    private static ServiceLocator instance;
    private ServiceRegistry registry;

    private ServiceLocator() {
        registry = new ServiceRegistry();
    }

    public static synchronized ServiceLocator getInstance() {
        if (instance == null) {
            instance = new ServiceLocator();
        }
        return instance;
    }

    public Object getService(String serviceName) {
        return registry.getService(serviceName);
    }
}