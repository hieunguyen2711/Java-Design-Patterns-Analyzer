package com.lms.course;

public class CourseService {
    public static void main(String[] args) {
        // Create base course
        Course basicCourse = new Course("Java Fundamentals", 
            "Learn the basics of Java programming");
        
        System.out.println("Base Course:");
        System.out.println("Title: " + basicCourse.getTitle());
        System.out.println("Description: " + basicCourse.getDescription());
        
        // Decorate with advanced level
        Course advancedCourse = new AdvancedCourseDecorator(basicCourse);
        System.out.println("\n