package com.lms.course;

public class AdvancedCourseDecorator extends CourseDecorator {
    private String level;
    
    public AdvancedCourseDecorator(Course course) {
        super(course);
        this.level = "Advanced";
    }
    
    @Override
    public String getTitle() {
        return "[ADVANCED] " + course.getTitle();
    }
    
    @Override
    public String getDescription() {
        return course.getDescription() + " - This is an advanced level course.";
    }
}