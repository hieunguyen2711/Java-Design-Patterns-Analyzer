package com.lms.course;

public abstract class CourseDecorator implements Course {
    protected Course course;
    
    public CourseDecorator(Course course) {
        this.course = course;
    }
    
    @Override
    public String getTitle() {
        return course.getTitle();
    }
    
    @Override
    public String getDescription() {
        return course.getDescription();
    }
}