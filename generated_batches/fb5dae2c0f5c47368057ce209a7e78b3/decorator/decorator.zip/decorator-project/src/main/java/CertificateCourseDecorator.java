package com.lms.course;

public class CertificateCourseDecorator extends CourseDecorator {
    private boolean hasCertificate;
    
    public CertificateCourseDecorator(Course course) {
        super(course);
        this.hasCertificate = true;
    }
    
    @Override
    public String getTitle() {
        return course.getTitle() + " [CERTIFICATE]";
    }
    
    @Override
    public String getDescription() {
        return course.getDescription() + " - Earn a certificate upon completion.";
    }
}