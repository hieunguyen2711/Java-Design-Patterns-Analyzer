package com.lms.dao;

import com.lms.model.Course;
import java.util.List;

public interface CourseDAO {
    List<Course> getAllCourses();
    Course getCourseById(int id);
    void saveCourse(Course course);
    void updateCourse(Course course);
    void deleteCourse(int id);
}