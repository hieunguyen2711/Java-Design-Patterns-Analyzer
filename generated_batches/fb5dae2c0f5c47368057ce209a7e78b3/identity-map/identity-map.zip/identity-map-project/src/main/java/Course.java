package com.lms.model;

import java.util.Objects;

public class Course {
    private final String courseId;
    private final String title;
    
    public Course(String courseId, String title) {
        this.courseId = courseId;
        this.title = title;
    }
    
    public String getCourseId() {
        return courseId;
    }
    
    public String getTitle() {
        return title;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Course course = (Course) o;
        return Objects.equals(courseId, course.courseId);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(courseId);
    }
}