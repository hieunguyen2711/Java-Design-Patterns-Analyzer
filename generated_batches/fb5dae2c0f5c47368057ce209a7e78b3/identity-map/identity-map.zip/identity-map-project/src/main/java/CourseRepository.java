package com.lms.repository;

import com.lms.model.Course;
import com.lms.util.IdentityMap;

public class CourseRepository {
    private final IdentityMap<Course> courseIdentityMap = new IdentityMap<>();
    
    public Course findCourseById(String courseId) {
        // Check if we already have this course in our identity map
        for (Course existingCourse : courseIdentityMap.map.values()) {
            if (existingCourse.getCourseId().equals(courseId)) {
                return existingCourse;
            }
        }
        
        // If not found, create new course and store it
        Course newCourse = new Course(courseId, "Course Title: " + courseId);
        courseIdentityMap.put(courseId, newCourse);
        return newCourse;
    }
    
    public void clearCache() {
        courseIdentityMap.map.clear();
    }
}