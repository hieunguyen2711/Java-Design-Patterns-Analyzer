package com.lms;

import com.lms.model.Course;
import com.lms.repository.CourseRepository;

public class LMSApplication {
    public static void