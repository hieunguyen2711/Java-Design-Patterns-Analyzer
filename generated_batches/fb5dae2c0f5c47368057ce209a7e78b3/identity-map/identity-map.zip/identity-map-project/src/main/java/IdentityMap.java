package com.lms.util;

import com.lms.model.Course;
import java.util.HashMap;
import java.util.Map;

public class IdentityMap<T> {
    private final Map<Object, T> map = new HashMap<>();
    
    public T get(Object key) {
        return map.get(key);
    }
    
    public T put(Object key, T value) {
        return map.put(key, value);
    }
    
    public boolean containsKey(Object key) {
        return map.containsKey(key);
    }
}