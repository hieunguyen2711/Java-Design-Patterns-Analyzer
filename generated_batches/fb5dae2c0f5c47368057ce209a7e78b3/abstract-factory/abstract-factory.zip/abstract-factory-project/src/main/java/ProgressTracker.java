public class ProgressTracker {
    private String studentId;
    private int completedLessons;
    private int totalLessons;
    
    public ProgressTracker(String studentId, int completedLessons, int totalLessons) {
        this.studentId = studentId;
        this.completedLessons = completed