public class Grading {
    private String studentId;
    private double score;
    private String feedback;
    
    public Grading(String studentId, double score, String feedback) {
        this.studentId = studentId;
        this.score = score;
        this.feedback = feedback;
    }
    
    public String getStudentId() {
        return studentId;
    }
    
    public double getScore() {
        return score;
    }
    
    public String getFeedback() {
        return feedback;
    }
}