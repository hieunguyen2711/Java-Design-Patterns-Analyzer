package com.lms.view;

import com.lms.model.Course;
import java.util.List;

public interface CourseView {
    void displayCourses(List<Course> courses);
    void showCourseDetails(Course course);
    void showMessage(String message);
    String getCourseIdInput();
}