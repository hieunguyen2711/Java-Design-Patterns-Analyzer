package com.lms.presenter;

import com.lms.model.Course;
import com.lms.service.CourseService;
import com.lms.view.CourseView;
import java.util.List;

public class CoursePresenter {
    private CourseService courseService;
    private CourseView view;
    
    public CoursePresenter(CourseService courseService, CourseView view) {
        this.courseService = courseService;
        this.view = view;
    }
    
    public void loadCourses() {
        List<Course> courses = courseService.getAllCourses();
        view.displayCourses(courses);
    }
    
    public void showCourseDetails(String courseId) {
        Course course = courseService.getCourseById(courseId);
        if (course != null) {
            view.showCourseDetails(course);
        } else {
            view.showMessage("Course not found");
        }
    }
    
    public void addNewCourse() {
        String courseId = view.getCourseIdInput();
        // In a real implementation, we would get more details from the view
        Course newCourse = new Course(courseId, "New Course", "Description");
        courseService.addCourse(newCourse);
        loadCourses(); // Refresh the list
    }
}