public class LMSApplication {
    public static void main(String[] args) {
        BusinessDelegate delegate = new BusinessDelegate();
        Client client = new Client(delegate);
        
        client.doCourseWork();
        client.doAssignmentWork();
    }
}