public class BusinessDelegate {
    private CourseService courseService;
    private AssignmentService assignmentService;
    
    public void handleCourseRequest(String request) {
        courseService = new CourseService();
        courseService.doProcessing(request);
    }
    
    public void handleAssignmentRequest(String request) {
        assignmentService = new AssignmentService();
        assignmentService.doProcessing(request);
    }
}