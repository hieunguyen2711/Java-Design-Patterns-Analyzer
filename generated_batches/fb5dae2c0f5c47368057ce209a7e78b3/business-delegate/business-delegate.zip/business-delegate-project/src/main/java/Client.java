public class Client {
    private BusinessDelegate businessDelegate;
    
    public Client(BusinessDelegate businessDelegate) {
        this.businessDelegate = businessDelegate;
    }
    
    public void doCourseWork() {
        businessDelegate.handleCourseRequest("View course details");
    }
    
    public void doAssignmentWork() {
        businessDelegate.handleAssignmentRequest("Submit assignment");
    }
}