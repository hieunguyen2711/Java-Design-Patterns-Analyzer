public class CourseService {
    public void doProcessing(String request) {
        System.out.println("Processing course request: " + request);
    }
}