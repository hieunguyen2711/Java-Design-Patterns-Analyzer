public class AssignmentService {
    public void doProcessing(String request) {
        System.out.println("Processing assignment request: " + request);
    }
}