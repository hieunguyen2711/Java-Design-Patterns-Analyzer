public class Main {
    public static void main(String[] args) {
        CourseService courseService = CourseServiceProxy.createCourseService();
        
        courseService.enrollStudent("student123", "course456");
        courseService.completeLesson("student123", "lesson789");
        double progress = courseService.getProgress("student123", "course456");
        
        System.out.println("Final progress: "