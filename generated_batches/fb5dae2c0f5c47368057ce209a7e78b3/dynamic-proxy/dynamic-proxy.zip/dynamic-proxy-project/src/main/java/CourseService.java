public interface CourseService {
    void enrollStudent(String studentId, String courseId);
    void completeLesson(String studentId, String lessonId);
    double getProgress(String studentId, String courseId);
}