import java.lang.reflect.Proxy;

public class CourseServiceProxy {
    
    public static CourseService createCourseService() {
        CourseService target = new CourseServiceImpl();
        return (CourseService) Proxy.newProxyInstance(
            CourseService.class.getClassLoader(),
            new Class[]{CourseService.class},
            new LoggingHandler(target)
        );
    }
}