public class CourseServiceImpl implements CourseService {
    
    @Override
    public void enrollStudent(String studentId, String courseId) {
        System.out.println("Enrolling student " + studentId + " in course " + courseId);
    }
    
    @Override
    public void completeLesson(String studentId, String lessonId) {
        System.out.println("Marking lesson " + lessonId + " as completed for student " + studentId);
    }
    
    @Override
    public double getProgress(String studentId, String courseId) {
        System.out.println("Calculating progress for student " + studentId + " in course " + courseId);
        return 75.0;
    }
}