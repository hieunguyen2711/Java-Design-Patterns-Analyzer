public class LMSFacade {
    private CourseService courseService;
    private AssignmentService assignmentService;
    private SubmissionService submissionService;
    
    public LMSFacade() {
        this.courseService = new CourseService