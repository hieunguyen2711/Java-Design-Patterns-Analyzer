public class CourseService {
    public void enrollStudent(String studentId, String courseId) {
        System.out.println("Enrolling student " + studentId + " in course " + courseId);
    }
    
    public void getCourseProgress(String studentId, String courseId) {
        System.out.println("Retrieving progress for student " + studentId + " in course " + courseId);
    }
}