public class SubmissionService {
    public void submitAssignment(String studentId, String assignmentId, String submissionContent) {
        System.out.println("Submitting assignment " + assignmentId + " by student " + studentId);
    }
    
    public void getSubmissionStatus(String studentId, String assignmentId) {
        System.out.println("Checking status for submission of assignment " + assignmentId + 
                          " by student " + studentId);
    }
}