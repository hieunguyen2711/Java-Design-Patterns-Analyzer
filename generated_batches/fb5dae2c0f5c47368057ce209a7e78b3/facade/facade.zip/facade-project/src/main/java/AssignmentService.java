public class AssignmentService {
    public void createAssignment(String assignmentId, String title) {
        System.out.println("Creating assignment " + assignmentId + ": " + title);
    }
    
    public void getAssignmentDetails(String assignmentId) {
        System.out.println("Retrieving details for assignment " + assignmentId);
    }
}