public class LearningManagementSystem {
    private CourseService courseService;
    private AssignmentService assignmentService;
    private SubmissionService submissionService;
    
    public LearningManagementSystem() {
        this.courseService = new CourseService();
        this.assignmentService = new AssignmentService();
        this.submissionService = new SubmissionService();
    }
    
    public void enrollStudentInCourse(String studentId, String courseId) {
        courseService.enrollStudent(studentId, courseId);
    }
    
    public void submitAssignment(String studentId, String assignmentId, String submissionContent) {
        assignmentService.createAssignment(assignmentId, "Sample Assignment");
        submissionService.submitAssignment(studentId, assignmentId, submissionContent);
    }
    
    public void getCourseProgress(String studentId, String courseId) {
        courseService.getCourseProgress(studentId, courseId);
    }
}