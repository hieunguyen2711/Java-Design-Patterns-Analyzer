package library;

import java.time.LocalDate;
import java.util.concurrent.TimeUnit;

public class Book {
    private String title;
    private String author;
    private boolean isBorrowed;
    private LocalDate borrowDate;
    private Member borrower;
    private double lateFeePerDay;
    
    public Book(String title, String author) {
        this.title = title;
        this.author = author;
        this.isBorrowed = false;
        this.lateFeePerDay = 0.50;
    }
    
    public void borrow() {
        isBorrowed = true;
        borrowDate = LocalDate.now();
    }
    
    public void