public class Library {
    private static Library instance;
    private String name;
    private int totalBooks;
    private int totalMembers;
    
    // Private constructor to prevent instantiation
    private Library() {
        this.name = "Central Public Library";
        this.totalBooks = 0;
        this.totalMembers = 0;
    }
    
    // Static method to get the single instance
    public static synchronized Library getInstance() {
        if (instance == null) {
            instance = new Library();
        }
        return instance;
    }
    
    // Getters and setters for shared state
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public int getTotalBooks() {
        return totalBooks;
    }
    
    public void setTotalBooks(int totalBooks) {
        this.totalBooks = totalBooks;
    }
    
    public int getTotalMembers() {
        return totalMembers;
    }
    
    public void setTotalMembers(int totalMembers) {
        this.totalMembers = totalMembers;
    }
}