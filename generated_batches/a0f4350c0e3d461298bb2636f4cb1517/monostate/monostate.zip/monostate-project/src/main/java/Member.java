public class Member {
    private String name;
    private int memberId;
    private int booksBorrowed;
    
    public Member(String name, int memberId) {
        this.name = name;
        this.memberId = memberId;
        this.booksBorrowed = 0;
    }
    
    // Getters and setters
    public String getName() {