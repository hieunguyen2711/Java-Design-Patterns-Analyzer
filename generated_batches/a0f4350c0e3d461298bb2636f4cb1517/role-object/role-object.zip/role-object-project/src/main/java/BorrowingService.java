public class BorrowingService {
    private Book book;
    private Member member;
    
    public void borrowBook(Book book, Member member) {
        this.book = book;
        this.member = member;
        
        // Role-object pattern: the service object (BorrowingService)
        // takes on the role of managing the borrowing relationship
        System.out.println(member.getName() + " borrowed " + book.getTitle());
    }
    
    public Book getBook() {
        return book;
    }
    
    public Member getMember() {
        return member;
    }
}