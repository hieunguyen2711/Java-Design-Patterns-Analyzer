public class LibrarySystem {
    public static void main(String[] args) {
        Book book1 = new Book("1234567890", "Java Programming");
        Book book2 = new Book("0987654321", "Design Patterns");
        
        Member member1 = new Member("John Doe", "JD001");
        Member member2 = new Member("Jane Smith", "JS002");
        
        BorrowingService borrowingService = new BorrowingService();
        
        borrowingService.borrowBook(book1, member1);
        borrowingService.borrowBook(book2, member2);
        
        System.out.println("Books borrowed:");
        System.out.println(member1.getName() + " has: " + book1.getTitle());
        System.out.println(member2.getName() + " has: " + book2.getTitle());
    }
}