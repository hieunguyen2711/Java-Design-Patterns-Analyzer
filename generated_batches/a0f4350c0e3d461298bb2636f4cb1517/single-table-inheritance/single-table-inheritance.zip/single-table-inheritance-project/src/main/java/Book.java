package library;

public class Book extends LibraryItem {
    private String author;
    
    public Book(String title, String isbn, String author) {
        super(title, isbn);
        this.author = author;
    }
    
    @Override
    public double calculateLateFee(int daysOverdue) {
        return daysOverdue * 0.50; // $0.50 per day
    }
    
    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }
}