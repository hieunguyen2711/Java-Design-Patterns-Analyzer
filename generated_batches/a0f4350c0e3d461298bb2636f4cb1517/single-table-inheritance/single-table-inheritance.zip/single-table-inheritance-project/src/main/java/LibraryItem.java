package library;

public abstract class LibraryItem {
    protected String title;
    protected String isbn;
    protected boolean isAvailable;
    
    public LibraryItem(String title, String isbn) {
        this.title = title;
        this.isbn = isbn;
        this.isAvailable = true;
    }
    
    public abstract double calculateLateFee(int daysOverdue);
    
    // Getters and setters
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }
    public boolean isAvailable() { return isAvailable; }
    public void setAvailable(boolean available) { isAvailable = available; }
}