package library;

public class Magazine extends LibraryItem {
    private int issueNumber;
    
    public Magazine(String title, String isbn, int issueNumber) {
        super(title, isbn);
        this.issueNumber = issueNumber;
    }
    
    @Override
    public double calculateLateFee(int daysOverdue) {
        return daysOverdue * 0.25; // $0.25 per day
    }
    
    public int getIssueNumber() { return issueNumber; }
    public void setIssueNumber(int issueNumber) { this.issueNumber = issueNumber; }
}