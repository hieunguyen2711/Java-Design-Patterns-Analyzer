package library;

public class DVD extends LibraryItem {
    private String director;
    
    public DVD(String title, String isbn, String director) {
        super(title, isbn);
        this.director = director;
    }
    
    @Override
    public double calculateLateFee(int daysOverdue) {
        return daysOverdue * 1.00; // $1