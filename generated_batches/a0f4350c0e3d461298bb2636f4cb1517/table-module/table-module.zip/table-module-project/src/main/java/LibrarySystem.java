public class LibrarySystem {
    public static void main(String[] args) {
        // Create the table module with different book types
        TableModule<Book> bookTable = new TableModule<>();
        
        // Add books to the system
        Book book1 = new Book("1234567890", "Java Programming", "John Doe");
        Book book2 = new Book("0987654321", "Design Patterns", "Gang of Four");
        
        bookTable.add(book1);
        bookTable.add(book2);
        
        // Display all books
        System.out.println("All Books:");
        for (Book book : bookTable.getAll()) {
            System.out.println("- " + book.getTitle() + " by " + book.getAuthor());
        }
    }
}