import java.util.*;

public class TableModule<T> {
    private List<T> items;
    
    public TableModule() {
        this.items = new ArrayList<>();
    }
    
    public void add(T item) {
        items.add(item);
    }
    
    public List<T> getAll() {
        return new ArrayList<>(items);
    }
    
    public T get(int index) {
        return items.get(index);
    }
    
    public int size() {
        return items.size();
    }
}