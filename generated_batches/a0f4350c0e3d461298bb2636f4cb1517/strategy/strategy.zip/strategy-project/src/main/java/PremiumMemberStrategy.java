public class PremiumMemberStrategy implements BorrowingStrategy {
    @Override
    public int calculateBorrowingPeriod() {
        return 21; // 3 weeks for premium members
    }
    
    @Override
    public double calculateLateFee(int daysOverdue) {
        return daysOverdue * 0.25; // $0.25 per day late
    }
}