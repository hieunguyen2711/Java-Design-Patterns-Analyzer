public interface BorrowingStrategy {
    int calculateBorrowingPeriod();
    double calculateLateFee(int daysOverdue);
}