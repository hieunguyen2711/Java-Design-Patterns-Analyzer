public class RegularMemberStrategy implements BorrowingStrategy {
    @Override
    public int calculateBorrowingPeriod() {
        return 14; // 2 weeks for regular members
    }
    
    @Override
    public double calculateLateFee(int daysOverdue) {
        return daysOverdue * 0.50; // $0.50 per day late
    }
}