package library;

public class Book {
    private String title;
    private String author;
    private String isbn;
    private boolean isAvailable;
    
    public Book(String title, String author, String isbn) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.isAvailable = true;
    }
    
    public Book setTitle(String title) {
        this.title = title;
        return this;
    }
    
    public Book setAuthor(String author) {
        this.author = author;
        return this;
    }
    
    public Book setIsbn(String isbn) {
        this.isbn = isbn;
        return this;
    }
    
    public Book setAvailable(boolean available) {
        isAvailable = available;
        return this;
    }
    
    // Getters
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public String getIsbn() { return isbn; }
    public boolean isAvailable() { return isAvailable; }
}