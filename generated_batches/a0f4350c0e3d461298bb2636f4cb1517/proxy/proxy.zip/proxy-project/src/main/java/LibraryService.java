public interface LibraryService {
    void borrowBook(String memberId, String isbn);
    void returnBook(String memberId, String isbn);
    boolean isBookAvailable(String isbn);
}