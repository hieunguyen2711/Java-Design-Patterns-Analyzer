import java.util.*;

public class RealLibraryService implements LibraryService {
    private Map<String, Book> books;
    private Map<String, List<String>> memberBorrowedBooks;
    
    public RealLibraryService() {
        this.books = new HashMap<>();
        this.memberBorrowedBooks = new HashMap<>();
        initializeBooks();
    }
    
    private void initializeBooks() {
        books.put("978-0-123456-78-9", new Book("978-0-123456-78-9", "Effective Java", "Joshua Bloch"));
        books.put("978-0-987654-32-1", new Book("978-0-987654-32-1", "Clean Code", "Robert Martin"));
    }
    
    @Override
    public void borrowBook(String memberId, String isbn) {
        if (isBookAvailable(isbn)) {
            memberBorrowedBooks.computeIfAbsent(memberId, k -> new ArrayList<>()).add(isbn);
            System.out.println("Book borrowed successfully by member: " + memberId);
        } else {
            System.out.println("Book is not available for borrowing");
        }
    }
    
    @Override
    public void returnBook(String memberId, String isbn) {
        if (memberBorrowedBooks.containsKey(memberId)) {
            memberBorrowedBooks.get(memberId).remove(isbn);
            System.out.println("Book returned successfully by member: " + memberId);
        }
    }
    
    @Override
    public boolean isBookAvailable(String isbn) {
        return