public class BookBorrowedEvent extends LibraryEvent {
    private String bookId;
    private String memberId;
    private long dueDate;
    
    public BookBorrowedEvent(String eventId, String bookId, String memberId, long dueDate) {
        super(eventId);
        this.bookId = bookId;
        this.memberId = memberId;
        this.dueDate = dueDate;
    }
    
    public String getBookId() {
        return bookId;
    }
    
    public String getMemberId() {
        return memberId;
    }
    
    public long getDueDate() {
        return dueDate;
    }
    
    @Override
    public String getType() {
        return "BOOK_BORROWED";
    }
}