import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class LibraryEventStore {
    private final Map<String, List<LibraryEvent>> eventsByBook = new ConcurrentHashMap<>();
    
    public void save(LibraryEvent event) {
        eventsByBook.computeIfAbsent(event.getEventId(), k -> new ArrayList<>()).add(event);
    }
    
    public List<LibraryEvent> getEventsForBook(String bookId)