public abstract class LibraryEvent {
    protected String eventId;
    protected long timestamp;
    
    public LibraryEvent(String eventId) {
        this.eventId = eventId;
        this.timestamp = System.currentTimeMillis();
    }
    
    public String getEventId() {
        return eventId;
    }
    
    public long getTimestamp() {
        return timestamp;
    }
    
    public abstract String getType();
}