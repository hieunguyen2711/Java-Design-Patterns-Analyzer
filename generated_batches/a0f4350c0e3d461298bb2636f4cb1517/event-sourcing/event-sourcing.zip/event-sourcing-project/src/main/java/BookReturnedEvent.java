public class BookReturnedEvent extends LibraryEvent {
    private String bookId;
    private String memberId;
    private long returnDate;
    
    public BookReturnedEvent(String eventId, String bookId, String memberId, long returnDate) {
        super(eventId);
        this.bookId = bookId;
        this.memberId = memberId;
        this.returnDate = returnDate;
    }
    
    public String getBookId() {
        return bookId;
    }
    
    public String getMemberId() {
        return memberId;
    }
    
    public long getReturnDate() {
        return returnDate;
    }
    
    @Override
    public String getType() {
        return "BOOK_RETURNED";
    }
}