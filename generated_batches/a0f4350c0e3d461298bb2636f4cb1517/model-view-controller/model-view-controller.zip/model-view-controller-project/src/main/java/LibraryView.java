import java.util.List;

public class LibraryView {
    
    public void displayBooks(List<Book> books) {
        System.out.println("=== Books ===");