public class LibrarySystem {
    public static void main(String[] args) {
        // Create model
        LibraryModel model = new LibraryModel();
        
        // Create view
        LibraryView view = new LibraryView();
        
        // Create controller
        LibraryController controller = new LibraryController(model, view);
        
        // Initialize with sample data
        controller.addBook("1984", "George Orwell");
        controller.addMember("John Doe");
        controller.borrowBook("1984", "John Doe");
        
        // Display current state
        controller.displayLibraryStatus();
    }
}