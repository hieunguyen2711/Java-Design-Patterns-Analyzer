public class LibrarySystem {
    public static void main(String[] args) {
        // Demonstrating double-checked locking pattern with singleton
        Library library1 = Library.getInstance();
        Library library2 = Library.getInstance();
        
        System.out.println("Same instance: " + (library1 == library2));
        
        library1.manageBooks();
    }
}