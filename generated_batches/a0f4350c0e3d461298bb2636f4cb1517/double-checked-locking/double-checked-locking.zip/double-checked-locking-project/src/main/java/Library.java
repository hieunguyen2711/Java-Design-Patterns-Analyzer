public class Library {
    private static volatile Library instance;
    
    private Library() {
        // Private constructor to prevent instantiation
    }
    
    public static Library getInstance() {
        if (instance == null) {
            synchronized (Library.class) {
                if (instance == null) {
                    instance = new Library();
                }
            }
        }
        return instance;
    }
    
    public void manageBooks() {
        System.out.println("Managing library books...");
    }
}