package library;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class LibrarySystem {
    private List<Book> books;
    private List<Member> members;
    private List<BorrowingRecord> borrowingRecords;
    
    public LibrarySystem() {
        this.books = new ArrayList<>();
        this.members = new ArrayList<>();
        this.borrowingRecords = new ArrayList<>();
    }
    
    public void addBook(Book book) {
        books.add(book);
    }
    
    public void registerMember(Member member) {
        members.add(member);
    }
    
    public void borrowBook(String isbn, String memberId) {
        Book book = books.stream()
                .filter(b -> b.getIsbn().