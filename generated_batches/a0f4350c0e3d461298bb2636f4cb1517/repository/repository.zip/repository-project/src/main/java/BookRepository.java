import java.util.*;

public interface BookRepository {
    Book save(Book book);
    Optional<Book> findById(String isbn);
    List<Book> findAll();
    void deleteById(String isbn);
    List<Book> findByAuthor(String author);
    List<Book> findAvailableBooks();
}