import java.util.*;

public interface MemberRepository {
    Member save(Member member);
    Optional<Member> findById(String memberId);
    List<Member> findAll();
    void deleteById(String memberId);
}