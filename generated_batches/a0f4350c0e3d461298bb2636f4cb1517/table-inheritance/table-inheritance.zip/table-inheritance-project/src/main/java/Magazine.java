package library;

public class Magazine extends LibraryItem {
    private String publisher;
    private int issueNumber;
    
    public Magazine(String title, String itemId, String publisher, int issueNumber) {
        super(title, itemId);
        this.publisher = publisher;
        this.issueNumber = issueNumber;
    }
    
    @Override
    public double calculateLateFee(int daysOverdue) {
        return daysOverdue * 1.00; // $1.00 per day for magazines
    }
    
    public String getPublisher() {
        return publisher;
    }
    
    public int getIssueNumber() {
        return issueNumber;
    }
}