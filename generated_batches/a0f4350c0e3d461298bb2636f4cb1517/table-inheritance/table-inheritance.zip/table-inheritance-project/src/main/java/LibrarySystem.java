package library;

import java.util.ArrayList;
import java.util.List;

public class LibrarySystem {
    private List<LibraryItem> items;
    
    public LibrarySystem() {
        this.items = new ArrayList<>();
    }
    
    public void addItem(LibraryItem item) {
        items.add(item);
    }
    
    public double calculateTotalLateFee(String itemId, int