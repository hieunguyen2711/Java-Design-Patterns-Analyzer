package library;

public class Book extends LibraryItem {
    private String author;
    private int pages;
    
    public Book(String title, String itemId, String author, int pages) {
        super(title, itemId);
        this.author = author;
        this.pages = pages;
    }
    
    @Override
    public double calculateLateFee(int daysOverdue) {
        return daysOverdue * 0.50; // $0.50 per day for books
    }
    
    public String getAuthor() {
        return author;
    }
    
    public int getPages() {
        return pages;
    }
}