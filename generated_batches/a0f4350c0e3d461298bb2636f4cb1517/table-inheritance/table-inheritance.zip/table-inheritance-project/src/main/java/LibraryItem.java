package library;

public abstract class LibraryItem {
    protected String title;
    protected String itemId;
    protected boolean isAvailable;
    
    public LibraryItem(String title, String itemId) {
        this.title = title;
        this.itemId = itemId;
        this.isAvailable = true;
    }
    
    public abstract double calculateLateFee(int daysOverdue);
    
    public String getTitle() {
        return title;
    }
    
    public String getItemId() {
        return itemId;
    }
    
    public boolean isAvailable() {
        return isAvailable;
    }
    
    public void setAvailable(boolean available) {
        isAvailable = available;
    }
}