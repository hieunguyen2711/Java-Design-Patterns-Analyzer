package library;

public class Book {
    private final String title;
    private final String author;
    private final String isbn;
    private final int publicationYear;
    
    private Book(Builder builder) {
        this.title = builder.title;
        this.author = builder.author;
        this.isbn = builder.isbn;
        this.publicationYear = builder.publicationYear;
    }
    
    public String getTitle() {
        return title;
    }
    
    public String getAuthor() {
        return author;
    }
    
    public String getIsbn() {
        return isbn;
    }
    
    public int getPublicationYear() {
        return publicationYear;
    }
    
    public static class Builder {
        private String title;
        private String author;
        private String isbn;
        private int publicationYear;
        
        public Builder setTitle(String title) {
            this.title = title;
            return this;
        }
        
        public Builder setAuthor(String author) {
            this.author = author;
            return this;
        }
        
        public Builder setIsbn(String isbn) {
            this.isbn = isbn;
            return this;
        }
        
        public Builder setPublicationYear(int publicationYear) {
            this.publicationYear = publicationYear;
            return this;
        }
        
        public Book build() {
            return new Book(this);
        }
    }
}