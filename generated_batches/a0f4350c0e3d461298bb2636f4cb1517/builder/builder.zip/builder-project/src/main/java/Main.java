package library;

public class Main {
    public static void main(String[] args) {
        Library library = new Library();
        
        Book book1 = new Book.Builder()
                .setTitle("The Great Gatsby")
                .setAuthor("F. Scott Fitzgerald")
                .setIsbn("978-0-7432-7356-5")
                .setPublicationYear(1925)
                .build();
        
        Book book2 = new Book.Builder()
                .setTitle("To Kill a Mockingbird")
                .setAuthor("Harper Lee")
                .setIsbn("9