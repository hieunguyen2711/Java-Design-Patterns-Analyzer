package library;

import java.util.*;

public class LibrarySystem {
    private List<Book> books;
    private Map<String, Book> bookMap;
    
    // Double buffering - two views of the data
    private volatile List<Book> currentBooks;
    private volatile List<Book> nextBooks;
    
    public LibrarySystem() {
        this.books = new ArrayList<>();
        this.bookMap = new HashMap<>();
        this.currentBooks = books;
        this.nextBooks = new ArrayList<>();
    }
    
    // Add book using double buffering
    public void addBook(Book book) {
        synchronized (this) {
            nextBooks.add(book);
            bookMap.put(book.getIsbn(), book);
        }
    }
    
    // Commit changes - switch buffers
    public void commitChanges() {
        synchronized (this) {
            currentBooks = new ArrayList<>(nextBooks);
            books = currentBooks;
        }
    }
    
    // Get current view of books
    public List<Book> getBooks() {
        return new ArrayList<>(currentBooks);
    }
    
    // Find book by ISBN
    public Book findBook(String isbn) {
        return bookMap.get(isbn);
    }
}