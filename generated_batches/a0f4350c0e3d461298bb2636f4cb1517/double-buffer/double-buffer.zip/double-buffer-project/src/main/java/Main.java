package library;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        LibrarySystem library = new LibrarySystem();
        
        // Add books to the system
        library.addBook(new Book("978-0134685991", "Effective Java", "Joshua Bloch"));
        library.addBook(new Book("978-020163361