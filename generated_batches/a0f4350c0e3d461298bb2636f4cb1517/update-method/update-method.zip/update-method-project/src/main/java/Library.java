import java.util.*;

public class Library {
    private List<Book> books;
    private List<Member> members;
    private Map<String, Date> borrowRecords;
    
    public Library() {
        this