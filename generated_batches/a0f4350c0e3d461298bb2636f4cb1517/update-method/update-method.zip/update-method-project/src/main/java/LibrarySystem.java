public class LibrarySystem {
    public static void main(String[] args) {
        Book book1 = new Book("1234567890", "Effective Java", "Joshua Bloch");
        Book book2 = new Book("0987654321", "Design Patterns", "Gang of Four");
        
        Member member1 = new Member("M001", "Alice Johnson");
        Member member2 = new Member("M002", "Bob Smith");
        
        Library library = new Library();
        library.addBook(book1);
        library.addBook(book2);
        library.registerMember(member1);
        library.registerMember(member2);
        
        // Borrow books
        library.borrowBook("1234567890", "M001");
        library.borrowBook("0987654321", "M002");
        
        // Update due dates and check late fees
        library.updateDueDates();
        library.checkLateFees();
    }
}