public class ConcreteBook implements LibraryItem {
    private Book book;
    private boolean available;
    
    public ConcreteBook(Book book) {
        this.book = book;
        this.available = true;
    }
    
    @Override
    public String getTitle() {
        return book.getTitle();
    }
    
    @Override
    public String getAuthor() {
        return book.getAuthor();
    }
    
    @Override
    public String getIsbn() {
        return book.getIsbn();
    }
    
    @Override
    public boolean isAvailable() {
        return available;
    }
    
    @Override
    public void borrow() {
        if (available) {
            available = false;
        } else {
            throw new IllegalStateException("Book is already borrowed");
        }
    }
    
    @Override
    public void returnItem() {
        available = true;
    }
}