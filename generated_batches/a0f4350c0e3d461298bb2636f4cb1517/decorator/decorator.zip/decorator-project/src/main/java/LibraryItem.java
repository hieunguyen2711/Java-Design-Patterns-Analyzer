public interface LibraryItem {
    String getTitle();
    String getAuthor();
    String getIsbn();
    boolean isAvailable();
    void borrow();
    void returnItem();
}