public abstract class BookDecorator implements LibraryItem {
    protected LibraryItem item;
    
    public BookDecorator(LibraryItem item) {
        this.item = item;
    }
    
    @Override
    public String getTitle() {
        return item.getTitle();
    }
    
    @Override
    public String getAuthor() {
        return item.getAuthor();
    }
    
    @Override
    public String getIsbn() {
        return item.getIsbn();
    }
    
    @Override
    public boolean isAvailable() {
        return item.isAvailable();
    }
    
    @Override
    public void borrow() {
        item.borrow();
    }
    
    @Override
    public void returnItem() {
        item.returnItem();
    }
}