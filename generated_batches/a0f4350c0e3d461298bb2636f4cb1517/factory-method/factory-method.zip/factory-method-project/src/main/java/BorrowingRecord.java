public class BorrowingRecord extends LibraryItem {
    private static final int REGULAR_BOOK_DAYS = 14;
    private static final int REFERENCE_BOOK_DAYS = 7;
    
    public BorrowingRecord(Book book, Member member) {
        super(book, member);
    }
    
    @Override
    protected java.time.LocalDate calculateDueDate() {
        int