package library;

import java.util.*;
import java.util.concurrent.*;

public class LibrarySystem {
    private final ExecutorService executor = Executors.newFixedThreadPool(10);
    private final Map<String, Book> books = new ConcurrentHashMap<>();
    private final Map<String, Member> members = new ConcurrentHashMap<>();
    private final List<EventHandler> eventHandlers = new CopyOnWriteArrayList<>();

    public void registerHandler(EventHandler handler) {
        eventHandlers.add(handler);
    }

    public void addBook(String isbn, String title, String author) {
        Book book = new Book(isbn, title, author);
        books.put(isbn, book);
        
        // React to book addition
        notifyEvent(new BookAddedEvent(book));
    }

    public void registerMember(String memberId, String name) {
        Member member = new Member(memberId, name);
        members.put(memberId, member);
        
        // React to member registration
        notifyEvent(new MemberRegisteredEvent(member));
    }

    public void borrowBook(String isbn, String memberId) {
        Book book = books.get(isbn);
        Member member = members.get(memberId);
        
        if (book != null && member != null && !book.isBorrowed()) {
            book.setBorrowed(true);
            book.setBorrower(memberId);
            book.setDueDate(new Date(System.currentTimeMillis() + 14 * 24 * 60 * 60 * 1000L)); // 14 days
            
            // React to borrowing
            notifyEvent(new BookBorrowedEvent(book, member));
        }
    }

    public void returnBook(String isbn) {
        Book book = books.get(isbn);
        if (book != null && book.isBorrowed()) {
            String borrowerId = book.getBorrower();
            Member borrower = members.get(borrowerId);
            
            book.setBorrowed(false);
            book.setBorrower(null);
            book.setDueDate(null);
            
            // React to return
            notifyEvent(new BookReturnedEvent(book, borrower));
        }
    }

    private void notifyEvent(LibraryEvent event) {
        for (EventHandler handler : eventHandlers) {
            executor.submit(() -> handler.handle(event));
        }
    }

    public static void main(String[] args) {
        LibrarySystem library = new LibrarySystem();
        
        // Register event handlers
        library.registerHandler(new LoggingEventHandler());
        library.registerHandler(new NotificationEventHandler