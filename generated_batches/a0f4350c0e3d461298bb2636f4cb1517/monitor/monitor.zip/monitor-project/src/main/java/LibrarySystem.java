public class LibrarySystem {
    private final BookManager bookManager;
    private final MemberManager memberManager;
    
    public LibrarySystem() {
        this.bookManager = new BookManager();
        this.memberManager = new MemberManager();
    }
    
    public void borrowBook(String memberId, String isbn) throws Exception {
        memberManager.borrowBook(memberId, isbn);
    }
    
    public void returnBook(String memberId, String isbn) throws Exception {
        memberManager.returnBook(memberId, isbn);
    }
    
    public static void main(String[] args) {
        LibrarySystem library = new LibrarySystem();
        
        try {
            library.borrowBook("M001", "978-0-123456-78-9");
            library.borrowBook("M002", "978-0-123456-78-9");
            library.returnBook("M001", "978-0-123456-78-9");
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}