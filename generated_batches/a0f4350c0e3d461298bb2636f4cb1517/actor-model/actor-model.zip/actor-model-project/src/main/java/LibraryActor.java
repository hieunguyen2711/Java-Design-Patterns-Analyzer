import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LibraryActor {
    private final ExecutorService executor = Executors.newFixedThreadPool(10);
    
    public static void main(String[] args) {
        LibraryActor library = new LibraryActor();
        
        // Create actors
        Actor<Book> bookActor = library.createBookActor();
        Actor<Member> memberActor = library.createMemberActor();
        Actor<BorrowingRecord> borrowingActor = library.createBorrowingActor();
        
        // Send messages to actors
        bookActor.tell(new Book("1984", "George Orwell"));
        bookActor.tell(new Book("To Kill a Mockingbird", "Harper Lee"));
        
        memberActor.tell(new Member("John Doe"));
        memberActor.tell(new Member("Jane Smith"));
        
        borrowingActor.tell(new BorrowingRecord("1984", "John Doe", 30));
        borrowingActor.tell(new BorrowingRecord("To Kill a Mockingbird", "Jane Smith", 15));
    }
    
    public Actor<Book> createBookActor() {
        return new Actor<>(book -> {
            System.out.println("Book added: " + book.title);
            return CompletableFuture.completedFuture(null);
        });
    }
    
    public Actor<Member> createMemberActor() {
        return new Actor<>(member -> {
            System.out.println("Member registered: " + member.name);
            return CompletableFuture.completedFuture(null);
        });
    }
    
    public Actor<BorrowingRecord> createBorrowingActor() {
        return new Actor<>(record -> {
            System.out.println("Borrowing record created for book: " + record.bookTitle 
                             + ", member: " + record.memberName 
                             + ", due days: " + record.dueDays);
            return CompletableFuture.completedFuture(null);
        });
    }
    
    public static class Book {
        String title;
        String author;
        
        public Book(String title, String author) {
            this.title = title;
            this.author = author;
        }
    }
    
    public static class Member {
        String name;
        
        public Member(String name) {
            this.name = name;
        }
    }
    
    public static class BorrowingRecord {
        String bookTitle;
        String memberName;
        int dueDays;
        
        public BorrowingRecord(String bookTitle, String memberName, int dueDays) {