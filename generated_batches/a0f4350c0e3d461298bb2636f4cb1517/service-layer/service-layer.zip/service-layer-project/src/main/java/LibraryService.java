package library.service;

import library.model.Book;
import library.model.Member;

import java.util.Date;

public class LibraryService implements BorrowingService {
    private static final int LOAN_PERIOD_DAYS = 14;
    
    @Override
    public boolean borrowBook(Member member, Book book) {
        if (book.isAvailable()) {
            book.setAvailable(false);
            return true;
        }
        return false;
    }

    @