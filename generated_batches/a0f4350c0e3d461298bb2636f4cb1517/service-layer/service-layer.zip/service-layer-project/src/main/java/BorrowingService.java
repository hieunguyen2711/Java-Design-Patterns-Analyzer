package library.service;

import library.model.Book;
import library.model.Member;

public interface BorrowingService {
    boolean borrowBook(Member member, Book book);
    boolean returnBook(Member member, Book book);
    boolean isOverdue(Book book);
}