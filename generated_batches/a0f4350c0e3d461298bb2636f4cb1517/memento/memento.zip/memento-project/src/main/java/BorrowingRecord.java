import java.time.LocalDate;

public class BorrowingRecord {
    private Book book;
    private LibraryMember member;
    private LocalDate borrowDate;
    private LocalDate dueDate;
    private boolean isReturned;
    
    public BorrowingRecord(Book book, LibraryMember member, LocalDate borrowDate, LocalDate dueDate) {
        this.book = book;
        this.member = member;
        this.borrowDate = borrowDate;
        this.dueDate = dueDate;
        this.isReturned = false;
    }
    
    public Book getBook() {
        return book;
    }
    
    public LibraryMember getMember() {
        return member;
    }
    
    public LocalDate getBorrowDate() {
        return borrowDate;
    }
    
    public LocalDate getDueDate() {
        return dueDate;
    }
    
    public boolean isReturned() {
        return isReturned;
    }
    
    public void setReturned(boolean returned) {
        isReturned = returned;
    }
    
    @Override
    public String toString() {
        return "BorrowingRecord{" +
                "book=" + book