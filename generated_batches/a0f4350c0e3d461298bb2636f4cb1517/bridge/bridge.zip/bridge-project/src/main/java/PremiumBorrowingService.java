public class PremiumBorrowingService implements BorrowingService {
    private static final int PREMIUM_LOAN_PERIOD_DAYS = 28;
    
    @Override
    public void borrowBook(Book book, LibraryMember member) {
        System.out.println("Premium borrowing: " + book.getTitle() + 
                          " borrowed by " + member.getName());
    }
    
    @Override
    public void returnBook(Book book, LibraryMember