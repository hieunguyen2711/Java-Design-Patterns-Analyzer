public class StandardBorrowingService implements BorrowingService {
    private static final int STANDARD_LOAN_PERIOD_DAYS = 14;
    
    @Override
    public void borrowBook(Book book, LibraryMember member) {
        System.out.println("Standard borrowing: " + book.getTitle() + 
                          " borrowed by " + member.getName());
    }
    
    @Override
    public void returnBook(Book book, LibraryMember member) {
        System.out.println("Standard returning: " + book.getTitle() + 
                          " returned by " + member.getName());
    }
    
    @Override
    public boolean isOverdue(Book book, LibraryMember member) {
        // Simplified overdue check for demonstration
        return false;
    }
}