public interface BorrowingService {
    void borrowBook(Book book, LibraryMember member);
    void returnBook(Book book, LibraryMember member);
    boolean isOverdue(Book book, LibraryMember member);
}