import java.util.concurrent.ConcurrentLinkedQueue;

public class BookPool {
    private static BookPool instance;
    private ConcurrentLinkedQueue<Book> availableBooks;
    
    private BookPool() {
        availableBooks = new ConcurrentLinkedQueue<>();
        initializePool();
    }
    
    public static synchronized BookPool getInstance() {
        if (instance == null) {
            instance = new BookPool();
        }
        return instance;
    }
    
    private void initializePool() {
        // Pre-populate with some books
        availableBooks.offer(new Book("978-0134685991", "Effective Java", "Joshua Bloch"));
        availableBooks.offer(new Book("978-0596009205", "