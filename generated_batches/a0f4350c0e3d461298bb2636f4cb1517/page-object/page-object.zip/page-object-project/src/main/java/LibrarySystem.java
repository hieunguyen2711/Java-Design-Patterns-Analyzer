public class LibrarySystem {
    private final BookRepository bookRepository;
    private final MemberRepository memberRepository;
    
    public LibrarySystem(BookRepository bookRepository, MemberRepository memberRepository) {
        this.bookRepository = bookRepository;
        this.memberRepository = memberRepository;
    }
    
    public void borrowBook(String memberId, String isbn) {
        Member member = memberRepository.findMember(memberId);
        Book book = bookRepository.findBook(isbn);
        
        if (member != null && book != null && !book.isBorrowed()) {
            book.setBorrowed(true);
            book.setDueDate(java.time.LocalDate.now().plusDays(14));
            member.addBorrowedBook(book);
        }
    }
    
    public void returnBook(String memberId, String isbn) {
        Member member = memberRepository.findMember(memberId);
        Book book = bookRepository.findBook(isbn);
        
        if (member != null && book != null && book.isBorrowed()) {
            book.setBorrowed(false);
            book.setDueDate(null);
            member.removeBorrowedBook(book);
        }
    }
}