import java.util.List;
import java.util.ArrayList;

public class Member {
    private final String memberId;
    private final String name;
    private final List<Book> borrowedBooks;
    
    public Member(String memberId, String name) {
        this.memberId = memberId;
        this.name = name;
        this