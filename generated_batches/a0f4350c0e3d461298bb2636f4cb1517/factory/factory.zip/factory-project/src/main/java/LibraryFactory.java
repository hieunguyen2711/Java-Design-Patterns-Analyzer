public class LibraryFactory {
    
    public static Book