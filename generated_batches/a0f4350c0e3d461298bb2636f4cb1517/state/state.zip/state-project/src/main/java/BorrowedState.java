public class BorrowedState extends BookState {
    @Override
    public void borrow(Book book) {
        System.out.println("Cannot borrow a book that is already borrowed.");
    }

    @Override
    public void returnBook(Book book) {
        System.out.println("Book '" + book.getTitle() + "' has been returned.");
        book.setState(new AvailableState());
    }
}