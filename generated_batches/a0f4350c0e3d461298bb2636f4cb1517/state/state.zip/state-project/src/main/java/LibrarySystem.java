public class LibrarySystem {
    public static void main(String[] args) {
        Book book = new Book("1984", "George Orwell", "978-0451524935");
        
        System.out.println("Initial state: " + book.getState().getClass().getSimpleName());
        
        book.borrow();
        System.out.println("After borrow: " + book.getState().getClass().getSimpleName());
        
        book.borrow();
        System.out.println("After second borrow: " + book.getState().getClass().getSimpleName());