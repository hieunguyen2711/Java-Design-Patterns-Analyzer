public abstract class BookState {
    public abstract void borrow(Book book);
    public abstract void returnBook(Book book);
}