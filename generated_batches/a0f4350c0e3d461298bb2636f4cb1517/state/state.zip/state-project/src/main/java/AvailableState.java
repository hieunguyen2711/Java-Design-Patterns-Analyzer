public class AvailableState extends BookState {
    @Override
    public void borrow(Book book) {
        System.out.println("Book '" + book.getTitle() + "' is now borrowed.");
        book.setState(new BorrowedState());
    }

    @Override
    public void returnBook(Book book) {
        System.out.println("Cannot return a book that is not borrowed.");
    }
}