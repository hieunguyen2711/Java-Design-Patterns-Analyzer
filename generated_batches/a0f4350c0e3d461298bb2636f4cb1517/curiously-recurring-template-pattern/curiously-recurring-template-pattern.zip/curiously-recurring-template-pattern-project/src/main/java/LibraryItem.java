package library;

public abstract class LibraryItem<T extends LibraryItem<T>> {
    protected String title;
    protected String isbn;
    protected boolean isAvailable;
    
    public LibraryItem(String title, String isbn) {
        this.title = title;
        this.isbn = isbn;
        this.isAvailable = true;
    }
    
    public T checkout() {
        if (isAvailable) {
            isAvailable = false;
            return (T) this;
        }
        return null;
    }
    
    public T checkin() {
        isAvailable = true;
        return (T) this;
    }
    
    public String getTitle() {
        return title;
    }
    
    public String getIsbn() {
        return isbn;
    }
    
    public boolean isAvailable() {
        return isAvailable;
    }
}