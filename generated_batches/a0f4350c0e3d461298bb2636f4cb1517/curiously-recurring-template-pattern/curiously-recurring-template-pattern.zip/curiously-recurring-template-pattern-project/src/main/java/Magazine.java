package library;

public class Magazine extends LibraryItem<Magazine> {
    private int issueNumber;
    
    public Magazine(String title, String isbn, int issueNumber) {
        super(title, isbn);
        this.issueNumber = issueNumber;
    }
    
    public int getIssueNumber() {
        return issueNumber;
    }
    
    @Override
    public String toString() {
        return "Magazine{" +
                "title='" + title + '\'' +
                ", isbn='" + isbn + '\'' +
                ", issueNumber=" + issueNumber +
                ", isAvailable=" + isAvailable +
                '}';
    }
}