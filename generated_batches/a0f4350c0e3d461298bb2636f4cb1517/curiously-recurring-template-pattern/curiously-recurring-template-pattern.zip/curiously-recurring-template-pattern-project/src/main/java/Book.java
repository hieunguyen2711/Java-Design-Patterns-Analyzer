package library;

public class Book extends LibraryItem<Book> {
    private String author;
    
    public Book(String title, String isbn, String author) {
        super(title, isbn);
        this.author = author;
    }
    
    public String getAuthor() {
        return author;
    }
    
    @Override
    public String toString() {
        return "Book{" +
                "title='" + title + '\'' +
                ", isbn='" + isbn + '\'' +
                ", author='" + author + '\'' +
                ", isAvailable=" + isAvailable +
                '}';
    }
}