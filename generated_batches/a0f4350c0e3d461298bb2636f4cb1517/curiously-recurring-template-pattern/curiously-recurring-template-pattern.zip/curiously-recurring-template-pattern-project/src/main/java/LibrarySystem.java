package library;

public class LibrarySystem {
    public static void main(String[] args) {
        Book book = new Book("Effective Java", "978-0134685991", "Joshua Bloch");
        Magazine magazine = new Magazine("