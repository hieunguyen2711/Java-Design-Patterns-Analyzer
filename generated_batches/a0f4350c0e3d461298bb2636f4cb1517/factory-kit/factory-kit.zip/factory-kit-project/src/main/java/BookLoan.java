public class BookLoan extends LibraryItem {
    private static final int BORROW_PERIOD = 14;
    
    public BookLoan(Book book, Member member) {
        super(book, member);
    }
    
    @Override
    public int getBorrowPeriod() {
        return B