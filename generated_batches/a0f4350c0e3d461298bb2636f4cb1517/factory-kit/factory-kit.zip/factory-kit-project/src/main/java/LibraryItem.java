public abstract class LibraryItem {
    protected Book book;
    protected Member member;
    protected java.time.LocalDate borrowDate;
    protected java.time.LocalDate dueDate;
    
    public LibraryItem(Book book, Member member) {
        this.book = book;
        this.member = member;
        this.borrowDate = java.time.LocalDate.now();
        this.dueDate = borrowDate.plusDays(getBorrowPeriod());
    }
    
    public abstract int getBorrowPeriod();
    public abstract double calculateLateFee(int daysOverdue);
    
    // Getters
    public Book getBook() { return book; }
    public Member getMember() { return member; }
    public java.time.LocalDate getBorrowDate() { return borrowDate; }
    public java.time.LocalDate getDueDate() { return dueDate; }
}