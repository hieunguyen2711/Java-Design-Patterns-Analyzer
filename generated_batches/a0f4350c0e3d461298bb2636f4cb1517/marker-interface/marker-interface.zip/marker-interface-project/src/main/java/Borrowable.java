package library;

/**
 * Marker interface to indicate that a book can be borrowed from the library.
 */
public interface Borrowable {
    // This is a marker interface with no methods
}