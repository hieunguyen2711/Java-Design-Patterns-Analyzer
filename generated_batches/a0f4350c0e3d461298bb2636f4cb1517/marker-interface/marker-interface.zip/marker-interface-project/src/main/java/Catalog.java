package library;

import java.util.*;

public class Catalog {
    private Map<String, Book> books;
    
    public Catalog() {
        this.books = new HashMap<>();
    }
    
    public void addBook(Book book) {
        books.put(book.getIsbn(), book);
    }
    
    public Book getBook(String isbn) {
        return books.get(isbn);
    }
    
    public List<Book> getAllBooks() {
        return new ArrayList<>(books.values());
    }
    
    /**
     * Returns only books that implement the Borrowable interface
     */
    public List<Book> getBorrowableBooks() {
        List<Book> borrowableBooks = new ArrayList<>();
        for (Book book : books.values()) {
            if (book instanceof Borrowable) {
                borrowableBooks.add(book);
            }
        }
        return borrowableBooks;
    }
}