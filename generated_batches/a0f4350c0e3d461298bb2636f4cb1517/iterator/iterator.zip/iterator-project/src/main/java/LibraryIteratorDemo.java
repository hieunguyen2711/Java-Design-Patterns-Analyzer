public class LibraryIteratorDemo {
    public static void main(String[] args) {
        Library library = new Library();
        
        library.addBook(new Book("1984", "George Orwell", "978-0451524935"));
        library.addBook(new Book("To Kill a Mockingbird", "Harper Lee", "978-0061120084"));
        library.addBook(new Book("The Great Gatsby", "F. Scott Fitzgerald", "978-0743273565"));
        
        System.out.println("Books in the library:");
        for (Book book : library) {
            System.out.println("- " + book.getTitle() + " by " + book.getAuthor());
        }
    }
}