package library;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class LibrarySystem {
    private final ExecutorService executorService;
    
    public LibrarySystem() {
        this.executorService = Executors.newFixedThreadPool(3);
    }
    
    public void processBookReturn(String bookId, String memberId) {
        executorService.submit(() -> {
            // Simulate processing book return
            System.out.println("Processing return for book: " + bookId + 
                             " by member: " + memberId);
            try {
                Thread.sleep(1000); // Simulate work
                System.out.println("Return processed successfully");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
    }
    
    public void processBookBorrow(String bookId, String memberId) {
        executorService.submit(() -> {
            // Simulate processing book borrow
            System.out.println("Processing borrow for book: " + bookId + 
                             " by member: " + memberId);
            try {
                Thread.sleep(1500); // Simulate work
                System.out.println("Borrow processed successfully");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
    }
    
    public void shutdown() {
        executorService.shutdown();
        try {
            if (!executorService.awaitTermination(60, TimeUnit.SECONDS)) {
                executorService.shutdownNow();
            }
        } catch (InterruptedException e) {
            executorService.shutdownNow();
        }
    }
}