package library;

public class Main {
    public static void main(String[] args) {
        LibraryManager manager = new LibraryManager();
        
        // Simulate concurrent book operations
        manager.borrowBook("B001", "M001");
        manager.returnBook