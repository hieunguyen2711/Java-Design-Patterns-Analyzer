package library;

public class LibraryManager {
    private final LibrarySystem librarySystem;
    
    public LibraryManager() {
        this.librarySystem = new LibrarySystem();
    }
    
    public void returnBook(String bookId, String memberId) {
        librarySystem.processBookReturn(bookId, memberId);
    }
    
    public void borrowBook(String bookId, String memberId) {
        librarySystem.processBookBorrow(bookId, memberId);
    }
    
    public void close() {
        librarySystem.shutdown();
    }
}