import java.util.*;

public class BookManager {
    private final Map<String, Book> books;
    
    public BookManager() {
        this.books = new HashMap<>();
    }
    
    public void addBook(Book book) {
        books.put(book.getIsbn(), book);
    }
    
    public Book findBook(String isbn) {
        return books.get(isbn);
    }
    
    public Collection<Book> getAllBooks() {
        return new ArrayList<>(books.values());
    }
}