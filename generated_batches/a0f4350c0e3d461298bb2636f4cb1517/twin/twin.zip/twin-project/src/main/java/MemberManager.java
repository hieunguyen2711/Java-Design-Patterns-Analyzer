import java.util.*;

public class MemberManager {
    private final Map<String, Member> members;
    
    public MemberManager() {
        this.members = new HashMap<>();
    }
    
    public void addMember(Member member) {
        members.put(member.getMemberId(), member);
    }
    
    public Member findMember(String memberId) {
        return members.get(memberId);
    }
    
    public Collection<Member> getAllMembers() {
        return new ArrayList<>(members.values());
    }
}