public class LibrarySystem {
    private static LibrarySystem instance;
    private final BookManager bookManager;
    private final MemberManager memberManager;
    
    private LibrarySystem() {
        this.bookManager = new BookManager();
        this.memberManager = new MemberManager();
    }
    
    public static synchronized LibrarySystem getInstance() {
        if (instance == null) {
            instance = new LibrarySystem();
        }
        return instance;
    }
    
    public BookManager getBookManager() {
        return bookManager;
    }
    
    public MemberManager getMemberManager() {
        return memberManager;
    }
}