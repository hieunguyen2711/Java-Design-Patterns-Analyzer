package library;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class BorrowingRecord {
    private Book book;
    private Member member;
    private LocalDate borrowDate;
    private LocalDate returnDate;
    
    public BorrowingRecord(Book book, Member member, LocalDate borrowDate) {
        this.book = book;
        this.member = member;
        this.borrowDate = borrowDate;
    }
    
    // Getters and setters
    public Book getBook() { return book; }
    public void setBook(Book book) { this.book = book; }
    public Member getMember() { return member; }
    public void setMember(Member member) { this.member = member; }
    public LocalDate getBorrowDate() { return borrowDate; }
    public void setBorrowDate(LocalDate borrowDate) { this.borrowDate = borrowDate; }
    public LocalDate getReturnDate() { return returnDate; }
    public void setReturnDate(LocalDate returnDate) { this.returnDate = returnDate; }
    
    public long getDaysBorrowed() {
        if (returnDate != null