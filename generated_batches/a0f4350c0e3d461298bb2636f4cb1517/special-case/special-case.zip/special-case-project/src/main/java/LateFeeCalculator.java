package library;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class LateFeeCalculator {
    private static final double DAILY_LATE_FEE = 0.25;
    
    public static double calculateLateFee(BorrowingRecord record) {
        LocalDate today = LocalDate.now();
        if (today.isAfter(record.getDueDate())) {
            long daysLate = ChronoUnit.DAYS.between(record.getDueDate(), today);
            return daysLate * DAILY_LATE_FEE;
        }
        return 0.0;
    }
}