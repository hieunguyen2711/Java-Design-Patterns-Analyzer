package library;

import java.time.LocalDate;

public class BorrowingRecord {
    private Book book;
    private Member member;
    private LocalDate borrowDate;
    private LocalDate dueDate;
    
    public BorrowingRecord(Book book, Member member, LocalDate borrowDate) {
        this.book = book;
        this.member = member;
        this.borrowDate = borrowDate;
        this.dueDate = borrowDate.plusDays(14);
    }
    
    public Book getBook() {
        return book;
    }
    
    public Member getMember() {
        return member;
    }
    
    public LocalDate getBorrowDate() {
        return borrowDate;
    }
    
    public LocalDate getDueDate() {
        return dueDate;
    }
}