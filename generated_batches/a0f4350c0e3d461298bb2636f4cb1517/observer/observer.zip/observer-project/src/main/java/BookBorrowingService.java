package library;

public class BookBorrowingService {
    private BookStatusNotifier notifier;
    
    public BookBorrowingService() {
        this.not