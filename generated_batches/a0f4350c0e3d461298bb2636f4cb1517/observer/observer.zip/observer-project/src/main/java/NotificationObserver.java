package library;

public interface NotificationObserver {
    void update(String message);
}