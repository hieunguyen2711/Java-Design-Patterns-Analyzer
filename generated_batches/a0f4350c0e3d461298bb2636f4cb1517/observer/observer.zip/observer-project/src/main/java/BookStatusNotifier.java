package library;

import java.util.ArrayList;
import java.util.List;

public class BookStatusNotifier {
    private List<NotificationObserver> observers;
    
    public BookStatusNotifier() {
        this.observers = new ArrayList<>();
    }
    
    public void addObserver(NotificationObserver observer) {
        observers.add(observer);
    }
    
    public void removeObserver(NotificationObserver observer) {
        observers.remove(observer);
    }
    
    public void notifyObservers(String message) {
        for (NotificationObserver observer : observers) {
            observer.update(message);
        }
    }
}