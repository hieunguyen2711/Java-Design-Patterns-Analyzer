package library;

import java.util.HashMap;
import java.util.Map;

public class LibraryServiceImpl implements LibraryService {
    private Map<String, Book> books = new HashMap<>();
    private Map<String, Member> members = new HashMap<>();
    
    public LibraryServiceImpl() {
        // Initialize with some sample data
        books.put("978-0134685991", new Book("978-0134685991", "Effective Java", "Joshua Bloch"));
        members.put("M001", new Member("M001", "John Doe"));
    }
    
    @Override
    public void borrowBook(String memberId, String isbn) {
        // Implementation would handle borrowing logic
        System.out.println("Borrowing book " + isbn + " for member " + memberId);
    }
    
    @Override
    public void returnBook(String memberId, String isbn) {
        // Implementation would handle returning logic
        System.out.println("Returning book " + isbn + " from member " + memberId);
    }
    
    @Override
    public double calculateLateFee(String memberId, String isbn) {
        // Implementation would calculate late fees
        return 0.0;
    }
}