package library;

public interface LibraryService {
    void borrowBook(String memberId, String isbn);
    void returnBook(String memberId, String isbn);
    double calculateLateFee(String memberId, String isbn);
}