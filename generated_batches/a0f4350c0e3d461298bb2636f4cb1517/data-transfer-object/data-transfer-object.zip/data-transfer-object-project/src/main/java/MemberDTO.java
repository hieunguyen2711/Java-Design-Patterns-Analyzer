package library.dto;

public class MemberDTO {
    private int memberId;
    private String name;
    private String email;