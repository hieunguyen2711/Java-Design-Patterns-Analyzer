package library;

public interface PaymentProcessor {
    void processPayment(double amount);
}