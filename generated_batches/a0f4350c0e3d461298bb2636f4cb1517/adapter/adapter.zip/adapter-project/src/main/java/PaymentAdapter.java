package library;

public class PaymentAdapter implements PaymentProcessor {
    private CreditCardProcessor creditCardProcessor;
    
    public PaymentAdapter(CreditCardProcessor creditCardProcessor) {
        this.creditCardProcessor