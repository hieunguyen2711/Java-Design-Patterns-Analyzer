package library;

public class CreditCardProcessor {
    public void chargeCreditCard(String cardNumber, double amount) {
        System.out.println("Charging $" + amount + " to credit card ending in " + 
                          cardNumber.substring(cardNumber.length() - 4));
    }
}