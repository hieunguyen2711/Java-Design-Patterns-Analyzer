package library.model;

import java.time.LocalDate;
import java.util.Objects;

public class BorrowingRecord {