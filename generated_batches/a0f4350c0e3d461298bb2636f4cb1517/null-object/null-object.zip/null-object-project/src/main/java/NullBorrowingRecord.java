package library;

import java.time.LocalDate;

public class NullBorrowingRecord extends BorrowingRecord {
    private static final NullBorrowingRecord INSTANCE = new NullBorrowingRecord();
    
    private NullBorrowingRecord() {
        super(null, null, null, null);
    }
    
    public static NullBorrowingRecord getInstance() {
        return INSTANCE;
    }
    
    @Override
    public Book