public class LibrarySystem {
    public static void main(String[] args) {
        Book book1 = new Book("1984", "George Orwell");
        Book book2 = new Book("To Kill a Mockingbird", "Harper Lee");
        
        Member member1 = new Member("John Doe");
        Member member2 = new Member("Jane Smith");
        
        Library library = new Library();
        
        // Borrow books
        library.borrowBook(book1, member1);
        library.borrowBook(book2, member2);
        
        // Return books
        library.returnBook(book1, member1);
        library.returnBook(book2, member2);
    }
}