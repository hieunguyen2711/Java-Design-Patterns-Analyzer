import java.util.*;

public class Library {
    private Map<Book, Member> borrowedBooks;
    private Map<Member, List<Book>> memberBorrowedBooks;
    
    public Library() {
        this.borrowedBooks = new HashMap<>();
        this.memberBorrowedBooks = new HashMap<>();
    }
    
    public void borrowBook(Book book, Member member) {
        if (borrowedBooks.containsKey(book)) {
            System.out.println("Book " + book.getTitle() + " is already borrowed.");
            return;
        }
        
        borrowedBooks.put(book, member);
        memberBorrowedBooks.computeIfAbsent(member, k -> new ArrayList<>()).add(book);
        System.out.println(member.getName() + " borrowed " + book.getTitle());
    }
    
    public void returnBook(Book book, Member member) {
        if (!borrowedBooks.containsKey(book)) {
            System.out.println("Book " + book.getTitle() + " was not borrowed.");
            return;
        }
        
        Member borrower = borrowedBooks.get(book);
        if (borrower != member) {
            System.out.println("Book " + book