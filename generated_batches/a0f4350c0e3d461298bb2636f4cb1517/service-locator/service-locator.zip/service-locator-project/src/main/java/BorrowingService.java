public class BorrowingService implements LibraryService {
    @Override
    public void borrowBook(Member member, Book book) {
        System.out.println("Borrowing book " + book.getTitle() + 
                          " for member " + member.getName());
    }
    
    @Override
    public void returnBook(Member member, Book book) {
        System.out.println("Returning book " + book.getTitle() + 
                          " from member " + member.getName());
    }
    
    @Override
    public double calculateLateFee(Book book, int daysOverdue) {
        return daysOverdue * 0.50;
    }
}