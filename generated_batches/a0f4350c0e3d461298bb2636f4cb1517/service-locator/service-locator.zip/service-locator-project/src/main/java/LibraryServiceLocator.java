import java.util.HashMap;
import java.util.Map;

public class LibraryServiceLocator {
    private static Map<String, LibraryService> services = new HashMap<>();
    
    static {
        services.put("borrowing", new BorrowingService());
    }
    
    public static LibraryService getService(String serviceType) {
        return services.get(serviceType);
    }
}