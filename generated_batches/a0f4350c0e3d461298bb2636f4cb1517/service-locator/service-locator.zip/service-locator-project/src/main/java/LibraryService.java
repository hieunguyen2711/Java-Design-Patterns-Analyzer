public interface LibraryService {
    void borrowBook(Member member, Book book);
    void returnBook(Member member, Book book);
    double calculateLateFee(Book book, int daysOverdue);
}