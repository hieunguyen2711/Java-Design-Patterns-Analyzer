public class BookTitleExpression implements Expression {
    private String title;
    
    public BookTitleExpression(String title) {
        this.title = title;
    }
    
    @Override
    public boolean interpret(BorrowingRecord record, LocalDate currentDate) {
        return record.getBook().getTitle().equals(title);
    }
}