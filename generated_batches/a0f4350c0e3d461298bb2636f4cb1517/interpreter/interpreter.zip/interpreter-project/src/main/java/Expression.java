import java.time.LocalDate;

public interface Expression {
    boolean interpret(BorrowingRecord record, LocalDate currentDate);
}