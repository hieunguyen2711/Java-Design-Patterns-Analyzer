import java.time.LocalDate;

public class BorrowingRecord {
    private Book book;
    private LibraryMember member;
    private LocalDate borrowDate;
    private LocalDate dueDate;
    
    public BorrowingRecord(Book book, LibraryMember member, LocalDate borrowDate, LocalDate dueDate) {
        this.book = book;
        this.member = member;
        this.borrowDate = borrowDate;
        this.dueDate = dueDate;
    }
    
    public Book getBook() {
        return book;
    }
    
    public LibraryMember getMember() {
        return member;
    }
    
    public LocalDate getBorrowDate() {
        return borrowDate;
    }
    
    public LocalDate getDueDate() {
        return dueDate;
    }
}