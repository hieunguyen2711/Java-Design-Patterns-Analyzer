public class MemberExpression implements Expression {
    private String memberId;
    
    public MemberExpression(String memberId) {
        this.memberId = memberId;
    }
    
    @Override
    public