package library;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class BorrowingRecord {
    private Book book;
    private Member member;
    private LocalDate borrowDate;
    private LocalDate dueDate;
    private boolean isReturned;
    
    public BorrowingRecord(Book book, Member member, LocalDate borrowDate) {
        this.book = book;
        this.member = member;
        this.borrowDate = borrowDate;
        this.dueDate = borrowDate.plusDays(14); // 2 weeks borrowing period
        this.isReturned = false;
    }
    
    public double calculateLateFee() {
        if (isReturned) return 0.0;
        
        LocalDate today = LocalDate.now();
        long daysOverdue = ChronoUnit.DAYS.between(dueDate, today);
        return Math.max(0, daysOverdue * 0.25); // $0.25 per day late
    }
    
    public void returnBook() {
        this.isReturned = true;
    }
    
    // Getters and setters
    public Book getBook()