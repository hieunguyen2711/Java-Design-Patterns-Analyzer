package library;

import java.util.*;

public class LibrarySystem {
    private Map<String, Book> books;
    private Map<String, Member> members;
    private List<BorrowingRecord> borrowingRecords;
    
    public LibrarySystem() {
        this.books = new HashMap<>();
        this.members = new HashMap<>();
        this.borrowingRecords = new ArrayList<>();
    }
    
    public void addBook(Book book) {
        books.put(book.getIsbn(), book);
    }
    
    public void registerMember(Member member) {
        members.put(member.getMemberId(), member);
    }
    
    public BorrowingRecord borrowBook(String memberId, String isbn) {
        Member member = members.get(memberId);
        Book book = books.get(isbn);
        
        if (member == null || book == null) {
            return null;
        }
        
        BorrowingRecord record = new BorrowingRecord(member, book);
        borrowingRecords.add(record);
        return record;
    }
    
    public boolean returnBook(String isbn) {
        Iterator<BorrowingRecord> iterator = borrowingRecords.iterator();
        while (iterator.hasNext()) {
            BorrowingRecord record = iterator.next();
            if (record.getBook().getIsbn().equals(isbn)) {
                iterator.remove();
                return true;
            }
        }
        return false;
    }
    
    public List<BorrowingRecord> getBorrowingRecords() {
        return new ArrayList<>(borrowingRecords);
    }
}