package library;

import java.util.HashMap;
import java.util.Map;

public class LibraryDatabase {
    private static final Map<String, Book> bookCache = new HashMap<>();
    
    public static Book getBook(String isbn) {
        return bookCache.get(isbn);
    }
    
    public static void addBook(Book book) {
        bookCache.put(book.getIsbn(), book);
    }
    
    public static boolean containsBook(String isbn) {
        return bookCache.containsKey(isbn);
    }
}