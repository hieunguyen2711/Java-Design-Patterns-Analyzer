package library;

public class Main {
    public static void main(String[] args) {
        BookManager manager = new BookManager();
        
        // Create books with same