package library;

public class BookManager {
    
    public Book getOrCreateBook(String isbn, String title, String author) {
        Book existingBook = LibraryDatabase.getBook(isbn);
        if (existingBook != null) {
            return existingBook;
        }
        
        Book newBook = new Book(isbn, title, author);
        LibraryDatabase.addBook(newBook);
        return newBook;
    }
    
    public void printBookInfo(String isbn) {
        Book book = LibraryDatabase.getBook(isbn);
        if (book != null) {
            System.out.println("Title: " + book.getTitle() + 
                             ", Author: " + book.getAuthor());
        } else {
            System.out.println("Book not found");
        }
    }
}