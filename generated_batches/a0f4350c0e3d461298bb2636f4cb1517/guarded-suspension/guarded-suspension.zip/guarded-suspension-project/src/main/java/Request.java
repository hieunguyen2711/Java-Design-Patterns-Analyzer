package library;

public class Request {
    private final String type;
    private final String bookId;
    private final String memberId;
    
    public Request(String type, String bookId, String memberId) {
        this.type = type;
        this.bookId = bookId;
        this.memberId = memberId;
    }
    
    public String getType() { return type; }
    public String getBookId() { return bookId; }
    public String getMemberId() { return memberId; }
}