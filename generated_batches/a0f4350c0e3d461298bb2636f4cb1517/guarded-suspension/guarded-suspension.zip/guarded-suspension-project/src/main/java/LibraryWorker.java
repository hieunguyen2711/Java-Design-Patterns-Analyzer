package library;

public class LibraryWorker {
    private final LibrarySystem system;
    
    public LibraryWorker(LibrarySystem system) {
        this.system = system;
    }
    
    public void processRequests() {
        try {
            while (!Thread.currentThread().isInterrupted()) {
                // Guarded suspension - wait for request
                Request request = system.waitForRequest();
                
                // Process the request
                if ("borrow".equals(request.getType())) {
                    System.out.println("Processing borrow request for book " + 
                        request.getBookId() + " by member " + request.getMemberId());
                } else if ("return".equals(request.getType())) {
                    System.out.println("Processing return request for book " + 
                        request.getBookId() + " by member " + request.getMemberId());
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}