package library;

public class LibraryClient {
    private final LibrarySystem system;
    
    public LibraryClient(LibrarySystem system) {
        this.system = system;
    }
    
    public void borrowBook(String bookId, String memberId) {
        Request request = new Request("borrow", bookId, memberId);
        system.submitRequest(request);
    }
    
    public void returnBook(String bookId, String memberId)