package library;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class LibrarySystem {
    private final BlockingQueue<Request> requestQueue = new LinkedBlockingQueue<>();
    
    public void submitRequest(Request request) {
        try {
            requestQueue.put(request);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
    
    public Request waitForRequest() throws InterruptedException {
        return requestQueue.take();
    }
}