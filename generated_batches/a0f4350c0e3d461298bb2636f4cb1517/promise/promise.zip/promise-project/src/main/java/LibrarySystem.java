package library;

public class LibrarySystem {
    public static void main(String[] args) {
        Book book1 = new Book("1234567890", "Java Programming", "John Doe");
        Book book2 = new Book("0987654321", "Design Patterns", "Gang of Four");
        
        Member member1 = new Member("M001", "Alice Smith");
        Member member2 = new Member("M002", "Bob Johnson");
        
        Library library = new Library();
        
        // Borrow books
        library.borrowBook(member1, book1);
        library.borrowBook(member2, book2);
        
        // Return books
        library.returnBook(member1, book1);
        library.returnBook(member2, book2);
    }
}