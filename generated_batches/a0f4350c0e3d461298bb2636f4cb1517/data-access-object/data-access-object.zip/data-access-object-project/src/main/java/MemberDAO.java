import java.util.List;

public interface MemberDAO {
    Member getMemberById(int memberId);
    List<Member> getAllMembers();
    void save(Member member);
    void update(Member member);
    void delete(int memberId);
}