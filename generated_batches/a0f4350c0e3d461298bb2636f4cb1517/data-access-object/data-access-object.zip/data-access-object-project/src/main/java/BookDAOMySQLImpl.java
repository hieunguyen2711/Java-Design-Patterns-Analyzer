import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BookDAOMySQLImpl implements BookDAO {
    private Connection connection;
    
    public BookDAOMySQLImpl(Connection connection) {
        this.connection = connection;
    }
    
    @Override
    public Book getBookByIsbn(String isbn) {
        try {
            PreparedStatement stmt =