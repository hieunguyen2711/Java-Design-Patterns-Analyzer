import java.util.List;

public interface BookDAO {
    Book getBookByIsbn(String isbn);
    List<Book> getAllBooks();
    void save(Book book);
    void update(Book book);
    void delete(String isbn);
}