public class LibrarySystem {
    public static void main(String[] args) {
        Book book1 = new Book("1234567890", "Java Programming", "John Doe");
        Book book2 = new Book("0987654321", "Design Patterns", "Gang of Four");
        
        Library library = Library.getInstance();
        library.addBook(book1);
        library.addBook(book2);
        
        Member member1 = new Member("M001", "Alice Smith");
        Member member2 = new Member("M002", "Bob Johnson");
        
        library.registerMember(member1);
        library.registerMember(member2);
        
        library.borrowBook("1234567890", "M001");
        library.borrowBook("0987654321", "M002");
        
        System.out.println("Books in library: " + library.getAvailableBooks().size());
    }
}