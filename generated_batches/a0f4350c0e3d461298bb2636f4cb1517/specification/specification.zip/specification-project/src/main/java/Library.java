import java.util.*;

public class Library {
    private static Library instance;
    private List<Book> books;
    private Map<String, Member> members;
    private Map<String, Book> borrowedBooks;
    
    private Library() {
        books = new ArrayList<>();
        members = new HashMap<>();
        borrowedBooks = new HashMap<>();
    }
    
    public static synchronized Library getInstance() {
        if (instance == null) {
            instance = new Library();
        }
        return instance;
    }
    
    public void addBook(Book