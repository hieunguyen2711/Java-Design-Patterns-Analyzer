public class LibrarySystem {
    private final Book book;
    private boolean isBorrowed = false;
    
    public LibrarySystem(Book book) {
        this.book = book;
    }
    
    public void borrowBook(Member member) {
        if (isBorrowed) {
            System.out.println("Book is already borrowed");
            return; // Balking - don't proceed if book is already borrowed
        }
        
        isBorrowed = true;
        book.setBorrower(member);
        book.setDueDate(java.time.LocalDate.now().plusDays(14));
        System.out.println("Book borrowed successfully by " + member.getName());
    }
    
    public void returnBook() {
        if (!isBorrowed) {
            System.out.println("Book was not borrowed");
            return; // Balking - don't proceed if book wasn't borrowed
        }
        
        isBorrowed = false;
        book.setBorrower(null);
        book.setDueDate(null);
        System.out.println("Book returned successfully");
    }
}