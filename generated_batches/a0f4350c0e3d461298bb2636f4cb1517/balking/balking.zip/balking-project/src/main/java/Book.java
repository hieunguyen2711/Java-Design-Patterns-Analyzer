import java.time.LocalDate;

public class Book {
    private String title;
    private String author;
    private Member borrower;
    private LocalDate dueDate;
    
    public Book(String title, String author) {
        this.title = title;
        this.author = author;
    }
    
    // Getters and setters
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }
    
    public Member getBorrower() { return borrower; }
    public void setBorrower(Member borrower) { this.borrower = borrower; }
    
    public LocalDate getDueDate() { return dueDate; }
    public void setDueDate(LocalDate dueDate) { this.dueDate = dueDate; }
}