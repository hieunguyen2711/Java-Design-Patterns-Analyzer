public class LibrarySystem {
    private static LibrarySystem instance;
    
    private LibrarySystem() {}
    
    public static synchronized LibrarySystem getInstance() {
        if (instance == null) {
            instance = new LibrarySystem();
        }
        return instance;
    }
    
    public void borrowBook(String bookTitle, String memberName) {
        System.out.println("Book '" + bookTitle + "' borrowed by " + memberName);
    }
    
    public void returnBook(String bookTitle, String memberName) {
        System.out.println("Book '" + bookTitle + "' returned by " + memberName);
    }
}