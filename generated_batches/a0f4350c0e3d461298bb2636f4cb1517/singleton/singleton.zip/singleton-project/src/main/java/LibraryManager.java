public class LibraryManager {
    public static void main(String[] args) {
        LibrarySystem library1 = LibrarySystem.getInstance();
        LibrarySystem library2 = LibrarySystem.getInstance();
        
        System.out.println("Are both instances the same? " + (library1 == library2));
        
        library1.borrowBook("Java Programming", "John Doe");
        library2.returnBook("Java Programming", "John Doe");
    }
}