package library;

public class Book {
    private String title;
    private String author;
    private String isbn;
    private boolean isAvailable;
    
    // Dirty flag to track if the book has been modified
    private boolean isDirty = false;
    
    public Book(String title, String author, String isbn) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.isAvailable = true;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
        markDirty();
    }
    
    public String getAuthor() {
        return author;
    }
    
    public void setAuthor(String author) {
        this.author = author;
        markDirty();
    }
    
    public String getIsbn() {
        return isbn;
    }
    
    public void setIsbn(String isbn) {
        this.isbn = isbn;
        markDirty();
    }
    
    public boolean isAvailable() {
        return isAvailable;
    }
    
    public void setAvailable(boolean available) {
        isAvailable = available;
        markDirty();
    }
    
    // Dirty flag methods
    private void markDirty() {
        isDirty = true;
    }
    
    public boolean isDirty() {
        return isDirty;
    }
    
    public void clearDirtyFlag() {
        isDirty = false;
    }
    
    @Override
    public String toString() {
        return "Book{" +
                "title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", isbn='" + isbn + '\'' +
                ", isAvailable=" + isAvailable +
                '}';
    }
}