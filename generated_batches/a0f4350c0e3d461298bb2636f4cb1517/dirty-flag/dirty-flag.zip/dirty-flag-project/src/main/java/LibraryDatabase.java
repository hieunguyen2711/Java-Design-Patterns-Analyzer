package library;

import java.util.*;

public class LibraryDatabase {
    private Map<String, Book> books;
    
    public LibraryDatabase() {
        this.books = new HashMap<>();
    }
    
    public void addBook(Book book) {
        books.put(book.getIsbn(), book);
    }
    
    public Book getBook(String isbn) {
        return books.get(isbn);
    }
    
    public List<Book> getAllBooks() {
        return new ArrayList<>(books.values());
    }
    
    // Simulate saving dirty books to database
    public void saveDirtyBooks() {
        for (Book book : books.values()) {
            if (book.isDirty()) {
                System.out.println("Saving