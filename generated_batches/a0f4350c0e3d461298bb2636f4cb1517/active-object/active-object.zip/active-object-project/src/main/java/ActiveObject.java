import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class ActiveObject {
    private final BlockingQueue<Request> requestQueue;
    private final Thread workerThread;
    
    public ActiveObject() {
        this.requestQueue = new LinkedBlockingQueue<>();
        this.workerThread = new Thread(this::processRequests);
        this.workerThread.start();
    }
    
    public void enqueue(Request request) {
        try {
            requestQueue.put(request);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
    
    private void processRequests() {
        while (!Thread.currentThread().isInterrupted()) {
            try {
                Request request = requestQueue.take();
                request.execute();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }
    
    public void processQueue() {
        // For testing purposes - processes all pending requests
        while (!requestQueue.isEmpty()) {
            try {
                Request request = requestQueue.take();
                request.execute();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }
}