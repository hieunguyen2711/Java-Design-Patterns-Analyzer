import java.time.LocalDate;

public class BorrowRequest implements Request {
    private final String memberName;
    private final String bookTitle;
    
    public BorrowRequest(String memberName, String bookTitle) {
        this.memberName = memberName;
        this.bookTitle = bookTitle;
    }
    
    @Override
    public void execute() {
        System.out.println("Processing borrow request for " + bookTitle + 
                          " by " + memberName);
        // Simulate processing delay
        try {
            Thread.sleep(100);
        } catch (