public class LibrarySystem {
    private final ActiveObject activeObject;
    
    public LibrarySystem() {
        this.activeObject = new ActiveObject();
    }
    
    public void borrowBook(String memberName, String bookTitle) {
        activeObject.enqueue(new BorrowRequest(memberName, bookTitle));
    }
    
    public void returnBook(String memberName, String bookTitle) {
        activeObject.enqueue(new ReturnRequest(memberName, bookTitle));
    }
    
    public void processRequests() {
        activeObject.processQueue();
    }
}