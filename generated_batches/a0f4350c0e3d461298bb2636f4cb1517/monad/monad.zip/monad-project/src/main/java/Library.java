import java.time.LocalDate;
import java.util.*;

public class Library {
    private final Map<String, Book> books = new HashMap<>();
    private final Map<String, Member> members = new HashMap<>();
    private final Map<String, List<BorrowingRecord>> borrowingRecords = new HashMap<>();

    public void addBook(Book book) {
        books.put(book.getIsbn(), book);
    }

    public void registerMember(Member member) {
        members.put(member.getMemberId(), member);
    }

    public Optional<Book> findBookByIsbn(String isbn) {
        return Optional.ofNullable(books.get(isbn));
    }

    public Optional<Member> findMemberById(String memberId) {
        return Optional.ofNullable(members.get(memberId));
    }

    public void borrowBook(String memberId, String isbn) {
        findMemberById(memberId)
            .flatMap(member -> findBookByIsbn(isbn))
            .ifPresent(book -> {
                BorrowingRecord record = new BorrowingRecord(
                    book.getIsbn(),
                    member.getMemberId(),
                    LocalDate.now(),
                    null
                );
                borrowingRecords.computeIfAbsent(memberId, k -> new ArrayList<>()).add(record);
            });
    }

    public void returnBook(String memberId, String isbn) {
        findMemberById(memberId)
            .flatMap(member -> findBookByIsbn(isbn))
            .ifPresent(book -> {
                List<BorrowingRecord> records = borrowingRecords.get(memberId);
                if (records != null) {
                    records.stream()
                        .filter(record -> record