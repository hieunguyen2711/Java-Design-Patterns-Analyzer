public class LibraryPageController implements PageController {
    private BookService bookService;
    
    public LibraryPageController() {
        this.bookService = new BookService();
    }
    
    @Override
    public void handleRequest(String action, String bookId) {
        switch (action.toLowerCase()) {
            case "borrow":
                bookService.borrowBook(bookId);
                break;
            case "return":
                bookService.returnBook(bookId);
                break;
            case "latefee":
                bookService.calculateLateFee(bookId);
                break;
            default:
                System.out.println("Unknown action: " + action);
        }
    }
}