public class BookService {
    public void borrowBook(String bookId) {
        System.out.println("Borrowing book with ID: " + bookId);
    }
    
    public void returnBook(String bookId) {
        System.out.println("Returning book with ID: " + bookId);
    }
    
    public void calculateLateFee(String bookId) {
        System.out.println("Calculating late fee for book with ID: " + bookId);
    }
}