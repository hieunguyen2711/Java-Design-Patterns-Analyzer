public interface PageController {
    void handleRequest(String action, String bookId);
}