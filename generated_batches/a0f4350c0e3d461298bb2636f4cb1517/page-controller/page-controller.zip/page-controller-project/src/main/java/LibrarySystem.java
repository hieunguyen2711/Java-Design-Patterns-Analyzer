public class LibrarySystem {
    public static void main(String[] args) {
        PageController controller = new LibraryPageController();
        controller.handleRequest("borrow", "12345");
        controller.handleRequest("return", "12345");
        controller.handleRequest("latefee", "12345");
    }
}