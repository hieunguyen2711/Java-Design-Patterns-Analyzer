public class Member {
    private String name;
    private String memberId;
    private int maxBooks;

    public Member(String name, String memberId) {
        this.name = name;
        this.memberId = memberId;
        this.maxBooks = 3;
    }

    // Getters and setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getMemberId() { return memberId; }
    public void setMemberId(String memberId) { this.memberId = memberId; }
    
    public int getMaxBooks() { return maxBooks; }
    public void setMaxBooks(int maxBooks) { this.maxBooks = maxBooks; }
}