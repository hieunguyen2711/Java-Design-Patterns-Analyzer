import java.util.*;

public class LibraryModel {
    private List<Book> books;
    private List<Member> members;
    private Map<String, List<Book>> borrowedBooks;

    public LibraryModel() {
        this.books = new ArrayList<>();
        this.members = new ArrayList<>();
        this.borrowedBooks = new HashMap<>();
    }

    // Book management
    public void addBook(Book book) {
        books.add(book);
    }
    
    public void removeBook(String isbn) {
        books.removeIf(book -> book.getIsbn().equals(isbn));
    }
    
    public List<Book> getAllBooks() {
        return new ArrayList<>(books);
    }
    
    public Book findBookByIsbn(String isbn) {
        return books.stream()