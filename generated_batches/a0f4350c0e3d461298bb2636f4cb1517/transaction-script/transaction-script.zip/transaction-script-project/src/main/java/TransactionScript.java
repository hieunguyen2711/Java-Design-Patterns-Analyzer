import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

public class TransactionScript {
    private Map<String, LocalDate> borrowDates;
    
    public TransactionScript() {
        this.borrowDates = new HashMap<>();
    }
    
    public