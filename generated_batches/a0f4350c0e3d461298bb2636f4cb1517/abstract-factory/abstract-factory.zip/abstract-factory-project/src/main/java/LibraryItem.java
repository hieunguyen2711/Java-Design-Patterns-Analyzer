public interface LibraryItem {
    String getId();
    String getTitle();
    boolean isAvailable();
    void setAvailable(boolean available);
}