package library;

import java.util.List;

public class BookServiceProxy implements BookService {
    private RealBookService realBookService;
    private List<Book> cachedSearchResults;
    private Book cachedBookDetails;
    
    @Override
    public List<Book> searchBooks(String query) {
        if (cachedSearchResults == null) {
            System.out.println("Loading books from database...");
            realBookService = new RealBookService();