package library;

import java.util.List;

public interface BookService {
    List<Book> searchBooks(String query);
    Book getBookDetails(String isbn);
}