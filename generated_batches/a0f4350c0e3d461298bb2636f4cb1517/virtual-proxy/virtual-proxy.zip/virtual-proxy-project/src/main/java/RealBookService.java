package library;

import java.util.Arrays;
import java.util.List;

public class RealBookService implements BookService {
    
    @Override
    public List<Book> searchBooks(String query) {
        // Simulate expensive database operation
        simulateDelay();
        return Arrays.asList(
            new Book("978-0134685991", "Effective Java", "Joshua Bloch"),
            new Book("978-0201633610", "Design Patterns", "Gang of Four")
        );
    }
    
    @Override
    public Book getBookDetails(String isbn) {
        // Simulate expensive database operation
        simulateDelay();
        if ("978-0134685991".equals(isbn)) {
            return new Book("978-0134685991", "Effective Java", "Joshua Bloch");
        }
        return null;
    }
    
    private void simulateDelay() {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}