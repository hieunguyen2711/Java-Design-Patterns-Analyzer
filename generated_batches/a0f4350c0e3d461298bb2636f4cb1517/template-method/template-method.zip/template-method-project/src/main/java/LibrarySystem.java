public abstract class LibrarySystem {
    // Template method
    public final void processBorrowing() {
        checkMemberEligibility();
        checkBookAvailability();
        if (isEligible() && isAvailable()) {
            assignBookToMember();
            calculateDueDate();
            calculateLateFee();
            updateLibraryRecords();
            notifyMember();
        } else {
            handleUnsuccessfulBorrowing();
        }
    }

    protected abstract void checkMemberEligibility();
    protected abstract void checkBookAvailability();
    protected abstract boolean isEligible();
    protected abstract boolean isAvailable();
    protected abstract void assignBookToMember();
    protected abstract void calculateDueDate();
    protected abstract void calculateLateFee();
    protected abstract void updateLibraryRecords();
    protected abstract void notifyMember();
    protected abstract void handleUnsuccessfulBorrowing();
}