public class BorrowBookCommand implements Command {
    private Library library;
    private String bookId;
    private String memberName;
    
    public BorrowBookCommand(Library library, String bookId, String memberName) {
        this.library = library;
        this.bookId = bookId;
        this.memberName = memberName;