public class LibrarySystem {
    public static void main(String[] args) {
        Library library = new Library();
        
        // Create commands
        Command borrowBookCommand = new BorrowBookCommand(library, "123", "John Doe");
        Command returnBookCommand = new ReturnBookCommand(library, "123", "John Doe");
        
        // Execute commands
        borrowBookCommand.execute();
        returnBookCommand.execute();
    }
}