import java.util.HashMap;
import java.util.Map;

public class Library {
    private Map<String, Book> books;
    private Map<String, Member> members;
    
    public Library() {
        this.books = new HashMap<>();
        this.members = new HashMap<>();
        initializeLibrary();
    }
    
    private void initializeLibrary() {
        books.put("123", new Book("123", "Effective Java"));
        books.put("456", new Book("456", "Design Patterns"));
        members.put("John Doe", new Member("John Doe"));
    }
    
    public void borrowBook(String bookId, String memberName) {
        Book book = books.get(bookId);
        Member member = members.get(memberName);
        
        if (book != null && member != null) {
            book.setBorrowed(true);
            book.setDueDate(java.time.LocalDate.now().plusDays(14));
            System.out.println("Book " + book.getTitle() + " borrowed by " + member.getName());
        }
    }
    
    public void returnBook(String bookId, String memberName) {
        Book book = books.get(bookId);
        Member member = members.get(memberName);
        
        if (book != null && member != null) {
            book.setBorrowed(false);
            book.setDueDate(null);
            System.out.println("Book " + book.getTitle() + " returned by " + member.getName());
        }
    }
}