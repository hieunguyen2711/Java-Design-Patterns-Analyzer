package library;

import java.util.Date;
import java.util.concurrent.TimeUnit;

public class LibrarySystem {
    
    public static void main(String[] args) {
        Book book = new Book("978-0134685991", "Effective Java", "Joshua Bloch");
        Member member = new Member("M001", "John Doe");
        
        // RAII pattern in action - resource automatically managed
        try (LibraryCard card