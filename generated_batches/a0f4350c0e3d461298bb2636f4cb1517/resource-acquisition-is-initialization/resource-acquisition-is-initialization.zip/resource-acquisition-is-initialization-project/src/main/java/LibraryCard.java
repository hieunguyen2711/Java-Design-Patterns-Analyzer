package library;

import java.util.Date;

public class LibraryCard implements AutoCloseable {
    private Member member;
    private Book book;
    private Date borrowDate;
    private Date dueDate;
    
    public LibraryCard(Member member, Book book) {
        this.member = member;
        this.book = book;
        this.borrowDate = new Date();
        // Set due date to 14 days from now
        this.dueDate = new Date(System.currentTimeMillis() + (14 * 24 * 60 * 60 * 1000L));
    }
    
    public Member getMember() { return member; }
    public Book getBook() { return book; }
    public Date getBorrowDate() { return borrowDate; }
    public Date getDueDate() { return dueDate; }
    
    @Override
    public void close() {
        System.out.println("Library card for " + member.getName() + 
                          " returned for book: " + book.getTitle());
    }
}