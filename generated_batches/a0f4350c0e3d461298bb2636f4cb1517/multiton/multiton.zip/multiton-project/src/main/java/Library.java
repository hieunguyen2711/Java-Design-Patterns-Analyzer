public class Library {
    private static final int MAX_LIBRARIES = 3;
    private static Library[] instances = new Library[MAX_LIBRARIES];
    
    private String name;
    private int id;
    
    private Library(String name, int id) {
        this.name = name;
        this.id = id;
    }
    
    public static synchronized Library getInstance(String name, int id) {
        if (id < 0 || id >= MAX_LIBRARIES) {
            throw new IllegalArgumentException("Invalid library ID: " + id);
        }
        
        if (instances[id] == null) {
            instances[id] = new Library(name, id);
        }
        
        return instances[id];
    }
    
    public String getName() {
        return name;
    }
    
    public int getId() {
        return id;
    }
}