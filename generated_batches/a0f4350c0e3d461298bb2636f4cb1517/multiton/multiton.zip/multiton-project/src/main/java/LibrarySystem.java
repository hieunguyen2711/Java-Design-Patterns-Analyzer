public class LibrarySystem {
    public static void main(String[] args) {
        // Create libraries using multiton pattern
        Library centralLibrary = Library.getInstance("Central Library", 0);
        Library downtownLibrary = Library.getInstance("Downtown Library", 1);
        Library eastsideLibrary = Library.getInstance("Eastside Library", 2);
        
        // Try to get same instances again
        Library centralLibrary2 = Library.getInstance("Central Library", 0);
        Library downtownLibrary2 = Library.getInstance("D