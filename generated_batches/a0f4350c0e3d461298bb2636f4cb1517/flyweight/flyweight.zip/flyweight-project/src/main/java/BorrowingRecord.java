public class BorrowingRecord {
    private Book book;
    private LibraryMember member;
    private String borrowDate;
    private String dueDate;
    private boolean isReturned;
    
    public BorrowingRecord(Book book, LibraryMember member, String borrowDate, String dueDate) {
        this.book = book;
        this.member = member;
        this.borrowDate = borrowDate;
        this.dueDate = dueDate;
        this.isReturned = false;
    }
    
    public Book getBook() {
        return book;
    }
    
    public LibraryMember getMember() {
        return member;
    }
    
    public String getBorrowDate() {
        return borrowDate;
    }
    
    public String getDueDate() {
        return dueDate;
    }
    
    public boolean isReturned() {
        return isReturned;
    }
    
    public void set