import java.util.HashMap;
import java.util.Map;

public class BookFlyweightFactory {
    private static final Map<String, Book> bookCache = new HashMap<>();
    
    public static Book getBook(String title, String author, String isbn) {
        String key = title + "|" + author + "|" + isbn;
        
        if (!bookCache.containsKey(key)) {
            bookCache.put(key, new Book(title, author, isbn));
        }
        
        return bookCache.get(key);
    }
    
    public static int getCacheSize() {
        return bookCache.size();
    }
}