public class Book extends LibraryItem {
    private String author;
    
    public Book(String title, String itemID, String author) {
        super(title, itemID);
        this.author = author;
    }
    
    @Override
    public void accept(LibraryVisitor visitor) {
        visitor.visit(this);
    }
    
    public String getAuthor() {
        return author;
    }
}