public class Magazine extends LibraryItem {
    private int issueNumber;
    
    public Magazine(String title, String itemID, int issueNumber) {
        super(title, itemID);
        this.issueNumber = issueNumber;
    }
    
    @Override
    public void accept(LibraryVisitor visitor) {
        visitor.visit(this);
    }
    
    public int getIssueNumber() {
        return issueNumber;
    }
}