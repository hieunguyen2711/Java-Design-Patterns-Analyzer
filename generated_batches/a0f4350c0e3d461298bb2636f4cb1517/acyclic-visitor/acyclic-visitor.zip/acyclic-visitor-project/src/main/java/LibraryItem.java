public abstract class LibraryItem {
    protected String title;
    protected String itemID;
    
    public LibraryItem(String title, String itemID) {
        this.title = title;
        this.itemID = itemID;
    }
    
    public abstract void accept(LibraryVisitor visitor);
    
    public String getTitle() {
        return title;
    }
    
    public String getItemID() {
        return itemID;
    }
}