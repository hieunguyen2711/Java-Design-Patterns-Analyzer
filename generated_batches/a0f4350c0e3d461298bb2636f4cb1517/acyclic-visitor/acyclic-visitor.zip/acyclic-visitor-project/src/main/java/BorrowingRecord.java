public class BorrowingRecord {
    private Member member;
    private LibraryItem item;
    private java.time.LocalDate borrowDate;
    private java.time.LocalDate dueDate;
    
    public BorrowingRecord(Member member, LibraryItem item, java.time.LocalDate borrowDate) {
        this.member = member;
        this.item = item;
        this.borrowDate = borrowDate;
        this.dueDate = borrowDate.plusDays(14); // 2 week borrowing period
    }
    
    public Member getMember() {
        return member;
    }
    
    public LibraryItem getItem() {
        return item;
    }
    
    public java.time.LocalDate getB