public class BorrowingRecord {
    private Book book;
    private LibraryMember member;
    private java.time.LocalDate borrowDate;
    private java.time.LocalDate dueDate;
    
    public BorrowingRecord(Book book, LibraryMember member, java.time.LocalDate borrowDate) {
        this.book = book;
        this.member = member;
        this.borrowDate = borrowDate;
        this.dueDate = borrowDate.plusDays(14); // 2 weeks borrowing period
    }
    
    // Getters and setters
    public Book getBook() { return book; }
    public void setBook(Book book) { this.book = book; }
    public LibraryMember getMember() { return member; }
    public void setMember(LibraryMember member) { this.member = member; }
    public java.time.LocalDate getBorrowDate() { return borrowDate; }
    public void setBorrowDate(java.time.LocalDate borrowDate) { this.borrowDate = borrowDate; }
    public java.time.LocalDate getDueDate() { return dueDate; }
    public void setDueDate(java.time.LocalDate dueDate) { this.dueDate = dueDate