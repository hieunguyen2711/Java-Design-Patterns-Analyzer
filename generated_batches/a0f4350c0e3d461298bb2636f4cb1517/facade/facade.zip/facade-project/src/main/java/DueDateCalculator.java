import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class DueDateCalculator {
    private static final int LOAN_PERIOD_DAYS = 14;
    
    public LocalDate calculateDueDate() {
        return LocalDate.now().plusDays(LOAN_PERIOD_DAYS);
    }
    
    public long calculateLateDays(LocalDate dueDate) {
        return ChronoUnit.DAYS.between(LocalDate.now(), dueDate);
    }
}