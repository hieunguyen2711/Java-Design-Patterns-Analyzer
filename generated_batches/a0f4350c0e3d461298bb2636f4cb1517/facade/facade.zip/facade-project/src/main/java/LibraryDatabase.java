import java.util.*;

public class LibraryDatabase {
    private Map<String, Book> books;
    private Map<String, Member> members;
    
    public LibraryDatabase() {
        this.books = new HashMap<>();
        this.members = new HashMap<>();
    }
    
    public void addBook(Book book) {
        books.put(book.getIsbn(), book);
    }
    
    public void addMember(Member member) {
        members.put(member.getMemberId(), member);
    }
    
    public Book findBookByIsbn(String isbn) {
        return books.get(isbn);
    }
    
    public Member findMemberById(String memberId) {
        return members.get(memberId);
    }
}