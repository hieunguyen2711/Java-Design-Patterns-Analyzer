public class LateFeeCalculator {
    private static final double DAILY_LATE_FEE = 0.50;
    
    public double calculateLateFee(long lateDays) {
        if (lateDays <= 0) return 0.0;
        return lateDays * DAILY_LATE_FEE