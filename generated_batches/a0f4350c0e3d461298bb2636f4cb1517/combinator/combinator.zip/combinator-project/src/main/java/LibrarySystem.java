package com.library.system;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class LibrarySystem {
    private List<Book> books;
    private List<Member> members;
    
    public LibrarySystem() {
        this.books = new ArrayList<>();
        this.members = new ArrayList<>();
    }
    
    public void addBook(Book book) {
        books.add(book);
    }
    
    public void registerMember(Member member) {
        members.add(member);
    }
    
    public BorrowingResult borrowBook(String memberId, String isbn) {
        Member member = findMember(memberId);
        Book book = findBook(isbn);
        
        if (member == null || book == null) {
            return new BorrowingResult(false, "Member or book not found");
        }
        
        if (!book.isAvailable()) {
            return new BorrowingResult(false, "Book is already borrowed");
        }
        
        book.borrow();
        member.borrowBook(book);
        
        LocalDate dueDate = LocalDate.now().plusDays(14); // 2 weeks
        return new BorrowingResult(true, "Success", book, member, dueDate);
    }
    
    public ReturnResult returnBook(String memberId, String isbn) {
        Member member = findMember(memberId);
        Book book = findBook(isbn);
        
        if (member == null || book == null) {
            return new ReturnResult(false, "Member or book not found");
        }
        
        if (!book.isAvailable()) {
            book.returnBook();
            member.returnBook(book);
            
            LocalDate dueDate = LocalDate.now().plusDays(14);
            long daysLate = Math.max(0, java.time.temporal.ChronoUnit.DAYS.between(dueDate, LocalDate.now()));
            double lateFee = daysLate * 0.50; // $0.50 per day
            
            return new ReturnResult(true, "Success", book, member, lateFee);
        }
        
        return new ReturnResult(false, "Book was not borrowed");
    }
    
    private Member findMember(String id) {
        return members.stream()
                .filter(m -> m.getId().equals(id))
                .findFirst()
                .orElse(null);
    }
    
    private Book findBook(String isbn) {
        return books.stream()
                .filter(b -> b.getIsbn().equals(isbn))
                .findFirst()
                .orElse(null);
    }
}