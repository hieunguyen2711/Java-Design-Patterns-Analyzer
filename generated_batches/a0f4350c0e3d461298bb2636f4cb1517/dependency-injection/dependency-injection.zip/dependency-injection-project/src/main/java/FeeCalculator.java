package library;

public interface FeeCalculator {
    double calculateLateFee(int daysLate);
}