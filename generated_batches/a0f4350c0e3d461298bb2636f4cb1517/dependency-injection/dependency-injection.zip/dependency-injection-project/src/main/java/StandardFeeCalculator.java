package library;

public class StandardFeeCalculator implements FeeCalculator {
    private static final double DAILY_FEE = 0.50;
    
    @Override
    public double calculateLateFee(int daysLate) {