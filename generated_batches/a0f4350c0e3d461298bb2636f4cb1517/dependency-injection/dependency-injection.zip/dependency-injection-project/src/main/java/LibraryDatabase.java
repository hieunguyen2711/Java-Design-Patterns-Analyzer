package library;

import java.util.HashMap;
import java.util.Map;

public class LibraryDatabase {
    private Map<String, Book> books;
    private Map<String, Member> members;
    
    public LibraryDatabase() {
        this.books = new HashMap<>();
        this.members = new HashMap<>();
    }
    
    public void addBook(Book book) {
        books.put(book.getIsbn(), book);
    }
    
    public void addMember(Member member) {
        members.put(member.getMemberId(), member);
    }
    
    public Book findBook(String isbn) {
        return books.get(isbn);
    }
    
    public Member findMember(String memberId) {
        return members.get(memberId);
    }
}