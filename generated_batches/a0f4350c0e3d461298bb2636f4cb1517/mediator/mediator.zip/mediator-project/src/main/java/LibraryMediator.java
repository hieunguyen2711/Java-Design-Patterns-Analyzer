import java.util.*;

public class LibraryMediator implements Mediator {
    private List<Book> books;
    private List<Member> members;
    
    public LibraryMediator() {
        this.books = new ArrayList<>();
        this.members = new ArrayList<>();
    }
    
    @Override
    public void registerBook(Book book) {
        books.add(book);
    }
    
    @Override
    public void registerMember(Member member) {
        members.add(member);
    }
    
    @Override
    public void borrowBook(Book book, Member member) {
        if (book.isAvailable()) {
            book.setAvailable(false);
            book.setBorrower(member);
            member.borrowBook(book);
        } else {
            System.out.println("Book " + book.getTitle() + " is already borrowed.");
        }
    }
    
    @Override
    public void returnBook(Book book, Member member) {
        if (book.getBorrower() == member) {
            book.setAvailable(true);
            book.setBorrower(null);
            member.returnBook(book);
        } else {
            System.out.println("Member " + member.getName() + "