public interface Mediator {
    void registerBook(Book book);
    void registerMember(Member member);
    void borrowBook(Book book, Member member);
    void returnBook(Book book, Member member);
    void updateLateFee(Member member, double fee);
}