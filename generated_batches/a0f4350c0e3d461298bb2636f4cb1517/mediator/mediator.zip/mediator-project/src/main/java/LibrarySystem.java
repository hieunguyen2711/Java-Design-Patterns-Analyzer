public class LibrarySystem {
    public static void main(String[] args) {
        Mediator mediator = new LibraryMediator();
        
        Book book1 = new Book("1984", "George Orwell");
        Book book2 = new Book("To Kill a Mockingbird", "Harper Lee");
        
        Member member1 = new Member("Alice Johnson", "M001");
        Member member2 = new Member("Bob Smith", "M002");
        
        mediator.registerBook(book1);
        mediator.registerBook(book2);
        mediator.registerMember(member1);
        mediator.registerMember(member2);
        
        mediator.borrowBook(book1, member1);
        mediator.borrowBook(book2, member2);
        
        System.out.println("Late fees:");
        System.out.println(member1.getName() + ": $" + member1.getLateFee());
        System.out.println(member2.getName() + ": $" + member2.getLateFee());
    }
}