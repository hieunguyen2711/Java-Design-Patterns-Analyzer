import java.util.HashMap;
import java.util.Map;

public class BookService {
    private Map<String, Book> books = new HashMap<>();
    
    public Book findBook(String isbn) {
        return books.get(isbn);
    }
    
    public void addBook(Book book) {
        books.put(book.getIsbn(), book);
    }
}