import java.util.HashMap;
import java.util.Map;

public class MemberService {
    private Map<Integer, Member> members = new HashMap<>();
    
    public Member findMember(int memberId) {
        return members.get(memberId);
    }
    
    public void addMember(Member member) {
        members.put(member.getMemberId(),