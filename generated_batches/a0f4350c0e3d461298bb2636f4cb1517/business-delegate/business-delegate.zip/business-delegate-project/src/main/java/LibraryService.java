public interface LibraryService {
    void borrowBook(int memberId, String isbn);
    void returnBook(int memberId, String isbn);
    double calculateLateFee(int memberId, String isbn);
}