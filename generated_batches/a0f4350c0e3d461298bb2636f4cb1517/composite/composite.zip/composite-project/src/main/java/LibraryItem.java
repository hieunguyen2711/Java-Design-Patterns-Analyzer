package library;

public abstract class LibraryItem {
    protected String title;
    protected String itemId;
    
    public LibraryItem(String title, String itemId) {
        this.title = title;
        this.itemId = itemId;
    }
    
    public abstract double calculateLateFee(int daysOverdue);
    public abstract boolean isAvailable();
    public abstract void borrowItem();
    public abstract void returnItem();
    
    public String getTitle() {
        return title;
    }
    
    public String getItemId() {
        return itemId;
    }
}