package library;

import java.util.ArrayList;
import java.util.List;

public class LibraryCollection extends LibraryItem {
    private List<LibraryItem> items;
    private String collectionName;
    
    public LibraryCollection(String name, String itemId) {
        super(name, itemId);
        this.items = new ArrayList<>();
        this.collectionName = name;
    }
    
    public void addItem(LibraryItem item) {
        items.add(item);
    }
    
    public void removeItem(LibraryItem item) {
        items.remove(item);
    }
    
    @Override
    public double calculateLateFee(int daysOverdue) {
        double totalFee = 0.0;
        for (LibraryItem item : items) {
            if (!item.isAvailable()) {
                totalFee += item.calculateLateFee(daysOverdue);
            }
        }
        return totalFee;
    }
    
    @Override
    public boolean isAvailable() {
        for (