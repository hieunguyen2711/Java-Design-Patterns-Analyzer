package library;

public class Book extends LibraryItem {
    private boolean isBorrowed;
    private String author;
    
    public Book(String title, String itemId, String author) {
        super(title, itemId);
        this.author = author;
        this.isBorrowed = false;
    }
    
    @Override
    public double calculateLateFee(int daysOverdue) {
        return daysOverdue * 0.50;
    }
    
    @Override
    public boolean isAvailable() {
        return !isBorrowed;
    }
    
    @Override
    public void borrowItem() {
        if (isAvailable()) {
            isBorrowed = true;
        }
    }
    
    @Override
    public void returnItem() {
        isBorrowed = false;
    }
    
    public String getAuthor() {
        return author;
    }
}