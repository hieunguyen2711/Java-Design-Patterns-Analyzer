package com.example.booking;

public class BookingClient {
    public static void main(String[] args) {
        TicketBookingSystem system = new TicketBookingSystem();
        
        // Simulate multiple concurrent booking requests
        Thread t1 = new Thread(() -> {
            try {
                system.bookTicket("T001");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
        
        Thread t2 = new Thread(() -> {
            try {
                system.bookTicket("T002"); // This should be balked
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
        
        t1.start();
        t2.start();
        
        try {
            t1.join();
            t2.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}