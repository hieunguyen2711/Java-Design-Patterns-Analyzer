package com.example.booking;

public class TicketBookingSystem {
    private boolean isBookingInProgress = false;
    
    public void bookTicket(String ticketId) throws InterruptedException {
        // Balking pattern: only proceed if no booking is currently in progress
        if (isBookingInProgress) {
            System.out.println("Booking already in progress, skipping request for " + ticketId);
            return;
        }
        
        // Simulate booking process
        isBookingInProgress = true;
        System.out.println("Starting booking for ticket: " + ticketId);
        Thread.sleep(1000); // Simulate processing time
        System.out.println("Completed booking for ticket: " + ticketId);
        isBookingInProgress = false;
    }
}