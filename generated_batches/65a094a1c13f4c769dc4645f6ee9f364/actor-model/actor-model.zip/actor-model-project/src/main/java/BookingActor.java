import java.util.concurrent.CompletableFuture;

public class BookingActor implements Actor<TicketRequest> {
    private int availableTickets = 10;
    
    @Override
    public void tell(TicketRequest message) {
        CompletableFuture.runAsync(() -> processMessage(message), 
                                  java.util.concurrent.Executors.newCachedThreadPool());
    }
    
    @Override
    public void processMessage(TicketRequest request) {
        if (availableTickets >= request.quantity) {
            availableTickets -= request.quantity;
            System.out.println("Booking confirmed for " + request.customerName + 
                             " for " + request.event + " (" + request.quantity + " tickets)");
            
            // Send notification
            ActorSystem system = new ActorSystem();
            Actor<NotificationRequest> notificationActor = system.createActor(NotificationActor.class);
            notificationActor.tell(new NotificationRequest(request.customerName + "@email.com", 
                                                          "Booking confirmed for " + request.event));
        } else {
            System.out.println("Not enough tickets available for " + request.customerName);
        }
    }
}