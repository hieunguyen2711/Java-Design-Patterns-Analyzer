public class TicketRequest {
    public final String customerName;
    public final String event;
    public final int quantity;
    
    public TicketRequest(String customerName, String event, int quantity) {
        this.customerName = customerName;
        this.event = event;
        this.quantity = quantity;
    }
}