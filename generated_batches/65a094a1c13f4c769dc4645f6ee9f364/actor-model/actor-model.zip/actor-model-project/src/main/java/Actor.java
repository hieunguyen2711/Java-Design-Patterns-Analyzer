public interface Actor<T> {
    void tell(T message);
    void processMessage(T message);
}