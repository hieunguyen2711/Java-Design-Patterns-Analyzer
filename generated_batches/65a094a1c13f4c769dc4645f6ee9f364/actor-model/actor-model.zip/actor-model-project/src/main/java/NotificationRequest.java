public class NotificationRequest {
    public final String email;
    public final String message;
    
    public NotificationRequest(String email, String message) {
        this.email = email;
        this.message = message;
    }
}