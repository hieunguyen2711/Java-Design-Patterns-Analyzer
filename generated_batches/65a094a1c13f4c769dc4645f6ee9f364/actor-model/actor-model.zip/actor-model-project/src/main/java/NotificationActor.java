import java.util.concurrent.CompletableFuture;

public class NotificationActor implements Actor<NotificationRequest> {
    
    @Override
    public void tell(NotificationRequest message) {
        CompletableFuture.runAsync(() -> processMessage(message), 
                                  java.util.concurrent.Executors.newCachedThreadPool());
    }
    
    @Override
    public void processMessage(NotificationRequest request) {
        System.out.println("Sending notification to " + request.email + ": " + request.message);
    }
}