import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TicketBookingSystem {
    public static void main(String[] args) {
        ActorSystem actorSystem = new ActorSystem();
        
        // Create actors
        Actor<TicketRequest> bookingActor = actorSystem.createActor(BookingActor.class);
        Actor<NotificationRequest> notificationActor = actorSystem.createActor(NotificationActor.class);
        
        // Send messages to actors
        bookingActor.tell(new TicketRequest("John", "Concert", 2));
        bookingActor.tell(new TicketRequest("Jane", "Concert", 1));
        notificationActor.tell(new NotificationRequest("john@email.com", "Booking confirmed for Concert"));
        
        // Shutdown system after processing
        try {
            Thread.sleep(1000);
            actorSystem.shutdown();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}