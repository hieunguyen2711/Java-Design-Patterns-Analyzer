import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ActorSystem {
    private final ExecutorService executor = Executors.newFixedThreadPool(10);
    private final ConcurrentHashMap<Class<?>, Actor<?>> actors = new ConcurrentHashMap<>();
    
    public <T> Actor<T> createActor(Class<? extends Actor<T>> actorClass) {
        try {
            Actor<T> actor = actorClass.getDeclaredConstructor().newInstance();
            actors.put(actorClass, actor);
            return actor;
        } catch (Exception e) {
            throw new RuntimeException("Failed to create actor", e);
        }
    }
    
    public void shutdown() {
        executor.shutdown();
    }
}