public class TicketBookingSystem {
    public static void main(String[] args) {
        BookingService service = new BookingService();
        
        // Book multiple tickets using trampoline pattern
        int totalTickets = service.bookTickets(10);
        System.out.println("Total tickets booked: " + totalTickets);
    }
}