class Done<T> implements Trampoline<T> {
    private final T value;
    
    public Done(T value) {
        this.value = value;
    }
    
    @Override
    public T getResult() {
        return value;
    }
}