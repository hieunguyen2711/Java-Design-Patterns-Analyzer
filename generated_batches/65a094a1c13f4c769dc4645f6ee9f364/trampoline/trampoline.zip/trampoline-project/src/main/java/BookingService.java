public class BookingService {
    
    public int bookTickets(int numberOfTickets) {
        return Trampoline.trampoline(bookTicketsHelper(numberOfTickets, 0));
    }
    
    private Trampoline<Integer> bookTicketsHelper(int remaining, int booked) {
        if (remaining <= 0) {
            return Trampoline.done(booked);
        }
        
        // Simulate booking a ticket
        boolean success = simulateBooking();
        int newBooked = success ? booked + 1 : booked;
        int newRemaining = remaining - 1;
        
        return Trampoline.<Integer>more(() -> bookTicketsHelper(newRemaining, newBooked));
    }
    
    private boolean simulateBooking() {
        // Simulate booking process that might fail
        return Math.random() > 0.1; // 90% success rate
    }
}