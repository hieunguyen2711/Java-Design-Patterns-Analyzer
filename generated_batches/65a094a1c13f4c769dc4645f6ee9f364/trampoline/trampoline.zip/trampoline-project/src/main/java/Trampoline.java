@FunctionalInterface
public interface Trampoline<T> {
    
    T getResult();
    
    static <T> T trampoline(Trampoline<T> trampoline) {
        Trampoline<T> current = trampoline;
        while (true) {
            if (current instanceof Done<T>) {
                return ((Done<T>) current).value;
            }
            current = current.getResult();
        }
    }
    
    static <T> Trampoline<T> done(T value) {
        return new Done<>(value);
    }
    
    static <T> Trampoline<T> more(java.util.function.Supplier<Trampoline<T>> supplier) {
        return () -> supplier.get().getResult();
    }
}