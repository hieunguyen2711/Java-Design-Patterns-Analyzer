package com.ticketbooking;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;

public class TicketBookingSystem {
    private final Reactor reactor;
    private final ExecutorService executorService;

    public TicketBookingSystem() {
        this.reactor = new Reactor();
        this.executorService = Executors.newFixedThreadPool(10);
    }

    public void bookTicket(String userId, String eventId) {
        try {
            executorService.submit(() -> {
                reactor.handleEvent(new BookingRequest(userId, eventId));
            });
        } catch (RejectedExecutionException e) {
            System.err.println("Booking request rejected: " + e.getMessage());
        }
    }

    public void close() {
        executorService.shutdown();
    }
}