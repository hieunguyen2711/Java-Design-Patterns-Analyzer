package com.ticketbooking;

public class Main {
    public static void main(String[] args) {
        TicketBookingSystem system = new TicketBookingSystem();
        
        // Simulate multiple booking requests
        for (int i = 0; i < 5; i++) {
            final int userId = i;
            new Thread(() -> {
                system.bookTicket("user-" + userId, "event-123");
            }).start();
        }
        
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        system.close();
    }
}