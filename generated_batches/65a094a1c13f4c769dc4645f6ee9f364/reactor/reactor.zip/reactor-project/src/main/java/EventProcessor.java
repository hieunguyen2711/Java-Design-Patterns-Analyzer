package com.ticketbooking;

public class EventProcessor {
    
    public void process(Event event) {
        if (event instanceof BookingRequest) {
            handleBooking((BookingRequest) event);
        } else {
            System.err.println("Unknown event type: " + event.getClass().getSimpleName());
        }
    }

    private void handleBooking(BookingRequest request) {
        // Simulate booking processing
        System.out.printf("Processing booking for user %s on event %s%n", 
                         request.getUserId(), request.getEventId());
        
        try {
            Thread.sleep(100); // Simulate work
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        System.out.printf("Booking confirmed for user %s on event %s%n", 
                         request.getUserId(), request.getEventId());
    }
}