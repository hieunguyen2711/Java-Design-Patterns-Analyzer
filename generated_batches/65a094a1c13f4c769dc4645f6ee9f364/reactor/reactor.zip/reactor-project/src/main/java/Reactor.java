package com.ticketbooking;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;

public class Reactor {
    private final BlockingQueue<Event> eventQueue;
    private final AtomicBoolean isRunning;
    private final EventProcessor processor;

    public Reactor() {
        this.eventQueue = new LinkedBlockingQueue<>();
        this.isRunning = new AtomicBoolean(false);
        this.processor = new EventProcessor();
        
        // Start the reactor loop
        Thread reactorThread = new Thread(this::reactorLoop);
        reactorThread.setDaemon(true);
        reactorThread.start();
    }

    public void handleEvent(Event event) {
        try {
            eventQueue.put(event);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Interrupted while queuing event", e);
        }
    }

    private void reactorLoop() {
        isRunning.set(true);
        while (isRunning.get()) {
            try {
                Event event = eventQueue.take();
                processor.process(event);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            } catch (Exception e) {
                System.err.println("Error processing event: " + e.getMessage());
            }
        }
    }

    public void stop() {
        isRunning.set(false);
    }
}