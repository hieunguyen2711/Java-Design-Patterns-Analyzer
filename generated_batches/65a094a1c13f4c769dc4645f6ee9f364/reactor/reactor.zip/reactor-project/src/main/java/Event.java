package com.ticketbooking;

public interface Event {
    String getId();
    long getTimestamp();
}