package com.ticketbooking;

import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

public class BookingRequest implements Event {
    private static final AtomicLong counter = new AtomicLong(0);
    
    private final String id;
    private final String userId;
    private final String eventId;
    private final long timestamp;

    public BookingRequest(String userId, String eventId) {
        this.id = "booking-" + UUID.randomUUID();
        this.userId = userId;
        this.eventId = eventId;
        this.timestamp = counter.incrementAndGet();
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public long getTimestamp() {
        return timestamp;
    }

    public String getUserId() {
        return userId;
    }

    public String getEventId() {
        return eventId;
    }
}