package com.ticketbooking;

public class BookingModule {
    public String createBooking(String customerName, String event) {
        System.out.println("Creating booking for " + customerName + " for " + event);
        return "BOOKING_" + System.currentTimeMillis();
    }
}