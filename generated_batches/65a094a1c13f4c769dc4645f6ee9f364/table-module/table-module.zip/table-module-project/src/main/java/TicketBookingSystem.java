package com.ticketbooking;

public class TicketBookingSystem {
    public static void main(String[] args) {
        // Using Table-Module pattern with different modules
        BookingModule bookingModule = new BookingModule();
        PaymentModule paymentModule = new PaymentModule();
        NotificationModule notificationModule = new NotificationModule();
        
        // Process a ticket booking
        String bookingId = bookingModule.createBooking("John Doe", "Concert A");
        String paymentId = paymentModule.processPayment(bookingId, 50.0);
        notificationModule.sendConfirmation(bookingId, paymentId);
    }
}