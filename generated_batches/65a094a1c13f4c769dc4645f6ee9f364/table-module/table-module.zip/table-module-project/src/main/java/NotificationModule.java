package com.ticketbooking;

public class NotificationModule {
    public void sendConfirmation(String bookingId, String paymentId) {
        System.out.println("Sending confirmation for booking " + bookingId + 
                          " with payment " + paymentId);
    }
}