package com.ticketbooking;

public class PaymentModule {
    public String processPayment(String bookingId, double amount) {
        System.out.println("Processing payment of $" + amount + " for booking " + bookingId);
        return "PAYMENT_" + System.currentTimeMillis();
    }
}