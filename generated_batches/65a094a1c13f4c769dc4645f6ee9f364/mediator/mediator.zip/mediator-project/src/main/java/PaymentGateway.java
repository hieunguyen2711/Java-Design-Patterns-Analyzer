public class PaymentGateway {
    private Mediator mediator;
    
    public PaymentGateway(Mediator mediator) {
        this.mediator = mediator;
    }
    
    public void processPayment(String event, int quantity, User user) {
        System.out.println("Processing payment for " + quantity + " tickets to " + event);
        String message = "Payment successful for " + quantity + " tickets to " + event;
        mediator.sendNotification(message, user);
    }
}