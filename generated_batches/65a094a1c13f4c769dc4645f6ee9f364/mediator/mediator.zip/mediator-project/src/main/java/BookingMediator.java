import java.util.ArrayList;
import java.util.List;

public class BookingMediator implements Mediator {
    private List<User> users = new ArrayList<>();
    private PaymentGateway paymentGateway;
    private NotificationService notificationService;
    
    @Override
    public void registerUser(User user) {
        users.add(user);
    }
    
    @Override
    public void registerPaymentGateway(PaymentGateway paymentGateway) {
        this.paymentGateway = paymentGateway;
    }
    
    @Override
    public void registerNotificationService(NotificationService notificationService) {
        this.notificationService = notificationService;
    }
    
    @Override
    public void bookTicket(String event, int quantity, User user) {
        System.out.println("Booking " + quantity + " tickets for " + event);
        processPayment(event, quantity, user);
    }
    
    @Override
    public void processPayment(String event, int quantity, User user) {
        paymentGateway.processPayment(event, quantity, user);
    }
    
    @Override
    public void sendNotification(String message, User user) {
        notificationService.sendNotification(message, user);
    }
}