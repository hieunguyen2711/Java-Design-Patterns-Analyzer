public class TicketBookingSystem {
    public static void main(String[] args) {
        Mediator mediator = new BookingMediator();
        
        User user1 = new User("Alice", mediator);
        User user2 = new User("Bob", mediator);
        PaymentGateway paymentGateway = new PaymentGateway(mediator);
        NotificationService notificationService = new NotificationService(mediator);
        
        mediator.registerUser(user1);
        mediator.registerUser(user2);
        mediator.registerPaymentGateway(paymentGateway);
        mediator.registerNotificationService(notificationService);
        
        user1.bookTicket("Concert", 2);
    }
}