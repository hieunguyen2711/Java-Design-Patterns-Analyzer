public class User {
    private String name;
    private Mediator mediator;
    
    public User(String name, Mediator mediator) {
        this.name = name;
        this.mediator = mediator;
    }
    
    public void bookTicket(String event, int quantity) {
        mediator.bookTicket(event, quantity, this);
    }
    
    public String getName() {
        return name;
    }
}