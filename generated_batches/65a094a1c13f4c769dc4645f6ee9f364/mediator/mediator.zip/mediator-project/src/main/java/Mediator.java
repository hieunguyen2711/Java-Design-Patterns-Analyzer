import java.util.List;

public interface Mediator {
    void registerUser(User user);
    void registerPaymentGateway(PaymentGateway paymentGateway);
    void registerNotificationService(NotificationService notificationService);
    
    void bookTicket(String event, int quantity, User user);
    void processPayment(String event, int quantity, User user);
    void sendNotification(String message, User user);
}