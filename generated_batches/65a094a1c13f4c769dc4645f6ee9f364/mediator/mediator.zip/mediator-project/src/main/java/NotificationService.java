public class NotificationService {
    private Mediator mediator;
    
    public NotificationService(Mediator mediator) {
        this.mediator = mediator;
    }
    
    public void sendNotification(String message, User user) {
        System.out.println("Sending notification to " + user.getName() + ": " + message);
    }
}