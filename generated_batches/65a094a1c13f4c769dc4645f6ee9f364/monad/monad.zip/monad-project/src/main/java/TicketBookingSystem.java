package com.example.ticketbooking;

import java.util.Optional;
import java.util.function.Function;

public class TicketBookingSystem {
    public static void main(String[] args) {
        // Example usage of the monad pattern in ticket booking
        Optional<Ticket> result = Optional.of("user123")
                .map(User::new)
                .filter(user -> user.isValid())
                .map(user -> new BookingRequest(user, "Concert", 2))
                .flatMap(BookingService::bookTickets)
                .filter(ticket -> ticket.isConfirmed());

        result.ifPresent(ticket -> System.out.println("Booking confirmed: " + ticket.getEvent()));
    }
}