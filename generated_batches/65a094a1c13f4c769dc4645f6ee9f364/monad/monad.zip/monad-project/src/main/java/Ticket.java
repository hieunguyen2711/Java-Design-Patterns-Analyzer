package com.example.ticketbooking;

public class Ticket {
    private final String eventId;
    private final String userId;
    private final int quantity;
    private boolean confirmed = false;
    
    public Ticket(String eventId, String userId, int quantity) {
        this.eventId = eventId;
        this.userId = userId;
        this.quantity = quantity;
    }
    
    public void confirm() {
        this.confirmed = true;
    }
    
    public boolean isConfirmed() {
        return confirmed;
    }
    
    public String getEvent() {
        return eventId;
    }
    
    public String getUserId() {
        return userId;
    }
    
    public int getQuantity() {
        return quantity;
    }
}