package com.example.ticketbooking;

public class BookingRequest {
    private final User user;
    private final String event;
    private final int quantity;
    
    public BookingRequest(User user, String event, int quantity) {
        this.user = user;
        this.event = event;
        this.quantity = quantity;
    }
    
    public User getUser() {
        return user;
    }
    
    public String getEvent() {
        return event;
    }
    
    public int getQuantity() {
        return quantity;
    }
}