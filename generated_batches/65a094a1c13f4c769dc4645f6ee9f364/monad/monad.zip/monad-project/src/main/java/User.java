package com.example.ticketbooking;

public class User {
    private final String userId;
    
    public User(String userId) {
        this.userId = userId;
    }
    
    public boolean isValid() {
        return userId != null && !userId.isEmpty();
    }
    
    public String getUserId() {
        return userId;
    }
}