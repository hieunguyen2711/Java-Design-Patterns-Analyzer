package com.example.ticketbooking;

import java.util.Optional;

public class BookingService {
    public static Optional<Ticket> bookTickets(BookingRequest request) {
        if (request == null || request.getUser() == null) {
            return Optional.empty();
        }
        
        // Simulate booking logic
        Ticket ticket = new Ticket(request.getEvent(), request.getUser().getUserId(), request.getQuantity());
        ticket.confirm();
        
        return Optional.of(ticket);
    }
}