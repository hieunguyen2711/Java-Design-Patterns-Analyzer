public class TicketBookingSystem {
    public static void main(String[] args) {
        try (TicketProcessor processor = new TicketProcessor()) {
            processor.processTicket("VIP-123");
            processor.processTicket("Regular-456");
        } catch (Exception e) {
            System.err.println("Error processing tickets: " + e.getMessage());
        }
    }
}