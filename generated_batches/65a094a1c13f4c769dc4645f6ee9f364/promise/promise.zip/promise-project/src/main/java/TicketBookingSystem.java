package com.example.ticketbooking;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TicketBookingSystem {
    private final ExecutorService executor = Executors.newFixedThreadPool(2);
    
    public CompletableFuture<Ticket> bookTicket(String eventId, String userId) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                // Simulate booking process
                Thread.sleep(1000);
                return new Ticket(eventId, userId, "CONFIRMED");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new RuntimeException(e);
            }
        }, executor);
    }
    
    public void shutdown() {
        executor.shutdown();
    }
}