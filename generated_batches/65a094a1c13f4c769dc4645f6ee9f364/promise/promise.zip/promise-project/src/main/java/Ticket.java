package com.example.ticketbooking;

public class Ticket {
    private final String eventId;
    private final String userId;
    private final String status;
    
    public Ticket(String eventId, String userId, String status) {
        this.eventId = eventId;
        this.userId = userId;
        this.status = status;
    }
    
    public String getEventId() {
        return eventId;
    }
    
    public String getUserId() {
        return userId;
    }
    
    public String getStatus() {
        return status;
    }
}