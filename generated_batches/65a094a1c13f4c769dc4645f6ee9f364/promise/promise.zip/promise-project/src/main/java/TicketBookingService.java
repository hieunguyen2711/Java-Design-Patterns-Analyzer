package com.example.ticketbooking;

import java.util.concurrent.CompletableFuture;

public class TicketBookingService {
    private final TicketBookingSystem bookingSystem = new TicketBookingSystem();
    
    public CompletableFuture<Ticket> bookTicketAsync(String eventId, String userId) {
        return bookingSystem.bookTicket(eventId, userId)
                .thenApply(ticket -> {
                    System.out.println("Processing ticket: " + ticket.getEventId());
                    return ticket;
                })
                .exceptionally(throwable -> {
                    System.err.println("Booking failed: " + throwable.getMessage());
                    return null;
                });
    }
    
    public void shutdown() {
        bookingSystem.shutdown();
    }
}