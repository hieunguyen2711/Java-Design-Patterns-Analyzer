package com.example.ticketbooking;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class Main {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        TicketBookingService service = new TicketBookingService();
        
        CompletableFuture<Ticket> ticket1 = service.bookTicketAsync("EVENT001", "USER001");
        CompletableFuture<Ticket> ticket2 = service.bookTicketAsync("EVENT002", "USER002");
        
        // Wait for both bookings to complete
        CompletableFuture.allOf(ticket1, ticket2).join();
        
        Ticket result1 = ticket1.get();
        Ticket result2 = ticket2.get();
        
        System.out.println("Booking 1: " + result1.getStatus());
        System.out.println("Booking 2: " + result2.getStatus());
        
        service.shutdown();
    }
}