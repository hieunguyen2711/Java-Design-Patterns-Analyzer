public interface Expression {
    boolean interpret(BookingContext context);
}