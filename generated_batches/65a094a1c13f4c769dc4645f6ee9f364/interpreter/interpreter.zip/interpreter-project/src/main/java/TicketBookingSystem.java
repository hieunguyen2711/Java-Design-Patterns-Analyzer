public class TicketBookingSystem {
    public static void main(String[] args) {
        // Create expression for booking premium tickets
        Expression premiumExpression = new AndExpression(
            new TypeExpression("premium"),
            new QuantityExpression(2)
        );
        
        // Create expression for booking regular tickets with discount
        Expression discountExpression = new OrExpression(
            new TypeExpression("regular"),
            new DiscountExpression(10)
        );
        
        BookingContext context = new BookingContext();
        context.setTicketType("premium");
        context.setQuantity(2);
        context.setDiscount(0);
        
        // Evaluate expressions
        System.out.println("Premium booking valid: " + premiumExpression.interpret(context));
        
        context.setTicketType("regular");
        context.setQuantity(1);
        context.setDiscount(5);
        
        System.out.println("Regular booking with discount valid: " + discountExpression.interpret(context));
    }
}