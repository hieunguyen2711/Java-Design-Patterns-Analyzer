public class DiscountExpression implements Expression {
    private int discountThreshold;
    
    public DiscountExpression(int discountThreshold) {
        this.discountThreshold = discountThreshold;
    }
    
    @Override
    public boolean interpret(BookingContext context) {
        return context.getDiscount() >= discountThreshold;
    }
}