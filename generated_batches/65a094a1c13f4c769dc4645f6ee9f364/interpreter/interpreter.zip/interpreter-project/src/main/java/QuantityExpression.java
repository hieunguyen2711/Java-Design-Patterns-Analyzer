public class QuantityExpression implements Expression {
    private int quantity;
    
    public QuantityExpression(int quantity) {
        this.quantity = quantity;
    }
    
    @Override
    public boolean interpret(BookingContext context) {
        return context.getQuantity() >= quantity;
    }
}