public class TypeExpression implements Expression {
    private String type;
    
    public TypeExpression(String type) {
        this.type = type;
    }
    
    @Override
    public boolean interpret(BookingContext context) {
        return type.equals(context.getTicketType());
    }
}