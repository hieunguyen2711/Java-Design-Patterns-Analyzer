public class Ticket {
    private String id;
    private String event;
    private String seatNumber;
    
    public Ticket(String id, String event, String seatNumber) {
        this.id = id;
        this.event = event;
        this.seatNumber = seatNumber;
    }
    
    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getEvent() { return event; }
    public void setEvent(String event) { this.event = event; }
    
    public String getSeatNumber() { return seatNumber; }
    public void setSeatNumber(String seatNumber) { this.seatNumber = seatNumber; }
    
    @Override
    public String toString() {
        return "Ticket{id='" + id + "', event='" + event + "', seatNumber='" + seatNumber + "'}";
    }
}