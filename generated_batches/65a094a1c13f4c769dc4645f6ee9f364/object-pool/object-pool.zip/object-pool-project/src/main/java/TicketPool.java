import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;

public class TicketPool {
    private static volatile TicketPool instance;
    private final ConcurrentLinkedQueue<Ticket> pool;
    private final AtomicInteger activeTickets;
    
    private TicketPool() {
        this.pool = new ConcurrentLinkedQueue<>();
        this.activeTickets = new AtomicInteger(0);
        
        // Initialize with some tickets
        for (int i = 1; i <= 5; i++) {
            pool.offer(new Ticket("T" + i, "Concert", "S" + i));
        }
    }
    
    public static TicketPool getInstance() {
        if (instance == null) {
            synchronized (TicketPool.class) {
                if (instance == null) {
                    instance = new TicketPool();
                }
            }
        }
        return instance;
    }
    
    public Ticket acquireTicket(String event, String seatNumber) {
        Ticket ticket = pool.poll();
        if (ticket == null) {
            // Create new ticket if pool is empty
            ticket = new Ticket("T" + (activeTickets.incrementAndGet() + 5), event, seatNumber);
        } else {
            // Reset ticket properties
            ticket.setEvent(event);
            ticket.setSeatNumber(seatNumber);
        }
        return ticket;
    }
    
    public void releaseTicket(Ticket ticket) {
        if (ticket != null && pool.size() < 10) { // Pool size limit
            pool.offer(ticket);
        }
    }
}