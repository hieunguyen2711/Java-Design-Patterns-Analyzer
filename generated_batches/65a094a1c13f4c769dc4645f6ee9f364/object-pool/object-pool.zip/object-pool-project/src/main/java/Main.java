public class Main {
    public static void main(String[] args) {
        TicketPool pool = TicketPool.getInstance();
        BookingService service = new BookingService(pool);
        
        // Book some tickets
        Ticket t1 = service.bookTicket("Concert", "A1");
        Ticket t2 = service.bookTicket("Movie", "B2");
        Ticket t3 = service.bookTicket("Theater", "C3");
        
        System.out.println("Acquired tickets: " + t1 + ", " + t2 + ", " + t3);
        
        // Complete some bookings
        service.completeBooking(t1);
        service.completeBooking(t2);
        
        // Book more tickets to demonstrate pool reuse
        Ticket t4 = service.bookTicket("Sports", "D4");
        Ticket t5 = service.bookTicket("Conference", "E5");
        
        System.out.println("Reused tickets: " + t4 + ", " + t5);
    }
}