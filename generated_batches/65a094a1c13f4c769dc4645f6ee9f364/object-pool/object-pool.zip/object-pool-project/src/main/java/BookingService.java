public class BookingService {
    private TicketPool ticketPool;
    
    public BookingService(TicketPool ticketPool) {
        this.ticketPool = ticketPool;
    }
    
    public Ticket bookTicket(String event, String seatNumber) {
        System.out.println("Booking ticket for " + event + " at seat " + seatNumber);
        return ticketPool.acquireTicket(event, seatNumber);
    }
    
    public void completeBooking(Ticket ticket) {
        System.out.println("Completing booking: " + ticket);
        ticketPool.releaseTicket(ticket);
    }
}