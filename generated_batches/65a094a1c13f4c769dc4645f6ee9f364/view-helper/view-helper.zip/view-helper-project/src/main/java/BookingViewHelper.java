public class BookingViewHelper {
    
    public String generateBookingSummary(Ticket ticket) {
        StringBuilder summary = new StringBuilder();
        summary.append("=== BOOKING SUMMARY ===\n");
        summary.append("Event: ").append(ticket.getEventName()).append("\n");
        summary.append("Category: ").append(formatCategory(ticket.getCategory())).append("\n");
        summary.append("Price: $").append(String.format("%.2f", ticket.getPrice())).append("\n");
        summary.append("======================\n");
        return summary.toString();
    }
    
    private String formatCategory(String category) {
        switch (category.toLowerCase()) {
            case "vip":
                return "VIP - Premium Seating";
            case "standard":
                return "Standard - Regular Seating";
            default:
                return category;
        }
    }
}