public class TicketBookingSystem {
    public static void main(String[] args) {
        BookingViewHelper helper = new BookingViewHelper();
        
        // Simulate booking process
        Ticket ticket1 = new Ticket("Concert", "VIP", 150.0);
        Ticket ticket2 = new Ticket("Movie", "Standard", 25.0);
        
        System.out.println(helper.generateBookingSummary(ticket1));
        System.out.println(helper.generateBookingSummary(ticket2));
    }
}