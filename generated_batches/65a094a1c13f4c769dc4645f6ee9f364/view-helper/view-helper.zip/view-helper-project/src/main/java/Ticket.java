public class Ticket {
    private String eventName;
    private String category;
    private double price;
    
    public Ticket(String eventName, String category, double price) {
        this.eventName = eventName;
        this.category = category;
        this.price = price;
    }
    
    public String getEventName() {
        return eventName;
    }
    
    public String getCategory() {
        return category;
    }
    
    public double getPrice() {
        return price;
    }
}