public class ModernPaymentProcessor implements PaymentProcessor {
    @Override
    public void processPayment(double amount) {
        System.out.println("Modern payment processed for $" + amount);
    }
}