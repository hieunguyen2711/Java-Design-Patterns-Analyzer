public class LegacyPaymentAdapter implements PaymentProcessor {
    private LegacyPaymentSystem legacySystem;
    
    public LegacyPaymentAdapter() {
        this.legacySystem = new LegacyPaymentSystem();
    }
    
    @Override
    public void processPayment(double amount) {
        legacySystem.makePayment(amount);
    }
}