public class TicketBookingSystem {
    public static void main(String[] args) {
        // Using the legacy payment system through the adapter
        PaymentProcessor legacyPayment = new LegacyPaymentAdapter();
        legacyPayment.processPayment(100.0);
        
        // Using the modern payment system directly
        ModernPaymentProcessor modernPayment = new ModernPaymentProcessor();
        modernPayment.processPayment(200.0);
    }
}