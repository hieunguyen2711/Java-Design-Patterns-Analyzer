public class LegacyPaymentSystem {
    public void makePayment(double amount) {
        System.out.println("Legacy payment processed for $" + amount);
    }
}