package com.example.ticketbooking;

import java.util.List;
import java.util.function.Function;

public class BookingCombinator {
    // Combinator that creates a function to combine different booking options
    public static Function<Ticket, List<String>> createBookingOptions() {
        return ticket -> List.of(
            "Standard: $" + ticket.getBasePrice(),
            "Premium: $" + (ticket.getBasePrice() * 1.5),
            "VIP: $" + (ticket.getBasePrice() * 2.0)
        );
    }
    
    // Another combinator that applies different discounts
    public static Function<Ticket, List<String>> createDiscountedOptions(double discount) {
        return ticket -> List.of(
            "Standard with " + (discount * 100) + "%: $" + (ticket.getBasePrice() * (1 - discount)),
            "Premium with " + (discount * 100) + "%: $" + (ticket.getBasePrice() * 1.5 * (1 - discount))
        );
    }
}