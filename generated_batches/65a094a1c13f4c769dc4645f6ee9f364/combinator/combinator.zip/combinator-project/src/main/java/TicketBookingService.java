package com.example.ticketbooking;

import java.util.List;
import java.util.function.Function;

public class TicketBookingService {
    private Function<Ticket, List<String>> bookingCombinator;
    
    public TicketBookingService(Function<Ticket, List<String>> combinator) {
        this.bookingCombinator = combinator;
    }
    
    public List<String> getBookingOptions(Ticket ticket) {
        return bookingCombinator.apply(ticket);
    }
}