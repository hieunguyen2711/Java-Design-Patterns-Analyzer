public interface Ticket {
    void book();
}