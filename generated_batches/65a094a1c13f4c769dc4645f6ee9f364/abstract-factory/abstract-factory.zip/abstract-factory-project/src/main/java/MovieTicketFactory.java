public class MovieTicketFactory extends TicketFactory {
    @Override
    public Ticket createTicket() {
        return new MovieTicket();
    }
}