public class MovieTicket implements Ticket {
    @Override
    public void book() {
        System.out.println("Movie ticket booked successfully");
    }
}