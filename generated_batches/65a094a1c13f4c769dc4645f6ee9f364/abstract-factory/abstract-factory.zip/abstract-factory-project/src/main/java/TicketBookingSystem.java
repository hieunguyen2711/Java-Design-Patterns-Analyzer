public class TicketBookingSystem {
    public static void main(String[] args) {
        // Book concert tickets using concert factory
        TicketFactory concertFactory = new ConcertTicketFactory();
        Ticket ticket1 = concertFactory.createTicket();
        ticket1.book();
        
        // Book movie tickets using movie factory
        TicketFactory movieFactory = new MovieTicketFactory();
        Ticket ticket2 = movieFactory.createTicket();
        ticket2.book();
    }
}