public class ConcertTicket implements Ticket {
    @Override
    public void book() {
        System.out.println("Concert ticket booked successfully");
    }
}