public class ConcertTicketFactory extends TicketFactory {
    @Override
    public Ticket createTicket() {
        return new ConcertTicket();
    }
}