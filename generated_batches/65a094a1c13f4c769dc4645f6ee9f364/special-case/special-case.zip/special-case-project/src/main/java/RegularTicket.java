package com.example.ticketbooking;

public class RegularTicket extends Ticket {
    public RegularTicket(String id, String movieName, double basePrice) {
        super(id, movieName, basePrice);
    }
    
    @Override
    public String getTicketDetails() {
        return "Regular ticket for " + movieName + " (ID: " + id + ")";
    }
}