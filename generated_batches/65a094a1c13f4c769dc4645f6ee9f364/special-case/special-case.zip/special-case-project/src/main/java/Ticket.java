package com.example.ticketbooking;

public abstract class Ticket {
    protected String id;
    protected String movieName;
    protected double basePrice;
    
    public Ticket(String id, String movieName, double basePrice) {
        this.id = id;
        this.movieName = movieName;
        this.basePrice = basePrice;
    }
    
    public abstract String getTicketDetails();
    
    public double calculateFinalPrice() {
        return basePrice;
    }
}