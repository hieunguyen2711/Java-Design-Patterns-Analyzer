package com.example.ticketbooking;

public class TicketBookingSystem {
    public static void main(String[] args) {
        // Test different ticket types
        Ticket regularTicket = new RegularTicket("T123", "Movie A", 100.0);
        Ticket premiumTicket = new PremiumTicket("P456", "Movie B", 200.0, true);
        Ticket discountTicket = new DiscountTicket("D789", "Movie C", 50.0, 0.2);
        
        // Test special case handling
        Ticket invalidTicket = new InvalidTicket();
        
        System.out.println("Regular ticket: " + regularTicket.getTicketDetails());
        System.out.println("Premium ticket: " + premiumTicket.getTicketDetails());
        System.out.println("Discount ticket: " + discountTicket.getTicketDetails());
        System.out.println("Invalid ticket: " + invalidTicket.getTicketDetails());
    }
}