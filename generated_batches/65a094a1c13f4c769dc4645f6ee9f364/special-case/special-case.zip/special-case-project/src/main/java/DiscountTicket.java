package com.example.ticketbooking;

public class DiscountTicket extends Ticket {
    private double discountRate;
    
    public DiscountTicket(String id, String movieName, double basePrice, double discountRate) {
        super(id, movieName, basePrice);
        this.discountRate = discountRate;
    }
    
    @Override
    public String getTicketDetails() {
        return "Discount ticket for " + movieName + " (ID: " + id + 
               ", Discount: " + (discountRate * 100) + "%)";
    }
    
    @Override
    public double calculateFinalPrice() {
        return basePrice * (1 - discountRate);
    }
}