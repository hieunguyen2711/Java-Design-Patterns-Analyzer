package com.example.ticketbooking;

public class PremiumTicket extends Ticket {
    private boolean hasVipAccess;
    
    public PremiumTicket(String id, String movieName, double basePrice, boolean hasVipAccess) {
        super(id, movieName, basePrice);
        this.hasVipAccess = hasVipAccess;
    }
    
    @Override
    public String getTicketDetails() {
        return "Premium ticket for " + movieName + " (ID: " + id + 
               ", VIP Access: " + (hasVipAccess ? "Yes" : "No") + ")";
    }
    
    @Override
    public double calculateFinalPrice() {
        return basePrice * 1.5; // Premium tickets cost 50% more
    }
}