package com.example.ticketbooking;

public class InvalidTicket extends Ticket {
    public InvalidTicket() {
        super("INVALID", "Invalid Ticket", 0.0);
    }
    
    @Override
    public String getTicketDetails() {
        return "Special case - Invalid ticket";
    }
    
    @Override
    public double calculateFinalPrice() {
        // Special case: invalid tickets have no price
        return 0.0;
    }
}