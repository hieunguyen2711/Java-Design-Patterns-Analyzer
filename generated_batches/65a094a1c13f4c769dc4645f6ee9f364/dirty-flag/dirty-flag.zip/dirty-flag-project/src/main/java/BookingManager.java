package com.example.booking;

public class BookingManager {
    public Booking createBooking(String customerName, String eventId) {
        return new Booking(customerName, eventId);
    }
    
    public void saveBooking(Booking booking) {
        // In a real system, this would persist to database
        System.out.println("Saving booking for " + booking.getCustomerName());
        
        // Clear the dirty flag after saving
        booking.clearDirtyFlag();
    }
}