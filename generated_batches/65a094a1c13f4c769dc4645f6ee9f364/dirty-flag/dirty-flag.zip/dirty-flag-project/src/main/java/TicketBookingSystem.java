package com.example.booking;

public class TicketBookingSystem {
    public static void main(String[] args) {
        BookingManager manager = new BookingManager();
        
        // Create a booking
        Booking booking = manager.createBooking("John Doe", "Movie123");
        
        // Modify booking details (dirty flag will be set)
        booking.setSeatNumber("A15");
        booking.setPrice(15.50);
        
        // Check if booking is dirty before saving
        System.out.println("Is booking dirty? " + booking.isDirty());
        
        // Save the booking (clears dirty flag)
        manager.saveBooking(booking);
        
        // Check if booking is dirty after save
        System.out.println("Is booking dirty after save? " + booking.isDirty());
    }
}