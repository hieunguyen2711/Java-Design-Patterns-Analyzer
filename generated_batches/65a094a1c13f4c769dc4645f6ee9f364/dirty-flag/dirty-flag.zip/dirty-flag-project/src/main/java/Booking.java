package com.example.booking;

public class Booking {
    private String customerName;
    private String eventId;
    private String seatNumber;
    private double price;
    private boolean isDirty = false;
    
    public Booking(String customerName, String eventId) {
        this.customerName = customerName;
        this.eventId = eventId;
    }
    
    public String getCustomerName() {
        return customerName;
    }
    
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
        markDirty();
    }
    
    public String getEventId() {
        return eventId;
    }
    
    public String getSeatNumber() {
        return seatNumber;
    }
    
    public void setSeatNumber(String seatNumber) {
        this.seatNumber = seatNumber;
        markDirty();
    }
    
    public double getPrice() {
        return price;
    }
    
    public void setPrice(double price) {
        this.price = price;
        markDirty();
    }
    
    public boolean isDirty() {
        return isDirty;
    }
    
    private void markDirty() {
        this.isDirty = true;
    }
    
    public void clearDirtyFlag() {
        this.isDirty = false;
    }
}