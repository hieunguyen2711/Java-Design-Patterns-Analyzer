public abstract class Ticket {
    protected String ticketId;
    protected double basePrice;
    
    public Ticket(String ticketId, double basePrice) {
        this.ticketId = ticketId;
        this.basePrice = basePrice;
    }
    
    public abstract void updatePrice(double newPrice);
    
    public abstract double calculateFinalPrice();
    
    public String getTicketId() {
        return ticketId;
    }
}