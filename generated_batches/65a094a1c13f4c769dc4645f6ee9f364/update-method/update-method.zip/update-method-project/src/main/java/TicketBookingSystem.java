public class TicketBookingSystem {
    public static void main(String[] args) {
        BookingService bookingService = new BookingService();
        
        // Create tickets using different strategies
        Ticket ticket1 = new StandardTicket("VIP-001", 150.0);
        Ticket ticket2 = new PremiumTicket("PREM-001", 300.0);
        
        // Book tickets with different update methods
        bookingService.bookTicket(ticket1);
        bookingService.bookTicket(ticket2);
        
        System.out.println("Booking completed successfully!");
    }
}