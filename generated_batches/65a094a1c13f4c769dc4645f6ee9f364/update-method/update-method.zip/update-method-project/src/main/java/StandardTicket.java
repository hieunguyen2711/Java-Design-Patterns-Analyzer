public class StandardTicket extends Ticket {
    private double discount;
    
    public StandardTicket(String ticketId, double basePrice) {
        super(ticketId, basePrice);
        this.discount = 0.1; // 10% discount
    }
    
    @Override
    public void updatePrice(double newPrice) {
        this.basePrice = newPrice;
        System.out.println("Standard ticket price updated to: $" + newPrice);
    }
    
    @Override
    public double calculateFinalPrice() {
        return basePrice * (1 - discount);
    }
}