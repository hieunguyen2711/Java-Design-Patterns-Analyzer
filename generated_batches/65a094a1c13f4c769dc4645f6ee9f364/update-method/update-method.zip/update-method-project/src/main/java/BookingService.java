public class BookingService {
    public void bookTicket(Ticket ticket) {
        System.out.println("Booking ticket ID: " + ticket.getTicketId());
        
        // Using update method to modify price before booking
        if (ticket instanceof StandardTicket) {
            ((StandardTicket) ticket).updatePrice(140.0);
        } else if (ticket instanceof PremiumTicket) {
            ((PremiumTicket) ticket).updatePrice(320.0);
        }
        
        double finalPrice = ticket.calculateFinalPrice();
        System.out.println("Final price: $" + finalPrice);
    }
}