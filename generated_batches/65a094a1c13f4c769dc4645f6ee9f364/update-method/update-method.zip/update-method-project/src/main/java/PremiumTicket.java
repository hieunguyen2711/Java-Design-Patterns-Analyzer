public class PremiumTicket extends Ticket {
    private double premiumSurcharge;
    
    public PremiumTicket(String ticketId, double basePrice) {
        super(ticketId, basePrice);
        this.premiumSurcharge = 0.25; // 25% surcharge
    }
    
    @Override
    public void updatePrice(double newPrice) {
        this.basePrice = newPrice;
        System.out.println("Premium ticket price updated to: $" + newPrice);
    }
    
    @Override
    public double calculateFinalPrice() {
        return basePrice * (1 + premiumSurcharge);
    }
}