package com.example.ticketbooking;

public class TicketBookingSystem {
    public static void main(String[] args) {
        // Using the builder pattern to create tickets
        Ticket regularTicket = new Ticket.Builder()
                .setEventId("EVT001")
                .setEventName("Concert Night")
                .setSeatNumber("A12")
                .setPrice(85.50)
                .setCustomerName("John Doe")
                .build();
        
        Ticket vipTicket = new Ticket.Builder()
                .setEventId("EVT002")
                .setEventName("VIP Gala Dinner")
                .setSeatNumber("V10")
                .setPrice(350.00)
                .setIsVip(true)
                .setCustomerName("Jane Smith")
                .build();
        
        System.out.println(regularTicket);
        System.out.println(vipTicket);
    }
}