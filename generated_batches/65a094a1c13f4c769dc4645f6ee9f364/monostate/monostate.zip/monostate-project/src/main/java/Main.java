public class Main {
    public static void main(String[] args) {
        // Create multiple booking agents that share the same state
        BookingAgent agent1 = new BookingAgent("Agent A");
        BookingAgent agent2 = new BookingAgent("Agent B");
        BookingAgent agent3 = new BookingAgent("Agent C");
        
        // All agents access the same shared instance
        agent1.showStatus();
        System.out.println();
        
        agent1.bookTickets(50);
        System.out.println();
        
        agent2.showStatus();
        System.out.println();
        
        agent2.bookTickets(300);
        System.out.println();
        
        agent3.showStatus();
        System.out.println();
        
        agent3.bookTickets(700);
        System.out.println();
        
        agent1.showStatus();
    }
}