public class TicketBookingSystem {
    private static TicketBookingSystem instance;
    
    private int totalTickets = 1000;
    private int bookedTickets = 0;
    
    // Private constructor to prevent instantiation
    private TicketBookingSystem() {}
    
    public static synchronized TicketBookingSystem getInstance() {
        if (instance == null) {
            instance = new TicketBookingSystem();
        }
        return instance;
    }
    
    public boolean bookTicket(int numberOfTickets) {
        if (bookedTickets + numberOfTickets <= totalTickets) {
            bookedTickets += numberOfTickets;
            System.out.println("Booked " + numberOfTickets + " tickets. Total booked: " + bookedTickets);
            return true;
        } else {
            System.out.println("Not enough tickets available. Available: " + 
                             (totalTickets - bookedTickets));
            return false;
        }
    }
    
    public int getAvailableTickets() {
        return totalTickets - bookedTickets;
    }
    
    public int getTotalTickets() {
        return totalTickets;
    }
}