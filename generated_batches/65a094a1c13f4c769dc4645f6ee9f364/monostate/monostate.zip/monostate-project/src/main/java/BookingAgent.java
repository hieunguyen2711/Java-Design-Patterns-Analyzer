public class BookingAgent {
    private String agentName;
    
    public BookingAgent(String agentName) {
        this.agentName = agentName;
    }
    
    public void bookTickets(int numberOfTickets) {
        TicketBookingSystem system = TicketBookingSystem.getInstance();
        System.out.println(agentName + " is attempting to book " + numberOfTickets + " tickets");
        system.bookTicket(numberOfTickets);
    }
    
    public void showStatus() {
        TicketBookingSystem system = TicketBookingSystem.getInstance();
        System.out.println("Agent: " + agentName);
        System.out.println("Available tickets: " + system.getAvailableTickets());
        System.out.println("Total tickets: " + system.getTotalTickets());
    }
}