public class Main {
    public static void main(String[] args) {
        // Test double-checked locking pattern
        TicketBookingSystem system1 = TicketBookingSystem.getInstance();
        TicketBookingSystem system2 = TicketBookingSystem.getInstance();
        
        System.out.println("Same instance: " + (system1 == system2));
        
        system1.bookTicket("T001", "John Doe");
        system2.bookTicket("T002", "Jane Smith");
    }
}