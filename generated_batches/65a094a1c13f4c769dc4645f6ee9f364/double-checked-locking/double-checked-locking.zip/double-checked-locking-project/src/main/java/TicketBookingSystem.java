public class TicketBookingSystem {
    private static volatile TicketBookingSystem instance;
    
    private TicketBookingSystem() {
        // Private constructor to prevent instantiation
    }
    
    public static TicketBookingSystem getInstance() {
        if (instance == null) {
            synchronized (TicketBookingSystem.class) {
                if (instance == null) {
                    instance = new TicketBookingSystem();
                }
            }
        }
        return instance;
    }
    
    public boolean bookTicket(String ticketId, String customerName) {
        // Simulate booking logic
        System.out.println("Booking ticket " + ticketId + " for " + customerName);
        return true;
    }
}