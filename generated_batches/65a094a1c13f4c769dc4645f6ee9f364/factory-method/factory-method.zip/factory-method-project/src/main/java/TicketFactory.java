public abstract class TicketFactory {
    public abstract Ticket createTicket(String ticketType, int quantity);
}