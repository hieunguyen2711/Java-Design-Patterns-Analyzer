public class ConcertTicketFactory extends TicketFactory {
    @Override
    public Ticket createTicket(String ticketType, int quantity) {
        switch (ticketType.toLowerCase()) {
            case "vip":
                return new ConcertTicket("VIP", 80.0, "The Beatles");
            case "regular":
                return new ConcertTicket("Regular", 40.0, "The Beatles");
            default:
                throw new IllegalArgumentException("Unknown ticket type: " + ticketType);
        }
    }
}