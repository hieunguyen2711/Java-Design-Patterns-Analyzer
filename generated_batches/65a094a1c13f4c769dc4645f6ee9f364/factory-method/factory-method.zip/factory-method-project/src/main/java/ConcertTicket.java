public class ConcertTicket extends Ticket {
    private String artist;
    
    public ConcertTicket(String type, double price, String artist) {
        super(type, price);
        this.artist = artist;
    }
    
    @Override
    public void displayDetails() {
        System.out.println("Artist: " + artist + ", Type: " + type + ", Price: $" + price);
    }
}