public class MovieTicket extends Ticket {
    private String movieName;
    
    public MovieTicket(String type, double price, String movieName) {
        super(type, price);
        this.movieName = movieName;
    }
    
    @Override
    public void displayDetails() {
        System.out.println("Movie: " + movieName + ", Type: " + type + ", Price: $" + price);
    }
}