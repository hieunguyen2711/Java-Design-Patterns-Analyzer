public class TicketBookingSystem {
    public static void main(String[] args) {
        TicketFactory factory = new MovieTicketFactory();
        Ticket ticket1 = factory.createTicket("VIP", 100);
        
        factory = new ConcertTicketFactory();
        Ticket ticket2 = factory.createTicket("Regular", 50);
        
        System.out.println(ticket1.getType() + " - $" + ticket1.getPrice());
        System.out.println(ticket2.getType() + " - $" + ticket2.getPrice());
    }
}