public abstract class Ticket {
    protected String type;
    protected double price;
    
    public Ticket(String type, double price) {
        this.type = type;
        this.price = price;
    }
    
    public String getType() {
        return type;
    }
    
    public double getPrice() {
        return price;
    }
    
    public abstract void displayDetails();
}