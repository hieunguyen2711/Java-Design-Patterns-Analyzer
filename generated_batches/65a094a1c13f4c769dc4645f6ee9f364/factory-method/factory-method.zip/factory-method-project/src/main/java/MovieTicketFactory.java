public class MovieTicketFactory extends TicketFactory {
    @Override
    public Ticket createTicket(String ticketType, int quantity) {
        switch (ticketType.toLowerCase()) {
            case "vip":
                return new MovieTicket("VIP", 25.0, "The Matrix");
            case "regular":
                return new MovieTicket("Regular", 15.0, "The Matrix");
            default:
                throw new IllegalArgumentException("Unknown ticket type: " + ticketType);
        }
    }
}