public class Ticket {
    private String eventId;
    private String seatNumber;
    private double price;

    public Ticket(String eventId, String seatNumber, double price) {
        this.eventId = eventId;
        this.seatNumber = seatNumber;
        this.price = price;
    }

    public String getEventId() {
        return eventId;
    }

    public String getSeatNumber() {
        return seatNumber;
    }

    public double getPrice() {
        return price;
    }
}