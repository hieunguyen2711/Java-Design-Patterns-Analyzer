public class Main {
    public static void main(String[] args) {
        TicketBookingSystem bookingSystem = new TicketBookingSystem();
        
        bookingSystem.addTicket(new Ticket("E001", "A1", 50.0));
        bookingSystem.addTicket(new Ticket("E001", "A2", 50.0));
        bookingSystem.addTicket(new Ticket("E002", "B1", 75.0));
        
        System.out.println("Iterating through tickets:");
        Iterator<Ticket> iterator = bookingSystem.getTicketsIterator();
        while (iterator.hasNext()) {
            Ticket ticket = iterator.next();
            System.out.println("Event: " + ticket.getEventId() + 
                             ", Seat: " + ticket.getSeatNumber() + 
                             ", Price: $" + ticket.getPrice());
        }
    }
}