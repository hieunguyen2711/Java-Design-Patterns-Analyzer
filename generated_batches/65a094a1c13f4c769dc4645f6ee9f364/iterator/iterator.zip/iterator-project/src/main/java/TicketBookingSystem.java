import java.util.*;

public class TicketBookingSystem {
    private List<Ticket> tickets;

    public TicketBookingSystem() {
        this.tickets = new ArrayList<>();
    }

    public void addTicket(Ticket ticket) {
        tickets.add(ticket);
    }

    public Iterator<Ticket> getTicketsIterator() {
        return tickets.iterator();
    }
}