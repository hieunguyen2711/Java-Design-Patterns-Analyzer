public class FoodBundle extends TicketDecorator {
    public FoodBundle(Ticket ticket) {
        super(ticket);
    }
    
    @Override
    public double getPrice() {
        return ticket.getPrice() + 30.0;
    }
    
    @Override
    public String getDescription() {
        return ticket.getDescription() + " with food bundle";
    }
}