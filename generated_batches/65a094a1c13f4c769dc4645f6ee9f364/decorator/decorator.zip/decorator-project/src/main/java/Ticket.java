public interface Ticket {
    double getPrice();
    String getDescription();
}