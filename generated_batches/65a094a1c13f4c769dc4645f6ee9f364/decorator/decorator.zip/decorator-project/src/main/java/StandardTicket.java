public class StandardTicket implements Ticket {
    private final double basePrice = 100.0;
    
    @Override
    public double getPrice() {
        return basePrice;
    }
    
    @Override
    public String getDescription() {
        return "Standard ticket";
    }
}