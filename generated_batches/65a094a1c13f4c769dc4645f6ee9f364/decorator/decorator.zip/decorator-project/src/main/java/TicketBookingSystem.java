public class TicketBookingSystem {
    public static void main(String[] args) {
        // Create a standard ticket
        Ticket ticket = new StandardTicket();
        System.out.println(ticket.getDescription() + ": $" + ticket.getPrice());
        
        // Add premium seating to the ticket
        ticket = new PremiumSeating(ticket);
        System.out.println(ticket.getDescription() + ": $" + ticket.getPrice());
        
        // Add food bundle to the ticket
        ticket = new FoodBundle(ticket);
        System.out.println(ticket.getDescription() + ": $" + ticket.getPrice());
    }
}