public class PremiumSeating extends TicketDecorator {
    public PremiumSeating(Ticket ticket) {
        super(ticket);
    }
    
    @Override
    public double getPrice() {
        return ticket.getPrice() + 50.0;
    }
    
    @Override
    public String getDescription() {
        return ticket.getDescription() + " with premium seating";
    }
}