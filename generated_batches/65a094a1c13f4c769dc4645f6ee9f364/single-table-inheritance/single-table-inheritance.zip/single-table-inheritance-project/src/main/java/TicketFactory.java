package com.example.ticketbooking;

public class TicketFactory {
    public static Ticket createTicket(String type, String id, double price, String details) {
        switch (type.toLowerCase()) {
            case "regular":
                return new RegularTicket(id, price, details);
            case "vip":
                return new VIPTicket(id, price, details);
            default:
                throw new IllegalArgumentException("Unknown ticket type: " + type);
        }
    }
}