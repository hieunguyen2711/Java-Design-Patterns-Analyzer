package com.example.ticketbooking;

public abstract class Ticket {
    protected String id;
    protected double price;
    protected boolean isBooked;
    
    public Ticket(String id, double price) {
        this.id = id;
        this.price = price;
        this.isBooked = false;
    }
    
    public abstract void book();
    
    public abstract void cancel();
    
    public String getId() {
        return id;
    }
    
    public double getPrice() {
        return price;
    }
    
    public boolean isBooked() {
        return isBooked;
    }
}