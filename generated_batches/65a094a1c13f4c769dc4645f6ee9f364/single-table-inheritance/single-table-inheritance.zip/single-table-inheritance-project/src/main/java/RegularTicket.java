package com.example.ticketbooking;

public class RegularTicket extends Ticket {
    private String seatNumber;
    
    public RegularTicket(String id, double price, String seatNumber) {
        super(id, price);
        this.seatNumber = seatNumber;
    }
    
    @Override
    public void book() {
        if (!isBooked) {
            isBooked = true;
            System.out.println("Regular ticket " + id + " booked with seat " + seatNumber);
        }
    }
    
    @Override
    public void cancel() {
        if (isBooked) {
            isBooked = false;
            System.out.println("Regular ticket " + id + " cancelled");
        }
    }
    
    public String getSeatNumber() {
        return seatNumber;
    }
}