package com.example.ticketbooking;

public class VIPTicket extends Ticket {
    private String loungeAccess;
    
    public VIPTicket(String id, double price, String loungeAccess) {
        super(id, price);
        this.loungeAccess = loungeAccess;
    }
    
    @Override
    public void book() {
        if (!isBooked) {
            isBooked = true;
            System.out.println("VIP ticket " + id + " booked with access to " + loungeAccess);
        }
    }
    
    @Override
    public void cancel() {
        if (isBooked) {
            isBooked = false;
            System.out.println("VIP ticket " + id + " cancelled");
        }
    }
    
    public String getLoungeAccess() {
        return loungeAccess;
    }
}