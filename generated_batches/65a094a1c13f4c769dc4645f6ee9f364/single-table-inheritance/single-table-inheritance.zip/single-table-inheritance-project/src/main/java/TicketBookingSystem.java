package com.example.ticketbooking;

import java.util.ArrayList;
import java.util.List;

public class TicketBookingSystem {
    private List<Ticket> tickets;
    
    public TicketBookingSystem() {
        this.tickets = new ArrayList<>();
    }
    
    public void addTicket(Ticket ticket) {
        tickets.add(ticket);
    }
    
    public void bookTicket(String id) {
        for (Ticket ticket : tickets) {
            if (ticket.getId().equals(id)) {
                ticket.book();
                break;
            }
        }
    }
    
    public void cancelTicket(String id) {
        for (Ticket ticket : tickets) {
            if (ticket.getId().equals(id)) {
                ticket.cancel();
                break;
            }
        }
    }
    
    public static void main(String[] args) {
        TicketBookingSystem system = new TicketBookingSystem();
        
        // Using single-table inheritance - all tickets are treated as base type
        Ticket regularTicket = TicketFactory.createTicket("regular", "R001", 50.0, "A12");
        Ticket vipTicket = TicketFactory.createTicket("vip", "V001", 150.0, "Gold Lounge");
        
        system.addTicket(regularTicket);
        system.addTicket(vipTicket);
        
        system.bookTicket("R001");
        system.bookTicket("V001");
        
        system.cancelTicket("R001");
    }
}