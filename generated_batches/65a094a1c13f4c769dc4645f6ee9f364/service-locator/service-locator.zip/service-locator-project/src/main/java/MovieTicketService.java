public class MovieTicketService implements TicketBookingService {
    @Override
    public void bookTicket(String eventId, String userId) {
        System.out.println("Booking movie ticket for event: " + eventId + " user: " + userId);
    }
}