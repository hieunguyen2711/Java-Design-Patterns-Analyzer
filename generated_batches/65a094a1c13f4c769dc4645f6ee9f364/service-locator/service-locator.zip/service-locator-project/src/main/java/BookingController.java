public class BookingController {
    public void processBooking(String eventType, String eventId, String userId) {
        TicketBookingService service = ServiceLocator.getService(eventType.toUpperCase());
        if (service != null) {
            service.bookTicket(eventId, userId);
        } else {
            System.out.println("No service found for type: " + eventType);
        }
    }
}