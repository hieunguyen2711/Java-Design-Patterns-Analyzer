public class ConcertTicketService implements TicketBookingService {
    @Override
    public void bookTicket(String eventId, String userId) {
        System.out.println("Booking concert ticket for event: " + eventId + " user: " + userId);
    }
}