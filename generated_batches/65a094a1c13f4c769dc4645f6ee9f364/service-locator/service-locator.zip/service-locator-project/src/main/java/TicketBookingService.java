public interface TicketBookingService {
    void bookTicket(String eventId, String userId);
}