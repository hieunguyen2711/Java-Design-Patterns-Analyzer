import java.util.HashMap;
import java.util.Map;

public class ServiceLocator {
    private static Map<String, TicketBookingService> services = new HashMap<>();
    
    static {
        services.put("CONCERT", new ConcertTicketService());
        services.put("MOVIE", new MovieTicketService());
    }
    
    public static TicketBookingService getService(String serviceType) {
        return services.get(serviceType);
    }
}