public class Main {
    public static void main(String[] args) {
        BookingController controller = new BookingController();
        
        controller.processBooking("CONCERT", "C001", "user123");
        controller.processBooking("MOVIE", "M001", "user456");
        controller.processBooking("THEATER", "T001", "user789");
    }
}