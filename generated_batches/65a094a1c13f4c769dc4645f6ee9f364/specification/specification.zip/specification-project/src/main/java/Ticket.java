public abstract class Ticket {
    protected String customerName;
    protected double basePrice;
    
    public Ticket(String customerName) {
        this.customerName = customerName;
    }
    
    public abstract double calculateFinalPrice();
    
    @Override
    public String toString() {
        return "Ticket{" +
                "customerName='" + customerName + '\'' +
                ", finalPrice=" + calculateFinalPrice() +
                '}';
    }
}