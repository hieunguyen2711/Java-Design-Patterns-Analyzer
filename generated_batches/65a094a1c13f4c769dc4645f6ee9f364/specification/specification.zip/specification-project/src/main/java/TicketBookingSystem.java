public class TicketBookingSystem {
    public static void main(String[] args) {
        // Using singleton instance to book tickets
        BookingService service = BookingService.getInstance();
        
        // Book different types of tickets
        Ticket ticket1 = service.bookTicket("VIP", "John Doe");
        Ticket ticket2 = service.bookTicket("Regular", "Jane Smith");
        Ticket ticket3 = service.bookTicket("Premium", "Bob Johnson");
        
        System.out.println(ticket1);
        System.out.println(ticket2);
        System.out.println(ticket3);
    }
}