public class VipTicket extends Ticket {
    
    public VipTicket(String customerName) {
        super(customerName);
        this.basePrice = 200.0;
    }
    
    @Override
    public double calculateFinalPrice() {
        return basePrice * 1.3; // 30% premium for VIP
    }
}