public class RegularTicket extends Ticket {
    
    public RegularTicket(String customerName) {
        super(customerName);
        this.basePrice = 50.0;
    }
    
    @Override
    public double calculateFinalPrice() {
        return basePrice; // No additional charges
    }
}