public class PremiumTicket extends Ticket {
    
    public PremiumTicket(String customerName) {
        super(customerName);
        this.basePrice = 100.0;
    }
    
    @Override
    public double calculateFinalPrice() {
        return basePrice * 1.2; // 20% premium for Premium
    }
}