public class BookingService {
    private static volatile BookingService instance;
    
    private BookingService() {
        // Private constructor to prevent instantiation
    }
    
    public static BookingService getInstance() {
        if (instance == null) {
            synchronized (BookingService.class) {
                if (instance == null) {
                    instance = new BookingService();
                }
            }
        }
        return instance;
    }
    
    public Ticket bookTicket(String ticketType, String customerName) {
        switch (ticketType.toLowerCase()) {
            case "vip":
                return new VipTicket(customerName);
            case "regular":
                return new RegularTicket(customerName);
            case "premium":
                return new PremiumTicket(customerName);
            default:
                throw new IllegalArgumentException("Unknown ticket type: " + ticketType);
        }
    }
}