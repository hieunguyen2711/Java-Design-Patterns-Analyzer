package com.ticketbooking;

import java.util.ArrayList;
import java.util.List;

public class UnitOfWork {
    private List<Ticket> newTickets;
    private List<Ticket> dirtyTickets;
    private List<Ticket> deletedTickets;
    
    public UnitOfWork() {
        this.newTickets = new ArrayList<>();
        this.dirtyTickets = new ArrayList<>();
        this.deletedTickets = new ArrayList<>();
    }
    
    public void registerNew(Ticket ticket) {
        if (!newTickets.contains(ticket)) {
            newTickets.add(ticket);
        }
    }
    
    public void registerDirty(Ticket ticket) {
        if (!dirtyTickets.contains(ticket)) {
            dirtyTickets.add(ticket);
        }
    }
    
    public void registerDeleted(Ticket ticket) {
        deletedTickets.add(ticket);
    }
    
    public void commit() {
        // Simulate database operations
        for (Ticket ticket : newTickets) {
            System.out.println("Saving new ticket: " + ticket.getId());
        }
        
        for (Ticket ticket : dirtyTickets) {
            System.out.println("Updating ticket: " + ticket.getId());
        }
        
        for (Ticket ticket : deletedTickets) {
            System.out.println("Deleting ticket: " + ticket.getId());
        }
        
        // Clear the unit of work after commit
        newTickets.clear();
        dirtyTickets.clear();
        deletedTickets.clear();
    }
}