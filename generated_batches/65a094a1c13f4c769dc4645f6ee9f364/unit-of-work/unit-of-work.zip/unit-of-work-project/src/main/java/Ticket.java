package com.ticketbooking;

public class Ticket {
    private String id;
    private String eventName;
    
    public Ticket(String id, String eventName) {
        this.id = id;
        this.eventName = eventName;
    }
    
    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getEventName() { return eventName; }
    public void setEventName(String eventName) { this.eventName = eventName; }
}