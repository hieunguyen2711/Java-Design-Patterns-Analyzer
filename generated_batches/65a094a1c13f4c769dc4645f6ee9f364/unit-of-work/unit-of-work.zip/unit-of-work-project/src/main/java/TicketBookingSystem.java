package com.ticketbooking;

import java.util.ArrayList;
import java.util.List;

public class TicketBookingSystem {
    public static void main(String[] args) {
        UnitOfWork unitOfWork = new UnitOfWork();
        
        // Create tickets within the unit of work
        Ticket ticket1 = new Ticket("T001", "Concert A");
        Ticket ticket2 = new Ticket("T002", "Movie B");
        
        unitOfWork.registerNew(ticket1);
        unitOfWork.registerNew(ticket2);
        
        // Commit changes to database
        unitOfWork.commit();
        
        // Create another unit of work for updates
        UnitOfWork updateUnitOfWork = new UnitOfWork();
        ticket1.setEventName("Concert A - Updated");
        updateUnitOfWork.registerDirty(ticket1);
        updateUnitOfWork.commit();
    }
}