public class Booking {
    private String event;
    private String date;
    private String location;
    private int tickets;
    private double price;
    
    public Booking setEvent(String event) {
        this.event = event;
        return this;
    }
    
    public Booking setDate(String date) {
        this.date = date;
        return this;
    }
    
    public Booking setLocation(String location) {
        this.location = location;
        return this;
    }
    
    public Booking setTickets(int tickets) {
        this.tickets = tickets;
        return this;
    }
    
    public Booking setPrice(double price) {
        this.price = price;
        return this;
    }
    
    @Override
    public String toString() {
        return "Booking{" +
                "event='" + event + '\'' +
                ", date='" + date + '\'' +
                ", location='" + location + '\'' +
                ", tickets=" + tickets +
                ", price=" + price +
                '}';
    }
}