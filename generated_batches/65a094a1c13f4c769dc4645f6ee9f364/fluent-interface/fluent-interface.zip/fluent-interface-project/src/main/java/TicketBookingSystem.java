public class TicketBookingSystem {
    public static void main(String[] args) {
        // Demonstrating fluent interface pattern
        Booking booking = new Booking()
            .setEvent("Concert")
            .setDate("2023-12-25")
            .setLocation("Stadium A")
            .setTickets(4)
            .setPrice(89.99);
            
        System.out.println(booking);
    }
}