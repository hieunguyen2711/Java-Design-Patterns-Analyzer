public abstract class TicketCreator {
    public abstract Ticket createTicket(String category);
}