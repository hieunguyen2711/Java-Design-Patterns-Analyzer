public class MovieTicket extends Ticket {
    public MovieTicket(String category) {
        super("Movie", category);
    }
}