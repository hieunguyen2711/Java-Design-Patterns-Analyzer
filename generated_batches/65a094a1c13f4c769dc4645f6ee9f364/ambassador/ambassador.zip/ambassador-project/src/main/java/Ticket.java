public abstract class Ticket {
    private String type;
    private String category;
    
    public Ticket(String type, String category) {
        this.type = type;
        this.category = category;
    }
    
    public String getType() {
        return type;
    }
    
    public String getCategory() {
        return category;
    }
}