public class MovieTicketCreator extends TicketCreator {
    @Override
    public Ticket createTicket(String category) {
        return new MovieTicket(category);
    }
}