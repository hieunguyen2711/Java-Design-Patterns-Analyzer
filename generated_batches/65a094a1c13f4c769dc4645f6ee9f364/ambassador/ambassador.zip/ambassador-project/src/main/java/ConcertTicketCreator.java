public class ConcertTicketCreator extends TicketCreator {
    @Override
    public Ticket createTicket(String category) {
        return new ConcertTicket(category);
    }
}