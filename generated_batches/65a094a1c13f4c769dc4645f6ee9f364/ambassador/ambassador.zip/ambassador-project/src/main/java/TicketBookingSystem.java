public class TicketBookingSystem {
    public static void main(String[] args) {
        // Using Ambassador pattern to handle different booking types
        BookingService bookingService = new BookingService();
        
        // Book concert tickets through ambassador
        Ticket concertTicket = bookingService.bookTicket("concert", "VIP");
        System.out.println("Booked: " + concertTicket.getType() + " - " + concertTicket.getCategory());
        
        // Book movie tickets through ambassador  
        Ticket movieTicket = bookingService.bookTicket("movie", "Premium");
        System.out.println("Booked: " + movieTicket.getType() + " - " + movieTicket.getCategory());
    }
}