public class BookingService {
    
    public Ticket bookTicket(String type, String category) {
        // Ambassador pattern - delegating to appropriate ticket creator
        TicketCreator creator = getTicketCreator(type);
        return creator.createTicket(category);
    }
    
    private TicketCreator getTicketCreator(String type) {
        switch (type.toLowerCase()) {
            case "concert":
                return new ConcertTicketCreator();
            case "movie":
                return new MovieTicketCreator();
            default:
                throw new IllegalArgumentException("Unknown ticket type: " + type);
        }
    }
}