public class ConcertTicket extends Ticket {
    public ConcertTicket(String category) {
        super("Concert", category);
    }
}