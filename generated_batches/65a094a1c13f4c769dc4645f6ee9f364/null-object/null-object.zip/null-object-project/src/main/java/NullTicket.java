public class NullTicket extends Ticket {
    @Override
    public boolean isNull() {
        return true;
    }

    @Override
    public String getEventName() {
        return "No event";
    }

    @Override
    public double getPrice() {
        return 0.0;
    }
}