public class RegularTicket extends Ticket {
    private final String eventName;
    private final double price;

    public RegularTicket(String eventName, double price) {
        this.eventName = eventName;
        this.price = price;
    }

    @Override
    public boolean isNull() {
        return false;
    }

    @Override
    public String getEventName() {
        return eventName;
    }

    @Override
    public double getPrice() {
        return price;
    }
}