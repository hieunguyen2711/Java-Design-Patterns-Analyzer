public abstract class Ticket {
    public abstract boolean isNull();
    public abstract String getEventName();
    public abstract double getPrice();
}