public class BookingSystem {
    public static void main(String[] args) {
        Ticket ticket1 = TicketFactory.createTicket("Concert", 50.0);
        Ticket ticket2 = TicketFactory.createTicket("", 0.0);
        Ticket ticket3 = TicketFactory.createTicket(null, 0.0);

        System.out.println("Ticket 1 - Event: " + ticket1.getEventName() + 
                          ", Price: $" + ticket1.getPrice());
        
        System.out.println("Ticket 2 - Event: " + ticket2.getEventName() + 
                          ", Price: $" + ticket2.getPrice());
        
        System.out.println("Ticket 3 - Event: " + ticket3.getEventName() + 
                          ", Price: $" + ticket3.getPrice());
    }
}