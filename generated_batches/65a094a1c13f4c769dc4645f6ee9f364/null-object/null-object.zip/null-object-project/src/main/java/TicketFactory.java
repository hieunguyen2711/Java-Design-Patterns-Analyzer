public class TicketFactory {
    public static Ticket createTicket(String eventName, double price) {
        if (eventName == null || eventName.isEmpty()) {
            return new NullTicket();
        }
        return new RegularTicket(eventName, price);
    }
}