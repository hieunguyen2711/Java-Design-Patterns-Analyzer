public class TicketBookingSystem {
    public static void main(String[] args) {
        BookingService service = new BookingService();
        
        try {
            // Book a ticket using transaction script pattern
            service.bookTicket("John Doe", "Movie123", 4);
            System.out.println("Ticket booked successfully!");
            
            // Attempt to book invalid number of tickets
            service.bookTicket("Jane Smith", "Movie456", -1);
        } catch (Exception e) {
            System.err.println("Booking failed: " + e.getMessage());
        }
    }
}