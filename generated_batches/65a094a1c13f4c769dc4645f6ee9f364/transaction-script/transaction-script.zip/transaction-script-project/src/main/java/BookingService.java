public class BookingService {
    
    public void bookTicket(String customerName, String movieId, int numberOfTickets) throws Exception {
        // Transaction script - all steps in one method
        if (customerName == null || customerName.trim().isEmpty()) {
            throw new IllegalArgumentException("Customer name cannot be empty");
        }
        
        if (movieId == null || movieId.trim().isEmpty()) {
            throw new IllegalArgumentException("Movie ID cannot be empty");
        }
        
        if (numberOfTickets <= 0) {
            throw new IllegalArgumentException("Number of tickets must be positive");
        }
        
        // Validate movie exists
        Movie movie = findMovie(movieId);
        if (movie == null) {
            throw new Exception("Movie not found: " + movieId);
        }
        
        // Check availability
        if (!isAvailable(movieId, numberOfTickets)) {
            throw new Exception("Not enough tickets available for " + movieId);
        }
        
        // Reserve seats
        reserveSeats(movieId, numberOfTickets);
        
        // Calculate total price
        double totalPrice = calculatePrice(movie, numberOfTickets);
        
        // Process payment (mock implementation)
        processPayment(customerName, totalPrice);
        
        // Create booking record
        createBookingRecord(customerName, movieId, numberOfTickets, totalPrice);
        
        // Update inventory
        updateInventory(movieId, numberOfTickets);
        
        System.out.println("Booking completed for " + customerName + 
                          " - Movie: " + movieId + 
                          ", Tickets: " + numberOfTickets);
    }
    
    private Movie findMovie(String movieId) {
        // Mock implementation
        return new Movie(movieId, "Sample Movie", 10.0);
    }
    
    private boolean isAvailable(String movieId, int numberOfTickets) {
        // Mock implementation - assume we have enough tickets
        return true;
    }
    
    private void reserveSeats(String movieId, int numberOfTickets) throws Exception {
        // Mock reservation logic
        System.out.println("Reserving " + numberOfTickets + " seats for " + movieId);
    }
    
    private double calculatePrice(Movie movie, int numberOfTickets) {
        return movie.getPrice() * numberOfTickets;
    }
    
    private void processPayment(String customerName, double amount) throws Exception {
        // Mock payment processing
        System.out.println("Processing payment of $" + amount + " for " + customerName);
    }
    
    private void createBookingRecord(String customerName, String movieId, int numberOfTickets, double totalPrice) {
        // Mock booking record creation
        System.out.println("Creating booking record: " + customerName + 
                          " - " + movieId + " - " + numberOfTickets + 
                          " tickets - $" + totalPrice);
    }
    
    private void updateInventory(String movieId, int numberOfTickets) throws Exception {
        // Mock inventory update
        System.out.println("Updating inventory for " + movieId + 
                          " by reducing " + numberOfTickets + " seats");
    }
}