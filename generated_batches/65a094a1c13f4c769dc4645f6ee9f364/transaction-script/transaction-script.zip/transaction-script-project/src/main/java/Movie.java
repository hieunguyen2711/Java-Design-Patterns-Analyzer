public class Movie {
    private String id;
    private String title;
    private double price;
    
    public Movie(String id, String title, double price) {
        this.id = id;
        this.title = title;
        this.price = price;
    }
    
    public String getId() {
        return id;
    }
    
    public String getTitle() {
        return title;
    }
    
    public double getPrice() {
        return price;
    }
}