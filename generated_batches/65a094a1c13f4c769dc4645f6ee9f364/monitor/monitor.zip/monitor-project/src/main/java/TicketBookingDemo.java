package com.example.ticketbooking;

public class TicketBookingDemo {
    public static void main(String[] args) {
        TicketBookingSystem bookingSystem = new TicketBookingSystem(10);
        
        // Create multiple threads to simulate customers
        Thread customer1 = new Thread(() -> {
            try {
                bookingSystem.bookTicket("Alice", 3);
                Thread.sleep(2000);
                bookingSystem.releaseTickets("Alice", 1);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
        
        Thread customer2 = new Thread(() -> {
            try {
                bookingSystem.bookTicket("Bob", 5);
                Thread.sleep(1000);
                bookingSystem.releaseTickets("Bob", 2);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
        
        Thread customer3 = new Thread(() -> {
            try {
                bookingSystem.bookTicket("Charlie", 4);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
        
        // Start all threads
        customer1.start();
        customer2.start();
        customer3.start();
        
        // Wait for completion
        try {
            customer1.join();
            customer2.join();
            customer3.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}