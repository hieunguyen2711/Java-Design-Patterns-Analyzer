package com.example.ticketbooking;

import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Condition;

public class TicketBookingSystem {
    private final int totalTickets;
    private int availableTickets;
    private final ReentrantLock lock;
    private final Condition ticketsAvailable;
    
    public TicketBookingSystem(int totalTickets) {
        this.totalTickets = totalTickets;
        this.availableTickets = totalTickets;
        this.lock = new ReentrantLock();
        this.ticketsAvailable = lock.newCondition();
    }
    
    public boolean bookTicket(String customerName, int numberOfTickets) throws InterruptedException {
        lock.lock();
        try {
            while (availableTickets < numberOfTickets) {
                System.out.println("Customer " + customerName + " waiting for tickets...");
                ticketsAvailable.await(); // Monitor waits
            }
            
            availableTickets -= numberOfTickets;
            System.out.println("Customer " + customerName + " booked " + numberOfTickets + 
                             " ticket(s). Remaining: " + availableTickets);
            return true;
        } finally {
            lock.unlock();
        }
    }
    
    public void releaseTickets(String customerName, int numberOfTickets) {
        lock.lock();
        try {
            availableTickets += numberOfTickets;
            System.out.println("Customer " + customerName + " released " + numberOfTickets + 
                             " ticket(s). Available: " + availableTickets);
            ticketsAvailable.signalAll(); // Notify waiting monitors
        } finally {
            lock.unlock();
        }
    }
    
    public int getAvailableTickets() {
        lock.lock();
        try {
            return availableTickets;
        } finally {
            lock.unlock();
        }
    }
}