public class PremiumTicketHandler extends Handler {
    @Override
    public void handle(BookingRequest request) {
        if ("Premium".equalsIgnoreCase(request.getTicketType())) {
            System.out.println("Processing " + request.getQuantity() + 
                              " premium ticket(s)");
        } else if (next != null) {
            next.handle(request);
        } else {
            System.out.println("No handler found for " + request.getTicketType() + " tickets");
        }
    }
}