public class StandardTicketHandler extends Handler {
    @Override
    public void handle(BookingRequest request) {
        if ("Standard".equalsIgnoreCase(request.getTicketType())) {
            System.out.println("Processing " + request.getQuantity() + 
                              " standard ticket(s)");
        } else if (next != null) {
            next.handle(request);
        } else {
            System.out.println("No handler found for " + request.getTicketType() + " tickets");
        }
    }
}