public class TicketBookingSystem {
    public static void main(String[] args) {
        // Create handlers
        Handler premiumHandler = new PremiumTicketHandler();
        Handler standardHandler = new StandardTicketHandler();
        Handler economyHandler = new EconomyTicketHandler();
        
        // Chain the handlers
        premiumHandler.setNext(standardHandler);
        standardHandler.setNext(economyHandler);
        
        // Test booking requests
        BookingRequest request1 = new BookingRequest("Premium", 2);
        BookingRequest request2 = new BookingRequest("Standard", 1);
        BookingRequest request3 = new BookingRequest("Economy", 5);
        BookingRequest request4 = new BookingRequest("VIP", 1);
        
        premiumHandler.handle(request1);
        premiumHandler.handle(request2);
        premiumHandler.handle(request3);
        premiumHandler.handle(request4);
    }
}