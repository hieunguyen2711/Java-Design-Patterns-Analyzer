public class EconomyTicketHandler extends Handler {
    @Override
    public void handle(BookingRequest request) {
        if ("Economy".equalsIgnoreCase(request.getTicketType())) {
            System.out.println("Processing " + request.getQuantity() + 
                              " economy ticket(s)");
        } else if (next != null) {
            next.handle(request);
        } else {
            System.out.println("No handler found for " + request.getTicketType() + " tickets");
        }
    }
}