public class BookingRequest {
    private String ticketType;
    private int quantity;
    
    public BookingRequest(String ticketType, int quantity) {
        this.ticketType = ticketType;
        this.quantity = quantity;
    }
    
    public String getTicketType() {
        return ticketType;
    }
    
    public int getQuantity() {
        return quantity;
    }
}