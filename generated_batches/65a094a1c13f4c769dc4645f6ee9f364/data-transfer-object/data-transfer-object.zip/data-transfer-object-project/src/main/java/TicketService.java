public class TicketService {
    public BookingResponseDTO processBooking(BookingRequestDTO request) {
        // In a real system, this would interact with database and other services
        
        // Create response DTO
        BookingResponseDTO response = new BookingResponseDTO();
        response.setConfirmed(true);
        response.setTicketId("TKT-" + System.currentTimeMillis());
        response.setEventName(request.getEventName());
        response.setSeatNumber(request.getSeatNumber());
        
        return response;
    }
}