public class TicketBookingSystem {
    public static void main(String[] args) {
        // Create DTO for booking request
        BookingRequestDTO request = new BookingRequestDTO();
        request.setEventName("Concert");
        request.setSeatNumber("A12");
        request.setCustomerEmail("john.doe@example.com");
        
        // Process booking using DTO
        TicketService ticketService = new TicketService();
        BookingResponseDTO response = ticketService.processBooking(request);
        
        System.out.println("Booking confirmed: " + response.isConfirmed());
        System.out.println("Ticket ID: " + response.getTicketId());
    }
}