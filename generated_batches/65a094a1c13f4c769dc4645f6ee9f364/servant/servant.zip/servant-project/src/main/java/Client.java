package com.example.ticketbooking;

public class Client {
    private final TicketServant ticketServant;
    private final PaymentServant paymentServant;
    
    public Client(TicketServant ticketServant, PaymentServant paymentServant) {
        this.ticketServant = ticketServant;
        this.paymentServant = paymentServant;
    }
    
    public void bookTicket(String event, int quantity) {
        ticketServant.bookTicket(event, quantity);
    }
    
    public void makePayment(double amount) {
        paymentServant.processPayment(amount);
    }
}