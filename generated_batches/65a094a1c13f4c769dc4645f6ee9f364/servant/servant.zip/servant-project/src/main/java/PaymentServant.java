package com.example.ticketbooking;

public class PaymentServant implements Servant {
    @Override
    public void performAction() {
        System.out.println("Processing payment...");
    }
    
    public void processPayment(double amount) {
        System.out.println("Processing payment of $" + amount);
    }
}