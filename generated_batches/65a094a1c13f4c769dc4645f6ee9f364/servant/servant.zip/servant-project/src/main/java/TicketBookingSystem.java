package com.example.ticketbooking;

public class TicketBookingSystem {
    public static void main(String[] args) {
        // Create servant instances
        TicketServant ticketServant = new TicketServant();
        PaymentServant paymentServant = new PaymentServant();
        
        // Create client
        Client client = new Client(ticketServant, paymentServant);
        
        // Use the system
        client.bookTicket("Concert", 2);
        client.makePayment(150.0);
    }
}