package com.example.ticketbooking;

public interface Servant {
    void performAction();
}