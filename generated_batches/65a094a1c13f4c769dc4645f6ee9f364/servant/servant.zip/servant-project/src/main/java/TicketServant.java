package com.example.ticketbooking;

public class TicketServant implements Servant {
    @Override
    public void performAction() {
        System.out.println("Booking ticket...");
    }
    
    public void bookTicket(String event, int quantity) {
        System.out.println("Booking " + quantity + " tickets for " + event);
    }
}