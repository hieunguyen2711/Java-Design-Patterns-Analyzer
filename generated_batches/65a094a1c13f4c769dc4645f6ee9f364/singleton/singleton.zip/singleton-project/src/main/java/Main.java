public class Main {
    public static void main(String[] args) {
        TicketBookingSystem system1 = TicketBookingSystem.getInstance();
        TicketBookingSystem system2 = TicketBookingSystem.getInstance();
        
        System.out.println("Are both instances the same? " + (system1 == system2));
        
        system1.bookTicket("Concert", "A1");
        system2.bookTicket("Movie", "B2");
    }
}