public class TicketBookingSystem {
    private static volatile TicketBookingSystem instance;
    
    private TicketBookingSystem() {
        // Private constructor to prevent instantiation
    }
    
    public static TicketBookingSystem getInstance() {
        if (instance == null) {
            synchronized (TicketBookingSystem.class) {
                if (instance == null) {
                    instance = new TicketBookingSystem();
                }
            }
        }
        return instance;
    }
    
    public void bookTicket(String event, String seatNumber) {
        System.out.println("Booking ticket for " + event + " at seat " + seatNumber);
    }
}