import java.util.ArrayList;
import java.util.List;

public class TicketBookingSystem {
    private List<Ticket> tickets = new ArrayList<>();
    
    public void bookTicket(String event, String seat) {
        tickets.add(new Ticket(event, seat));
    }
    
    public Memento saveState() {
        return new Memento(new ArrayList<>(tickets));
    }
    
    public void restoreState(Memento memento) {
        tickets = memento.getTickets();
    }
    
    public List<Ticket> getTickets() {
        return new ArrayList<>(tickets);
    }
}