import java.util.List;

public class Memento {
    private List<Ticket> tickets;
    
    public Memento(List<Ticket> tickets) {
        this.tickets = new ArrayList<>(tickets);
    }
    
    public List<Ticket> getTickets() {
        return new ArrayList<>(tickets);
    }
}