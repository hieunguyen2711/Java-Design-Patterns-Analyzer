import java.util.List;

public class Originator {
    private List<Ticket> tickets;
    
    public void setTickets(List<Ticket> tickets) {
        this.tickets = tickets;
    }
    
    public Memento saveToMemento() {
        return new Memento(tickets);
    }
    
    public void restoreFromMemento(Memento memento) {
        this.tickets = memento.getTickets();
    }
    
    public List<Ticket> getTickets() {
        return tickets;
    }
}