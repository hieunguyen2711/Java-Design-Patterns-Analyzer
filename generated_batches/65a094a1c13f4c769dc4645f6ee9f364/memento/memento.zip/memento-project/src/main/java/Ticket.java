public class Ticket {
    private String event;
    private String seat;
    
    public Ticket(String event, String seat) {
        this.event = event;
        this.seat = seat;
    }
    
    public String getEvent() {
        return event;
    }
    
    public String getSeat() {
        return seat;
    }
    
    @Override
    public String toString() {
        return "Ticket{event='" + event + "', seat='" + seat + "'}";
    }
}