import java.util.List;

public class Main {
    public static void main(String[] args) {
        TicketDAO ticketDAO = new TicketDAOImpl();
        TicketService ticketService = new TicketService(ticketDAO);

        // Book some tickets
        ticketService.bookTicket("Concert", "A1", 50.0);
        ticketService.bookTicket("Movie", "B2", 25.0);

        // Retrieve all tickets
        List<Ticket> tickets = ticketService.getAllTickets();
        for (Ticket ticket : tickets) {
            System.out.println("ID: " + ticket.getId() + 
                             ", Event: " + ticket.getEventName() + 
                             ", Seat: " + ticket.getSeatNumber() + 
                             ", Price: $" + ticket.getPrice());
        }

        // Update a ticket
        ticketService.updateTicket(1, "Concert", "A2", 55.0);
        
        // Retrieve updated ticket
        Ticket updatedTicket = ticketService.getTicket(1);
        System.out.println("Updated ticket - ID: " + updatedTicket.getId() + 
                          ", Event: " + updatedTicket.getEventName() + 
                          ", Seat: " + updatedTicket.getSeatNumber() + 
                          ", Price: $" + updatedTicket.getPrice());
    }
}