import java.util.ArrayList;
import java.util.List;

public class TicketDAOImpl implements TicketDAO {
    private List<Ticket> tickets = new ArrayList<>();
    private int nextId = 1;

    @Override
    public void save(Ticket ticket) {
        ticket.setId(nextId++);
        tickets.add(ticket);
    }

    @Override
    public Ticket findById(int id) {
        for (Ticket ticket : tickets) {
            if (ticket.getId() == id) {
                return ticket;
            }
        }
        return null;
    }

    @Override
    public List<Ticket> findAll() {
        return new ArrayList<>(tickets);
    }

    @Override
    public void update(Ticket updatedTicket) {
        for (int i = 0; i < tickets.size(); i++) {
            if (tickets.get(i).getId() == updatedTicket.getId()) {
                tickets.set(i, updatedTicket);
                break;
            }
        }
    }

    @Override
    public void delete(int id) {
        tickets.removeIf(ticket -> ticket.getId() == id);
    }
}