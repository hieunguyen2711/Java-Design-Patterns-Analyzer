import java.util.List;

public interface TicketDAO {
    void save(Ticket ticket);
    Ticket findById(int id);
    List<Ticket> findAll();
    void update(Ticket ticket);
    void delete(int id);
}