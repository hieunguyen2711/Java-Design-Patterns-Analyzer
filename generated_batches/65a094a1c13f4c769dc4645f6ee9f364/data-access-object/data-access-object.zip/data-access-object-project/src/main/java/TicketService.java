import java.util.List;

public class TicketService {
    private final TicketDAO ticketDAO;

    public TicketService(TicketDAO ticketDAO) {
        this.ticketDAO = ticketDAO;
    }

    public void bookTicket(String eventName, String seatNumber, double price) {
        Ticket ticket = new Ticket(0, eventName, seatNumber, price);
        ticketDAO.save(ticket);
    }

    public Ticket getTicket(int id) {
        return ticketDAO.findById(id);
    }

    public List<Ticket> getAllTickets() {
        return ticketDAO.findAll();
    }

    public void updateTicket(int id, String eventName, String seatNumber, double price) {
        Ticket ticket = new Ticket(id, eventName, seatNumber, price);
        ticketDAO.update(ticket);
    }

    public void cancelTicket(int id) {
        ticketDAO.delete(id);
    }
}