import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class TicketBookingSystem {
    private final BlockingQueue<BookingRequest> requestQueue = new LinkedBlockingQueue<>();
    
    public static void main(String[] args) {
        TicketBookingSystem system = new TicketBookingSystem();
        system.startBookingProcess();
    }
    
    public void startBookingProcess() {
        // Start booking thread
        Thread bookingThread = new Thread(() -> {
            while (true) {
                try {
                    BookingRequest request = requestQueue.take(); // Guarded suspension - blocks until request available
                    processBooking(request);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        });
        
        bookingThread.start();
        
        // Simulate booking requests
        new Thread(() -> {
            try {
                Thread.sleep(1000);
                requestQueue.put(new BookingRequest("John", "Concert"));
                Thread.sleep(500);
                requestQueue.put(new BookingRequest("Jane", "Movie"));
                Thread.sleep(1000);
                requestQueue.put(new BookingRequest("Bob", "Theater"));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }).start();
    }
    
    private void processBooking(BookingRequest request) {
        System.out.println("Processing booking for: " + request.customerName + 
                          " - " + request.eventType);
        try {
            Thread.sleep(2000); // Simulate processing time
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        System.out.println("Booking completed for: " + request.customerName);
    }
    
    static class BookingRequest {
        final String customerName;
        final String eventType;
        
        public BookingRequest(String customerName, String eventType) {
            this.customerName = customerName;
            this.eventType = eventType;
        }
    }
}