import java.util.ArrayList;
import java.util.List;

public class TicketBookingSystem {
    public static void main(String[] args) {
        Event event = new Event("Concert");
        
        User user1 = new User("Alice");
        User user2 = new User("Bob");
        
        event.addObserver(user1);
        event.addObserver(user2);
        
        event.setTicketsAvailable(50);
        System.out.println();
        event.setTicketsAvailable(10);
    }
}