public class User implements Observer {
    private String name;
    
    public User(String name) {
        this.name = name;
    }
    
    @Override
    public void update(String eventName, int ticketsAvailable) {
        System.out.println("Notification to " + name + 
                          ": " + eventName + " has " + 
                          ticketsAvailable + " tickets available");
    }
}