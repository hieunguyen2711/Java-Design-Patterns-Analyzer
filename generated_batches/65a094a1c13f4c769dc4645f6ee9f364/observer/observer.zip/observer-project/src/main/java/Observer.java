public interface Observer {
    void update(String eventName, int ticketsAvailable);
}