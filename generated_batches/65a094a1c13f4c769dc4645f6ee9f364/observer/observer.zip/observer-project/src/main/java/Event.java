import java.util.ArrayList;
import java.util.List;

public class Event {
    private String eventName;
    private int ticketsAvailable;
    private List<Observer> observers;
    
    public Event(String eventName) {
        this.eventName = eventName;
        this.observers = new ArrayList<>();
    }
    
    public void addObserver(Observer observer) {
        observers.add(observer);
    }
    
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }
    
    public void setTicketsAvailable(int ticketsAvailable) {
        this.ticketsAvailable = ticketsAvailable;
        notifyObservers();
    }
    
    private void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(eventName, ticketsAvailable);
        }
    }
}