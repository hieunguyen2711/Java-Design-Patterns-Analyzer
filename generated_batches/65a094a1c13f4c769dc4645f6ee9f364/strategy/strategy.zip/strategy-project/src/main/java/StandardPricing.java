public class StandardPricing implements PricingStrategy {
    @Override
    public double calculatePrice(int tickets) {
        return tickets * 50.0;
    }
}