public interface PricingStrategy {
    double calculatePrice(int tickets);
}