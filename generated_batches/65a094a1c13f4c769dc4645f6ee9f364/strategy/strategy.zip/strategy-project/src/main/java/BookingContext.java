public class BookingContext {
    private PricingStrategy strategy;
    
    public void setPricingStrategy(PricingStrategy strategy) {
        this.strategy = strategy;
    }
    
    public double calculateCost(int tickets) {
        return strategy.calculatePrice(tickets);
    }
}