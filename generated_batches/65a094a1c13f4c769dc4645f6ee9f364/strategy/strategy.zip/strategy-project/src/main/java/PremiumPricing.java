public class PremiumPricing implements PricingStrategy {
    @Override
    public double calculatePrice(int tickets) {
        return tickets * 100.0;
    }
}