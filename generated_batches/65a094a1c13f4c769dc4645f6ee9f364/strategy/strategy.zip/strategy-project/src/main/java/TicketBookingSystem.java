public class TicketBookingSystem {
    public static void main(String[] args) {
        BookingContext context = new BookingContext();
        
        // Book with standard pricing
        context.setPricingStrategy(new StandardPricing());
        System.out.println("Standard booking cost: " + context.calculateCost(2));
        
        // Book with premium pricing
        context.setPricingStrategy(new PremiumPricing());
        System.out.println("Premium booking cost: " + context.calculateCost(2));
    }
}