public class TicketBookingSystem {
    public static void main(String[] args) {
        // Demonstrating Multiton pattern with different ticket types
        TicketManager standardTicketManager = TicketManager.getInstance("STANDARD");
        TicketManager premiumTicketManager = TicketManager.getInstance("PREMIUM");
        TicketManager vipTicketManager = TicketManager.getInstance("VIP");
        
        // Same instance returned for same key
        TicketManager standardTicketManager2 = TicketManager.getInstance("STANDARD");
        System.out.println(standardTicketManager == standardTicketManager2); // true
        
        // Different instances for different keys
        System.out.println(standardTicketManager == premiumTicketManager); // false
        
        // Using the managers to book tickets
        standardTicketManager.bookTicket("A1");
        premiumTicketManager.bookTicket("B2");
        vipTicketManager.bookTicket("C3");
        
        // Display current bookings
        System.out.println("Standard tickets booked: " + standardTicketManager.getBookedTickets());
        System.out.println("Premium tickets booked: " + premiumTicketManager.getBookedTickets());
        System.out.println("VIP tickets booked: " + vipTicketManager.getBookedTickets());
    }
}