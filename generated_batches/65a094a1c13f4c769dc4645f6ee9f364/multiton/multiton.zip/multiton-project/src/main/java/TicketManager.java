import java.util.HashMap;
import java.util.Map;

public class TicketManager {
    private static final Map<String, TicketManager> instances = new HashMap<>();
    
    private final String ticketType;
    private final Map<String, Boolean> bookedTickets;
    
    // Private constructor to prevent instantiation
    private TicketManager(String ticketType) {
        this.ticketType = ticketType;
        this.bookedTickets = new HashMap<>();
    }
    
    /**
     * Returns the singleton instance for the given ticket type.
     * This is the core of the Multiton pattern - multiple instances 
     * but controlled by a key (ticket type).
     */
    public static TicketManager getInstance(String ticketType) {
        if (!instances.containsKey(ticketType)) {
            instances.put(ticketType, new TicketManager(ticketType));
        }
        return instances.get(ticketType);
    }
    
    public void bookTicket(String seatNumber) {
        bookedTickets.put(seatNumber, true);
        System.out.println("Booked " + ticketType + " ticket for seat " + seatNumber);
    }
    
    public int getBookedTickets() {
        return bookedTickets.size();
    }
}