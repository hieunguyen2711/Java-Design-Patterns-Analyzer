package com.booking.system;

public class Ticket implements Cloneable {
    private String eventId;
    private String seatNumber;
    private double price;
    private boolean isVIP;
    
    public Ticket(String eventId, String seatNumber, double price, boolean isVIP) {
        this.eventId = eventId;
        this.seatNumber = seatNumber;
        this.price = price;
        this.isVIP = isVIP;
    }
    
    @Override
    public Ticket clone() throws CloneNotSupportedException {
        return (Ticket) super.clone();
    }
    
    // Getters and setters
    public String getEventId() { return eventId; }
    public void setEventId(String eventId) { this.eventId = eventId; }
    
    public String getSeatNumber() { return seatNumber; }
    public void setSeatNumber(String seatNumber) { this.seatNumber = seatNumber; }
    
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
    
    public boolean isVIP() { return isVIP; }
    public void setVIP(boolean VIP) { isVIP = VIP; }
    
    @Override
    public String toString() {
        return "Ticket{" +
                "eventId='" + eventId + '\'' +
                ", seatNumber='" + seatNumber + '\'' +
                ", price=" + price +
                ", isVIP=" + isVIP +
                '}';
    }
}