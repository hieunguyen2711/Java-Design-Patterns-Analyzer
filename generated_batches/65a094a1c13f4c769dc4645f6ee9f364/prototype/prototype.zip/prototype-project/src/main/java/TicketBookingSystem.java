package com.booking.system;

public class TicketBookingSystem {
    public static void main(String[] args) {
        try {
            // Create a prototype ticket
            Ticket standardTicket = new Ticket("EVT001", "A12", 50.0, false);
            
            // Clone the prototype to create new tickets
            Ticket clonedTicket1 = standardTicket.clone();
            clonedTicket1.setSeatNumber("B12");
            
            Ticket clonedTicket2 = standardTicket.clone();
            clonedTicket2.setSeatNumber("C12");
            clonedTicket2.setVIP(true);
            
            System.out.println("Original ticket: " + standardTicket);
            System.out.println("Cloned ticket 1: " + clonedTicket1);
            System.out.println("Cloned ticket 2: " + clonedTicket2);
            
        } catch (CloneNotSupportedException e) {
            System.err.println("Cloning not supported: " + e.getMessage());
        }
    }
}