public class ConcreteTicket implements Ticket {
    private final TicketFlyweight flyweight;
    private final int seatNumber;
    
    public ConcreteTicket(TicketFlyweight flyweight, int seatNumber) {
        this.flyweight = flyweight;
        this.seatNumber = seatNumber;
    }
    
    @Override
    public String getEvent() {
        return flyweight.getEvent();
    }
    
    @Override
    public String getCategory() {
        return flyweight.getCategory();
    }
    
    @Override
    public int getSeatNumber() {
        return seatNumber;
    }
    
    @Override
    public double getPrice() {
        return flyweight.getPrice();
    }
    
    @Override
    public String toString() {
        return "Ticket{" +
                "event='" + getEvent() + '\'' +
                ", category='" + getCategory() + '\'' +
                ", seatNumber=" + getSeatNumber() +
                ", price=" + getPrice() +
                '}';
    }
}