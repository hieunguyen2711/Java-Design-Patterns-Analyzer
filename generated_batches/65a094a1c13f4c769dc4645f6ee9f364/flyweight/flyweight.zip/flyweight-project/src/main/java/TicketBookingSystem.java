import java.util.HashMap;
import java.util.Map;

public class TicketBookingSystem {
    public static void main(String[] args) {
        // Create booking system with flyweight pattern
        FlyweightTicketFactory factory = new FlyweightTicketFactory();
        
        // Book multiple tickets - they will share common data
        Ticket ticket1 = factory.getTicket("Concert", "VIP", 100);
        Ticket ticket2 = factory.getTicket("Concert", "VIP", 101);
        Ticket ticket3 = factory.getTicket("Movie", "Regular", 200);
        Ticket ticket4 = factory.getTicket("Movie", "Regular", 201);
        
        // Display tickets
        System.out.println(ticket1);
        System.out.println(ticket2);
        System.out.println(ticket3);
        System.out.println(ticket4);
    }
}