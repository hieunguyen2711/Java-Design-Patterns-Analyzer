public interface Ticket {
    String getEvent();
    String getCategory();
    int getSeatNumber();
    double getPrice();
    String toString();
}