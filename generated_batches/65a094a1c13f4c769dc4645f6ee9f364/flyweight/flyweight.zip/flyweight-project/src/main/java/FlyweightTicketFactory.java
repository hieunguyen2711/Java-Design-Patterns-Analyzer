import java.util.HashMap;
import java.util.Map;

public class FlyweightTicketFactory {
    private static final Map<String, TicketFlyweight> flyweights = new HashMap<>();
    
    public static Ticket getTicket(String event, String category, int seatNumber) {
        // Create key for flyweight lookup
        String key = event + ":" + category;
        
        // Get or create flyweight object
        TicketFlyweight flyweight = flyweights.get(key);
        if (flyweight == null) {
            flyweight = new TicketFlyweight(event, category);
            flyweights.put(key, flyweight);
        }
        
        // Return concrete ticket with shared flyweight and unique data
        return new ConcreteTicket(flyweight, seatNumber);
    }
}