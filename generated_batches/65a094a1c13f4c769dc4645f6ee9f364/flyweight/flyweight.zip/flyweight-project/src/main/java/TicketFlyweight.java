public class TicketFlyweight {
    private final String event;
    private final String category;
    
    public TicketFlyweight(String event, String category) {
        this.event = event;
        this.category = category;
    }
    
    public String getEvent() {
        return event;
    }
    
    public String getCategory() {
        return category;
    }
    
    public double getPrice() {
        // Base pricing logic
        if ("VIP".equals(category)) {
            return 200.0;
        } else if ("Regular".equals(category)) {
            return 50.0;
        }
        return 0.0;
    }
}