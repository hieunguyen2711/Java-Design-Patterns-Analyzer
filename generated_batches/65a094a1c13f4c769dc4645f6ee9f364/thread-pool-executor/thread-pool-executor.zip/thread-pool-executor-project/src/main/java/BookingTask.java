import java.util.concurrent.atomic.AtomicInteger;

public class BookingTask implements Runnable {
    private static final AtomicInteger counter = new AtomicInteger(0);
    private final String customerName;
    private final int ticketId;
    
    public BookingTask(String customerName, int ticketId) {
        this.customerName = customerName;
        this.ticketId = ticketId;
    }
    
    @Override
    public void run() {
        int taskId = counter.incrementAndGet();
        System.out.println("Booking task " + taskId + " started for " + customerName + 
                          " with ticket ID: " + ticketId);
        
        try {
            // Simulate booking process
            Thread.sleep(1000);
            System.out.println("Booking task " + taskId + " completed for " + customerName + 
                              " with ticket ID: " + ticketId);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.err.println("Booking task " + taskId + " was interrupted");
        }
    }
}