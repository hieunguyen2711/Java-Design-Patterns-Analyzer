import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class TicketBookingSystem {
    private final ExecutorService executorService;
    
    public TicketBookingSystem() {
        this.executorService = Executors.newFixedThreadPool(3);
    }
    
    public void bookTicket(String customerName, int ticketId) {
        executorService.submit(new BookingTask(customerName, ticketId));
    }
    
    public void shutdown() {
        executorService.shutdown();
        try {
            if (!executorService.awaitTermination(60, TimeUnit.SECONDS)) {
                executorService.shutdownNow();
            }
        } catch (InterruptedException e) {
            executorService.shutdownNow();
        }
    }
    
    public static void main(String[] args) {
        TicketBookingSystem system = new TicketBookingSystem();
        
        for (int i = 1; i <= 10; i++) {
            system.bookTicket("Customer-" + i, i);
        }
        
        system.shutdown();
    }
}