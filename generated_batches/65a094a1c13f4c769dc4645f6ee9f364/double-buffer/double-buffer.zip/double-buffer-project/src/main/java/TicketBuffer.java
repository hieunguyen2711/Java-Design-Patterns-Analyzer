package com.example.ticketbooking;

import java.util.HashSet;
import java.util.Set;

public class TicketBuffer {
    private final Set<String> tickets = new HashSet<>();
    
    public TicketBuffer() {}
    
    public TicketBuffer(TicketBuffer other) {
        this.tickets.addAll(other.tickets);
    }
    
    public void addTicket(String ticketId) {
        tickets.add(ticketId);
    }
    
    public boolean isTicketAvailable(String ticketId) {
        return tickets.contains(ticketId);
    }
}