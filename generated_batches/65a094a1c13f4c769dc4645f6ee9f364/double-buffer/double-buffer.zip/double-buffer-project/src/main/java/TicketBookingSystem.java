package com.example.ticketbooking;

import java.util.concurrent.atomic.AtomicReference;

public class TicketBookingSystem {
    private final AtomicReference<TicketBuffer> currentBuffer = new AtomicReference<>(new TicketBuffer());
    
    public void bookTicket(String ticketId) {
        // Double buffering - create new buffer with updated state
        TicketBuffer newBuffer = new TicketBuffer(currentBuffer.get());
        newBuffer.addTicket(ticketId);
        
        // Atomically swap buffers
        currentBuffer.set(newBuffer);
    }
    
    public boolean isTicketAvailable(String ticketId) {
        // Read from current buffer without modification
        return currentBuffer.get().isTicketAvailable(ticketId);
    }
}