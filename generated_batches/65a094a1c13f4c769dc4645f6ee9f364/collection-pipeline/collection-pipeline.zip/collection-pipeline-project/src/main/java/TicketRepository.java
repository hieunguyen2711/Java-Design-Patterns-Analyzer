package com.example.ticketbooking;

import java.util.*;
import java.util.stream.Collectors;

public class TicketRepository {
    private List<Ticket> tickets;
    
    public TicketRepository() {
        this.tickets = new ArrayList<>();
    }
    
    public void addTicket(Ticket ticket) {
        tickets.add(ticket);
    }
    
    public Collection<Ticket> findByEvent(String eventId) {
        return tickets.stream()
                .filter(ticket -> ticket.getEventId().equals(eventId))
                .collect(Collectors.toList());
    }
    
    public Collection<Ticket> findByCustomer(String customerId) {
        return tickets.stream()
                .filter(ticket -> ticket.getCustomerId().equals(customerId))
                .collect(Collectors.toList());
    }
    
    public double getTotalRevenue() {
        return tickets.stream()
                .mapToDouble(ticket -> ticket.getPrice() * ticket.getQuantity())
                .sum();
    }
    
    public Collection<Ticket> getTicketsByEventAndCustomer(String eventId, String customerId) {
        return tickets.stream()
                .filter(ticket -> ticket.getEventId().equals(eventId))
                .filter(ticket -> ticket.getCustomerId().equals(customerId))
                .collect(Collectors.toList());
    }
}