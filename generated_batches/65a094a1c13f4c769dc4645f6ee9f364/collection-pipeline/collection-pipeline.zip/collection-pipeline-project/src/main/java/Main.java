package com.example.ticketbooking;

import java.util.Collection;

public class Main {
    public static void main(String[] args) {
        TicketBookingSystem system = new TicketBookingSystem();
        
        // Book some tickets
        system.bookTicket("event1", "customer1", 2, 50.0);
        system.bookTicket("event1", "customer2", 1, 75.0);
        system.bookTicket("event2", "customer1", 3, 40.0);
        system.bookTicket("event1", "customer1", 1, 60.0);
        
        // Use collection-pipeline pattern to process data
        Collection<Ticket> customerTickets = system.getCustomerBookings("customer1");
        double totalSpent = customerTickets.stream()
                .mapToDouble(ticket -> ticket.getPrice() * ticket.getQuantity())
                .sum();
        
        System.out.println("Total spent by customer1: $" + totalSpent);
        
        Collection<Ticket> eventTickets = system.getTicketsForEvent("event1");
        double revenue = eventTickets.stream()
                .mapToDouble(ticket -> ticket.getPrice() * ticket.getQuantity())
                .sum();
                
        System.out.println("Revenue from event1: $" + revenue);
    }
}