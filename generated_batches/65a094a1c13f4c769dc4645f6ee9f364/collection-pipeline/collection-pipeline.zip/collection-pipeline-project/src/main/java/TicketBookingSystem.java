package com.example.ticketbooking;

import java.util.Collection;
import java.util.stream.Collectors;

public class TicketBookingSystem {
    private TicketRepository repository;
    
    public TicketBookingSystem() {
        this.repository = new TicketRepository();
    }
    
    public void bookTicket(String eventId, String customerId, int quantity, double price) {
        Ticket ticket = new Ticket(eventId, customerId, quantity, price);
        repository.addTicket(ticket);
    }
    
    public Collection<Ticket> getTicketsForEvent(String eventId) {
        return repository.findByEvent(eventId);
    }
    
    public Collection<Ticket> getCustomerBookings(String customerId) {
        return repository.findByCustomer(customerId);
    }
    
    public double calculateTotalRevenue() {
        return repository.getTotalRevenue();
    }
    
    public Collection<Ticket> findHighValueBookings(double minAmount) {
        return repository.getTicketsByEventAndCustomer("event1", "customer1")
                .stream()
                .filter(ticket -> ticket.getPrice() * ticket.getQuantity() >= minAmount)
                .collect(Collectors.toList());
    }
}