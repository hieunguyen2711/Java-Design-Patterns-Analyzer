package com.example.ticketbooking;

public class Ticket {
    private String eventId;
    private String customerId;
    private int quantity;
    private double price;
    
    public Ticket(String eventId, String customerId, int quantity, double price) {
        this.eventId = eventId;
        this.customerId = customerId;
        this.quantity = quantity;
        this.price = price;
    }
    
    // Getters
    public String getEventId() { return eventId; }
    public String getCustomerId() { return customerId; }
    public int getQuantity() { return quantity; }
    public double getPrice() { return price; }
    
    // Setters
    public void setEventId(String eventId) { this.eventId = eventId; }
    public void setCustomerId(String customerId) { this.customerId = customerId; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public void setPrice(double price) { this.price = price; }
}