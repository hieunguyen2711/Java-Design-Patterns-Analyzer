package com.example.ticketbooking;

import java.util.concurrent.atomic.AtomicLong;

public class TicketBookingSystem {
    private final AtomicLong ticketCounter = new AtomicLong(0);
    
    public void bookTicket(String customerName, Runnable operation) {
        long ticketId = ticketCounter.incrementAndGet();
        System.out.println("Booking ticket #" + ticketId + " for " + customerName);
        
        try {
            operation.run();
        } finally {
            System.out.println("Cleaning up after ticket #" + ticketId);
        }
    }
}