package com.example.ticketbooking;

public class Main {
    public static void main(String[] args) {
        TicketBookingSystem bookingSystem = new TicketBookingSystem();
        TicketBookingService service = new TicketBookingService(bookingSystem);
        
        service.processBooking("John Doe", "Concert A");
        System.out.println("---");
        service.processBooking("Jane Smith", "Movie B");
    }
}