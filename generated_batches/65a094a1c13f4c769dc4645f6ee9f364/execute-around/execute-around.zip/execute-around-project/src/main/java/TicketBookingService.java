package com.example.ticketbooking;

public class TicketBookingService {
    private final TicketBookingSystem bookingSystem;
    
    public TicketBookingService(TicketBookingSystem bookingSystem) {
        this.bookingSystem = bookingSystem;
    }
    
    public void processBooking(String customerName, String event) {
        bookingSystem.bookTicket(customerName, () -> {
            System.out.println("Processing booking for event: " + event);
            // Simulate some booking logic
            try {
                Thread.sleep(100);
                System.out.println("Booking confirmed for " + customerName + " at " + event);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
    }
}