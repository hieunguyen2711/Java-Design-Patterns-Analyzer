public abstract class Ticket {
    protected String event;
    protected double price;
    
    public Ticket(String event, double price) {
        this.event = event;
        this.price = price;
    }
    
    public abstract String getDetails();
    
    public String getEvent() {
        return event;
    }
    
    public double getPrice() {
        return price;
    }
}