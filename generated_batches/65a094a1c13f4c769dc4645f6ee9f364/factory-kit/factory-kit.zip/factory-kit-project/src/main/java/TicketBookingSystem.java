public class TicketBookingSystem {
    public static void main(String[] args) {
        // Using the factory kit to create different types of tickets
        TicketFactory factory = new TicketFactory();
        
        Ticket concertTicket = factory.createTicket("CONCERT", "Rock Concert", 100.0);
        Ticket movieTicket = factory.createTicket("MOVIE", "Action Movie", 25.0);
        Ticket sportsTicket = factory.createTicket("SPORTS", "Football Match", 75.0);
        
        System.out.println(concertTicket.getDetails());
        System.out.println(movieTicket.getDetails());
        System.out.println(sportsTicket.getDetails());
    }
}