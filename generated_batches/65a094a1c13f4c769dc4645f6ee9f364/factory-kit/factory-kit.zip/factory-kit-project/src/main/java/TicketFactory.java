public class TicketFactory {
    public Ticket createTicket(String type, String event, double price) {
        switch (type.toUpperCase()) {
            case "CONCERT":
                return new ConcertTicket(event, price, "Main Arena");
            case "MOVIE":
                return new MovieTicket(event, price, "Cinema Hall 1");
            case "SPORTS":
                return new SportsTicket(event, price, "Stadium Center");
            default:
                throw new IllegalArgumentException("Unknown ticket type: " + type);
        }
    }
}