public interface BookingService {
    String createBooking(String userId, String eventId);
}