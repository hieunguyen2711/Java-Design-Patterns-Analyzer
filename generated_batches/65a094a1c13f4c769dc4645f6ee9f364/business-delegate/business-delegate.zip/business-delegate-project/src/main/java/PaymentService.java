public interface PaymentService {
    void processPayment(String ticketId);
}