public class PaymentServiceImpl implements PaymentService {
    @Override
    public void processPayment(String ticketId) {
        // Simulate payment processing
        System.out.println("Processing payment for ticket " + ticketId);
    }
}