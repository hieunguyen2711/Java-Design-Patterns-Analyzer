public class BookingServiceImpl implements BookingService {
    @Override
    public String createBooking(String userId, String eventId) {
        // Simulate booking creation
        System.out.println("Creating booking for user " + userId + " and event " + eventId);
        return "TICKET-12345";
    }
}