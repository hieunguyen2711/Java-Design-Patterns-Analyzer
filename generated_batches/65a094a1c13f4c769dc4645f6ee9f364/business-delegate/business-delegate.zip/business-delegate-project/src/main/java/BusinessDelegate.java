public class BusinessDelegate {
    private BookingService bookingService;
    private PaymentService paymentService;
    
    public void bookTicket(String userId, String eventId) {
        // Business logic coordination
        if (bookingService == null) {
            bookingService = new BookingServiceImpl();
        }
        
        if (paymentService == null) {
            paymentService = new PaymentServiceImpl();
        }
        
        // Delegate to appropriate services
        String ticketId = bookingService.createBooking(userId, eventId);
        paymentService.processPayment(ticketId);
    }
}