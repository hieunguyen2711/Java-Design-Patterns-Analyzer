public class TicketBookingClient {
    public static void main(String[] args) {
        BusinessDelegate delegate = new BusinessDelegate();
        delegate.bookTicket("USER-001", "EVENT-54321");
    }
}