public class MovieTicketBooking extends BookingProcess {
    @Override
    protected void selectTicketType() {
        System.out.println("Selecting movie ticket type (2D/3D)");
    }
    
    @Override
    protected void processPayment() {
        System.out.println("Processing payment via credit card for movie");
    }
}