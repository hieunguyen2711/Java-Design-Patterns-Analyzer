public class TicketBookingSystem {
    public static void main(String[] args) {
        BookingProcess booking1 = new MovieTicketBooking();
        BookingProcess booking2 = new ConcertTicketBooking();
        
        System.out.println("Movie Booking:");
        booking1.executeBooking();
        
        System.out.println("\nConcert Booking:");
        booking2.executeBooking();
    }
}