public class ConcertTicketBooking extends BookingProcess {
    @Override
    protected void selectTicketType() {
        System.out.println("Selecting concert ticket type (VIP/General)");
    }
    
    @Override
    protected void processPayment() {
        System.out.println("Processing payment via mobile wallet for concert");
    }
}