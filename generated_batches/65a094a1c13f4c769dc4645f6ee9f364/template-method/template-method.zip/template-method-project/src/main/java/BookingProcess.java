public abstract class BookingProcess {
    // Template method
    public final void executeBooking() {
        selectTicketType();
        processPayment();
        confirmBooking();
        sendConfirmation();
    }
    
    protected abstract void selectTicketType();
    protected abstract void processPayment();
    
    // Common implementation
    protected void confirmBooking() {
        System.out.println("Booking confirmed");
    }
    
    private void sendConfirmation() {
        System.out.println("Confirmation sent to customer");
    }
}