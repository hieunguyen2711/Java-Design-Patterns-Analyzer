package com.example.ticketbooking;

public class MovieTicket extends Ticket {
    private String movieTitle;
    private String theater;
    
    public MovieTicket(String id, double price, String movieTitle, String theater) {
        super(id, price);
        this.movieTitle = movieTitle;
        this.theater = theater;
    }
    
    @Override
    public void book() {
        if (!isBooked) {
            isBooked = true;
            System.out.println("Movie ticket " + id + " booked for " + movieTitle + " at " + theater);
        }
    }
    
    @Override
    public void cancel() {
        if (isBooked) {
            isBooked = false;
            System.out.println("Movie ticket " + id + " cancelled");
        }
    }
    
    public String getMovieTitle() {
        return movieTitle;
    }
    
    public String getTheater() {
        return theater;
    }
}