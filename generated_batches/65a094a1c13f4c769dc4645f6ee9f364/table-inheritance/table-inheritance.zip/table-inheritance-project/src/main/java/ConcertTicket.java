package com.example.ticketbooking;

public class ConcertTicket extends Ticket {
    private String venue;
    private String date;
    
    public ConcertTicket(String id, double price, String venue, String date) {
        super(id, price);
        this.venue = venue;
        this.date = date;
    }
    
    @Override
    public void book() {
        if (!isBooked) {
            isBooked = true;
            System.out.println("Concert ticket " + id + " booked at " + venue + " on " + date);
        }
    }
    
    @Override
    public void cancel() {
        if (isBooked) {
            isBooked = false;
            System.out.println("Concert ticket " + id + " cancelled");
        }
    }
    
    public String getVenue() {
        return venue;
    }
    
    public String getDate() {
        return date;
    }
}