package com.example.ticketbooking;

import java.util.ArrayList;
import java.util.List;

public class TicketBookingSystem {
    private List<Ticket> tickets;
    
    public TicketBookingSystem() {
        this.tickets = new ArrayList<>();
    }
    
    public void addTicket(Ticket ticket) {
        tickets.add(ticket);
    }
    
    public void bookAllTickets() {
        for (Ticket ticket : tickets) {
            ticket.book();
        }
    }
    
    public static void main(String[] args) {
        TicketBookingSystem system = new TicketBookingSystem();
        
        ConcertTicket concert1 = new ConcertTicket("C001", 85.50, "Madison Square Garden", "2023-12-15");
        MovieTicket movie1 = new MovieTicket("M001", 25.00, "Avengers: Endgame", "AMC Theater 1");
        
        system.addTicket(concert1);
        system.addTicket(movie1);
        
        system.bookAllTickets();
    }
}