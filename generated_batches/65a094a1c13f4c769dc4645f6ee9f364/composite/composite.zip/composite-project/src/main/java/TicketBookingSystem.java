public class TicketBookingSystem {
    public static void main(String[] args) {
        // Create individual tickets
        TicketComponent singleTicket = new SingleTicket("VIP Seat", 250.0);
        TicketComponent standardTicket = new SingleTicket("Standard Seat", 100.0);
        
        // Create ticket groups
        TicketComponent groupOfTickets = new TicketGroup();
        ((TicketGroup) groupOfTickets).addTicket(new SingleTicket("Child Ticket", 50.0));
        ((TicketGroup) groupOfTickets).addTicket(new SingleTicket("Student Ticket", 75.0));
        
        // Create a concert package
        TicketComponent concertPackage = new TicketGroup();
        ((TicketGroup) concertPackage).addTicket(singleTicket);
        ((TicketGroup) concertPackage).addTicket(standardTicket);
        ((TicketGroup) concertPackage).addTicket(groupOfTickets);
        
        // Display the total price
        System.out.println("Total price: $" + concertPackage.getPrice());
    }
}