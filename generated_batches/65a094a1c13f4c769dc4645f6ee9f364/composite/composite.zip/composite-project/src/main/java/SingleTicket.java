public class SingleTicket implements TicketComponent {
    private String description;
    private double price;
    
    public SingleTicket(String description, double price) {
        this.description = description;
        this.price = price;
    }
    
    @Override
    public double getPrice() {
        return price;
    }
    
    @Override
    public void addTicket(TicketComponent ticket) {
        // Single tickets cannot contain other tickets
        throw new UnsupportedOperationException("Cannot add tickets to a single ticket");
    }
    
    @Override
    public void removeTicket(TicketComponent ticket) {
        // Single tickets cannot contain other tickets
        throw new UnsupportedOperationException("Cannot remove tickets from a single ticket");
    }
}