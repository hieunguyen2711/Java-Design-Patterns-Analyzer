import java.util.ArrayList;
import java.util.List;

public class TicketGroup implements TicketComponent {
    private List<TicketComponent> tickets;
    
    public TicketGroup() {
        this.tickets = new ArrayList<>();
    }
    
    @Override
    public double getPrice() {
        return tickets.stream().mapToDouble(TicketComponent::getPrice).sum();
    }
    
    @Override
    public void addTicket(TicketComponent ticket) {
        tickets.add(ticket);
    }
    
    @Override
    public void removeTicket(TicketComponent ticket) {
        tickets.remove(ticket);
    }
}