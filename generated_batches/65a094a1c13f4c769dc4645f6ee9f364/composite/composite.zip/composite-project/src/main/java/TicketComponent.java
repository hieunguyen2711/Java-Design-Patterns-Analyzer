public interface TicketComponent {
    double getPrice();
    void addTicket(TicketComponent ticket);
    void removeTicket(TicketComponent ticket);
}