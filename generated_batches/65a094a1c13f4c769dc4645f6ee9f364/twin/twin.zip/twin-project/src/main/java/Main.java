package com.example.ticketbooking;

public class Main {
    public static void main(String[] args) {
        // Demonstrating twin pattern with singleton instances
        TicketBookingSystem system1 = TicketBookingSystem.getInstance();
        TicketBookingSystem system2 = TicketBookingSystem.getInstance();
        
        BookingService service1 = BookingService.getInstance();
        BookingService service2 = BookingService.getInstance();
        
        System.out.println("System 1 == System 2: " + (system1 == system2));
        System.out.println("Service 1 == Service 2: " + (service1 == service2));
        
        // Using the twin pattern in context
        Ticket ticket = new Ticket("T001", "Concert", 50.0);
        TicketBookingContext context = new TicketBookingContext(service1, ticket);
        context.bookTicket();
    }
}