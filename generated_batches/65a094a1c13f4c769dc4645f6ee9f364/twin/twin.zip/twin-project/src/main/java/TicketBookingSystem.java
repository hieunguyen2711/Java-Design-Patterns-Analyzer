package com.example.ticketbooking;

public class TicketBookingSystem {
    private static volatile TicketBookingSystem instance;
    private final String systemName;
    
    private TicketBookingSystem(String systemName) {
        this.systemName = systemName;
    }
    
    public static TicketBookingSystem getInstance() {
        if (instance == null) {
            synchronized (TicketBookingSystem.class) {
                if (instance == null) {
                    instance = new TicketBookingSystem("Main Booking System");
                }
            }
        }
        return instance;
    }
    
    public String getSystemName() {
        return systemName;
    }
}