package com.example.ticketbooking;

public class BookingService {
    private static volatile BookingService instance;
    private final TicketBookingSystem bookingSystem;
    
    private BookingService(TicketBookingSystem bookingSystem) {
        this.bookingSystem = bookingSystem;
    }
    
    public static BookingService getInstance() {
        if (instance == null) {
            synchronized (BookingService.class) {
                if (instance == null) {
                    instance = new BookingService(TicketBookingSystem.getInstance());
                }
            }
        }
        return instance;
    }
    
    public String getSystemName() {
        return bookingSystem.getSystemName();
    }
}