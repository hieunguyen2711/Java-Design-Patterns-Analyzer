package com.example.ticketbooking;

public class TicketBookingContext {
    private final BookingService bookingService;
    private final Ticket ticket;
    
    public TicketBookingContext(BookingService bookingService, Ticket ticket) {
        this.bookingService = bookingService;
        this.ticket = ticket;
    }
    
    public void bookTicket() {
        System.out.println("Booking ticket " + ticket.getTicketId() + 
                          " for event: " + ticket.getEventName());
        System.out.println("Using system: " + bookingService.getSystemName());
    }
}