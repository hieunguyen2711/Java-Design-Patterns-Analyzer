package com.example.ticketbooking;

public class Ticket {
    private final String ticketId;
    private final String eventName;
    private final double price;
    
    public Ticket(String ticketId, String eventName, double price) {
        this.ticketId = ticketId;
        this.eventName = eventName;
        this.price = price;
    }
    
    public String getTicketId() {
        return ticketId;
    }
    
    public String getEventName() {
        return eventName;
    }
    
    public double getPrice() {
        return price;
    }
}