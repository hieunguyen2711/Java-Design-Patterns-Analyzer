package com.example.ticketbooking;

public class Ticket {
    private int seatNumber;
    private boolean booked;
    private boolean paid;
    
    public Ticket(int seatNumber, boolean booked, boolean paid) {
        this.seatNumber = seatNumber;
        this.booked = booked;
        this.paid = paid;
    }
    
    public int getSeatNumber() {
        return seatNumber;
    }
    
    public boolean isBooked() {
        return booked;
    }
    
    public void setBooked(boolean booked) {
        this.booked = booked;
    }
    
    public boolean isPaid() {
        return paid;
    }
    
    public void setPaid(boolean paid) {
        this.paid = paid;
    }
    
    @Override
    public String toString() {
        return "Ticket{seatNumber=" + seatNumber + ", booked=" + booked + ", paid=" + paid + '}';
    }
}