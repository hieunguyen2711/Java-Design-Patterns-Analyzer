package com.example.ticketbooking;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        TicketRepository repository = new InMemoryTicketRepository();
        TicketBookingService service = new TicketBookingService(repository);
        
        // Book some tickets
        Ticket ticket1 = service.bookTicket("Concert", "A1", 50.0);
        Ticket ticket2 = service.bookTicket("Movie", "B2", 25.0);
        
        System.out.println("Booked tickets:");
        List<Ticket> allTickets = service.getAllTickets();
        for (Ticket ticket : allTickets) {
            System.out.println("ID: " + ticket.getId() + 
                             ", Event: " + ticket.getEventName() + 
                             ", Seat: " + ticket.getSeatNumber() + 
                             ", Price: $" + ticket.getPrice());
        }
        
        // Retrieve a specific ticket
        Ticket retrievedTicket = service.getTicket(ticket1.getId());
        System.out.println("\nRetrieved ticket:");
        if (retrievedTicket != null) {
            System.out.println("ID: " + retrievedTicket.getId() + 
                             ", Event: " + retrievedTicket.getEventName() + 
                             ", Seat: " + retrievedTicket.getSeatNumber() + 
                             ", Price: $" + retrievedTicket.getPrice());
        }
        
        // Cancel a ticket
        service.cancelTicket(ticket2.getId());
        System.out.println("\nAfter cancelling ticket:");
        allTickets = service.getAllTickets();
        for (Ticket ticket : allTickets) {
            System.out.println("ID: " + ticket.getId() + 
                             ", Event: " + ticket.getEventName() + 
                             ", Seat: " + ticket.getSeatNumber() + 
                             ", Price: $" + ticket.getPrice());
        }
    }
}