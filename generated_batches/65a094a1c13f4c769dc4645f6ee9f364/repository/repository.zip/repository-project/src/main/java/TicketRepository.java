package com.example.ticketbooking;

import java.util.List;
import java.util.ArrayList;

public interface TicketRepository {
    Ticket save(Ticket ticket);
    Ticket findById(int id);
    List<Ticket> findAll();
    void deleteById(int id);
}