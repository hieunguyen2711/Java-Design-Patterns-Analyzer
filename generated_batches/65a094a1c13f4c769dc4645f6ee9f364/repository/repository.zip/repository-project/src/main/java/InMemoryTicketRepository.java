package com.example.ticketbooking;

import java.util.List;
import java.util.ArrayList;
import java.util.stream.Collectors;

public class InMemoryTicketRepository implements TicketRepository {
    private List<Ticket> tickets = new ArrayList<>();
    private int nextId = 1;
    
    @Override
    public Ticket save(Ticket ticket) {
        if (ticket.getId() == 0) {
            ticket.setId(nextId++);
        }
        tickets.add(ticket);
        return ticket;
    }
    
    @Override
    public Ticket findById(int id) {
        return tickets.stream()
                .filter(ticket -> ticket.getId() == id)
                .findFirst()
                .orElse(null);
    }
    
    @Override
    public List<Ticket> findAll() {
        return new ArrayList<>(tickets);
    }
    
    @Override
    public void deleteById(int id) {
        tickets = tickets.stream()
                .filter(ticket -> ticket.getId() != id)
                .collect(Collectors.toList());
    }
}