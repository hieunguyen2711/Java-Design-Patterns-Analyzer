package com.example.ticketbooking;

import java.util.List;

public class TicketBookingService {
    private final TicketRepository repository;
    
    public TicketBookingService(TicketRepository repository) {
        this.repository = repository;
    }
    
    public Ticket bookTicket(String eventName, String seatNumber, double price) {
        Ticket ticket = new Ticket(0, eventName, seatNumber, price);
        return repository.save(ticket);
    }
    
    public Ticket getTicket(int id) {
        return repository.findById(id);
    }
    
    public List<Ticket> getAllTickets() {
        return repository.findAll();
    }
    
    public void cancelTicket(int id) {
        repository.deleteById(id);
    }
}