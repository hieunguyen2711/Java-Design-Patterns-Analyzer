package com.ticketbooking;

import com.ticketbooking.service.TicketBookingService;
import com.ticketbooking.service.impl.TicketBookingServiceImpl;
import com.ticketbooking.model.Ticket;
import java.util.List;

public class MainApplication {
    public static void main(String[] args) {
        TicketBookingService bookingService = new TicketBookingServiceImpl();
        
        // Search for tickets
        List<Ticket> nyTickets = bookingService.searchTickets("New York");
        System.out.println("Available New York tickets:");
        for (Ticket ticket : nyTickets) {
            System.out.println("- ID: " + ticket.getId() + ", Price: $" + ticket.getPrice());
        }
        
        // Book a ticket
        boolean booked = bookingService.bookTicket(1, "John Doe");
        System.out.println("Booking successful: " + booked);
        
        // Search again to see availability change
        List<Ticket> updatedTickets = bookingService.searchTickets("New York");
        System.out.println("Updated New York tickets:");
        for (Ticket ticket : updatedTickets) {
            System.out.println("- ID: " + ticket.getId() + ", Price: $" + ticket.getPrice());
        }
    }
}