package com.ticketbooking.service.impl;

import com.ticketbooking.service.TicketBookingService;
import com.ticketbooking.model.Ticket;
import com.ticketbooking.model.BookingRecord;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

public class TicketBookingServiceImpl implements TicketBookingService {
    private List<Ticket> tickets;
    private Map<Integer, BookingRecord> bookings;
    private int bookingCounter = 0;
    
    public TicketBookingServiceImpl() {
        this.tickets = new ArrayList<>();
        this.bookings = new HashMap<>();
        initializeTickets();
    }
    
    private void initializeTickets() {
        tickets.add(new Ticket(1, "New York", 250.0));
        tickets.add(new Ticket(2, "Los Angeles", 300.0));
        tickets.add(new Ticket(3, "Chicago", 180.0));
        tickets.add(new Ticket(4, "Miami", 220.0));
    }
    
    @Override
    public List<Ticket> searchTickets(String destination) {
        List<Ticket> results = new ArrayList<>();
        for (Ticket ticket : tickets) {
            if (ticket.getDestination().equalsIgnoreCase(destination) && ticket.isAvailable()) {
                results.add(ticket);
            }
        }
        return results;
    }
    
    @Override
    public boolean bookTicket(int ticketId, String customerName) {
        Ticket ticket = findTicketById(ticketId);
        if (ticket != null && ticket.isAvailable()) {
            ticket.setAvailable(false);
            bookings.put(++bookingCounter, new BookingRecord(bookingCounter, ticketId, customerName));
            return true;
        }
        return false;
    }
    
    @Override
    public boolean cancelBooking(int bookingId) {
        if (bookings.containsKey(bookingId)) {
            int ticketId = bookings.get(bookingId).getTicketId();
            Ticket ticket = findTicketById(ticketId);
            if (ticket != null) {
                ticket.setAvailable(true);
                bookings.remove(bookingId);
                return true;
            }
        }
        return false;
    }
    
    private Ticket findTicketById(int id) {
        for (Ticket ticket : tickets) {
            if (ticket.getId() == id) {
                return ticket;
            }
        }
        return null;
    }
}