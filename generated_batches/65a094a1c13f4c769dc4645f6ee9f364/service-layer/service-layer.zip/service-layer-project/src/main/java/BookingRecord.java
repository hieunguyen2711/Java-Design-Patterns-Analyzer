package com.ticketbooking.model;

public class BookingRecord {
    private int id;
    private int ticketId;
    private String customerName;
    
    public BookingRecord(int id, int ticketId, String customerName) {
        this.id = id;
        this.ticketId = ticketId;
        this.customerName = customerName;
    }
    
    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getTicketId() { return ticketId; }
    public void setTicketId(int ticketId) { this.ticketId = ticketId; }
    
    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }
}