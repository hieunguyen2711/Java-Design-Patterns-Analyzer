package com.ticketbooking.model;

public class Ticket {
    private int id;
    private String destination;
    private double price;
    private boolean available;
    
    public Ticket(int id, String destination, double price) {
        this.id = id;
        this.destination = destination;
        this.price = price;
        this.available = true;
    }
    
    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }
    
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
    
    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }
}