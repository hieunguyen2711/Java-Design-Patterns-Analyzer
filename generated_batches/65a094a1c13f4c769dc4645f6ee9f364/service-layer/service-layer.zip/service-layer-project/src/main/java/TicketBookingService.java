package com.ticketbooking.service;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

public interface TicketBookingService {
    List<Ticket> searchTickets(String destination);
    boolean bookTicket(int ticketId, String customerName);
    boolean cancelBooking(int bookingId);
}