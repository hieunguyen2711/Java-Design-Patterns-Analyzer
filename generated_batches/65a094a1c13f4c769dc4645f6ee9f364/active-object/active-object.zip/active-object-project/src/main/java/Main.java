public class Main {
    public static void main(String[] args) {
        TicketBookingService service = new TicketBookingService();
        TicketBookingSystem system = new TicketBookingSystem(service);
        
        // Simulate concurrent booking requests
        Thread user1 = new Thread(() -> {
            system.bookTicket("user1", "event1");
            system.bookTicket("user1", "event2");
        });
        
        Thread user2 = new Thread(() -> {
            system.bookTicket("user2", "event3");
            system.cancelTicket("user2", "event3");
        });
        
        user1.start();
        user2.start();
        
        try {
            user1.join();
            user2.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        System.out.println("All requests processed.");
    }
}