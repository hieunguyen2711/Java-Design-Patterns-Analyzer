import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class TicketBookingService implements ActiveObject {
    private final BlockingQueue<Runnable> requestQueue = new LinkedBlockingQueue<>();
    
    public TicketBookingService() {
        // Start the processing thread
        Thread processorThread = new Thread(() -> {
            while (!Thread.currentThread().isInterrupted()) {
                try {
                    Runnable request = requestQueue.take();
                    request.run();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        });
        processorThread.start();
    }
    
    @Override
    public void bookTicket(String userId, String eventId) {
        requestQueue.add(() -> {
            System.out.println("Booking ticket for user: " + userId + ", event: " + eventId);
            // Simulate booking logic
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            System.out.println("Ticket booked successfully for user: " + userId);
        });
    }
    
    @Override
    public void cancelTicket(String userId, String eventId) {
        requestQueue.add(() -> {
            System.out.println("Canceling ticket for user: " + userId + ", event: " + eventId);
            // Simulate cancellation logic
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            System.out.println("Ticket canceled successfully for user: " + userId);
        });
    }
    
    @Override
    public void processRequests() {
        // This method is implicitly handled by the background thread
    }
}