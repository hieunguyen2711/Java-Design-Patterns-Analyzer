public class TicketBookingSystem {
    private final ActiveObject activeObject;
    
    public TicketBookingSystem(ActiveObject activeObject) {
        this.activeObject = activeObject;
    }
    
    public void bookTicket(String userId, String eventId) {
        activeObject.bookTicket(userId, eventId);
    }
    
    public void cancelTicket(String userId, String eventId) {
        activeObject.cancelTicket(userId, eventId);
    }
}