public interface ActiveObject {
    void bookTicket(String userId, String eventId);
    void cancelTicket(String userId, String eventId);
    void processRequests();
}