public class BookTicketCommand implements BookingCommand {
    private TicketService service;
    
    public BookTicketCommand(TicketService service) {
        this.service = service;
    }
    
    @Override
    public void execute(String ticketId, String customerName) {
        service.bookTicket(ticketId, customerName);
    }
}