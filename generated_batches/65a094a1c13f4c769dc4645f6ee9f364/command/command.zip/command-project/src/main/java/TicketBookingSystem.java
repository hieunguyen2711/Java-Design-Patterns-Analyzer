public class TicketBookingSystem {
    public static void main(String[] args) {
        // Create command invoker
        BookingInvoker invoker = new BookingInvoker();
        
        // Create command objects
        BookTicketCommand bookCommand = new BookTicketCommand(new TicketService());
        CancelTicketCommand cancelCommand = new CancelTicketCommand(new TicketService());
        
        // Execute commands
        invoker.setCommand(bookCommand);
        invoker.executeCommand("VIP-123", "John Doe");
        
        invoker.setCommand(cancelCommand);
        invoker.executeCommand("VIP-123", null);
    }
}