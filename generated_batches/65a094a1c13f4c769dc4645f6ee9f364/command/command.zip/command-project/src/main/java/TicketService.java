public class TicketService {
    public void bookTicket(String ticketId, String customerName) {
        System.out.println("Booking ticket " + ticketId + " for " + customerName);
    }
    
    public void cancelTicket(String ticketId) {
        System.out.println("Canceling ticket " + ticketId);
    }
}