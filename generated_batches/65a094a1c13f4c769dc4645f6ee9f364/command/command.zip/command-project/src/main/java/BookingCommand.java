public interface BookingCommand {
    void execute(String ticketId, String customerName);
}