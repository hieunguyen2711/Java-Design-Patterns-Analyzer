public class CancelTicketCommand implements BookingCommand {
    private TicketService service;
    
    public CancelTicketCommand(TicketService service) {
        this.service = service;
    }
    
    @Override
    public void execute(String ticketId, String customerName) {
        service.cancelTicket(ticketId);
    }
}