public class BookingInvoker {
    private BookingCommand command;
    
    public void setCommand(BookingCommand command) {
        this.command = command;
    }
    
    public void executeCommand(String ticketId, String customerName) {
        if (command != null) {
            command.execute(ticketId, customerName);
        }
    }
}