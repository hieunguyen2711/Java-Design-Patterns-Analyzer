public class TicketBookingSystem {
    private final PaymentService paymentService;
    private final NotificationService notificationService;
    
    public TicketBookingSystem(PaymentService paymentService, 
                              NotificationService notificationService) {
        this.paymentService = paymentService;
        this.notificationService = notificationService;
    }
    
    public boolean bookTicket(String userId, double amount) {
        if (paymentService.processPayment(userId, amount)) {
            notificationService.sendConfirmation(userId);
            return true;
        }
        return false;
    }
}