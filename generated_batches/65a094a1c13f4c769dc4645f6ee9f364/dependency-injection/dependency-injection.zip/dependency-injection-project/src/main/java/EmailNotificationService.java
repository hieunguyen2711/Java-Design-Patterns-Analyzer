public class EmailNotificationService implements NotificationService {
    @Override
    public void sendConfirmation(String userId) {
        System.out.println("Sending confirmation email to user " + userId);
    }
}