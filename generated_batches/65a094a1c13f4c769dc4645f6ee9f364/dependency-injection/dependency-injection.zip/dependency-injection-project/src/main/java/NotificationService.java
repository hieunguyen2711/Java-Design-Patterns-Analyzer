public interface NotificationService {
    void sendConfirmation(String userId);
}