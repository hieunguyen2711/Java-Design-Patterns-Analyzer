public interface PaymentService {
    boolean processPayment(String userId, double amount);
}