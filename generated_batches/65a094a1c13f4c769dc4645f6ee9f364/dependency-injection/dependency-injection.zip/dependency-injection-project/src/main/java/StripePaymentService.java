public class StripePaymentService implements PaymentService {
    @Override
    public boolean processPayment(String userId, double amount) {
        System.out.println("Processing payment of $" + amount + " for user " + userId + " via Stripe");
        return true;
    }
}