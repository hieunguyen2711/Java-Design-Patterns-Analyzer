public class Main {
    public static void main(String[] args) {
        PaymentService paymentService = new StripePaymentService();
        NotificationService notificationService = new EmailNotificationService();
        
        TicketBookingSystem bookingSystem = new TicketBookingSystem(
            paymentService, 
            notificationService
        );
        
        bookingSystem.bookTicket("user123", 50.0);
    }
}