public abstract class PageController {
    public abstract void handleRequest(String action, String event);
}