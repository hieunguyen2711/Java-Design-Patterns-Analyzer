public class BookingPageController extends PageController {
    @Override
    public void handleRequest(String action, String event) {
        if ("BOOK_TICKETS".equals(action)) {
            System.out.println("Booking tickets for " + event);
        } else if ("VIEW_SCHEDULE".equals(action)) {
            System.out.println("Viewing schedule for " + event);
        }
    }
}