public class TicketBookingSystem {
    public static void main(String[] args) {
        PageController controller = new BookingPageController();
        controller.handleRequest("BOOK_TICKETS", "Concert");
        controller.handleRequest("VIEW_SCHEDULE", "Movie");
    }
}