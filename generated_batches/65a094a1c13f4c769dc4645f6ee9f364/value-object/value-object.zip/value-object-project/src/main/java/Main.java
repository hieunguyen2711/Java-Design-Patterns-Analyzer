package com.booking.system;

public class Main {
    public static void main(String[] args) {
        BookingService service = new BookingService();
        
        Ticket ticket1 = TicketBuilder.aTicket()
                .withId("T001")
                .withEventName("Concert")
                .withSeatNumber("A12")
                .withPrice(85.50)
                .build();
                
        Ticket ticket2 = new Ticket("T002", "Movie", "B5", 25.00);
        
        service.addTicket(ticket1);
        service.addTicket(ticket2);
        
        System.out.println("All tickets:");
        service.getAllTickets().forEach(System.out::println);
        
        System.out.println("\nFound ticket by ID T001:");
        Ticket found = service.findTicketById("T001");
        if (found != null) {
            System.out.println(found);
        }
    }
}