package com.booking.system;

public class TicketBuilder {
    private String id;
    private String eventName;
    private String seatNumber;
    private double price;
    
    public static TicketBuilder aTicket() {
        return new TicketBuilder();
    }
    
    public TicketBuilder withId(String id) {
        this.id = id;
        return this;
    }
    
    public TicketBuilder withEventName(String eventName) {
        this.eventName = eventName;
        return this;
    }
    
    public TicketBuilder withSeatNumber(String seatNumber) {
        this.seatNumber = seatNumber;
        return this;
    }
    
    public TicketBuilder withPrice(double price) {
        this.price = price;
        return this;
    }
    
    public Ticket build() {
        return new Ticket(id, eventName, seatNumber, price);
    }
}