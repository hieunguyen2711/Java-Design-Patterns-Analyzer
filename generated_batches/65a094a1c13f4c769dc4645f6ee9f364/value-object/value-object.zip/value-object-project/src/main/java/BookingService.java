package com.booking.system;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class BookingService {
    private final List<Ticket> tickets = new ArrayList<>();
    
    public void addTicket(Ticket ticket) {
        Objects.requireNonNull(ticket, "Ticket cannot be null");
        tickets.add(ticket);
    }
    
    public Ticket findTicketById(String id) {
        return tickets.stream()
                .filter(t -> Objects.equals(t.getId(), id))
                .findFirst()
                .orElse(null);
    }
    
    public List<Ticket> getAllTickets() {
        return new ArrayList<>(tickets);
    }
}