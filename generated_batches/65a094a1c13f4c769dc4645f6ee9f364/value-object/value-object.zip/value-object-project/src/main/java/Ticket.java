package com.booking.system;

import java.util.Objects;

public final class Ticket {
    private final String id;
    private final String eventName;
    private final String seatNumber;
    private final double price;
    
    public Ticket(String id, String eventName, String seatNumber, double price) {
        this.id = Objects.requireNonNull(id, "Ticket ID cannot be null");
        this.eventName = Objects.requireNonNull(eventName, "Event name cannot be null");
        this.seatNumber = Objects.requireNonNull(seatNumber, "Seat number cannot be null");
        this.price = price;
    }
    
    public String getId() {
        return id;
    }
    
    public String getEventName() {
        return eventName;
    }
    
    public String getSeatNumber() {
        return seatNumber;
    }
    
    public double getPrice() {
        return price;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Ticket ticket = (Ticket) o;
        return Objects.equals(id, ticket.id);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
    
    @Override
    public String toString() {
        return "Ticket{" +
                "id='" + id + '\'' +
                ", eventName='" + eventName + '\'' +
                ", seatNumber='" + seatNumber + '\'' +
                ", price=" + price +
                '}';
    }
}