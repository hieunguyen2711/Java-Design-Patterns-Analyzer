public class TicketController {
    private TicketModel model;
    private TicketView view;
    
    public TicketController(TicketModel model, TicketView view) {
        this.model = model;
        this.view = view;
    }
    
    public void bookTicket(String customerName, String movieName, int numberOfSeats) {
        Ticket ticket = new Ticket(customerName, movieName, numberOfSeats);
        model.addTicket(ticket);
    }
    
    public void displayTickets() {
        view.displayTickets(model.getTickets());
    }
}