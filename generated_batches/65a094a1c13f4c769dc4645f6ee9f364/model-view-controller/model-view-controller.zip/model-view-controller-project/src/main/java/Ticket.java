public class Ticket {
    private String customerName;
    private String movieName;
    private int numberOfSeats;
    
    public Ticket(String customerName, String movieName, int numberOfSeats) {
        this.customerName = customerName;
        this.movieName = movieName;
        this.numberOfSeats = numberOfSeats;
    }
    
    public String getCustomerName() {
        return customerName;
    }
    
    public String getMovieName() {
        return movieName;
    }
    
    public int getNumberOfSeats() {
        return numberOfSeats;
    }
}