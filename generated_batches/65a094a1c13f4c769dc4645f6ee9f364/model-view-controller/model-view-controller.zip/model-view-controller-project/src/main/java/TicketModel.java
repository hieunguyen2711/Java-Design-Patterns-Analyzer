import java.util.ArrayList;
import java.util.List;

public class TicketModel {
    private List<Ticket> tickets;
    
    public TicketModel() {
        this.tickets = new ArrayList<>();
    }
    
    public void addTicket(Ticket ticket) {
        tickets.add(ticket);
    }
    
    public List<Ticket> getTickets() {
        return tickets;
    }
}