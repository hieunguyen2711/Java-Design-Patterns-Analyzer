public class TicketBookingSystem {
    public static void main(String[] args) {
        // Create model
        TicketModel model = new TicketModel();
        
        // Create view
        TicketView view = new TicketView();
        
        // Create controller
        TicketController controller = new TicketController(model, view);
        
        // Use the system
        controller.bookTicket("John Doe", "Movie1", 2);
        controller.bookTicket("Jane Smith", "Movie2", 1);
        controller.displayTickets();
    }
}