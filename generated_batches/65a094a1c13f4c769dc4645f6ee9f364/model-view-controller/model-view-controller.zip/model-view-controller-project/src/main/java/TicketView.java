import java.util.List;

public class TicketView {
    public void displayTickets(List<Ticket> tickets) {
        System.out.println("=== TICKET BOOKINGS ===");
        for (Ticket ticket : tickets) {
            System.out.println("Name: " + ticket.getCustomerName() + 
                             ", Movie: " + ticket.getMovieName() + 
                             ", Seats: " + ticket.getNumberOfSeats());
        }
        System.out.println("=======================");
    }
}