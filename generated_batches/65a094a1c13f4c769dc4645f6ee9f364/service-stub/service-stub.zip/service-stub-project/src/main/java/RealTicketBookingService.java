package com.ticketbooking.service;

import java.util.HashMap;
import java.util.Map;

public class RealTicketBookingService implements TicketBookingService {
    private Map<String, Integer> eventSeats = new HashMap<>();
    
    public RealTicketBookingService() {
        eventSeats.put("EVENT001", 100);
        eventSeats.put("EVENT002", 50);
    }
    
    @Override
    public boolean bookTicket(String eventId, String userId) {
        if (eventSeats.containsKey(eventId) && eventSeats.get(eventId) > 0) {
            eventSeats.put(eventId, eventSeats.get(eventId) - 1);
            System.out.println("Ticket booked for user " + userId + " at event " + eventId);
            return true;
        }
        return false;
    }
    
    @Override
    public boolean cancelTicket(String eventId, String userId) {
        if (eventSeats.containsKey(eventId)) {
            eventSeats.put(eventId, eventSeats.get(eventId) + 1);
            System.out.println("Ticket cancelled for user " + userId + " at event " + eventId);
            return true;
        }
        return false;
    }
}