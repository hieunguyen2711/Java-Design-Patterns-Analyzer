package com.ticketbooking.service;

public interface TicketBookingService {
    boolean bookTicket(String eventId, String userId);
    boolean cancelTicket(String eventId, String userId);
}