package com.ticketbooking.service;

public class TicketBookingClient {
    private TicketBookingService service;
    
    public TicketBookingClient(TicketBookingService service) {
        this.service = service;
    }
    
    public void performBooking(String eventId, String userId) {
        boolean result = service.bookTicket(eventId, userId);
        System.out.println("Booking result: " + result);
    }
    
    public static void main(String[] args) {
        // Using real service
        TicketBookingService realService = new RealTicketBookingService();
        TicketBookingClient client1 = new TicketBookingClient(realService);
        client1.performBooking("EVENT001", "USER001");
        
        // Using stub service for testing
        TicketBookingService stubService = new StubTicketBookingService();
        TicketBookingClient client2 = new TicketBookingClient(stubService);
        client2.performBooking("EVENT002", "USER002");
    }
}