package com.ticketbooking.service;

public class StubTicketBookingService implements TicketBookingService {
    
    @Override
    public boolean bookTicket(String eventId, String userId) {
        System.out.println("Stub booking ticket for user " + userId + " at event " + eventId);
        return true;
    }
    
    @Override
    public boolean cancelTicket(String eventId, String userId) {
        System.out.println("Stub cancelling ticket for user " + userId + " at event " + eventId);
        return true;
    }
}