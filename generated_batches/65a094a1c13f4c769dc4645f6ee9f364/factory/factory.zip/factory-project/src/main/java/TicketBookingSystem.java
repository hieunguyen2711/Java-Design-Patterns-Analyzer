public class TicketBookingSystem {
    public static void main(String[] args) {
        TicketFactory factory = new TicketFactory();
        
        Ticket concertTicket = factory.createTicket("CONCERT", "Rock Concert", 100);
        Ticket movieTicket = factory.createTicket("MOVIE", "Action Movie", 50);
        Ticket sportsTicket = factory.createTicket("SPORTS", "Football Match", 75);
        
        System.out.println(concertTicket.getDetails());
        System.out.println(movieTicket.getDetails());
        System.out.println(sportsTicket.getDetails());
    }
}