public class MovieTicket extends Ticket {
    private String theater;
    
    public MovieTicket(String event, int price, String theater) {
        super(event, price);
        this.theater = theater;
    }
    
    @Override
    public String getDetails() {
        return "Movie: " + event + " at " + theater + ", Price: $" + price;
    }
}