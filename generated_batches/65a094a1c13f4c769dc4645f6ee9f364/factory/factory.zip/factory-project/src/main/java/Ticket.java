public abstract class Ticket {
    protected String event;
    protected int price;
    
    public Ticket(String event, int price) {
        this.event = event;
        this.price = price;
    }
    
    public abstract String getDetails();
    
    public String getEvent() {
        return event;
    }
    
    public int getPrice() {
        return price;
    }
}