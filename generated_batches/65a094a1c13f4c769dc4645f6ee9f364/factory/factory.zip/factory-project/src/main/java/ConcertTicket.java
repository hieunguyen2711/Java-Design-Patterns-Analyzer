public class ConcertTicket extends Ticket {
    private String venue;
    
    public ConcertTicket(String event, int price, String venue) {
        super(event, price);
        this.venue = venue;
    }
    
    @Override
    public String getDetails() {
        return "Concert: " + event + " at " + venue + ", Price: $" + price;
    }
}