public class SportsTicket extends Ticket {
    private String stadium;
    
    public SportsTicket(String event, int price, String stadium) {
        super(event, price);
        this.stadium = stadium;
    }
    
    @Override
    public String getDetails() {
        return "Sports: " + event + " at " + stadium + ", Price: $" + price;
    }
}