package com.example.ticketbooking;

import java.util.HashMap;
import java.util.Map;

public class BookingSystem {
    private final Map<String, Ticket> tickets = new HashMap<>();
    
    public void bookTicket(String eventId, String seatNumber, double price) {
        Ticket ticket = new Ticket(eventId, seatNumber, price);
        tickets.put(seatNumber, ticket);
    }
    
    public Ticket getTicket(String seatNumber) {
        return tickets.get(seatNumber);
    }
    
    public Ticket updateTicketPrice(String seatNumber, double newPrice) {
        Ticket ticket = tickets.get(seatNumber);
        if (ticket != null) {
            Ticket updatedTicket = ticket.updatePrice(newPrice);
            tickets.put(seatNumber, updatedTicket);
            return updatedTicket;
        }
        return null;
    }
}