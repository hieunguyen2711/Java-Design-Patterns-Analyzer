package com.example.ticketbooking;

public class Main {
    public static void main(String[] args) {
        BookingSystem system = new BookingSystem();
        
        // Book a ticket
        system.bookTicket("EVENT001", "A1", 50.0);
        
        // Retrieve and display ticket information
        Ticket ticket = system.getTicket("A1");
        System.out.println("Event: " + ticket.getEventId());
        System.out.println("Seat: " + ticket.getSeatNumber());
        System.out.println("Price: $" + ticket.getPrice());
        
        // Update ticket price
        system.updateTicketPrice("A1", 60.0);
        
        // Retrieve updated ticket information
        Ticket updatedTicket = system.getTicket("A1");
        System.out.println("Updated Price: $" + updatedTicket.getPrice());
    }
}