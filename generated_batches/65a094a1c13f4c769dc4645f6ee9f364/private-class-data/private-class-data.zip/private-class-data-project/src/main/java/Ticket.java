package com.example.ticketbooking;

public class Ticket {
    private final String eventId;
    private final String seatNumber;
    private final double price;
    
    public Ticket(String eventId, String seatNumber, double price) {
        this.eventId = eventId;
        this.seatNumber = seatNumber;
        this.price = price;
    }
    
    // Private constructor for internal use only
    private Ticket(TicketData ticketData) {
        this.eventId = ticketData.eventId;
        this.seatNumber = ticketData.seatNumber;
        this.price = ticketData.price;
    }
    
    public String getEventId() {
        return eventId;
    }
    
    public String getSeatNumber() {
        return seatNumber;
    }
    
    public double getPrice() {
        return price;
    }
    
    // Factory method that returns a new Ticket with modified data
    public Ticket updatePrice(double newPrice) {
        return new Ticket(new TicketData(eventId, seatNumber, newPrice));
    }
    
    // Inner private class to hold ticket data
    private static class TicketData {
        private final String eventId;
        private final String seatNumber;
        private final double price;
        
        public TicketData(String eventId, String seatNumber, double price) {
            this.eventId = eventId;
            this.seatNumber = seatNumber;
            this.price = price;
        }
    }
}