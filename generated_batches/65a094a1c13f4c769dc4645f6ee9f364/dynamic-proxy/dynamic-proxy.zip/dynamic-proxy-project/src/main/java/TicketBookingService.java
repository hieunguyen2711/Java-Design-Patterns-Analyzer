public interface TicketBookingService {
    void bookTicket(String eventId, String userId);
    void cancelTicket(String eventId, String userId);
}