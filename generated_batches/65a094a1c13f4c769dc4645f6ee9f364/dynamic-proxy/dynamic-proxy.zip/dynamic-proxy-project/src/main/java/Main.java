public class Main {
    public static void main(String[] args) {
        TicketBookingService realService = new RealTicketBookingService();
        TicketBookingService proxyService = TicketBookingProxyFactory.createProxy(realService);
        
        proxyService.bookTicket("EVENT001", "USER123");
        System.out.println("---");
        proxyService.cancelTicket("EVENT001", "USER123");
    }
}