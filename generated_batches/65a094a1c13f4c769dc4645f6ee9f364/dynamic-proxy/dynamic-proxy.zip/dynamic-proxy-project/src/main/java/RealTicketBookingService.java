public class RealTicketBookingService implements TicketBookingService {
    @Override
    public void bookTicket(String eventId, String userId) {
        System.out.println("Booking ticket for event: " + eventId + " for user: " + userId);
    }
    
    @Override
    public void cancelTicket(String eventId, String userId) {
        System.out.println("Canceling ticket for event: " + eventId + " for user: " + userId);
    }
}