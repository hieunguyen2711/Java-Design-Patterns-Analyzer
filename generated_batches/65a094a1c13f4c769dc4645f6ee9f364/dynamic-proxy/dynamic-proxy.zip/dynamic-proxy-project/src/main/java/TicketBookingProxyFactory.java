import java.lang.reflect.Proxy;

public class TicketBookingProxyFactory {
    public static TicketBookingService createProxy(TicketBookingService target) {
        return (TicketBookingService) Proxy.newProxyInstance(
            target.getClass().getClassLoader(),
            new Class[]{TicketBookingService.class},
            new LoggingHandler(target)
        );
    }
}