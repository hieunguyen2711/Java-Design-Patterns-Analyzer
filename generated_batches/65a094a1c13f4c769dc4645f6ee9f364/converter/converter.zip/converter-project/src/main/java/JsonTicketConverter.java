package com.ticketbooking;

public class JsonTicketConverter implements TicketConverter {
    @Override
    public String convert(Ticket ticket) {
        return "{\n" +
                "  \"eventId\": \"" + ticket.getEventId() + "\",\n" +
                "  \"seatNumber\": \"" + ticket.getSeatNumber() + "\",\n" +
                "  \"price\": " + ticket.getPrice() + "\n" +
                "}";
    }
}