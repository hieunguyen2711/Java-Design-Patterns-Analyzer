package com.ticketbooking;

public class TicketConverterFactory {
    public static TicketConverter createConverter(String format) {
        switch (format.toLowerCase()) {
            case "json":
                return new JsonTicketConverter();
            case "xml":
                return new XmlTicketConverter();
            default:
                throw new IllegalArgumentException("Unsupported format: " + format);
        }
    }
}