package com.ticketbooking;

public class XmlTicketConverter implements TicketConverter {
    @Override
    public String convert(Ticket ticket) {
        return "<ticket>\n" +
                "  <eventId>" + ticket.getEventId() + "</eventId>\n" +
                "  <seatNumber>" + ticket.getSeatNumber() + "</seatNumber>\n" +
                "  <price>" + ticket.getPrice() + "</price>\n" +
                "</ticket>";
    }
}