package com.ticketbooking;

public class Main {
    public static void main(String[] args) {
        Ticket ticket = new Ticket("EVENT001", "A12", 85.50);
        
        // Convert to JSON
        TicketConverter jsonConverter = TicketConverterFactory.createConverter("json");
        System.out.println("JSON Format:");
        System.out.println(jsonConverter.convert(ticket));
        
        // Convert to XML
        TicketConverter xmlConverter = TicketConverterFactory.createConverter("xml");
        System.out.println("\nXML Format:");
        System.out.println(xmlConverter.convert(ticket));
    }
}