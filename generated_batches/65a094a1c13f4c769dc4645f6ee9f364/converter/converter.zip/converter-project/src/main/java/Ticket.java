package com.ticketbooking;

public class Ticket {
    private String eventId;
    private String seatNumber;
    private double price;
    
    public Ticket(String eventId, String seatNumber, double price) {
        this.eventId = eventId;
        this.seatNumber = seatNumber;
        this.price = price;
    }
    
    // Getters and setters
    public String getEventId() { return eventId; }
    public void setEventId(String eventId) { this.eventId = eventId; }
    public String getSeatNumber() { return seatNumber; }
    public void setSeatNumber(String seatNumber) { this.seatNumber = seatNumber; }
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
}