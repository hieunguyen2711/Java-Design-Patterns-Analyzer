package com.ticketbooking;

public interface TicketConverter {
    String convert(Ticket ticket);
}