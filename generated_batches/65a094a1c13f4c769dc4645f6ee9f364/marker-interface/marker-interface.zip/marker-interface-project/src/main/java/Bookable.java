package com.example.ticketbooking;

public interface Bookable {
    // Marker interface - no methods required
    // Used to identify objects that can be booked
}