package com.example.ticketbooking;

import java.util.ArrayList;
import java.util.List;

public class BookingService {
    private List<Bookable> bookings;
    
    public BookingService() {
        this.bookings = new ArrayList<>();
    }
    
    public void addBooking(Bookable booking) {
        if (booking != null) {
            bookings.add(booking);
        }
    }
    
    public List<Bookable> getBookings() {
        return new ArrayList<>(bookings);
    }
    
    public int getTotalBookings() {
        return bookings.size();
    }
}