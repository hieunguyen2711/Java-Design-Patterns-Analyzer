package com.example.ticketbooking;

public class Main {
    public static void main(String[] args) {
        BookingService service = new BookingService();
        
        // Create tickets (which implement the marker interface)
        Ticket concertTicket = new Ticket("CONCERT123", "A1", 85.0);
        Ticket movieTicket = new Ticket("MOVIE456", "B5", 25.0);
        
        // Add to booking service - compiler ensures only Bookable objects are added
        service.addBooking(concertTicket);
        service.addBooking(movieTicket);
        
        System.out.println("Total bookings: " + service.getTotalBookings());
    }
}