public class ConfirmedState implements TicketState {
    @Override
    public void processPayment(Ticket ticket) {
        System.out.println("Cannot process payment. Booking is already confirmed.");
    }
    
    @Override
    public void confirmBooking(Ticket ticket) {
        System.out.println("Ticket already confirmed.");
    }
    
    @Override
    public void cancelBooking(Ticket ticket) {
        System.out.println("Cancelling confirmed ticket " + ticket.getTicketId());
        ticket.setState(new CancelledState());
    }
}