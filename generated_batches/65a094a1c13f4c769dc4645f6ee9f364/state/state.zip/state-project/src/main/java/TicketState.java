public interface TicketState {
    void processPayment(Ticket ticket);
    void confirmBooking(Ticket ticket);
    void cancelBooking(Ticket ticket);
}