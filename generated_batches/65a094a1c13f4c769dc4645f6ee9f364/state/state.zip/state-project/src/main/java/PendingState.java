public class PendingState implements TicketState {
    @Override
    public void processPayment(Ticket ticket) {
        System.out.println("Processing payment for ticket " + ticket.getTicketId());
        ticket.setState(new PaidState());
    }
    
    @Override
    public void confirmBooking(Ticket ticket) {
        System.out.println("Cannot confirm booking. Ticket is not paid yet.");
    }
    
    @Override
    public void cancelBooking(Ticket ticket) {
        System.out.println("Cancelling pending ticket " + ticket.getTicketId());
        ticket.setState(new CancelledState());
    }
}