public class Ticket {
    private String ticketId;
    private TicketState state;
    
    public Ticket(String ticketId) {
        this.ticketId = ticketId;
        this.state = new PendingState();
    }
    
    public void processPayment() {
        state.processPayment(this);
    }
    
    public void confirmBooking() {
        state.confirmBooking(this);
    }
    
    public void cancelBooking() {
        state.cancelBooking(this);
    }
    
    public String getState() {
        return state.getClass().getSimpleName();
    }
    
    public void setState(TicketState state) {
        this.state = state;
    }
    
    public String getTicketId() {
        return ticketId;
    }
}