public class TicketBookingSystem {
    public static void main(String[] args) {
        Ticket ticket = new Ticket("T12345");
        
        // Test the state transitions
        System.out.println("Initial state: " + ticket.getState());
        ticket.processPayment();
        System.out.println("After payment: " + ticket.getState());
        ticket.confirmBooking();
        System.out.println("After confirmation: " + ticket.getState());
        ticket.cancelBooking();
        System.out.println("After cancellation: " + ticket.getState());
    }
}