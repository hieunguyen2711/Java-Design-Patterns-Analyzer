public class CancelledState implements TicketState {
    @Override
    public void processPayment(Ticket ticket) {
        System.out.println("Cannot process payment. Booking is cancelled.");
    }
    
    @Override
    public void confirmBooking(Ticket ticket) {
        System.out.println("Cannot confirm booking. Booking is cancelled.");
    }
    
    @Override
    public void cancelBooking(Ticket ticket) {
        System.out.println("Ticket already cancelled.");
    }
}