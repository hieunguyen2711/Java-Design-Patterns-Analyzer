public class PaidState implements TicketState {
    @Override
    public void processPayment(Ticket ticket) {
        System.out.println("Ticket already paid.");
    }
    
    @Override
    public void confirmBooking(Ticket ticket) {
        System.out.println("Confirming booking for ticket " + ticket.getTicketId());
        ticket.setState(new ConfirmedState());
    }
    
    @Override
    public void cancelBooking(Ticket ticket) {
        System.out.println("Cancelling paid ticket " + ticket.getTicketId());
        ticket.setState(new CancelledState());
    }
}