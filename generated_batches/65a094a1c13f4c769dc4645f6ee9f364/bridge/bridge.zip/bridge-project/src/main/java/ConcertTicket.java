public class ConcertTicket extends Ticket {
    public ConcertTicket(BookingMethod bookingMethod) {
        super(bookingMethod);
    }
    
    @Override
    public void book() {
        System.out.println("Booking concert ticket via:");
        bookingMethod.book();
    }
}