public class MovieTicket extends Ticket {
    public MovieTicket(BookingMethod bookingMethod) {
        super(bookingMethod);
    }
    
    @Override
    public void book() {
        System.out.println("Booking movie ticket via:");
        bookingMethod.book();
    }
}