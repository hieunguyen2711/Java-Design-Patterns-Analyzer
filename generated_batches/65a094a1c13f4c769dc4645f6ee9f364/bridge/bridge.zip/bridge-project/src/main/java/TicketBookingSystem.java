public class TicketBookingSystem {
    public static void main(String[] args) {
        // Create different types of tickets with different booking methods
        Ticket concertTicket = new ConcertTicket(new OnlineBooking());
        Ticket movieTicket = new MovieTicket(new PhoneBooking());
        
        concertTicket.book();
        movieTicket.book();
    }
}