public abstract class Ticket {
    protected BookingMethod bookingMethod;
    
    public Ticket(BookingMethod bookingMethod) {
        this.bookingMethod = bookingMethod;
    }
    
    public abstract void book();
}