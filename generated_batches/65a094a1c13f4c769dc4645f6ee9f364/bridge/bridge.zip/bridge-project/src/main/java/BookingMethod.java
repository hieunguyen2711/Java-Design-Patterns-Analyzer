public interface BookingMethod {
    void book();
}