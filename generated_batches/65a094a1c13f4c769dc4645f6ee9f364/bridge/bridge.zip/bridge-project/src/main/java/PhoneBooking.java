public class PhoneBooking implements BookingMethod {
    @Override
    public void book() {
        System.out.println("  - Phone booking completed");
    }
}