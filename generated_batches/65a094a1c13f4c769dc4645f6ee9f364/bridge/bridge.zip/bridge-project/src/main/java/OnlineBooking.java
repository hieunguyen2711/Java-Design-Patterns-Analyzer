public class OnlineBooking implements BookingMethod {
    @Override
    public void book() {
        System.out.println("  - Online booking completed");
    }
}