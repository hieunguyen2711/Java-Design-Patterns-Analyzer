public class BookingPage {
    private String event;
    private int seats;
    private String name;
    private String email;
    
    public BookingPage navigateToBookingPage() {
        System.out.println("Navigating to booking page...");
        return this;
    }
    
    public BookingPage selectEvent(String eventName) {
        this.event = eventName;
        System.out.println("Selected event: " + eventName);
        return this;
    }
    
    public BookingPage selectSeats(int numberOfSeats) {
        this.seats = numberOfSeats;
        System.out.println("Selected seats: " + numberOfSeats);
        return this;
    }
    
    public BookingPage enterPersonalInfo(String customerName, String customerEmail) {
        this.name = customerName;
        this.email = customerEmail;
        System.out.println("Entered personal info: " + customerName + ", " + customerEmail);
        return this;
    }
    
    public void submitBooking() {
        System.out.println("Submitting booking for " + seats + " seat(s) to event '" + 
                          event + "' for " + name + " (" + email + ")");
    }
}