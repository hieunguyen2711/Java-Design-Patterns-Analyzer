public class TicketBookingSystem {
    public static void main(String[] args) {
        // Using Page Object pattern to interact with booking flow
        BookingPage bookingPage = new BookingPage();
        
        // Navigate to booking page and fill form
        bookingPage.navigateToBookingPage()
                  .selectEvent("Concert")
                  .selectSeats(2)
                  .enterPersonalInfo("John Doe", "john@example.com")
                  .submitBooking();
    }
}