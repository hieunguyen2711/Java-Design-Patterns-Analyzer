package com.example.ticketbooking;

public class TicketBookingService {
    
    public Ticket bookTicket(String ticketId, String event, String seatNumber) {
        // Check if ticket already exists in cache (identity map)
        Ticket existingTicket = TicketDatabase.getTicket(ticketId);
        
        if (existingTicket != null) {
            System.out.println("Returning cached ticket: " + ticketId);
            return existingTicket;
        }
        
        // Create new ticket
        Ticket newTicket = new Ticket(ticketId, event, seatNumber);
        TicketDatabase.addTicket(newTicket);
        System.out.println("Created and cached new ticket: " + ticketId);
        
        return newTicket;
    }
    
    public void printCacheStats() {
        System.out.println("Tickets in cache: " + TicketDatabase.getTicketCount());
    }
}