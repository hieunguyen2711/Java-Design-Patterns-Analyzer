package com.example.ticketbooking;

import java.util.HashMap;
import java.util.Map;

public class TicketDatabase {
    private static final Map<String, Ticket> ticketCache = new HashMap<>();
    
    public static Ticket getTicket(String ticketId) {
        return ticketCache.get(ticketId);
    }
    
    public static void addTicket(Ticket ticket) {
        ticketCache.put(ticket.getId(), ticket);
    }
    
    public static boolean containsTicket(String ticketId) {
        return ticketCache.containsKey(ticketId);
    }
    
    public static int getTicketCount() {
        return ticketCache.size();
    }
}