package com.example.ticketbooking;

public class Ticket {
    private final String id;
    private final String event;
    private final String seatNumber;
    
    public Ticket(String id, String event, String seatNumber) {
        this.id = id;
        this.event = event;
        this.seatNumber = seatNumber;
    }
    
    public String getId() {
        return id;
    }
    
    public String getEvent() {
        return event;
    }
    
    public String getSeatNumber() {
        return seatNumber;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Ticket ticket = (Ticket) obj;
        return id.equals(ticket.id);
    }
    
    @Override
    public int hashCode() {
        return id.hashCode();
    }
}