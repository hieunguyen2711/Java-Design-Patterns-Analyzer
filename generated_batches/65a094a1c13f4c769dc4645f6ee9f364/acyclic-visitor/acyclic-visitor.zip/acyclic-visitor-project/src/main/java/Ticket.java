public interface Ticket {
    double accept(Visitor visitor);
}