public class BookingVisitor implements Visitor {
    
    @Override
    public double visit(StandardTicket ticket) {
        return ticket.getBasePrice() * 1.1; // 10% service fee
    }
    
    @Override
    public double visit(PremiumTicket ticket) {
        return ticket.getBasePrice() * 1.2; // 20% service fee
    }
}