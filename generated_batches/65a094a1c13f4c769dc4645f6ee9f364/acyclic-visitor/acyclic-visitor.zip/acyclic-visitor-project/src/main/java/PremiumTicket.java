public class PremiumTicket implements Ticket {
    private final double basePrice;
    
    public PremiumTicket(double basePrice) {
        this.basePrice = basePrice;
    }
    
    @Override
    public double accept(Visitor visitor) {
        return visitor.visit(this);
    }
    
    public double getBasePrice() {
        return basePrice;
    }
}