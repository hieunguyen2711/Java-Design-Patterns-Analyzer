public interface Visitor {
    double visit(StandardTicket ticket);
    double visit(PremiumTicket ticket);
}