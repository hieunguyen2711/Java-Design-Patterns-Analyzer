public class TicketBookingSystem {
    public static void main(String[] args) {
        Ticket ticket = new StandardTicket(100.0);
        Visitor visitor = new BookingVisitor();
        
        double total = ticket.accept(visitor);
        System.out.println("Total booking cost: " + total);
    }
}