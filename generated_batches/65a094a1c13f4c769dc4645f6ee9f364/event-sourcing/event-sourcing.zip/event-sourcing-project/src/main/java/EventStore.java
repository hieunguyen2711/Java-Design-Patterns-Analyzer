package com.example.ticketbooking;

import java.util.ArrayList;
import java.util.List;

public class EventStore {
    private final List<Event> events = new ArrayList<>();
    
    public void save(Event event) {
        events.add(event);
    }
    
    public List<Event> getAllEvents() {
        return new ArrayList<>(events);
    }
}