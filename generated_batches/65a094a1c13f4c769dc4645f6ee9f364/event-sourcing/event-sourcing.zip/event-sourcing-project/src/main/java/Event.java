package com.example.ticketbooking;

import java.time.LocalDateTime;
import java.util.UUID;

public abstract class Event {
    protected final String id = UUID.randomUUID().toString();
    protected final LocalDateTime timestamp = LocalDateTime.now();
    
    public String getId() {
        return id;
    }
    
    public LocalDateTime getTimestamp() {
        return timestamp;
    }
}