package com.example.ticketbooking;

public class TicketCancelledEvent extends Event {
    private final String ticketId;
    
    public TicketCancelledEvent(String ticketId) {
        this.ticketId = ticketId;
    }
    
    public String getTicketId() {
        return ticketId;
    }
}