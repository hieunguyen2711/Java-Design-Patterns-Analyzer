package com.example.ticketbooking;

public class TicketBookedEvent extends Event {
    private final String userId;
    private final String eventId;
    
    public TicketBookedEvent(String id, String userId, String eventId) {
        this.userId = userId;
        this.eventId = eventId;
    }
    
    public String getUserId() {
        return userId;
    }
    
    public String getEventId() {
        return eventId;
    }
}