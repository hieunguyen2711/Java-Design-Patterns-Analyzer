package com.example.ticketbooking;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class TicketBookingSystem {
    private final List<Event> events = new ArrayList<>();
    private final EventStore eventStore = new EventStore();
    
    public void bookTicket(String userId, String eventId) {
        TicketBookedEvent event = new TicketBookedEvent(UUID.randomUUID().toString(), userId, eventId);
        events.add(event);
        eventStore.save(event);
    }
    
    public void cancelTicket(String ticketId) {
        TicketCancelledEvent event = new TicketCancelledEvent(ticketId);
        events.add(event);
        eventStore.save(event);
    }
    
    public List<Event> getEvents() {
        return new ArrayList<>(events);
    }
}