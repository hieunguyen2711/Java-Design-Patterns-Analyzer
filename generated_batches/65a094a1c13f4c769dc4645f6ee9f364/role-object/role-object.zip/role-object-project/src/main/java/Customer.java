package com.example.ticketbooking;

import java.util.List;
import java.util.Optional;

public class Customer implements Role {
    private String name;
    
    public Customer(String name) {
        this.name = name;
    }
    
    @Override
    public void viewTickets(List<Ticket> tickets) {
        System.out.println("Customer " + name + " viewing available tickets:");
        for (Ticket ticket : tickets) {
            System.out.println("- " + ticket.getName() + ": " + 
                             ticket.getAvailable() + " seats at $" + 
                             ticket.getPrice());
        }
    }
    
    @Override
    public void bookTicket(BookingSystem system, String eventName, int quantity) {
        Optional<Ticket> ticketOpt = system.getTickets().stream()
            .filter(t -> t.getName().equals(eventName))
            .findFirst();
            
        if (ticketOpt.isPresent()) {
            Ticket ticket = ticketOpt.get();
            if (ticket.getAvailable() >= quantity) {
                ticket.setAvailable(ticket.getAvailable() - quantity);
                System.out.println("Customer " + name + 
                                 " booked " + quantity + " tickets for " + eventName);
            } else {
                System.out.println("Not enough seats available for " + eventName);
            }
        } else {
            System.out.println("Ticket event not found: " + eventName);
        }
    }
    
    @Override
    public void addTicket(BookingSystem system, String eventName, int available, double price) {
        // Customers cannot add tickets - this method is intentionally left empty or throws exception
        System.out.println("Customer " + name + " does not have permission to add tickets");
    }
}