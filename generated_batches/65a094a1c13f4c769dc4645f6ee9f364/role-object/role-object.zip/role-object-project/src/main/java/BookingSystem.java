package com.example.ticketbooking;

import java.util.*;

public class BookingSystem {
    private List<Ticket> tickets;
    private Role role;
    
    public BookingSystem() {
        this.tickets = new ArrayList<>();
        this.tickets.add(new Ticket("Concert A", 50, 30.0));
        this.tickets.add(new Ticket("Movie X", 100, 15.0));
    }
    
    public void setRole(Role role) {
        this.role = role;
    }
    
    public void viewAvailableTickets() {
        if (role != null) {
            role.viewTickets(tickets);
        }
    }
    
    public void bookTicket(String eventName, int quantity) {
        if (role != null) {
            role.bookTicket(this, eventName, quantity);
        }
    }
    
    public void addNewTicket(String eventName, int available, double price) {
        if (role != null) {
            role.addTicket(this, eventName, available, price);
        }
    }
    
    public List<Ticket> getTickets() {
        return tickets;
    }
}