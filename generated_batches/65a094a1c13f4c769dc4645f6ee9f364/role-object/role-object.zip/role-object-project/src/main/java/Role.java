package com.example.ticketbooking;

import java.util.List;

public interface Role {
    void viewTickets(List<Ticket> tickets);
    void bookTicket(BookingSystem system, String eventName, int quantity);
    void addTicket(BookingSystem system, String eventName, int available, double price);
}