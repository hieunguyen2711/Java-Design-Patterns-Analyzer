package com.example.ticketbooking;

public class Ticket {
    private String name;
    private int available;
    private double price;
    
    public Ticket(String name, int available, double price) {
        this.name = name;
        this.available = available;
        this.price = price;
    }
    
    public String getName() {
        return name;
    }
    
    public int getAvailable() {
        return available;
    }
    
    public void setAvailable(int available) {
        this.available = available;
    }
    
    public double getPrice() {
        return price;
    }
}