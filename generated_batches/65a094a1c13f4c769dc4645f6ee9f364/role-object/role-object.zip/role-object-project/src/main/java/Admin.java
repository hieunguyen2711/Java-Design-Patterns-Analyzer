package com.example.ticketbooking;

import java.util.List;
import java.util.Optional;

public class Admin implements Role {
    private String name;
    
    public Admin(String name) {
        this.name = name;
    }
    
    @Override
    public void viewTickets(List<Ticket> tickets) {
        System.out.println("Admin " + name + " viewing all tickets:");
        for (Ticket ticket : tickets) {
            System.out.println("- " + ticket.getName() + ": " + 
                             ticket.getAvailable() + " seats at $" + 
                             ticket.getPrice());
        }
    }
    
    @Override
    public void bookTicket(BookingSystem system, String eventName, int quantity) {
        // Admins can also book tickets like customers
        Optional<Ticket> ticketOpt = system.getTickets().stream()
            .filter(t -> t.getName().equals(eventName))
            .findFirst();
            
        if (ticketOpt.isPresent()) {
            Ticket ticket = ticketOpt.get();
            if (ticket.getAvailable() >= quantity) {
                ticket.setAvailable(ticket.getAvailable() - quantity);
                System.out.println("Admin " + name + 
                                 " booked " + quantity + " tickets for " + eventName);
            } else {
                System.out.println("Not enough seats available for " + eventName);
            }
        } else {
            System.out.println("Ticket event not found: " + eventName);
        }
    }
    
    @Override
    public void addTicket(BookingSystem system, String eventName, int available, double price) {
        Optional<Ticket> ticketOpt = system.getTickets().stream()
            .filter(t -> t.getName().equals(eventName))
            .findFirst();
            
        if (ticketOpt.isPresent()) {
            Ticket existingTicket = ticketOpt.get();
            existingTicket.setAvailable(existingTicket.getAvailable() + available);
            System.out.println("Admin " + name + 
                             " added " + available + " more seats for " + eventName);
        } else {
            system.getTickets().add(new Ticket(eventName, available, price));
            System.out.println("Admin " + name + 
                             " created new ticket event: " + eventName);
        }
    }
}