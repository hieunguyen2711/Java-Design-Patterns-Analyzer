package com.example.ticketbooking;

public class TicketBookingSystem {
    public static void main(String[] args) {
        // Create booking system with different roles
        BookingSystem system = new BookingSystem();
        
        // Customer role - can view tickets and book
        Customer customer = new Customer("John Doe");
        system.setRole(customer);
        system.viewAvailableTickets();
        system.bookTicket("Concert A", 2);
        
        // Admin role - can manage inventory
        Admin admin = new Admin("Jane Smith");
        system.setRole(admin);
        system.viewAvailableTickets();
        system.addNewTicket("Concert B", 100, 50.0);
        system.bookTicket("Concert B", 1);
    }
}