public class TicketBookingSystem {
    public static void main(String[] args) {
        // Create components following MVP pattern
        TicketModel model = new TicketModel();
        TicketView view = new TicketView();
        TicketPresenter presenter = new TicketPresenter(model, view);
        
        // Simulate user interaction
        presenter.bookTicket("John Doe", "Concert A", 2);
        presenter.bookTicket("Jane Smith", "Movie B", 1);
        
        // Display current bookings
        presenter.displayBookings();
    }
}