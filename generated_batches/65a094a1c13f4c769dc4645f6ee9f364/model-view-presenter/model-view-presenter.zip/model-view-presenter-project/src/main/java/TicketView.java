import java.util.List;

public class TicketView {
    
    public void displayBookings(List<Ticket> bookings) {
        System.out.println("=== Current Bookings ===");
        for (Ticket booking : bookings) {
            System.out.println(booking);
        }
        System.out.println("========================");
    }
    
    public void showBookingConfirmation(String customerName, String event, int quantity) {
        System.out.println("Booking confirmed for " + customerName + 
                          " for " + event + " (" + quantity + " tickets)");
    }
}