import java.util.List;

public class TicketPresenter {
    private TicketModel model;
    private TicketView view;
    
    public TicketPresenter(TicketModel model, TicketView view) {
        this.model = model;
        this.view = view;
    }
    
    public void bookTicket(String customerName, String event, int quantity) {
        Ticket ticket = new Ticket(customerName, event, quantity);
        model.addBooking(ticket);
        view.showBookingConfirmation(customerName, event, quantity);
    }
    
    public void displayBookings() {
        List<Ticket> bookings = model.getBookings();
        view.displayBookings(bookings);
    }
}