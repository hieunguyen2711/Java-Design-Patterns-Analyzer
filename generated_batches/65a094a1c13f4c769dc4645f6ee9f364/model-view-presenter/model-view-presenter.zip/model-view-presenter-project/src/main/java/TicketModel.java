import java.util.ArrayList;
import java.util.List;

public class TicketModel {
    private List<Ticket> bookings;
    
    public TicketModel() {
        this.bookings = new ArrayList<>();
    }
    
    public void addBooking(Ticket ticket) {
        bookings.add(ticket);
    }
    
    public List<Ticket> getBookings() {
        return new ArrayList<>(bookings);
    }
    
    public int getTotalBookings() {
        return bookings.size();
    }
}