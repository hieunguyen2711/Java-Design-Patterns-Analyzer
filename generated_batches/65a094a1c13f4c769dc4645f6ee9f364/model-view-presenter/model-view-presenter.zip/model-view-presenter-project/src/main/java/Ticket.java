public class Ticket {
    private String customerName;
    private String event;
    private int quantity;
    
    public Ticket(String customerName, String event, int quantity) {
        this.customerName = customerName;
        this.event = event;
        this.quantity = quantity;
    }
    
    @Override
    public String toString() {
        return "Ticket{" +
                "customerName='" + customerName + '\'' +
                ", event='" + event + '\'' +
                ", quantity=" + quantity +
                '}';
    }
}