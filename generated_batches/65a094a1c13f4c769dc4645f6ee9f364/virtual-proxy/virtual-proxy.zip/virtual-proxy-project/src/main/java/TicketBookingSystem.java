public class TicketBookingSystem {
    public static void main(String[] args) {
        // Create proxy for expensive ticket data loading
        TicketService ticketService = new TicketServiceProxy("VIP_SECTION_1");
        
        // First access - triggers real object creation and data loading
        System.out.println("Booking ticket: " + ticketService.getTicketDetails());
        
        // Second access - uses cached data from proxy
        System.out.println("Booking ticket: " + ticketService.getTicketDetails());
    }
}