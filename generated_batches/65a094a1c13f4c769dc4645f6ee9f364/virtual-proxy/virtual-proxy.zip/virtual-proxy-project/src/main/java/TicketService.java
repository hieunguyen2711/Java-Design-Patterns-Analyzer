public interface TicketService {
    String getTicketDetails();
}