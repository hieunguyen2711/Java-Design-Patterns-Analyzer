public class RealTicketService implements TicketService {
    private final String section;
    
    public RealTicketService(String section) {
        this.section = section;
        // Simulate expensive operation - loading ticket data from database
        System.out.println("Loading ticket data for " + section + " (expensive operation)");
        try {
            Thread.sleep(1000); // Simulate network/database delay
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
    
    @Override
    public String getTicketDetails() {
        return "VIP Ticket for Section: " + section;
    }
}