public class TicketServiceProxy implements TicketService {
    private RealTicketService realTicketService;
    private final String section;
    
    public TicketServiceProxy(String section) {
        this.section = section;
    }
    
    @Override
    public String getTicketDetails() {
        // Create real object only when first accessed
        if (realTicketService == null) {
            realTicketService = new RealTicketService(section);
        }
        
        return realTicketService.getTicketDetails();
    }
}