public class TheaterService {
    public Theater findTheater(String name) {
        // Simulate theater lookup
        return new Theater(name);
    }
}