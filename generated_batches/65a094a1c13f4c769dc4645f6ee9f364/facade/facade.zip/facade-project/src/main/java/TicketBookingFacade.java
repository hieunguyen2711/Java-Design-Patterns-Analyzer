public class TicketBookingFacade {
    private MovieService movieService;
    private TheaterService theaterService;
    private BookingService bookingService;
    
    public TicketBookingFacade() {
        this.movieService = new MovieService();
        this.theaterService = new TheaterService();
        this.bookingService = new BookingService();
    }
    
    public void bookTicket(String movieName, String theaterName, int seatNumber) {
        Movie movie = movieService.findMovie(movieName);
        Theater theater = theaterService.findTheater(theaterName);
        
        if (movie != null && theater != null) {
            bookingService.createBooking(movie, theater, seatNumber);
            System.out.println("Ticket booked successfully for " + movie.getName() + 
                             " at " + theater.getName() + " seat " + seatNumber);
        } else {
            System.out.println("Movie or theater not found");
        }
    }
}