public class TicketBookingSystem {
    public static void main(String[] args) {
        TicketBookingFacade bookingFacade = new TicketBookingFacade();
        
        // Simple interface to book a ticket
        bookingFacade.bookTicket("Inception", "Grand Theater", 15);
    }
}