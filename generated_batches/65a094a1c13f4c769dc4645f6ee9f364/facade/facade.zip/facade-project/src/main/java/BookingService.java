public class BookingService {
    public void createBooking(Movie movie, Theater theater, int seatNumber) {
        // Simulate booking creation
        System.out.println("Creating booking for " + movie.getName() + 
                          " at " + theater.getName() + " seat " + seatNumber);
    }
}