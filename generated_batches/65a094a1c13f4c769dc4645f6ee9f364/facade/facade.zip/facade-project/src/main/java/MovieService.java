public class MovieService {
    public Movie findMovie(String name) {
        // Simulate movie lookup
        return new Movie(name);
    }
}