public class MovieTicket extends BaseTicket<MovieTicket> {
    @Override
    protected String generateTicketId(String seat, int quantity) {
        return "MOV-" + seat.replace(" ", "-").toUpperCase() + "-" + System.currentTimeMillis();
    }
}