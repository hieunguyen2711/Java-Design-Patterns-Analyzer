public abstract class BaseTicket<T extends BaseTicket<T>> {
    protected String ticketId;
    
    public T bookTicket(String seat, int quantity) {
        this.ticketId = generateTicketId(seat, quantity);
        System.out.println("Booking " + quantity + " tickets for " + seat);
        return (T) this;
    }
    
    protected abstract String generateTicketId(String seat, int quantity);
    
    public String getTicketId() {
        return ticketId;
    }
}