public class TicketBookingSystem {
    public static void main(String[] args) {
        // Demonstrating CRTP with different ticket types
        ConcertTicket concert = new ConcertTicket();
        MovieTicket movie = new MovieTicket();
        
        concert.bookTicket("VIP Section", 10);
        movie.bookTicket("Premium Seat", 5);
        
        System.out.println("Concert Ticket ID: " + concert.getTicketId());
        System.out.println("Movie Ticket ID: " + movie.getTicketId());
    }
}