public class ConcertTicket extends BaseTicket<ConcertTicket> {
    @Override
    protected String generateTicketId(String seat, int quantity) {
        return "CON-" + seat.replace(" ", "-").toUpperCase() + "-" + System.currentTimeMillis();
    }
}