package com.example.ticketbooking;

public class Ticket {
    private int id;
    private String eventName;
    private String seatNumber;
    private double price;
    private boolean isBooked;

    public Ticket() {}

    public Ticket(int id, String eventName, String seatNumber, double price) {
        this.id = id;
        this.eventName = eventName;
        this.seatNumber = seatNumber;
        this.price = price;
        this.isBooked = false;
    }

    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getEventName() { return eventName; }
    public void setEventName(String eventName) { this.eventName = eventName; }

    public String getSeatNumber() { return seatNumber; }
    public void setSeatNumber(String seatNumber) { this.seatNumber = seatNumber; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public boolean isBooked() { return isBooked; }
    public void setBooked(boolean booked) { isBooked = booked; }
}