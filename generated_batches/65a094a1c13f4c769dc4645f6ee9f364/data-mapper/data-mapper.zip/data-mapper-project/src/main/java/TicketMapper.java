package com.example.ticketbooking;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TicketMapper {
    private final Connection connection;

    public TicketMapper(Connection connection) {
        this.connection = connection;
    }

    public Ticket findById(int id) throws SQLException {
        String sql = "SELECT * FROM tickets WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapRowToTicket(rs);
            }
        }
        return null;
    }

    public List<Ticket> findAll() throws SQLException {
        List<Ticket> tickets = new ArrayList<>();
        String sql = "SELECT * FROM tickets";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                tickets.add(mapRowToTicket(rs));
            }
        }
        return tickets;
    }

    public void save(Ticket ticket) throws SQLException {
        if (ticket.getId() > 0) {
            update(ticket);
        } else {
            insert(ticket);
        }
    }

    private void insert(Ticket ticket) throws SQLException {
        String sql = "INSERT INTO tickets (event_name, seat_number, price, is_booked) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, ticket.getEventName());
            stmt.setString(2, ticket.getSeatNumber());
            stmt.setDouble(3, ticket.getPrice());
            stmt.setBoolean(4, ticket.isBooked());
            stmt.executeUpdate();
            
            ResultSet generatedKeys = stmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                ticket.setId(generatedKeys.getInt(1));
            }
        }
    }

    private void update(Ticket ticket) throws SQLException {
        String sql = "UPDATE tickets SET event_name = ?, seat_number = ?, price = ?, is_booked = ? WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, ticket.getEventName());
            stmt.setString(2, ticket.getSeatNumber());
            stmt.setDouble(3, ticket.getPrice());
            stmt.setBoolean(4, ticket.isBooked());
            stmt.setInt(5, ticket.getId());
            stmt.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM tickets WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    private Ticket mapRowToTicket(ResultSet rs) throws SQLException {
        Ticket ticket = new Ticket();
        ticket.setId(rs.getInt("id"));
        ticket.setEventName(rs.getString("event_name"));
        ticket.setSeatNumber(rs.getString("seat_number"));
        ticket.setPrice(rs.getDouble("price"));
        ticket.setBooked(rs.getBoolean("is_booked"));
        return ticket;
    }
}