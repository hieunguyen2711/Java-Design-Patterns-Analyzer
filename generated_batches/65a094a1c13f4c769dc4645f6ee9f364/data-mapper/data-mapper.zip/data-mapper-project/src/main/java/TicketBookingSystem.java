package com.example.ticketbooking;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class TicketBookingSystem {
    private final TicketMapper ticketMapper;

    public TicketBookingSystem() throws SQLException {
        Connection connection = DatabaseConnection.getConnection();
        createTableIfNotExists(connection);
        this.ticketMapper = new TicketMapper(connection);
    }

    private void createTableIfNotExists(Connection connection) throws SQLException {
        String sql = """
            CREATE TABLE IF NOT EXISTS tickets (
                id INT AUTO_INCREMENT PRIMARY KEY,
                event_name VARCHAR(255),
                seat_number VARCHAR(10),
                price DOUBLE,
                is_booked BOOLEAN
            )
            """;
        try (var stmt = connection.createStatement()) {
            stmt.execute(sql);
        }
    }

    public void bookTicket(int ticketId) throws SQLException {
        Ticket ticket = ticketMapper.findById(ticketId);
        if (ticket != null && !ticket.isBooked()) {
            ticket.setBooked(true);
            ticketMapper.save(ticket);
        }
    }

    public List<Ticket> getAllTickets() throws SQLException {
        return ticketMapper.findAll();
    }

    public void addTicket(Ticket ticket) throws SQLException {
        ticketMapper.save(ticket);
    }

    public static void main(String[] args) {
        try {
            TicketBookingSystem system = new TicketBookingSystem();
            
            // Add some tickets
            system.addTicket(new Ticket(0, "Concert", "A1", 50.0));
            system.addTicket(new Ticket(0, "Movie", "B2", 25.0));
            
            // Display all tickets
            System.out.println("All Tickets:");
            for (Ticket ticket : system.getAllTickets()) {
                System.out.printf("ID: %d, Event: %s, Seat: %s, Price: %.2f, Booked: %s%n",
                        ticket.getId(), ticket.getEventName(), ticket.getSeatNumber(),
                        ticket.getPrice(), ticket.isBooked() ? "Yes" : "No");
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}