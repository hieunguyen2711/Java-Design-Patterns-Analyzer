public class RealTicketBookingService implements TicketBookingService {
    @Override
    public void bookTicket(String event, String seat) {
        System.out.println("Booking ticket for " + event + " at seat " + seat);
    }
}