public interface TicketBookingService {
    void bookTicket(String event, String seat);
}