public class TicketBookingSystem {
    public static void main(String[] args) {
        TicketBookingService service = new ProxyTicketBookingService();
        
        for (int i = 0; i < 7; i++) {
            service.bookTicket("Concert", "Seat " + i);
        }
    }
}