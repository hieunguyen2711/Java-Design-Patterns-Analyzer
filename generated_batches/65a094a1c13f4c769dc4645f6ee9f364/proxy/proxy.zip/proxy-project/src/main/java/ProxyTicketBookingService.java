public class ProxyTicketBookingService implements TicketBookingService {
    private RealTicketBookingService realService;
    private static final int MAX_BOOKINGS_PER_HOUR = 5;
    private int bookingsThisHour = 0;
    
    @Override
    public void bookTicket(String event, String seat) {
        if (bookingsThisHour >= MAX_BOOKINGS_PER_HOUR) {
            System.out.println("Booking limit exceeded for this hour");
            return;
        }
        
        if (realService == null) {
            realService = new RealTicketBookingService();
        }
        
        realService.bookTicket(event, seat);
        bookingsThisHour++;
    }
}