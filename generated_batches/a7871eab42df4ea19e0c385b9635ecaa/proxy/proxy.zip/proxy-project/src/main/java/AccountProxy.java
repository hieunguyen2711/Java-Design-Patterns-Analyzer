public class AccountProxy implements Account {
    private BankAccount realAccount;
    private String userRole;
    
    public AccountProxy(String userRole) {
        this.userRole = userRole;
    }
    
    @Override
    public void deposit(double amount) {
        if (userRole.equals("ADMIN") || userRole.equals("USER")) {
            if (realAccount == null) {
                realAccount = new BankAccount(0);
            }
            realAccount.deposit(amount);
        } else {
            throw new SecurityException("Insufficient permissions for deposit");
        }
    }
    
    @Override
    public void withdraw(double amount) {
        if (userRole.equals("ADMIN") || userRole.equals("USER")) {
            if (realAccount == null) {
                realAccount = new BankAccount(0);
            }
            realAccount.withdraw(amount);
        } else {
            throw new SecurityException("Insufficient permissions for withdrawal");
        }
    }
    
    @Override
    public double getBalance() {
        if (userRole.equals("ADMIN") || userRole.equals("USER")) {
            if (realAccount == null) {
                realAccount = new BankAccount(0);
            }
            return realAccount.getBalance();
        } else {
            throw new SecurityException("Insufficient permissions for balance inquiry");
        }
    }
    
    @Override
    public String generateStatement() {
        if (userRole.equals("ADMIN") || userRole.equals("USER")) {
            if (realAccount == null)