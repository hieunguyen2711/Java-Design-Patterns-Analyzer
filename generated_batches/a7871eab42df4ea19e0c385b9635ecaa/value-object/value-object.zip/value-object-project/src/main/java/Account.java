package com.example.bank;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Account {
    private final String accountId;
    private final Customer customer;
    private BigDecimal balance;
    private final List<Transaction> transactions;
    
    public Account(String accountId, Customer customer, BigDecimal initialBalance) {
        this.accountId = accountId;
        this.customer = customer;
        this.balance = initialBalance;
        this.transactions = new ArrayList<>();
    }
    
    public String getAccountId() {
        return accountId;
    }
    
    public Customer getCustomer() {
        return customer;
    }
    
    public BigDecimal getBalance() {
        return balance;
    }
    
    public List<Transaction> getTransactions() {
        return new ArrayList<>(transactions);
    }
    
    public void deposit(BigDecimal amount) {
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Deposit amount must be positive");
        }
        balance = balance.add(amount);
        transactions.add(new Transaction(TransactionType.DEPOSIT, amount));
    }
    
    public void withdraw(BigDecimal amount) {
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Withdrawal amount must be positive");
        }
        if (amount.compareTo(balance) > 0) {
            throw new IllegalStateException("