package banking;

import java.util.*;

public class BankService {
    private Map<String, Account> accounts;
    private List<Transaction> transactionHistory;
    
    public BankService() {
        this.accounts = new HashMap<>();
        this.transactionHistory = new ArrayList<>();
    }
    
    public void createAccount(String accountId, double initialBalance) {
        accounts.put(accountId, new Account(accountId, initialBalance));
    }
    
    public boolean deposit(String accountId, double amount) {
        Account account = accounts.get(accountId);
        if (account != null && amount > 0) {
            account.deposit(amount);
            transactionHistory.add(new Transaction(UUID.randomUUID().toString(), 
                accountId, "DEPOSIT", amount, account.getBalance()));
            return true;
        }
        return false;
    }
    
    public boolean withdraw(String accountId, double amount) {
        Account account = accounts.get(accountId);