public class AccountFactory {
    
    public static Account createAccount(String type, String accountNumber, double initialBalance) {
        switch (type.toLowerCase()) {
            case "checking":
                return new CheckingAccount(accountNumber, initialBalance);
            case "savings":
                return new SavingsAccount(accountNumber, initialBalance);
            default:
                throw new IllegalArgumentException("Unknown account type: " + type);
        }
    }
}