public class BankApplication {
    
    public static void main(String[] args) {
        // Using the factory to create different types of accounts
        Account checkingAccount = AccountFactory.createAccount("checking", "CHK001", 1000.0);
        Account savingsAccount = AccountFactory.createAccount("savings", "SAV001", 5000.0);
        
        System.out.println("Created account: " + checkingAccount.getAccountType() + 
                          " with number: " + checkingAccount.getAccountNumber());
        System.out.println("Created