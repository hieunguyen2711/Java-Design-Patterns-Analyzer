package com.example.bank;

public abstract class Account<T extends Account<T>> {
    protected String accountId;
    protected double balance;
    
    public Account(String accountId, double initialBalance) {
        this.accountId = accountId;
        this.balance = initialBalance;
    }
    
    public T deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            audit("Deposit", amount);
        }
        return self();
    }
    
    public T withdraw(double amount) {
        if (amount > 0 && balance >= amount) {
            balance -= amount;
            audit("Withdrawal", amount);
        }
        return self();
    }
    
    protected abstract void audit(String operation, double amount);
    
    @SuppressWarnings("unchecked")
    private T self() {
        return (T) this;
    }
    
    public double getBalance() {
        return balance;
    }
}