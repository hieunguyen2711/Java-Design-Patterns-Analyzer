package com.example.bank;

public class CheckingAccount extends Account<CheckingAccount> {
    private String accountNumber;
    
    public CheckingAccount(String accountId, String accountNumber, double initialBalance) {
        super(accountId, initialBalance);
        this.accountNumber = accountNumber;
    }
    
    @Override
    protected void audit(String operation, double amount) {
        System.out.println("Audit: " + operation + " of $" + amount + 
                          " on account " + accountNumber + ", balance: $" + balance);
    }
}