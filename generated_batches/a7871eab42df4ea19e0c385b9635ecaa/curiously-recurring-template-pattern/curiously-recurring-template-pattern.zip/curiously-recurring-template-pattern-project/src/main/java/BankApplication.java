package com.example.bank;

public class BankApplication {
    public static void main(String[] args) {
        CheckingAccount checking = new CheckingAccount("CHK001", "123456789", 1000.0);
        SavingsAccount savings = new SavingsAccount("