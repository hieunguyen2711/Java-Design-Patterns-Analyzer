package com.example.bank;

public class SavingsAccount extends Account<SavingsAccount> {
    private String accountNumber;
    
    public SavingsAccount(String accountId, String accountNumber, double initialBalance) {
        super(accountId, initialBalance);
        this.accountNumber = accountNumber;
    }
    
    @Override
    protected void audit(String operation, double amount) {
        System.out.println("Audit: " + operation + " of $" + amount + 
                          " on savings account " + accountNumber + ", balance: $" + balance);
    }
}