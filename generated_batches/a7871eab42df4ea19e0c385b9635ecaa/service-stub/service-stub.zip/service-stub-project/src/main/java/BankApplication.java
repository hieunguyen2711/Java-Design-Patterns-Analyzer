package com.example.bank;

import com.example.bank.service.AccountService;
import com.example.bank.service.AccountServiceImpl;
import com.example.bank.service.AccountServiceStub;

public class BankApplication {
    
    public static void main(String[] args) {
        // Using real