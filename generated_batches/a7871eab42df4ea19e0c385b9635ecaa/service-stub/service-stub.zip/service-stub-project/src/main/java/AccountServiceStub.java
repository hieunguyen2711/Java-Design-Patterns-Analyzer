package com.example.bank.service;

public class AccountServiceStub implements AccountService {
    
    @Override
    public void deposit(String accountId, double amount) {
        // Stub implementation - does nothing
    }
    
    @Override
    public void withdraw(String accountId, double amount) {
        // Stub implementation - does nothing
    }
    
    @Override
    public void transfer(String fromAccountId, String toAccountId, double amount) {
        // Stub implementation - does nothing
    }
    
    @Override
    public String generateStatement(String accountId) {
        return "Stub statement for account " + accountId;
    }
    
    @Override
    public void audit(String action, String accountId) {
        // Stub implementation - does nothing
    }
}