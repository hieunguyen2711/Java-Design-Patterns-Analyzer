package com.example.bank.service;

public interface AccountService {
    void deposit(String accountId, double amount);
    void withdraw(String accountId, double amount);
    void transfer(String fromAccountId, String toAccountId, double amount);
    String generateStatement(String accountId);
    void audit(String action, String accountId);
}