package com.example.bank.service;

public class AccountServiceImpl implements AccountService {
    
    @Override
    public void deposit(String accountId, double amount) {
        System.out.println("Depositing $" + amount + " into account " + accountId);
    }
    
    @Override
    public void withdraw(String accountId, double amount) {
        System.out.println("Withdrawing $" + amount + " from account " + accountId);
    }
    
    @Override
    public void transfer(String fromAccountId, String toAccountId, double amount) {
        System.out.println("Transferring $" + amount + " from " + fromAccountId + 
                          " to " + toAccountId);
    }
    
    @Override
    public String generateStatement(String accountId) {
        return "Statement for account " + accountId;
    }
    
    @Override
    public void audit(String action, String accountId) {
        System.out.println("Auditing: " + action + " on account " + accountId);
    }
}