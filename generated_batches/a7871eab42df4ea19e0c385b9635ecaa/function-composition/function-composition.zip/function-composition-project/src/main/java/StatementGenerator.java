package banking;

import java.util.List;
import java.util.function.Function;

public class StatementGenerator {
    
    public static Function<List<Transaction>, String> generateStatement = 
        transactions -> {
            StringBuilder statement = new StringBuilder();
            statement.append("Account Statement:\n");
            for (Transaction transaction : transactions) {
                statement.append(String.format("%s: %s - $%.2f\n", 
                    transaction.getType(), 
                    transaction.getTransactionId(),
                    transaction.getAmount()));
            }
            return statement.toString();
        };
}