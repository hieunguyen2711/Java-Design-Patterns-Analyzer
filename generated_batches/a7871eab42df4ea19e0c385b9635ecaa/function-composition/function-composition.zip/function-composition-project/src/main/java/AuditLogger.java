package banking;

import java.util.function.Function;

public class Audit