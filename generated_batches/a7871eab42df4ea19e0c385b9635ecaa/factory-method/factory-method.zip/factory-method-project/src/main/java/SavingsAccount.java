public class SavingsAccount extends Account {
    public SavingsAccount(String accountId, double initialBalance) {
        super(accountId, initialBalance);
    }
    
    @Override
    public AccountType getAccountType() {
        return AccountType.SAVINGS;
    }
}