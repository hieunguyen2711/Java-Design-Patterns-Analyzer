public class BusinessAccount extends Account {
    public BusinessAccount(String accountId, double initialBalance) {
        super(accountId, initialBalance);
    }
    
    @Override
    public AccountType getAccountType() {
        return AccountType.BUSINESS;
    }
}