public class CheckingAccount extends Account {
    public CheckingAccount(String accountId, double initialBalance) {
        super(accountId, initialBalance);
    }
    
    @Override
    public AccountType getAccountType() {
        return AccountType.CHECKING;
    }
}