public abstract class AccountFactory {
    public abstract Account createAccount(String accountId, double initialBalance);
    
    public static AccountFactory getFactory(AccountType type) {
        switch (type) {
            case CHECKING:
                return new CheckingAccountFactory();
            case SAVINGS:
                return new SavingsAccountFactory();
            case BUSINESS:
                return new BusinessAccountFactory();
            default:
                throw new IllegalArgumentException("Unknown account type: " + type);
        }
    }
}