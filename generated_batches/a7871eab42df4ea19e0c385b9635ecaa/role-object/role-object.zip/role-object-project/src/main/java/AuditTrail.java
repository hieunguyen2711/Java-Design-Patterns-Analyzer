package banking;

import java.util.ArrayList;
import java.util.List;

public class AuditTrail {
    private List<Transaction> transactions;
    
    public AuditTrail() {
        this.transactions = new ArrayList<>();
    }
    
    public void