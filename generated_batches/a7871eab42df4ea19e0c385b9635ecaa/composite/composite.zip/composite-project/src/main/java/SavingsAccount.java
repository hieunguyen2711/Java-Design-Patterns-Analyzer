package com.example.bank;

public class SavingsAccount extends Account {
    private static final double MINIMUM_BALANCE = 100.0;
    
    public SavingsAccount(String accountNumber, double balance) {
        super(accountNumber, balance);
    }
    
    @Override
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
        }
    }
    
    @Override
    public void withdraw(double amount) {
        if (amount > 0 && (balance - amount) >= MINIMUM_BALANCE) {
            balance -= amount;
        }
    }
    
    @Override
    public double getBalance() {
        return balance;
    }
    
    @Override
    public void printStatement() {
        System.out.println("Savings Account " + accountNumber + ": $" + balance);
    }
}