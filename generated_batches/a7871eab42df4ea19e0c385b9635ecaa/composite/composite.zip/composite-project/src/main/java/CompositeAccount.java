package com.example.bank;

import java.util.ArrayList;
import java.util.List;

public class CompositeAccount