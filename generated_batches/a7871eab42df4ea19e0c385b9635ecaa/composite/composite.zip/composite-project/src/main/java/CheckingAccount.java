package com.example.bank;

public class CheckingAccount extends Account {
    private static final double OVERDRAFT_LIMIT = 100.0;
    
    public CheckingAccount(String accountNumber, double balance) {
        super(accountNumber, balance);
    }
    
    @Override
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
        }
    }
    
    @Override
    public void withdraw(double amount) {
        if (amount > 0 && (balance - amount) >= -OVERDRAFT_LIMIT) {
            balance -= amount;
        }
    }
    
    @Override
    public double getBalance() {
        return balance;
    }
    
    @Override
    public void printStatement() {
        System.out.println("Checking Account " + accountNumber + ": $" + balance);
    }
}