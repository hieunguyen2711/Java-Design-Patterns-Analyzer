package com.example.bank;

public class AuditLogger {
    private static volatile AuditLogger instance;
    
    private AuditLogger() {
        // Private constructor to prevent instantiation
    }
    
    public static AuditLogger getInstance() {
        if (instance == null) {
            synchronized (AuditLogger.class) {
                if (instance == null) {
                    instance = new AuditLogger();
                }
            }
        }
        return instance;
    }
    
    public void logTransaction(Transaction transaction) {
        System.out.println("AUDIT: