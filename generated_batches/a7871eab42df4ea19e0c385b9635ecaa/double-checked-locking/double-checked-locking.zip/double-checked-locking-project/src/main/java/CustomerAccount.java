package com.example.bank;

public class CustomerAccount {
    private String customerId;
    private String accountNumber;
    private double balance;
    
    public CustomerAccount(String customerId, String accountNumber, double initialBalance) {
        this.customerId = customerId;
        this.accountNumber = accountNumber;
        this.balance = initialBalance;
    }
    
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
        }
    }
    
    public boolean withdraw(double amount) {
        if (amount > 0 && balance >= amount) {
            balance -= amount;
            return true;
        }
        return false;
    }
    
    public double getBalance() {
        return balance;
    }
    
    public String getCustomerId() {
        return customerId;
    }
    
    public String getAccountNumber() {
        return accountNumber;
    }
}