package banking;

public abstract class CustomerAccount {
    protected String accountNumber;
    protected double balance;
    
    public CustomerAccount(String accountNumber, double initialBalance) {
        this.accountNumber = accountNumber;
        this.balance = initialBalance;
    }
    
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            auditDeposit(amount);
        }
    }
    
    public boolean withdraw(double amount) {
        if (amount > 0 && balance >= amount) {
            balance -= amount;
            auditWithdrawal(amount);
            return true;
        }
        return false;
    }
    
    public abstract void auditDeposit(double amount);
    public abstract void auditWithdrawal(double amount);
    
    public double getBalance() {
        return balance;
    }
    
    public String getAccountNumber() {
        return accountNumber;
    }
}