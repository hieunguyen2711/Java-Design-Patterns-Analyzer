package banking;

public class CheckingAccount extends CustomerAccount {
    private static final double OVERDRAFT_LIMIT = 500.0;
    
    public CheckingAccount(String accountNumber, double initialBalance) {
        super(accountNumber, initialBalance);
    }
    
    @Override
    public void auditDeposit(double amount) {
        System.out.println("Checking deposit: $" + amount + " to account " + accountNumber);
    }
    
    @Override
    public void auditWithdrawal(double amount) {
        System.out.println("Checking withdrawal: $" + amount + " from account " + accountNumber