package banking;

public class SavingsAccount extends CustomerAccount {
    private static final double MIN_BALANCE = 100.0;
    
    public SavingsAccount(String accountNumber, double initialBalance) {
        super(accountNumber, initialBalance);
    }
    
    @Override
    public void auditDeposit(double amount) {
        System.out.println("Savings deposit: $" + amount + " to account " + accountNumber);
    }
    
    @Override
    public void auditWithdrawal(double amount) {
        System.out.println("Savings withdrawal: $" + amount + " from account " + accountNumber);
    }
    
    public boolean withdraw(double amount) {
        if (amount > 0 && balance - amount >= MIN_BALANCE) {
            balance -= amount;
            auditWithdrawal(amount);
            return true;
        }
        return false;
    }
}