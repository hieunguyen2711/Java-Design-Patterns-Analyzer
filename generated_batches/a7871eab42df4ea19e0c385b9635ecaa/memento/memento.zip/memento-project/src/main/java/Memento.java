package banking;

import java.util.List;

public class Memento {
    private String accountNumber;
    private double balance;
    private List<String> transactionHistory;
    
    public Memento(String accountNumber, double balance, List<String> transactionHistory) {
        this.accountNumber = accountNumber;
        this.balance = balance;
        this.transactionHistory = transactionHistory;
    }
    
    public String getAccountNumber() {
        return accountNumber;
    }
    
    public double getBalance() {
        return balance;
    }
    
    public