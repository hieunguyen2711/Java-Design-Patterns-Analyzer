package banking;

import java.util.ArrayList;
import java.util.List;

public class Account {
    private String accountNumber;
    private double balance;
    private List<String> transactionHistory;
    
    public Account(String accountNumber, double initialBalance) {
        this.accountNumber = accountNumber;
        this.balance = initialBalance;
        this.transactionHistory = new ArrayList<>();
        addTransaction("Account created with balance: " + initialBalance);
    }
    
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            addTransaction("Deposit: +" + amount);
        }
    }
    
    public boolean withdraw(double amount) {
        if (amount > 0 && balance >= amount) {
            balance -= amount;
            addTransaction("Withdrawal: -" + amount);
            return true;
        }
        return false;
    }
    
    public boolean transfer(Account targetAccount, double amount) {
        if (this.withdraw(amount)) {
            targetAccount.deposit(amount);
            addTransaction("Transfer to " + targetAccount.getAccountNumber() + ": -" + amount);
            return true;
        }
        return false;
    }
    
    private void addTransaction(String transaction) {
        transactionHistory.add(transaction);
    }
    
    public double getBalance() {
        return balance;
    }
    
    public String getAccountNumber() {
        return accountNumber;
    }
    
    public List<String> getTransactionHistory() {
        return new ArrayList<>(transactionHistory);
    }
    
    public Memento createMemento() {
        return new Memento(accountNumber, balance, new ArrayList<>(transactionHistory));
    }
    
    public void restoreMemento(Memento memento) {
        this.accountNumber = memento.getAccountNumber();
        this.balance = memento.getBalance();
        this.transactionHistory = new ArrayList<>(memento.getTransactionHistory());
    }
}