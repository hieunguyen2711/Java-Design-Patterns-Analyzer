public interface AccountState {
    void deposit(Account account, double amount);
    void withdraw(Account account, double amount);
    void transfer(Account sourceAccount, Account targetAccount, double amount);
}