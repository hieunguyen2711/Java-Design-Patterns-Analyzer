public class OverdrawnAccountState implements AccountState {
    @Override
    public void deposit(Account account, double amount) {
        if (amount >