public class ActiveAccountState implements AccountState {
    @Override
    public void deposit(Account account, double amount) {
        if (amount > 0) {
            account.setBalance(account.getBalance() + amount);
        }
    }

    @Override
    public void withdraw(Account account, double amount) {
        if (amount > 0 && account.getBalance() >= amount) {
            account.setBalance(account.getBalance() - amount);
        } else if (account.getBalance() < amount) {
            account.setState(new OverdrawnAccountState());
        }
    }

    @Override
    public void transfer(Account sourceAccount, Account targetAccount, double amount) {
        if (amount > 0 && sourceAccount.getBalance() >= amount) {
            sourceAccount.setBalance(sourceAccount.getBalance() - amount);
            targetAccount.setBalance(targetAccount.getBalance() + amount);
        } else if (sourceAccount.getBalance() < amount) {
            sourceAccount.setState(new OverdrawnAccountState());
        }
    }
}