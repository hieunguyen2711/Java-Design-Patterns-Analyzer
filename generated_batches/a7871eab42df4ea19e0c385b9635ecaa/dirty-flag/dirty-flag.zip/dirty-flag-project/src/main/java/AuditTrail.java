package com.example.account;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class AuditTrail {
    private List<AuditEntry> entries;