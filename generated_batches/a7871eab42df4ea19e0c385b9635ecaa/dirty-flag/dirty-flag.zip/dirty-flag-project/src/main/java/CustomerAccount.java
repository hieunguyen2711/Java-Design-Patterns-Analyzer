package com.example.account;

public class CustomerAccount {
    private String accountId;
    private double balance;
    private boolean dirtyFlag = false;
    
    public CustomerAccount(String accountId, double initialBalance) {
        this.accountId = accountId;
        this.balance = initialBalance;
    }
    
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            setDirty(true);
        }
    }
    
    public boolean withdraw(double amount) {
        if (amount > 0 && balance >= amount) {
            balance -= amount;
            setDirty(true);
            return true;
        }
        return false;
    }
    
    public void transfer(CustomerAccount target, double amount) {
        if (this.withdraw(amount)) {
            target.deposit(amount);
            setDirty(true);
        }
    }
    
    public double getBalance() {
        return balance;
    }
    
    public String getAccountId() {
        return accountId;
    }
    
    public boolean isDirty() {
        return dirtyFlag;
    }
    
    public void setDirty(boolean dirty) {
        this.dirtyFlag = dirty;
    }
    
    public void clearDirty() {
        this.dirtyFlag = false;
    }
}