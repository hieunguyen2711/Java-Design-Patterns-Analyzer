package com.example.account;

import java.util.ArrayList;
import java.util.List;

public class AccountService {
    private List<CustomerAccount> accounts;
    
    public AccountService() {
        this.accounts = new ArrayList<>();
    }
    
    public void createAccount(String accountId, double initialBalance) {
        accounts.add(new CustomerAccount(accountId, initialBalance));
    }
    
    public CustomerAccount getAccount(String accountId) {
        return accounts.stream()
                .filter(acc -> acc.getAccountId().equals(accountId))
                .findFirst()
                .orElse(null);
    }
    
    public void processDirtyAccounts() {
        for (CustomerAccount account : accounts) {
            if (account.isDirty()) {
                // In a real system, this would persist to database
                System.out.println("Saving dirty account: " + account.getAccountId() 
                    + " with balance: " + account.getBalance());
                account.clearDirty();
            }
        }
    }
}