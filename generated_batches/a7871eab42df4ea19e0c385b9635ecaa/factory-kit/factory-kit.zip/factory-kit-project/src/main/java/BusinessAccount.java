public class BusinessAccount extends Account {
    private static final AccountType TYPE = AccountType.BUSINESS;
    
    public BusinessAccount(String accountId, double initialBalance) {
        super(accountId, initialBalance);
    }
    
    @Override
    public AccountType getAccountType() {
        return TYPE;
    }
}