public class AccountFactory {
    public static Account createAccount(AccountType type, String accountId, double initialBalance) {
        switch (type) {
            case CHECKING:
                return new CheckingAccount(accountId, initialBalance);
            case SAVINGS:
                return new SavingsAccount(accountId, initialBalance);
            case BUSINESS:
                return new BusinessAccount(accountId, initialBalance);
            default: