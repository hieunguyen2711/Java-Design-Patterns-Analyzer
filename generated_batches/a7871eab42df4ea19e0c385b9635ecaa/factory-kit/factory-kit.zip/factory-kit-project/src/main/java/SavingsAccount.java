public class SavingsAccount extends Account {
    private static final AccountType TYPE = AccountType.SAVINGS;
    
    public SavingsAccount(String accountId, double initialBalance) {
        super(accountId, initialBalance);
    }
    
    @Override
    public AccountType getAccountType() {
        return TYPE;
    }
}