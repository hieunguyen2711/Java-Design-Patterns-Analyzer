public class CheckingAccount extends Account {
    private static final AccountType TYPE = AccountType.CHECKING;
    
    public CheckingAccount(String accountId, double initialBalance) {
        super(accountId, initialBalance);
    }
    
    @Override
    public AccountType getAccountType() {
        return TYPE;
    }
}