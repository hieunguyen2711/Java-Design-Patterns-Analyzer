package banking;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Account {
    private String accountId;
    private String customerName;
    private BigDecimal balance;
    private List<Transaction> transactions;
    
    public Account(String accountId, String customerName, BigDecimal initialBalance) {
        this.accountId = accountId;
        this.customerName = customerName;
        this.balance = initialBalance;
        this.transactions = new ArrayList<>();
    }
    
    public void deposit(BigDecimal amount) {
        balance = balance.add(amount);
        transactions.add(new Transaction("DEPOSIT", amount, balance));
    }
    
    public boolean withdraw(BigDecimal amount) {
        if (balance.compareTo(amount) >= 0) {
            balance = balance.subtract(amount);
            transactions.add(new Transaction("WITHDRAWAL", amount, balance));
            return true;
        }
        return false;
    }
    
    public void transfer(Account toAccount, BigDecimal amount) {
        if (withdraw(amount)) {
            toAccount.deposit(amount);
            transactions.add(new Transaction("TRANSFER_OUT", amount, balance));
            toAccount.transactions.add(new Transaction("TRANSFER_IN", amount, toAccount.balance));
        }
    }
    
    public List<Transaction> getTransactionHistory() {
        return new ArrayList<>(transactions);
    }
    
    public List<Transaction> getFilteredTransactions(String type) {
        return transactions.stream()
                .filter(t -> t.getType().equals(type))
                .collect(Collectors.toList());
    }
    
    public BigDecimal getBalance() {
        return balance;
    }
    
    public String getAccountId() {
        return accountId;
    }
}