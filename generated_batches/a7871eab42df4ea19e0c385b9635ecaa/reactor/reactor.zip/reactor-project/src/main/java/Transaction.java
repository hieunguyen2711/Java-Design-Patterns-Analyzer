package com.example.bank;

public class Transaction {
    private String transactionId;
    private String accountId;
    private TransactionType type;
    private double amount;
    private long timestamp;
    
    public Transaction(String transactionId, String accountId, TransactionType type, double amount) {
        this.transactionId = transactionId;
        this.accountId = accountId;
        this.type = type;
        this.amount = amount;
        this.timestamp = System.currentTimeMillis();
    }
    
    public String getTransactionId() {
        return transactionId;
    }
    
    public String getAccountId() {
        return accountId;
    }
    
    public TransactionType getType() {
        return type;
    }
    
    public double getAmount() {
        return amount;
    }
    
    public long getTimestamp() {
        return timestamp;
    }
}