package com.example.bank;

import java.util.List;
import java.util.ArrayList;

public class StatementGenerator {
    
    public List<String> generateStatement(String accountId, List<Transaction> transactions) {
        List<String> statement = new ArrayList<>();
        statement.add("Account Statement for " + accountId);
        statement.add("==================");
        
        double balance = 0.0;
        for (Transaction transaction : transactions) {
            if (transaction.getAccountId().equals(accountId)) {
                balance += transaction.getAmount();
                statement.add(String.format("%s: %s - %.2f", 
                    transaction.getType(), 
                    transaction.getTransactionId(),
                    transaction.getAmount()));
            }
        }
        
        statement.add("Final Balance: " + String.format("%.