package com.example.bank;

public class CustomerAccount {
    private String accountId;
    private double balance;
    
    public CustomerAccount(String accountId, double initialBalance) {
        this.accountId = accountId;
        this.balance = initialBalance;
    }
    
    public String getAccountId() {
        return accountId;
    }
    
    public double getBalance() {
        return balance;
    }
    
    public void deposit(double amount) {
        balance += amount;
    }
    
    public void withdraw(double amount) {
        balance -= amount;
    }
}