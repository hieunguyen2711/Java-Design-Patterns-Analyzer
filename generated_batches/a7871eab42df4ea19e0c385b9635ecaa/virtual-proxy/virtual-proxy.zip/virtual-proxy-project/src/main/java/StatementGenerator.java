package com.example.bank;

public interface StatementGenerator {
    AccountStatement generateStatement(String accountId);
}