package com.example.bank;

public class AccountStatement {
    private String accountId;
    private String statementContent;
    
    public AccountStatement(String accountId, String content) {
        this.accountId = accountId;
        this.statementContent = content;
    }
    
    public String getAccountId() {
        return accountId;
    }
    
    public String getContent() {
        return statementContent;
    }
}