package com.example.bank;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class RealStatementGenerator implements StatementGenerator {
    
    @Override
    public AccountStatement generateStatement(String accountId) {
        // Simulate expensive operation
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        String content = "Account: " + accountId + 
                        "\nGenerated at: " + LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME) +
                        "\nBalance: $5000.00\nTransactions: 12";
        
        return new AccountStatement(accountId, content);
    }
}