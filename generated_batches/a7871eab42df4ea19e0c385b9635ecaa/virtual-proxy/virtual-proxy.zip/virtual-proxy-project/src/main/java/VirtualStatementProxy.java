package com.example.bank;

public class VirtualStatementProxy implements StatementGenerator {
    private String accountId;
    private AccountStatement statement;
    private RealStatementGenerator realGenerator;
    
    public VirtualStatementProxy(String accountId) {
        this.accountId = accountId;
        this.realGenerator = new RealStatementGenerator();
    }
    
    @Override
    public AccountStatement generateStatement(String accountId) {
        if (statement == null) {
            System.out.println("Generating statement for account " + accountId + "