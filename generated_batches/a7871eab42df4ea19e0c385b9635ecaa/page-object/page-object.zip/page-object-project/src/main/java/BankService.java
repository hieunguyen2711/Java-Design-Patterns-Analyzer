package com.example.bank;

public class BankService {
    private Account sourceAccount;
    private Account targetAccount;
    
    public BankService(Account sourceAccount, Account targetAccount) {
        this.sourceAccount = sourceAccount;
        this.targetAccount = targetAccount;
    }
    
    public boolean transfer(double amount) {
        if (sourceAccount.withdraw(amount)) {
            targetAccount.deposit(amount);
            return true;
        }
        return false;
    }
}