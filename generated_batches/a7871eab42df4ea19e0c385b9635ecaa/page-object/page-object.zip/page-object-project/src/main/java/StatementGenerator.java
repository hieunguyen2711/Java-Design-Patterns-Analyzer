package com.example.bank;

public class StatementGenerator {
    private Account account;
    
    public StatementGenerator(Account account) {
        this.account = account;
    }
    
    public String generateStatement() {
        StringBuilder statement = new StringBuilder();
        statement.append("Account Statement for ").append(account.getAccountNumber()).append("\n");
        statement.append