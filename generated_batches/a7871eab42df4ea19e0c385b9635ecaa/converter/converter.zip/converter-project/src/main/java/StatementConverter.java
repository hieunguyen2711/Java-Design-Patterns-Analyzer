package banking;

import java.util.List;
import java.util.ArrayList;

public class StatementConverter {
    
    public static List<String> convertTransactionsToStatement(List<Transaction> transactions) {
        List<String> statement = new ArrayList<>();
        
        for (Transaction transaction : transactions) {
            String line = formatTransactionLine(transaction);
            statement.add(line);
        }
        
        return statement;
    }
    
    private static String formatTransactionLine(Transaction transaction) {
        switch (transaction.getType()) {
            case DEPOSIT:
                return String.format("DEPOSIT: Account %s, Amount $%.2f", 
                                   transaction.getToAccountId(),