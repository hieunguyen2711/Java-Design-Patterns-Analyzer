public interface StatementService {
    String generateStatement(String accountId);
    void printStatement(String statement);
}