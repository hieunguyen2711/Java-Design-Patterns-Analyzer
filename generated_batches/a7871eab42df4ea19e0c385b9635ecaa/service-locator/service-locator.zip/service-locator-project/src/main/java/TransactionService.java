public interface TransactionService {
    void transfer(String fromAccountId, String toAccountId, double amount);
    void auditTransaction(String transactionId);
}