public interface AccountService {
    void createAccount(String customerId, double initialBalance);
    double getBalance(String accountId);
    void deposit(String accountId, double amount);
    void withdraw(String accountId, double amount);
}