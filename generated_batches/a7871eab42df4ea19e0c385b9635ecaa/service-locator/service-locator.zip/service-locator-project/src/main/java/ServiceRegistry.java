import java.util.HashMap;
import java.util.Map;

public class ServiceRegistry {
    private Map<String, Object> services;

    public ServiceRegistry() {
        services = new HashMap<>();
        initializeServices();
    }

    private void initializeServices() {
        services.put("AccountService", new AccountServiceImpl());
        services.put("TransactionService", new TransactionServiceImpl());
        services.put("StatementService", new StatementServiceImpl());
    }

    public Object getService(String serviceName) {
        return services.get(serviceName);
    }
}