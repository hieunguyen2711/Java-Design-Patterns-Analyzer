public class AccountServiceImpl implements AccountService {
    @Override
    public void createAccount(String customerId, double initialBalance) {
        System.out.println("Creating account for customer " + customerId 
            + " with balance " + initialBalance);
    }

    @Override
    public double getBalance(String accountId) {
        System.out.println("Retrieving balance for account " + accountId);
        return 1000.0;
    }

    @Override
    public void deposit(String accountId, double amount) {
        System.out.println("Depositing " + amount + " into account " + accountId);
    }

    @Override
    public void withdraw(String accountId, double amount) {
        System.out.println("Withdrawing " + amount + " from account " + accountId);
    }
}