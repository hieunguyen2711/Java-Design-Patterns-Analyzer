public interface Actor {
    void receive(Message message);
}