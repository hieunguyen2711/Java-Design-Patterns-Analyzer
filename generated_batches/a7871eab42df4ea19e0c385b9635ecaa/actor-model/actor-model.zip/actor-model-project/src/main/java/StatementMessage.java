public class StatementMessage extends Message {
    private final String accountId;
    
    public StatementMessage(String sender, String accountId) {
        super(sender);
        this.accountId = accountId;
    }
    
    public String getAccountId() {
        return accountId;
    }
    
    @Override
    public void process() {
        // Implementation handled by actor
    }
}