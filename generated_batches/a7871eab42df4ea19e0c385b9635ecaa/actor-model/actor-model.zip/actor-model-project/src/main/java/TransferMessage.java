public class TransferMessage extends Message {
    private final String fromAccountId;
    private final String toAccountId;
    private final double amount;
    
    public TransferMessage(String sender, String fromAccountId, String toAccountId, double amount) {
        super(sender);
        this.fromAccountId = fromAccountId;
        this.toAccountId = toAccountId;
        this.amount = amount;
    }
    
    public String getFromAccountId() {
        return fromAccountId;
    }
    
    public String getToAccountId() {
        return toAccountId;
    }
    
    public double getAmount() {
        return amount;
    }
    
    @Override
    public void process() {
        // Implementation handled by actor
    }
}