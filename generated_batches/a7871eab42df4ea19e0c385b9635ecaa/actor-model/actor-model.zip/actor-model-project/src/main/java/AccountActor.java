import java.util.HashMap;
import java.util.Map;

public class AccountActor implements Actor {
    private final String accountId;
    private double balance = 0.0;
    private final Map