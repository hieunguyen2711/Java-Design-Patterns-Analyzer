public class AccountMessage extends Message {
    private final String accountId;
    private final double amount;
    private final String operation;
    
    public AccountMessage(String sender, String accountId, double amount, String operation) {
        super(sender);
        this.accountId = accountId;
        this.amount = amount;
        this.operation = operation;
    }
    
    public String getAccountId() {
        return accountId;
    }
    
    public double getAmount() {
        return amount;
    }
    
    public String getOperation() {
        return operation;
    }
    
    @Override
    public void process() {
        // Implementation handled by actor
    }
}