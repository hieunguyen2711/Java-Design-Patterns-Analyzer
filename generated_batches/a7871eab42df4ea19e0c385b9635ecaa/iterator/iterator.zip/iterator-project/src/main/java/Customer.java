package banking;

import java.util.ArrayList;
import java.util.List;

public class Customer {
    private String customerId;
    private String name;
    private List<Account> accounts;
    
    public Customer(String customerId, String name) {
        this.customerId = customerId;
        this.name = name;
        this.accounts = new ArrayList<>();
    }
    
    public void addAccount(Account account) {
        accounts.add(account);
    }
    
    public Iterable<Account> getAccounts() {
        return accounts;
    }
    
    // Getters
    public String getCustomerId() { return customerId; }
    public String getName() { return name; }
}