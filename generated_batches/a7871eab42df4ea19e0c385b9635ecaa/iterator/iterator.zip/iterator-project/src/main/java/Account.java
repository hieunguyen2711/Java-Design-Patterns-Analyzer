package banking;

import java.util.ArrayList;
import java.util.List;

public class Account {
    private String accountId;
    private double balance;
    private List<Transaction> transactions;
    
    public Account(String accountId, double initialBalance) {
        this.accountId = accountId;
        this.balance = initialBalance;
        this.transactions = new ArrayList<>();
    }
    
    public void deposit(double amount) {
        balance += amount;
        transactions.add(new Transaction("DEPOSIT", amount));
    }
    
    public void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
            transactions.add(new Transaction("WITHDRAWAL", amount));
        }
    }
    
    public Iterable<Transaction> getTransactions() {
        return transactions;
    }
    
    // Getters
    public String getAccountId() { return accountId; }
    public double getBalance() { return balance; }
}