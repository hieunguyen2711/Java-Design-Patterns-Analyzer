package banking;

import java.util.Iterator;

public class StatementGenerator {
    
    public void generateStatement(Customer customer) {
        System.out.println("Customer: " + customer.getName());
        System.out.println("Account Statements:");
        
        // Using Iterator pattern to traverse accounts
        Iterator<Account> accountIterator = customer.getAccounts().iterator();
        while (accountIterator.hasNext()) {
            Account account = accountIterator.next();
            System.out.println("  Account ID: