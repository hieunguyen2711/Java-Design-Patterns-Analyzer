package com.example.bank;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class AccountCreated implements Event {
    private final String accountId;
    private final BigDecimal balance;
    private final LocalDateTime timestamp;

    public AccountCreated(String accountId, BigDecimal balance) {
        this.accountId = accountId;
        this.balance = balance;
        this.timestamp = LocalDateTime.now();
    }

    @Override
    public String getAccountId() {
        return