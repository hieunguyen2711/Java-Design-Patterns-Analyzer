package com.example.bank;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public interface Event {
    String getAccountId();
    LocalDateTime getTimestamp();
    String getType();
}