public interface Account {
    void deposit(double amount);
    void withdraw(double amount);
    void transfer(Account targetAccount, double amount);
    String generateStatement();
    void addAuditEntry(String entry);
}