public class LoggingAccountDecorator extends AccountDecorator {
    
    public Logging