public abstract class AccountDecorator implements Account {
    protected Account account;
    
    public AccountDecorator(Account account) {
        this.account = account;
    }
    
    @Override
    public void deposit(double amount) {
        account.deposit(amount);
    }
    
    @Override
    public void withdraw(double amount) {
        account.withdraw(amount);
    }
    
    @Override
    public void transfer(Account targetAccount, double amount) {
        account.transfer(targetAccount, amount);
    }
    
    @Override
    public String generateStatement() {
        return account.generateStatement();
    }
    
    @Override
    public void addAuditEntry(String entry) {
        account.addAuditEntry(entry);
    }
}