public class BasicAccount implements Account {
    private double balance;
    private StringBuilder auditLog;
    
    public BasicAccount() {
        this.balance = 0.0;
        this.auditLog = new StringBuilder();
    }
    
    @Override
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            addAuditEntry("Deposit: $" + amount);
        }
    }
    
    @Override
    public void withdraw(double amount) {
        if (amount > 0 && balance >= amount) {
            balance -= amount;
            addAuditEntry("Withdrawal: $" + amount);
        }
    }
    
    @Override
    public void transfer(Account targetAccount, double amount) {
        if (targetAccount != null && amount > 0 && balance >= amount) {
            withdraw(amount);
            targetAccount.deposit(amount);
            addAuditEntry("Transfer: $" + amount + " to account");
        }
    }
    
    @Override
    public String generateStatement() {
        return "Basic Account Statement - Balance: $" + balance;
    }
    
    @Override
    public void addAuditEntry(String entry) {
        auditLog.append(entry).append("\n");
    }
    
    public double getBalance() {
        return balance;
    }
}