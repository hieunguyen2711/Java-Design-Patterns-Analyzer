package banking;

public class TransferService {
    private final Account fromAccount;
    private final Account toAccount;
    
    public TransferService(Account fromAccount, Account toAccount) {
        this.fromAccount = fromAccount;
        this.toAccount = toAccount;
    }
    
    public synchronized boolean transfer(double amount) {
        // Balking - if withdrawal fails, don't proceed with deposit
        if (!fromAccount.withdraw(amount)) {
            System.out.println("Transfer failed: insufficient funds in account " + 
                             fromAccount.getAccountId());
            return false;
        }
        
        // If we reach here, withdrawal succeeded, so proceed with deposit
        boolean success = toAccount.deposit(amount);
        if (!success) {
            // This is a rare case - should ideally rollback the withdrawal
            System.out.println("Transfer failed: could not complete deposit");
            return false;
        }
        
        System.out.println("Transfer of " + amount + " completed from account " + 
                         fromAccount.getAccountId() + " to " + toAccount.getAccountId());
        return true;
    }
}