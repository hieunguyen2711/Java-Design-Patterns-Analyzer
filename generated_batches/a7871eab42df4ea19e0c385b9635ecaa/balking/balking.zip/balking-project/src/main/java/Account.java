package banking;

public class Account {
    private final String accountId;
    private double balance;
    
    public Account(String accountId, double initialBalance) {
        this.accountId = accountId;
        this.balance = initialBalance;
    }
    
    public synchronized boolean withdraw(double amount) {
        if (amount <= 0 || balance < amount) {
            return false; // Balking - cannot proceed with withdrawal
        }
        
        balance -= amount;
        System.out.println("Withdrawal of " + amount + " completed. New balance: " + balance);
        return true;
    }
    
    public synchronized boolean deposit(double amount) {
        if (amount <= 0) {
            return false; // Balking - cannot proceed with invalid deposit
        }
        
        balance += amount;
        System.out.println("Deposit of " + amount + " completed. New balance: " + balance);
        return true;
    }
    
    public double getBalance() {
        return balance;
    }
    
    public String getAccountId() {
        return accountId;
    }
}