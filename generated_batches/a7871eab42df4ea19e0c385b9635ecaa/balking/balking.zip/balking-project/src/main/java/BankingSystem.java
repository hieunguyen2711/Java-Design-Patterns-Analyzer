package banking;

public class BankingSystem {
    public static void main(String[] args) {
        Account account1 = new Account("ACC001", 1000.0);