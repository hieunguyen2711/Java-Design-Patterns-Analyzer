package banking;

public class DepositStrategy implements TransactionStrategy {
    
    @Override
    public void execute(Account fromAccount, Account toAccount, double amount) {
        if (toAccount != null && amount > 0) {
            toAccount.deposit(amount);
        }
    }
    
    @Override
    public String getTransactionType() {
        return "Deposit";
    }
}