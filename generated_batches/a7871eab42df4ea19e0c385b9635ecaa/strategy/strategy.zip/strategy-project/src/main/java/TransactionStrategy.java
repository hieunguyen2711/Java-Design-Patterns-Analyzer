package banking;

public interface TransactionStrategy {
    void execute(Account fromAccount, Account toAccount, double amount);
    String getTransactionType();
}