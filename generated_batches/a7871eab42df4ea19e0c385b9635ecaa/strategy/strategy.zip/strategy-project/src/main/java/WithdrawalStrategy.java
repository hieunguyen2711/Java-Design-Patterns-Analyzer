package banking;

public class WithdrawalStrategy implements TransactionStrategy {
    
    @Override
    public void execute(Account fromAccount, Account toAccount, double amount) {
        if (