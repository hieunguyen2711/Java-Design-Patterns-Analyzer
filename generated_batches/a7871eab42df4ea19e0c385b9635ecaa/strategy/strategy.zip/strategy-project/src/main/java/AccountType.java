package banking;

public enum AccountType {
    CHECKING,
    SAVINGS,
    BUSINESS
}