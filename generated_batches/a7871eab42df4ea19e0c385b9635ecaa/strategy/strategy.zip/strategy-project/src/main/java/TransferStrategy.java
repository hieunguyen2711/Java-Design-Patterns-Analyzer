package banking;

public class TransferStrategy implements TransactionStrategy {
    
    @Override
    public void execute(Account fromAccount, Account toAccount, double amount) {
        if (fromAccount != null && toAccount != null && amount > 0) {
            if (fromAccount.withdraw(amount)) {
                toAccount.deposit(amount);
            }
        }
    }
    
    @Override
    public String getTransactionType() {
        return "Transfer";
    }
}