package banking;

public class SavingsAccount extends Account {
    
    private double interestRate;
    
    public SavingsAccount(String accountId, double initialBalance, double interestRate) {
        super(accountId, initialBalance, "SAVINGS");
        this.interestRate = interestRate;
    }
    
    @Override
    public void applyInterest() {
        balance += balance * interestRate;
    }
}