package banking;

public abstract class Account {
    protected String accountId;
    protected double balance;
    protected String accountType;
    
    public Account(String accountId, double initialBalance, String accountType) {
        this.accountId = accountId;
        this.balance = initialBalance;
        this.accountType = accountType;
    }
    
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
        }
    }
    
    public boolean withdraw(double amount) {
        if (amount > 0 && balance >= amount) {
            balance -= amount;
            return true;
        }
        return false;
    }
    
    public double getBalance() {
        return balance;
    }
    
    public String getAccountId() {
        return accountId;
    }
    
    public abstract void applyInterest();
}