package banking;

public class CheckingAccount extends Account {
    
    public CheckingAccount(String accountId, double initialBalance) {
        super(accountId, initialBalance, "CHECKING");
    }
    
    @Override
    public void applyInterest() {
        // Checking accounts typically don't earn interest
    }
}