package banking;

public class AccountFactory {
    
    public static Account createAccount(String accountType, String accountId, double initialBalance, double interestRate) {
        switch (accountType.toUpperCase()) {
            case "CHECKING":
                return new CheckingAccount(accountId, initialBalance);
            case "SAVINGS":
                return new SavingsAccount(accountId, initialBalance, interestRate);
            default:
                throw new IllegalArgumentException("Unknown account type: " + accountType);
        }
    }
}