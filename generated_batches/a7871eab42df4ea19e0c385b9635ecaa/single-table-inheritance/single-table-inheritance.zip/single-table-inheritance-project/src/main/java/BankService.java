package banking;

import java.util.ArrayList;
import java.util.List;

public class BankService {
    
    private List<Account> accounts;
    
    public BankService() {
        this.accounts = new ArrayList<>();
    }
    
    public