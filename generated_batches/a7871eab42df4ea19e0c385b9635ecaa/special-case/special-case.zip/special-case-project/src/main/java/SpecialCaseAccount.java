package banking;

public class SpecialCaseAccount extends Account {
    
    public SpecialCaseAccount(String accountId, double initialBalance) {
        super(accountId, initialBalance);
    }
    
    @Override
    public boolean withdraw(double amount) {
        // Special case: always allow withdrawal but with penalty
        if (amount > 0 && balance >= amount) {
            balance -= amount;
            balance -= 5.0; // Penalty fee
            return true;
        }
        return false;
    }
}