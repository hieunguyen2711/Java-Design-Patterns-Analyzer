package banking;

public abstract class Account {
    protected String accountId;
    protected double balance;
    
    public Account(String accountId, double initialBalance) {
        this.accountId = accountId;
        this.balance = initialBalance;
    }
    
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
        }
    }
    
    public abstract boolean withdraw(double amount);
    
    public double getBalance() {
        return balance;
    }
    
    public String getAccountId() {
        return accountId;
    }
}