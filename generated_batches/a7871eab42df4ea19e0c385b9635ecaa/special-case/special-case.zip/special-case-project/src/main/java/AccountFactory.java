package banking;

public class AccountFactory {
    
    public static Account createAccount(String type, String accountId, double initialBalance) {
        switch (type.toLowerCase()) {
            case "checking":
                return new CheckingAccount(accountId, initialBalance);
            case "savings":
                return new SavingsAccount(accountId,