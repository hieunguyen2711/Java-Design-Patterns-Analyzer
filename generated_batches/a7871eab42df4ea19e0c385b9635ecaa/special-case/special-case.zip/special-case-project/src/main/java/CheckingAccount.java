package banking;

public class CheckingAccount extends Account {
    private static final double OVERDRAFT_LIMIT = 100.0;
    
    public CheckingAccount(String accountId, double initialBalance) {
        super(accountId, initialBalance);
    }
    
    @Override
    public boolean withdraw(double amount) {
        if (amount > 0 && balance + OVERDRAFT_LIMIT >= amount) {
            balance -= amount;
            return true;
        }
        return false;
    }
}