package banking;

public class SavingsAccount extends Account {
    
    public SavingsAccount(String accountId, double initialBalance) {
        super(accountId, initialBalance);
    }
    
    @Override
    public boolean withdraw(double amount) {
        if (amount > 0 && balance >= amount) {
            balance -= amount;
            return true;
        }
        return false;
    }
}