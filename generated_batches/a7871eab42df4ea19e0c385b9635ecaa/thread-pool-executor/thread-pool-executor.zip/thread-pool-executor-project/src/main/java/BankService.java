package com.example.bank;

public class BankService {
    private TransactionProcessor processor;