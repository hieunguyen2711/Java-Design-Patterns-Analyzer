package com.example.bank;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

public class TransactionProcessor {
    private final ExecutorService executorService;
    
    public TransactionProcessor(int poolSize) {
        this.executorService = Executors.newFixedThreadPool(poolSize);
    }
    
    public void processTransaction(Transaction transaction) {
        executorService.submit(() -> {
            // Simulate transaction processing
            System.out.println("Processing " + transaction.getType() + 
                             " of $" + transaction.getAmount() + 
                             " for account " + transaction.getAccountId());
            
            try {
                Thread.sleep(100); // Simulate work
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            
            System.out.println("Completed processing " + transaction.getType() + 
                             " of $" + transaction.getAmount());
        });
    }
    
    public void shutdown() {
        executorService.shutdown();
    }
}