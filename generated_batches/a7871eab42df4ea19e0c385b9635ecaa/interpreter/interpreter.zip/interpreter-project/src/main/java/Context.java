import java.util.List;

public class Context {
    private List<Account> accounts;
    private Transaction transaction;

    public Context(List<Account> accounts, Transaction transaction) {
        this.accounts = accounts;
        this.transaction = transaction;
    }

    public List<Account> getAccounts() {
        return accounts;
    }

    public Transaction getTransaction() {
        return transaction;
    }
}