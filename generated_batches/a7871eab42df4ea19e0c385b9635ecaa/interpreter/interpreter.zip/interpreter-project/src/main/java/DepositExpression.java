public class DepositExpression implements Expression {
    @Override
    public boolean interpret(Context context) {
        if ("DEPOSIT".equals(context.getTransaction().getType())) {
            Account account = findAccount(context, context.getTransaction().getFromAccount());
            if (account != null) {
                account.deposit(context.getTransaction().getAmount());
                return true;
            }
        }
        return false;
    }

    private Account findAccount(Context context, String accountNumber) {
        for (Account account : context.getAccounts()) {
            if (account.getAccountNumber().equals(accountNumber)) {
                return account;