import java.util.HashMap;
import java.util.Map;

public class AccountManager {
    private static final Map<String, Account> accounts = new HashMap<>();
    private static final int MAX_ACCOUNTS = 5;
    
    private AccountManager() {}
    
    public static Account getAccount(String accountNumber) {
        if (!accounts.containsKey(accountNumber)) {
            if (accounts.size() >= MAX_ACCOUNTS) {
                throw new IllegalStateException("Maximum number of accounts reached");
            }
            accounts.put(accountNumber, new Account(accountNumber, 0.0));
        }
        return accounts.get(accountNumber);
    }
    
    public static int getAccountCount() {
        return accounts.size();
    }
}