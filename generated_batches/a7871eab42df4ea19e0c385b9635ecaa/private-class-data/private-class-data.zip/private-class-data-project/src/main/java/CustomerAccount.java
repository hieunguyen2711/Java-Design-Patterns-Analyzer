package com.example.bank;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class CustomerAccount {
    private final String accountNumber;
    private final String customerName;
    private BigDecimal balance;
    private final List<AuditEntry> auditTrail;
    
    public CustomerAccount(String accountNumber, String customerName, BigDecimal initialBalance) {
        this.accountNumber = accountNumber;
        this.customerName = customerName;
        this.balance = initialBalance;
        this.auditTrail = new ArrayList<>();
        
        addAuditEntry("Account created", initialBalance);
    }
    
    public void deposit(BigDecimal amount) {
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Deposit amount must be positive");
        }
        balance = balance.add(amount);
        addAuditEntry("Deposit", amount);
    }
    
    public void withdraw(BigDecimal amount) {
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Withdrawal amount must be positive");
        }
        if (amount.compareTo(balance) > 0) {
            throw new IllegalStateException("Insufficient funds");
        }
        balance = balance.subtract(amount);
        addAuditEntry("Withdrawal", amount);
    }
    
    public void transfer(CustomerAccount target, BigDecimal amount) {
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Transfer amount must be positive");
        }
        if (amount.compareTo(balance) > 0) {
            throw new IllegalStateException("Insufficient funds for transfer");
        }
        
        this.balance = balance.subtract(amount);
        target.balance = target.balance.add(amount);
        
        addAuditEntry("Transfer to " + target.accountNumber, amount);
        target.addAuditEntry("Transfer from " + this.accountNumber, amount);
    }
    
    public BigDecimal getBalance() {
        return balance;
    }
    
    public String getAccountNumber() {
        return accountNumber;
    }
    
    public String getCustomerName() {
        return customerName;
    }
    
    public List<AuditEntry> getAuditTrail() {
        return new ArrayList<>(auditTrail); // Return copy to maintain encapsulation
    }
    
    private void addAuditEntry(String action, BigDecimal amount) {
        auditTrail.add(new AuditEntry(action, amount, LocalDateTime.now()));
    }
}