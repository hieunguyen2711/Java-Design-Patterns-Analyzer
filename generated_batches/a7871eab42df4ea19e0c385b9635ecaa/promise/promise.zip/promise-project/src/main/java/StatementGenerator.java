package banking;

import java.util.List;
import java.util.ArrayList;

public class StatementGenerator {
    
    public List<String> generateStatement(Account account, List<Transaction> transactions) {
        List<String> statement = new ArrayList<>();
        statement.add("Account Statement for " + account.getAccountId());
        statement.add("Initial Balance: $" + String.format("%.2f", account.getBalance()));
        
        double balance = account.getBalance();
        for (Transaction transaction : transactions) {
            switch (transaction.getType()) {
                case DEPOSIT:
                    balance += transaction.getAmount();
                    statement.add("Deposit: +" + String.format("%.2f", transaction.getAmount