package com.example.bank;

public class AccountService {
    private static AccountService instance;
    
    private AccountService() {}
    
    public static synchronized AccountService getInstance() {
        if (instance == null) {
            instance = new AccountService();
        }
        return instance;
    }
    
    public void deposit(Account account, double amount) {
        account.deposit(amount);
    }
    
    public boolean withdraw(Account account, double amount) {
        return account.withdraw(amount);
    }
}