package com.example.bank;

public class Transaction {
    private String transactionId;
    private String accountId;
    private String type;
    private double amount;
    private double balanceAfter;
    
    public Transaction(String transactionId, String accountId, String type, double amount, double balanceAfter) {
        this.transactionId = transactionId;
        this.accountId = accountId;
        this.type = type;
        this.amount = amount;
        this.balanceAfter = balanceAfter;
    }
    
    public String getTransactionId() {
        return transactionId;
    }
    
    public String getAccountId() {
        return accountId;
    }
    
    public String getType() {
        return type;
    }
    
    public double getAmount() {
        return amount;
    }
    
    public double getBalanceAfter() {
        return balanceAfter;
    }
}