package com.example.bank;

import java.util.ArrayList;
import java.util.List;

public class TransactionHistory {
    private static TransactionHistory instance;
    private List<Transaction> transactions;
    
    private TransactionHistory() {
        this.transactions = new ArrayList<>();
    }
    
    public static synchronized TransactionHistory