public class TransactionScript {
    private Account fromAccount;
    private Account toAccount;
    private double amount;
    
    public TransactionScript(Account fromAccount, Account toAccount, double amount) {
        this.fromAccount = fromAccount;
        this.toAccount = toAccount;
        this.amount = amount;
    }
    
    public void execute() {
        if (fromAccount.getBalance() >= amount) {
            fromAccount.setBalance(fromAccount.getBalance() - amount);
            toAccount.setBalance(toAccount.getBalance() + amount);
        } else {
            throw new RuntimeException("Insufficient funds");
        }
    }
}