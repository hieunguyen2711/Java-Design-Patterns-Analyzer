public class Main {
    public static void main(String[] args) {
        Account account1 = new Account("ACC001", 1000.0);
        Account account2 = new Account("ACC002", 500.0);
        
        AccountService service = new AccountService();
        
        System.out.println("Initial balances:");
        System.out.println("Account 1: " + account1.getBalance());
        System.out.println("Account