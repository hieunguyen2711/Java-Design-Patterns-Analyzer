public class AccountService {
    public void transfer(Account from, Account to, double amount) {
        TransactionScript transaction = new TransactionScript(from, to, amount);
        transaction.execute();
    }
    
    public void deposit(Account account, double amount) {
        TransactionScript transaction = new TransactionScript(account, null, amount);
        // Simple deposit logic
        account.setBalance(account.getBalance() + amount);
    }
    
    public void withdraw(Account account, double amount) {
        TransactionScript transaction = new TransactionScript(account, null, amount);
        // Simple withdrawal logic
        if (account.getBalance() >= amount) {
            account.setBalance(account.getBalance() - amount);
        } else {
            throw new RuntimeException("Insufficient funds");
        }
    }
}