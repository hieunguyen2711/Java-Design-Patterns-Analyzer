package com.example.bank;

public class Account {
    private final String accountId;
    private final String accountNumber;
    private final double balance;
    private final Customer customer;
    
    private Account(Builder builder) {
        this.accountId = builder.accountId;
        this.accountNumber = builder.accountNumber;
        this.balance = builder.balance;
        this.customer = builder.customer;
    }
    
    public String getAccountId() {
        return accountId;
    }
    
    public String getAccountNumber() {
        return accountNumber;
    }
    
    public double getBalance() {
        return balance;
    }
    
    public Customer getCustomer() {
        return customer;
    }
    
    public static class Builder {
        private String accountId;
        private String accountNumber;
        private double balance;
        private Customer customer;
        
        public Builder setAccountId(String accountId) {
            this.accountId = accountId;
            return this;
        }
        
        public Builder setAccountNumber(String accountNumber) {
            this.accountNumber = accountNumber;
            return this;
        }
        
        public Builder setBalance(double balance) {
            this.balance = balance;
            return this