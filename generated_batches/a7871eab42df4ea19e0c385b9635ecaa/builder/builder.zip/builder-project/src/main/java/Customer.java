package com.example.bank;

public class Customer {
    private final String customerId;
    private final String name;
    private final String email;
    private final String phoneNumber;
    
    private Customer(Builder builder) {
        this.customerId = builder.customerId;
        this.name = builder.name;
        this.email = builder.email;
        this.phoneNumber = builder.phoneNumber;
    }
    
    public String getCustomerId() {
        return customerId;
    }
    
    public String getName() {
        return name;
    }
    
    public String getEmail() {
        return email;
    }
    
    public String getPhoneNumber() {
        return phoneNumber;
    }
    
    public static class Builder {
        private String customerId;
        private String name;
        private String email;
        private String phoneNumber;
        
        public Builder setCustomerId(String customerId) {
            this.customerId = customerId;
            return this;
        }
        
        public Builder setName(String name) {
            this.name = name;
            return this;
        }
        
        public Builder setEmail(String email) {
            this.email = email;
            return this;
        }
        
        public Builder setPhoneNumber(String phoneNumber) {
            this.phoneNumber = phoneNumber;
            return this;
        }
        
        public Customer build() {
            return new Customer(this);
        }
    }
}