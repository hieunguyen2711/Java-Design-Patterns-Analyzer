import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class AccountProxyHandler implements InvocationHandler {
    private final Account account;
    
    public AccountProxyHandler(Account account) {
        this.account = account;
    }
    
    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        String methodName = method.getName();
        
        if (methodName.equals("deposit") || methodName.equals("withdraw")) {
            double amount = (Double) args[0];
            AuditLogger.log(methodName, amount);
        }
        
        return method.invoke(account, args);
    }
}