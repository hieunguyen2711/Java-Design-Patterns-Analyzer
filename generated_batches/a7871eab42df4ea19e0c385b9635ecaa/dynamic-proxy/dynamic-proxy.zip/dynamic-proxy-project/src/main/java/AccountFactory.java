import java.lang.reflect.Proxy;

public class AccountFactory {
    public static Account createAccount(double initialBalance) {
        Account account = new BankAccount(initialBalance);
        return (Account) Proxy.newProxyInstance(
            Account.class.getClassLoader(),
            new Class[]{Account.class},
            new AccountProxyHandler(account)
        );
    }
}