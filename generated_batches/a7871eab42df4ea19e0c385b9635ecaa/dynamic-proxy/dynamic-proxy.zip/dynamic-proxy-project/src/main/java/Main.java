public class Main {
    public static void main(String[] args) {
        Account account = AccountFactory.createAccount(1000.0);
        
        account.deposit(500.0);
        account