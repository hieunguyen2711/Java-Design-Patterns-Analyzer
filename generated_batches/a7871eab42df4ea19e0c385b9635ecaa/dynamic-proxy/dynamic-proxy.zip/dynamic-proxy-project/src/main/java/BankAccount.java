public class BankAccount implements Account {
    private double balance;
    
    public BankAccount(double initialBalance) {
        this.balance = initialBalance;
    }
    
    @Override
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
        }
    }
    
    @Override
    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
        }
    }
    
    @Override
    public double getBalance() {
        return balance;
    }
    
    @Override
    public String generateStatement() {
        return "Account Balance: $" + balance;
    }
}