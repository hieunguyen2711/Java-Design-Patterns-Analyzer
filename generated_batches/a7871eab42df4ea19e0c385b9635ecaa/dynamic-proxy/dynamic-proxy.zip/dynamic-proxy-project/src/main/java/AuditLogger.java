public class AuditLogger {
    public static void log(String operation, double amount) {
        System.out.println("AUDIT: " + operation + " of $" + amount);
    }
}