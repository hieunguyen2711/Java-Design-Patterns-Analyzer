public interface Mediator {
    void executeTransaction(String fromAccount, String toAccount, double amount);
    void generateStatement(String accountNumber);
    void recordAudit(String action, String accountNumber);
}