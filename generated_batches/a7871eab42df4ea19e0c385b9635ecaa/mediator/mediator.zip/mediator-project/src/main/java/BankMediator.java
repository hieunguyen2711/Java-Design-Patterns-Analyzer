import java.util.ArrayList;
import java.util.List;

public class BankMediator implements Mediator {
    private List<BankAccount> accounts;
    private List<Transaction> transactions;
    private List<String> auditLog;
    
    public BankMediator() {