package com.example.bank;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;

public class ActiveObject implements Runnable {
    private final BlockingQueue<Runnable> requestQueue;
    private final AtomicBoolean running = new AtomicBoolean(true);
    
    public ActiveObject(BlockingQueue<Runnable> requestQueue) {
        this.requestQueue = requestQueue;
    }
    
    @Override
    public void run() {
        while (running.get()) {
            try {
                Runnable request = requestQueue.take();
                request.run();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }