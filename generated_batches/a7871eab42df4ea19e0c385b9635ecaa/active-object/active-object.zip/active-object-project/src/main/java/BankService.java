package com.example.bank;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class BankService {
    private final BlockingQueue<Runnable> requestQueue = new LinkedBlockingQueue<>();
    private final ActiveObject activeObject;
    
    public BankService() {
        this.activeObject = new ActiveObject(requestQueue);
        Thread workerThread = new Thread(activeObject::run);
        workerThread.start();
    }
    
    public void deposit(String accountId, double amount) {
        requestQueue.add(() -> {
            // Simulate actual processing
            System.out.println("Processing deposit of " + amount + " to account " + accountId);
            try {
                Thread.sleep(100); // Simulate work
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
    }
    
    public boolean withdraw(String accountId, double amount) {
        // This would be implemented with proper synchronization in a real system
        return true;
    }
}