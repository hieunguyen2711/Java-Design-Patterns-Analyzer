import java.util.List;
import java.util.ArrayList;

public class AccountService {
    private List<CustomerAccount> accounts;
    private List<Transaction> transactions;