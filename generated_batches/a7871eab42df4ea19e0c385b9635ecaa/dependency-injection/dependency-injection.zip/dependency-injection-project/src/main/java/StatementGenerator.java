package com.example.bank;

import java.util.List;

public interface StatementGenerator {
    String generateStatement(List<Transaction> transactions);
}