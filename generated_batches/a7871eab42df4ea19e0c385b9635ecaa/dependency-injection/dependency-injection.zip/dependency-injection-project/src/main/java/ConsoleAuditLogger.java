package com.example.bank;

public class ConsoleAuditLogger implements AuditLogger {
    @Override
    public void log(String message) {
        System.out.println("AUDIT: " + message);
    }
}