package com.example.bank;

public interface AuditLogger {
    void log(String message);
}