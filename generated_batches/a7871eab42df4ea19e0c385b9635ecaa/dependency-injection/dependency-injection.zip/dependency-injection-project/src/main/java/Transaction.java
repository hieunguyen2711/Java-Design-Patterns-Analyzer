package com.example.bank;

public class Transaction {
    private String transactionId;
    private String fromAccountId;
    private String toAccountId;
    private double amount;
    private TransactionType type;
    
    public Transaction(String transactionId, String fromAccountId, String toAccountId, double amount, TransactionType type) {
        this.transactionId = transactionId;
        this.fromAccountId = fromAccountId;
        this.toAccountId = toAccountId;
        this.amount = amount;
        this.type = type;
    }
    
    public String getTransactionId() {
        return transactionId;
    }
    
    public String getFromAccountId() {
        return fromAccountId;
    }
    
    public String getToAccountId() {
        return toAccountId;
    }
    
    public double getAmount() {
        return amount;
    }
    
    public TransactionType getType() {
        return type;
    }
}