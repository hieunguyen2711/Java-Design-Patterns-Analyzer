public class ConsoleAuditTrail extends AuditTrail {
    @Override
    public void record(String transaction, double amount) {
        System.out.println("Console Audit: " + transaction + " of $" + amount);
    }
}