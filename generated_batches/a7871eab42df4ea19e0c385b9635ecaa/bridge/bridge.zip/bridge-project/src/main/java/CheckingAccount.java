public class CheckingAccount extends Account {
    private final AuditTrail auditTrail;
    
    public CheckingAccount(double initialBalance) {
        super(AccountType.CHECKING, initialBalance);
        this.auditTrail = new ConsoleAuditTrail();
    }
    
    @Override
    public AuditTrail auditTrail() {
        return auditTrail;
    }
}