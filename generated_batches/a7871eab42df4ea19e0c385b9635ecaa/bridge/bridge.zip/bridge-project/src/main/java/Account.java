public abstract class Account {
    protected AccountType accountType;
    protected double balance;
    
    public Account(AccountType accountType, double initialBalance) {
        this.accountType = accountType;
        this.balance = initialBalance;
    }
    
    public void deposit(double amount) {
        balance += amount;
        auditTrail().record("Deposit", amount);
    }
    
    public void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
            auditTrail().record("Withdrawal", amount);
        } else {
            throw new IllegalArgumentException("Insufficient funds");
        }
    }
    
    public abstract AuditTrail auditTrail();
    
    public double getBalance() {
        return balance;
    }
    
    public AccountType getAccountType() {
        return accountType;
    }
}