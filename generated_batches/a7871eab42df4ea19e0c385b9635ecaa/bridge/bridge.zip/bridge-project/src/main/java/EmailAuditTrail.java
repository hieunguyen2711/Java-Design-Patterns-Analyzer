public class EmailAuditTrail extends AuditTrail {
    @Override
    public void record(String transaction, double amount) {
        System.out.println("Email Audit: " + transaction + " of $" + amount);
    }
}