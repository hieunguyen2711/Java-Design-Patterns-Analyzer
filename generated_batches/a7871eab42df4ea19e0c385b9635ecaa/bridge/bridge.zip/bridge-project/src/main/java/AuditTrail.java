public abstract class AuditTrail {
    public abstract void record(String transaction, double amount);
}