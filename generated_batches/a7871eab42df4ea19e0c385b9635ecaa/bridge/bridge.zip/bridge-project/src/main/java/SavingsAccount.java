public class SavingsAccount extends Account {
    private final AuditTrail auditTrail;
    
    public SavingsAccount(double initialBalance) {
        super(AccountType.SAVINGS, initialBalance);
        this.auditTrail = new EmailAuditTrail();
    }
    
    @Override
    public AuditTrail auditTrail() {
        return auditTrail;
    }
}