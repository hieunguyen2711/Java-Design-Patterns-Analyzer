public class DepositService implements BusinessService {
    @Override
    public void doProcessing() {
        System.out.println("Processing deposit service");
    }
}