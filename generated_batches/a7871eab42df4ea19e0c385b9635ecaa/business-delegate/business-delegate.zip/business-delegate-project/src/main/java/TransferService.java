public class TransferService implements BusinessService {
    @Override
    public void doProcessing() {
        System.out.println("Processing transfer service");
    }
}