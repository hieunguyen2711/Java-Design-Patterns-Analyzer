public class CustomerAccountService implements BusinessService {
    @Override
    public void doProcessing() {
        System.out.println("Processing customer account service");
    }
}