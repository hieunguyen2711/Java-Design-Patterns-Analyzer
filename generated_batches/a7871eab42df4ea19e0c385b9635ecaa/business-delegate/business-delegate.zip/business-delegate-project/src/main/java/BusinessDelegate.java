public class BusinessDelegate {
    private BusinessService businessService;
    private String serviceType;

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public void doTask() {
        if (businessService == null) {
            businessService = ServiceLookup.getService(serviceType);
        }
        businessService.doProcessing();
    }
}