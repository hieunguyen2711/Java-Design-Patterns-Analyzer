public class ServiceLookup {
    public static BusinessService getService(String serviceType) {
        if (serviceType.equalsIgnoreCase("CUSTOMER_ACCOUNT")) {
            return new CustomerAccountService();
        } else if (serviceType.equalsIgnoreCase("DEPOSIT")) {
            return new DepositService();
        } else if (serviceType.equalsIgnoreCase("TRANSFER")) {
            return new TransferService();
        }
        return null;
    }
}