public class BankApplication {
    public static void main(String[] args) {
        BusinessDelegate delegate = new BusinessDelegate();
        
        Client client = new Client(delegate);
        
        delegate.setServiceType("CUSTOMER_ACCOUNT");
        client.doTask();
        
        delegate.setServiceType("DEPOSIT");
        client.doTask();
        
        delegate.setServiceType("TRANSFER");
        client.doTask();
    }
}