package banking;

public class Account {
    private final String accountNumber;
    private double balance;
    
    public Account(String accountNumber, double initialBalance) {
        this.accountNumber = accountNumber;
        this.balance = initialBalance;
    }
    
    public synchronized void deposit(double amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Deposit amount must be positive");
        }
        balance += amount;
        System.out.println("Deposited " + amount + ", new balance: " + balance);
        notifyAll();
    }
    
    public synchronized double withdraw(double amount) throws InterruptedException {
        while (balance < amount) {
            System.out.println("Insufficient funds. Waiting for deposit...");
            wait(); // Guarded suspension - waiting until condition is met
        }
        
        if (amount <= 0) {
            throw new IllegalArgumentException("Withdrawal amount must be positive");
        }
        
        balance -= amount;
        System.out.println("Withdrew " + amount + ", new balance: " + balance);
        return amount;
    }
    
    public synchronized double getBalance() {
        return balance;
    }
    
    public String getAccountNumber() {
        return accountNumber;
    }
}