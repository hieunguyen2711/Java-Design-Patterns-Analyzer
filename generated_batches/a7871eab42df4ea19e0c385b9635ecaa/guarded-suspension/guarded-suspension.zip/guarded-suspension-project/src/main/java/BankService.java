package banking;

public class BankService {
    private final Account account1;
    private final Account account2;
    
    public BankService() {
        this.account1 = new Account("ACC001", 1000.0);
        this.account2 = new Account("ACC002", 500.0);
    }
    
    public void transfer(String fromAccount, String toAccount, double amount) 
            throws InterruptedException {
        if (fromAccount.equals(account1.getAccountNumber())) {
            account1.withdraw(amount); // This will suspend if insufficient funds
            account2.deposit(amount);
        } else if (fromAccount.equals(account2.getAccountNumber())) {
            account2.withdraw(amount); // This will suspend if insufficient funds
            account1.deposit(amount);
        }
    }
    
    public void printBalances() {
        System.out.println("Account 1 balance: " + account1.getBalance());
        System.out.println("Account 2 balance: " + account2.getBalance());
    }
}