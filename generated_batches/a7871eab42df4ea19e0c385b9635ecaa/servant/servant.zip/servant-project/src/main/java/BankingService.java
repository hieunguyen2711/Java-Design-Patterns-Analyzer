package banking;

public class BankingService {
    private Account sourceAccount;
    private Account targetAccount;
    
    public BankingService(String sourceId, String targetId) {
        this.sourceAccount = new Account(sourceId, 1000.0);
        this.targetAccount = new Account(targetId, 500.0);
    }
    
    public void performTransfer(double amount) {
        TransactionServant transaction = new TransactionServant(sourceAccount, targetAccount);