package banking;

public class AuditTrail {
    private Account account;
    
    public AuditTrail(Account account) {
        this.account = account;
    }
    
    public void logTransaction(String transactionType, double amount) {
        System.out.println("Audit Log - " + transactionType + 
                          ": $" + amount + " on account " + 
                          account.getAccountId());
    }
}