package banking;

public class StatementGenerator {
    private Account account;
    
    public StatementGenerator(Account account) {
        this.account = account;
    }
    
    public String generateStatement() {
        return "Account: " + account.getAccountId() + 
               ", Balance: $" + account.getBalance();
    }
}