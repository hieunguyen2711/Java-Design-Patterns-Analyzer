package banking;

public class TransactionServant {
    private Account sourceAccount;
    private Account targetAccount;
    
    public TransactionServant(Account source, Account target) {
        this.sourceAccount = source;
        this.targetAccount = target;
    }
    
    public boolean transfer(double amount) {
        if (sourceAccount.withdraw(amount)) {
            targetAccount.deposit(amount);
            return true;
        }
        return false;
    }
}