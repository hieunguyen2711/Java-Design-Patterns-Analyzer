package banking;

import java.util.ArrayList;
import java.util.List;

public class AccountService {
    private List<Account> accounts;
    
    public AccountService() {
        this.accounts = new ArrayList<>();
    }
    
    public void addAccount(Account account) {
        accounts.add(account);
    }
    
    public Account getAccount(String accountNumber) {
        return accounts.stream()
                .filter(acc -> acc.getAccountNumber().equals(accountNumber))
                .findFirst()
                .orElse(null);
    }
    
    public void executeTransaction(String fromAccount, String toAccount, 
                                 double amount, String description) {
        // Execute-around pattern: wrap the transaction logic with audit logging
        AuditLogger.log("Starting transfer from " + fromAccount + " to " + toAccount);
        
        Account source = getAccount(fromAccount);
        Account target = getAccount(toAccount);