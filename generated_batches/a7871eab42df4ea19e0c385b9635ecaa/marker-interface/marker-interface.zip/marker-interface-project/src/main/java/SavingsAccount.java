package com.example.bank;

public class SavingsAccount extends Account implements Auditable {
    private double interestRate;
    
    public SavingsAccount(String accountNumber, double initialBalance, double interestRate) {
        super(accountNumber, initialBalance);
        this.interestRate = interestRate;
    }
    
    public void addInterest() {
        double interest = getBalance() * interestRate / 100;
        deposit(interest);
    }
    
    public double getInterestRate() {
        return interestRate;
    }
}