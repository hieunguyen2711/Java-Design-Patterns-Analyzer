package com.example.bank;

public class CheckingAccount extends Account implements Auditable {
    private double overdraftLimit;
    
    public CheckingAccount(String accountNumber, double initialBalance, double overdraftLimit) {
        super(accountNumber, initialBalance);
        this.overdraftLimit = overdraftLimit;
    }
    
    @Override
    public boolean withdraw(double amount) {
        if (amount > 0 && balance + overdraftLimit >= amount) {
            balance -= amount;
            return true;
        }
        return false;
    }