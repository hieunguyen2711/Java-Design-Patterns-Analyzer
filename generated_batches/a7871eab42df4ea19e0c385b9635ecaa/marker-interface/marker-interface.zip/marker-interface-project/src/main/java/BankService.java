package com.example.bank;

public class BankService {
    private Account account;
    
    public BankService(Account account) {
        this.account = account;
    }
    
    public void performDeposit(double amount) {
        account.deposit(amount);
    }
    
    public boolean performWithdrawal(double amount) {
        return account.withdraw(amount);
    }
}