package com.example.bank;

public interface Auditable {
    // Marker interface - no methods required
}