package banking;

public class TransactionProcessor {
    private Account account;
    
    public TransactionProcessor(Account account) {
        this.account = account;
    }
    
    public void processDeposit(double amount) {
        if (amount > 0) {
            double previousBalance = account.getBalance();
            account.deposit(amount);
            System.out.println("Deposited: $" + amount + ", New Balance: $" + account.getBalance());
        }
    }
    
    public boolean processWithdrawal(double amount) {
        if (amount > 0) {
            double previousBalance = account.getBalance();
            boolean success = account.withdraw(amount);
            if (success) {
                System.out.println("Withdrew: $" + amount + ", New Balance: $" + account.getBalance());
            } else {
                System.out.println("Insufficient funds for withdrawal