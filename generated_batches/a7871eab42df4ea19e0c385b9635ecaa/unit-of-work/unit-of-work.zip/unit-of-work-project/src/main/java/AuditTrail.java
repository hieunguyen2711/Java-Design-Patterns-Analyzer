package banking;

import java.util.ArrayList;
import java.util.List;

public class AuditTrail {
    private List<String> entries;
    
    public AuditTrail() {
        this.entries = new ArrayList<>();
    }
    
    public void addEntry(String entry) {
        entries.add(entry);
    }
    
    public List<String> getEntries() {
        return new ArrayList<>(entries);
    }
}