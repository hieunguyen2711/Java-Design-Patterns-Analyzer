package banking;

import java.util.*;

public class UnitOfWork {
    private Map<String, CustomerAccount> accounts;
    private Map<String, Transaction> transactions;
    private AuditTrail auditTrail;
    
    public UnitOfWork() {
        this.accounts = new HashMap<>();
        this.transactions = new HashMap<>();
        this.auditTrail = new AuditTrail();
    }
    
    public void