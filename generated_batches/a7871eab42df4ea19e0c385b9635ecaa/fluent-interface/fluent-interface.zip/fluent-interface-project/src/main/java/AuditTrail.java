package com.example.bank;

public class AuditTrail {
    private StringBuilder auditLog;
    
    public AuditTrail() {
        this.auditLog = new StringBuilder();
    }
    
    public AuditTrail log(String action) {
        auditLog.append(String.format("[%s] %s\n", 
            java.time.LocalDateTime.now(), action));
        return this;
    }
    
    public AuditTrail withUser(String user) {
        auditLog.append