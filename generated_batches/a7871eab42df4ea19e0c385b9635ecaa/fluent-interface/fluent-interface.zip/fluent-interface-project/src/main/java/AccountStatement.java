package com.example.bank;

public class AccountStatement {
    private StringBuilder statementBuilder;
    
    public AccountStatement() {
        this.statementBuilder = new StringBuilder();
    }
    
    public AccountStatement addTransaction(String transactionType, double amount) {
        statementBuilder.append(String.format("%s: $%.2f\n", transactionType, amount));
        return this;
    }
    
    public AccountStatement withAccountInfo(CustomerAccount account) {
        statementBuilder.append(String.format("Account: %s - %s\n", 
            account.getAccountNumber(), account.getCustomerName()));
        statementBuilder.append(String.format("Balance: $%.2f\n", account.getBalance()));
        return this;
    }
    
    public String generate() {
        return statementBuilder.toString();
    }
}