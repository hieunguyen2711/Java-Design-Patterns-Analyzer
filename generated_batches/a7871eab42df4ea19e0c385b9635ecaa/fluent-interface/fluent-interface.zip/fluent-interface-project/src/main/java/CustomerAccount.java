package com.example.bank;

public class CustomerAccount {
    private String accountNumber;
    private String customerName;
    private double balance;
    
    public CustomerAccount(String accountNumber, String customerName) {
        this.accountNumber = accountNumber;
        this.customerName = customerName;
        this.balance = 0.0;
    }
    
    public CustomerAccount deposit(double amount) {
        if (amount > 0) {
            this.balance += amount;
        }
        return this;
    }
    
    public CustomerAccount withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            this.balance -= amount;
        }
        return this;
    }
    
    public CustomerAccount transfer(CustomerAccount targetAccount, double amount) {
        if (amount > 0 && amount <= balance) {
            this.balance -= amount;
            targetAccount.balance += amount;
        }
        return this;
    }
    
    public String getAccountNumber() {
        return accountNumber;
    }
    
    public String getCustomerName() {
        return customerName;
    }
    
    public double getBalance() {
        return balance;
    }
}