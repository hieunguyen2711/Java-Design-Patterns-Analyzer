public class BankService {
    private CustomerAccount account1;
    private Customer