package banking;

public class CustomerAccount {
    private String accountId;
    private String customerId;
    private double balance;
    
    public CustomerAccount(String accountId, String customerId, double initialBalance) {
        this.accountId = accountId;
        this.customerId = customerId;
        this.balance = initialBalance;
    }
    
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
        }
    }
    
    public boolean withdraw(double amount) {
        if (amount > 0 && balance >= amount) {
            balance -= amount;
            return true;
        }
        return false;
    }
    
    public double getBalance() {
        return balance;
    }
    
    public String getAccountId() {
        return accountId;
    }
    
    public String getCustomerId() {
        return customerId;
    }
}