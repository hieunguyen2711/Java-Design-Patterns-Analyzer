package banking;

import java.util.HashMap;
import java.util.Map;

public class BankingServiceImpl implements TransactionService {
    private Map<String, CustomerAccount> accounts;
    private AuditLogService auditLogService;
    
    public BankingServiceImpl() {
        this.accounts = new HashMap<>();
        this.auditLogService = new AuditLogService();
    }
    
    @Override
    public boolean deposit(String accountId, double amount) {
        CustomerAccount account = accounts.get(accountId);
        if (account != null && amount > 0) {
            account.deposit(amount);
            auditLogService.log("DEPOSIT", accountId);
            return true;
        }
        return false;
    }
    
    @Override
    public boolean withdraw(String accountId, double amount) {
        CustomerAccount account = accounts.get(accountId);
        if (account != null && amount > 0) {
            boolean success = account.withdraw(amount);
            if (success) {
                auditLogService.log("WITHDRAWAL", accountId);
            }
            return success;
        }
        return false;
    }
    
    @Override
    public boolean transfer(String fromAccountId, String toAccountId, double amount) {
        CustomerAccount fromAccount = accounts.get(fromAccountId);