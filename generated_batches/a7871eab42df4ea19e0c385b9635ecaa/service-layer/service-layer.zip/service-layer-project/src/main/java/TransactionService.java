package banking;

public interface TransactionService {
    boolean deposit(String accountId, double amount);
    boolean withdraw(String accountId, double amount);
    boolean transfer(String fromAccountId, String toAccountId, double amount);
    String generateStatement(String accountId);
    void logAudit(String action, String accountId);
}