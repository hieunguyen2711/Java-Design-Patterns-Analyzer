public class StatementService {
    public void generateStatement(BankAccount account) {
        System.out.println("Account Statement for " + account.getAccountNumber() + 
                          ": Balance = $" + account.getBalance());
    }
}