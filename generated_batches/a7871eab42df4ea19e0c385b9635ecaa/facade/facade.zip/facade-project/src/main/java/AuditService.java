public class AuditService {
    public void logTransaction(String transactionType, BankAccount account, double amount) {
        System.out.println("Audit Log - " + transactionType +