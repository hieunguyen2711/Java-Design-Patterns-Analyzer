public class DepositService {
    public void deposit(BankAccount account, double amount) {
        account.deposit(amount);
        System.out.println("Deposited $" + amount + " into account " + account.getAccountNumber());
    }
}