public class TransferService {
    public void transfer(BankAccount fromAccount, BankAccount toAccount, double amount) {
        if (fromAccount.withdraw(amount)) {
            toAccount.deposit(amount);
            System.out.println("Transferred $" + amount + " from account " + 
                             fromAccount.getAccountNumber() + " to " + toAccount.getAccountNumber());
        } else {
            System.out.println("Transfer failed: insufficient funds in " + fromAccount.getAccountNumber());
        }
    }
}