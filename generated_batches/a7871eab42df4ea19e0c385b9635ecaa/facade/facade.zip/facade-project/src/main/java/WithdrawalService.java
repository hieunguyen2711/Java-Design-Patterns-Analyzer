public class WithdrawalService {
    public boolean withdraw(BankAccount account, double amount) {
        boolean success = account.withdraw(amount);
        if (success) {
            System.out.println("Withdrew $" + amount + " from account " + account.getAccountNumber());
        } else {
            System.out.println("Insufficient funds for withdrawal of $" + amount);
        }
        return success;
    }
}