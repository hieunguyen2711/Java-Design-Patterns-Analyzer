package com.example.bank;

public class TransferService {
    private final Account sourceAccount;
    private final Account targetAccount;
    
    public TransferService(Account source, Account target) {
        this.sourceAccount = source;
        this.targetAccount = target;
    }
    
    public boolean transfer(double amount) {
        if (sourceAccount.withdraw(amount)) {
            targetAccount.deposit(amount);
            return true;
        }
        return false;
    }
}