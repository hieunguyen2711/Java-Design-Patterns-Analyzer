package com.example.bank;

public class AuditLogger {
    private final Account account;
    
    public AuditLogger(Account account) {
        this.account = account;
    }
    
    public void logDeposit(double amount) {
        System.out.println("AUDIT: Deposit of $" + amount + 
                          " to account " + account.getAccountNumber());
    }
    
    public void logWithdrawal(double amount) {
        System.out.println("AUDIT: Withdrawal of $" + amount + 
                          " from account " + account.getAccountNumber());
    }
}