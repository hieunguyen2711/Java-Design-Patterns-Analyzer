package com.example.bank;

public class StatementGenerator {
    private final Account account;
    
    public StatementGenerator(Account account) {
        this.account = account;
    }
    
    public String generateStatement() {
        return "Account: " + account.getAccountNumber() + 
               ", Balance: $" + account.getBalance();
    }
}