package com.example.bank;

public class BankApplication {
    public static void main(String[] args) {
        Account account1 = new Account("ACC001", 1000