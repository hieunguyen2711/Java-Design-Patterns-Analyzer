package banking;

public class Transaction {
    private int transactionId;
    private int accountId;
    private String type;
    private double amount;
    private String timestamp;
    
    public Transaction(int transactionId, int accountId, String type, double amount, String timestamp) {
        this.transactionId = transactionId;
        this.accountId = accountId;
        this.type = type;
        this.amount = amount;
        this.timestamp = timestamp;
    }
    
    // Getters and setters
    public int getTransactionId() { return transactionId; }
    public void setTransactionId(int transactionId) { this.transactionId = transactionId; }
    
    public int getAccountId() {