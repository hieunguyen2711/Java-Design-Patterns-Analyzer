import java.util.List;

public interface CustomerDAO {
    Customer getCustomerById(int customerId);
    List<Customer> getAllCustomers();
    void saveCustomer(Customer customer);
    void updateCustomer(Customer customer);
    void deleteCustomer(int customerId);
}