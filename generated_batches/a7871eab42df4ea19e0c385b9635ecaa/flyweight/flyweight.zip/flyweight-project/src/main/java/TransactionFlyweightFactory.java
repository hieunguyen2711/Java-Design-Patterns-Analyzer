import java.util.HashMap;
import java.util.Map;

public class TransactionFlyweightFactory {
    private static final Map<String, TransactionFlyweight> flyweights = new HashMap<>();
    
    public static TransactionFlyweight getTransactionFlyweight(TransactionType type) {
        String key = type.name();
        if (!flyweights.containsKey(key)) {
            flyweights.put(key, new TransactionFlyweight(type));
        }
        return flyweights.get(key);
    }
}