import java.time.LocalDateTime;

public class Transaction {
    private CustomerAccount account;
    private double amount;
    private LocalDateTime timestamp;
    private TransactionFlyweight flyweight;
    
    public Transaction(CustomerAccount account, double amount, TransactionType type) {
        this.account = account;
        this.amount = amount;
        this.timestamp = LocalDateTime.now