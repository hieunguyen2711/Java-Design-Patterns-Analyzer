public class TransactionFlyweight {
    private TransactionType type;
    
    public TransactionFlyweight(TransactionType type) {
        this.type = type;
    }
    
    public void execute(CustomerAccount account, double amount) {
        switch (type) {
            case DEPOSIT:
                account.deposit(amount);
                break;
            case WITHDRAWAL:
                account.withdraw(amount);
                break;
            case TRANSFER:
                // Transfer logic would be implemented here
                break;
        }
    }
    
    public TransactionType getType() {
        return type;
    }
}