package com.example.bank;

public class DepositTransaction implements Transaction {
    private final Account account;
    private final double amount;
    
    public DepositTransaction(Account account, double amount) {
        this.account = account;
        this.amount = amount;
    }
    
    @Override
    public void execute() {
        account.deposit(amount);
    }
    
    @Override
    public void rollback() {
        account.withdraw(amount);
    }
}