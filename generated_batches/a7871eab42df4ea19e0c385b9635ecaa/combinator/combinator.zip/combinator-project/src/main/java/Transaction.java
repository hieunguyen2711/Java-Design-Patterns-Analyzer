package com.example.bank;

public interface Transaction {
    void execute();
    void rollback();
}