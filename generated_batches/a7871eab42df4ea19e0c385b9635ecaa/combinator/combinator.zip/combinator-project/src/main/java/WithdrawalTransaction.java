package com.example.bank;

public class WithdrawalTransaction implements Transaction {
    private final Account account;
    private final double amount;
    
    public WithdrawalTransaction(Account account, double amount) {
        this.account = account;
        this.amount = amount;
    }
    
    @Override
    public void execute() {
        account.withdraw(amount);
    }
    
    @Override
    public void rollback() {
        account.deposit(amount);
    }
}