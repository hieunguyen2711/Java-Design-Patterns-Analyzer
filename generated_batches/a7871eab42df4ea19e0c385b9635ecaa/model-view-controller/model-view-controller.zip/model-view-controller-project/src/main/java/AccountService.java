package banking.service;

import banking.model.CustomerAccount;
import banking.model.Transaction;
import java.util.ArrayList;
import java.util.List;

public class AccountService {
    private List<CustomerAccount> accounts;
    private List<Transaction> transactionHistory;

    public AccountService() {
        this.accounts = new ArrayList<>();
        this.transactionHistory = new ArrayList<>();
    }

    public void createAccount(String accountNumber, String customerName, double initialBalance) {
        CustomerAccount account = new CustomerAccount(accountNumber, customerName, initialBalance);
        accounts.add(account);
    }

    public boolean deposit(String accountNumber, double amount) {
        CustomerAccount account = findAccount(accountNumber);
        if (account != null &&