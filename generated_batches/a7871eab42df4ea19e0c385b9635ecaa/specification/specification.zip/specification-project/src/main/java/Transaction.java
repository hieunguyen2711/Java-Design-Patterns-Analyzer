package banking;

public class Transaction {
    private String transactionId;
    private String type;
    private double amount;
    private String fromAccount;
    private String toAccount;
    private long timestamp;
    
    public Transaction(String transactionId, String type, double amount, 
                      String fromAccount, String toAccount) {
        this.transactionId = transactionId;
        this.type = type;
        this.amount = amount;
        this.fromAccount = fromAccount;
        this.toAccount = toAccount;
        this.timestamp = System.currentTimeMillis();
    }
    
    public String getTransactionId() {
        return transactionId;
    }
    
    public String getType() {
        return type;
    }
    
    public double getAmount() {
        return amount;
    }
    
    public String getFromAccount() {
        return fromAccount;
    }
    
    public String getToAccount() {
        return toAccount;
    }
    
    public long getTimestamp() {
        return timestamp;
    }
}