package banking;

public class BankService {
    private TransactionHistory history;
    
    public BankService() {
        this.history = new TransactionHistory();
    }
    
    public void deposit(Account account, double amount) {