package banking;

public abstract class Account {
    protected String accountNumber;
    protected double balance;
    
    public Account(String accountNumber, double initialBalance) {
        this.accountNumber = accountNumber;
        this.balance = initialBalance;
    }
    
    public void deposit(double amount) {
        if (amount > 0) {
            performDeposit(amount);
            updateAuditTrail("DEPOSIT", amount);
        }
    }
    
    public void withdraw(double amount) {
        if (canWithdraw(amount)) {
            performWithdrawal(amount);
            updateAuditTrail("WITHDRAWAL", amount);
        }
    }
    
    protected abstract void performDeposit(double amount);
    protected abstract void performWithdrawal(double amount);
    protected abstract boolean canWithdraw(double amount);
    
    protected void updateAuditTrail(String transactionType, double amount) {
        System.out.println("AUDIT: " + accountNumber + " - " + transactionType + " $" + amount);
    }
    
    public double getBalance() {
        return balance;
    }
}