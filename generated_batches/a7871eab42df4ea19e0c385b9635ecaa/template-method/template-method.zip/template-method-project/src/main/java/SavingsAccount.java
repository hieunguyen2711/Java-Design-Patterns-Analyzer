package banking;

public class SavingsAccount extends Account {
    private static final double MIN_BALANCE = 100.0;
    private static final double INTEREST_RATE = 0.02;
    
    public SavingsAccount(String accountNumber, double initialBalance) {
        super(accountNumber, initialBalance);
    }
    
    @Override
    protected void performDeposit(double amount) {
        balance += amount;
        System.out.println("Savings deposit: $" + amount);
    }
    
    @Override
    protected void performWithdrawal(double amount) {
        balance -= amount;
        System.out.println("Savings withdrawal: $" + amount);
    }
    
    @Override
    protected boolean canWithdraw