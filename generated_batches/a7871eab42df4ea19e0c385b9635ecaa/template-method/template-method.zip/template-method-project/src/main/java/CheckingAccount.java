package banking;

public class CheckingAccount extends Account {
    
    public CheckingAccount(String accountNumber, double initialBalance) {
        super(accountNumber, initialBalance);
    }
    
    @Override
    protected void performDeposit(double amount) {
        balance += amount;
        System.out.println("Checking deposit: $" + amount);
    }
    
    @Override
    protected void performWithdrawal(double amount) {
        balance -= amount;
        System.out.println("Checking withdrawal: $" + amount);
    }
    
    @Override
    protected boolean canWithdraw(double amount) {
        return balance >= amount;
    }
}