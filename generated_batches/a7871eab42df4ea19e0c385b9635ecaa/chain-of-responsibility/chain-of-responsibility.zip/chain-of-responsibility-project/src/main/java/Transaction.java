public class Transaction {
    private String transactionType;
    private double amount;
    private Account account;
    private String description;
    
    public Transaction(String transactionType, double amount, Account account, String description) {
        this.transactionType = transactionType;
        this.amount = amount;
        this.account = account;
        this.description = description;
    }
    
    public String getTransactionType() {
        return transactionType;
    }
    
    public double getAmount() {
        return amount;
    }
    
    public Account getAccount() {
        return account;
    }
    
    public String getDescription() {
        return description;
    }
}