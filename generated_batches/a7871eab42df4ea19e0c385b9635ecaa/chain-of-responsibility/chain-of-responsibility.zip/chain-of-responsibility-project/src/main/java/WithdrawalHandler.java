public class WithdrawalHandler extends TransactionHandler {
    @Override
    public boolean handleTransaction(Transaction transaction) {
        if ("WITHDRAWAL".equals(transaction.getTransactionType())) {
            double currentBalance = transaction.getAccount().getBalance();
            if (currentBalance >= transaction.getAmount()) {
                double newBalance = currentBalance - transaction.getAmount();
                transaction.getAccount().set