public abstract class TransactionHandler {
    protected TransactionHandler nextHandler;
    
    public void setNext(TransactionHandler handler) {
        this.nextHandler = handler;
    }
    
    public abstract boolean handleTransaction(Transaction transaction);
}