public class DepositHandler extends TransactionHandler {
    @Override
    public boolean handleTransaction(Transaction transaction) {
        if ("DEPOSIT".equals(transaction.getTransactionType())) {
            double newBalance = transaction.getAccount().getBalance() + transaction.getAmount();
            transaction.getAccount().setBalance(newBalance);
            System.out.println("Deposit processed: " + transaction.getAmount() + 
                             " to account " + transaction.getAccount().getAccountNumber());
            return true;
        } else if (nextHandler != null) {
            return nextHandler.handleTransaction(transaction);
        }
        return false;
    }
}