package com.example.bank;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class TrampolineProcessor {
    
    public static <T> T trampoline(Function<Trampoline<T>, Trampoline<T>> function, T initial) {
        Trampoline<T> result = new Trampoline<>(initial);
        
        while (result.isContinuation()) {
            result = function.apply(result);
        }
        
        return result.getValue();
    }
    
    public static class Trampoline<T> {
        private final T value;
        private final boolean isContinuation;
        private final Function<Tr