public class SavingsAccount extends Account {
    private double interestRate;
    
    public SavingsAccount(String accountId, double balance, double interestRate) {
        super(accountId, balance);
        this.interestRate = interestRate;
    }
    
    public double getInterestRate() {
        return interestRate;
    }
    
    @Override
    public void accept(AccountVisitor visitor) {
        visitor.visit(this);
    }
}