public interface AccountVisitor {
    void visit(CheckingAccount checkingAccount);
    void visit(SavingsAccount savingsAccount);
}