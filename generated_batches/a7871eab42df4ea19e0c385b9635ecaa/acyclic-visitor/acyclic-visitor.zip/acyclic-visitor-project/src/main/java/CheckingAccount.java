public class CheckingAccount extends Account {
    private double overdraftLimit;
    
    public CheckingAccount(String accountId, double balance, double overdraftLimit) {
        super(accountId, balance);
        this.overdraftLimit = overdraftLimit;
    }
    
    public double getOverdraftLimit() {
        return overdraftLimit;
    }
    
    @Override
    public void accept(AccountVisitor visitor) {
        visitor.visit(this);
    }
}