public class StatementGenerator implements AccountVisitor {
    private StringBuilder statement = new StringBuilder();
    
    @Override
    public void visit(CheckingAccount checkingAccount) {
        statement.append("Checking Account ").append(checkingAccount.getAccountId())
                 .append(": Balance $").append(String.format("%.2f", checkingAccount.getBalance()))
                 .append(", Overdraft Limit $").append(String.format("%.2f", checkingAccount.getOverdraftLimit()))
                 .append("\n");
    }
    
    @Override
    public void visit(SavingsAccount savingsAccount) {
        statement.append("Savings Account ").append(savingsAccount.getAccountId())
                 .append(": Balance $").append(String.format("%.2f", savingsAccount.getBalance()))
                 .append(", Interest Rate ").append(String.format("%.2f", savingsAccount.getInterestRate() * 100)).append