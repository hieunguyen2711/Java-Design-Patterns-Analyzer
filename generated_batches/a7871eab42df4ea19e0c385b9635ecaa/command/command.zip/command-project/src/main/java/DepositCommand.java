public class DepositCommand implements Command {
    private Account account;
    private double amount;
    private boolean executed;

    public DepositCommand(Account account, double amount) {
        this.account = account;
        this.amount = amount;
        this.executed = false;
    }

    @Override
    public void execute() {
        if (!executed) {
            account.deposit(amount);
            executed = true;
        }
    }

    @Override
    public void undo() {
        if (executed) {
            account.withdraw(amount);
            executed = false;
        }
    }
}