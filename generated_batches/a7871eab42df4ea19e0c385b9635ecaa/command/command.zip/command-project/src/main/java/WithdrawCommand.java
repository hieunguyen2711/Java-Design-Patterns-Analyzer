public class WithdrawCommand implements Command {
    private Account account;
    private double amount;
    private boolean executed;

    public WithdrawCommand(Account account, double amount) {
        this.account = account;
        this.amount = amount;
        this.executed = false;
    }

    @Override
    public void execute() {
        if (!executed) {
            if (account.withdraw(amount)) {
                executed = true;
            }
        }
    }

    @Override
    public void undo() {
        if (executed) {
            account.deposit(amount);
            executed = false;
        }
    }
}