public class TransferCommand implements Command {
    private Account fromAccount;
    private Account toAccount;
    private double amount;
    private boolean executed;

    public TransferCommand(Account fromAccount, Account toAccount, double amount) {
        this.fromAccount = fromAccount;
        this.toAccount = toAccount;
        this.amount = amount;
        this.executed = false;
    }

    @