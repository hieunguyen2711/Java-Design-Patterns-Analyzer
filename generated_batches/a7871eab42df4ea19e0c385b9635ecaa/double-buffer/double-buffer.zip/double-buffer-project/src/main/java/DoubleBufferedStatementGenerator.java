package banking;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

public class DoubleBufferedStatementGenerator {
    private final ReentrantLock lock = new ReentrantLock();
    
    // Double buffering - two buffers for concurrent access
    private volatile List<Transaction> currentBuffer = new ArrayList<>();
    private volatile List<Transaction> nextBuffer = new ArrayList<>();
    
    public void addTransaction(Transaction transaction) {
        lock.lock();
        try {
            nextBuffer.add(transaction);
        } finally {
            lock.unlock();
        }
    }
    
    // Double buffer swap - atomic operation
    public