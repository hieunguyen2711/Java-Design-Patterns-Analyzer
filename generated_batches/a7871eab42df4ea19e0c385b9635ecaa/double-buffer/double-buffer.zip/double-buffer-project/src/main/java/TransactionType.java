package banking;

public enum TransactionType {
    DEPOSIT,
    WITHDRAWAL,
    TRANSFER
}