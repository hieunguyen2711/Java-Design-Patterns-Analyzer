package com.example.bank;

public class Transaction {
    private String transactionId;
    private String accountId;
    private String type;
    private double amount;
    private String timestamp;
    
    public Transaction(String transactionId, String accountId, String type, double amount, String timestamp) {
        this.transactionId = transactionId;
        this.accountId = accountId;
        this.type = type;
        this.amount = amount;
        this.timestamp = timestamp;
    }
    
    // Getters and setters
    public String getTransactionId() { return transactionId; }
    public void setTransactionId(String transactionId) { this.transactionId = transactionId; }