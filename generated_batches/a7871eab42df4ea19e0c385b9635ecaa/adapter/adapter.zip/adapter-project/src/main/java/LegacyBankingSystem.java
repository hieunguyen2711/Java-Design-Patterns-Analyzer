package banking;

public class LegacyBankingSystem {
    public void processDeposit(String accountNumber, double amount) {
        System.out.println("Legacy system deposit: " + amount + " to account " + accountNumber);
    }
    
    public boolean processWithdrawal(String accountNumber, double amount) {
        System.out.println("Legacy system withdrawal: " + amount + " from account " + accountNumber);
        return true;
    }
}