package banking;

public interface BankingSystem {
    void deposit(String accountNumber, double amount);
    boolean withdraw(String accountNumber, double amount);
    double getBalance(String accountNumber);
    void transfer(String fromAccount, String toAccount, double amount);
    void generateStatement(String accountNumber);
}