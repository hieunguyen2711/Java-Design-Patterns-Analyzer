package banking;

public class ModernBankingSystem implements Banking