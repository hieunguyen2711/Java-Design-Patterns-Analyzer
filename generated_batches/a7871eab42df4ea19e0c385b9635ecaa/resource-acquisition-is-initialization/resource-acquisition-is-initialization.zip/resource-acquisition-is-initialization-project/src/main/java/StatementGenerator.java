package banking;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class StatementGenerator {
    private static final DateTimeFormatter DATE_FORMATTER = 
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    
    public String generateStatement(Account account) {
        StringBuilder statement = new StringBuilder();
        statement.append("Account Statement for