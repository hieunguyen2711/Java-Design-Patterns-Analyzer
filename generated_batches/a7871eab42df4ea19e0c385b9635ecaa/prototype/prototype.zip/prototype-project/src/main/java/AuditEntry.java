package com.bank.account;

import java.time.LocalDateTime;

public class AuditEntry {
    private String action;
    private LocalDateTime timestamp;
    
    public AuditEntry(String