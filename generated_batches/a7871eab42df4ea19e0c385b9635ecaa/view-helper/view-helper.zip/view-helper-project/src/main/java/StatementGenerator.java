package com.example.bank;

import java.util.List;
import java.util.ArrayList;

public class StatementGenerator {
    private List<Transaction> transactions;
    
    public StatementGenerator() {
        this.transactions = new ArrayList<>();
    }
    
    public void addTransaction(Transaction transaction) {
        transactions.add(transaction);
    }
    
    public String generateStatement(String accountId, CustomerAccount account) {
        StringBuilder statement =