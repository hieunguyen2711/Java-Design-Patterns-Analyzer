package banking;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class StatementGenerator implements Observer {
    private StringBuilder statement;

    public StatementGenerator() {
        this.statement = new StringBuilder();
    }

    @Override
    public void update(Account account, String transactionType, double amount) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String timestamp = LocalDateTime.now().format(formatter);
        
        statement.append(String.format("[%s] Account %s: %s of $%.2f\n", 
            timestamp, account.getAccountNumber(), transactionType, amount));
    }

    public String getStatement() {
        return statement.toString();
    }
}