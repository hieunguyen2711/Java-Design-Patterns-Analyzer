package banking;

public class AuditLogger implements Observer {
    private StringBuilder auditLog;

    public AuditLogger() {
        this.auditLog = new StringBuilder();
    }

    @Override
    public void update(Account account, String transactionType, double amount) {