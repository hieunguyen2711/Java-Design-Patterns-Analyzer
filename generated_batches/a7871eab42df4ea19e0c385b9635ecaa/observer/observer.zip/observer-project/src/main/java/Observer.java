package banking;

public interface Observer {
    void update(Account account, String transactionType, double amount);
}