package banking;

import java.util.ArrayList;
import java.util.List;

public class Account {
    private String accountNumber;
    private double balance;
    private List<Observer> observers;

    public Account(String accountNumber, double initialBalance) {
        this.accountNumber = accountNumber;
        this.balance = initialBalance;
        this.observers = new ArrayList<>();
    }

    public void addObserver(Observer observer) {
        observers.add(observer);
    }

    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            notifyObservers("Deposit", amount);
        }
    }

    public boolean withdraw(double amount) {
        if (amount > 0 && balance >= amount) {
            balance -= amount;
            notifyObservers("Withdrawal", amount);
            return true;
        }
        return false;
    }

    private void notifyObservers(String transactionType, double amount) {
        for (Observer observer : observers) {
            observer.update(this, transactionType, amount);
        }
    }

    public double getBalance() {
        return balance;
    }

    public String getAccountNumber() {
        return accountNumber;
    }
}