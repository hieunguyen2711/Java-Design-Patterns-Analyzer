package com.bank.account;

public class Transaction {
    private String transactionId;
    private String fromAccountId;
    private String toAccountId;
    private double amount;
    private String type;
    
    public Transaction(String transactionId, String fromAccountId, String toAccountId, 
                      double amount, String type) {
        this.transactionId = transactionId;
        this.fromAccountId = fromAccountId;
        this.toAccountId = toAccountId;