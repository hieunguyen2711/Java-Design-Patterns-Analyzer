package com.bank.account;

import java.util.concurrent.ConcurrentLinkedQueue;

public class AccountPool {
    private static AccountPool instance;
    private ConcurrentLinkedQueue<CustomerAccount> pool;
    private int maxPoolSize;
    
    private AccountPool(int maxSize) {
        this.maxPoolSize = maxSize;
        this.pool = new ConcurrentLinkedQueue<>();
        initializePool();
    }
    
    public static synchronized AccountPool getInstance(int maxSize) {
        if (instance == null) {
            instance = new AccountPool(maxSize);
        }
        return instance;
    }
    
    private void initializePool() {
        for (int i = 0; i < maxPoolSize; i++) {
            pool.offer(new CustomerAccount("ACC-" + i, 0.0));
        }
    }
    
    public CustomerAccount acquireAccount() {
        CustomerAccount account = pool.poll();
        if (account == null) {
            return new CustomerAccount("ACC-DYNAMIC-" + System.currentTimeMillis(), 0.0);
        }
        return account;
    }
    
    public void releaseAccount(CustomerAccount account) {
        if (pool.size() < maxPoolSize) {
            // Reset account state
            account = new CustomerAccount(account.getAccountId(), 0.0);
            pool.offer(account);
        }
    }
}