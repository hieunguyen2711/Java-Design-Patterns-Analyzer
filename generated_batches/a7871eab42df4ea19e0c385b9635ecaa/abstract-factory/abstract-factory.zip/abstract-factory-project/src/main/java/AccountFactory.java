public interface AccountFactory {
    Account createAccount(String accountNumber, double initialBalance);
}