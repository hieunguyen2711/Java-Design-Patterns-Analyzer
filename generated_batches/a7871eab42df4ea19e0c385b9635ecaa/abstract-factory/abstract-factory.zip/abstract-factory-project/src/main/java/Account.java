public interface Account {
    String getAccountNumber();
    double getBalance();
    void deposit(double amount);
    boolean withdraw(double amount);
    void transfer(Account targetAccount, double amount);
}