package banking;

public class Account {
    private final String accountId;
    private double balance;
    private final Customer customer;
    
    public Account(String accountId, double initialBalance, Customer customer) {
        this.accountId = accountId;
        this.balance = initialBalance;
        this.customer = customer;
    }
    
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
        }
    }
    
    public boolean withdraw(double amount) {
        if (amount > 0 && balance >= amount) {
            balance -= amount;
            return true;
        }
        return false;
    }
    
    public double getBalance() {
        return balance;
    }
    
    public String getAccountId() {
        return accountId;
    }
    
    public Customer getCustomer() {
        return customer;
    }
}