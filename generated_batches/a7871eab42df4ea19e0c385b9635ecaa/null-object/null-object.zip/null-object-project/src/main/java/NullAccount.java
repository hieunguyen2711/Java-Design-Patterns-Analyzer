package banking;

public class NullAccount extends Account {
    private static final NullAccount INSTANCE = new NullAccount();
    
    private NullAccount() {
        super("NULL", 0.0, null);
    }
    
    public static NullAccount getInstance() {
        return INSTANCE;
    }
    
    @Override
    public void deposit(double amount) {
        // No operation - null object pattern
    }
    
    @Override
    public boolean withdraw(double amount) {
        return false;
    }
    
    @Override
    public double getBalance() {
        return 0.0;
    }
    
    @Override
    public Customer getCustomer() {
        return null;
    }
}