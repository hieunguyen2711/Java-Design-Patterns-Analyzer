package banking;

public class AccountService {
    
    public Account findAccount(String accountId) {
        // Simulate account lookup - in real app this would query a database
        if (accountId == null || accountId.isEmpty()) {
            return NullAccount.getInstance();
        }
        
        // Return actual account for valid IDs
        if ("ACC001".equals(accountId)) {
            return new Account("ACC0