package banking;

import java.util.ArrayList;
import java.util.List;

public class BankService {
    private List<Account> accounts;
    private List<Transaction> transactions;
    
    public BankService() {
        this.accounts = new ArrayList<>();
        this.transactions = new ArrayList<>();
    }
    
    public void createAccount(String accountId, double initialBalance) {
        accounts.add(new Account(accountId, initialBalance));
    }
    
    public boolean deposit(String accountId, double amount) {
        Account account = findAccount(accountId);
        if (account != null && amount > 0) {
            account.deposit(amount);
            transactions.add(new Transaction("TXN" + System.currentTimeMillis(), "DEPOSIT", amount, accountId));
            return true;
        }