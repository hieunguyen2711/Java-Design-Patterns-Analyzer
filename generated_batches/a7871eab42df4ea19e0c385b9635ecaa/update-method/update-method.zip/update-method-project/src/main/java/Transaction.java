package banking;

public class Transaction {
    private String transactionId;
    private String type;
    private double amount;
    private String accountId;
    private long timestamp;
    
    public Transaction(String transactionId, String type, double amount, String accountId) {
        this.transactionId = transactionId;
        this.type = type;
        this.amount = amount;
        this.accountId = accountId;
        this.timestamp = System.currentTimeMillis();
    }
    
    public void updateAmount(double newAmount) {
        this.amount = newAmount;
    }
    
    public void updateType(String newType) {
        this.type = newType;
    }
    
    // Getters
    public String getTransactionId() { return transactionId; }
    public String getType() { return type; }
    public double getAmount() { return amount; }
    public String getAccountId() { return accountId; }
    public long getTimestamp() { return timestamp; }
}