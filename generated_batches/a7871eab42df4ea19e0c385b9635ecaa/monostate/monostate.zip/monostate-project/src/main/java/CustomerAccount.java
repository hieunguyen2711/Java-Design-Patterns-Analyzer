package com.example.bank;

public class CustomerAccount {
    private String accountNumber;
    private double balance;
    
    public CustomerAccount(String accountNumber) {
        this.accountNumber = accountNumber;
        this.balance = 0.0;
    }
    
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            AuditLogger.getInstance().log("Deposit: " + amount + " to account " + accountNumber);
        }
    }
    
    public boolean withdraw(double amount) {
        if (amount > 0 && balance >= amount) {
            balance -= amount;
            AuditLogger.getInstance().log("Withdrawal: " + amount + " from account " + accountNumber);
            return true;
        }
        return false;
    }
    
    public double getBalance() {
        return balance;
    }
    
    public String getAccountNumber() {
        return accountNumber;
    }
}