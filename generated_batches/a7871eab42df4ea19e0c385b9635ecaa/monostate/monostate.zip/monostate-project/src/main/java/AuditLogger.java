package com.example.bank;

import java.util.ArrayList;
import java.util.List;

public class AuditLogger {
    private static AuditLogger instance;
    private List<String> auditLog;
    
    // Private constructor to prevent instantiation
    private AuditLogger() {
        this.auditLog = new ArrayList<>();
    }
    
    // Static method to get the single instance
    public static synchronized AuditLogger getInstance() {
        if (instance == null) {
            instance = new AuditLogger();
        }
        return instance;
    }
    
    public void log(String message) {
        auditLog.add(message);
    }
    
    public List<String> getAuditLog() {
        return new ArrayList<>(auditLog); // Return copy to maintain encapsulation
    }
}