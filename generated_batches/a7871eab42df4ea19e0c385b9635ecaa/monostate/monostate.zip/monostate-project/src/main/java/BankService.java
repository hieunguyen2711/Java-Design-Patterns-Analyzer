package com.example.bank;

public class BankService {
    private CustomerAccount account1;
    private CustomerAccount account2;
    
    public BankService() {
        this.account1 = new CustomerAccount("ACC001");
        this.account2 = new CustomerAccount("ACC002");
    }
    
    public void transfer(String fromAccount, String toAccount, double amount) {
        if (fromAccount.equals(account1.getAccountNumber()) && 
            toAccount.equals(account2.getAccountNumber())) {
            if (account1.withdraw(amount)) {
                account2.deposit(amount);
                AuditLogger.getInstance().log("Transfer: " + amount + 
                    " from "