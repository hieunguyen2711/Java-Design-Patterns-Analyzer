package com.example.bank;

import java.util.HashMap;
import java.util.Map;

public class CustomerRepository {
    private static final Map<String, Customer> customerCache = new HashMap<>();
    
    public static Customer findById(String customerId) {
        return customerCache.get(customerId);
    }
    
    public static void save(Customer customer) {
        customerCache.put(customer.getCustomerId(), customer);
    }
    
    public static void clearCache() {
        customerCache.clear();
    }
}