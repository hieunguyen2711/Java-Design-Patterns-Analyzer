package com.example.bank;

public class BankApplication {
    public static void main(String[] args) {