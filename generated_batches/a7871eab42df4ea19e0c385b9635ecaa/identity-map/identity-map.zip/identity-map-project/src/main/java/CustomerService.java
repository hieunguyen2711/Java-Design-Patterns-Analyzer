package com.example.bank;

public class CustomerService {
    
    public Customer getCustomer(String customerId) {
        // Check if customer is already loaded
        Customer existingCustomer = CustomerRepository.findById(customerId);
        
        if (existingCustomer != null) {
            return existingCustomer;
        }
        
        // Simulate loading from database
        Customer newCustomer = createCustomerFromDatabase(customerId);
        CustomerRepository.save(newCustomer);
        
        return newCustomer;
    }
    
    private Customer createCustomerFromDatabase(String customerId) {
        // In a real application, this would query a database
        return new Customer(customerId, "John Doe", "john.doe@example.com");
    }
}