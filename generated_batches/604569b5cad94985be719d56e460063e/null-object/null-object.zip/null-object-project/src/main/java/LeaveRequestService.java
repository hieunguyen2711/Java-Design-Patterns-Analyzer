package hr.system;

public class LeaveRequestService {
    
    public LeaveRequest findLeaveRequest(String employeeId) {
        // Simulate database lookup
        if ("EMP001".equals(employeeId)) {
            return new LeaveRequest(new Employee("EMP001", "John Doe", 50000.0), 5, true);
        }
        return NullLeaveRequest.getInstance();
    }
}