package hr.system;

public class NullLeaveRequest extends LeaveRequest {
    private static final NullLeaveRequest INSTANCE = new NullLeaveRequest();
    
    private NullLeaveRequest() {
        super(new Employee("NULL", "Unknown", 0.0), 0, false);
    }
    
    public static NullLeaveRequest getInstance() {
        return INSTANCE;
    }
    
    @Override
    public boolean isApproved() {
        return false;
    }
    
    @Override
    public int getDaysRequested() {
        return 0;
    }
}