package hr.system;

public class PayrollCalculator {
    
    public double calculateNetSalary(Employee employee, LeaveRequest leaveRequest) {
        if (employee == null ||