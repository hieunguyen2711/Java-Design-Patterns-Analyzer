package hr.system;

public class LeaveRequest {
    private final Employee employee;
    private final int daysRequested;
    private final boolean approved;
    
    public LeaveRequest(Employee employee, int daysRequested, boolean approved) {
        this.employee = employee;
        this.daysRequested = daysRequested;
        this.approved = approved;
    }
    
    public Employee getEmployee() {
        return employee;
    }
    
    public int getDaysRequested() {
        return daysRequested;
    }
    
    public boolean isApproved() {
        return approved;
    }
}