public class FullTimeEmployee extends Employee {
    private static final double BONUS_PERCENTAGE = 0.1;
    
    public FullTimeEmployee(String name, String employeeId, double baseSalary) {
        super(name, employeeId, baseSalary);
    }
    
    @Override
    public double calculateSalary() {
        return baseSalary + (baseSalary * BONUS_PERCENTAGE);
    }
    
    @Override
    public String getEmployeeType() {
        return "FullTime";
    }
}