public class PartTimeEmployeeFactory extends EmployeeFactory {
    @Override
    public Employee createEmployee(String name, String employeeId, double baseSalary) {
        return new PartTimeEmployee(name,