public abstract class EmployeeFactory {
    public abstract Employee createEmployee(String name, String employeeId, double baseSalary);
}