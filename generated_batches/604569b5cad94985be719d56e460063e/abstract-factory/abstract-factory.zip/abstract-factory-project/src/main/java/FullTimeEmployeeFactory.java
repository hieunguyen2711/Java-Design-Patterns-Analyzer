public class FullTimeEmployeeFactory extends EmployeeFactory {
    @Override
    public Employee createEmployee(String name, String employeeId, double baseSalary) {
        return new FullTimeEmployee(name, employeeId, baseSalary);
    }
}