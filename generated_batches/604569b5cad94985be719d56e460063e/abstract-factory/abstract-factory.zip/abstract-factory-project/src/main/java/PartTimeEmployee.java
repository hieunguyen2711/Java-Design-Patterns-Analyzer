public class PartTimeEmployee extends Employee {
    private static final double OVERTIME_MULTIPLIER = 1.5;
    
    public PartTimeEmployee(String name, String employeeId, double baseSalary) {
        super(name, employeeId, baseSalary);
    }
    
    @Override
    public double calculateSalary() {
        return baseSalary * OVERTIME_MULTIPLIER;
    }
    
    @Override
    public String getEmployeeType() {
        return "PartTime";
    }
}