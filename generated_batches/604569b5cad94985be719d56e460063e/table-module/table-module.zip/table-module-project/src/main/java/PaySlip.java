package hr.system;

public class PaySlip {
    private String employeeId;
    private double grossSalary;
    private double taxDeduction;
    private double netSalary;
    
    public PaySlip(String employeeId, double grossSalary, double taxDeduction, double netSalary) {
        this.employeeId = employeeId;
        this.grossSalary =