package hr.system;

public class SalaryCalculator {
    private static final double TAX_RATE = 0.2;
    
    public double calculateNetSalary(Employee employee, double bonus) {
        double grossSalary = employee.getBaseSalary() + bonus;
        return grossSalary - (grossSalary * TAX_RATE);
    }
}