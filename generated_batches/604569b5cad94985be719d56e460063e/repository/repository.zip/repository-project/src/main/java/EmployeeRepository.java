package com.example.hr;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public interface EmployeeRepository {
    Optional<Employee> findById(int id);
    List<Employee> findAll();
    Employee save(Employee employee);
    void deleteById(int id);
}