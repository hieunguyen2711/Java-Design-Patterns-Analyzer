package com.example.hr;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class InMemoryEmployeeRepository implements EmployeeRepository {
    private final ConcurrentHashMap<Integer, Employee> employees = new ConcurrentHashMap<>();
    private final AtomicInteger idGenerator = new AtomicInteger(1);

    @Override
    public Optional<Employee> findById(int id) {
        return Optional.ofNullable(employees.get(id));
    }

    @Override
    public List<Employee> findAll() {
        return new ArrayList<>(employees.values());
    }

    @Override
    public Employee save(Employee employee) {
        if (employee.getId() == 0) {
            employee.setId(idGenerator.getAndIncrement());
        }
        employees.put(employee.getId(), employee);
        return employee;
    }

    @Override
    public void deleteById(int id) {
        employees.remove(id);
    }
}