package hr.system;

public interface PaymentStrategy {
    double calculatePayment(double baseSalary);
}