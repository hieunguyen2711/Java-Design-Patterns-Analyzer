package hr.system;

public class FixedSalaryStrategy implements PaymentStrategy {
    @Override
    public double calculatePayment(double baseSalary) {
        return baseSalary;
    }
}