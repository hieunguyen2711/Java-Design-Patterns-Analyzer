package hr.system;

public class Employee {
    private String name;
    private double baseSalary;
    private PaymentStrategy paymentStrategy;
    
    public Employee(String name, double baseSalary) {
        this.name = name;
        this.baseSalary = baseSalary;
    }
    
    public void setPaymentStrategy(PaymentStrategy strategy) {
        this.paymentStrategy = strategy;
    }
    
    public double calculatePay() {
        if (paymentStrategy != null) {
            return paymentStrategy.calculatePayment(baseSalary);
        }
        return baseSalary;
    }
    
    public String getName() {
        return name;
    }
    
    public double getBaseSalary() {
        return baseSalary;
    }
}