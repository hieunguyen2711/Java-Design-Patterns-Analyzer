package hr.system;

public class CommissionSalaryStrategy implements PaymentStrategy {
    private double commissionRate;
    
    public CommissionSalaryStrategy(double commissionRate) {
        this.commissionRate = commissionRate;
    }
    
    @Override
    public double calculatePayment(double baseSalary) {
        return baseSalary + (baseSalary * commissionRate);
    }
}