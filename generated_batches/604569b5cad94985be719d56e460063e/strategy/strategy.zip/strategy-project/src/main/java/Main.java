package hr.system;

public class Main {
    public static void main(String[] args) {
        Employee employee1 = new Employee("John Doe", 5000.0);
        Employee employee2 = new Employee("Jane Smith", 5000.0);
        Employee employee3 = new Employee("Bob Johnson", 5000.0);
        
        // Fixed salary strategy
        employee1.setPaymentStrategy(new FixedSalaryStrategy());
        
        // Commission based strategy
        employee2.setPaymentStrategy(new Commission