package hr.system;

public class BonusSalaryStrategy implements PaymentStrategy {
    private double bonusAmount;
    
    public BonusSalaryStrategy(double bonusAmount) {
        this.bonusAmount = bonusAmount;
    }
    
    @Override
    public double calculatePayment(double baseSalary) {
        return baseSalary + bonusAmount;
    }
}