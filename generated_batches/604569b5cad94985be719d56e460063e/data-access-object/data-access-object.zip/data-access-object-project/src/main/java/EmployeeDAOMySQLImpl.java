package hr.system.dao.impl;

import hr.system.model.Employee;
import hr.system.dao.EmployeeDAO;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDAOMySQLImpl implements EmployeeDAO {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/hrdb";
    private static final String USERNAME = "user";
    private static final String PASSWORD = "password";
    
    @Override
    public void save(Employee employee) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(
                 "INSERT INTO employees (name, email, salary) VALUES (?, ?, ?)")) {
            
            stmt.setString(1, employee.getName());
            stmt.setString(2, employee.getEmail());
            stmt.setDouble(3, employee.getSalary());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error saving employee", e);
        }
    }
    
    @Override
    public Employee findById(int id) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement("SELECT *