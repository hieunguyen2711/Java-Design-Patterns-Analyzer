package hr.system;

public interface SalaryCalculator {
    double calculateSalary(Employee employee);
}