package hr.system;

public class PayrollSystem {
    public static void main(String[] args) {
        Employee employee = new Employee("John Doe", 5000.0);
        
        SalaryCalculator calculator = new BasicSalaryCalculator();
        calculator