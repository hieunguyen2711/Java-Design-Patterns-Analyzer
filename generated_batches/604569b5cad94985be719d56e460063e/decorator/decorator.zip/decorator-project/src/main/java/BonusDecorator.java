package hr.system;

public class BonusDecorator extends SalaryDecorator {
    private double bonusAmount;
    
    public BonusDecorator(SalaryCalculator decoratedCalculator, double bonusAmount) {
        super(decoratedCalculator);
        this.bonusAmount = bonusAmount;
    }
    
    @Override
    public double calculateSalary(Employee employee) {
        return super.calculateSalary(employee) + bonusAmount;
    }
}