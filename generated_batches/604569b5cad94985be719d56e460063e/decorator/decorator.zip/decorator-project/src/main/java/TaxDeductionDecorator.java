package hr.system;

public class TaxDeductionDecorator extends SalaryDecorator {
    private double taxRate;
    
    public TaxDeductionDecorator(SalaryCalculator decoratedCalculator, double taxRate) {
        super(decoratedCalculator);
        this.taxRate = taxRate;
    }
    
    @Override
    public double calculateSalary(Employee employee) {
        double baseSalary = super.calculateSalary(employee);
        return baseSalary - (baseSalary * taxRate);
    }
}