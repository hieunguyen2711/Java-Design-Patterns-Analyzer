package hr.system;

public abstract class SalaryDecorator implements SalaryCalculator {
    protected SalaryCalculator decoratedCalculator;
    
    public SalaryDecorator(SalaryCalculator decoratedCalculator) {
        this.decoratedCalculator = decoratedCalculator;
    }
    
    @Override
    public double calculateSalary(Employee employee) {
        return decoratedCalculator.calculateSalary(employee);
    }
}