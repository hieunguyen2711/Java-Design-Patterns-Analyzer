package hr.system;

public class PaySlipGenerator implements PayrollObserver {
    private Pay