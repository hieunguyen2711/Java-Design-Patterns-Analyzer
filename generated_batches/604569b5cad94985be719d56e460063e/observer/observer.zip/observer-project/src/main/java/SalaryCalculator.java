package hr.system;

public class SalaryCalculator implements PayrollObserver {
    private PayrollSubject subject;
    
    public SalaryCalculator(PayrollSubject subject) {
        this.subject = subject;
        this.subject.attach(this);
    }
    
    @Override
    public void update(Employee employee, double newSalary) {
        System.out.println("Salary calculator notified: " + 
                          employee.getName() + "'s salary updated to $" + newSalary);
        
        // Calculate tax and net pay
        double tax = newSalary * 0.2;
        double netPay = newSalary - tax;
        
        System.out.println("Tax deduction: $" + tax);
        System.out.println("Net pay: $" + netPay);
    }
}