package hr.system;

public interface PayrollObserver {
    void update(Employee employee, double newSalary);
}