package hr.system;

import java.util.ArrayList;
import java.util.List;

public class PayrollSubject {
    private List<PayrollObserver> observers = new ArrayList<>();
    
    public void attach(PayrollObserver observer) {
        observers.add(observer);
    }
    
    public void detach(PayrollObserver observer) {
        observers.remove(observer);
    }
    
    public void notifyObservers(Employee employee, double newSalary) {
        for (PayrollObserver observer : observers) {
            observer.update(employee, newSalary);
        }
    }
}