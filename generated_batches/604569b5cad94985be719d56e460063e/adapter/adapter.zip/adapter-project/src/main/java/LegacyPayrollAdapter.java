package hr.system;

public class LegacyPayrollAdapter implements SalaryCalculator {
    private LegacyPayrollSystem legacySystem;
    
    public LegacyPayrollAdapter() {
        this.legacySystem = new LegacyPayrollSystem();
    }
    
    @Override
    public double calculateNetSalary(Employee employee) {
        double grossSalary = legacySystem.calculateGrossSalary(employee.getId(), employee.getBaseSalary());
        double tax = legacySystem.calculateTax(grossSalary);
        return grossSalary - tax;
    }
}