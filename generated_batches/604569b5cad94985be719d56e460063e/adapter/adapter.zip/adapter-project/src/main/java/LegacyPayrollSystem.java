package hr.system;

public class LegacyPayrollSystem {
    public double calculateGrossSalary(String employeeId, double baseSalary) {
        // Simulate legacy system calculation with fixed multipliers
        return baseSalary * 1.2;
    }
    
    public double calculateTax(double grossSalary) {
        // Simulate legacy tax calculation
        return grossSalary * 0.25;
    }
}