package hr.system;

public class PayrollService {
    private SalaryCalculator salaryCalculator;
    
    public PayrollService(SalaryCalculator calculator) {
        this.salaryCalculator = calculator;
    }
    
    public double calculateEmployeeNetSalary(Employee employee) {
        return salaryCalculator.calculateNetSalary(employee);
    }
}