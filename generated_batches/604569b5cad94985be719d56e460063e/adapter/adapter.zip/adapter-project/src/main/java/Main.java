package hr.system;

public class Main {
    public static void main(String[] args) {
        Employee emp = new Employee("E001", "John Doe", 5000.0);
        
        PayrollService service = new PayrollService(new LegacyPayrollAdapter());
        double netSalary = service.calculateEmployeeNet