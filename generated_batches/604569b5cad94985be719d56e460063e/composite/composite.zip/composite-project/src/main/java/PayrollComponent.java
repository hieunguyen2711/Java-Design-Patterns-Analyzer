package hr.system;

public interface PayrollComponent {
    double calculateSalary();
    void add(PayrollComponent component);
    void remove(PayrollComponent component);
    String getName();
}