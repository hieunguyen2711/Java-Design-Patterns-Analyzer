package hr.system;

public class Employee implements PayrollComponent {
    private String name;
    private double baseSalary;
    
    public Employee(String name, double baseSalary) {
        this.name = name;
        this.baseSalary = baseSalary;
    }
    
    @Override
    public double calculateSalary() {
        return baseSalary;
    }
    
    @Override
    public void add(PayrollComponent component) {
        throw new UnsupportedOperationException("Cannot add components to individual employee");
    }
    
    @Override
    public void remove(PayrollComponent component) {
        throw new UnsupportedOperationException("Cannot remove components from individual employee");
    }
    
    @Override
    public String getName() {
        return name;
    }
}