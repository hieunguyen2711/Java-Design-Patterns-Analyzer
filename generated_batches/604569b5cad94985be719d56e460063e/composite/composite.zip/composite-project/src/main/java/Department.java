package hr.system;

import java.util.ArrayList;
import java.util.List;

public class Department implements PayrollComponent {
    private String name;
    private List<PayrollComponent> components;
    
    public Department(String name) {
        this.name = name;
        this.components = new ArrayList<>();
    }
    
    @Override
    public double calculateSalary() {
        return components.stream()
                .mapToDouble(PayrollComponent::calculateSalary)
                .sum();
    }
    
    @Override
    public void add(PayrollComponent component) {
        components.add(component);
    }
    
    @Override
    public void remove(PayrollComponent component) {
        components.remove(component);
    }
    
    @Override
    public String getName() {
        return name;
    }
}