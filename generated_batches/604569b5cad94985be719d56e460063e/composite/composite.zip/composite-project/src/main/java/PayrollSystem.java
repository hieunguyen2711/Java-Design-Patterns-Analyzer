package hr.system;

public class PayrollSystem {
    public static void main(String[] args) {
        // Create individual employees
        Employee emp1 = new Employee("John Doe", 50000);
        Employee emp2 = new Employee("Jane Smith", 60000);
        Employee emp3 = new Employee("Bob Johnson", 55000);
        
        // Create departments and add employees
        Department engineering = new Department("Engineering");
        engineering.add(emp1);
        engineering.add(emp2);
        
        Department marketing = new Department("Marketing