package hr.system;

public class Employee {
    private String name;
    private double baseSalary;
    private boolean dirtyFlag = false;
    
    public Employee(String name, double baseSalary) {
        this.name = name;
        this.baseSalary = baseSalary;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
        setDirty(true);
    }
    
    public double getBaseSalary() {
        return baseSalary;
    }
    
    public void setBaseSalary(double baseSalary) {
        this.baseSalary = baseSalary;
        setDirty(true);
    }
    
    public boolean isDirty() {
        return dirtyFlag;
    }
    
    private void setDirty(boolean dirty) {
        this.dirtyFlag = dirty;
    }
    
    public void clearDirtyFlag() {
        this.dirtyFlag = false;
    }
}