package hr.system;

public class PayrollService {
    private Employee employee;
    
    public PayrollService(Employee employee) {
        this.employee = employee;
    }
    
    public double calculateNetSalary() {
        if (employee.isDirty()) {
            System.out.println("Employee data has changed, recalculating...");
            // In a real system, this would trigger expensive calculations
            employee.clearDirtyFlag();
        }
        
        // Simulate complex salary calculation
        double tax = employee.getBaseSalary() * 0.2;
        return employee.getBaseSalary() - tax;
    }
}