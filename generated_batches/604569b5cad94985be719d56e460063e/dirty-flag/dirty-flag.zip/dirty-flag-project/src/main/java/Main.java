package hr.system;

public class Main {
    public static void main(String[] args) {
        Employee emp = new Employee("John Doe", 50000);
        PayrollService payroll = new PayrollService(emp);
        
        // First calculation - should trigger recalculation
        System.out.println("Net Salary: " + payroll.calculateNetSalary());
        
        // Modify employee data
        emp.setBaseSalary(55000);
        
        // Second calculation - should detect dirty flag and recalculate
        System.out.println("Net Salary: " + payroll.calculateNetSalary());
    }
}