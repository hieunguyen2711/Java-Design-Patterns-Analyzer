package hr.system;

public interface PayrollConverter {
    double convertToAnnualSalary(double monthlySalary);
    double convertToMonthlySalary(double annualSalary);
    double calculateTax(double salary);
}