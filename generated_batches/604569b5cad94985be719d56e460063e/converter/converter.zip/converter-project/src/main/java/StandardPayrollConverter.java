package hr.system;

public class StandardPayrollConverter implements PayrollConverter {
    
    @Override
    public double convertToAnnualSalary(double monthlySalary) {
        return monthlySalary * 12;
    }
    
    @Override
    public double convertToMonthlySalary(double annualSalary) {
        return annualSalary / 12;
    }
    
    @Override
    public double calculateTax(double salary) {
        if (salary <= 50000) {
            return salary * 0.10;
        } else if (salary <= 100000) {
            return 5000 + (salary - 50000) * 0.15;
        } else {
            return 12500 + (salary - 100000) * 0.25;
        }
    }
}