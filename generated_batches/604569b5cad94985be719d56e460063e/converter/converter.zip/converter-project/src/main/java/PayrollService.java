package hr.system;

public class PayrollService {
    private PayrollConverter converter;
    
    public PayrollService(PayrollConverter converter) {
        this.converter = converter;
    }
    
    public double calculateAnnualSalary(double monthlySalary) {
        return converter.convertToAnnualSalary(monthlySalary);
    }
    
    public double calculateMonthlySalary(double annualSalary) {
        return converter.convertToMonthlySalary(annualSalary);
    }