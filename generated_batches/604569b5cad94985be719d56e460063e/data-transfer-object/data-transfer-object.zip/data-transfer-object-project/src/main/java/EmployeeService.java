package hr.system;

public class EmployeeService {
    
    public EmployeeDTO getEmployeeDTO(int employeeId) {
        // Simulate fetching from database
        Employee employee = new Employee(employeeId, "John Doe", "john.doe@company.com", 50000.0);
        
        // Transform to DTO for data transfer
        return new EmployeeDTO(employee.getId(), employee.getName(), employee.getEmail());
    }
    
    public void updateEmployeeFromDTO(EmployeeDTO dto) {
        // Simulate updating database with DTO data
        System.out.println("Updating employee " + dto.getName() + " with email " + dto.getEmail());
    }
}