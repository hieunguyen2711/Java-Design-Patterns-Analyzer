package hr.system;

public class BonusCalculator implements SalaryCalculator {
    private final SalaryCalculator baseCalculator;
    private final double bonusPercentage;
    
    public BonusCalculator(SalaryCalculator baseCalculator, double bonusPercentage) {
        this.baseCalculator = baseCalculator;
        this.bonusPercentage = bonusPercentage;
    }
    
    @Override
    public double calculate(Employee employee) {
        double baseSalary = baseCalculator.calculate(employee);
        return baseSalary + (baseSalary * bonusPercentage / 100);
    }
}