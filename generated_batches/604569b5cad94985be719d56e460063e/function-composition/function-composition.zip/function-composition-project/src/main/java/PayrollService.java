package hr.system;

public class PayrollService {
    
    public static void main(String[] args) {
        Employee employee = new Employee("John Doe", 50000.0);
        
        // Function composition: calculate salary with bonus and tax deduction
        SalaryCalculator finalCalculator = new TaxDeductionCalculator(
            new BonusCalculator(employee -> employee.getBaseSalary(), 10.0),
            20.0
        );
        
        double netSalary = finalCalculator.calculate(employee);
        System.out.println("Net salary for " + employee.getName() + ": $" + netSalary);
    }
}