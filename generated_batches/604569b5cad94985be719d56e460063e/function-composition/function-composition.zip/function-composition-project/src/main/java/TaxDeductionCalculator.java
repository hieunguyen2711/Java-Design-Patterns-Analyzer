package hr.system;

public class TaxDeductionCalculator implements SalaryCalculator {
    private final SalaryCalculator baseCalculator;
    private final double taxRate;
    
    public TaxDeductionCalculator(SalaryCalculator baseCalculator, double taxRate) {
        this.baseCalculator = baseCalculator;
        this.taxRate = taxRate;
    }
    
    @Override
    public double calculate(Employee employee) {
        double grossSalary = baseCalculator.calculate(employee);
        return grossSalary - (grossSalary * taxRate / 100);
    }
}