package hr.system;

@FunctionalInterface
public interface SalaryCalculator {
    double calculate(Employee employee);
}