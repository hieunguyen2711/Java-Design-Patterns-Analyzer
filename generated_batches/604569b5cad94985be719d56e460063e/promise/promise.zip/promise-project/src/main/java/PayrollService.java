package hr.system;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PayrollService {
    private ExecutorService executor = Executors.newFixedThreadPool(2);
    
    public CompletableFuture<Double> calculateSalaryAsync(Employee employee) {
        return CompletableFuture.supplyAsync(() -> {
            // Simulate some processing time
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            
            double tax = employee.getBaseSalary() * 0.2;
            return employee.getBaseSalary() - tax;
        }, executor);
    }
    
    public CompletableFuture<LeaveRequest> processLeaveRequestAsync(LeaveRequest request) {
        return CompletableFuture.supplyAsync(() -> {
            // Simulate processing time
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            
            request.approve();
            return request;
        }, executor);
    }
    
    public void shutdown() {
        executor.shutdown();
    }
}