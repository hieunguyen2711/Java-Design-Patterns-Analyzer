package hr.system;

public class PayrollSystem {
    private static PayrollSystem instance;
    
    private PayrollSystem() {
        // Private constructor to prevent instantiation
    }
    
    public static synchronized PayrollSystem getInstance() {
        if (instance == null) {
            instance = new PayrollSystem();
        }
        return instance;
    }
    
    public double calculateNetSalary(Employee employee, double taxDeduction, double leaveDeduction) {
        double grossSalary = employee.getBaseSalary();
        double netSalary = grossSalary - taxDeduction - leaveDeduction;
        return Math.max(0, netSalary);
    }
    
    public void processPayslip(Employee employee, double taxDeduction, double leaveDeduction) {
        double netSalary = calculateNetSalary(employee, taxDeduction, leaveDeduction);
        System.out.println("Processing payslip for " + employee.getName() + 
                          ": Net Salary = $" + String.format("%.2f", netSalary));
    }
}