package hr.command;

import hr.Employee;
import hr.PayrollSystem;

public class SalaryCalculationCommand implements Command {
    private final Employee employee;
    
    public SalaryCalculationCommand(Employee employee) {
        this.employee = employee;
    }
    
    @Override
    public void execute() {
        PayrollSystem.getInstance().calculateSalary(employee);
    }
}