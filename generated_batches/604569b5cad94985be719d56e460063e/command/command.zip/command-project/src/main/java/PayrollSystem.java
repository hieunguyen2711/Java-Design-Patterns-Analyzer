package hr;

public class PayrollSystem {
    private static volatile PayrollSystem instance;
    
    private PayrollSystem() {}
    
    public static PayrollSystem getInstance() {
        if (instance == null) {
            synchronized (Pay