package hr.command;

import hr.Employee;
import hr.LeaveManager;

public class LeaveRequestCommand implements Command {
    private final Employee employee;
    private final String leaveType;
    private final int days;
    
    public LeaveRequestCommand(Employee employee, String leaveType, int days) {
        this.employee = employee;
        this.leaveType = leaveType;
        this.days = days;
    }
    
    @Override
    public void execute() {
        LeaveManager.getInstance().processLeaveRequest(employee, leaveType, days);
    }
}