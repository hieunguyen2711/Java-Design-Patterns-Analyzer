package hr;

public class LeaveManager {
    private static volatile LeaveManager instance;
    
    private LeaveManager() {}
    
    public static LeaveManager getInstance() {
        if (instance == null) {
            synchronized (LeaveManager.class) {
                if (instance == null) {
                    instance = new LeaveManager();
                }
            }
        }
        return instance;
    }
    
    public void processLeaveRequest(Employee employee, String leaveType, int days) {
        System.out.println("Processing " + days + " days of " + leaveType + 
                          " leave for employee: " + employee.getName());
    }
}