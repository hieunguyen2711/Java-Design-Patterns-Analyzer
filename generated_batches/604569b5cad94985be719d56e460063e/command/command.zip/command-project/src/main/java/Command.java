package hr.command;

public interface Command {
    void execute();
}