package hr.system;

import java.util.concurrent.atomic.AtomicBoolean;

public class PayrollSystem {
    private final Employee employee;
    private final AtomicBoolean isProcessing = new AtomicBoolean(false);
    
    public PayrollSystem(Employee employee) {
        this.employee = employee;
    }
    
    public void processSalaryUpdate(double newSalary) {
        // Balking pattern: if already processing, don't start another
        if (isProcessing.get()) {
            System.out.println("Balking: Salary update already in progress for employee " + employee.getId());
            return;
        }
        
        // Only proceed if not currently processing
        if (isProcessing.compareAndSet(false, true)) {
            try {
                System.out.println("Starting salary update for employee " + employee.getId());
                
                // Simulate some processing time
                Thread.sleep(100);
                
                // Update the salary
                employee.setSalary(newSalary);
                System.out.println("Salary updated