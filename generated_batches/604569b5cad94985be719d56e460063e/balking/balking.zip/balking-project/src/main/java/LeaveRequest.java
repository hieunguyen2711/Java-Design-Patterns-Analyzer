package hr.system;

public class LeaveRequest {
    private final int employeeId;
    private final String reason;
    private LeaveStatus status;
    
    public enum LeaveStatus {
        PENDING, APPROVED, REJECTED
    }
    
    public LeaveRequest(int employeeId, String reason) {
        this.employeeId = employeeId;
        this.reason = reason;
        this.status = LeaveStatus.PENDING;
    }
    
    public int getEmployeeId() {
        return employeeId;
    }
    
    public String getReason() {
        return reason;
    }
    
    public LeaveStatus getStatus() {
        return status;
    }
    
    public void setStatus(LeaveStatus status) {
        this.status = status;
    }
}