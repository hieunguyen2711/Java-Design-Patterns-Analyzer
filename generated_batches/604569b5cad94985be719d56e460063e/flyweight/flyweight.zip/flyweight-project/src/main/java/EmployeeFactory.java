package hr.system;

import java.util.HashMap;
import java.util.Map;

public class EmployeeFactory {
    private static final Map<String, Employee> employeeCache = new HashMap<>();
    
    public static Employee getEmployee(String name, String employeeId, String department, double baseSalary) {
        String key = employeeId;
        
        if (!employeeCache.containsKey(key)) {
            Employee employee = new Employee(name, employeeId, department, baseSalary);
            employeeCache.put(key, employee);
            System.out.println("Creating new employee: " + name);
        } else {
            System.out.println("Retrieving existing employee: " + name);
        }
        
        return employeeCache.get(key);
    }
    
    public static int getCacheSize() {
        return employeeCache.size();
    }
}