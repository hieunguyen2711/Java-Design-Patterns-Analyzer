package hr.system;

public class LeaveRequest {
    private Employee employee;
    private String leaveType;
    private int daysRequested;
    private String status;
    
    public LeaveRequest(Employee employee, String leaveType, int daysRequested) {
        this.employee = employee;
        this.leaveType = leaveType;
        this.daysRequested = daysRequested;
        this.status = "PENDING";
    }
    
    // Getters and setters
    public Employee getEmployee() { return employee; }
    public void setEmployee(Employee employee) { this.employee = employee; }