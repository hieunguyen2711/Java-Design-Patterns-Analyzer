package hr.system;

public class Employee {
    private String name;
    private String employeeId;
    private String department;
    private double baseSalary;
    
    public Employee(String name, String employeeId, String department, double baseSalary) {
        this.name = name;
        this.employeeId = employeeId;
        this.department = department;
        this.baseSalary = baseSalary;
    }
    
    // Getters and setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getEmployeeId() { return employeeId; }
    public void setEmployeeId(String employeeId) { this.employeeId = employeeId; }
    
    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }
    
    public double getBaseSalary() { return baseSalary; }
    public void setBaseSalary(double baseSalary) { this.baseSalary = baseSalary; }
}