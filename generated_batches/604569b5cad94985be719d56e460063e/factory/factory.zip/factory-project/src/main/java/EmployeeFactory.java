public class EmployeeFactory {
    public enum EmployeeType {
        MANAGER,
        DEVELOPER
    }
    
    public static Employee createEmployee(EmployeeType type, String name, String employeeId, double baseSalary, Object additionalInfo) {
        switch (type) {
            case MANAGER:
                return new Manager(name, employeeId, baseSalary, (Integer) additionalInfo);
            case DEVELOPER:
                return new Developer(name, employeeId, baseSalary, (String) additionalInfo);
            default:
                throw new IllegalArgumentException("Unknown employee type");
        }
    }
}