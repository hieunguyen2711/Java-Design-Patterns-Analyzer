public class Main {
    public static void main(String[] args) {
        Employee manager = EmployeeFactory.createEmployee(
            EmployeeFactory.EmployeeType.MANAGER,
            "John Smith",
            "M001",
            500