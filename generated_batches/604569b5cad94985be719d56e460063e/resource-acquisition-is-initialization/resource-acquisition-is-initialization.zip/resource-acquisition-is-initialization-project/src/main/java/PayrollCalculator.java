package hr.system;

public class PayrollCalculator {
    
    public static class SalaryCalculationResource implements AutoCloseable {
        private final Employee employee;
        private boolean isClosed = false;
        
        public SalaryCalculationResource(Employee employee) {
            this.employee = employee;
            System.out.println("Acquiring resources for employee: " + employee.getName());
        }
        
        public double calculateGrossSalary() {
            if (isClosed) {
                throw new IllegalStateException("Cannot use closed resource");
            }
            return employee.getBaseSalary();
        }
        
        public double calculateNetSalary(double taxRate) {
            if (isClosed) {
                throw new IllegalStateException("Cannot use closed resource");
            }
            double gross = calculateGrossSalary();
            return gross - (gross * taxRate);
        }
        
        @Override
        public void close() {
            if (!isClosed) {
                System.out.println("Releasing resources for employee: " + employee.getName());
                isClosed = true;
            }
        }
    }
    
    public static SalaryCalculationResource calculateSalary(Employee employee) {
        return new SalaryCalculationResource(employee);
    }
}