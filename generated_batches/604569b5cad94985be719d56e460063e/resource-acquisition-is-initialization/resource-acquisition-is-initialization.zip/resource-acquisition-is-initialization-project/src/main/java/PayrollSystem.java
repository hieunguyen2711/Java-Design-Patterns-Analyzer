package hr.system;

public class PayrollSystem {
    
    public static void main(String[] args) {
        Employee emp = new Employee("E001", "John Doe", 5000.0);
        
        // Using RAII pattern with try-with-resources
        try (PayrollCalculator.SalaryCalculationResource resource = 
             PayrollCalculator.calculateSalary(emp)) {
            
            double gross = resource.calculateGrossSalary();