package hr.system;

@FunctionalInterface
public interface TrampolineResult {
    TrampolineResult compute();
    
    default double getResult() {
        TrampolineResult current = this;
        while (current instanceof TrampolineResult) {
            if (current instanceof ResultWrapper) {
                return ((ResultWrapper) current).value;
            }
            current = current.compute();
        }
        throw new IllegalStateException("Invalid trampoline result");
    }
    
    static TrampolineResult of(double value) {
        return new ResultWrapper(value);
    }
    
    class ResultWrapper implements TrampolineResult {
        private final double value;
        
        public ResultWrapper(double value) {
            this.value = value;
        }
        
        @Override
        public TrampolineResult compute() {
            return this;
        }
    }
}