package hr.system;

public class PayrollService {
    
    public double processPayroll(Employee employee) {
        SalaryCalculator calculator = new SalaryCalculator();
        TrampolineResult result = calculator.calculateTotalSalary(employee);
        return result.getResult();
    }
}