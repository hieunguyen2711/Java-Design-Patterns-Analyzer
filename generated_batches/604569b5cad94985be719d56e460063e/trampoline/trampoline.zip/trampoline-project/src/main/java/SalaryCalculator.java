package hr.system;

public class SalaryCalculator {
    private static final double TAX_RATE = 0.2;
    private static final double BONUS_MULTIPLIER = 1.1;
    
    public TrampolineResult calculateTotalSalary(Employee employee) {
        return new TrampolineResult(() -> calculateTax(employee));
    }
    
    private TrampolineResult calculateTax(Employee employee) {
        double taxAmount = employee.getBaseSalary() * TAX_RATE;
        return new TrampolineResult(() -> calculateBonus(employee, taxAmount));
    }
    
    private TrampolineResult calculateBonus(Employee employee, double taxAmount) {
        double bonus = employee.getBaseSalary() * BONUS_MULTIPLIER;
        double total = employee.getBaseSalary() + bonus - taxAmount;
        return new TrampolineResult(total);
    }
}