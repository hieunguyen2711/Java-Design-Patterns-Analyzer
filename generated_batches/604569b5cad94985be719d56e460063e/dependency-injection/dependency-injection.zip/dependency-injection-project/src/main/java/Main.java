package hr.system;

public class Main {
    public static void main(String[] args) {
        Employee employee = new Employee("E001", "John Doe", 5000.0);
        
        SalaryCalculator calculator = new BasicSalaryCalculator();
        PayrollService payrollService = new PayrollService(calculator);
        
        double netSalary = payrollService.calculateNetSalary(employee, 0.2);
        System.out.println("Net salary: $" + netSalary);
    }
}