package hr.system;

public class PayrollService {
    private SalaryCalculator salaryCalculator;
    
    public PayrollService(SalaryCalculator salaryCalculator) {
        this.salaryCalculator = salaryCalculator;
    }
    
    public double calculateNetSalary(Employee employee, double taxRate) {
        return salaryCalculator.calculateNetSalary(employee, taxRate);
    }
}