package hr.system;

public class BasicSalaryCalculator implements SalaryCalculator {
    
    @Override
    public double calculateNetSalary(Employee employee, double taxRate) {
        double gross = employee.getBaseSalary();
        return gross - (gross * taxRate);
    }
}