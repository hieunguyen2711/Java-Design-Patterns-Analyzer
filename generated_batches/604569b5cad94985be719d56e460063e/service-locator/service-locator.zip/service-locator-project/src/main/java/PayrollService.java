public interface PayrollService {
    double calculateSalary(int employeeId);
    String generatePayslip(int employeeId);
    double calculateTax(double salary);
}