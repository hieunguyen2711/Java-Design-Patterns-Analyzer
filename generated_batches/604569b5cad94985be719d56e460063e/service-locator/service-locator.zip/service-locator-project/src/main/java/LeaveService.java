public interface LeaveService {
    void applyLeave(LeaveRequest request);
    LeaveRequest getLeaveRequest(int id);
    void approveLeave(int requestId);
    void rejectLeave(int requestId);
}