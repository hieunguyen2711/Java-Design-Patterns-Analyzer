public interface EmployeeService {
    void addEmployee(Employee employee);
    Employee getEmployee(int id);
    void updateEmployee(Employee employee);
    void deleteEmployee(int id);
}