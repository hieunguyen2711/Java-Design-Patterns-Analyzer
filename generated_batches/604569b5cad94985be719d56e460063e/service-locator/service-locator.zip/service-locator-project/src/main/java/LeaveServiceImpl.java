public class LeaveServiceImpl implements LeaveService {
    private Map<Integer, LeaveRequest> leaveRequests = new HashMap<>();

    @Override
    public void applyLeave(LeaveRequest request) {
        leaveRequests.put(request.getId(), request);
    }

    @Override
    public LeaveRequest getLeaveRequest(int id) {
        return leaveRequests.get(id);
    }

    @Override
    public void approveLeave(int requestId) {
        LeaveRequest request = leaveRequests.get(requestId