package hr.system;

public class EmployeeServiceStub implements EmployeeService {
    
    @Override
    public void processLeaveRequest(String employeeId, int days) {
        System.out.println("Stub: Processing leave request for employee " + employeeId);
    }
    
    @Override
    public double calculateSalary(String employeeId) {
        System.out.println("Stub: Calculating salary for employee " + employeeId);
        return 50000.0;
    }
    
    @Override
    public String generatePayslip(String employeeId) {
        System.out.println("Stub: Generating payslip for employee " + employeeId);
        return "Stub Payslip";
    }
    
    @Override
    public double deductTax(double salary) {
        System.out.println("Stub: Deducting tax from salary: " + salary);
        return salary * 0.8;
    }
}