package hr.system;

public class PayrollProcessor {
    private EmployeeService employeeService;
    
    public PayrollProcessor(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }
    
    public void processEmployee