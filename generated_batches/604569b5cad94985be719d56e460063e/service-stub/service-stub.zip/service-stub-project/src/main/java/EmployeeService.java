package hr.system;

public interface EmployeeService {
    void processLeaveRequest(String employeeId, int days);
    double calculateSalary(String employeeId);
    String generatePayslip(String employeeId);
    double deductTax(double salary);
}