package hr.system;

public class EmployeeServiceImpl implements EmployeeService {
    
    @Override
    public void processLeaveRequest(String employeeId, int days) {
        System.out.println("Processing leave request for employee " + employeeId + " for " + days + " days");
    }
    
    @Override
    public double calculateSalary(String employeeId) {
        System.out.println("Calculating salary for employee " + employeeId);
        return 50000.0;
    }
    
    @Override
    public String generatePayslip(String employeeId) {
        System.out.println("Generating payslip for employee " + employeeId);
        return "Payslip for " + employeeId;
    }
    
    @Override
    public double deductTax(double salary) {
        System.out.println("Deducting tax from salary: " + salary);
        return salary * 0.8;
    }
}