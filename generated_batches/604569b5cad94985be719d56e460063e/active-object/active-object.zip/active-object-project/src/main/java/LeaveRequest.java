public class LeaveRequest {
    private final int employeeId;
    private final String reason;
    private final int days;

    public LeaveRequest(int employeeId, String reason, int days) {
        this.employeeId = employeeId;
        this.reason = reason;
        this.days = days;
    }

    // Getters
    public int getEmployeeId() { return employeeId; }
    public String getReason() { return reason; }
    public int getDays() { return days; }
}