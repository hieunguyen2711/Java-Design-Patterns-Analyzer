public abstract class Request {
    private final long timestamp;

    public Request() {
        this.timestamp = System.currentTimeMillis();
    }

    public long getTimestamp() {
        return timestamp;
    }

    public abstract void process(ActiveObject activeObject);
}