public class LeaveRequestProcessor extends Request {
    private final LeaveRequest leaveRequest;

    public LeaveRequestProcessor(LeaveRequest leaveRequest) {
        this.leaveRequest = leaveRequest;
    }

    @Override
    public void process(ActiveObject activeObject) {
        // Simulate processing delay
        try {