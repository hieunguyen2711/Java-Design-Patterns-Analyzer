public class SalaryCalculationRequest {
    private final int employeeId;
    private final double bonus;

    public SalaryCalculationRequest(int employeeId, double bonus) {
        this.employeeId = employeeId;
        this.bonus = bonus;
    }

    // Getters
    public int getEmployeeId() { return employeeId; }
    public double getBonus() { return bonus; }
}