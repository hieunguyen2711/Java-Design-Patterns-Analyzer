public interface Visitor {
    void visit(Employee employee);
    void visit(LeaveRequest leaveRequest);
    void visit(TaxDeduction taxDeduction);
    void visit(PaySlip paySlip);
}