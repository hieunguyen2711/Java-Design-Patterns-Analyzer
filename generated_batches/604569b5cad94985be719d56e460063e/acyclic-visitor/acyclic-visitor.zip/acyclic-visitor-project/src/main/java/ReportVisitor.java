import java.util.ArrayList;
import java.util.List;

public class ReportVisitor implements Visitor {
    private List<String> reports = new ArrayList<>();
    
    @Override
    public void visit(Employee employee) {
        reports.add("Employee: " + employee.getName() + ", Salary: $" + employee.get