public class PaySlip {
    private Employee employee;
    private double grossSalary;
    private double netSalary;
    
    public PaySlip(Employee employee, double grossSalary, double netSalary) {
        this.employee = employee;
        this.grossSalary = grossSalary;
        this.netSalary = netSalary;
    }
    
    public Employee getEmployee() {
        return employee;
    }
    
    public double getGrossSalary() {
        return grossSalary;
    }
    
    public double getNetSalary() {
        return netSalary;
    }
}