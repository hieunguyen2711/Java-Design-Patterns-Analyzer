public class LeaveRequest {
    private Employee employee;
    private int daysRequested;
    
    public LeaveRequest(Employee employee, int daysRequested) {
        this.employee = employee;
        this.daysRequested = daysRequested;
    }
    
    public Employee getEmployee() {
        return employee;
    }
    
    public int getDaysRequested() {
        return daysRequested;
    }
}