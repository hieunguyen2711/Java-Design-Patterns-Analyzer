public class TaxDeduction {
    private Employee employee;
    private double amount;
    
    public TaxDeduction(Employee employee, double amount) {
        this.employee = employee;
        this.amount = amount;
    }
    
    public Employee getEmployee() {
        return employee;
    }
    
    public double getAmount() {
        return amount;
    }
}