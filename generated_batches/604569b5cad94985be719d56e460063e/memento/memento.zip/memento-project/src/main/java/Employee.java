package hr.system;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Employee {
    private String id;
    private String name;
    private BigDecimal salary;
    private List<LeaveRequest> leaveRequests;
    
    public Employee(String id, String name, BigDecimal salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
        this.leaveRequests = new ArrayList<>();
    }
    
    public void addLeaveRequest(LeaveRequest request) {
        leaveRequests.add(request);
    }
    
    public Memento saveToMemento() {
        return new Memento(id, name, salary, new ArrayList<>(leaveRequests));
    }
    
    public void restoreFromMemento(Memento memento) {
        this.id = memento.getId();
        this.name = memento.getName();
        this.salary = memento.getSalary();
        this.leaveRequests = new ArrayList<>(memento.getLeaveRequests());
    }
    
    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public BigDecimal getSalary() { return salary; }
    public void setSalary(BigDecimal salary) { this.salary = salary; }
    public List<LeaveRequest> getLeaveRequests() { return leaveRequests; }
    
    @Override
    public String toString() {
        return "Employee{id='" + id + "', name='" + name + "', salary=" + salary + "}";
    }
}