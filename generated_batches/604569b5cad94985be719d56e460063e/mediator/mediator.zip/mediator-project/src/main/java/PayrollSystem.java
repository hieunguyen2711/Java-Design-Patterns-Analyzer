public class PayrollSystem {
    private double taxRate;
    
    public PayrollSystem(double taxRate) {
        this.taxRate = taxRate;
    }
    
    public double calculateNetSalary(Employee employee) {
        double grossSalary = employee.getBaseSalary();
        return grossSalary - (grossSalary * taxRate);
    }
    
    public void processPayslip(Employee employee, double netSalary) {
        System.out.println("Processing payslip for " + employee.getName() + 
                          ": $" + String.format("%.2f", netSalary));
    }
}