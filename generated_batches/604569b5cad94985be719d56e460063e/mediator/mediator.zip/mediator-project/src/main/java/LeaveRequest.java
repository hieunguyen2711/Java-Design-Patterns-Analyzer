public class LeaveRequest {
    private String employeeId;
    private int daysRequested;
    private String reason;
    
    public LeaveRequest(String employeeId, int daysRequested, String reason) {
        this.employeeId = employeeId;
        this.daysRequested = daysRequested;
        this.reason = reason;
    }
    
    // Getters and setters
    public String getEmployeeId() { return employeeId; }
    public void setEmployeeId(String employeeId) { this.employeeId = employeeId; }
    
    public int getDaysRequested() { return daysRequested; }
    public void setDaysRequested(int daysRequested) { this.daysRequested = daysRequested; }
    
    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }
}