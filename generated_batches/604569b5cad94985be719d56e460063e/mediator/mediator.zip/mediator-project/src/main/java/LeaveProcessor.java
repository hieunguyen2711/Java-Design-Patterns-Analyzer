public class LeaveProcessor {
    private int maxLeaveDays;
    
    public LeaveProcessor(int maxLeaveDays) {
        this.maxLeaveDays = maxLeaveDays;
    }