package hr.system;

public class PayrollCalculator {
    
    public static double calculateGrossSalary(Employee employee, LeaveRequest leaveRequest) {
        // Base salary plus leave adjustment
        double gross = employee.getBaseSalary();
        
        if (leaveRequest != null && "sick".equals(leaveRequest.getLeaveType())) {
            // Sick leave reduces pay by 20%
            gross *= 0.8;
        } else if (leaveRequest != null && "vacation".equals(leaveRequest.getLeaveType())) {
            // Vacation leave has no reduction
            gross = gross;
        }
        
        return gross;
    }
    
    public static double calculateNetSalary(double grossSalary, boolean taxDeduction) {