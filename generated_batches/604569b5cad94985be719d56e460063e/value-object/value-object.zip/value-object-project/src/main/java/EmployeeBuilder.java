package hr.system;

import java.math.BigDecimal;
import java.time.LocalDate;

public class EmployeeBuilder {
    private String id;
    private String firstName;
    private String lastName;
    private LocalDate hireDate;
    private BigDecimal salary;
    private String department;
    
    public static EmployeeBuilder anEmployee() {
        return new EmployeeBuilder();
    }
    
    public EmployeeBuilder withId(String id) {
        this.id = id;
        return this;
    }
    
    public EmployeeBuilder withFirstName(String firstName) {
        this.firstName = firstName;