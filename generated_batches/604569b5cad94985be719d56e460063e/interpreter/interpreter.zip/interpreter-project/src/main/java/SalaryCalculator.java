public class SalaryCalculator {
    public static void main(String[] args) {
        // Calculate salary: base + bonus - tax
        Expression expression = new SubtractExpression(
            new AddExpression(
                new NumberExpression(5000),
                new NumberExpression(1000)
            ),
            new NumberExpression(500)
        );
        
        System.out.println("Employee salary: " + expression.interpret());
    }
}