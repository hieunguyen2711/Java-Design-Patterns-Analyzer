public class Developer extends Employee {
    private String programmingLanguage;
    
    public Developer(String name, String employeeId, double baseSalary, String programmingLanguage) {
        super(name, employeeId, baseSalary);
        this.programmingLanguage = programmingLanguage;
    }
    
    @Override
    public double calculateSalary() {
        return baseSalary + (programmingLanguage.equals("Java") ? 2000 : 1500);
    }
}