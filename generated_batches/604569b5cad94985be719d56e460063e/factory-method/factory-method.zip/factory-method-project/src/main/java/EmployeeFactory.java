public abstract class EmployeeFactory {
    public abstract Employee createEmployee(String name, String employeeId, double baseSalary);
    
    public static EmployeeFactory getFactory(String type) {
        if ("manager".equalsIgnoreCase(type)) {
            return new ManagerFactory();
        } else if ("developer".equalsIgnoreCase(type)) {
            return new DeveloperFactory();
        }
        throw new IllegalArgumentException("Unknown employee type: " + type);
    }
}

class ManagerFactory extends EmployeeFactory {
    @Override
    public Employee createEmployee(String name, String employeeId, double baseSalary) {
        return new Manager(name, employeeId, baseSalary, 10);
    }
}

class DeveloperFactory extends EmployeeFactory {
    @Override
    public Employee createEmployee(String name, String employeeId, double baseSalary) {
        return new Developer(name, employeeId, baseSalary, "Java");
    }