package hr.system;

public class PayrollService {
    private Employee employee;
    private double baseSalary;
    private double taxDeduction;
    
    public PayrollService(Employee employee) {
        this.employee = employee;
        this.baseSalary = employee.getBaseSalary();
        this.taxDeduction = calculateTax(baseSalary);
    }