package hr.system;

public class LeaveRequest {
    private Employee employee;
    private String leaveType;
    private int daysRequested;
    private String reason;
    private boolean approved;
    
    public LeaveRequest(Employee employee) {
        this.employee = employee;
    }
    
    public LeaveRequest setLeaveType(String leaveType) {
        this.leaveType = leaveType;
        return this;
    }
    
    public LeaveRequest setDaysRequested(int daysRequested) {
        this.daysRequested = daysRequested;
        return this;
    }
    
    public LeaveRequest setReason(String reason) {
        this.reason = reason;
        return this;
    }
    
    public LeaveRequest approve() {
        this.approved = true;
        return this;
    }
    
    // Getters
    public Employee getEmployee() { return employee; }
    public String getLeaveType() { return leaveType; }
    public int getDaysRequested() { return daysRequested; }
    public String getReason() { return reason; }
    public boolean isApproved() { return approved; }
}