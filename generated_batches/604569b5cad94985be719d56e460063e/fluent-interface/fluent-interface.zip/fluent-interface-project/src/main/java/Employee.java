package hr.system;

public class Employee {
    private String name;
    private String id;
    private double baseSalary;
    private int vacationDays;
    private boolean isManager;
    
    public Employee(String name, String id) {
        this.name = name;
        this.id = id;
    }
    
    public Employee setName(String name) {
        this.name = name;
        return this;
    }
    
    public Employee setId(String id) {
        this.id = id;
        return this;
    }
    
    public Employee setBaseSalary(double baseSalary) {
        this.baseSalary = baseSalary;
        return this;
    }
    
    public Employee setVacationDays(int vacationDays) {
        this.vacationDays = vacationDays;
        return this;
    }
    
    public Employee setIsManager(boolean isManager) {
        this.isManager = isManager;
        return this;
    }
    
    // Getters
    public String getName() { return name; }
    public String getId() { return id; }
    public double getBaseSalary() { return baseSalary; }
    public int getVacationDays() { return vacationDays; }
    public boolean isManager() { return isManager; }
}