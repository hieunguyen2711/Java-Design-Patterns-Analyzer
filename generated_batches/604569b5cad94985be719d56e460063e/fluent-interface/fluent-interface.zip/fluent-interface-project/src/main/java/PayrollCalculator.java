package hr.system;

public class PayrollCalculator {