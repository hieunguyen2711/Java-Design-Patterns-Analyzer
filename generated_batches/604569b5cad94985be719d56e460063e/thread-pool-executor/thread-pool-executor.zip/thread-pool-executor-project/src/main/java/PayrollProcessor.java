package hr.system;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class PayrollProcessor {
    private ExecutorService executorService;
    
    public PayrollProcessor() {
        // Create a fixed thread pool with 3 threads for processing payroll tasks
        this.executorService = Executors.newFixedThreadPool(3);
    }
    
    public void processEmployeeSalary(Employee employee) {
        executorService.submit(() -> {
            System.out.println("Processing salary for " + employee.getName());
            try {
                Thread.sleep(1000); // Simulate processing time
                double calculatedSalary = calculateSalary(employee);
                System.out.println("Calculated salary: $" + calculatedSalary);