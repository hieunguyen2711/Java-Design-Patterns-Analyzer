package hr.system;

public class PayrollSystem {
    private static PayrollSystem instance;
    
    // Shared state - these fields are shared across all instances
    private double taxRate;
    private double bonusPercentage;
    private String companyPolicy;
    
    // Private constructor to prevent instantiation
    private PayrollSystem() {
        this.taxRate = 0.20; // 20% default tax rate
        this.bonusPercentage = 0.10; // 10% bonus percentage
        this.companyPolicy = "Standard HR Policy";
    }
    
    // Static factory method to get the single instance
    public static PayrollSystem getInstance() {
        if (instance == null) {
            instance = new PayrollSystem();
        }
        return instance;
    }
    
    // Methods that modify shared state
    public void setTaxRate(double taxRate) {
        this.taxRate = taxRate;
    }
    
    public void setBonusPercentage(double bonusPercentage) {
        this.bonusPercentage = bonusPercentage;
    }
    
    public void setCompanyPolicy(String companyPolicy) {
        this.companyPolicy = companyPolicy;
    }
    
    // Methods that access shared state
    public double calculateNetSalary(Employee employee) {
        double grossSalary = employee.getBaseSalary();
        double taxAmount = grossSalary * taxRate;
        double bonusAmount = grossSalary * bonusPercentage;
        return grossSalary - taxAmount + bonusAmount;
    }
    
    public String getCompanyPolicy() {
        return companyPolicy;
    }
    
    public double getTaxRate