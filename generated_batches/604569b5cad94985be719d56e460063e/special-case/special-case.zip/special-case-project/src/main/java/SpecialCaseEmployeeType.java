package hr.system;

public class SpecialCaseEmployeeType implements EmployeeType {
    
    @Override
    public double calculateBonus(Employee employee) {
        return employee.getBaseSalary() * 0.15;
    }
    
    @Override
    public double calculateTax(double grossSalary) {
        return grossSalary * 0.15;
    }
    
    @Override
    public String getType() {
        return "SpecialCase";
    }
}