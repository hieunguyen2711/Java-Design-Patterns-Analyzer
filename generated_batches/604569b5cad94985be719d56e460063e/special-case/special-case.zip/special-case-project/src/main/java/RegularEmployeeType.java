package hr.system;

public class RegularEmployeeType implements EmployeeType {
    
    @Override
    public double calculateBonus(Employee employee) {
        return employee.getBaseSalary() * 0.1;
    }
    
    @Override
    public double calculateTax(double grossSalary) {
        return grossSalary * 0.2;
    }
    
    @Override
    public String getType() {
        return "Regular";
    }
}