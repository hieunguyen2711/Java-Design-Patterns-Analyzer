package hr.system;

public interface EmployeeType {
    double calculateBonus(Employee employee);
    double calculateTax(double grossSalary);
    String getType();
}