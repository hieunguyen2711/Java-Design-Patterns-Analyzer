package hr.system;

public class EmployeeFactory {
    
    public static EmployeeType createEmployeeType(String type) {
        switch (type.toLowerCase()) {
            case "regular":
                return new RegularEmployeeType();
            case "