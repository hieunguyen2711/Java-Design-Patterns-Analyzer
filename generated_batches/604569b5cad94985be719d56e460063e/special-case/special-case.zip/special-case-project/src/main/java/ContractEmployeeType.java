package hr.system;

public class ContractEmployeeType implements EmployeeType {
    
    @Override
    public double calculateBonus(Employee employee) {
        return 0;
    }
    
    @Override
    public double calculateTax(double grossSalary) {
        return grossSalary * 0.25;
    }
    
    @Override
    public String getType() {
        return "Contract";
    }
}