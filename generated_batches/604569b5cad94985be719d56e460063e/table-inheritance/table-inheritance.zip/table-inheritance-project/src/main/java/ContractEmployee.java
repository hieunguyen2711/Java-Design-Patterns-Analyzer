package hr.system;

public class ContractEmployee extends Employee