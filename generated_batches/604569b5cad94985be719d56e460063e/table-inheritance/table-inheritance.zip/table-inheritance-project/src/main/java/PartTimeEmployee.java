package hr.system;

public class PartTimeEmployee extends Employee {
    private int hoursWorked;
    private double hourlyRate;
    
    public PartTimeEmployee(String name, int employeeId, int hoursWorked, 
                           double hourlyRate) {
        super(name, employeeId, 0); // Base salary is calculated
        this.hoursWorked = hoursWorked;
        this.hourlyRate = hourlyRate;
    }
    
    @Override
    public double calculateSalary() {
        return hoursWorked * hourlyRate;
    }
    
    @Override
    public String getEmployeeType() {
        return "Part-Time";
    }
    
    // Getters
    public int getHoursWorked() { return hoursWorked; }
    public double getHourlyRate() { return hourlyRate; }
}