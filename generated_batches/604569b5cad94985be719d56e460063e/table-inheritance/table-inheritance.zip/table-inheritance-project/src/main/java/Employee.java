package hr.system;

public abstract class Employee {
    protected String name;
    protected int employeeId;
    protected double baseSalary;
    
    public Employee(String name, int employeeId, double baseSalary) {
        this.name = name;
        this.employeeId = employeeId;
        this.baseSalary = baseSalary;
    }
    
    public abstract double calculateSalary();
    
    public abstract String getEmployeeType();
    
    // Getters
    public String getName() { return name; }
    public int getEmployeeId() { return employeeId; }
    public double getBaseSalary() { return baseSalary; }
}