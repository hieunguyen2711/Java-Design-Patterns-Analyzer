package hr.system;

public class FullTimeEmployee extends Employee {
    private double bonus;
    private double pensionContribution;
    
    public FullTimeEmployee(String name, int employeeId, double baseSalary, 
                           double bonus, double pensionContribution) {
        super(name, employeeId, baseSalary);
        this.bonus = bonus;
        this.pensionContribution = pensionContribution;
    }
    
    @Override
    public double calculateSalary() {
        return baseSalary + bonus - pensionContribution;
    }
    
    @Override
    public String getEmployeeType() {
        return "Full-Time";
    }
    
    // Getters
    public double getBonus() { return bonus; }
    public double getPensionContribution() { return pensionContribution; }
}