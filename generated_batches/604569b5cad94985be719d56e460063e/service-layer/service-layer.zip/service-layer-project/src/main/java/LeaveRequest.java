package hr.system;

public class LeaveRequest {
    private int employeeId;
    private String leaveType;
    private int daysRequested;
    private boolean approved;
    
    public LeaveRequest(int employeeId, String leaveType, int daysRequested) {
        this.employeeId = employeeId;
        this.leaveType = leaveType;
        this.daysRequested = daysRequested;
        this.approved = false;
    }
    
    // Getters and setters
    public int getEmployeeId() { return employeeId; }
    public void setEmployeeId(int employeeId) { this.employeeId = employeeId; }
    
    public String getLeaveType() { return leaveType; }
    public void setLeaveType(String leaveType) { this.leaveType = leaveType; }
    
    public int getDaysRequested() { return daysRequested; }
    public void setDaysRequested(int daysRequested) { this.daysRequested = daysRequested; }
    
    public boolean isApproved() { return approved; }
    public void setApproved(boolean approved) { this.approved = approved; }
}