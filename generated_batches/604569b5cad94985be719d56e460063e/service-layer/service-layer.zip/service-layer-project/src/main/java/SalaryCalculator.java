package hr.system;

public class SalaryCalculator {
    private static final double TAX_RATE = 0.2;
    private static final double BONUS_MULTIPLIER = 1.1;
    
    public double calculateNetSalary(Employee employee, double leaveDays) {
        double grossSalary = employee.getBaseSalary();
        
        // Apply bonus for good attendance
        if (leaveDays <= 5) {
            grossSalary *= BONUS_MULTIPLIER;
        }
        
        // Deduct taxes
        return grossSalary - (gross