package hr.system;

public interface BonusEligible {
    // Marker interface - no methods required
}