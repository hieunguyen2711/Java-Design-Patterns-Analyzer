package hr.system;

public class Manager extends Employee implements BonusEligible {
    private String department;
    
    public Manager(String name, int id, double baseSalary, String department) {
        super(name, id, baseSalary);
        this.department = department;
    }
    
    public String getDepartment() {
        return department;
    }
}