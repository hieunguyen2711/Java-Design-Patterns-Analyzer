package hr.system;

public class PayrollProcessor {
    
    public double calculateBonus(Employee employee) {
        if (employee instanceof BonusEligible) {
            return employee.getBaseSalary() * 0.1; // 10% bonus
        }
        return 0.0;
    }
    
    public static void main(String[] args) {
        Employee regularEmployee = new Employee("John Doe", 101, 50000);
        Manager manager = new Manager("Jane Smith", 201, 75000, "Engineering");
        
        PayrollProcessor processor = new PayrollProcessor();
        
        System.out.println("Regular employee bonus: $" + processor.calculateBonus(regularEmployee));
        System.out.println("Manager bonus: $" + processor.calculateBonus(manager));
    }
}