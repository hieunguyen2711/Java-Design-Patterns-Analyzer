package hr.system;

public class CommissionSalaryCalculator implements SalaryCalculator {
    private double commissionRate;
    
    public CommissionSalaryCalculator(double commissionRate) {
        this.commissionRate = commissionRate;
    }
    
    @Override
    public double calculateNetSalary(Employee employee) {
        return (employee.getBaseSalary() * (1 + commissionRate)) * 0.8;
    }
}