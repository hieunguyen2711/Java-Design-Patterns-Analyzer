package hr.system;

public class PayrollService {
    private SalaryCalculator calculator;
    
    public PayrollService(SalaryCalculator calculator) {
        this.calculator = calculator;
    }
    
    public double calculatePayslip(Employee employee) {
        return calculator.calculateNetSalary(employee);
    }
}