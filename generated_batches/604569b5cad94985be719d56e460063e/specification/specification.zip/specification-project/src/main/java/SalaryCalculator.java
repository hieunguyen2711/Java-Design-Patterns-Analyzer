package hr.system;

public interface SalaryCalculator {
    double calculateNetSalary(Employee employee);
}