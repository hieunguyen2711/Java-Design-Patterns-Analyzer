package hr.system;

public class FixedSalaryCalculator implements SalaryCalculator {
    @Override
    public double calculateNetSalary(Employee employee) {
        return employee.getBaseSalary() * 0.8; // 20% tax deduction
    }
}