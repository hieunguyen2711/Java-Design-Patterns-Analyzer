package hr.system;

public class Main {
    public static void main(String[] args) {
        Employee emp1 = new Employee("E001", "John Doe", 5000.0);
        Employee emp2 = new Employee("E002", "Jane Smith", 6000.0);
        
        PayrollService fixedPayroll = new PayrollService(new FixedSalaryCalculator());
        PayrollService commissionPayroll = new PayrollService(new CommissionSalaryCalculator(0.1));
        
        System.out.println("Fixed Salary Payslip for " + emp1.getName() + ": $"