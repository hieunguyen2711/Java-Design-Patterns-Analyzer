package hr.system;

public abstract class SalaryCalculator {
    protected Employee employee;
    
    public SalaryCalculator(Employee employee) {
        this.employee = employee;
    }
    
    public abstract double calculateSalary();
    public abstract double calculateTax();
}