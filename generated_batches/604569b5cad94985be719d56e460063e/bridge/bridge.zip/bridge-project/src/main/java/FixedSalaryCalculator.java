package hr.system;

public class FixedSalaryCalculator extends SalaryCalculator {
    
    public FixedSalaryCalculator(Employee employee) {
        super(employee);
    }
    
    @Override
    public double calculateSalary() {
        return employee.getBaseSalary();
    }
    
    @Override
    public double calculateTax() {
        return employee.getBaseSalary() * 0.2;
    }
}