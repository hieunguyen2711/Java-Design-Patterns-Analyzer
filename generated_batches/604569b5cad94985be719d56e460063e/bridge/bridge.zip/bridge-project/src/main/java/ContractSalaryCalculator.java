package hr.system;

public class ContractSalaryCalculator extends SalaryCalculator {
    
    public ContractSalaryCalculator(Employee employee) {
        super(employee);
    }
    
    @Override
    public double calculateSalary() {
        return employee.getBaseSalary() * 1.2;
    }
    
    @Override
    public double calculateTax() {
        return employee.getBaseSalary() * 0.15;
    }
}