package hr.system;

public class PayrollService {
    private SalaryCalculator salaryCalculator;
    
    public PayrollService(SalaryCalculator salaryCalculator) {
        this.salaryCalculator = salaryCalculator;
    }
    
    public void processPayroll() {
        double grossSalary = salaryCalculator.calculateSalary();
        double tax = salaryCalculator.calculateTax();
        double netSalary = grossSalary - tax;
        
        System.out.println("Processing payroll for employee: " + 
                          salaryCalculator.employee.getName());
        System.out.println("Gross Salary: $" + grossSalary);
        System.out.println("Tax Deduction: $" + tax);
        System.out.println("Net Salary: $" + net