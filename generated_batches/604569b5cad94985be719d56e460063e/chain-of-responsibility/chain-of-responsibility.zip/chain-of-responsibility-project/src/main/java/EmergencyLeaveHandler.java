public class EmergencyLeaveHandler extends LeaveHandler {
    private static final int MAX_DAYS = 5;

    @Override
    public boolean handleRequest(LeaveRequest request) {
        if ("Emergency".equals(request.getType()) && request.getDays() <= MAX_DAYS) {
            System.out.println("Emergency leave approved for " + request.getEmployee