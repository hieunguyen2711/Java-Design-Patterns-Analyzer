public class SickLeaveHandler extends LeaveHandler {
    private static final int MAX_DAYS = 10;

    @Override
    public boolean handleRequest(LeaveRequest request) {
        if ("Sick".equals(request.getType()) && request.getDays() <= MAX_DAYS) {
            System.out.println("Sick leave approved for " + request.getEmployeeName() + 
                             " for " + request.getDays() + " days");
            return true;
        } else if (nextHandler != null) {
            return nextHandler.handleRequest(request);
        }
        return false;
    }
}