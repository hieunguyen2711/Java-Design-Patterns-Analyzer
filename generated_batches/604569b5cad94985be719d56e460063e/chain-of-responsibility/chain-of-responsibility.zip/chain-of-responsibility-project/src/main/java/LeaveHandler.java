public abstract class LeaveHandler {
    protected LeaveHandler nextHandler;

    public void setNext(LeaveHandler handler) {
        this.nextHandler = handler;
    }

    public abstract boolean handleRequest(LeaveRequest request);
}