public class AnnualLeaveHandler extends LeaveHandler {
    private static final int MAX_DAYS = 30;

    @Override
    public boolean handleRequest(LeaveRequest request) {
        if ("Annual".equals(request.getType()) && request.getDays() <= MAX_DAYS) {
            System.out.println("Annual leave approved for " + request.getEmployeeName() + 
                             " for " + request.getDays() + " days");
            return true;
        } else if (nextHandler != null) {
            return nextHandler.handleRequest(request);
        }
        return false;
    }
}