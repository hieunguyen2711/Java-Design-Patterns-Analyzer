public class LeaveRequest {
    private String employeeName;
    private int days;
    private String type;

    public LeaveRequest(String employeeName, int days, String type) {
        this.employeeName = employeeName;
        this.days = days;
        this.type = type;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public int getDays() {
        return days;
    }

    public String getType() {
        return type;
    }
}