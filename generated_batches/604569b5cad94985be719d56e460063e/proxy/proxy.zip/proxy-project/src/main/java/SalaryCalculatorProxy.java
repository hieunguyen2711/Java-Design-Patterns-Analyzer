public class SalaryCalculatorProxy implements SalaryCalculator {
    private RealSalaryCalculator realCalculator;
    private static final int MAX_CALCULATIONS_PER_DAY = 100;
    private int calculationCount = 0;
    
    @Override
    public double calculateNetSalary(Employee employee) {
        if (calculationCount >= MAX_CALCULATIONS_PER_DAY) {
            throw new RuntimeException("Daily calculation limit exceeded");
        }
        
        if (realCalculator == null) {
            realCalculator = new RealSalaryCalculator();
        }
        
        calculationCount++;
        System.out.println("Proxy: Calculating salary for " + employee.getName());
        return realCalculator.calculateNetSalary(employee);
    }
    
    @Override
    public double calculateTax(double grossSalary) {
        if (realCalculator == null) {
            realCalculator = new Real