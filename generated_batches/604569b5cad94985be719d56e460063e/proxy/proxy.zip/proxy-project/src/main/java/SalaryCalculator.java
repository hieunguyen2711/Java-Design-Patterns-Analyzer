public interface SalaryCalculator {
    double calculateNetSalary(Employee employee);
    double calculateTax(double grossSalary);
}