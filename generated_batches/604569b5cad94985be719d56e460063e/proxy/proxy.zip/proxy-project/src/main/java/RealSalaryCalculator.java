public class RealSalaryCalculator implements SalaryCalculator {
    
    @Override
    public double calculateNetSalary(Employee employee) {
        double grossSalary = employee.getBaseSalary();
        double tax = calculateTax(grossSalary);
        return grossSalary - tax;
    }
    
    @Override
    public double calculateTax(double grossSalary) {
        // Simple progressive tax calculation
        if (grossSalary <= 5000) {
            return grossSalary * 0.10;
        } else if (grossSalary <= 10000) {
            return 500 + (grossSalary - 5000) * 0.15;
        } else {
            return 1250 + (grossSalary - 10000) * 0.25;
        }
    }
}