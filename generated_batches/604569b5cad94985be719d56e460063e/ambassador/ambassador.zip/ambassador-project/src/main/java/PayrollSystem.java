package hr.system;

public class PayrollSystem {
    private static volatile PayrollSystem instance;
    
    private PayrollSystem() {}
    
    public static PayrollSystem getInstance() {
        if (instance == null) {
            synchronized (PayrollSystem.class) {
                if (instance == null) {
                    instance = new PayrollSystem();
                }
            }
        }
        return instance;
    }
    
    public double calculateNetSalary(Employee employee, double taxDeduction, double bonus) {
        double grossSalary = employee.getBaseSalary() + bonus;
        return grossSalary - taxDeduction;
    }
}