package hr.system;

public class PayslipGenerator {
    private static volatile PayslipGenerator instance;
    
    private PayslipGenerator() {}
    
    public static PayslipGenerator getInstance() {
        if (instance == null) {
            synchronized (PayslipGenerator.class) {
                if (instance == null) {
                    instance = new PayslipGenerator();