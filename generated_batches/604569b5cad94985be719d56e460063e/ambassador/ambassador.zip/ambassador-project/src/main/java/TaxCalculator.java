package hr.system;

public class TaxCalculator {
    private static volatile TaxCalculator instance;
    
    private TaxCalculator() {}
    
    public static TaxCalculator getInstance() {
        if (instance == null) {
            synchronized (TaxCalculator.class) {
                if (instance == null) {
                    instance = new TaxCalculator();
                }
            }
        }
        return instance;
    }
    
    public double calculateTax(double grossSalary) {
        if (grossSalary <= 50000) {
            return grossSalary * 0.10;
        } else if (grossSalary <= 100000) {
            return grossSalary * 0.20;
        } else {
            return grossSalary * 0.30;
        }
    }
}