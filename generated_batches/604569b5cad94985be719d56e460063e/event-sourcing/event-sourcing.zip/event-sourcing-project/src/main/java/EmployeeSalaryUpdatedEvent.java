package hr.system;

public class EmployeeSalaryUpdatedEvent extends Event {
    private final double newSalary;