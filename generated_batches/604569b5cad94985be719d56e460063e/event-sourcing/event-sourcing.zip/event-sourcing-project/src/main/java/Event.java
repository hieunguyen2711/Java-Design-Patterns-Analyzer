package hr.system;

import java.time.LocalDateTime;

public abstract class Event {
    private final String eventId;
    private final LocalDateTime timestamp;
    private final String employeeId;
    
    public Event(String eventId, String employeeId) {
        this.eventId = eventId;
        this.employeeId = employeeId;
        this.timestamp = LocalDateTime.now();
    }
    
    public String getEventId() {
        return eventId;
    }
    
    public LocalDateTime getTimestamp() {
        return timestamp;
    }
    
    public String getEmployeeId() {
        return employeeId;
    }
}