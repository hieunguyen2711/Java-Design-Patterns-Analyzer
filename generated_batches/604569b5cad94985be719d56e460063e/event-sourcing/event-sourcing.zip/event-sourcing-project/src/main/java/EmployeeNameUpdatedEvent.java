package hr.system;

public class EmployeeNameUpdatedEvent extends Event {
    private final String newName;
    
    public EmployeeNameUpdatedEvent(String eventId, String employeeId, String newName) {
        super(eventId, employeeId);
        this.newName = newName;
    }
    
    public String getNewName() {
        return newName;
    }
}