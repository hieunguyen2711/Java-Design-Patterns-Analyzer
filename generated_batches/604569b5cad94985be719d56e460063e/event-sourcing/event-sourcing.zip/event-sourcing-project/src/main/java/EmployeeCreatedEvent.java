package hr.system;

public class EmployeeCreatedEvent extends Event {
    private final String name;
    private final double baseSalary;
    
    public EmployeeCreatedEvent(String eventId, String employeeId, String name, double baseSalary) {
        super(eventId, employeeId);
        this.name = name;
        this.baseSalary = baseSalary;
    }
    
    public String getName() {
        return name;
    }
    
    public double getBaseSalary() {
        return baseSalary;
    }
}