package hr.system;

import java.util.*;
import java.util.stream.Collectors;

public class PayrollProcessor {
    
    public List<Employee> processEmployees(List<Employee> employees) {
        return employees.stream()
                .filter(emp -> emp.getBaseSalary() > 0)
                .sorted(Comparator.comparing(Employee::getName))
                .collect(Collectors.toList());
    }
    
    public Map<String, Double> calculateBonuses(List<Employee> employees) {
        return employees.stream()
                .filter(emp -> emp.getYearsOfService() >= 5)
                .collect(Collectors.toMap(
                    Employee::getId,
                    emp -> emp.getBaseSalary() * 0.1
                ));
    }
    
    public List<LeaveRequest> processLeaveRequests(List<LeaveRequest> requests) {
        return requests.stream()
                .filter(req -> req.getDaysRequested() > 0)
                .filter(req -> "vacation".equalsIgnoreCase(req.getType()))
                .sorted(Comparator.comparing(LeaveRequest::getEmployeeId))
                .collect(Collectors.toList());
    }
    
    public double calculateTotalSalary(List<Employee> employees) {
        return