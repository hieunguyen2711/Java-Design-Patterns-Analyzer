package hr.system;

public class Employee {
    private String id;
    private String name;
    private double baseSalary;
    private int yearsOfService;
    
    public Employee(String id, String name, double baseSalary, int yearsOfService) {
        this.id = id;
        this.name = name;
        this.baseSalary = baseSalary;
        this.yearsOfService = yearsOfService;
    }
    
    // Getters
    public String getId() { return id; }
    public String getName() { return name; }
    public double getBaseSalary() { return baseSalary; }
    public int getYearsOfService() { return yearsOfService; }
}