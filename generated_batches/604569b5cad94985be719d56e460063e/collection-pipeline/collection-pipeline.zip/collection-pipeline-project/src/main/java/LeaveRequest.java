package hr.system;

public class LeaveRequest {
    private String employeeId;
    private String type;
    private int daysRequested;
    
    public LeaveRequest(String employeeId, String type, int daysRequested) {
        this.employeeId = employeeId;
        this.type = type;
        this.daysRequested = daysRequested;
    }
    
    // Getters
    public String getEmployeeId() { return employeeId; }
    public String getType() { return type; }
    public int getDaysRequested() { return daysRequested; }
}