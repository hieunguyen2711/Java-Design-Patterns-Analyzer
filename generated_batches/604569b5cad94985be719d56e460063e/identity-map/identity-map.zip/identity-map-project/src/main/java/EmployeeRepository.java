package hr.system;

import java.util.HashMap;
import java.util.Map;

public class EmployeeRepository {
    private static final Map<Integer, Employee> employeeMap = new HashMap<>();
    
    public static Employee findById(int id) {
        return employeeMap.get(id);
    }
    
    public static void save(Employee employee) {
        employeeMap.put(employee.getId(), employee);
    }
    
    public static void remove(int id) {
        employeeMap.remove(id);
    }
    
    public static boolean exists(int id) {
        return employeeMap.containsKey(id);
    }
}