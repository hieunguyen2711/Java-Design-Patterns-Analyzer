package hr.system;

public class EmployeeService {
    
    public Employee getEmployeeById(int id) {
        // First check if employee already exists in memory (identity map)
        Employee existing = EmployeeRepository.findById(id);
        if (existing != null) {
            return existing;
        }
        
        // If not found, create new employee (simulating database fetch)
        Employee newEmployee = new Employee(id, "Employee-" + id, 50000.0);
        EmployeeRepository.save(newEmployee);
        return newEmployee;
    }
    
    public void updateEmployee(int id, String name, double salary) {
        Employee employee = getEmployeeById(id);
        employee.setName(name);
        employee.setSalary(salary);
    }
}