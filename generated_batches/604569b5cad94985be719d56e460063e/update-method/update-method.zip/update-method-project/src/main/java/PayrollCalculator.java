package hr.system;

public class PayrollCalculator {
    private static final double TAX_RATE = 0.20;
    private static final double BONUS_MULTIPLIER = 1.10;
    
    public double calculateNetSalary(Employee employee, LeaveRequest leaveRequest) {
        double grossSalary = employee.getBaseSalary();
        
        // Apply bonus if no leave requested
        if (leaveRequest == null || leaveRequest.getDaysRequested() <= 0) {
            grossSalary *= BONUS_MULTIPLIER;
        }
        
        // Deduct tax
        double netSalary = grossSalary * (1 - TAX_RATE);
        
        return netSalary;
    }
}