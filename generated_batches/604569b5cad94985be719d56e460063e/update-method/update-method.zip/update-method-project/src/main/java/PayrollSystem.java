package hr.system;

public class PayrollSystem {
    private PayrollCalculator calculator;
    
    public PayrollSystem() {
        this.calculator = new PayrollCalculator();
    }
    
    public void processPayroll(Employee employee, LeaveRequest leaveRequest)