package hr.system;

public class LeaveRequest {
    private String employeeId;
    private int daysRequested;
    private boolean approved;
    
    public LeaveRequest(String employeeId, int daysRequested) {
        this.employeeId = employeeId;
        this.daysRequested = daysRequested;
        this.approved = false;
    }
    
    public String getEmployeeId() {
        return employeeId;
    }
    
    public int getDaysRequested() {
        return daysRequested;
    }
    
    public boolean isApproved() {
        return approved;
    }
    
    public void setApproved(boolean approved) {
        this.approved = approved;
    }
}