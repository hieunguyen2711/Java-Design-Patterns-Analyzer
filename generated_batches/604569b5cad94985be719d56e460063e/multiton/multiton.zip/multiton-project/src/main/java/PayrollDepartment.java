import java.util.HashMap;
import java.util.Map;

public class PayrollDepartment {
    private static final Map<String, PayrollDepartment> instances = new HashMap<>();
    
    private final String departmentName;
    
    // Private constructor to prevent instantiation
    private PayrollDepartment(String departmentName) {
        this.departmentName = departmentName;
    }
    
    /**
     * Returns the singleton instance for a given department name.
     * This is the core of the multiton pattern - multiple instances 
     * but only one per unique key (department name).
     */
    public static PayrollDepartment getInstance(String departmentName) {
        return instances.computeIfAbsent(departmentName, PayrollDepartment::new);
    }
    
    public String getDepartmentName() {
        return departmentName;
    }
    
    // Example method that would be used in payroll system
    public void processSalaryPayments() {
        System.out.println("Processing salary payments for " + departmentName + " department");
    }
}