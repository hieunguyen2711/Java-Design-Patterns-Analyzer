public class EmployeePayrollSystem {
    public static void main(String[] args) {
        // Demonstrating multiton pattern with different payroll departments
        PayrollDepartment accounting = PayrollDepartment.getInstance("ACCOUNTING");
        PayrollDepartment hr = PayrollDepartment.getInstance("HR");
        PayrollDepartment finance = PayrollDepartment.getInstance("FINANCE");
        
        // Each department maintains its own instance
        System.out.println("Accounting Department ID: " + accounting.hashCode());
        System.out.println("HR Department ID: " + hr.hashCode());
        System.out.println("Finance Department ID: " + finance.hashCode());
        
        // Verify that same name returns same instance
        PayrollDepartment accounting2 = PayrollDepartment.getInstance("ACCOUNTING");
        System.out.println("Same instance check: " + (accounting == accounting2));
    }
}