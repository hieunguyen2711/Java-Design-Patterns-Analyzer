package payroll;

public class PayrollService {
    
    public void processEmployeePayroll(int employeeId, double bonusAmount) {
        // Transaction script - all logic in one method
        Employee employee = findEmployee(employeeId);
        if (employee == null) {
            throw new RuntimeException("Employee not found");
        }
        
        double grossSalary = calculateGrossSalary(employee, bonusAmount);
        double taxDeduction = calculateTax(grossSalary);
        double netSalary = grossSalary - taxDeduction;
        
        generatePayslip(employeeId, grossSalary, taxDeduction, netSalary);
        updateEmployeeRecord(employeeId, netSalary);
        
        System.out.println("Payroll processed for employee " + employee.getName());
    }
    
    public void processLeaveRequest(int employeeId, int daysRequested, String reason) {
        // Transaction script - all logic in one method
        Employee employee = findEmployee(employeeId);
        if (employee == null) {
            throw new RuntimeException("Employee not found");
        }
        
        LeaveRequest request = createLeaveRequest(employeeId, daysRequested, reason);
        boolean approvalStatus = approveLeaveRequest(request);
        
        if (approvalStatus) {
            updateLeaveBalance(employeeId, daysRequested);
            System.out.println