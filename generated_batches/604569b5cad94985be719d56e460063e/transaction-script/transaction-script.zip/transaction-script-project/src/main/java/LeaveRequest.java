package payroll;

public class LeaveRequest {
    private int employeeId;
    private int daysRequested;
    private String reason;
    
    public LeaveRequest(int employeeId, int daysRequested, String reason) {
        this.employeeId = employeeId;
        this.daysRequested = daysRequested;
        this.reason = reason;
    }
    
    public int getEmployeeId() {
        return employeeId;
    }
    
    public int getDaysRequested() {
        return daysRequested;
    }
    
    public String getReason() {
        return reason;
    }
}