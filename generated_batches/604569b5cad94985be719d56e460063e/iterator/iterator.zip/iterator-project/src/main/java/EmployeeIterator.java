package hr.system;

import java.util.Iterator;

public class EmployeeIterator implements Iterator<Employee> {
    private Employee[] employees;
    private int position = 0;
    
    public EmployeeIterator(Employee[] employees) {
        this.employees = employees;
    }
    
    @Override
    public boolean hasNext() {
        return position < employees.length && employees[position] != null;
    }
    
    @Override
    public Employee next() {
        Employee employee = employees[position];
        position++;
        return employee;
    }
}