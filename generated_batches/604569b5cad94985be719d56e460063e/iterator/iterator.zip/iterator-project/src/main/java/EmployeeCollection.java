package hr.system;

import java.util.Iterator;

public class EmployeeCollection implements Iterable<Employee> {
    private Employee[] employees = new Employee[10];
    private int size = 0;
    
    public void add(Employee employee) {
        if (size < employees.length) {
            employees[size++] = employee;
        }
    }
    
    @Override
    public Iterator<Employee> iterator() {
        return new EmployeeIterator(employees);
    }
}