package hr.system;

public class PayrollSystem {
    public static void main(String[] args) {
        EmployeeCollection employees = new EmployeeCollection();
        
        employees.add(new Employee("E001", "John Doe", 50000));
        employees.add(new Employee("E002", "Jane Smith", 60000));
        employees.add(new Employee("E003", "Bob Johnson", 55000));
        
        // Using the iterator pattern to traverse employees
        for (Employee employee : employees) {
            if (employee != null) {
                System.out.println("Processing payroll for: " + employee.getName());
            }
        }
    }
}