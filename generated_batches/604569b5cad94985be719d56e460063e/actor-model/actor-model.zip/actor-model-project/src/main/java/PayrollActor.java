package hr.system;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class PayrollActor {
    private final BlockingQueue<Object> mailbox = new LinkedBlockingQueue<>();
    private final Employee employee;
    
    public PayrollActor(Employee employee) {
        this.employee = employee;
        Thread actorThread = new Thread(this::processMessages);
        actorThread.setDaemon(true);
        actorThread.start();
    }
    
    public void send(Object message) {
        try {
            mailbox.put(message);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
    
    private void processMessages() {
        while (!Thread.currentThread().isInterrupted()) {
            try {
                Object message = mailbox.take();
                if (message instanceof LeaveRequest) {
                    handleLeaveRequest((LeaveRequest) message);
                } else if (message instanceof SalaryCalculation) {
                    handleSalaryCalculation((SalaryCalculation) message);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }
    
    private void handleLeaveRequest(LeaveRequest request) {
        System.out.println("Processing leave request for employee " + 
                          employee.getName() + " (" + request.getDaysRequested() + " days)");
    }
    
    private void