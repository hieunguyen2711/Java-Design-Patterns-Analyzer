package hr.system;

public class LeaveRequest {
    private final String employeeId;
    private final int daysRequested;
    private final String reason;
    
    public LeaveRequest(String employeeId, int daysRequested, String reason) {
        this.employeeId = employeeId;
        this.daysRequested = daysRequested;
        this.reason = reason;
    }
    
    public String getEmployeeId() { return employeeId; }
    public int getDaysRequested() { return daysRequested; }
    public String getReason() { return reason; }
}