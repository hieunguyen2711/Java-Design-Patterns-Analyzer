package hr.system;

public abstract class PayrollEvent {
    private String employeeId;
    
    public PayrollEvent(String employeeId) {
        this.employeeId = employeeId;
    }
    
    public String getEmployeeId() { return employeeId; }
}