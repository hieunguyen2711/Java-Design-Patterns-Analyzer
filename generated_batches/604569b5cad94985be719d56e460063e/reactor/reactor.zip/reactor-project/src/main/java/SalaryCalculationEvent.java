package hr.system;

public class SalaryCalculationEvent extends PayrollEvent