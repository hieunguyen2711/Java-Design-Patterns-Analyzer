package hr.system;

public class LeaveApprovedEvent extends PayrollEvent {
    private int approvedDays;
    
    public LeaveApprovedEvent(String employeeId, int approvedDays) {
        super(employeeId);
        this.approvedDays = approvedDays;
    }
    
    public int getApprovedDays() { return approvedDays; }
}