package hr.system;

public class LeaveRequest {
    private final int employeeId;
    private final String reason;
    private final int days;
    private boolean approved;
    
    public LeaveRequest(int employeeId, String reason, int days) {
        this.employeeId = employeeId;
        this.reason = reason;
        this.days = days;
        this.approved = false;
    }
    
    public int getEmployeeId() {
        return employeeId;
    }
    
    public String getReason() {
        return reason;
    }
    
    public int getDays() {
        return days;
    }
    
    public boolean isApproved() {
        return approved;
    }
    
    public void approve() {
        this.approved = true;
    }
}