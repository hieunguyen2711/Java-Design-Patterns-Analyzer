package hr.system;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class PayrollSystem {
    private final LeaveRequestProcessor processor;
    private final ExecutorService executor;
    
    public PayrollSystem()