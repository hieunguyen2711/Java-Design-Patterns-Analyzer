package hr.system;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class LeaveRequestProcessor {
    private final BlockingQueue<LeaveRequest> requestQueue;
    
    public LeaveRequestProcessor() {
        this.requestQueue = new LinkedBlockingQueue<>();
    }
    
    public void submitRequest(LeaveRequest request) throws InterruptedException {
        requestQueue.put(request);
    }
    
    public LeaveRequest getNextRequest() throws InterruptedException {
        // Guarded suspension - wait until there's a request
        while (requestQueue.isEmpty()) {
            Thread.sleep(100); // Brief pause to avoid busy waiting
        }
        return requestQueue.take();
    }
}