public class LeaveRequest {
    private String employeeId;
    private int daysRequested;
    private String leaveType;
    
    public LeaveRequest(String employeeId, int daysRequested, String leaveType) {
        this.employeeId = employeeId;
        this.daysRequested = daysRequested;
        this.leaveType = leaveType;
    }
    
    // Getters and setters
    public String getEmployeeId() { return employeeId; }
    public void setEmployeeId(String employeeId) { this.employeeId = employeeId; }
    public int getDaysRequested() { return daysRequested; }
    public void setDaysRequested(int daysRequested) { this.daysRequested = daysRequested; }
    public String getLeaveType() { return leaveType; }
    public void setLeaveType(String leaveType) { this.leaveType = leaveType; }
}