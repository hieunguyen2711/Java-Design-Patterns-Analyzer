public class SalaryCalculator {
    public double calculateNetSalary(Employee employee, int leaveDays) {
        double grossSalary = employee.getBaseSalary();
        // Deduct for leave days (simplified calculation)
        double deduction = leaveDays * 100; // $100 per day
        return grossSalary - deduction;
    }
    
    public double calculateTax(double salary) {
        if (salary <= 50000) {
            return salary * 0.10;
        } else if (salary <= 100000) {
            return salary * 0.20;
        } else {
            return salary * 0.30;
        }
    }
}