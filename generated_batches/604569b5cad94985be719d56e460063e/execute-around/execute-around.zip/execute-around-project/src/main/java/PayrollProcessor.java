package hr.system;

import java.util.List;
import java.util.ArrayList;

public class PayrollProcessor {
    
    public static void processPayroll(PayrollContext context, Employee employee) {
        try {
            // Setup - acquire resources
            System.out.println("Processing payroll for: " + employee.getName());
            
            // Execute the actual work
            double calculatedSalary = calculateNetSalary(context, employee);
            
            // Cleanup - release resources
            System.out.println("Final salary processed: $" + calculatedSalary);
        } catch (Exception e) {
            System.err.println("Error processing payroll: " + e.getMessage());
        }
    }
    
    private static double calculateNetSalary(PayrollContext context, Employee employee) {
        double gross = employee.getBaseSalary();
        
        // Apply deductions
        double taxDeduction = gross * 0.2;
        double leaveDeduction = context.getLeaveDays() * 100; // $100 per day
        
        return gross - taxDeduction - leaveDeduction;
    }
}