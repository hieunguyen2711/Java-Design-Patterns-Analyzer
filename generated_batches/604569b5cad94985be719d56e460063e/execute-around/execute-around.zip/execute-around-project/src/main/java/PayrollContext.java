package hr.system;

public class PayrollContext implements AutoCloseable {
    private int leaveDays;
    
    public PayrollContext(int leaveDays) {
        this.leaveDays = leaveDays;
        System.out.println("Payroll context initialized with " + leaveDays + " leave days");
    }
    
    public int getLeaveDays() {
        return leaveDays;
    }
    
    @Override
    public void close() throws Exception {
        System.out.println("Payroll context cleaned up - resources released");
    }
}