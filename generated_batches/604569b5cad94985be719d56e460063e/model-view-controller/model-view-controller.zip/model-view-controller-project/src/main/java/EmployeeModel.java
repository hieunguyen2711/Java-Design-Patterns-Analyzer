package hr.system.model;

import java.util.ArrayList;
import java.util.List;

public class EmployeeModel {
    private List<Employee> employees;
    
    public EmployeeModel() {
        this.employees = new ArrayList<>();
        // Initialize with sample data
        employees.add(new Employee(1, "John Doe", 50000));
        employees.add(new Employee(2, "Jane Smith", 60000));
    }
    
    public List<Employee> getAllEmployees() {
        return employees;
    }
    
    public Employee getEmployeeById(int id) {
        for (Employee emp : employees) {
            if (emp.getId() == id) {
                return emp;
            }
        }
        return null;
    }
    
    public void addEmployee(Employee employee) {
        employees.add(employee);
    }
}