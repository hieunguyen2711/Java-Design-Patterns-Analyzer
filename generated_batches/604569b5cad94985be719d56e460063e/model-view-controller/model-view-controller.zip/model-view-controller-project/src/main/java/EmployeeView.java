package hr.system.view;

import hr.system.model.Employee;
import java.util.List;

public class EmployeeView {
    
    public void displayEmployees(List<Employee> employees) {
        System.out.println("=== Employee List ===");
        for (Employee emp : employees) {
            System.out.println("ID: " + emp.getId() + 
                             ", Name: " + emp.getName() + 
                             ", Salary: $" + emp.getBaseSalary());
        }
    }
    
    public void displayEmployee(Employee employee) {
        if (employee != null) {
            System.out.println("=== Employee Details ===");
            System.out.println("ID: " + employee.getId());
            System.out.println("Name: " + employee.getName());
            System.out.println("Salary: $" + employee.getBaseSalary());