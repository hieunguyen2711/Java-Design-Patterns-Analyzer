package hr.system.view;

import hr.system.model.Employee;
import hr.system.model.LeaveRequest;

public interface EmployeeView {
    void displayEmployeeDetails(Employee employee);
    void displayLeaveRequests(java.util.List<LeaveRequest> requests);
    void showSuccessMessage(String message);
    void showErrorMessage(String message);
    String getEmployeeId();
    String getLeaveStartDate();
    String getLeaveEndDate();
}