import java.lang.reflect.Proxy;

public class PayrollServiceProxy {
    
    public static PayrollService createPayrollServiceProxy(PayrollService target) {
        return (PayrollService) Proxy.newProxyInstance(
            target.getClass().getClassLoader(),
            new Class[]{PayrollService.class},
            new LoggingHandler(target)
        );
    }