public interface PayrollService {
    double calculateNetSalary(Employee employee);
    void processLeaveRequest(String employeeName, int days);
    void generatePayslip(Employee employee);
}