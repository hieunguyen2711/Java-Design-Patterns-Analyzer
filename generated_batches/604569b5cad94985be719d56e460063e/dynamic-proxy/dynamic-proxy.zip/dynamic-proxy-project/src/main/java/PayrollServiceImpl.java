public class PayrollServiceImpl implements PayrollService {
    
    @Override
    public double calculateNetSalary(Employee employee) {
        // Simulate salary calculation with tax deductions
        double tax = employee.getBaseSalary() * 0.2;
        return employee.getBaseSalary() - tax;
    }
    
    @Override
    public void processLeaveRequest(String employeeName, int days) {
        System.out.println("Processing leave request for " + employeeName + 
                          " for " + days + " days");
    }
    
    @Override
    public void generatePayslip(Employee employee) {
        System.out.println("Generating payslip for " + employee.getName());
    }
}