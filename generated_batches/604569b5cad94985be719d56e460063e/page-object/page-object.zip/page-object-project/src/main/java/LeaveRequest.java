package hr.system;

public class LeaveRequest {
    private String employeeId;
    private String leaveType;
    private int daysRequested;
    private String status;
    
    public LeaveRequest(String employeeId, String leaveType, int daysRequested) {
        this.employeeId = employeeId;
        this.leaveType = leaveType;
        this.daysRequested = daysRequested;
        this.status = "PENDING";
    }
    
    // Getters and setters
    public String getEmployeeId() { return employeeId; }
    public void setEmployeeId(String employeeId) { this.employeeId = employeeId; }
    
    public String getLeaveType() { return leaveType; }
    public void setLeaveType(String leaveType) { this.leaveType = leaveType; }
    
    public int getDaysRequested() { return daysRequested; }
    public void setDaysRequested(int daysRequested) { this.daysRequested = daysRequested; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}