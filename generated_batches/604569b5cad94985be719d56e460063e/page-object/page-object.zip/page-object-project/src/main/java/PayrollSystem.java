package hr.system;

import java.util.*;

public class PayrollSystem {
    private Map<String, Employee> employees;
    private List<LeaveRequest> leaveRequests;
    
    public PayrollSystem() {
        this.employees = new HashMap<>();
        this.leaveRequests = new ArrayList<>();
    }
    
    public void addEmployee(Employee employee)