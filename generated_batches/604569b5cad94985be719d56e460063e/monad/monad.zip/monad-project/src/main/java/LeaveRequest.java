package hr.system;

public class LeaveRequest {
    private final String employeeId;
    private final int daysRequested;
    private final boolean approved;
    
    public LeaveRequest(String employeeId, int daysRequested, boolean approved) {
        this.employeeId = employeeId;
        this.daysRequested = daysRequested;
        this.approved = approved;
    }
    
    public String getEmployeeId() { return employeeId; }
    public int getDaysRequested() { return daysRequested; }
    public boolean isApproved() { return approved; }
}