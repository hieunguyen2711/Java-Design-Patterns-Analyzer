package hr.system;

public class PayrollCalculator {
    private static volatile PayrollCalculator instance;
    
    private PayrollCalculator() {}
    
    public static PayrollCalculator getInstance() {
        if (instance == null) {
            synchronized (PayrollCalculator.class) {
                if (instance == null) {
                    instance = new PayrollCalculator();
                }
            }
        }
        return instance;
    }
    
    public double calculateNetSalary(Employee employee, LeaveRequest leaveRequest) {
        double grossSalary = employee.getBaseSalary();
        
        // Apply leave deductions
        if (leaveRequest != null && leaveRequest.getType() == LeaveRequest.LeaveType.ANNUAL) {
            double dailyRate = grossSalary / 260; // Assuming 260 working days per year
            double deduction = dailyRate * leaveRequest.getDaysRequested();
            grossSalary -= deduction;
        }
        
        // Apply tax deductions (simplified)
        double netSalary = grossSalary - (grossSalary * 0.2