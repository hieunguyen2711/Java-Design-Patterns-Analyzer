package hr.system;

public class LeaveRequest {
    private String employeeId;
    private int daysRequested;
    private LeaveType type;
    
    public enum LeaveType {
        ANNUAL, SICK, MATERNITY, PATERNITY
    }
    
    public LeaveRequest(String employeeId, int daysRequested, LeaveType type) {
        this.employeeId = employeeId;
        this.daysRequested = daysRequested;
        this.type = type;
    }
    
    public String getEmployeeId() {
        return employeeId;
    }
    
    public int getDaysRequested() {
        return daysRequested;
    }
    
    public LeaveType getType() {
        return type;
    }
}