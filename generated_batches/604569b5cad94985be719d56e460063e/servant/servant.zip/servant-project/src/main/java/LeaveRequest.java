package hr.system;

public class LeaveRequest {
    private Employee employee;
    private int daysRequested;
    private String reason;
    
    public LeaveRequest(Employee employee, int daysRequested, String reason) {
        this.employee = employee;
        this.daysRequested = daysRequested;
        this.reason = reason;
    }
    
    public Employee getEmployee() {
        return employee;
    }
    
    public int getDaysRequested() {
        return daysRequested;
    }
    
    public String getReason() {
        return reason;
    }
}