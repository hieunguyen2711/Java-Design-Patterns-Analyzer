package hr.system;

public class TaxCalculator {
    public double calculateTax(double grossSalary) {
        if (grossSalary <= 5000) {
            return grossSalary * 0.1;
        } else if (grossSalary <= 10000) {
            return grossSalary * 0.2;