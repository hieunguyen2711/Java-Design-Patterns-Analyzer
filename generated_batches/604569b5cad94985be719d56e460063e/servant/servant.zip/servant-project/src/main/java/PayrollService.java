package hr.system;

public class PayrollService {
    private TaxCalculator taxCalculator;
    private PayslipGenerator payslipGenerator;
    
    public PayrollService(TaxCalculator taxCalculator, PayslipGenerator payslipGenerator) {
        this.taxCalculator = taxCalculator;
        this.payslipGenerator = payslipGenerator;
    }
    
    public void processSalaryPayment(Employee employee) {
        double grossSalary = calculateGrossSalary(employee);
        double taxAmount = taxCalculator.calculateTax(grossSalary);
        double netSalary = grossSalary - taxAmount;
        
        String payslip = payslipGenerator.generatePayslip(employee, grossSalary, taxAmount, netSalary);
        System.out.println("Processed salary for " + employee.getName() + ":");
        System.out.println(payslip);
    }
    
    private double calculateGrossSalary(Employee employee) {
        return employee.getBaseSalary();
    }
}