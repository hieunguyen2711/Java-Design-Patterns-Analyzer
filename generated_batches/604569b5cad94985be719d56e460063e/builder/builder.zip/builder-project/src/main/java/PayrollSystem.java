package hr.system;

public class PayrollSystem {
    public static void main(String[] args) {
        // Using the Builder pattern to create employee objects
        Employee engineer = new Employee.Builder()
                .setId("EMP001")
                .setName("John Smith")
                .setDepartment("Engineering")
                .setBaseSalary(75000.0)
                .setEmail("john.smith@company.com")
                .build();
        
        Employee manager = new Employee.Builder()
                .setId("EMP002")
                .setName("Sarah Johnson")
                .