package hr.system;

public class PayrollCalculator {
    private static final double TAX_RATE = 0.20;
    private static final double BONUS_MULTIPLIER = 1.10;
    
    public double calculateNetSalary(Employee employee, int leaveDays) {
        double grossSalary = employee.getBaseSalary();
        
        // Apply bonus for good attendance
        if (leaveDays <= 5) {
            grossSalary *= BONUS_MULTIPLIER;
        }
        
        // Deduct taxes
        return grossSalary - (grossSalary * TAX_RATE);
    }
    
    public double calculateLeaveDeduction(LeaveRequest request, Employee employee) {
        double dailyRate =