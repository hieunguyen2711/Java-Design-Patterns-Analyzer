package hr.system;

public class PayrollService {
    private SalaryCalculator salaryCalculator;
    private TaxDeductionCalculator taxDeductionCalculator;
    
    public PayrollService(SalaryCalculator salaryCalculator, 
                         TaxDeductionCalculator taxDeductionCalculator) {
        this.salaryCalculator = salaryCalculator;
        this.taxDeductionCalculator = taxDeductionCalculator;
    }
    
    public Payslip generatePayslip(Employee employee, int leaveDays) {
        double grossSalary = salaryCalculator.calculateGrossSalary(employee, leaveDays);
        double taxDeduction = taxDeductionCalculator.calculateTaxDeduction(grossSalary);
        double netSalary = grossSalary - taxDeduction;
        
        return new Payslip(employee.getId(), employee.getName(), 
                          grossSalary, taxDeduction, netSalary);
    }
}