package hr.system;

public class RegularEmployeeSalaryCalculator implements SalaryCalculator {
    
    @Override
    public double calculateGrossSalary(Employee employee, int leaveDays) {
        double dailyRate = employee.getBaseSalary() / 26; // Assuming 26 working days per month
        double leaveDeduction = dailyRate * leaveDays;
        return employee.getBaseSalary() - leaveDeduction;
    }
}