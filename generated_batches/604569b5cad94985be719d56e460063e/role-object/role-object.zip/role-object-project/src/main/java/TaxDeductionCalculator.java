package hr.system;

public interface TaxDeductionCalculator {
    double calculateTaxDeduction(double grossSalary);
}