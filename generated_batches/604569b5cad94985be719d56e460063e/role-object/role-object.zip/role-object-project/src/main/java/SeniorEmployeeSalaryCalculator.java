package hr.system;

public class SeniorEmployeeSalaryCalculator implements SalaryCalculator {
    
    @Override