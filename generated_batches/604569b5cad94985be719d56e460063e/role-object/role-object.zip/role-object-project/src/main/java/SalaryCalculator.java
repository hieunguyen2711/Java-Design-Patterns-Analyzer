package hr.system;

public interface SalaryCalculator {
    double calculateGrossSalary(Employee employee, int leaveDays);
}