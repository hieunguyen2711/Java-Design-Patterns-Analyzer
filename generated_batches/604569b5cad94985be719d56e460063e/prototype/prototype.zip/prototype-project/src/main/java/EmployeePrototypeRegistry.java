package hr.system;

import java.util.HashMap;
import java.util.Map;

public class EmployeePrototypeRegistry {
    private Map<String, Employee> prototypes = new HashMap<>();
    
    public void registerPrototype(String key, Employee prototype) {
        prototypes.put(key, prototype);
    }
    
    public Employee createEmployee(String key) throws CloneNotSupportedException {
        Employee prototype = prototypes.get(key);
        if (prototype != null) {
            return prototype.clone();
        }
        throw new IllegalArgumentException("No prototype found for key: " + key);
    }
}