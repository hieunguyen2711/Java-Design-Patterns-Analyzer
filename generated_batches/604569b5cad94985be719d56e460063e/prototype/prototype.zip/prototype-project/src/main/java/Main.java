package hr.system;

public class Main {
    public static void main(String[] args) throws CloneNotSupportedException {
        EmployeePrototypeRegistry registry = new EmployeePrototypeRegistry();
        
        // Register prototypes
        Employee developerPrototype = new Employee("John Doe", 1001, 75000.0);
        Employee managerPrototype = new Employee("Jane Smith", 1002, 95000.0);
        
        registry.registerPrototype("developer", developerPrototype);
        registry.registerPrototype("manager", managerPrototype);
        
        // Create new employees using prototypes
        Employee juniorDev = registry.createEmployee("developer");
        juniorDev.setName("Alice Johnson");
        juniorDev.setId(20