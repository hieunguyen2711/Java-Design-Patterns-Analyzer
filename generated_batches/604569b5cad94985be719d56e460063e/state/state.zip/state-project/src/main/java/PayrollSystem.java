package hr.system;

public class PayrollSystem {
    public static void main(String[] args) {
        Employee emp = new Employee("John Doe", 50000);
        
        System.out.println("Active employee pay: " + emp.calculatePay());
        
        emp.setState(new OnLeaveEmployeeState());
        System.out.println("On leave employee pay: " + emp.calculatePay());
        
        emp.setState(new TerminatedEmployeeState());
        System.out.println("Terminated employee pay: " + emp.calculatePay());
    }
}