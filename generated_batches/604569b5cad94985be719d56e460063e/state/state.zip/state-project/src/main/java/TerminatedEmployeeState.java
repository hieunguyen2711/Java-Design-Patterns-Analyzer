package hr.system;

public class TerminatedEmployeeState implements EmployeeState {
    @Override
    public double calculatePay(Employee employee) {
        return 0.0;
    }
}