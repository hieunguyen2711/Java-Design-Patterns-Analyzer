package hr.system;

public class ActiveEmployeeState implements EmployeeState {
    @Override
    public double calculatePay(Employee employee) {
        return employee.getBaseSalary() * 1.0;
    }
}