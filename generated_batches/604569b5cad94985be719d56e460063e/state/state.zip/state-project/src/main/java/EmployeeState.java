package hr.system;

public interface EmployeeState {
    double calculatePay(Employee employee);
}