package hr.system;

public class OnLeaveEmployeeState implements EmployeeState {
    @Override
    public double calculatePay(Employee employee) {
        return employee.getBaseSalary() * 0.8;
    }
}