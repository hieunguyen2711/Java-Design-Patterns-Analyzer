package hr.system;

public class Employee {
    private String name;
    private double baseSalary;
    private EmployeeState state;
    
    public Employee(String name, double baseSalary) {
        this.name = name;
        this.baseSalary = baseSalary;
        this.state = new ActiveEmployeeState();
    }
    
    public void setState(EmployeeState state) {
        this.state = state;
    }
    
    public double calculatePay() {
        return state.calculatePay(this);
    }
    
    public double getBaseSalary() {
        return baseSalary;
    }
    
    public String getName() {
        return name;
    }
}