package hr.system;

public interface EmployeeRecord {
    void displayEmployeeDetails();
    double calculateAnnualSalary();
    void updateLeaveBalance(int days);
}