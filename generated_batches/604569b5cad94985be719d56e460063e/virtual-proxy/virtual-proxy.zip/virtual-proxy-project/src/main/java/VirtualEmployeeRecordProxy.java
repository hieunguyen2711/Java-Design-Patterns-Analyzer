package hr.system;

public class VirtualEmployeeRecordProxy implements EmployeeRecord {
    private Employee employee;
    private RealEmployeeRecord realRecord;
    
    public VirtualEmployeeRecordProxy