package hr.system;

import java.util.Date;

public class RealEmployeeRecord implements EmployeeRecord {
    private Employee employee;
    private int leaveBalance;
    private String payslipData;
    
    public RealEmployeeRecord(Employee employee) {
        this.employee = employee;
        this.leaveBalance = 20; // Default 20 days
        loadPayslipData(); // Simulate expensive data loading
    }
    
    private void loadPayslipData() {
        // Simulate heavy database or file I/O operation
        try {
            Thread.sleep(1000);
            this.payslipData = "Payslip data for employee " + employee.getName();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
    
    @Override
    public void displayEmployeeDetails() {
        System.out.println("Employee ID: " + employee.getId());
        System.out.println("Name: " + employee.getName());
        System.out.println("Base Salary: $" + employee.getBaseSalary());
        System.out.println("Leave Balance: " + leaveBalance + " days");
        System.out.println("Payslip Data: " + payslipData);
    }
    
    @Override
    public double calculateAnnualSalary() {
        return employee.getBaseSalary() * 12;
    }
    
    @Override
    public void updateLeaveBalance(int days) {
        this.leaveBalance += days;
    }
}