package hr.system;

public abstract class Employee {
    protected String name;
    protected int employeeId;
    
    public Employee(String name, int employeeId) {
        this.name = name;
        this.employeeId = employeeId;
    }
    
    // Template method
    public final double calculateSalary() {
        double baseSalary = getBaseSalary();
        double bonuses = calculateBonuses();
        double deductions = calculateDeductions();
        
        return baseSalary + bonuses - deductions;
    }
    
    protected abstract double getBaseSalary();
    protected abstract double calculateBonuses();
    protected abstract double calculateDeductions();
}