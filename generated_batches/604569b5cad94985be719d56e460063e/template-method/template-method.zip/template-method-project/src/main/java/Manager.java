package hr.system;

public class Manager extends Employee {
    private int teamSize;
    
    public Manager(String name, int employeeId, int teamSize) {
        super(name, employeeId);
        this.teamSize = teamSize;
    }
    
    @Override
    protected double getBaseSalary() {
        return 7000.0;
    }
    
    @Override
    protected double calculateBonuses() {
        return teamSize * 500.0;
    }
    
    @Override
    protected double calculateDeductions() {
        return 1200.0;
    }
}