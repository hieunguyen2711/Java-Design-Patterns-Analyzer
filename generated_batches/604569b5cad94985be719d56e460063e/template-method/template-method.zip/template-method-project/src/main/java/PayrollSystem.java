package hr.system;

public class PayrollSystem {
    public static void main(String[] args) {
        Employee manager = new Manager("Alice Johnson", 101, 10);
        Employee developer = new Developer("Bob Smith", 102, 5);
        
        System.out.println("Manager Salary: $" + String.format("%.2f", manager.calculateSalary()));