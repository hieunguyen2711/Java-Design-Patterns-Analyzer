package hr.system;

public class Developer extends Employee {
    private int yearsOfExperience;
    
    public Developer(String name, int employeeId, int yearsOfExperience) {
        super(name, employeeId);
        this.yearsOfExperience = yearsOfExperience;
    }
    
    @Override
    protected double getBaseSalary() {
        return 5000.0;
    }
    
    @Override
    protected double calculateBonuses() {
        return yearsOfExperience * 300.0;
    }
    
    @Override
    protected double calculateDeductions() {
        return 800.0;
    }
}