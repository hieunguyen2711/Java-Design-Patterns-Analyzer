package hr.system;

import java.util.*;

public class UnitOfWork {
    private Map<Class<?>, List<Object>> addedObjects;
    private Map<Class<?>, List<Object>> updatedObjects;
    private Map<Class<?>, List<Object>> deletedObjects;
    
    public UnitOfWork() {
        this.addedObjects = new HashMap<>();
        this.updatedObjects = new HashMap<>();
        this.deletedObjects = new HashMap<>();
    }
    
    public <T> void registerAdded(T entity, Class<T> type) {
        addedObjects.computeIfAbsent(type,