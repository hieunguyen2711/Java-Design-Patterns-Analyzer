package hr.system;

public class LeaveRequest {
    private int id;
    private int employeeId;
    private String leaveType;
    private int daysRequested;
    
    public LeaveRequest(int id, int employeeId, String leaveType, int daysRequested) {
        this.id = id;
        this.employeeId = employeeId;
        this.leaveType = leaveType;
        this.daysRequested = daysRequested;
    }
    
    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getEmployeeId() { return employeeId; }
    public void setEmployeeId(int employeeId) { this.employeeId = employeeId; }
    
    public String getLeaveType() { return leaveType; }
    public void setLeaveType(String leaveType) { this.leaveType = leaveType; }
    
    public int getDaysRequested() { return daysRequested; }
    public void setDaysRequested(int daysRequested) { this.daysRequested = daysRequested; }
}