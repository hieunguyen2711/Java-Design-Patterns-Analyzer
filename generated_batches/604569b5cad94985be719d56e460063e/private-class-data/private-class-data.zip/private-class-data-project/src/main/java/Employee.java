package hr.system;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;

public class Employee {
    private final String id;
    private final String name;
    private final BigDecimal baseSalary;
    private final LocalDate hireDate;
    
    public Employee(String id, String name, BigDecimal baseSalary, LocalDate hireDate) {
        this.id = Objects.requireNonNull(id);
        this.name = Objects.requireNonNull(name);
        this.baseSalary = Objects.requireNonNull(baseSalary);
        this.hireDate = Objects.requireNonNull(hireDate);
    }
    
    public String getId() {
        return id;
    }
    
    public String getName() {
        return name;
    }
    
    public BigDecimal getBaseSalary() {
        return baseSalary;
    }
    
    public LocalDate getHireDate() {
        return hireDate;
    }
}