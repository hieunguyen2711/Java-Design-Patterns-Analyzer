package hr.system;

import java.math.BigDecimal;
import java.time.LocalDate;

public class EmployeeData {
    private final String id;
    private final String name;
    private final BigDecimal baseSalary;
    private final LocalDate hireDate;
    
    public EmployeeData(String id, String name, BigDecimal baseSalary, LocalDate hireDate) {
        this.id = id;
        this.name = name;
        this.baseSalary = baseSalary;
        this.hireDate = hireDate;
    }
    
    // Getters for the data fields
    public String getId() {
        return id;
    }
    
    public String getName() {
        return name;
    }
    
    public BigDecimal getBaseSalary() {
        return baseSalary;
    }
    
    public LocalDate getHireDate() {
        return hireDate;
    }
}