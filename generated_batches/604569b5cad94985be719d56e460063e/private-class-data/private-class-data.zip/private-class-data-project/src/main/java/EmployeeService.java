package hr.system;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

public class EmployeeService {
    private final Map<String, EmployeeData> employeeDatabase = new HashMap<>();
    
    public void addEmployee(String id, String name, BigDecimal baseSalary, LocalDate hireDate) {
        employeeDatabase.put(id, new EmployeeData(id, name, baseSalary, hireDate));
    }
    
    public Employee getEmployee(String id) {
        EmployeeData data = employeeDatabase.get(id);
        if (data == null) {
            return null;
        }
        // Private-class-data pattern: encapsulating the mutable data in a private class
        return new Employee(data.getId(), data