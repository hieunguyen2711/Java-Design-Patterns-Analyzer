package hr.system;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;

public class EmployeePool {
    private static final int POOL_SIZE = 10;
    private static volatile EmployeePool instance;
    private ConcurrentLinkedQueue<Employee> pool;
    private AtomicInteger counter;
    
    private EmployeePool() {
        pool = new ConcurrentLinkedQueue<>();
        counter = new AtomicInteger(0);
        
        // Initialize the pool with employee objects
        for (int i = 0; i < POOL_SIZE; i++) {
            pool.offer(new Employee(i, "Employee-" + i, 50000.0));
        }
    }
    
    public static synchronized EmployeePool getInstance() {
        if (instance == null) {
            instance = new EmployeePool();
        }
        return instance;
    }
    
    public Employee acquireEmployee() {
        Employee employee = pool.poll();
        if (employee == null) {
            // Create new employee if pool is empty
            int id = counter.incrementAndGet();
            employee = new Employee(id, "Employee-" + id, 50000.0);
        }
        return employee;
    }
    
    public void releaseEmployee(Employee employee) {
        if (pool.size() < POOL_SIZE) {
            // Reset employee state before returning to pool
            employee.setName("Employee-" + employee.getId());
            employee.setBaseSalary(50000.0);
            pool.offer(employee);