package hr.system;

public class Manager extends Employee {
    private double baseSalary;
    private int teamSize;
    
    public Manager(String name, int employeeId, double baseSalary, int teamSize) {
        super(name, employeeId);
        this.baseSalary = baseSalary;
        this.teamSize = teamSize;
    }
    
    @Override
    public double calculateSalary() {
        return baseSalary + (teamSize * 1000);
    }
}