package hr.system;

public class PayrollProcessor {
    
    public static <T extends Employee> void processPayroll(T employee) {
        System.out.println("Processing payroll for " + employee.getName() + 
                          " (ID: " + employee.getEmployeeId() + ")");
        System.out.println("Salary: $" + employee.calculateSalary());
    }
    
    public static void main(String[] args) {
        Manager manager = new Manager("Alice Johnson", 101, 75000.0, 10);
        Developer developer = new Developer("Bob Smith", 201, 60000.0, 5);
        
        processPayroll(manager);
        processPayroll(developer);
    }
}