package hr.system;

public abstract class Employee {
    protected String name;
    protected int employeeId;
    
    public Employee(String name, int employeeId) {
        this.name = name;
        this.employeeId = employeeId;
    }
    
    public abstract double calculateSalary();
    
    public String getName() {
        return name;
    }
    
    public int getEmployeeId() {
        return employeeId;
    }
}