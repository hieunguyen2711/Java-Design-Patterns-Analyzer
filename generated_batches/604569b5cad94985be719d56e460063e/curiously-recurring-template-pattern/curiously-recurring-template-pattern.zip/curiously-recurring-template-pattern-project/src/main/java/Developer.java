package hr.system;

public class Developer extends Employee {
    private double baseSalary;
    private int experienceYears;
    
    public Developer(String name, int employeeId, double baseSalary, int experienceYears) {
        super(name, employeeId);
        this.baseSalary = baseSalary;
        this.experienceYears = experienceYears;
    }
    
    @Override
    public double calculateSalary() {
        return baseSalary + (experienceYears * 500);
    }
}