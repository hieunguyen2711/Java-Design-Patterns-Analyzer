package hr.system;

import java.util.*;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class PayrollSystem {
    private final Map<String, Employee> employees;
    private final List<LeaveRequest> leaveRequests;
    private final ReentrantReadWriteLock lock;
    
    public PayrollSystem() {
        this.employees = new HashMap<>();
        this.leaveRequests = new ArrayList<>();
        this.lock = new ReentrantReadWriteLock();
    }
    
    public void addEmployee(Employee employee) {
        lock.writeLock().lock();
        try {
            employees.put(employee.getId(), employee);
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    public Employee getEmployee(String id) {
        lock.readLock().lock();
        try {
            return employees.get(id);
        } finally {
            lock.readLock().unlock();
        }
    }
    
    public void submitLeaveRequest(LeaveRequest request) {
        lock.writeLock().lock();
        try {
            leaveRequests.add(request);
        } finally {
            lock.writeLock().unlock();
        }
    }