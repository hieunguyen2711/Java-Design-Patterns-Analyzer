public class PayrollSystem {
    public static void main(String[] args) {
        Employee manager = EmployeeFactory.createEmployee("manager", "M001", "M001", 5000, 10);
        Employee developer = EmployeeFactory.createEmployee("developer",