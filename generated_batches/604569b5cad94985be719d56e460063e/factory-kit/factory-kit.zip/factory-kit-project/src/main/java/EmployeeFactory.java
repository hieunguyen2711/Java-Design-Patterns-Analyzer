public class EmployeeFactory {
    public static Employee createEmployee(String type, String name, String employeeId, double baseSalary, Object additionalInfo) {
        switch (type.toLowerCase()) {
            case "manager":
                return new Manager(name, employeeId, baseSalary, (Integer) additionalInfo);
            case "developer":
                return new Developer(name, employeeId, baseSalary, (String) additionalInfo);
            default:
                throw new IllegalArgumentException("Unknown employee type: " + type);
        }
    }
}