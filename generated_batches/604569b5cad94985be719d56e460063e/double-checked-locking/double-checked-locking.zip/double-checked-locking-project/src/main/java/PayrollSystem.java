public class PayrollSystem {
    private EmployeeDatabase database;
    
    public PayrollSystem() {
        this.database = EmployeeDatabase.getInstance();
    }
    
    public void processSalary(String employeeId, double amount) {
        database.addEmployee(employeeId, "Employee-" + employeeId);
        System.out.println("Processing salary of $" + amount + " for employee " + employeeId);
    }
}