public class EmployeeDatabase {
    private static volatile EmployeeDatabase instance;
    
    private EmployeeDatabase() {
        // Private constructor to prevent instantiation
    }
    
    public static EmployeeDatabase getInstance() {
        if (instance == null) {
            synchronized (EmployeeDatabase.class) {
                if (instance == null) {
                    instance = new EmployeeDatabase();
                }
            }
        }
        return instance;
    }
    
    public void addEmployee(String employeeId, String name) {
        // Implementation for adding employee
        System.out.println("Adding employee: " + name + " with ID: " + employeeId);
    }
}