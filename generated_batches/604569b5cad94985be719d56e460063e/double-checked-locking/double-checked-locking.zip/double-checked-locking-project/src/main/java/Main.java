public class Main {
    public static void main(String[] args) {
        PayrollSystem payroll1 = new PayrollSystem();
        PayrollSystem payroll2 = new PayrollSystem();
        
        payroll1.processSalary("E001", 5000.0);
        payroll2.processSalary("E002", 6000.0);
        
        // Verify singleton behavior
        System.out.println("Same instance: " + (payroll1.database == payroll2.database));
    }
}