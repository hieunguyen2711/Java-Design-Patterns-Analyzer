public interface PayrollService {
    void calculateSalary(String employeeId);
}