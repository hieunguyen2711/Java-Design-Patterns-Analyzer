public class BusinessDelegatePatternDemo {
    public static void main(String[] args) {
        BusinessDelegate businessDelegate = new BusinessDelegate();
        
        businessDelegate.setEmployeeService(new EmployeeServiceImpl());
        businessDelegate.setLeaveService(new LeaveServiceImpl());
        businessDelegate.setPay