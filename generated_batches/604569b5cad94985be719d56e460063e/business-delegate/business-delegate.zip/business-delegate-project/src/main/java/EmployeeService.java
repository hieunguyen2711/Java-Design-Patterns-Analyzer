public interface EmployeeService {
    void getEmployeeDetails(String employeeId);
}