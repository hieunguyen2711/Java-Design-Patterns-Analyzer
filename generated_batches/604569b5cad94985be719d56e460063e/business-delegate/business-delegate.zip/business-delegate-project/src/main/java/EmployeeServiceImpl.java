public class EmployeeServiceImpl implements EmployeeService {
    @Override
    public void getEmployeeDetails(String employeeId) {
        System.out.println("Retrieving employee details for ID: " + employeeId);
    }
}