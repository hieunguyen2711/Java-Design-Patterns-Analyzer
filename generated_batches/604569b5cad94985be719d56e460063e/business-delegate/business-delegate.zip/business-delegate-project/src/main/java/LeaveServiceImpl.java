public class LeaveServiceImpl implements LeaveService {
    @Override
    public void submitLeaveRequest(String employeeId, String leaveType) {
        System.out.println("Submitting " + leaveType + " leave request for employee ID: " + employeeId);
    }
}