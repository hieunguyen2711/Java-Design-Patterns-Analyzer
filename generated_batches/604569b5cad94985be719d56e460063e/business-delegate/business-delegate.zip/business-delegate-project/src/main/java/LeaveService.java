public interface LeaveService {
    void submitLeaveRequest(String employeeId, String leaveType);
}