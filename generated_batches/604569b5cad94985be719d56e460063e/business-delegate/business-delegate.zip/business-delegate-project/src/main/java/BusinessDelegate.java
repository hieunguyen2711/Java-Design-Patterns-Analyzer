public class BusinessDelegate {
    private EmployeeService employeeService;
    private LeaveService leaveService;
    private PayrollService payrollService;

    public void setEmployeeService(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    public void setLeaveService(LeaveService leaveService) {
        this.leaveService = leaveService;
    }

    public void setPayrollService(PayrollService payrollService) {
        this.payrollService = payrollService;
    }

    public void processEmployeeRecord(String employeeId) {
        employeeService.getEmployeeDetails(employeeId);
    }

    public void processLeaveRequest(String employeeId, String leaveType) {
        leaveService.submitLeaveRequest(employeeId, leaveType);
    }

    public void processPayroll(String employeeId) {
        payrollService.calculateSalary(employeeId);
    }
}