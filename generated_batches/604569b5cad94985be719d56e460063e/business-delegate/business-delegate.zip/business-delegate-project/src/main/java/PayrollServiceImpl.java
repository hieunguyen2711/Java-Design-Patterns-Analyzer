public class PayrollServiceImpl implements PayrollService {
    @Override
    public void calculateSalary(String employeeId) {
        System.out.println("Calculating salary for employee ID: " + employeeId);
    }
}