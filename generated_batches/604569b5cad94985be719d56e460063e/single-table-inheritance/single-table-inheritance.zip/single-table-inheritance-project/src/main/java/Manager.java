package hr.system;

public class Manager extends Employee {
    private int teamSize;
    
    public Manager(String id, String name, double baseSalary, int teamSize) {
        super(id, name, baseSalary);
        this.teamSize = teamSize;
    }
    
    @Override
    public double calculateSalary() {
        return baseSalary + (teamSize * 500);
    }
    
    @Override
    public String getEmployeeType() {
        return "Manager";
    }
    
    // Getters and setters
    public int getTeamSize() { return teamSize; }
    public void setTeamSize(int teamSize) { this.teamSize = teamSize; }
}