package hr.system;

public class Developer extends Employee {
    private String programmingLanguage;
    
    public Developer(String id, String name, double baseSalary, String programmingLanguage) {
        super(id, name, baseSalary);
        this.programmingLanguage = programmingLanguage;
    }
    
    @Override
    public double calculateSalary() {
        return baseSalary + (programmingLanguage.equals("Java") ? 1000 : 500);
    }
    
    @Override
    public String getEmployeeType() {
        return "Developer";
    }
    
    // Getters and setters
    public String getProgrammingLanguage() { return programmingLanguage; }
    public void setProgrammingLanguage(String programmingLanguage) { this.programmingLanguage = programmingLanguage; }
}