package com.fleetmanager.page;

import com.fleetmanager.model.Vehicle;
import com.fleetmanager.repository.VehicleRepository;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class FleetManagerPage {
    private VehicleRepository vehicleRepository;
    
    public FleetManagerPage(VehicleRepository vehicleRepository) {
        this.vehicleRepository = vehicleRepository;
    }
    
    public List<Vehicle> getAllVehicles() {
        Map<String, Vehicle> vehicles = vehicleRepository.getAllVehicles();
        return vehicles.values().stream().collect(Collectors.toList());
    }