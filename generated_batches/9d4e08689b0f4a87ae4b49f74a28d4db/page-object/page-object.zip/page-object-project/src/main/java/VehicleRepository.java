package com.fleetmanager.repository;

import com.fleetmanager.model.Vehicle;
import java.util.HashMap;
import java.util.Map;

public class VehicleRepository {
    private Map<String, Vehicle> vehicles;
    
    public VehicleRepository() {
        this.vehicles = new HashMap<>();
    }
    
    public void addVehicle(Vehicle vehicle) {
        vehicles.put(vehicle.getId(), vehicle);
    }
    
    public Vehicle findVehicleById(String id) {
        return vehicles.get(id);
    }
    
    public Map<String, Vehicle> getAllVehicles() {
        return new HashMap<>(vehicles);
    }
}