package fleet;

public class Truck extends Vehicle {
    private double cargoCapacity;
    
    public Truck(String make, String model, int year, double basePrice, double cargoCapacity) {
        super(make, model, year, basePrice);
        this.cargoCapacity = cargoCapacity;
    }
    
    @Override
    protected double applyBaseDiscount(double price) {
        if (cargoCapacity > 2000) {
            return price * 0.85; //