package fleet;

public abstract class Vehicle {
    protected String make;
    protected String model;
    protected int year;
    protected double basePrice;
    
    public Vehicle(String make, String model, int year, double basePrice) {
        this.make = make;
        this.model = model;
        this.year = year;
        this.basePrice = basePrice;
    }
    
    // Template method
    public final double calculateTotalPrice() {
        double price = basePrice;
        price = applyBaseDiscount(price);
        price = applySeasonalAdjustment(price);
        price = applySpecialOffers(price);
        return price;
    }
    
    protected abstract double applyBaseDiscount(double price);
    protected abstract double applySeasonalAdjustment(double price);
    protected abstract double applySpecialOffers(double price);
    
    public String getVehicleInfo() {
        return year + " " + make + " " + model;
    }
}