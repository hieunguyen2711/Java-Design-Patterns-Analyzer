package fleet;

public class Car extends Vehicle {
    private boolean isElectric;
    
    public Car(String make, String model, int year, double basePrice, boolean isElectric) {
        super(make, model, year, basePrice);
        this.isElectric = isElectric;
    }
    
    @Override
    protected double applyBaseDiscount(double price) {
        if (isElectric) {
            return price * 0.9; // 10% discount for electric cars
        }
        return price;
    }
    
    @Override
    protected double applySeasonalAdjustment(double price) {
        // No seasonal adjustment for cars
        return price;
    }
    
    @Override
    protected double applySpecialOffers(double price) {
        if (year > 2020) {
            return price * 0.95; // Additional 5% off for newer models
        }
        return price;
    }
}