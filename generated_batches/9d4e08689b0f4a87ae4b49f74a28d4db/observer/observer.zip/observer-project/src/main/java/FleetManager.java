package fleetmanagement;

import java.util.ArrayList;
import java.util.List;

public class FleetManager implements Observer {
    private List<Vehicle> vehicles;
    
    public FleetManager() {
        this.vehicles = new ArrayList<>();
    }
    
    public void addVehicle(Vehicle vehicle) {
        vehicles.add(vehicle);
        vehicle.addObserver(this);
    }
    
    @Override
    public void update(Vehicle vehicle) {
        System.out.println("Fleet Manager notified: Vehicle " + 
                          vehicle.getId() + " is now " + 
                          (vehicle.isAvailable() ? "available" : "unavailable"));
    }
}