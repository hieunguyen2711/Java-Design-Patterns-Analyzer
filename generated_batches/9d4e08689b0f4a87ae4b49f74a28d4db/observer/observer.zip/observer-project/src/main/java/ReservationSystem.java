package fleetmanagement;

public class ReservationSystem implements Observer {
    @Override
    public void update(Vehicle vehicle) {
        if (vehicle.isAvailable()) {
            System.out.println("Reservation system: Vehicle " + 
                              vehicle.getId() + " is now available for booking");
        } else {
            System.out.println("Reservation system: Vehicle " + 
                              vehicle.getId() + " is no longer available");
        }
    }
}