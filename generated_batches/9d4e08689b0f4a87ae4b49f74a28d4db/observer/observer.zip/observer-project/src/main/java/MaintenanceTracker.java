package fleetmanagement;

public class MaintenanceTracker implements Observer {
    @Override
    public