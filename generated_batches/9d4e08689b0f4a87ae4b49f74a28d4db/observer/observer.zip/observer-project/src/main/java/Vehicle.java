package fleetmanagement;

import java.util.ArrayList;
import java.util.List;

public class Vehicle {
    private String id;
    private String model;
    private boolean isAvailable;
    private List<Observer> observers;
    
    public Vehicle(String id, String model) {
        this.id = id;
        this.model = model;
        this.isAvailable = true;
        this.observers = new ArrayList<>();
    }
    
    public void addObserver(Observer observer) {
        observers.add(observer);
    }
    
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }
    
    public void setAvailability(boolean available) {
        this.isAvailable = available;
        notifyObservers();
    }
    
    private void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(this);
        }
    }
    
    public String getId() {
        return id;
    }
    
    public String getModel() {
        return model;
    }
    
    public boolean isAvailable() {
        return isAvailable;
    }
}