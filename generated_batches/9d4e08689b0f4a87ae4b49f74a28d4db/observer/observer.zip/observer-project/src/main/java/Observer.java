package fleetmanagement;

public interface Observer {
    void update(Vehicle vehicle);
}