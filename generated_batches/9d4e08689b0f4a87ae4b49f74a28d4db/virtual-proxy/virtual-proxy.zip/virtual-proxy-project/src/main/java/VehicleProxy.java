public class VehicleProxy implements VehicleServiceInterface {
    private VehicleService realService;
    private List<Vehicle> cachedVehicles;
    
    @Override
    public List<Vehicle> getAllVehicles() {
        if (cachedVehicles == null)