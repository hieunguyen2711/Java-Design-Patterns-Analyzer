import java.util.*;

public class VehicleService {
    private Map<String, Vehicle> vehicles;
    
    public VehicleService() {
        this.vehicles = new HashMap<>();
        // Initialize with some sample data
        vehicles.put("V001", new Vehicle("V001", "Toyota", "Camry", 2020, 45.0));
        vehicles.put("V002", new Vehicle("V002", "Honda", "Civic", 2019, 35.0));
        vehicles.put("V003", new Vehicle("V003", "Ford", "F-150", 2021, 65.0));
    }
    
    public List<Vehicle> getAllVehicles() {
        return new ArrayList<>(vehicles.values());
    }
    
    public Vehicle getVehicleById(String id) {
        return vehicles.get(id);
    }
}