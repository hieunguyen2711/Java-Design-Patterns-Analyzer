public interface MaintenanceService extends Service {
    void scheduleMaintenance(MaintenanceRecord record);
    void completeMaintenance(String recordId);
    MaintenanceRecord findMaintenanceByVin(String vin);
}