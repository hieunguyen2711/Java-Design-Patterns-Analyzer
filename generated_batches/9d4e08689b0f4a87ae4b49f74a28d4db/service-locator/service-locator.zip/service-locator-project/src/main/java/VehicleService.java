public interface VehicleService extends Service {
    void addVehicle(Vehicle vehicle);
    void removeVehicle(String vin);
    Vehicle findVehicleByVin(String vin);
}