import java.util.HashMap;
import java.util.Map;

public class VehicleServiceImpl implements VehicleService {
    private Map<String, Vehicle> vehicles = new HashMap<>();

    @Override
    public String getName() {
        return "VehicleService";
    }

    @Override
    public void addVehicle(Vehicle vehicle) {
        vehicles.put(vehicle.getVin(), vehicle);
    }

    @Override
    public void removeVehicle(String vin) {
        vehicles.remove(vin);
    }

    @Override
    public Vehicle findVehicleByVin(String vin) {
        return vehicles.get(vin);
    }
}