public interface ReservationService extends Service {
    void createReservation(Reservation reservation);
    void cancelReservation(String reservationId);
    Reservation findReservationById(String id);
}