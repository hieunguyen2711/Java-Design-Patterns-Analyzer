public class ServiceLocator {
    private static ServiceLocator instance;
    private Map<String, Object> services;

    private ServiceLocator() {
        services = new HashMap<>();
        loadServices();
    }

    public static synchronized ServiceLocator getInstance() {
        if (instance == null) {
            instance = new ServiceLocator();
        }
        return instance;
    }

    private void loadServices() {
        services.put("VehicleService", new VehicleServiceImpl());
        services.put("ReservationService", new ReservationServiceImpl());
        services.put("MaintenanceService", new MaintenanceServiceImpl());
    }

    public Object getService(String serviceName) {
        return services.get(serviceName);
    }
}