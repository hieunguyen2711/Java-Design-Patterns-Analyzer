import java.util.HashMap;
import java.util.Map;

public class ReservationServiceImpl implements ReservationService {
    private Map<String, Reservation> reservations = new HashMap<>();

    @Override
    public String getName() {
        return "ReservationService";
    }

    @Override
    public void createReservation(Reservation reservation) {
        reservations.put(reservation.getId(), reservation);