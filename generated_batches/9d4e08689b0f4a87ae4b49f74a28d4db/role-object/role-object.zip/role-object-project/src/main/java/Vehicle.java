package fleet;

public class Vehicle {
    private String id;
    private String make;
    private String model;
    private int year;
    private double dailyRate;
    private boolean isAvailable;
    private MaintenanceStatus maintenanceStatus;
    
    public Vehicle(String id, String make, String model, int year, double dailyRate) {
        this.id = id;
        this.make = make;
        this.model = model;
        this.year = year;
        this.dailyRate = dailyRate;
        this.isAvailable = true;
        this.maintenanceStatus = MaintenanceStatus.NORMAL;
    }
    
    public String getId() { return id; }
    public String getMake() { return make; }
    public String getModel() { return model; }
    public int getYear() { return year; }
    public double getDailyRate() { return dailyRate; }
    public boolean isAvailable() { return isAvailable; }
    public MaintenanceStatus getMaintenanceStatus() { return maintenanceStatus; }
    
    public void setAvailable(boolean available) { isAvailable = available; }
    public void setMaintenanceStatus(MaintenanceStatus status) { maintenanceStatus = status; }
}