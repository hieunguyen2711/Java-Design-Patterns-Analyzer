package fleet;

import java.util.*;

public class FleetManager {
    private Map<String, Vehicle> vehicles;
    
    public FleetManager() {
        this.vehicles = new HashMap<>();
    }
    
    public void addVehicle(Vehicle vehicle) {
        vehicles.put(vehicle.getId(), vehicle);
    }
    
    public List<Vehicle> getAvailableVehicles() {
        List<Vehicle> available = new ArrayList<>();
        for (Vehicle v : vehicles.values()) {
            if (v.isAvailable() && v.getMaintenanceStatus() == MaintenanceStatus.NORMAL) {
                available.add(v);
            }
        }
        return available;
    }
    
    public Vehicle findVehicle(String id) {
        return vehicles.get(id);
    }
}