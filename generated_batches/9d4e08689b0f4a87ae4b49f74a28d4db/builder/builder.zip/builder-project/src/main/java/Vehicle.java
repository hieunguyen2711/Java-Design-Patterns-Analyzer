package com.fleetmanager.model;

public class Vehicle {
    private final String make;
    private final String model;
    private final int year;
    private final String vin;
    private final double dailyRate;
    private final boolean isAvailable;
    private final String maintenanceStatus;
    
    private Vehicle(Builder builder) {
        this.make = builder.make;
        this.model = builder.model;
        this.year = builder.year;
        this.vin = builder.vin;
        this.dailyRate = builder.dailyRate;
        this.isAvailable = builder.isAvailable;
        this.maintenanceStatus = builder.maintenanceStatus;
    }
    
    public String getMake() {
        return make;
    }
    
    public String getModel() {
        return model;
    }
    
    public int getYear() {
        return year;
    }
    
    public String getVin() {
        return vin;
    }
    
    public double getDailyRate() {
        return dailyRate;
    }
    
    public boolean isAvailable() {
        return isAvailable;
    }
    
    public String getMaintenanceStatus() {
        return maintenanceStatus;
    }
    
    @Override
    public String toString() {
        return "Vehicle{" +
                "make='" + make + '\'' +
                ", model='" + model + '\'' +
                ", year=" + year +
                ", vin='" + vin + '\'' +
                ", dailyRate=" + dailyRate +
                ", isAvailable=" + isAvailable +
                ", maintenanceStatus='" + maintenanceStatus + '\'' +
                '}';
    }
    
    public static class Builder {
        private String make;
        private String model;
        private int year;
        private String vin;
        private double dailyRate;
        private boolean isAvailable = true;
        private String maintenanceStatus = "NONE";
        
        public Builder setMake(String make) {
            this.make = make;
            return this;
        }
        
        public Builder setModel(String model) {
            this.model = model;
            return this;
        }
        
        public Builder setYear(int year) {
            this.year = year;
            return this;
        }
        
        public Builder setVin(String vin) {
            this.vin = vin;
            return this;
        }
        
        public Builder setDailyRate(double dailyRate) {
            this.dailyRate = dailyRate;
            return this;
        }
        
        public Builder setIsAvailable(boolean isAvailable) {
            this.isAvailable = isAvailable;
            return this;
        }