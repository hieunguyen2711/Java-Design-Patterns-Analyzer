package fleet.inventory;

public interface MaintenanceEligible {
    // Marker interface - no methods to implement
    // Used to identify vehicles that are eligible for maintenance
}