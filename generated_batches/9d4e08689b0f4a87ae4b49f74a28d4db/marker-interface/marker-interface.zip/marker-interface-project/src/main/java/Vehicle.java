package fleet.inventory;

public abstract class Vehicle implements MaintenanceEligible {
    protected String make;
    protected String model;
    protected int year;
    protected double dailyRate;
    
    public Vehicle(String make, String model, int year, double dailyRate) {
        this.make = make;
        this.model = model;
        this.year = year;
        this.dailyRate = dailyRate;
    }
    
    // Getters and setters
    public String getMake() { return make; }
    public void setMake(String make) { this.make = make; }
    public String getModel() { return model; }
    public void setModel(String model) { this.model = model; }
    public int getYear() { return year; }
    public void setYear(int year) { this.year = year; }
    public double getDailyRate() { return dailyRate; }
    public void setDailyRate(double dailyRate) { this.dailyRate = dailyRate; }
    
    @Override
    public String toString() {
        return year + " " + make + " " + model;
    }
}