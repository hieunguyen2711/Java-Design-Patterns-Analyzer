package fleet.inventory;

public class Car extends Vehicle {
    private int numberOfDoors;
    
    public Car(String make, String model, int year, double dailyRate, int numberOfDoors) {
        super(make, model, year, dailyRate);
        this.numberOfDoors = numberOfDoors;
    }
    
    public int getNumberOfDoors() { return numberOfDoors; }
    public void setNumberOfDoors(int numberOfDoors) { this.numberOfDoors = numberOfDoors; }
}