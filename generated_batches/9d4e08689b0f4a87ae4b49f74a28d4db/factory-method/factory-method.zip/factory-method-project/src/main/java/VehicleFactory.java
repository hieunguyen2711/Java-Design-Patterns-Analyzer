public abstract class VehicleFactory {
    public abstract Vehicle createVehicle(String model, Object... params);
    
    public static VehicleFactory getFactory(String vehicleType) {
        switch (vehicleType.toLowerCase()) {
            case "car":
                return new CarFactory();
            case "truck":
                return new TruckFactory();
            case "motorcycle":
                return new Motorcycle