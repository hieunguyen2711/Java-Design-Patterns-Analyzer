public class Car implements Vehicle {
    private final String vehicleId;
    private final String model;
    private final double pricePerDay;
    private boolean available;

    public Car(String vehicleId, String model, double pricePerDay) {
        this.vehicleId = vehicleId;
        this.model = model;
        this.pricePerDay = pricePerDay;
        this.available = true;
    }

    @Override
    public String getVehicleId() {
        return vehicleId;
    }

    @Override
    public String getModel() {
        return model;
    }

    @Override
    public double getPricePerDay() {
        return pricePerDay;
    }

    @Override
    public boolean isAvailable() {
        return available;
    }

    @Override
    public void setAvailability(boolean available) {
        this.available = available;
    }
}