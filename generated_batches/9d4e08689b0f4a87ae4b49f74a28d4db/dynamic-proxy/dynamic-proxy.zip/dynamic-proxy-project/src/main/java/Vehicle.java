public interface Vehicle {
    String getVehicleId();
    String getModel();
    double getPricePerDay();
    boolean isAvailable();
    void setAvailability(boolean available);
}