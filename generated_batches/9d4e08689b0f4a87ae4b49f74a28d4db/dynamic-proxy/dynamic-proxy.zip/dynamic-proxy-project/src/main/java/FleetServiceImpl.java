import java.util.*;

public class FleetServiceImpl implements FleetService {
    private final Map<String, Vehicle> vehicles = new HashMap<>();
    
    public FleetServiceImpl() {
        // Initialize with some sample data
        vehicles.put("C001", new Car("C001", "Toyota Camry", 45.0));
        vehicles.put("C002", new Car("C002", "Honda Accord", 50.0));
        vehicles.put("C003", new Car("C003", "Ford Fusion", 40.0));
    }

    @Override
    public List<Vehicle> getAllVehicles() {
        return new ArrayList<>(vehicles.values());
    }

    @Override
    public Vehicle getVehicleById(String vehicleId) {
        return vehicles.get(vehicleId);
    }

    @Override
    public List<Vehicle> getAvailableVehicles() {
        return vehicles.values().stream()
                .filter(Vehicle::isAvailable)