import java.util.List;

public interface FleetService {
    List<Vehicle> getAllVehicles();
    Vehicle getVehicleById(String vehicleId);
    List<Vehicle> getAvailableVehicles();
    void reserveVehicle(String vehicleId);
    void returnVehicle(String vehicleId);
}