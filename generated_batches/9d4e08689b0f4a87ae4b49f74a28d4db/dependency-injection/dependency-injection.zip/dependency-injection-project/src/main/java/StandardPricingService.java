package fleetmanagement;

public class StandardPricingService implements PricingService {
    @Override
    public double calculateDailyRate(Vehicle vehicle) {
        // Simple pricing logic based on vehicle year
        if (vehicle.getYear() < 2010) {
            return 45.0;
        } else if (vehicle.getYear() < 2015) {
            return 65.0;
        } else {
            return 85.0;
        }
    }
}