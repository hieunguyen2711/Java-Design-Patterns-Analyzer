package fleetmanagement;

import java.util.HashMap;
import java.util.Map;

public class VehicleRepository {
    private Map<String, Vehicle> vehicles;
    
    public VehicleRepository() {
        this.vehicles = new HashMap<>();
    }
    
    public void addVehicle(Vehicle vehicle) {
        vehicles.put(vehicle.getId(), vehicle);
    }
    
    public Vehicle findVehicleById(String id) {
        return vehicles.get(id);
    }
}