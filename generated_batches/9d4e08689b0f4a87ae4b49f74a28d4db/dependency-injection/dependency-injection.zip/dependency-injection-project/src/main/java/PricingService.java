package fleetmanagement;

public interface PricingService {
    double calculateDailyRate(Vehicle vehicle);
}