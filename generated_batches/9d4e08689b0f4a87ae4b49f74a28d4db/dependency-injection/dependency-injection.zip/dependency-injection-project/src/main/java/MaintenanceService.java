package fleetmanagement;

public interface MaintenanceService {
    boolean isVehicleMaintained(Vehicle vehicle);
}