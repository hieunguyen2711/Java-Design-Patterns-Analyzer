package fleetmanagement;

public class FleetManager {
    private VehicleRepository repository;
    private PricingService pricingService;
    private MaintenanceService maintenance