package com.fleet.service;

import java.util.HashMap;
import java.util.Map;

public class FleetServiceImpl implements FleetService {
    private final Map<String, Boolean> availabilityMap = new HashMap<>();
    private final Map<String, Double> pricingMap = new HashMap<>();

    public FleetServiceImpl() {
        // Initialize with sample data
        availabilityMap.put("V001", true);
        availabilityMap.put("V002", false);
        availabilityMap.put("V003", true);
        
        pricingMap.put("V001", 50.0);
        pricingMap.put("V002", 75.0);
        pricingMap.put("V003", 60.0);
    }

    @Override
    public boolean isVehicleAvailable(String vehicleId) {
        return availabilityMap.getOrDefault(vehicleId, false);
    }

    @Override
    public void reserveVehicle(String vehicleId) {
        if (availabilityMap.containsKey(vehicleId)) {
            availabilityMap.put(vehicleId, false);
        }
    }

    @Override
    public void returnVehicle(String vehicleId) {
        if (availabilityMap.containsKey(vehicleId)) {
            availabilityMap.put(vehicleId, true);
        }
    }

    @Override
    public double calculateRentalCost(String vehicleId, int days) {
        Double dailyRate = pricingMap.get(vehicleId);
        if (dailyRate != null) {
            return dailyRate * days;
        }
        return 0.0;
    }
}