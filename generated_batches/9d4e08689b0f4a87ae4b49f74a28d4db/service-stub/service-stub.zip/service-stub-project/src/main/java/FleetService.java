package com.fleet.service;

public interface FleetService {
    boolean isVehicleAvailable(String vehicleId);
    void reserveVehicle(String vehicleId);
    void returnVehicle(String vehicleId);
    double calculateRentalCost(String vehicleId, int days);
}