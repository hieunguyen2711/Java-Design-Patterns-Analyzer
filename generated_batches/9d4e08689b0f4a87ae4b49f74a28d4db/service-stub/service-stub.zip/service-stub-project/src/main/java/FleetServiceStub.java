package com.fleet.service;

public class FleetServiceStub implements FleetService {
    
    @Override
    public boolean isVehicleAvailable(String vehicleId) {
        // Stub implementation - always returns true for testing
        return true;
    }

    @Override
    public void reserveVehicle(String vehicleId) {
        // Stub implementation - does nothing
    }

    @Override
    public void returnVehicle(String vehicleId) {
        // Stub implementation - does nothing
    }

    @Override
    public double calculateRentalCost(String vehicleId, int days)