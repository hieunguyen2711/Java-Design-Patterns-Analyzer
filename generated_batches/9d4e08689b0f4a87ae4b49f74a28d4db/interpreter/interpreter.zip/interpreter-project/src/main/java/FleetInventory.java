package fleet;

import java.util.List;
import java.util.ArrayList;

public class FleetInventory {
    private List<Vehicle> vehicles;
    
    public FleetInventory() {
        this.vehicles = new ArrayList<>();
    }
    
    public void addVehicle(Vehicle vehicle) {
        vehicles.add(vehicle);
    }
    
    public List<Vehicle> getVehicles() {
        return vehicles;
    }
}