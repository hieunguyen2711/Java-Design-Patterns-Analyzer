package fleet;

public class Vehicle {
    private String id;
    private String model;
    private double dailyRate;
    private boolean isAvailable;
    private MaintenanceStatus maintenanceStatus;
    
    public Vehicle(String id, String model, double dailyRate) {
        this.id = id;
        this.model = model;
        this.dailyRate = dailyRate;
        this.isAvailable = true;
        this.maintenanceStatus = MaintenanceStatus.NORMAL;
    }
    
    // Getters and setters
    public String getId() { return id; }
    public String getModel() { return model; }
    public double getDailyRate() { return dailyRate; }
    public boolean isAvailable() { return isAvailable; }
    public void setAvailable(boolean available) { isAvailable = available; }
    public MaintenanceStatus getMaintenanceStatus() { return maintenanceStatus; }
    public void setMaintenanceStatus(MaintenanceStatus status) { maintenanceStatus = status; }
}