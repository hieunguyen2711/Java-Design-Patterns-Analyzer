package fleet;

public enum MaintenanceStatus {
    NORMAL, MAINTENANCE, OUT_OF_SERVICE
}