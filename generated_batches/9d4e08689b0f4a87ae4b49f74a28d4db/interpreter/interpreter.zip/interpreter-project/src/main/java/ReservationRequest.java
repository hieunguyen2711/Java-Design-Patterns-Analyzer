package fleet;

import java.time.LocalDate;
import java.util.List;

public class ReservationRequest {
    private String customerId;
    private LocalDate pickupDate;
    private LocalDate returnDate;
    private List<String> vehicleIds;
    
    public ReservationRequest(String customerId, LocalDate pickupDate, 
                            LocalDate returnDate, List<String> vehicleIds) {
        this.customerId = customerId;
        this.pickupDate = pickupDate;
        this.returnDate = returnDate;
        this.vehicleIds = vehicleIds;
    }
    
    // Getters
    public String getCustomerId() { return customerId; }
    public LocalDate getPickupDate() { return pickupDate; }
    public LocalDate getReturnDate() { return returnDate; }
    public List<String> getVehicleIds() { return vehicleIds; }
}