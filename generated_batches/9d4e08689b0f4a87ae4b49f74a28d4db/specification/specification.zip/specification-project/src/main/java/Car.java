package fleetmanagement;

public class Car extends Vehicle {
    private int numberOfDoors;
    
    public Car(String id, String model, double dailyRate) {
        super(id, model, dailyRate);
        this.numberOfDoors = 4;
    }
    
    public int getNumberOfDoors() { return numberOfDoors; }
    public void setNumberOfDoors(int numberOfDoors) { this.numberOfDoors = numberOfDoors; }
}