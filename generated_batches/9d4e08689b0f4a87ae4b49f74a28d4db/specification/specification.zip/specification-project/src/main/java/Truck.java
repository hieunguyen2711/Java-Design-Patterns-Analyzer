package fleetmanagement;

public class Truck extends Vehicle {
    private double cargoCapacity;
    
    public Truck(String id, String model, double dailyRate) {
        super(id, model, dailyRate);
        this.cargoCapacity = 1000.0; // in kg
    }
    
    public double getCargoCapacity() { return cargoCapacity; }
    public