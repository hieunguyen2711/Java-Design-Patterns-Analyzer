package fleetmanagement;

public class VehicleFactory {
    public static Vehicle createVehicle(String type, String id, String model, double dailyRate) {
        switch (type.toLowerCase()) {
            case "car":
                return new Car(id, model, dailyRate);
            case "truck":
                return new Truck(id, model, dailyRate);
            case "suv":
                return new SUV(id, model, dailyRate);
            default:
                throw new IllegalArgumentException("Unknown vehicle type: " + type);
        }
    }
}