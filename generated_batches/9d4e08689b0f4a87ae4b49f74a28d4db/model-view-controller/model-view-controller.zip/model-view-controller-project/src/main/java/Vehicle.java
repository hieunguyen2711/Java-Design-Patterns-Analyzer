public class Vehicle {
    private String make;
    private String type;
    private int year;
    
    public Vehicle(String make, String type, int year) {
        this.make = make;
        this.type = type;
        this.year = year;
    }
    
    public String getMake() {
        return make;
    }
    
    public String getType() {
        return type;
    }
    
    public int getYear() {
        return year;
    }
}