public class FleetInventoryApp {
    public static void main(String[] args) {
        // Create the model
        VehicleModel model = new VehicleModel();
        
        // Create views
        VehicleListView listView = new VehicleListView();
        VehicleDetailsView detailsView = new VehicleDetailsView();
        
        // Create controller
        FleetController controller = new FleetController(model, listView, detailsView);
        
        // Initialize with some data
        controller.addVehicle("Toyota Camry", "Sedan", 2020);
        controller.addVehicle("Ford F-150", "Truck", 2019);
        controller.addVehicle("Honda Civic", "Sedan", 2021);
        
        // Display all vehicles
        controller.displayAllVehicles();
        
        // Show details of first vehicle
        controller.showVehicleDetails(0);
    }
}