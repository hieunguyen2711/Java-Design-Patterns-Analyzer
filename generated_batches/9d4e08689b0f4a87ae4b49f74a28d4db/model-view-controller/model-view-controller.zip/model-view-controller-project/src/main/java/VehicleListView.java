import java.util.List;

public class VehicleListView {
    public void displayVehicles(List<Vehicle> vehicles) {
        System.out.println("=== Fleet Inventory ===");
        for (int i = 0; i < vehicles.size(); i++) {
            Vehicle vehicle = vehicles.get(i);
            System.out.printf("%d. %