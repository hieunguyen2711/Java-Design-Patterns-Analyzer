import java.util.ArrayList;
import java.util.List;

public class VehicleModel {
    private List<Vehicle> vehicles;
    
    public VehicleModel() {
        this.vehicles = new ArrayList<>();
    }
    
    public void addVehicle(String make, String type, int year) {
        vehicles.add(new Vehicle(make, type, year));
    }
    
    public List<Vehicle> getVehicles() {
        return vehicles;
    }
    
    public Vehicle getVehicle(int index) {
        return vehicles.get(index);
    }
    
    public int getVehicleCount() {
        return vehicles.size();
    }
}