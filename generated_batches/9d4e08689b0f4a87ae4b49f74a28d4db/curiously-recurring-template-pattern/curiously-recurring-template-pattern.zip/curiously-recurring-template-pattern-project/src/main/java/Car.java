package fleet.inventory;

public class Car extends Vehicle {
    
    public Car(String make, String model, int year, double basePrice) {
        super(make, model, year, basePrice);
    }
    
    @Override
    public double calculateValue() {
        return basePrice * 0.8;
    }
}