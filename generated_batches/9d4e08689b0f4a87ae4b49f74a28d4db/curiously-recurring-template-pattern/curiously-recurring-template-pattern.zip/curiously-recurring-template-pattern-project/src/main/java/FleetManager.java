package fleet.inventory;

public class FleetManager {
    private static final int MAX_VEHICLES = 100;
    private Vehicle[] vehicles = new Vehicle[MAX_VEHICLES];
    private int vehicleCount = 0;
    
    public <T extends Vehicle> void addVehicle(T vehicle) {
        if (vehicleCount < MAX_VEHICLES) {
            vehicles[vehicleCount++] = vehicle;
        }
    }
    
    public double getTotalFleetValue() {
        double totalValue = 0.0;
        for (int i = 0; i < vehicleCount; i++) {
            totalValue += vehicles[i].calculateValue();
        }
        return totalValue;
    }
}