package fleet.inventory;

public abstract class Vehicle {
    protected String make;
    protected String model;
    protected int year;
    protected double basePrice;
    
    public Vehicle(String make, String model, int year, double basePrice) {
        this.make = make;
        this.model = model;
        this.year = year;
        this.basePrice = basePrice;
    }
    
    public abstract double calculateValue();
    
    public String getMake() { return make; }
    public String getModel() { return model; }
    public int getYear() { return year; }
    public double getBasePrice() { return basePrice; }
}