package fleet.inventory;

public class Truck extends Vehicle {
    
    public Truck(String make, String model, int year, double basePrice) {
        super(make, model, year, basePrice);
    }
    
    @Override
    public double calculateValue() {
        return basePrice * 0.6;
    }
}