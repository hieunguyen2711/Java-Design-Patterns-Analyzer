package fleet;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;

public class FleetManager {
    private final BlockingQueue<VehicleRequest> requestQueue = new LinkedBlockingQueue<>();
    private final AtomicBoolean isRunning = new AtomicBoolean(true);
    
    public void submitRequest(VehicleRequest request) throws InterruptedException {
        requestQueue.put(request);
    }
    
    public VehicleRequest getNextRequest() throws InterruptedException {
        return requestQueue.take();
    }
    
    public boolean isRunning() {
        return isRunning.get();
    }
    
    public void stop() {
        isRunning.set(false);
    }
}