package fleet;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;

public class VehicleRequest {
    private final String vehicleType;
    private final int durationHours;
    private final Future<Vehicle> responseFuture;
    
    public VehicleRequest(String vehicleType, int durationHours) {
        this.vehicleType = vehicleType;
        this.durationHours = durationHours;
        this.responseFuture = new CompletableFuture<>();
    }
    
    public String getVehicleType() {
        return vehicleType;
    }
    
    public int getDurationHours() {
        return durationHours;
    }
    
    public Future<Vehicle> getResponseFuture() {
        return responseFuture;
    }
    
    public void completeWith(Vehicle vehicle) {
        ((CompletableFuture<Vehicle>) responseFuture).complete(vehicle);
    }
}