package fleet;

public class Vehicle {
    private final String id;
    private final String type;
    private boolean isAvailable;
    private int maintenanceHoursRemaining;
    
    public Vehicle(String id, String type) {
        this.id = id;
        this.type = type;
        this.isAvailable = true;
        this.maintenanceHoursRemaining = 100; // Starting with 100 hours
    }
    
    public String getId() {
        return id;
    }
    
    public String getType() {
        return type;
    }
    
    public boolean isAvailable() {
        return isAvailable;
    }
    
    public void setAvailable(boolean available) {
        isAvailable = available;
    }
    
    public int getMaintenanceHoursRemaining() {
        return maintenanceHoursRemaining;
    }
    
    public void decrementMaintenanceHours(int hours) {
        maintenanceHoursRemaining -= hours