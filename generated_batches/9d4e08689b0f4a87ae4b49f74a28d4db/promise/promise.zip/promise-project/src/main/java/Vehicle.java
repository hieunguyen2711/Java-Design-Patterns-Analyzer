package com.fleetmanager;

public class Vehicle {
    private final String id;
    private final String make;
    private final String model;
    private final int year;
    private boolean reserved;
    private MaintenanceStatus maintenanceStatus;
    
    public Vehicle(String id, String make,