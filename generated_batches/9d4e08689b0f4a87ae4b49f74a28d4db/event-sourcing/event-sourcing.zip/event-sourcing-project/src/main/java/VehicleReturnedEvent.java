public class VehicleReturnedEvent extends Event {
    private final String vehicleId;
    private final String reservationId;
    private final long actualReturnTime;
    private final double mileage;
    
    public Vehicle