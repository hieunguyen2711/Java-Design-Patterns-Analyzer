public class VehicleRegisteredEvent extends Event {
    private final String vehicleId;
    private final String make;
    private final String model;
    private final int year;
    
    public VehicleRegisteredEvent(String vehicleId, String make, String model, int year) {
        this.vehicleId = vehicleId;
        this.make = make;
        this.model = model;
        this.year = year;
    }
    
    public String getVehicleId() {
        return vehicleId;
    }
    
    public String getMake() {
        return make;
    }
    
    public String getModel() {
        return model;
    }
    
    public int getYear() {
        return year;
    }
    
    @Override
    public String getType() {
        return "VEHICLE_REGISTERED";
    }
}