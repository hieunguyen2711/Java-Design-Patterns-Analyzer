public class VehicleReservedEvent extends Event {
    private final String vehicleId;
    private final String reservationId;
    private final String customerId;
    private final long pickupTime;
    private final long returnTime;
    
    public VehicleReservedEvent(String vehicleId, String reservationId, String customerId, 
                               long pickupTime, long returnTime) {
        this.vehicleId = vehicleId;
        this.reservationId = reservationId;
        this.customerId = customerId;
        this.pickupTime = pickupTime;
        this.returnTime = returnTime;
    }
    
    public String getVehicleId() {
        return vehicleId;
    }
    
    public String getReservationId() {
        return reservationId;
    }
    
    public String getCustomerId() {
        return customerId;
    }
    
    public long getPickupTime() {
        return pickupTime;
    }
    
    public long getReturnTime() {
        return returnTime;
    }
    
    @Override
    public String getType() {
        return "VEHICLE_RESERVED";
    }
}