package com.fleetmanager.registry;

import com.fleetmanager.model.Vehicle;
import java.util.HashMap;
import java.util.Map;

public class VehiclePrototypeRegistry {
    private static final Map<String, Vehicle> prototypes = new HashMap<>();
    
    static {
        // Register prototype vehicles
        prototypes.put("Sedan", new Vehicle("SED-001", "Toyota", "Camry", 2022, 50.0));
        prototypes.put("SUV", new Vehicle("SUV-001", "Honda", "CR-V", 2023, 75.0));
        prototypes.put("Truck", new Vehicle("TRK-001", "Ford", "F-150", 2022, 85.0));
    }
    
    public static Vehicle getVehiclePrototype(String type) {
        try