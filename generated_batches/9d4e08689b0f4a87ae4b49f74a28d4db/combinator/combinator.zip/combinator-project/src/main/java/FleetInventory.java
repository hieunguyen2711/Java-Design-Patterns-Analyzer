package com.fleetmanager.inventory;

import com.fleetmanager.vehicle.Vehicle;
import java.util.*;

public class FleetInventory {
    private Map<String, Vehicle> vehicles;
    
    public FleetInventory() {
        this.vehicles = new HashMap<>();
    }
    
    public void addVehicle(Vehicle vehicle) {
        vehicles.put(vehicle.getId(), vehicle);
    }
    
    public Vehicle getVehicle(String id) {
        return vehicles.get(id);
    }
    
    public Collection<Vehicle> getAllVehicles() {
        return vehicles.values();
    }
    
    public List<Vehicle> filterByType(VehicleType type) {
        return vehicles.values().stream()
                .filter(v -> isOfType(v, type))
                .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }
    
    private boolean isOfType(Vehicle vehicle, VehicleType type) {
        // Simple implementation for demonstration
        switch (type) {
            case SEDAN: return vehicle.getModel().contains("Sedan");
            case SUV