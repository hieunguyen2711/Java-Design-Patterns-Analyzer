package com.fleetmanager.vehicle;

public enum VehicleType {
    SEDAN,
    SUV,
    TRUCK,
    VAN,
    SPORTS_CAR
}