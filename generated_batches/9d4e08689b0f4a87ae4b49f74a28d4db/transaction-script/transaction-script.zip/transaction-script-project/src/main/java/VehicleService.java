public class VehicleService {
    
    public void createReservation(String vehicleId, String customerName, 
                                 String startDate, String endDate) {
        // Transaction script for creating reservation
        System.out.println("Creating reservation for " + customerName);
        System.out.println("Vehicle ID: " + vehicleId);
        System.out.println("Start Date: " + startDate);
        System.out.println("End Date: " + endDate);
        
        // Business logic here
        Reservation reservation = new Reservation(vehicleId, customerName, startDate, endDate);
        ReservationDAO.save(reservation);
        System.out.println("Reservation created successfully");
    }
    
    public void processPickup(String vehicleId, String customerName) {
        // Transaction script for processing pickup
        System.out.println("Processing pickup for " + customerName);
        System.out.println("Vehicle ID: " + vehicleId);
        
        // Business logic here
        Vehicle vehicle = VehicleDAO.find(vehicleId);
        if (vehicle != null && !vehicle.isAvailable()) {
            vehicle.setPickupDate(java.time.LocalDate.now().toString());
            VehicleDAO.update(vehicle);
            System.out.println("Vehicle picked up successfully");
        } else {
            System.out.println("Vehicle not available for pickup");
        }
    }
    
    public void processReturn(String vehicleId, String customerName) {
        // Transaction script for processing return
        System.out.println("Processing return for " + customerName);
        System.out.println("Vehicle ID: " + vehicleId);
        
        // Business logic here
        Vehicle vehicle = VehicleDAO.find(vehicleId);
        if (vehicle != null && vehicle.isAvailable()) {
            vehicle.setReturnDate(java.time.LocalDate.now().toString());
            vehicle.setAvailable(true);
            VehicleDAO.update(vehicle);
            System.out.println("Vehicle returned successfully");
        } else {
            System