public class FleetManagementSystem {
    public static void main(String[] args) {
        VehicleService service = new VehicleService();
        
        // Create a reservation
        service.createReservation("V001", "John Doe", "2023-12-01", "2023-12-05");
        
        // Process vehicle pickup
        service.processPickup("V001", "John Doe");
        
        // Process vehicle return
        service.processReturn("V001", "John Doe");
    }
}