package fleet;

public class Truck extends Vehicle {
    private int cargoCapacity;
    
    public Truck(String id, String make, String model, int year, int cargoCapacity) {
        super(id, make, model, year);
        this.cargoCapacity = cargoCapacity;
    }
    
    @Override
    public double calculateRentalRate() {
        return 50.0 + (cargoCapacity * 0.5);
    }
    
    public int getCargoCapacity() {
        return cargoCapacity;
    }
}