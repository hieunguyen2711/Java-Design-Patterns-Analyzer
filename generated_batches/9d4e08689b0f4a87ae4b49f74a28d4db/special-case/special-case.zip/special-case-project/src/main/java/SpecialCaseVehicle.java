package fleet;

public class SpecialCaseVehicle extends Vehicle {
    private String specialDescription;
    
    public SpecialCaseVehicle(String id, String make, String model, int year, String specialDescription) {
        super(id, make, model, year);
        this.specialDescription = specialDescription;
    }
    
    @Override
    public double calculateRentalRate() {
        return 100.0; // Fixed rate for special cases
    }
    
    public String getSpecialDescription() {
        return specialDescription;
    }
}