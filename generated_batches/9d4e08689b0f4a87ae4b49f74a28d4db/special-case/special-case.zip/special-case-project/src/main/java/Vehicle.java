package fleet;

public abstract class Vehicle {
    protected String id;
    protected String make;
    protected String model;
    protected int year;
    
    public Vehicle(String id, String make, String model, int year) {
        this.id = id;
        this.make = make;
        this.model = model;
        this.year = year;
    }
    
    public abstract double calculateRentalRate();
    
    public String getId() {
        return id;
    }
    
    public String getMake() {
        return make;
    }
    
    public String getModel() {
        return model;
    }
    
    public int getYear() {
        return year;
    }
}