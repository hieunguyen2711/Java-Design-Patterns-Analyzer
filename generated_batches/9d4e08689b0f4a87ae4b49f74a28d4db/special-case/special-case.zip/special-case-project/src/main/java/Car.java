package fleet;

public class Car extends Vehicle {
    private boolean isElectric;
    
    public Car(String id, String make, String model, int year, boolean isElectric) {
        super(id, make, model, year);
        this.isElectric = isElectric;
    }
    
    @Override
    public double calculateRentalRate() {
        return isElectric ? 45.0 : 35.0;
    }
    
    public boolean isElectric() {
        return isElectric;
    }
}