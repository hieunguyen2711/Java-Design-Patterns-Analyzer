package fleet.inventory;

public class VehicleViewHelper {
    private Vehicle vehicle;
    
    public VehicleViewHelper(Vehicle vehicle) {
        this.vehicle = vehicle;
    }
    
    public String getFormattedDisplay() {
        return String.format("%s %s %d - $%.2f/day", 
                           vehicle.getMake(), 
                           vehicle.getModel(), 
                           vehicle.getYear(),
                           vehicle.getDailyRate());
    }
    
    public String getStatusText() {
        return vehicle.isAvailable() ? "Available" : "Reserved";
    }
    
    public String getVehicleId() {
        return vehicle.getId();
    }
}