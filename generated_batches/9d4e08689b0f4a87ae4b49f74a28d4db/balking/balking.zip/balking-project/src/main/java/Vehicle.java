package com.fleetmanager;

import java.util.concurrent.atomic.AtomicBoolean;

public class Vehicle {
    private final String id;
    private final AtomicBoolean isReserved = new AtomicBoolean(false);
    
    public Vehicle(String id) {
        this.id = id;
    }
    
    public void reserve() {
        isReserved.set(true);
    }
    
    public boolean isReserved() {
        return isReserved.get();
    }
    
    public String getId() {
        return id;
    }
}