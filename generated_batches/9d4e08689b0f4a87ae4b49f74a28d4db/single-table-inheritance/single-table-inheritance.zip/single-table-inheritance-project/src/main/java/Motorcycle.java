package fleet.inventory;

public class Motorcycle extends Vehicle {
    private boolean