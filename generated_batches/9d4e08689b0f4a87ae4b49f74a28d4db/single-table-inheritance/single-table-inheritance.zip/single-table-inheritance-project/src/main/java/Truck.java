package fleet.inventory;

public class Truck extends Vehicle {
    private double cargoCapacity;
    
    public Truck(String make, String model, int year, double dailyRate, double cargoCapacity) {
        super(make, model, year, dailyRate);
        this.cargoCapacity = cargoCapacity;
    }
    
    @Override
    public String getVehicleType() {
        return "Truck";
    }
    
    // Getters and setters
    public double getCargoCapacity() { return cargoCapacity; }
    public void setCargoCapacity(double cargoCapacity) { this.cargoCapacity = cargoCapacity; }
}