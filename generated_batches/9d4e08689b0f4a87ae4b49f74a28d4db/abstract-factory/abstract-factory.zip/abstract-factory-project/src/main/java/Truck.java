public class Truck implements Vehicle {
    private final String type = "Truck";
    private final double basePrice = 80.0;
    private final int capacity = 2;

    @Override
    public String getType() {
        return type;
    }

    @Override
    public double getBasePrice() {
        return basePrice;
    }

    @Override
    public int getCapacity() {
        return capacity;
    }
}