public class FleetInventoryManager {
    private final VehicleFactory vehicleFactory;

    public FleetInventoryManager(VehicleFactory vehicleFactory) {
        this.vehicleFactory = vehicleFactory;
    }

    public void displayVehicleInfo() {
        Vehicle vehicle = vehicleFactory.createVehicle();
        System.out.println("Vehicle Type: " + vehicle.getType());
        System.out.println("Base Price: $" + vehicle.getBasePrice());
        System.out.println("Capacity: " + vehicle.getCapacity() + " passengers");
    }
}