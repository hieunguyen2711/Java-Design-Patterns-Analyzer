public class Car implements Vehicle {
    private final String type = "Car";
    private final double basePrice = 50.0;
    private final int capacity = 4;

    @Override
    public String getType() {
        return type;
    }

    @Override
    public double getBasePrice() {
        return basePrice;
    }

    @Override
    public int getCapacity() {
        return capacity;
    }
}