public interface VehicleFactory {
    Vehicle createVehicle();
    String getVehicleType();
}