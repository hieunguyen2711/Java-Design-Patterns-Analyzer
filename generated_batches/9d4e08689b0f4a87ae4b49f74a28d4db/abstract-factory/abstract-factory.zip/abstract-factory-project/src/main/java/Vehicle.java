public interface Vehicle {
    String getType();
    double getBasePrice();
    int getCapacity();
}