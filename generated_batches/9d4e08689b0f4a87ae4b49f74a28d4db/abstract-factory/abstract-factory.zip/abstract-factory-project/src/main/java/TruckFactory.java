public class TruckFactory implements VehicleFactory {
    @Override
    public Vehicle createVehicle() {
        return new Truck();
    }

    @Override
    public String getVehicleType() {
        return "Truck";
    }
}