package fleetmanagement;

import java.util.*;

public class VehicleRepository {
    private Map<String, Vehicle> vehicles;
    
    public VehicleRepository() {
        this.vehicles = new HashMap<>();
    }
    
    public void save(Vehicle vehicle) {
        vehicles.put(vehicle.getId(), vehicle);
    }
    
    public void delete(String id) {
        vehicles.remove(id);
    }
    
    public Vehicle findById(String id) {
        return vehicles.get(id);
    }
    
    public List<Vehicle> findAll() {
        return new ArrayList<>(vehicles.values());
    }
}