package fleetmanagement;

import java.util.*;

public class UnitOfWork {
    private Map<String, Vehicle> addedEntities;
    private Map<String, Vehicle> updatedEntities;
    private Set<String> deletedEntities;
    private VehicleRepository repository;
    
    public UnitOfWork(VehicleRepository repository) {
        this.repository = repository;
        this.addedEntities = new HashMap<>();
        this.updatedEntities = new HashMap<>();
        this.deletedEntities = new HashSet<>();
    }
    
    public void registerAdded(Vehicle vehicle) {
        addedEntities.put(vehicle.getId(), vehicle);
    }
    
    public void registerUpdated(Vehicle vehicle) {
        updatedEntities.put(vehicle.getId(), vehicle);
    }
    
    public void register