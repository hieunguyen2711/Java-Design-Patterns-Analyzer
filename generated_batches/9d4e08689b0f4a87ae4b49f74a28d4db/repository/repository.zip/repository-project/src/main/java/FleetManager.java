import java.util.List;
import java.util.Optional;

public class FleetManager {
    private