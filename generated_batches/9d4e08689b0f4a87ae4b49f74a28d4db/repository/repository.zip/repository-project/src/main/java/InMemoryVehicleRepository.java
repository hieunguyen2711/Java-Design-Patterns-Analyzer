import java.util.*;
import java.util.stream.Collectors;

public class InMemoryVehicleRepository implements VehicleRepository {
    private final Map<String, Vehicle> vehicles = new HashMap<>();
    
    @Override
    public Optional<Vehicle> findById(String id) {
        return Optional.ofNullable(vehicles.get(id));
    }
    
    @Override
    public List<Vehicle> findAll() {
        return new ArrayList<>(vehicles.values());
    }
    
    @Override
    public List<Vehicle> findByMake(String make) {
        return vehicles.values().stream()
                .filter(vehicle -> vehicle.getMake().equalsIgnoreCase(make))
                .collect(Collectors.toList());
    }
    
    @Override
    public void save(Vehicle vehicle) {
        vehicles.put(vehicle.getId(), vehicle);
    }
    
    @Override
    public void delete(String id) {
        vehicles.remove(id);
    }
}