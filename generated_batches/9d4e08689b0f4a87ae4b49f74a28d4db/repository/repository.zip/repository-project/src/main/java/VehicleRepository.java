import java.util.*;
import java.util.stream.Collectors;

public interface VehicleRepository {
    Optional<Vehicle> findById(String id);
    List<Vehicle> findAll();
    List<Vehicle> findByMake(String make);
    void save(Vehicle vehicle);
    void delete(String id);
}