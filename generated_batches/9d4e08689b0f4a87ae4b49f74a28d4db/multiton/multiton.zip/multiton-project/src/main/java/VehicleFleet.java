public class VehicleFleet {
    private static final int FLEET_SIZE = 3;
    private static VehicleFleet[] instances = new VehicleFleet[FLEET_SIZE];
    
    private String fleetName;
    private int fleetId;
    
    private VehicleFleet(int fleetId) {
        this.fleetId = fleetId;
        this.fleetName = "Fleet-" + fleetId;
    }
    
    public static synchronized VehicleFleet getInstance(int fleetId) {
        if (fleetId < 0 || fleetId >= FLEET_SIZE) {
            throw new IllegalArgumentException("Invalid fleet ID: " + fleetId);
        }
        
        if (instances[fleetId] == null) {
            instances[fleetId] = new VehicleFleet(fleetId);
        }
        
        return instances[fleetId];
    }
    
    public String getFleetName() {
        return fleetName;
    }
    
    public int getFleetId() {
        return fleetId;
    }
}