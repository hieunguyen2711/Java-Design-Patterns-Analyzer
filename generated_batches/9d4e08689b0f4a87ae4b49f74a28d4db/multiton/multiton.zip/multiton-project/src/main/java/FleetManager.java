public class FleetManager {
    private static final int MAX_FLEETS = 3;
    
    public void manageFleets() {
        // Demonstrating multiton pattern - only 3 instances allowed
        VehicleFleet fleet1 = VehicleFleet.getInstance(0);
        VehicleFleet fleet2 = VehicleFleet.getInstance(1);
        VehicleFleet fleet3 = VehicleFleet.getInstance(2);
        
        // Requesting same instance again
        VehicleFleet fleet1Again = VehicleFleet.getInstance(0);
        
        System.out.println("Fleet 1 name: " + fleet1.getFleetName());
        System.out.println("Fleet 2 name: " + fleet2.getFleetName());
        System.out.println("Fleet 3 name: " + fleet3.getFleetName());
        System.out.println("Same instance? " + (fleet1 == fleet1Again));
        
        // This would throw an exception
        try {
            VehicleFleet invalid = VehicleFleet.getInstance(5);
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    
    public static void main(String[] args) {
        new FleetManager().manageFleets();
    }
}