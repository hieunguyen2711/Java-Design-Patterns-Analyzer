package fleetmanagement;

public class Vehicle {
    private String id;
    private String model;
    private double dailyRate;
    private boolean isAvailable;
    private MaintenanceStatus maintenanceStatus;
    
    public Vehicle(String id, String model, double dailyRate) {
        this.id = id;
        this.model = model;
        this.dailyRate = dailyRate;
        this.isAvailable = true;
        this.maintenanceStatus = MaintenanceStatus.NONE;
    }
    
    public void updateAvailability(boolean available) {
        this.isAvailable = available;
    }
    
    public void updateMaintenanceStatus(MaintenanceStatus status) {
        this.maintenanceStatus = status;
    }
    
    public void updateDailyRate(double newRate) {
        this.dailyRate = newRate;
    }
    
    // Getters
    public String getId() { return id; }
    public String getModel() { return model; }
    public double getDailyRate() { return dailyRate; }
    public boolean isAvailable() { return isAvailable; }
    public MaintenanceStatus getMaintenanceStatus() { return maintenanceStatus; }
}