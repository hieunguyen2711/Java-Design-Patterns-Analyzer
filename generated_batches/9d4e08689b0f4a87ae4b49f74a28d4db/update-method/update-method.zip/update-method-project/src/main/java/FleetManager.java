package fleetmanagement;

import java.util.ArrayList;
import java.util.List;

public class FleetManager {
    private List<Vehicle> vehicles;
    
    public FleetManager() {
        this.vehicles = new ArrayList<>();
    }
    
    public void addVehicle(Vehicle vehicle) {
        vehicles.add(vehicle);
    }
    
    public void updateVehicleAvailability(String vehicleId, boolean available) {
        for (Vehicle vehicle : vehicles) {
            if (vehicle.getId().equals(vehicleId)) {
                vehicle.updateAvailability(available);
                break;
            }
        }
    }
    
    public void updateVehicleMaintenanceStatus(String vehicleId, MaintenanceStatus status) {
        for (Vehicle vehicle : vehicles) {
            if (vehicle.getId().equals(vehicleId)) {
                vehicle.updateMaintenanceStatus(status);
                break;
            }
        }
    }
    
    public void updateVehicleRate(String vehicleId, double newRate) {
        for (Vehicle vehicle : vehicles) {
            if (vehicle.getId().equals(vehicleId)) {
                vehicle.updateDailyRate(newRate);
                break;
            }
        }
    }
    
    public List<Vehicle> getAvailableVehicles() {
        List<Vehicle> available = new ArrayList<>();
        for (Vehicle vehicle : vehicles) {
            if (vehicle.isAvailable()) {
                available.add(vehicle);
            }
        }