package com.fleetmanager.model;

public class VehicleBuilder {
    private String vin;
    private String make;
    private String model;
    private int year;
    private String type;
    
    public VehicleBuilder setVin(String vin) {
        this.vin = vin;
        return this;
    }
    
    public VehicleBuilder setMake(String make) {
        this.make = make;
        return this;
    }
    
    public VehicleBuilder setModel(String model) {
        this.model = model;
        return this;
    }
    
    public VehicleBuilder setYear(int year) {
        this.year = year;
        return this;
    }
    
    public VehicleBuilder setType(String type) {
        this.type = type;
        return this;
    }
    
    public Vehicle build() {
        return new Vehicle(vin, make