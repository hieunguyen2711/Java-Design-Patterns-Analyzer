package fleet.inventory;

import java.util.*;
import java.util.stream.Collectors;

public class FleetInventory {
    private List<Vehicle> vehicles;
    
    public FleetInventory() {
        this.vehicles = new ArrayList<>();
    }
    
    public void addVehicle(Vehicle vehicle) {
        vehicles.add(vehicle);
    }
    
    public List<Vehicle> getAvailableVehicles() {
        return vehicles.stream()
                .filter(Vehicle::isAvailable)
                .collect(Collectors.toList());
    }
    
    public List<Vehicle> getVehiclesByMake(String make) {
        return vehicles.stream()
                .filter(v -> v.getMake().equalsIgnoreCase(make))
                .collect(Collectors.toList());
    }
    
    public List<Vehicle> getVehiclesInMaintenance() {
        return vehicles.stream()
                .filter(v -> !v.getMaintenanceStatus