import java.util.HashMap;
import java.util.Map;

public class RealVehicleService implements VehicleService {
    private Map<String, Vehicle> vehicles = new HashMap<>();
    
    public RealVehicleService() {
        // Initialize with some sample data
        vehicles.put("V001", new Vehicle("V001", "Toyota", "Camry", 2022, 45.0));
        vehicles.put("V002", new Vehicle("V002", "Honda", "Civic", 2023, 40.0));
        vehicles.put("V003", new Vehicle("V003", "Ford", "F-150", 2021, 65.0));
    }
    
    @Override
    public Vehicle