public interface VehicleService {
    Vehicle getVehicle(String id);
    void reserveVehicle(String id);
    void returnVehicle(String id);
    double calculateRentalCost(String id, int days);
}