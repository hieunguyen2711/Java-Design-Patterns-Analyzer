public class FleetManager {
    private VehiclePool vehiclePool;
    
    public FleetManager() {
        this.vehiclePool = VehiclePool.getInstance();
    }
    
    public void rentVehicle(String customerId) {
        Vehicle vehicle = vehiclePool.acquireVehicle();
        if (vehicle != null) {
            System.out.println("Vehicle " + vehicle.getId() +