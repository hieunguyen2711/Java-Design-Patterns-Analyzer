import java.util.ArrayDeque;
import java.util.Deque;

public class VehiclePool {
    private static VehiclePool instance;
    private Deque<Vehicle> availableVehicles;
    private Deque<Vehicle> rentedVehicles;
    
    private VehiclePool() {
        availableVehicles = new ArrayDeque<>();
        rentedVehicles = new ArrayDeque<>();
        
        // Initialize with some vehicles
        availableVehicles.push(new Vehicle("V001", "Toyota", "Camry"));
        availableVehicles.push(new Vehicle("V002", "Honda", "Civic"));
        availableVehicles.push(new Vehicle("V003", "Ford", "Focus"));
    }
    
    public static synchronized VehiclePool getInstance() {
        if (instance == null) {
            instance = new VehiclePool();
        }
        return instance;
    }
    
    public Vehicle acquireVehicle() {
        Vehicle vehicle = availableVehicles.pollFirst();
        if (vehicle != null) {
            rentedVehicles.push(vehicle);
            vehicle.setAvailable(false);
        }
        return vehicle;
    }
    
    public void releaseVehicle(Vehicle vehicle) {
        if (vehicle != null && !vehicle.isAvailable()) {
            rentedVehicles.remove(vehicle);
            availableVehicles.push(vehicle);
            vehicle.setAvailable(true);
        }
    }
}