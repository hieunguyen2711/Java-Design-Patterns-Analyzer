package fleetmanagement;

import java.time.LocalDate;

public class VehicleData {
    private final String id;