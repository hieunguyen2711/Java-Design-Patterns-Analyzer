package fleetmanagement;

import java.time.LocalDate;
import java.util.Objects;

public class Vehicle {
    private final String id;
    private final String make;
    private final String model;
    private final int year;
    private final double dailyRate;
    private final boolean isAvailable;
    private final LocalDate lastMaintenanceDate;
    
    public Vehicle(String id, String make, String model, int year, double dailyRate) {
        this.id = Objects.requireNonNull(id);
        this.make = Objects.requireNonNull(make);
        this.model = Objects.requireNonNull(model);
        this.year = year;
        this.dailyRate = dailyRate;
        this.isAvailable = true;
        this.lastMaintenanceDate = null;
    }
    
    public Vehicle(VehicleData data) {
        this.id = Objects.requireNonNull(data.getId());
        this.make = Objects.requireNonNull(data.getMake());
        this.model = Objects.requireNonNull(data.getModel());
        this.year = data.getYear();
        this.dailyRate = data.getDailyRate();
        this.isAvailable = data.isAvailable();
        this.lastMaintenanceDate = data.getLastMaintenanceDate();
    }
    
    public String getId() {
        return id;
    }
    
    public String getMake() {
        return make;
    }
    
    public String getModel() {
        return model;
    }
    
    public int getYear() {
        return year;
    }
    
    public double getDailyRate() {
        return dailyRate;
    }
    
    public boolean isAvailable() {
        return isAvailable;
    }
    
    public LocalDate getLastMaintenanceDate() {
        return lastMaintenanceDate;
    }
    
    public Vehicle updateAvailability(boolean available) {
        return new Vehicle(new VehicleData(id, make, model, year, dailyRate, available, lastMaintenanceDate));
    }
    
    public Vehicle updateMaintenance(LocalDate date) {
        return new Vehicle(new VehicleData(id, make, model, year, dailyRate, isAvailable, date));
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Vehicle vehicle = (Vehicle) o;
        return Objects.equals(id, vehicle.id);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}