package fleetmanagement;

import java.util.*;

public class FleetManager {
    private List<Vehicle> vehicles;
    private volatile List<Vehicle> activeVehicles;
    
    public FleetManager() {
        this.vehicles = new ArrayList<>();
        this.activeVehicles = Collections.unmodifiableList(new ArrayList<>(vehicles));
    }
    
    public void addVehicle(Vehicle vehicle) {
        // Double buffering: create new list with added vehicle
        List<Vehicle> newVehicles = new ArrayList<>(activeVehicles);
        newVehicles.add(vehicle);
        
        // Atomic swap of reference (double buffer pattern)
        activeVehicles = Collections.unmodifiableList(newVehicles);
        vehicles = newVehicles;
    }
    
    public void removeVehicle(String vehicleId) {
        List<Vehicle> newVehicles = new ArrayList<>(activeVehicles);
        newVehicles.removeIf(v -> v.getId().equals(vehicleId));
        
        activeVehicles = Collections.unmodifiableList(newVehicles);
        vehicles = newVehicles;
    }
    
    public List<Vehicle> getAvailableVehicles() {
        return activeVehicles.stream()
                .filter(Vehicle::isAvailable)
                .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }
    
    public Vehicle findVehicle(String vehicleId) {
        return activeVehicles.stream()
                .filter(v -> v.getId().equals(vehicleId))
                .findFirst()
                .orElse(null);
    }
}