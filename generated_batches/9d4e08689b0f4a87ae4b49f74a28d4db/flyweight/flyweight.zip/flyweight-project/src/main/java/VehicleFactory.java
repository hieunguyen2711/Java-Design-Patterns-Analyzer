import java.util.HashMap;
import java.util.Map;

public class VehicleFactory {
    private static final Map<VehicleType, Vehicle> vehicleCache = new HashMap<>();
    
    public static Vehicle getVehicle(VehicleType type, String brand, String model) {
        String key = type + "_" + brand + "_" + model;
        
        if (!vehicleCache.containsKey(key)) {
            vehicleCache.put(key, new Vehicle(type, brand, model));
        }
        
        return vehicleCache.get(key);
    }
}