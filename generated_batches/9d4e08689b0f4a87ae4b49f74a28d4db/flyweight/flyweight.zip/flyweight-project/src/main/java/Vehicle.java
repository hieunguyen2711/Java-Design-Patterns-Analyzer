public class Vehicle {
    private final VehicleType type;
    private final String brand;
    private final String model;
    
    public Vehicle(VehicleType type, String brand, String model) {
        this.type = type;
        this.brand = brand;
        this.model = model;
    }
    
    public VehicleType getType() {
        return type;
    }
    
    public String getBrand() {
        return brand;
    }
    
    public String getModel() {
        return model;
    }
    
    @Override
    public String toString() {
        return "Vehicle{" +
                "type=" + type +
                ", brand='" + brand + '\'' +
                ", model='" + model + '\'' +
                '}';
    }
}