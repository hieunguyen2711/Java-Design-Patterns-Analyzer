public class FleetManager {
    public static void main(String[] args) {
        // Create vehicles using the factory - same vehicles should be reused
        Vehicle vehicle1 = VehicleFactory.getVehicle(VehicleType.SEDAN, "Toyota", "Camry");
        Vehicle vehicle2 = VehicleFactory.getVehicle(VehicleType.SEDAN, "Toyota", "Camry");
        Vehicle vehicle3 = VehicleFactory.getVehicle(VehicleType.SUV, "Honda", "CR-V");
        
        System.out.println("Vehicle 1: " + vehicle1);
        System.out.println("Vehicle 2: " + vehicle2);
        System.out.println("Vehicle 3: " + vehicle3);
        
        // Verify flyweight pattern - same instances
        System.out.println("Are vehicles 1 and 2 the same instance? " + (vehicle1 == vehicle2));
        System.out.println("Are vehicles 1 and 3 the same instance? " +