public enum VehicleType {
    SEDAN,
    SUV,
    TRUCK,
    SPORTS_CAR
}