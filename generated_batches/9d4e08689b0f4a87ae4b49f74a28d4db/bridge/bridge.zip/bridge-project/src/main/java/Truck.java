public class Truck extends Vehicle {
    private String cargoType;
    private double capacity;
    
    public Truck(String cargoType, double capacity, MaintenanceStatus maintenanceStatus) {
        super(VehicleType.TRUCK, maintenanceStatus);
        this.cargoType = cargoType;
        this.capacity = capacity;
    }
    
    @Override
    public void start() {
        System.out.println("Truck carrying " + cargoType + " with capacity " + capacity + " started");
    }
    
    @Override
    public void stop() {
        System.out.println("Truck carrying " + cargoType + " with capacity " + capacity + " stopped");
    }
    
    public String getCargoType() {
        return cargoType;
    }
    
    public double getCapacity() {
        return capacity;
    }
}