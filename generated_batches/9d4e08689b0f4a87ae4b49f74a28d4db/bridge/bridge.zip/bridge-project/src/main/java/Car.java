public class Car extends Vehicle {
    private String model;
    private int year;
    
    public Car(String model, int year, MaintenanceStatus maintenanceStatus) {
        super(VehicleType.CAR, maintenanceStatus);
        this.model = model;
        this.year = year;
    }
    
    @Override
    public void start() {
        System.out.println("Car " + model + " (" + year + ") started");
    }
    
    @Override
    public void stop() {
        System.out.println("Car " + model + " (" + year + ") stopped");
    }
    
    public String getModel() {
        return model;
    }
    
    public int getYear() {
        return year;
    }
}