public interface MaintenanceStatus {
    void performMaintenance();
    boolean isReadyForUse();
}