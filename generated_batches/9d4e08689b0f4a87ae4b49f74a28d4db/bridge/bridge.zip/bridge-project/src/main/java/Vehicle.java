public abstract class Vehicle {
    protected VehicleType type;
    protected MaintenanceStatus maintenanceStatus;
    
    public Vehicle(VehicleType type, MaintenanceStatus maintenanceStatus) {
        this.type = type;
        this.maintenanceStatus = maintenanceStatus;
    }
    
    public abstract void start();
    public abstract void stop();
    
    public VehicleType getType() {
        return type;
    }
    
    public MaintenanceStatus getMaintenanceStatus() {
        return maintenanceStatus;
    }
}