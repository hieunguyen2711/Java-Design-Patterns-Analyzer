public class RegularMaintenance implements MaintenanceStatus {
    private String lastServiceDate;
    
    public RegularMaintenance(String lastServiceDate) {
        this.lastServiceDate