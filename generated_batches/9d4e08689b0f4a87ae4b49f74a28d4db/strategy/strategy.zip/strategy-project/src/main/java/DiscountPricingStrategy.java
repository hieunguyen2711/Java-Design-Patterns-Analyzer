package fleet;

public class DiscountPricingStrategy implements PricingStrategy {
    @Override
    public double calculatePrice(Vehicle vehicle, int rentalDays) {
        double basePrice = vehicle.getBasePricePerDay() * rentalDays;