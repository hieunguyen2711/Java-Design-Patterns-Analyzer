package fleet;

public interface PricingStrategy {
    double calculatePrice(Vehicle vehicle, int rentalDays);
}