package fleet;

public class StandardPricingStrategy implements PricingStrategy {
    @Override
    public double calculatePrice(Vehicle vehicle, int rentalDays) {
        return vehicle.getBasePricePerDay() * rentalDays;
    }
}