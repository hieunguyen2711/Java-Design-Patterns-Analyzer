package fleet;

public enum MaintenanceStatus {
    AVAILABLE,
    MAINTENANCE,
    OUT_OF_SERVICE
}