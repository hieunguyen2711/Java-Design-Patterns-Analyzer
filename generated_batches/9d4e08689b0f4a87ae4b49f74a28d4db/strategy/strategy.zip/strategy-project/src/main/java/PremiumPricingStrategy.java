package fleet;

public class PremiumPricingStrategy implements PricingStrategy {
    @Override
    public double calculatePrice(Vehicle vehicle, int rentalDays) {
        double basePrice = vehicle.getBasePricePerDay() * rentalDays;
        return basePrice * 1.2; // 20% premium for premium vehicles
    }
}