package fleet;

public class Vehicle {
    private String id;
    private String model;
    private double basePricePerDay;
    private MaintenanceStatus maintenanceStatus;
    
    public Vehicle(String id, String model, double basePricePerDay) {
        this.id = id;
        this.model = model;
        this.basePricePerDay = basePricePerDay;
        this.maintenanceStatus = MaintenanceStatus.AVAILABLE;
    }
    
    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getModel() { return model; }
    public void setModel(String model) { this.model = model; }
    
    public double getBasePricePerDay() { return basePricePerDay; }
    public void setBasePricePerDay(double basePricePerDay) { this.basePricePerDay = basePricePerDay; }
    
    public MaintenanceStatus getMaintenanceStatus() { return maintenanceStatus; }
    public void setMaintenanceStatus(MaintenanceStatus maintenanceStatus) { this.maintenanceStatus = maintenanceStatus; }
}