package fleetmanagement;

import java.util.ArrayList;
import java.util.List;

public class VehicleManager {
    private List<Vehicle> vehicles;
    
    public VehicleManager() {
        this.vehicles = new ArrayList<>();
    }
    
    public void addVehicle(Vehicle vehicle) {
        vehicles.add(vehicle);
    }
    
    public void updateVehicle(String id, String make, String model, int year) {
        for (Vehicle vehicle : vehicles) {
            if (vehicle.getId().equals(id)) {
                vehicle.setMake(make);
                vehicle.setModel(model);
                vehicle.setYear(year);
                break;
            }
        }
    }
    
    public List<Vehicle> getDirtyVehicles() {
        List<Vehicle> dirtyVehicles = new ArrayList<>();
        for (Vehicle vehicle : vehicles) {
            if (vehicle.isDirty())