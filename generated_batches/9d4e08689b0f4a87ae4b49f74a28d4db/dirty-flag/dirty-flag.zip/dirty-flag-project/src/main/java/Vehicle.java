package fleetmanagement;

public class Vehicle {
    private String id;
    private String make;
    private String model;
    private int year;
    private boolean isDirty;
    
    public Vehicle(String id, String make, String model, int year) {
        this.id = id;
        this.make = make;
        this.model = model;
        this.year = year;
        this.isDirty = false;
    }
    
    public String getId() {
        return id;
    }
    
    public String getMake() {
        return make;
    }
    
    public void setMake(String make) {
        this.make = make;
        markAsDirty();
    }
    
    public String getModel() {
        return model;
    }
    
    public void setModel(String model) {
        this.model = model;
        markAsDirty();
    }
    
    public int getYear() {
        return year;
    }
    
    public void setYear(int year) {
        this.year = year;
        markAsDirty();
    }
    
    public boolean isDirty() {
        return isDirty;
    }
    
    public void markAsDirty() {
        this.isDirty = true;
    }
    
    public void clearDirtyFlag() {
        this.isDirty = false;
    }
    
    @Override
    public String toString() {
        return "Vehicle{" +
                "id='" + id + '\'' +
                ", make='" + make + '\'' +
                ", model='" + model + '\'' +
                ", year=" + year +
                ", isDirty=" + isDirty +
                '}';
    }
}