public class VehicleAdapter implements Vehicle {
    private final LegacyVehicle legacyVehicle;
    
    public VehicleAdapter(LegacyVehicle legacyVehicle) {
        this.legacyVehicle = legacyVehicle;
    }
    
    @Override
    public String getVehicleType() {
        return legacyVehicle.getType();
    }
    
    @Override
    public String getLicensePlate() {
        return legacyVehicle.getRegistrationNumber();
    }
    
    @Override
    public double getPricePerDay() {
        return legacyVehicle.getDailyRate();
    }
}