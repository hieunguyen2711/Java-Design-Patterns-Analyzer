public class Car implements Vehicle {
    private String type;
    private String licensePlate;
    private double pricePerDay;
    
    public Car(String type, String licensePlate, double pricePerDay) {
        this.type = type;
        this.licensePlate = licensePlate;
        this.pricePerDay = pricePerDay;
    }
    
    @Override
    public String getVehicleType() {
        return type;
    }
    
    @Override
    public String getLicensePlate() {
        return licensePlate;
    }
    
    @Override
    public double getPricePerDay() {
        return pricePerDay;
    }
}