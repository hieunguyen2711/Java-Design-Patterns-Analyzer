public class LegacyVehicle {
    private String type;
    private String registrationNumber;
    private double dailyRate;
    
    public LegacyVehicle(String type, String registrationNumber, double dailyRate) {
        this.type = type;
        this.registrationNumber = registrationNumber;
        this.dailyRate = dailyRate;
    }
    
    public String getType