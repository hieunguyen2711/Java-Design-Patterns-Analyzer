public interface Vehicle {
    String getVehicleType();
    String getLicensePlate();
    double getPricePerDay();
}