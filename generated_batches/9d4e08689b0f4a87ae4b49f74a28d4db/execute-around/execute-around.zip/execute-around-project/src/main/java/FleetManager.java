package fleet;

import java.util.ArrayList;
import java.util.List;

public class FleetManager {
    private List<Vehicle> vehicles;
    
    public FleetManager() {
        this.vehicles = new ArrayList<>();
    }
    
    public void addVehicle(Vehicle vehicle) {
        vehicles.add(vehicle);
    }
    
    public Vehicle findAvailableVehicle(String type) {
        for (Vehicle vehicle : vehicles) {
            if (vehicle.getType().equals(type) && vehicle.isAvailable()) {
                return vehicle;
            }
        }
        return null;
    }
    
    public void executeWithMaintenanceCheck(Vehicle vehicle, MaintenanceTask task) {
        try {
            System.out.println("Checking maintenance status for " + vehicle.getLicensePlate());
            if (vehicle.hasPendingMaintenance()) {
                System.out.println("Vehicle requires maintenance - cannot proceed");
                return;
            }
            task.execute(vehicle);
        } finally {
            System.out.println("Maintenance check completed for " + vehicle.getLicensePlate());
        }
    }
}