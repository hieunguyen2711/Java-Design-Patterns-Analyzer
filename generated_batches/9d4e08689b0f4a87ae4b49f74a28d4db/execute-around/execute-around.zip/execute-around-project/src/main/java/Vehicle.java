package fleet;

public class Vehicle {
    private String licensePlate;
    private String type;
    private boolean available;
    private boolean pendingMaintenance;
    
    public Vehicle(String licensePlate, String type) {
        this.licensePlate = licensePlate;
        this.type = type;
        this.available = true;
        this.pendingMaintenance = false;
    }
    
    public String getLicensePlate() {
        return licensePlate;
    }
    
    public String getType() {
        return type;
    }
    
    public boolean isAvailable() {
        return available;
    }
    
    public void setAvailable(boolean available) {
        this.available = available;
    }
    
    public boolean hasPendingMaintenance() {
        return pendingMaintenance;
    }
    
    public void setPendingMaintenance(boolean pendingMaintenance) {
        this.pendingMaintenance = pendingMaintenance;
    }
}