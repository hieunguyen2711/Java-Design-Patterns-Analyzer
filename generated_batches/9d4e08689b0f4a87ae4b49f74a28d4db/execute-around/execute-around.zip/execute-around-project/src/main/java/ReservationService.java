package fleet;

public class ReservationService {
    private FleetManager fleetManager;
    
    public ReservationService(FleetManager fleetManager) {
        this.fleetManager = fleetManager;
    }
    
    public void reserveVehicle(String type, String customerName) {
        Vehicle vehicle = fleetManager.findAvailableVehicle(type);
        
        if (vehicle != null) {
            fleetManager.executeWith