package fleet;

public interface MaintenanceTask {
    void execute(Vehicle vehicle);
}