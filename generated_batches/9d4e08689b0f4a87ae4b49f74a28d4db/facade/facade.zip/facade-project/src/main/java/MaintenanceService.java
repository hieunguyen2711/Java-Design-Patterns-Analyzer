public class MaintenanceService {
    public boolean isVehicle