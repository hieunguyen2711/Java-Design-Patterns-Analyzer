public class PricingService {
    private static final double BASE_RATE = 50.0;
    private static final double DAILY_RATE = 25.0;
    
    public double calculateRentalCost(int days, String vehicleType) {
        if ("luxury".equalsIgnoreCase(vehicleType)) {
            return (BASE_RATE + (DAILY_RATE * days)) * 1.5;
        }
        return BASE_RATE + (DAILY_RATE * days);
    }
}