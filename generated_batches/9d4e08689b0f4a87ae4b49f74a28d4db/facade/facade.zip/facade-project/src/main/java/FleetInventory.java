import java.util.*;

public class FleetInventory {
    private List<Vehicle> vehicles;
    
    public FleetInventory() {
        this.vehicles = new ArrayList<>();
    }
    
    public void addVehicle(Vehicle vehicle) {
        vehicles.add(vehicle);
    }
    
    public Vehicle findAvailableVehicle(String make, String model) {
        for (Vehicle vehicle : vehicles) {
            if (vehicle.isAvailable() && 
                vehicle.getMake().equals(make) && 
                vehicle.getModel().equals(model)) {
                return vehicle;
            }
        }
        return null;
    }
    
    public List<Vehicle> getAllVehicles() {
        return new ArrayList<>(vehicles);
    }
}