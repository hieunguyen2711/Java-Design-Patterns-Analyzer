package com.fleetmanager.mapper;

import com.fleetmanager.model.Vehicle;
import java.sql.ResultSet;
import java.sql.SQLException;

public class VehicleMapper {
    
    public static Vehicle mapResultSetToVehicle(ResultSet rs) throws SQLException {
        Vehicle vehicle = new Vehicle();
        vehicle.setId(rs.getString("id"));
        vehicle.setMake(rs.getString("make"));
        vehicle.setModel(rs.getString("model"));
        vehicle.setYear(rs.getInt("year"));
        vehicle.setLicensePlate(rs.getString("license_plate"));
        vehicle.setDailyRate(rs.getDouble("daily_rate"));
        vehicle.setAvailable(rs.getBoolean("is_available"));
        return vehicle;
    }
    
    public static Vehicle mapVehicleToEntity(Vehicle vehicle) {
        // In a real implementation, this might involve additional transformations