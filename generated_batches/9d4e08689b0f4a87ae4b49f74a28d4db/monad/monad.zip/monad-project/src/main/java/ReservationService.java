package com.fleetmanager;

import java.util.Optional;
import java.util.function.Function;

public class ReservationService {
    private final FleetInventory inventory;
    private final Map<String, Reservation> reservations = new HashMap<>();
    
    public ReservationService(FleetInventory inventory