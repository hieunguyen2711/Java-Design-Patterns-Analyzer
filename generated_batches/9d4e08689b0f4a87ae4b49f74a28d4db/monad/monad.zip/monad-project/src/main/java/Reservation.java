package com.fleetmanager;

import java.time.LocalDateTime;
import java.util.Optional;

public class Reservation {
    private final String id;
    private final String customerId;
    private final String vehicleId;
    private final LocalDateTime pickupTime;
    private final LocalDateTime returnTime;
    private ReservationStatus status;
    
    public Reservation(String id, String customerId, String vehicleId, 
                      LocalDateTime pickupTime, LocalDateTime returnTime) {
        this.id = id;
        this.customerId = customerId;
        this.vehicleId = vehicleId;
        this.pickupTime = pickupTime;
        this.returnTime = returnTime;
        this.status = ReservationStatus.PENDING;
    }
    
    public Optional<Reservation> confirm() {
        if (status == ReservationStatus.PENDING) {
            status = ReservationStatus.CONFIRMED;
            return Optional.of(this);
        }
        return Optional.empty();
    }
    
    public Optional<Reservation> cancel() {
        if (status != ReservationStatus.COMPLETED) {
            status = ReservationStatus.CANCELLED;
            return Optional.of(this);
        }
        return Optional.empty();
    }
    
    // Getters
    public String getId() { return id; }
    public String getCustomerId() { return customerId; }
    public String getVehicleId() { return vehicleId; }
    public LocalDateTime getPickupTime() { return pickupTime; }
    public LocalDateTime getReturnTime() { return returnTime; }
    public ReservationStatus getStatus() { return status; }
}