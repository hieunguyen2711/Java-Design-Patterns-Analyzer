package com.fleetmanager;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FleetInventory {
    private final Map<String, Vehicle> vehicles = new HashMap<>();
    
    public void addVehicle(Vehicle vehicle) {
        vehicles.put(vehicle.getId(), vehicle);
    }
    
    public Optional<Vehicle> findVehicle(String id) {
        return Optional.ofNullable(vehicles.get(id));
    }
    
    public List<Vehicle> getAvailableVehicles() {
        return vehicles.values().stream()
                .filter(Vehicle::isAvailable)
                .collect(Collectors.toList());
    }
}