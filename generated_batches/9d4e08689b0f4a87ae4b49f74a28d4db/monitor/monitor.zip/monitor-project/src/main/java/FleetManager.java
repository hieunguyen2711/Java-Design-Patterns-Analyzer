package com.fleetapp;

import java.util.concurrent.locks.ReentrantLock;
import java.util.HashMap;
import java.util.Map;

public class FleetManager {
    private final Map<String, Vehicle> vehicles;
    private final ReentrantLock lock;
    
    public FleetManager() {
        this.vehicles = new HashMap<>();
        this.lock = new ReentrantLock();
    }
    
    public void addVehicle(Vehicle vehicle) {
        lock.lock();
        try {
            vehicles.put(vehicle.getId(), vehicle);
        } finally {
            lock.unlock();
        }
    }
    
    public Vehicle getVehicle(String id) {
        lock.lock();
        try {
            return vehicles.get(id);
        } finally {
            lock.unlock();
        }
    }
    
    public void updateMaintenanceStatus(String id, String status) {
        lock.lock();
        try {
            Vehicle vehicle = vehicles.get(id);
            if (vehicle != null) {
                vehicle.setMaintenanceStatus(status);
            }
        } finally {
            lock.unlock();
        }
    }
}