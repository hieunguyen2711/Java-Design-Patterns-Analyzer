package com.fleetapp;

import java.util.concurrent.locks.ReentrantLock;

public class FleetMonitor {
    private final ReentrantLock monitorLock;
    
    public FleetMonitor() {
        this.monitorLock = new ReentrantLock();
    }
    
    public void acquireAccess() {
        monitorLock.lock();
    }
    
    public void releaseAccess() {
        monitorLock.unlock();
    }
}