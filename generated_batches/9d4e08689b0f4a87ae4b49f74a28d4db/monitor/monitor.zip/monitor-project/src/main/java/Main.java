package com.fleetapp;

public class Main {
    public static void main(String[] args) {
        FleetManager fleetManager = new FleetManager();
        FleetMonitor fleetMonitor = new FleetMonitor();
        
        // Add vehicles to fleet
        Vehicle vehicle1 = new Vehicle("V001", "Maintenance Required");
        Vehicle vehicle2 = new Vehicle("V00