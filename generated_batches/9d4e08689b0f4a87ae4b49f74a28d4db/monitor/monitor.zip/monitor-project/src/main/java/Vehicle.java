package com.fleetapp;

public class Vehicle {
    private final String id;
    private String maintenanceStatus;
    
    public Vehicle(String id, String maintenanceStatus) {
        this.id = id;
        this.maintenanceStatus = maintenanceStatus;
    }
    
    public String getId() {
        return id;
    }
    
    public String getMaintenanceStatus() {
        return maintenanceStatus;
    }
    
    public void setMaintenanceStatus(String maintenanceStatus) {
        this.maintenanceStatus = maintenanceStatus;
    }
}