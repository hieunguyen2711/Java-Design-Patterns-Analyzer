public class Truck extends Vehicle {
    private double cargoCapacity;
    
    public Truck(String model, double basePrice, double cargoCapacity) {
        super(model, "Truck", basePrice);
        this.cargoCapacity = cargoCapacity;
    }
    
    @Override
    public double calculateRentalCost(int days) {
        return basePrice * days * 1.5;
    }
    
    public double getCargoCapacity() {
        return cargoCapacity;
    }
}