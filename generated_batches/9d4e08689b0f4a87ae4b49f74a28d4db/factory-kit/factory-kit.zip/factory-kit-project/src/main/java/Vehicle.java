public abstract class Vehicle {
    protected String model;
    protected String type;
    protected double basePrice;
    
    public Vehicle(String model, String type, double basePrice) {
        this.model = model;
        this.type = type;
        this.basePrice = basePrice;
    }
    
    public abstract double calculateRentalCost(int days);
    
    public String getModel() {
        return model;
    }
    
    public String getType() {
        return type;
    }
    
    public double getBasePrice() {
        return basePrice;
    }
}