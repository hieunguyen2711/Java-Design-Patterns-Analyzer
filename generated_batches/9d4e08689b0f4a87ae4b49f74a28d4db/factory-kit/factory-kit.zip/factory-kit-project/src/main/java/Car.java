public class Car extends Vehicle {
    private int doors;
    
    public Car(String model, double basePrice, int doors) {
        super(model, "Car", basePrice);
        this.doors = doors;
    }
    
    @Override
    public double calculateRentalCost(int days) {
        return basePrice * days * 1.2;
    }
    
    public int getDoors() {
        return doors;
    }
}