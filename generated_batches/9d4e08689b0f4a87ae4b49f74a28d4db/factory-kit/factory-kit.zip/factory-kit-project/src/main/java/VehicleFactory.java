public class VehicleFactory {
    
    public static Vehicle createVehicle(String type, String model, double basePrice, Object... params) {
        switch (type.toLowerCase()) {
            case "car":
                int doors = (Integer) params[0];
                return new Car(model