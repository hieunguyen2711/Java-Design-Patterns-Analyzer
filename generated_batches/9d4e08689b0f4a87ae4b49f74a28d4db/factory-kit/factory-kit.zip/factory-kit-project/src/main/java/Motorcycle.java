public class Motorcycle extends Vehicle {
    private boolean hasSidecar;
    
    public Motorcycle(String model, double basePrice, boolean hasSidecar) {
        super(model, "Motorcycle", basePrice);
        this.hasSidecar = hasSidecar;
    }
    
    @Override
    public double calculateRentalCost(int days) {
        return basePrice * days * 1.3;
    }
    
    public boolean hasSidecar() {
        return hasSidecar;
    }
}