public class Car extends Vehicle {
    private boolean isConvertible;

    public Car(String make, String model, int year, double basePrice, boolean isConvertible) {
        super(make, model, year, basePrice);
        this.isConvertible = isConvertible;
    }

    @Override
    public double calculatePrice() {
        return basePrice + (isConvertible ? 5000 : 0);
    }
}