public class LuxuryPackage extends VehicleDecorator {
    private static final double LUXURY_PRICE = 10000;

    public LuxuryPackage(Vehicle vehicle) {
        super(vehicle);
    }

    @Override
    public double calculatePrice() {
        return vehicle.calculatePrice() + LUXURY_PRICE;
    }
}