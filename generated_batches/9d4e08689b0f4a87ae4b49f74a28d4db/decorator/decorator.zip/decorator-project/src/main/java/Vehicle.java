public abstract class Vehicle {
    protected String make;
    protected String model;
    protected int year;
    protected double basePrice;

    public Vehicle(String make, String model, int year, double basePrice) {
        this.make = make;
        this.model = model;
        this.year = year;
        this.basePrice = basePrice;
    }

    public abstract double calculatePrice();
    
    public String getDetails() {
        return year + " " + make + " " + model;
    }
}