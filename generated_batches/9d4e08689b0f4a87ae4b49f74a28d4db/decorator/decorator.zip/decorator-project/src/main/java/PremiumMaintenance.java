public class PremiumMaintenance extends VehicleDecorator {
    private static final double MAINTENANCE_PRICE = 2000;

    public PremiumMaintenance(Vehicle vehicle) {
        super(vehicle);
    }

    @Override
    public double calculatePrice() {
        return vehicle.calculatePrice() + MAINTENANCE_PRICE;
    }
}