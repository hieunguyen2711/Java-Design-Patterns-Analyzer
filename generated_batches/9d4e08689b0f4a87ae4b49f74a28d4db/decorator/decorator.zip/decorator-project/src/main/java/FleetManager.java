public class FleetManager {
    public static void main(String[] args) {
        Vehicle car = new Car("Toyota", "Camry", 2023, 25000, false);
        
        System.out.println("Base price: $" + car.calculate