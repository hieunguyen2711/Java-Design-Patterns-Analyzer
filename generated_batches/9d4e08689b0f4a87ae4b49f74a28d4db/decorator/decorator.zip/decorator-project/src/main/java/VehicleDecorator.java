public abstract class VehicleDecorator extends Vehicle {
    protected Vehicle vehicle;

    public VehicleDecorator(Vehicle vehicle) {
        super(vehicle.make, vehicle.model, vehicle.year, vehicle.basePrice);
        this.vehicle = vehicle;
    }

    @Override
    public double calculatePrice() {
        return vehicle.calculatePrice();
    }
}