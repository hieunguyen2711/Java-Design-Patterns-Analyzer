package fleetmanagement;

public class CsvVehicleConverter implements VehicleConverter {
    
    @Override
    public String convertToString(Vehicle vehicle) {
        return String.format("%s,%s,%s,%d,%.2f", 
            vehicle.getId(),
            vehicle.getMake(), 
            vehicle.getModel(),
            vehicle.getYear(),
            vehicle.getDailyRate());
    }
    
    @Override
    public Vehicle convertFromString(String vehicleString) {
        String[] parts = vehicleString.split