package fleetmanagement;

public interface VehicleConverter {
    String convertToString(Vehicle vehicle);
    Vehicle convertFromString(String vehicleString);
}