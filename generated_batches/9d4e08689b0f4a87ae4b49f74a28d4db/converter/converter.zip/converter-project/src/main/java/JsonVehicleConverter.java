package fleetmanagement;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class JsonVehicleConverter implements VehicleConverter {
    private final Gson gson;
    
    public JsonVehicleConverter() {
        this.gson = new GsonBuilder().setPrettyPrinting().create();
    }
    
    @Override
    public String convertToString(Vehicle vehicle) {
        return gson.toJson(vehicle);
    }
    
    @Override
    public Vehicle convertFromString(String vehicleString) {
        return gson.fromJson(vehicleString, Vehicle.class);
    }
}