public class Motorcycle extends Vehicle {
    private boolean hasSidecar;
    
    public Motorcycle(String make, String model, int year, boolean hasSidecar) {
        super(make, model, year);
        this.hasSidecar = hasSidecar;
    }
    
    @Override
    public void accept(VehicleVisitor visitor) {
        visitor.visit(this);
    }
    
    // Getters
    public boolean hasSidecar() { return hasSidecar; }
}