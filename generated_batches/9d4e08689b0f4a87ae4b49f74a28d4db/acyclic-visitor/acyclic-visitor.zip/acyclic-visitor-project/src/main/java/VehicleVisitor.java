public interface VehicleVisitor {
    void visit(Car car);
    void visit(Truck truck);
    void visit(Motorcycle motorcycle);
}