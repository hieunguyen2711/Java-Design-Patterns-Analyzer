public class Truck extends Vehicle {
    private double cargoCapacity;
    
    public Truck(String make, String model, int year, double cargoCapacity) {
        super(make, model, year);
        this.cargoCapacity = cargoCapacity;
    }
    
    @Override
    public void accept(VehicleVisitor visitor) {
        visitor.visit(this);
    }
    
    // Getters
    public double getCargoCapacity() { return cargoCapacity; }
}