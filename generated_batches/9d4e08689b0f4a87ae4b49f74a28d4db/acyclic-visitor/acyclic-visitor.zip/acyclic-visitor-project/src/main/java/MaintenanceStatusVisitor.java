public class MaintenanceStatusVisitor implements VehicleVisitor {
    private String status;
    
    @Override
    public void visit(Car car) {
        status = "Car maintenance: Check