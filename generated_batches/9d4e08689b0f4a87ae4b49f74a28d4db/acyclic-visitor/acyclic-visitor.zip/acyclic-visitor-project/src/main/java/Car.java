public class Car extends Vehicle {
    private boolean isConvertible;
    
    public Car(String make, String model, int year, boolean isConvertible) {
        super(make, model, year);
        this.isConvertible = isConvertible;
    }
    
    @Override
    public void accept(VehicleVisitor visitor) {
        visitor.visit(this);
    }
    
    // Getters
    public boolean isConvertible() { return isConvertible; }
}