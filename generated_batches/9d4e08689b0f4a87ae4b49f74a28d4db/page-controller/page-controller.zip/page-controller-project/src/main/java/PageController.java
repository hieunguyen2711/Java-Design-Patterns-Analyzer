import java.util.HashMap;
import java.util.Map;

public class PageController {
    private Map<String, PageHandler> handlers;
    
    public PageController() {
        handlers = new HashMap<>();
        handlers.put("vehicle_list", new VehicleListPage());
        handlers.put("reservation_form", new ReservationFormPage());
        handlers.put("maintenance_status", new MaintenanceStatusPage());
    }
    
    public void handleRequest(String pageName) {
        PageHandler handler = handlers.get(pageName);
        if (handler != null) {
            handler.display();
        } else {
            System.out.println("Page not found: " + pageName);
        }
    }
}