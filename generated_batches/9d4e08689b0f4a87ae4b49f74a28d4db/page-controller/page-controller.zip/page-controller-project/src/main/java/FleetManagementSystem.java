public class FleetManagementSystem {
    public static void main(String[] args) {
        // Create page controller
        PageController controller = new PageController();
        
        // Simulate user requests
        controller.handleRequest("vehicle_list");
        controller.handleRequest("reservation_form");
        controller.handleRequest("maintenance_status");
        controller.handleRequest("invalid_page");
    }
}