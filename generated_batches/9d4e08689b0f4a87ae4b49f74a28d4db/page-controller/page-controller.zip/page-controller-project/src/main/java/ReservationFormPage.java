public class ReservationFormPage implements PageHandler {
    @Override
    public void display() {
        System.out.println("=== Reservation Form Page ===");
        System.out.println("Please fill out the reservation form:");
        System.out.println("- Select vehicle type");
        System.out.println("- Enter pickup date");
        System.out.println("- Enter return date");
    }
}