public interface PageHandler {
    void display();
}