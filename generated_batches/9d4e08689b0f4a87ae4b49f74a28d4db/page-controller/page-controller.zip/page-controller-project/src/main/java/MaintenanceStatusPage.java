public class MaintenanceStatusPage implements PageHandler {
    @Override
    public void display() {
        System.out.println("=== Maintenance Status Page ===");
        System.out.println("Current maintenance status:");
        System.out.println("- Car #123: Service due in 30 days