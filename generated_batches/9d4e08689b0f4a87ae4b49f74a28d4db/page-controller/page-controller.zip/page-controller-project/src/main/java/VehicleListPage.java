public class VehicleListPage implements PageHandler {
    @Override
    public void display() {
        System.out.println("=== Vehicle List Page ===");
        System.out.println("Displaying all vehicles in fleet:");
        System.out.println("- Car #123 (Toyota Camry)");
        System.out.println("- Truck #456 (Ford F-150)");
        System.out.println("- Van #789 (Honda Odyssey)");
    }
}