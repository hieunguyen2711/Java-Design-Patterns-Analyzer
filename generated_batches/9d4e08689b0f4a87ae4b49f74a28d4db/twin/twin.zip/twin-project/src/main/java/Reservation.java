package fleet;

import java.time.LocalDateTime;
import java.util.Objects;

public class Reservation {
    private final String id;
    private final String vehicleId;
    private final LocalDateTime pickupTime;
    private final LocalDateTime returnTime;
    
    public Reservation(String id, String vehicleId, LocalDateTime pickupTime, LocalDateTime returnTime) {
        this.id = id;
        this.vehicleId = vehicleId;
        this.pickupTime = pickupTime;
        this.returnTime = returnTime;
    }
    
    public String getId() {
        return id;
    }
    
    public String getVehicleId() {
        return vehicleId;
    }
    
    public LocalDateTime getPickupTime() {
        return pickupTime;
    }
    
    public LocalDateTime getReturnTime() {
        return returnTime;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Reservation that = (Reservation) o;
        return Objects.equals(id, that.id);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}