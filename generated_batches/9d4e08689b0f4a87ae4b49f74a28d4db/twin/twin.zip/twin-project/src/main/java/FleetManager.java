package fleet;

import java.util.*;

public class FleetManager {
    private final Map<String, Vehicle> vehicles = new HashMap<>();
    
    public void addVehicle(Vehicle vehicle) {
        vehicles.put(vehicle.getId(), vehicle);
    }
    
    public Optional<Vehicle> getVehicle(String id) {
        return Optional.ofNullable(vehicles.get(id));
    }
    
    public Collection<Vehicle> getAllVehicles() {
        return new ArrayList<>(vehicles.values());
    }
}