package fleet.inventory;

public class FleetManager {
    public static void main(String[] args) {
        // First access - loads from database
        Vehicle vehicle1 = VehicleRepository.findVehicleByVin("ABC1234567