package fleet.inventory;

import java.util.HashMap;
import java.util.Map;

public class VehicleRepository {
    private static final Map<String, Vehicle> vehicleCache = new HashMap<>();
    
    public static Vehicle findVehicleByVin(String vin) {
        return vehicleCache.computeIfAbsent(vin, VehicleRepository::loadVehicle);
    }
    
    private static Vehicle loadVehicle(String vin) {
        // Simulate database lookup
        System.out.println("Loading vehicle with VIN: " + vin + " from database");
        return new Vehicle(vin, "Make-" + vin.substring(0, 3), "Model-" + vin.charAt(3), 
                          2000 + Integer.parseInt(vin.substring(4, 6)));
    }
    
    public static void clearCache() {
        vehicleCache.clear();
    }
}