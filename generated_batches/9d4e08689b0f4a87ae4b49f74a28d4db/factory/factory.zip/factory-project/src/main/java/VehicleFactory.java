public class VehicleFactory {
    
    public static Vehicle createVehicle(String type, String model, Object... params) {
        switch (type.toLowerCase()) {
            case "car":
                int doors = (Integer) params[0];
                return new Car(model, doors);
            case "truck":
                double capacity = (Double) params[0];
                return