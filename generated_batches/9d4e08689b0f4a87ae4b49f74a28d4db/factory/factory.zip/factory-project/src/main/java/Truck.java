public class Truck extends Vehicle {
    private double cargoCapacity;
    
    public Truck(String model, double cargoCapacity) {
        super(model, "Truck", 80.0);
        this.cargoCapacity = cargoCapacity;
    }
    
    @Override
    public void startEngine() {
        System.out.println("Truck engine started with diesel ignition");
    }
    
    public double getCargoCapacity() {
        return cargoCapacity;
    }
}