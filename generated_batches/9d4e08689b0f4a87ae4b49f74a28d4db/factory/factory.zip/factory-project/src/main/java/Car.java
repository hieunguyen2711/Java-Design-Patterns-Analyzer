public class Car extends Vehicle {
    private int doors;
    
    public Car(String model, int doors) {
        super(model, "Car", 50.0);
        this.doors = doors;
    }
    
    @Override
    public void startEngine() {
        System.out.println("Car engine started with key ignition");
    }
    
    public int getDoors() {
        return doors;
    }
}