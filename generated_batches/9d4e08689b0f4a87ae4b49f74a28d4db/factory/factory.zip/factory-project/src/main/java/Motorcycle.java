public class Motorcycle extends Vehicle {
    private boolean hasSidecar;
    
    public Motorcycle(String model, boolean hasSidecar) {
        super(model, "Motorcycle", 30.0);
        this.hasSidecar = hasSidecar;
    }
    
    @Override
    public void startEngine() {
        System.out.println("Motorcycle engine started with electric starter");
    }
    
    public boolean hasSidecar() {
        return hasSidecar;
    }
}