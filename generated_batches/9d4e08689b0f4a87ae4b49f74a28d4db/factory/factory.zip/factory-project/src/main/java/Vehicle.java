public abstract class Vehicle {
    protected String model;
    protected String type;
    protected double dailyRate;
    
    public Vehicle(String model, String type, double dailyRate) {
        this.model = model;
        this.type = type;
        this.dailyRate = dailyRate;
    }
    
    public abstract void startEngine();
    
    public String getModel() {
        return model;
    }
    
    public String getType() {
        return type;
    }
    
    public double getDailyRate() {
        return dailyRate;
    }
}