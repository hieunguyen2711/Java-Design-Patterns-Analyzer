public class Vehicle {
    private String id;
    private String model;
    private boolean available;
    private FleetMediator mediator;

    public Vehicle(String id, String model, FleetMediator mediator) {
        this.id = id;
        this.model = model;
        this.mediator = mediator;
        this.available = true;
        mediator.registerVehicle(this);
    }

    public void reserve() {
        if (available) {
            available = false;
            mediator.notify(this, "vehicle_reserved");
        }
    }

    public void returnVehicle() {
        available = true;
        mediator.notify(this, "vehicle_returned");
    }

    // Getters and setters
    public String getId() { return id; }
    public String getModel() { return model; }
    public boolean isAvailable() { return available; }
}