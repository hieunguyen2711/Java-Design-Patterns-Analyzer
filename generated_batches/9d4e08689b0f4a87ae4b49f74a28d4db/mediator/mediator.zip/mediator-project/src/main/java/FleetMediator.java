public interface FleetMediator {
    void registerVehicle(Vehicle vehicle);
    void registerReservation(Reservation reservation);
    void registerMaintenance(Maintenance maintenance);
    void notify(Object sender, String event);
}