public class Maintenance {
    private String id;
    private Vehicle vehicle;
    private FleetMediator mediator;

    public Maintenance(String id, Vehicle vehicle, FleetMediator mediator) {
        this.id = id;
        this.vehicle = vehicle;
        this.mediator = mediator;
        mediator.registerMaintenance(this);
    }

    public void schedule() {
        if (vehicle != null) {
            vehicle.returnVehicle();
            mediator.notify(this, "maintenance_scheduled");
        }
    }

    // Getters and setters
    public String getId() { return id; }
    public Vehicle getVehicle() { return vehicle; }
}