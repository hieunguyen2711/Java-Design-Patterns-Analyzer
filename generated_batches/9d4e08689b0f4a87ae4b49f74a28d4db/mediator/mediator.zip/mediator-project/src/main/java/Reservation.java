public class Reservation {
    private String id;
    private Vehicle vehicle;
    private FleetMediator mediator;

    public Reservation(String id, Vehicle vehicle, FleetMediator mediator) {
        this.id = id;
        this.vehicle = vehicle;
        this.mediator = mediator;
        mediator.registerReservation(this);
    }

    public void confirm() {
        if (vehicle != null && vehicle.isAvailable()) {
            vehicle.reserve();
            mediator.notify(this, "reservation_confirmed");
        }
    }

    // Getters and setters
    public String getId() { return id; }
    public Vehicle getVehicle() { return vehicle; }
}