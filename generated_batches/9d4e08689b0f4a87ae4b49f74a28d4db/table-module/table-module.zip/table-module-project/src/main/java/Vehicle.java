package com.fleetapp;

public class Vehicle {
    private String id;
    private String model;
    private boolean isAvailable;
    private double dailyRate;
    
    public Vehicle(String id, String model, double dailyRate) {
        this.id = id;
        this.model = model;
        this.dailyRate = dailyRate;
        this.isAvailable = true;
    }
    
    public String getId() { return id; }
    public String getModel() { return model; }
    public boolean isAvailable() { return isAvailable; }
    public void setAvailable(boolean available) { isAvailable = available; }
    public double getDailyRate() { return dailyRate; }
}