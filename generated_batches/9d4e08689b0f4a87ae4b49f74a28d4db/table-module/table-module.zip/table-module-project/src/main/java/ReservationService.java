package com.fleetapp;

import java.util.*;

public class ReservationService {
    private FleetManager fleetManager;
    private Map<String, Reservation> reservations;
    
    public ReservationService(FleetManager fleetManager) {
        this.fleetManager = fleetManager;
        this.reservations = new HashMap<>();
    }
    
    public Reservation createReservation(String vehicleId, String customerId, 
                                       Date pickupDate, Date returnDate) {
        Vehicle vehicle = fleetManager.findVehicle(vehicleId);
        if (vehicle == null || !vehicle.isAvailable()) {
            throw new IllegalArgumentException("Vehicle not available");
        }
        
        Reservation reservation = new Reservation(vehicleId, customerId, pickupDate, returnDate);
        reservations.put(reservation.getId(), reservation);
        vehicle.setAvailable(false);
        
        return reservation;
    }
    
    public List<Reservation> getCustomerReservations(String customerId) {
        List<Reservation> customerReservations = new ArrayList<>();
        for (Reservation res : reservations.values()) {
            if (res.get