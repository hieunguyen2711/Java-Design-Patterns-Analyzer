package com.fleetapp;

import java.util.*;

public class FleetManager {
    private Map<String, Vehicle> vehicles;
    
    public FleetManager() {
        this.vehicles = new HashMap<>();
    }
    
    public void addVehicle(Vehicle vehicle) {
        vehicles.put(vehicle.getId(), vehicle);
    }
    
    public List<Vehicle> getAvailableVehicles() {
        List<Vehicle> available = new ArrayList<>();
        for (Vehicle vehicle : vehicles.values()) {
            if (vehicle.isAvailable()) {
                available.add(vehicle);
            }
        }
        return available;
    }
    
    public Vehicle findVehicle(String id) {
        return vehicles.get(id);
    }
}