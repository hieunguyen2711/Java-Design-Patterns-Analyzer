package fleet;

import java.util.ArrayList;
import java.util.List;

public class FleetManager {
    private List<Vehicle> vehicles;
    
    public FleetManager() {
        this.vehicles = new ArrayList<>();
    }
    
    public FleetManager addVehicle(Vehicle vehicle) {
        vehicles.add(vehicle);
        return this;
    }
    
    public FleetManager removeVehicle(Vehicle vehicle) {
        vehicles.remove(vehicle);
        return this;
    }
    
    public List<Vehicle> getVehicles() {
        return new ArrayList<>(vehicles);
    }
}