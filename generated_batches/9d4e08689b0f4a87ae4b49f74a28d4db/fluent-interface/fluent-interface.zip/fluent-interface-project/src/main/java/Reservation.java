package fleet;

public class Reservation {
    private Vehicle vehicle;
    private String customerName;
    private int rentalDays;
    private double totalCost;
    
    public Reservation(Vehicle vehicle, String customerName) {
        this.vehicle = vehicle;
        this.customerName = customerName;
    }
    
    public Reservation setRentalDays(int rentalDays) {
        this.rentalDays = rentalDays;
        return this;
    }
    
    public Reservation calculateTotalCost() {
        this.totalCost = vehicle.getDailyRate() * rentalDays;
        return this;
    }
    
    // Getters