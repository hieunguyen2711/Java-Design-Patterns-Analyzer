package fleet;

public class Vehicle {
    private String make;
    private String model;
    private int year;
    private double dailyRate;
    private boolean isAvailable;
    private String maintenanceStatus;
    
    public Vehicle(String make, String model, int year) {
        this.make = make;
        this.model = model;
        this.year = year;
        this.isAvailable = true;
        this.maintenanceStatus = "NONE";
    }
    
    public Vehicle setDailyRate(double dailyRate) {
        this.dailyRate = dailyRate;
        return this;
    }
    
    public Vehicle setIsAvailable(boolean isAvailable) {
        this.isAvailable = isAvailable;
        return this;
    }
    
    public Vehicle setMaintenanceStatus(String maintenanceStatus) {
        this.maintenanceStatus = maintenanceStatus;
        return this;
    }
    
    // Getters
    public String getMake() { return make; }
    public String getModel() { return model; }
    public int getYear() { return year; }
    public double getDailyRate() { return dailyRate; }
    public boolean isAvailable() { return isAvailable; }
    public String getMaintenanceStatus() { return maintenanceStatus; }
}