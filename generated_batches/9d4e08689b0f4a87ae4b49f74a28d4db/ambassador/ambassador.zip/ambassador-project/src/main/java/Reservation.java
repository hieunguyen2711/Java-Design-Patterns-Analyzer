package fleetmanagement;

import java.time.LocalDate;

public class Reservation {
    private String id;
    private String customerId;
    private Vehicle vehicle;
    private LocalDate pickupDate;
    private LocalDate returnDate;
    
    public Reservation(String id, String customerId, Vehicle vehicle, 
                      LocalDate pickupDate, LocalDate returnDate) {
        this.id = id;
        this.customerId = customerId;
        this.vehicle = vehicle;
        this.pickupDate =