package fleetmanagement;

import java.util.*;

public class FleetManager {
    private static FleetManager instance;
    private Map<String, Vehicle> vehicles;
    
    private FleetManager() {
        this.vehicles = new HashMap<>();
    }
    
    public static FleetManager getInstance() {
        if (instance == null) {
            instance = new FleetManager();
        }
        return instance;
    }
    
    public void addVehicle(Vehicle vehicle) {
        vehicles.put(vehicle.getId(), vehicle);
    }
    
    public Vehicle getVehicle(String id) {
        return vehicles.get(id);
    }
    
    public List<Vehicle> getAllVehicles() {
        return new ArrayList<>(vehicles.values());
    }
    
    public List<Vehicle> getAvailableVehicles() {
        List<Vehicle> available = new ArrayList<>();
        for (Vehicle vehicle : vehicles.values()) {
            if (vehicle.isAvailable()) {
                available.add(vehicle);
            }
        }
        return available;
    }
}