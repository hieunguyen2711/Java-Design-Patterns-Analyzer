public class Request {
    private final Runnable task;
    private final String id;
    
    public Request(Runnable task, String id) {
        this.task = task;
        this.id = id;
    }
    
    public Runnable getTask() {
        return task;
    }
    
    public String getId() {
        return id;
    }
}