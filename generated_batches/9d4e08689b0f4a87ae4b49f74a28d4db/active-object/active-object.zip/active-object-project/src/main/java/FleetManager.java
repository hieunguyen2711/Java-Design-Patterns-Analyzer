public class FleetManager {
    private final ActiveObject activeObject;
    
    public FleetManager(ActiveObject activeObject) {
        this.activeObject = activeObject;
    }
    
    public void reserveVehicle(String vehicleId, String customerId) {
        Runnable task = () -> {
            // Simulate reservation logic
            System.out.println("Reserving vehicle " + vehicleId + " for customer " + customerId);
            try {
                Thread.sleep(100); // Simulate processing time
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            System.out.println("Reservation completed for vehicle " + vehicleId);
        };
        
        activeObject.scheduleRequest(new Request(task, "RESERVE_" +