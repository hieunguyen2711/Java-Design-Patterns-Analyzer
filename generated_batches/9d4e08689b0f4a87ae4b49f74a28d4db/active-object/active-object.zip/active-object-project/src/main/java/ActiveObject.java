public interface ActiveObject {
    void scheduleRequest(Request request);
}