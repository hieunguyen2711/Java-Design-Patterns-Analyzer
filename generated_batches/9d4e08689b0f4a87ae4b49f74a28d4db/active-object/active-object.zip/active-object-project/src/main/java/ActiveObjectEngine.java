import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class ActiveObjectEngine implements ActiveObject {
    private final BlockingQueue<Request> requestQueue = new LinkedBlockingQueue<>();
    private final Thread workerThread;
    
    public ActiveObjectEngine() {
        this.workerThread = new Thread(this::processRequests);
        this.workerThread.start();
    }
    
    @Override
    public void scheduleRequest(Request request) {
        try {
            requestQueue.put(request);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Interrupted while scheduling request", e);
        }
    }
    
    private void processRequests() {
        while (!Thread.currentThread().isInterrupted()) {
            try {
                Request request = requestQueue.take();
                request.getTask().run();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            } catch (Exception e) {
                // Handle exceptions in processing
                System.err.println("Error processing request: " + e.getMessage());
            }
        }
    }
    
    public void shutdown() {
        workerThread.interrupt();
    }
}