import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VehicleDAOImpl implements VehicleDAO {
    private Connection connection;
    
    public VehicleDAOImpl(Connection connection) {
        this.connection = connection;
    }
    
    @Override
    public void save(Vehicle vehicle) {
        try {
            String sql = "INSERT INTO vehicles (make, model, year, license_plate, is_available) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, vehicle.getMake());
            statement.setString(2, vehicle.getModel());
            statement.setInt(3, vehicle.getYear());
            statement.setString(4, vehicle.getLicensePlate());
            statement.setBoolean(5, vehicle.isAvailable());
            statement.executeUpdate();
        } catch (SQLException