import java.util.List;

public interface VehicleDAO {
    void save(Vehicle vehicle);
    void update(Vehicle vehicle);
    void delete(int id);
    Vehicle findById(int id);
    List<Vehicle> findAll();
}