public class Client {
    public static void main(String[] args) {
        BusinessDelegate businessDelegate = new BusinessDelegate();
        
        businessDelegate.setFleetInventoryService(new FleetInventoryService());
        businessDelegate.setReservationService(new ReservationService());
        businessDelegate.setMaintenanceService(new MaintenanceService());
        
        System.out.println(businessDelegate.checkVehicleAvailability("V001"));
        System.out.println(businessDelegate.processVehicleReservation("V001", "C123"));
        System.out.println(businessDelegate.getMaintenanceStatus("V001"));
    }
}