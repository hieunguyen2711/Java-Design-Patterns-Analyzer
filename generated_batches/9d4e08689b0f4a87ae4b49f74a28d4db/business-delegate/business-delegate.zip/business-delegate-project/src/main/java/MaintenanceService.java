public class MaintenanceService {
    public String getMaintenanceStatus(String vehicleId) {
        // Simulate checking maintenance status
        return "Vehicle " + vehicleId + " maintenance status: OK";
    }
}