public class BusinessDelegate {
    private FleetInventoryService fleetInventoryService;
    private ReservationService reservationService;
    private MaintenanceService maintenanceService;
    
    public void setFleetInventoryService(FleetInventoryService fleetInventoryService) {
        this.fleetInventoryService = fleetInventoryService;
    }
    
    public void setReservationService(ReservationService reservationService) {
        this.reservationService = reservationService;
    }
    
    public void setMaintenanceService(MaintenanceService maintenanceService) {
        this.maintenanceService = maintenanceService;
    }
    
    public String processVehicleReservation(String vehicleId, String customerId) {
        return reservationService.makeReservation(vehicleId, customerId);
    }
    
    public String checkVehicleAvailability(String vehicleId) {
        return fleetInventoryService.checkAvailability(vehicleId);
    }
    
    public String getMaintenanceStatus(String vehicleId) {
        return maintenanceService.getMaintenanceStatus(vehicleId);
    }
}