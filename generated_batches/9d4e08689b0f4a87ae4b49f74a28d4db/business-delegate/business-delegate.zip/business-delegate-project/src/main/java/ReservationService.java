public class ReservationService {
    public String makeReservation(String vehicleId, String customerId) {
        // Simulate making reservation
        return "Reserved vehicle " + vehicleId + " for customer " + customerId;
    }
}