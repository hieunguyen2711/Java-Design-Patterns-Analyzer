public class FleetInventoryService {
    public String checkAvailability(String vehicleId) {
        // Simulate checking inventory
        return "Vehicle " + vehicleId + " is available";
    }
}