public class Main {
    public static void main(String[] args) {
        FleetInventory fleet = new FleetInventory();
        
        fleet.addVehicle(new Vehicle("V001", "Toyota", "Camry", 2020));
        fleet.addVehicle(new Vehicle("V002", "Honda", "Civic", 2019));
        fleet.addVehicle(new Vehicle("V003", "Ford", "F-150", 2021));
        
        System.out.println("Iterating through fleet inventory:");
        for (Vehicle vehicle : fleet) {
            System.out.println(vehicle);
        }
    }
}