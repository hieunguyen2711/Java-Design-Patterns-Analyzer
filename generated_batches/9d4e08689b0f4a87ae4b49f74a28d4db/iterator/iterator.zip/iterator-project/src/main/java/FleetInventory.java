import java.util.*;

public class FleetInventory {
    private List<Vehicle> vehicles;
    
    public FleetInventory() {
        this.vehicles = new ArrayList<>();
    }
    
    public void addVehicle(Vehicle vehicle) {
        vehicles.add(vehicle);
    }
    
    public Iterator<Vehicle> iterator() {
        return vehicles.iterator();
    }
}