package fleet;

public class Vehicle {
    private String id;
    private String model;
    private double dailyRate;
    private boolean isAvailable;
    private MaintenanceStatus maintenanceStatus;
    
    public Vehicle(String id, String model, double dailyRate) {
        this.id = id;
        this.model = model;
        this.dailyRate = dailyRate;
        this.isAvailable = true;
        this.maintenanceStatus = MaintenanceStatus.NORMAL;
    }
    
    public Memento saveState() {
        return new Memento(id, model, dailyRate, isAvailable, maintenanceStatus);
    }
    
    public void restoreState(Memento memento) {
        this.id = memento.getId();
        this.model = memento.getModel();
        this.dailyRate = memento.getDailyRate();
        this.isAvailable = memento.isAvailable();
        this.maintenanceStatus = memento.getMaintenanceStatus();
    }
    
    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getModel() { return model; }
    public void setModel(String model) { this.model = model; }
    
    public double getDailyRate() { return dailyRate; }
    public void setDailyRate(double dailyRate) { this.dailyRate = dailyRate; }
    
    public boolean isAvailable() { return isAvailable; }
    public void setAvailable(boolean available) { isAvailable = available; }
    
    public MaintenanceStatus getMaintenanceStatus() { return maintenanceStatus; }
    public void setMaintenanceStatus(MaintenanceStatus maintenanceStatus) { 
        this.maintenanceStatus = maintenanceStatus; 
    }
}