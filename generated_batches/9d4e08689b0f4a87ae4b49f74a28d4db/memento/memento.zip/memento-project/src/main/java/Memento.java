package fleet;

public class Memento {
    private final String id;
    private final String model;
    private final double dailyRate;
    private final boolean isAvailable;
    private final MaintenanceStatus maintenanceStatus;
    
    public Memento(String id, String model, double dailyRate, boolean isAvailable, MaintenanceStatus maintenanceStatus) {
        this.id = id;
        this.model = model;
        this.dailyRate = dailyRate;
        this.isAvailable = isAvailable;
        this.maintenanceStatus = maintenanceStatus;
    }
    
    // Getters
    public String getId() { return id; }
    public String getModel() { return model; }
    public double getDailyRate() { return dailyRate; }
    public