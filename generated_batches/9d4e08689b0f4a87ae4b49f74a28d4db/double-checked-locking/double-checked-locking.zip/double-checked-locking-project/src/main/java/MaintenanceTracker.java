public class MaintenanceTracker {
    private static volatile MaintenanceTracker instance;
    
    private MaintenanceTracker() {
        // Private constructor to prevent instantiation
    }
    
    public static MaintenanceTracker getInstance() {
        if (instance == null) {
            synchronized (MaintenanceTracker.class) {
                if (instance == null) {
                    instance = new MaintenanceTracker();
                }
            }
        }
        return instance;
    }
    
    public void updateMaintenanceStatus(Vehicle vehicle, String status) {
        System.out.println("Updating maintenance status for vehicle " + 
                          vehicle