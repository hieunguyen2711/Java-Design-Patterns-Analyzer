public class FleetManager {
    private static volatile FleetManager instance;
    
    private FleetManager() {
        // Private constructor to prevent instantiation
    }
    
    public static FleetManager getInstance() {
        if (instance == null) {
            synchronized (FleetManager.class) {
                if (instance == null) {
                    instance = new FleetManager();
                }
            }
        }
        return instance;
    }
    
    public void manageVehicles() {
        System.out.println("Managing fleet vehicles...");
    }
}