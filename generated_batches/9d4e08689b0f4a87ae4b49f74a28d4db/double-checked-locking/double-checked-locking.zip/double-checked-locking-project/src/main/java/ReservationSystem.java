public class ReservationSystem {
    private static volatile ReservationSystem instance;
    
    private ReservationSystem() {
        // Private constructor to prevent instantiation
    }
    
    public static ReservationSystem getInstance() {
        if (instance == null) {
            synchronized (ReservationSystem.class) {
                if (instance == null) {
                    instance = new ReservationSystem();
                }
            }
        }
        return instance;
    }
    
    public void processReservation(Vehicle vehicle) {
        System.out.println("Processing reservation for vehicle: " + vehicle.getId());
    }
}