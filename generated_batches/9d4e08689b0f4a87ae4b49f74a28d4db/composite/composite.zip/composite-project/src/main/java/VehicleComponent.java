public class VehicleComponent implements FleetComponent {
    private Vehicle vehicle;
    
    public VehicleComponent(Vehicle vehicle) {
        this.vehicle = vehicle;
    }
    
    @Override
    public String getId() {
        return vehicle.getId();
    }
    
    @Override
    public void add(FleetComponent component) {
        throw new UnsupportedOperationException("Cannot add to leaf node");
    }
    
    @Override
    public void remove(FleetComponent component) {
        throw new UnsupportedOperationException("Cannot remove from leaf node");
    }
    
    @Override
    public List<FleetComponent> getChildren() {
        return null;
    }
    
    @Override
    public double calculateValue() {
        // Simple pricing logic for demonstration
        return vehicle.getYear() * 1000.0;
    }
}