import java.util.List;

public interface FleetComponent {
    String getId();
    void add(FleetComponent component);
    void remove(FleetComponent component);
    List<FleetComponent> getChildren();
    double calculateValue();
}