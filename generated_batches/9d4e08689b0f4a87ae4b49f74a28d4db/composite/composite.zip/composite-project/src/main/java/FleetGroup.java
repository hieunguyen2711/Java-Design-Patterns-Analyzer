import java.util.ArrayList;
import java.util.List;

public class FleetGroup implements FleetComponent {
    private String id;
    private List<FleetComponent> components;
    
    public FleetGroup(String id) {
        this.id = id;
        this.components = new ArrayList<>();
    }
    
    @Override
    public String getId() {
        return id;
    }
    
    @Override
    public void add(FleetComponent component) {
        components.add(component);
    }
    
    @Override
    public void remove(FleetComponent component) {
        components.remove(component);
    }
    
    @Override
    public List<FleetComponent> getChildren() {