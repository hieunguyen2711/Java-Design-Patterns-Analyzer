import java.util.ArrayList;
import java.util.List;

public class FleetModel {
    private List<Vehicle> vehicles;
    
    public FleetModel() {
        this.vehicles = new ArrayList<>();
    }
    
    public void addVehicle(String make, String type, double dailyRate) {
        Vehicle vehicle = new Vehicle(make, type, dailyRate);
        vehicles.add(vehicle);
    }
    
    public List<Vehicle> getVehicles() {
        return vehicles;
    }
    
    public static class Vehicle {
        private String make;
        private String type;
        private double dailyRate;
        
        public Vehicle(String make, String type, double dailyRate) {
            this.make = make;
            this.type = type;
            this.dailyRate = dailyRate;
        }
        
        public String getMake() { return make; }
        public String getType() { return type; }
        public double getDailyRate() { return dailyRate; }
    }
}