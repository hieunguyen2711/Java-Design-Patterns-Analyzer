import java.util.List;

public class FleetPresenter {
    private FleetModel model;
    private FleetView view;
    
    public FleetPresenter(FleetModel model, FleetView view) {
        this