import java.util.List;

public class FleetView {
    
    public void displayVehicles(List<FleetModel.Vehicle> vehicles) {
        System.out.println("=== Fleet Inventory ===");
        for (FleetModel.Vehicle vehicle : vehicles) {
            System.out.printf("- %s (%s): $%.2f/day%n", 
                vehicle.getMake(), vehicle.getType(), vehicle.getDailyRate());
        }
    }
    
    public void displayMessage(String message) {
        System.out.println(message);
    }
}