public class FleetInventoryApp {
    public static void main(String[] args) {
        // Create the presenter with model and view
        FleetModel model = new FleetModel();
        FleetView view = new FleetView();
        FleetPresenter presenter = new FleetPresenter(model, view);
        
        // Initialize the application
        presenter.initialize();
        
        // Simulate user interactions
        presenter.addVehicle("Toyota Camry", "Sedan", 45.00);
        presenter.addVehicle("Ford F-150", "Truck", 65.00);
        presenter.displayVehicles();
    }
}