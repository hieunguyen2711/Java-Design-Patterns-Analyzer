package fleet;

public interface VehicleService {
    void reserveVehicle(String vehicleId, String customerId);
    void returnVehicle(String vehicleId);
    double calculateRentalCost(String vehicleId, int days);
}