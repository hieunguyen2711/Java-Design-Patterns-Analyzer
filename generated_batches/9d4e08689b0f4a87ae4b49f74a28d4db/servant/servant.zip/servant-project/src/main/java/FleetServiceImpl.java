package fleet;

import java.util.HashMap;
import java.util.Map;

public class FleetServiceImpl implements VehicleService {
    private final Map<String, Vehicle> vehicles = new HashMap<>();
    
    public FleetServiceImpl() {
        // Initialize with some sample data
        vehicles.put("V001", new Vehicle("V001", "Toyota Camry", 50.0));
        vehicles.put("V002", new Vehicle("V002", "Honda Civic", 40.0));
        vehicles.put("V003", new Vehicle("V003", "Ford F-150", 70.0));
    }
    
    @Override
    public void reserveVehicle(String vehicleId, String customerId) {
        Vehicle vehicle = vehicles.get(vehicleId);
        if (vehicle != null && !vehicle.isReserved()) {
            vehicle.setReserved(true);
            System.out.println("Vehicle " + vehicleId + " reserved for customer " + customerId);
        } else {
            throw new RuntimeException("Vehicle not available for reservation");
        }
    }
    
    @Override
    public void returnVehicle(String vehicleId) {
        Vehicle vehicle = vehicles.get(vehicleId);
        if (vehicle != null && vehicle.isReserved()) {
            vehicle.setReserved(false);
            System.out.println("Vehicle " + vehicleId + " returned and now available");
        } else {
            throw new RuntimeException("Vehicle not found or not reserved");
        }
    }
    
    @Override
    public double calculateRentalCost(String vehicleId, int days)