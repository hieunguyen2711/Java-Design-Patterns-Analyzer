package fleet;

public class FleetManager {
    private final VehicleService vehicleService;
    
    public FleetManager(VehicleService vehicleService) {
        this.vehicleService = vehicleService;
    }
    
    public void processReservation(String vehicleId, String customerId) {
        vehicleService.reserveVehicle(vehicleId, customerId);
    }
    
    public void processReturn(String vehicleId) {
        vehicleService.returnVehicle(vehicleId);
    }
    
    public double calculateRentalCost(String vehicleId, int days) {
        return vehicleService.calculateRentalCost(vehicleId, days);
    }
}