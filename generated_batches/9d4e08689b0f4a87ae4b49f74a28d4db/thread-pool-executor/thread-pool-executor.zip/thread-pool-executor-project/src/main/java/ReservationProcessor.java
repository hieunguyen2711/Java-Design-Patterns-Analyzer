package com.fleet.management;

public class ReservationProcessor implements Runnable {
    private final String reservationId;
    
    public ReservationProcessor(String reservationId) {
        this.reservationId = reservationId;
    }
    
    @Override
    public void run() {
        System.out.println("Processing reservation: " + reservationId);
        try {
            Thread