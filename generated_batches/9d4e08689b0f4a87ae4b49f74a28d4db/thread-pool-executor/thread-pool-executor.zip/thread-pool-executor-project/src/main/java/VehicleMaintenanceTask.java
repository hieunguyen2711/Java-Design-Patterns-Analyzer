package com.fleet.management;

public class VehicleMaintenanceTask implements Runnable {
    private final String vehicleId;
    
    public VehicleMaintenanceTask(String vehicleId) {
        this.vehicleId = vehicleId;
    }
    
    @Override
    public void run() {
        System.out.println("Starting maintenance for: " + vehicleId);
        try {
            Thread.sleep(1500); // Simulate work
            System.out.println("Completed maintenance for: " + vehicleId);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}