package com.fleetmanager.service;

import com.fleetmanager.model.Vehicle;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FleetManager {
    private List<Vehicle> vehicles;
    
    public FleetManager(List<Vehicle> vehicles) {
        this.vehicles = vehicles;
    }
    
    // Function composition example: create a composite function that first filters by year,
    // then maps to make/model, and finally collects into a list
    public List<String> getVehicleDescriptions(Function<Integer, Boolean> yearFilter) {
        return vehicles.stream()
            .filter(vehicle -> yearFilter.apply(vehicle.getYear()))
            .map(vehicle -> vehicle.getMake() + " " + vehicle.getModel())
            .collect(Collectors.toList());
    }
    
    // Another function composition: price calculation with multiple composed functions
    public double calculateTotalPrice(Function<Vehicle, Double> baseCalculator,
                                    Function<Double, Double> taxApplier,
                                    Function<Double, Double> discountApplier) {
        return vehicles.stream()
            .map(baseCalculator)
            .map(taxApplier)
            .map(discountApplier)
            .reduce(0.0, Double::sum);
    }
    
    public List