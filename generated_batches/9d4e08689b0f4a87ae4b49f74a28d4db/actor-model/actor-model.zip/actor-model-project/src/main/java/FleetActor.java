import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class FleetActor {
    private final BlockingQueue<Message> messageQueue;
    private volatile boolean running;
    
    public FleetActor() {
        this.messageQueue = new LinkedBlockingQueue<>();
        this.running = true;
        start();
    }
    
    public void send(Message message) {
        try {
            messageQueue.put(message);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
    
    private void start() {
        Thread actorThread = new Thread(() -> {
            while (running) {
                try {
                    Message message = messageQueue.take();
                    processMessage(message);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        });
        actorThread.start();
    }
    
    private void processMessage(Message message) {
        switch (message.getType()) {
            case "RESERVE":
                handleReserve((ReserveRequest) message);
                break;
            case "RETURN":
                handleReturn((ReturnRequest) message);
                break;
            case "STATUS":
                handleStatus((StatusRequest) message);
                break;
            default:
                throw new IllegalArgumentException("Unknown message type: " + message.getType());
        }
    }
    
    private void handleReserve(ReserveRequest