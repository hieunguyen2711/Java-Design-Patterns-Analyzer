package fleet;

public class Truck extends Vehicle {
    private double cargoCapacity;
    
    public Truck(String id, String make, String model, int year, double cargoCapacity) {
        super(id, make, model, year);
        this.cargoCapacity = cargoCapacity;
    }
    
    @Override
    public double calculateRentalCost(int days) {
        return days * 50.0 + (cargoCapacity > 2000 ? 100 : 50);
    }
    
    public double getCargoCapacity() {
        return cargoCapacity;
    }
}