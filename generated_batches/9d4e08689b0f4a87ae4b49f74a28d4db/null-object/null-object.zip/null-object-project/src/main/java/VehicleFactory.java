package fleet;

public class VehicleFactory {
    private static final String[] CAR_TYPES = {"SEDAN", "SUV", "H