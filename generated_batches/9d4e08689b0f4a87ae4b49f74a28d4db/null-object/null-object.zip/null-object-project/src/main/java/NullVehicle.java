package fleet;

public class NullVehicle extends Vehicle {
    
    public NullVehicle() {
        super("NULL", "Unknown", "Unknown", 0);
    }
    
    @Override
    public double calculateRentalCost(int days) {
        return 0.0;
    }
}