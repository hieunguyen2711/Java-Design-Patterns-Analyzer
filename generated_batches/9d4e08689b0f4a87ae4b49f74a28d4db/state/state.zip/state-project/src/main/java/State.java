public abstract class State {
    protected Vehicle vehicle;
    
    public State(Vehicle vehicle) {
        this.vehicle = vehicle;
    }
    
    public abstract void reserve();
    public abstract void pickup();
    public abstract void returnVehicle();
    public abstract void performMaintenance();
    public abstract void completeMaintenance();
}