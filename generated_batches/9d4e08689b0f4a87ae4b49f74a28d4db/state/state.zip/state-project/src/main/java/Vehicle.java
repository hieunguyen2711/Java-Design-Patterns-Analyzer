public class Vehicle {
    private String id;
    private String make;
    private String model;
    private State currentState;
    
    public Vehicle(String id, String make, String model) {
        this.id = id;
        this.make = make;
        this.model = model;
        this.currentState = new AvailableState(this);
    }
    
    public void reserve() {
        currentState.reserve();
    }
    
    public void pickup() {
        currentState.pickup();
    }
    
    public void returnVehicle() {
        currentState.returnVehicle();
    }
    
    public void performMaintenance() {
        currentState.performMaintenance();
    }
    
    public void completeMaintenance() {
        currentState.completeMaintenance();
    }
    
    public String getId() {
        return id;
    }
    
    public String getMake() {
        return make;
    }
    
    public String getModel() {
        return model;
    }
    
    public State getCurrentState() {
        return currentState;
    }
    
    public void setCurrentState(State currentState) {
        this.currentState = currentState;
    }
}