public class ReservedState extends State {
    public ReservedState(Vehicle vehicle) {
        super(vehicle);