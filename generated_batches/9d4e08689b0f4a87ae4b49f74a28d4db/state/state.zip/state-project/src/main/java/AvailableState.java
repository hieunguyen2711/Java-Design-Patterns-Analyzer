public class AvailableState extends State {
    public AvailableState(Vehicle vehicle) {
        super(vehicle);
    }
    
    @Override
    public void reserve() {
        System.out.println("Vehicle " + vehicle.getId() + " reserved.");
        vehicle.setCurrentState(new ReservedState(vehicle));
    }
    
    @Override
    public void pickup() {
        throw new IllegalStateException("Cannot pickup available vehicle");
    }
    
    @Override
    public void returnVehicle() {
        throw new IllegalStateException("Cannot return available vehicle");
    }
    
    @Override
    public void performMaintenance() {
        System.out.println("Vehicle " + vehicle.getId() + " sent for maintenance.");
        vehicle.setCurrentState(new MaintenanceState(vehicle));
    }
    
    @Override
    public void completeMaintenance() {
        throw new IllegalStateException("Vehicle not in maintenance state");
    }
}