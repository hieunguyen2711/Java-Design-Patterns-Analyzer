package fleetmanagement;

import java.util.*;

public class FleetManager {
    private final Map<String, Vehicle> vehicles;
    
    public FleetManager() {
        this.vehicles = new HashMap<>();
    }
    
    public void addVehicle(Vehicle vehicle) {
        vehicles.put(vehicle.getId(), vehicle);
    }
    
    public Optional<Vehicle> getAvailableVehicle(String id) {
        Vehicle vehicle = vehicles.get(id);
        if (vehicle != null && vehicle.isAvailable()) {
            return Optional.of(vehicle);
        }
        return Optional.empty();
    }
    
    public void removeVehicle(String id) {
        vehicles.remove(id);
    }
}