package fleetmanagement;

import java.time.LocalDateTime;
import java.util.concurrent.atomic.AtomicBoolean;

public class Reservation implements AutoCloseable {
    private final Vehicle vehicle;
    private final LocalDateTime pickupTime;
    private final LocalDateTime returnTime;
    private final AtomicBoolean isActive;
    
    public Reservation(Vehicle vehicle, LocalDateTime pickupTime, LocalDateTime returnTime) {
        this.vehicle = vehicle;
        this.pickupTime = pickupTime;
        this.returnTime = returnTime;
        this.isActive = new AtomicBoolean(true);
        
        // RAII: Acquire resource (mark vehicle as reserved)
        if (!vehicle.isAvailable()) {
            throw new IllegalStateException("Vehicle is not available for reservation");
        }
        vehicle.setAvailable(false);
    }
    
    public Vehicle getVehicle() {
        return vehicle;
    }
    
    public LocalDateTime getPickupTime() {
        return pickupTime;
    }
    
    public LocalDateTime getReturnTime() {
        return returnTime;
    }
    
    public boolean isActive() {
        return isActive.get