package com.fleetmanager.service;

import com.fleetmanager.dto.VehicleDTO;
import java.util.ArrayList;
import java.util.List;

public class VehicleService {
    private List<VehicleDTO> vehicles;
    
    public VehicleService() {
        this.vehicles = new ArrayList<>();
    }
    
    public void addVehicle(VehicleDTO vehicle) {
        vehicles.add(vehicle);
    }
    
    public List<VehicleDTO> getAllVehicles() {
        return new ArrayList<>(vehicles);
    }
    
    public VehicleDTO getVehicleById(String id) {
        for