public class ReservationRequest {
    private String vehicleId