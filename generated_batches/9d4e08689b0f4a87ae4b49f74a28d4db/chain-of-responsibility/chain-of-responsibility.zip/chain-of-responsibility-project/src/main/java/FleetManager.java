import java.util.ArrayList;
import java.util.List;

public class FleetManager {
    private List<Vehicle> vehicles;
    private Handler handlerChain;
    
    public FleetManager() {
        this.vehicles = new ArrayList<>();
        this.handlerChain = setupHandlerChain();
    }
    
    private Handler setupHandlerChain() {
        Handler availabilityHandler = new AvailabilityHandler();
        Handler maintenanceHandler = new MaintenanceHandler();
        Handler pricingHandler = new PricingHandler();
        
        availabilityHandler.setNext(maintenanceHandler);
        maintenanceHandler.setNext(pricingHandler);
        
        return availabilityHandler;
    }
    
    public void addVehicle(Vehicle vehicle) {
        vehicles.add(vehicle);
    }
    
    public boolean processReservation(String vehicleId, String customerName) {
        ReservationRequest request = new ReservationRequest(vehicleId, customerName);
        return handlerChain.handle(request);
    }
    
    public List<Vehicle> getVehicles() {
        return vehicles;
    }
}