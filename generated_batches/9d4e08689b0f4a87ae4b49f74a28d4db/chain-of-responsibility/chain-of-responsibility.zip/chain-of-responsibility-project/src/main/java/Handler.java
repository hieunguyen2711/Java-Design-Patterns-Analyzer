public abstract class Handler {
    protected Handler nextHandler;
    
    public void setNext(Handler next) {
        this.nextHandler = next;
    }
    
    public abstract boolean handle(ReservationRequest request);
}