package com.fleetmanager.service.impl;

import com.fleetmanager.model.Vehicle;
import com.fleetmanager.service.FleetService;
import java.util.*;
import java.util.stream.Collectors;

public class FleetServiceImpl implements FleetService {
    private final Map<String, Vehicle> vehicleRepository = new HashMap<>();
    
    @Override
    public List<Vehicle> getAllVehicles() {
        return new ArrayList<>(vehicleRepository.values());
    }
    
    @Override
    public Optional<Vehicle> getVehicleById(String id) {
        return Optional.ofNullable(vehicleRepository.get