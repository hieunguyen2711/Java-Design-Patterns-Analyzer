package com.fleetmanager.service;

import java.util.List;
import java.util.Optional;

public interface FleetService {
    List<Vehicle> getAllVehicles();
    Optional<Vehicle> getVehicleById(String id);
    Vehicle addVehicle(Vehicle vehicle);
    void removeVehicle(String id);
    List<Vehicle> getAvailableVehicles();
    List<Vehicle> getMaintenanceVehicles();
}