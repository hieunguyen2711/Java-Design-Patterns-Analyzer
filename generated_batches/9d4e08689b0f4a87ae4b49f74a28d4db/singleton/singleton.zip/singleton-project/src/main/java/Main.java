public class Main {
    public static void main(String[] args) {
        // Demonstrating singleton pattern - all systems share the