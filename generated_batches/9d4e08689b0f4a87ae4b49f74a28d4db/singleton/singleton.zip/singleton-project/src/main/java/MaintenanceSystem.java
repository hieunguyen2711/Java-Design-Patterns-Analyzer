public class MaintenanceSystem {
    private FleetManager fleetManager;
    
    public MaintenanceSystem() {
        this.fleetManager = FleetManager.getInstance();
    }
    
    public void updateVehicleStatus(String vehicleId, String status) {
        fleetManager.updateMaintenanceStatus(vehicleId, status);
    }
}