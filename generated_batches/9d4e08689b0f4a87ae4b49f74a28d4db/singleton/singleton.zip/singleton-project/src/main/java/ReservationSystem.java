public class ReservationSystem {
    private FleetManager fleetManager;
    
    public ReservationSystem() {
        this.fleetManager = FleetManager.getInstance();
    }
    
    public void makeReservation(String vehicleId, String customerId) {
        fleetManager.processReservation(vehicleId, customerId);
    }
}