public class FleetManager {
    private static volatile FleetManager instance;
    
    private FleetManager() {
        // Private constructor to prevent instantiation
    }
    
    public static FleetManager getInstance() {
        if (instance == null) {
            synchronized (FleetManager.class) {
                if (instance == null) {
                    instance = new FleetManager();
                }
            }
        }
        return instance;
    }
    
    public void processReservation(String vehicleId, String customerId) {
        System.out.println("Processing reservation for vehicle " + vehicleId + 
                          " by customer " + customerId);
    }
    
    public void updateMaintenanceStatus(String vehicleId, String status) {
        System.out.println("Updating maintenance status for vehicle " + vehicleId + 
                          " to " + status);
    }
}