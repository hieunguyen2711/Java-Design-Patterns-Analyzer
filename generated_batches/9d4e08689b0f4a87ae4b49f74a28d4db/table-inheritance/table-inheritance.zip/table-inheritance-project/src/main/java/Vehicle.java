package fleet.inventory;

public abstract class Vehicle {
    protected String make;
    protected String model;
    protected int year;
    protected double dailyRate;
    
    public Vehicle(String make, String model, int year, double dailyRate) {
        this.make = make;
        this.model = model;
        this.year = year;
        this.dailyRate = dailyRate;
    }
    
    public abstract double calculateRentalCost(int days);
    
    public String getMake() { return make; }
    public String getModel() { return model; }
    public int getYear() { return year; }
    public double getDailyRate() { return dailyRate; }
}