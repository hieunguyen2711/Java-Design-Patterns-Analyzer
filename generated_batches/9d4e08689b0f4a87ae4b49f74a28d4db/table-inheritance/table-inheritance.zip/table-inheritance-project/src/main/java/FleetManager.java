package fleet.inventory;

import java.util.ArrayList;
import java.util.List;

public class FleetManager {
    private List<Vehicle> vehicles;
    
    public FleetManager() {
        this.vehicles = new ArrayList<>();
    }
    
    public void addVehicle(Vehicle vehicle) {
        vehicles.add(vehicle);
    }
    
    public double calculateTotalRentalCost(String make, String model, int days) {
        for (Vehicle vehicle : vehicles) {
            if (vehicle.getMake().equals(make) && vehicle.getModel().equals(model))