package fleet.inventory;

public class Car extends Vehicle {
    private int numberOfDoors;
    
    public Car(String make, String model, int year, double dailyRate, int numberOfDoors) {
        super(make, model, year, dailyRate);
        this.numberOfDoors = numberOfDoors;
    }
    
    @Override
    public double calculateRentalCost(int days) {
        return days * dailyRate;
    }
    
    public int getNumberOfDoors() { return numberOfDoors; }
}