package fleet.inventory;

public class Truck extends Vehicle {
    private double cargoCapacity;
    
    public Truck(String make, String model, int year, double dailyRate, double cargoCapacity) {
        super(make, model, year, dailyRate);
        this.cargoCapacity = cargoCapacity;
    }
    
    @Override
    public double calculateRentalCost(int days) {
        return days * dailyRate + (cargoCapacity > 2000 ? 50.0 : 0.0);
    }
    
    public double getCargoCapacity() { return cargoCapacity; }
}