import java.util.List;
import java.util.ArrayList;

public class ReserveVehicleCommand implements Command {
    private FleetManager fleetManager;
    private String vehicleId;
    private Vehicle reservedVehicle;
    
    public ReserveVehicleCommand(FleetManager fleetManager, String vehicleId) {
        this.fleetManager = fleetManager;
        this.vehicleId = vehicleId;
    }
    
    @Override
    public void execute() {