import java.util.*;

public class FleetManager {
    private List<Vehicle> vehicles;
    private Queue<Command> commandHistory;
    
    public FleetManager() {
        this.vehicles = new ArrayList<>();
        this.commandHistory = new LinkedList<>();
    }
    
    public void addVehicle(Vehicle vehicle) {
        vehicles.add(vehicle);
    }
    
    public void executeCommand(Command command) {
        command.execute();
        commandHistory.offer(command);
    }
    
    public void undoLastCommand() {
        if (!commandHistory.isEmpty()) {
            Command lastCommand = commandHistory.poll();
            lastCommand.undo();
        }
    }
    
    public List<Vehicle> getVehicles() {
        return new ArrayList<>(vehicles);
    }
}