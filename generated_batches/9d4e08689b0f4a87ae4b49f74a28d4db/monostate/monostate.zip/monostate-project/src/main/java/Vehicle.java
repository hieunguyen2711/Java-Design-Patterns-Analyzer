public class Vehicle {
    private String id;
    private String model;
    private boolean isAvailable;
    
    public Vehicle(String id, String model) {
        this.id = id;
        this.model = model;
        this.isAvailable = true;
    }
    
    public void rent() {
        this.isAvailable = false;
        FleetManager.getInstance().rentVehicle();
    }
    
    public void returnVehicle() {
        this.isAvailable = true;
        FleetManager.getInstance().returnVehicle();
    }
    
    // Getters
    public String getId() { return id; }
    public String getModel() { return model; }
    public boolean isAvailable() { return isAvailable; }
}