public class FleetManager {
    private static FleetManager instance;
    
    // Private constructor to prevent instantiation
    private FleetManager() {}
    
    public static FleetManager getInstance() {
        if (instance == null) {
            instance = new FleetManager();
        }
        return instance;
    }
    
    // Monostate pattern - shared state across all instances
    private int totalVehicles = 0;
    private int availableVehicles = 0;
    private double dailyRevenue = 0.0;
    
    public void addVehicle() {
        totalVehicles++;
        availableVehicles++;
    }
    
    public void removeVehicle() {
        if (totalVehicles > 0) {
            totalVehicles--;
            if (availableVehicles > 0) {
                availableVehicles--;
            }
        }
    }
    
    public void rentVehicle() {
        if (availableVehicles > 0) {
            availableVehicles--;
        }
    }
    
    public void returnVehicle() {
        availableVehicles++;
    }
    
    public void addRevenue(double amount) {
        dailyRevenue += amount;
    }
    
    // Getters for shared state
    public int getTotalVehicles() {
        return totalVehicles;
    }
    
    public int getAvailableVehicles() {
        return availableVehicles;
    }
    
    public double getDailyRevenue() {
        return dailyRevenue;
    }
}