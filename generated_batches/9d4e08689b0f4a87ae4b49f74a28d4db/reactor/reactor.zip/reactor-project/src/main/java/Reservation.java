package com.fleetmanager.model;

public class Reservation {
    private String id;
    private String customerId;
    private Vehicle vehicle;
    private int rentalDays;
    
    public Reservation(String id, String customerId, Vehicle vehicle, int rentalDays) {
        this.id = id;
        this.customerId = customerId;
        this.vehicle = vehicle;
        this.rentalDays = rentalDays;
    }
    
    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getCustomerId() { return customerId; }
    public void setCustomerId(String customerId) { this.customerId = customerId; }
    
    public Vehicle getVehicle() { return vehicle; }
    public void setVehicle(Vehicle vehicle) { this.vehicle = vehicle; }
    
    public int getRentalDays() { return rentalDays; }
    public void setRentalDays(int rentalDays) { this.rentalDays = rentalDays; }
}