package socialmedia;

public class Main {
    public static void main(String[] args) {
        SocialMediaManager manager = new SocialMediaManager();
        
        // Adapting different social media APIs
        manager.addAdapter(new TwitterAdapter(new TwitterAPI()));
        manager.addAdapter(new FacebookAdapter(new FacebookAPI()));
        
        // Posting to all platforms through unified interface
        manager.postToAll("Hello World!");
    }
}