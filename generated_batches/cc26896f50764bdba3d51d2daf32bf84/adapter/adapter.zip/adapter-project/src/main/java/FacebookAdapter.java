package socialmedia;

public class FacebookAdapter implements SocialMediaAdapter {
    private FacebookAPI facebookAPI;
    
    public FacebookAdapter(FacebookAPI facebookAPI) {
        this.facebookAPI = facebookAPI;
    }
    
    @Override
    public void postToSocialMedia(String message) {
        facebookAPI.postToFacebook(message);
    }
}