package socialmedia;

public class TwitterAPI {
    public void tweet(String message) {
        System.out.println("Tweeting: " + message);
    }
}