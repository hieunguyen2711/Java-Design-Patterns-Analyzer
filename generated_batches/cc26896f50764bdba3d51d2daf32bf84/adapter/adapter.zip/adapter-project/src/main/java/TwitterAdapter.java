package socialmedia;

public class TwitterAdapter implements SocialMediaAdapter {
    private TwitterAPI twitterAPI;
    
    public TwitterAdapter(TwitterAPI twitterAPI) {
        this.twitterAPI = twitterAPI;
    }
    
    @Override
    public void postToSocialMedia(String message) {
        twitterAPI.tweet(message);
    }
}