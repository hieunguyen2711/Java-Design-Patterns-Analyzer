package socialmedia;

import java.util.ArrayList;
import java.util.List;

public class SocialMediaManager {
    private List<SocialMediaAdapter> adapters;
    
    public SocialMediaManager() {
        this.adapters = new ArrayList<>();
    }
    
    public void addAdapter(SocialMediaAdapter adapter) {
        adapters.add(adapter);
    }
    
    public void postToAll(String message) {
        for (SocialMediaAdapter adapter : adapters) {
            adapter.postToSocialMedia(message);
        }
    }
}