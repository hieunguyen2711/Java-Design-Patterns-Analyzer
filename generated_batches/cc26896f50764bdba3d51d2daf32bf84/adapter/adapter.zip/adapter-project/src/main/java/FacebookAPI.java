package socialmedia;

public class FacebookAPI {
    public void postToFacebook(String message) {
        System.out.println("Posting to Facebook: " + message);
    }
}