package socialmedia;

public interface SocialMediaAdapter {
    void postToSocialMedia(String message);
}