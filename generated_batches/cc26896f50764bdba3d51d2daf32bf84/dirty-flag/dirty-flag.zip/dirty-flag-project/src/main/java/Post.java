package socialmedia;

public class Post {
    private String content;
    private boolean isDirty;
    
    public Post(String content) {
        this.content = content;
        this.isDirty = false;
    }
    
    public String getContent() {
        return content;
    }
    
    public void setContent(String content) {
        this.content = content;
        this.isDirty = true;
    }
    
    public boolean isDirty() {
        return isDirty;
    }
    
    public void markClean() {
        this.isDirty = false;
    }
}