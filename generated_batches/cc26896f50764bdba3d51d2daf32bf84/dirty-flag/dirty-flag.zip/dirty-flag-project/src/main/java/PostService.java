package socialmedia;

import java.util.ArrayList;
import java.util.List;

public class PostService {
    private List<Post> posts;
    
    public PostService() {
        this.posts = new ArrayList<>();
    }
    
    public void addPost(Post post) {
        posts.add(post);
    }
    
    public void updatePost(int index, String newContent) {
        if (index >= 0 && index < posts.size()) {
            posts.get(index).setContent(newContent);
        }
    }
    
    public List<Post> getDirtyPosts() {
        List<Post> dirtyPosts = new ArrayList<>();
        for (Post post : posts) {
            if (post.isDirty()) {
                dirtyPosts.add(post);
            }
        }
        return dirtyPosts;
    }
    
    public void saveAllDirtyPosts() {
        for (Post post : posts) {
            if (post.isDirty()) {
                // Simulate saving to database
                System.out.println("Saving post: " + post.getContent());
                post.markClean();
            }
        }
    }
}