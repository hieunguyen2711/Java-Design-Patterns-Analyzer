package socialmedia;

public class SocialMediaApplication {
    public static void main(String[] args) {
        PostService service = new PostService();
        
        // Create posts
        Post post1 = new Post("Hello World!");
        Post post2 = new Post("Java is awesome");
        
        service.addPost(post1);
        service.addPost(post2);
        
        // Modify posts - this marks them as dirty
        service.updatePost(0, "Hello Universe!");
        service.updatePost(1, "Java is really awesome");
        
        // Check which posts are dirty
        System.out.println("Dirty posts:");
        for (Post post : service.getDirtyPosts()) {
            System.out.println("- " + post.getContent());
        }
        
        // Save all dirty posts
        service.saveAllDirtyPosts();
        
        // Verify no more dirty posts
        System.out.println("Remaining dirty posts: " + service.getDirtyPosts().size());
    }
}