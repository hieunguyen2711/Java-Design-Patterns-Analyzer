package com.socialmedia.actor;

import java.util.ArrayList;
import java.util.List;

public class User implements Actor {
    private final String userId;
    private final List<String> followers;
    private final List<String> following;
    
    public User(String userId) {
        this.userId = userId;
        this.followers = new ArrayList<>();
        this.following = new ArrayList<>();
    }
    
    @Override
    public void receive(Message message) {
        if (message instanceof PostMessage) {
            ((PostMessage) message).process();
        } else if (message instanceof FollowMessage) {
            ((FollowMessage) message).process(this);
        }
    }
    
    public String getUserId() {
        return userId;
    }
    
    public List<String> getFollowers() {
        return followers;
    }
    
    public List<String> getFollowing() {
        return following;
    }
}