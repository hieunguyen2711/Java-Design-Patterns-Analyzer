package com.socialmedia.actor;

public class FollowMessage extends Message {
    private final String targetUserId;
    
    public FollowMessage(String sender, String targetUserId) {
        super(sender);
        this.targetUserId = targetUserId;
    }
    
    @Override
    public void process() {
        // This would be handled by the receiving user's actor
    }
    
    public void process(User user) {
        if (!user.getFollowing().contains(targetUserId)) {
            user.getFollowing().add(targetUserId);
            System.out.println("User " + getSender() + " is now following " + targetUserId);
        }
    }
}