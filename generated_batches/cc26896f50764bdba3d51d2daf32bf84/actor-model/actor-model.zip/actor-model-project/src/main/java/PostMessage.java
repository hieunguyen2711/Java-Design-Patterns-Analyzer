package com.socialmedia.actor;

public class PostMessage extends Message {
    private final String content;
    
    public PostMessage(String sender, String content) {
        super(sender);
        this.content = content;
    }
    
    @Override
    public void process() {
        System.out.println("User " + getSender() + " posted: " + content);
    }
    
    public String getContent() {
        return content;
    }
}