package com.socialmedia.actor;

public interface Actor {
    void receive(Message message);
}