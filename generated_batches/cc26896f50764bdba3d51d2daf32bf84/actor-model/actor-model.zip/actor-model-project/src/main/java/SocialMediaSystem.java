package com.socialmedia.actor;

import java.util.HashMap;
import java.util.Map;

public class SocialMediaSystem {
    private final Map<String, User> users;
    
    public SocialMediaSystem() {
        this.users = new HashMap<>();
    }
    
    public void createUser(String userId) {
        users.put(userId, new User(userId));
    }
    
    public void postMessage(String userId, String content) {
        User user = users.get(userId);
        if (user != null) {
            PostMessage message = new PostMessage(userId, content);
            user.receive(message);
        }
    }
    
    public void followUser(String followerId, String targetUserId) {
        User follower = users.get(followerId);
        User target = users.get(targetUserId);
        
        if (follower != null && target != null) {
            FollowMessage message = new FollowMessage(followerId, targetUserId);
            target.receive(message);
        }
    }
    
    public static void main(String[] args) {
        SocialMediaSystem system = new SocialMediaSystem();
        system.createUser("alice");
        system.createUser("bob");
        system.createUser("charlie");
        
        system.postMessage("alice", "Hello world!");
        system.followUser("bob", "alice");
        system.followUser("charlie", "alice");
    }
}