public class UserBusinessService implements BusinessService {
    @Override
    public void doProcessing() {
        System.out.println("Processing user service");
    }
}