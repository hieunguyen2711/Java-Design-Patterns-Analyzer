public class PostBusinessService implements BusinessService {
    @Override
    public void doProcessing() {
        System.out.println("Processing post service");
    }
}