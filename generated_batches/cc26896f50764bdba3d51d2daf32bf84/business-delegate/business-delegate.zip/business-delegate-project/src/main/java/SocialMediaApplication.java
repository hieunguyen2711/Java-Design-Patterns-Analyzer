public class SocialMediaApplication {
    public static void main(String[] args) {
        BusinessDelegate businessDelegate = new BusinessDelegate();
        Client client = new Client(businessDelegate);

        businessDelegate.setServiceType("POST");
        client.doTask();

        businessDelegate.setServiceType("USER");
        client.doTask();
    }
}