public class BusinessDelegate {
    private BusinessService businessService;
    private String serviceType;

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public void doTask() {
        if (serviceType.equalsIgnoreCase("POST")) {
            businessService = new PostBusinessService();
        } else if (serviceType.equalsIgnoreCase("USER")) {
            businessService = new UserBusinessService();
        }
        businessService.doProcessing();
    }
}