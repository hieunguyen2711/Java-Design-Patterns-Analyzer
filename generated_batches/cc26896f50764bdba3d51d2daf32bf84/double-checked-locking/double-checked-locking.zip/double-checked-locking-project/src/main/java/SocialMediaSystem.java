public class SocialMediaSystem {
    private static volatile SocialMediaSystem instance;
    
    private SocialMediaSystem() {
        // Private constructor to prevent instantiation
    }
    
    public static SocialMediaSystem getInstance() {
        if (instance == null) {
            synchronized (SocialMediaSystem.class) {
                if (instance == null) {
                    instance = new SocialMediaSystem();
                }
            }
        }
        return instance;
    }
    
    public void postUpdate(String message) {
        System.out.println("Posting update: " + message);
    }
}