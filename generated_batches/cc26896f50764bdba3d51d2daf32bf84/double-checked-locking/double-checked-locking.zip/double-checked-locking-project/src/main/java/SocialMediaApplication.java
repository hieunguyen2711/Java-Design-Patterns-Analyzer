public class SocialMediaApplication {
    public static void main(String[] args) {
        // Demonstrating double-checked locking pattern
        SocialMediaSystem system1 = SocialMediaSystem.getInstance();
        SocialMediaSystem system2 = SocialMediaSystem.getInstance();
        
        System.out.println("Same instance: " + (system1 == system2));
        
        User user = new User("john_doe", "john@example.com");
        system1.postUpdate("Hello, world! This is my first post.");
    }
}