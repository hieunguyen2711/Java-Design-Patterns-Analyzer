public class FacebookPost implements Post {
    @Override
    public void publish() {
        System.out.println("Facebook post published");
    }
}