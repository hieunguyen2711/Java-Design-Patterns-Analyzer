public interface Post {
    void publish();
}