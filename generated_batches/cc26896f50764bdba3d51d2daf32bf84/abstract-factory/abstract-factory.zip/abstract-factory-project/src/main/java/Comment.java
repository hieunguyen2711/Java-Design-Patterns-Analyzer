public interface Comment {
    void addComment();
}