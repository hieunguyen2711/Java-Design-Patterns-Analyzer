public interface User {
    void authenticate();
}