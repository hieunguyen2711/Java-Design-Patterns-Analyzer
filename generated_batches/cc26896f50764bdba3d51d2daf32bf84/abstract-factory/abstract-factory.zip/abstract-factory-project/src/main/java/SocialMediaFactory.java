public interface SocialMediaFactory {
    Post createPost();
    Comment createComment();
    User createUser();
}