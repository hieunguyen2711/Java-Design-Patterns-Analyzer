public class TwitterPost implements Post {
    @Override
    public void publish() {
        System.out.println("Twitter post published");
    }
}