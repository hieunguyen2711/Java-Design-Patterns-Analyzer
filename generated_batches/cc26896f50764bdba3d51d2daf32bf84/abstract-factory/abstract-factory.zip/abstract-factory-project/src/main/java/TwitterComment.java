public class TwitterComment implements Comment {
    @Override
    public void addComment() {
        System.out.println("Twitter comment added");
    }
}