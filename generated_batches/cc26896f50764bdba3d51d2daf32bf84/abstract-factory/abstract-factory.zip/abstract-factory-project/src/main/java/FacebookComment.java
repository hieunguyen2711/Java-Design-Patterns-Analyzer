public class FacebookComment implements Comment {
    @Override
    public void addComment() {
        System.out.println("Facebook comment added");
    }
}