public class TwitterUser implements User {
    @Override
    public void authenticate() {
        System.out.println("Twitter user authenticated");
    }
}