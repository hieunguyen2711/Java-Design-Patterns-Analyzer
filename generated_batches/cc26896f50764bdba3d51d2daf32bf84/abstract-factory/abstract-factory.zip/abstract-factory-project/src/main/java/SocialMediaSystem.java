public class SocialMediaSystem {
    public static void main(String[] args) {
        SocialMediaFactory facebookFactory = new FacebookFactory();
        SocialMediaFactory twitterFactory = new TwitterFactory();
        
        Post post1 = facebookFactory.createPost();
        Comment comment1 = facebookFactory.createComment();
        User user1 = facebookFactory.createUser();
        
        post1.publish();
        comment1.addComment();
        user1.authenticate();
        
        System.out.println("---");
        
        Post post2 = twitterFactory.createPost();
        Comment comment2 = twitterFactory.createComment();
        User user2 = twitterFactory.createUser();
        
        post2.publish();
        comment2.addComment();
        user2.authenticate();
    }
}