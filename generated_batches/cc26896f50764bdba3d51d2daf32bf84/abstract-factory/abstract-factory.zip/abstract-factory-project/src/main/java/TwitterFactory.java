public class TwitterFactory implements SocialMediaFactory {
    @Override
    public Post createPost() {
        return new TwitterPost();
    }
    
    @Override
    public Comment createComment() {
        return new TwitterComment();
    }
    
    @Override
    public User createUser() {
        return new TwitterUser();
    }
}