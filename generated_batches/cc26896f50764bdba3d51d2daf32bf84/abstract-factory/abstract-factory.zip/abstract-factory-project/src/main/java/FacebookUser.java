public class FacebookUser implements User {
    @Override
    public void authenticate() {
        System.out.println("Facebook user authenticated");
    }
}