public class FacebookFactory implements SocialMediaFactory {
    @Override
    public Post createPost() {
        return new FacebookPost();
    }
    
    @Override
    public Comment createComment() {
        return new FacebookComment();
    }
    
    @Override
    public User createUser() {
        return new FacebookUser();
    }
}