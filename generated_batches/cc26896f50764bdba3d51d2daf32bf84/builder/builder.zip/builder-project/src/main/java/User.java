package com.socialmedia.model;

public class User {
    private final String username;
    private final String email;
    private final String fullName;
    private final int age;
    private final String bio;
    
    private User(Builder builder) {
        this.username = builder.username;
        this.email = builder.email;
        this.fullName = builder.fullName;
        this.age = builder.age;
        this.bio = builder.bio;
    }
    
    public String getUsername() {
        return username;
    }
    
    public String getEmail() {
        return email;
    }
    
    public String getFullName() {
        return fullName;
    }
    
    public int getAge() {
        return age;
    }
    
    public String getBio() {
        return bio;
    }
    
    @Override
    public String toString() {
        return "User{" +
                "username='" + username + '\'' +
                ", email='" + email + '\'' +
                ", fullName='" + fullName + '\'' +
                ", age=" + age +
                ", bio='" + bio + '\'' +
                '}';
    }
    
    public static class Builder {
        private String username;
        private String email;
        private String fullName;
        private int age;
        private String bio;
        
        public Builder setUsername(String username) {
            this.username = username;
            return this;
        }
        
        public Builder setEmail(String email) {
            this.email = email;
            return this;
        }
        
        public Builder setFullName(String fullName) {
            this.fullName = fullName;
            return this;
        }
        
        public Builder setAge(int age) {
            this.age = age;
            return this;
        }
        
        public Builder setBio(String bio) {
            this.bio = bio;
            return this;
        }
        
        public User build() {
            return new User(this);
        }
    }
}