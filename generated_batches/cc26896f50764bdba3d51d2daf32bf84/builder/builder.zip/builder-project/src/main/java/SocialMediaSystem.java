package com.socialmedia;

import com.socialmedia.model.User;

public class SocialMediaSystem {
    public static void main(String[] args) {
        // Using the Builder pattern to create a user
        User user = new User.Builder()
                .setUsername("john_doe")
                .setEmail("john@example.com")
                .setFullName("John Doe")
                .setAge(28)
                .setBio("Software developer passionate about Java and design patterns.")
                .build();
        
        System.out.println(user);
    }
}