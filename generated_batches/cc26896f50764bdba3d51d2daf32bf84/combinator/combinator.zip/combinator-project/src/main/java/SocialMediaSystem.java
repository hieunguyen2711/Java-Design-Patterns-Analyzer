package com.socialmedia.system;

import com.socialmedia.post.Post;
import com.socialmedia.combinator.PostCombinator;
import java.util.Arrays;
import java.util.List;

public class SocialMediaSystem {
    
    public static void main(String[] args) {
        Post post1 = new Post("Hello world!", "Alice");
        Post post2 = new Post("Java is awesome", "Bob");
        Post post3 = new Post("Design patterns are useful", "Charlie");
        Post post4 = new Post("Learning combinator pattern", "Alice");
        
        List<Post> alicePosts = Arrays.asList(post1, post4);
        List<Post> bobPosts = Arrays.asList(post2);
        List<Post> charliePosts = Arrays.asList(post3);
        
        // Combine all posts
        List<Post> combinedAll = PostCombinator.combinePosts(
            PostCombinator.combinePosts(alicePosts, bobPosts), 
            charliePosts
        );
        
        System.out.println("Combined posts count: " + combinedAll.size());
        
        // Filter by author
        List<Post> aliceCombined = PostCombinator.filterByAuthor(combinedAll, "Alice");
        System.out.println("Alice's posts count: " + aliceCombined.size());
        
        // Get latest post from each user
        Post latestPost = PostCombinator.combineLatestPosts(alicePosts, bobPosts);
        if (latestPost != null) {
            System.out.println("Latest post: " + latestPost.getContent() 
                             + " by " + latestPost.getAuthor());
        }
    }
}