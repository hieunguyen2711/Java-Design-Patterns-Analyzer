package com.socialmedia.combinator;

import com.socialmedia.post.Post;
import java.util.List;
import java.util.stream.Collectors;

public class PostCombinator {
    
    public static List<Post> combinePosts(List<Post> posts1, List<Post> posts2) {
        return Stream.concat(posts1.stream(), posts2.stream())
                     .collect(Collectors.toList());
    }
    
    public static List<Post> filterByAuthor(List<Post> posts, String author) {
        return posts.stream()
                   .filter(post -> post.getAuthor().equals(author))
                   .collect(Collectors.toList());
    }
    
    public static Post combineLatestPosts(List<Post> posts1, List<Post> posts2) {
        Post latest1 = posts1.stream()
                            .max((p1, p2) -> p1.getContent().length() - p2.getContent().length())
                            .orElse(null);
        
        Post latest2 = posts2.stream()
                            .max((p1, p2) -> p1.getContent().length() - p2.getContent().length())
                            .orElse(null);
        
        if (latest1 == null && latest2 == null) return null;
        if (latest1 == null) return latest2;
        if (latest2 == null) return latest1;
        
        return latest1.getContent().length() >= latest2.getContent().length() ? latest1 : latest2;
    }
}