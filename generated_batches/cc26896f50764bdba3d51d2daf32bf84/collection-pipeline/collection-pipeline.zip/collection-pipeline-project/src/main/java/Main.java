package socialmedia;

import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        SocialMediaService service = new SocialMediaService();
        
        // Add users
        User user1 = new User("alice", 25, "New York");
        User user2 = new User("bob", 30, "New York");
        User user3 = new User("charlie", 35, "Los Angeles");
        User user4 = new User("diana", 28, "New York");
        
        service.addUser(user1);
        service.addUser(user2);
        service.addUser(user3);
        service.addUser(user4);
        
        // Add posts
        Post post1 = new Post(user1, "Hello World!", System.currentTimeMillis() - 1000);
        Post post2 = new Post(user2, "Java is awesome", System.currentTimeMillis() - 500);
        Post post3 = new Post(user3, "Beautiful LA", System.currentTimeMillis() - 2000);
        Post post4 = new Post(user4, "New York City", System.currentTimeMillis());
        
        service.addPost(post1);
        service.addPost(post2);
        service.addPost(post3);
        service.addPost(post4);
        
        // Demonstrate collection-pipeline pattern
        List<String> popularPosts = service.getPopularPostsByLocation("New York");
        System.out.println("Popular posts in New York:");
        popularPosts.forEach(System.out::println);
        
        Map<String, Long> postCount = service.getPostCountByLocation();
        System.out.println("\nPost count by location:");
        postCount.forEach((location, count) -> 
            System.out.println(location + ": " + count));
        
        List<User> olderUsers = service.getUsersOverAge(25);
        System.out.println("\nUsers over 25:");
        olderUsers.forEach(user -> 
            System.out.println(user.getUsername() + " (" + user.getAge() + ")"));
    }
}