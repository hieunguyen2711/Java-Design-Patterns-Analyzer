package socialmedia;

public class Post {
    private User author;
    private String content;
    private long timestamp;
    
    public Post(User author, String content, long timestamp) {
        this.author = author;
        this.content = content;
        this.timestamp = timestamp;
    }
    
    public User getAuthor() {
        return author;
    }
    
    public String getContent() {
        return content;
    }
    
    public long getTimestamp() {
        return timestamp;
    }
}