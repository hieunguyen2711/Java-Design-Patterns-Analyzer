package socialmedia;

public class User {
    private String username;
    private int age;
    private String location;
    
    public User(String username, int age, String location) {
        this.username = username;
        this.age = age;
        this.location = location;
    }
    
    public String getUsername() {
        return username;
    }
    
    public int getAge() {
        return age;
    }
    
    public String getLocation() {
        return location;
    }
}