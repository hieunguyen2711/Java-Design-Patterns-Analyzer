package socialmedia;

import java.util.*;
import java.util.stream.Collectors;

public class SocialMediaService {
    private List<User> users;
    private List<Post> posts;
    
    public SocialMediaService() {
        this.users = new ArrayList<>();
        this.posts = new ArrayList<>();
    }
    
    public void addUser(User user) {
        users.add(user);
    }
    
    public void addPost(Post post) {
        posts.add(post);
    }
    
    // Collection-pipeline pattern: collect, filter, map, and reduce operations
    public List<String> getPopularPostsByLocation(String location) {
        return posts.stream()
                .filter(post -> post.getAuthor().getLocation().equals(location))
                .sorted(Comparator.comparing(Post::getTimestamp).reversed())
                .limit(5)
                .map(Post::getContent)
                .collect(Collectors.toList());
    }
    
    public Map<String, Long> getPostCountByLocation() {
        return posts.stream()
                .collect(Collectors.groupingBy(
                    post -> post.getAuthor().getLocation(),
                    Collectors.counting()
                ));
    }
    
    public List<User> getUsersOverAge(int age) {
        return users.stream()
                .filter(user -> user.getAge() > age)
                .sorted(Comparator.comparing(User::getUsername))
                .collect(Collectors.toList());
    }
}