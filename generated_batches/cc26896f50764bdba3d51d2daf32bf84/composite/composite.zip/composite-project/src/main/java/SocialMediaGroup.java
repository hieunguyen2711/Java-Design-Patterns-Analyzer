package com.socialmedia;

import java.util.ArrayList;
import java.util.List;

public class SocialMediaGroup implements SocialMediaComponent {
    private String groupName;
    private List<SocialMediaComponent> components;
    
    public SocialMediaGroup(String groupName) {
        this.groupName = groupName;
        this.components = new ArrayList<>();
    }
    
    @Override
    public void display() {
        System.out.println("Group: " + groupName);
        for (SocialMediaComponent component : components) {
            component.display();
        }
    }
    
    @Override
    public List<SocialMediaComponent> getChildren() {
        return components;
    }
    
    @Override
    public void addChild(SocialMediaComponent component) {
        components.add(component);
    }
    
    @Override
    public void removeChild(SocialMediaComponent component) {
        components.remove(component);
    }
}