package com.socialmedia;

import java.util.List;

public interface SocialMediaComponent {
    void display();
    List<SocialMediaComponent> getChildren();
    void addChild(SocialMediaComponent component);
    void removeChild(SocialMediaComponent component);
}