package com.socialmedia;

public class SocialMediaSystem {
    public static void main(String[] args) {
        // Create a group
        SocialMediaGroup group = new SocialMediaGroup("Java Developers");
        
        // Create users
        User user1 = new User("Alice");
        User user2 = new User("Bob");
        
        // Create posts
        Post post1 = new Post("Hello everyone!");
        Post post2 = new Post("How to use composite pattern?");
        Post post3 = new Post("Great example!");
        
        // Build the structure
        user1.addChild(post1);
        user1.addChild(post2);
        user2.addChild(post3);
        
        group.addChild(user1);
        group.addChild(user2);
        
        // Display the entire structure
        group.display();
    }
}