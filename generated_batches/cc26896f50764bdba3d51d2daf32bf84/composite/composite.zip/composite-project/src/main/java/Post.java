package com.socialmedia;

public class Post implements SocialMediaComponent {
    private String content;
    
    public Post(String content) {
        this.content = content;
    }
    
    @Override
    public void display() {
        System.out.println("Post: " + content);
    }
    
    @Override
    public List<SocialMediaComponent> getChildren() {
        return null;
    }
    
    @Override
    public void addChild(SocialMediaComponent component) {
        // Posts cannot have children
    }
    
    @Override
    public void removeChild(SocialMediaComponent component) {
        // Posts cannot have children
    }
}