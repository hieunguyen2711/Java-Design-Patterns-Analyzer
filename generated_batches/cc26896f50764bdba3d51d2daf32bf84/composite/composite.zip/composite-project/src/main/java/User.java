package com.socialmedia;

import java.util.ArrayList;
import java.util.List;

public class User implements SocialMediaComponent {
    private String username;
    private List<SocialMediaComponent> posts;
    
    public User(String username) {
        this.username = username;
        this.posts = new ArrayList<>();
    }
    
    @Override
    public void display() {
        System.out.println("User: " + username);
        for (SocialMediaComponent post : posts) {
            post.display();
        }
    }
    
    @Override
    public List<SocialMediaComponent> getChildren() {
        return posts;
    }
    
    @Override
    public void addChild(SocialMediaComponent component) {
        if (component instanceof Post) {
            posts.add(component);
        }
    }
    
    @Override
    public void removeChild(SocialMediaComponent component) {
        posts.remove(component);
    }
}