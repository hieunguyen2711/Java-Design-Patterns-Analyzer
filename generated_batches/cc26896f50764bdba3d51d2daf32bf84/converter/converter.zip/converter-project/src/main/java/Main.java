package socialmedia;

public class Main {
    public static void main(String[] args) {
        // Create a user object
        User user = new User("john_doe", "john@example.com");
        
        // Convert to DTO using converter
        UserDto dto = UserConverter.toDto(user);
        
        // Convert back to user object
        User convertedUser = UserConverter.fromDto(dto);
        
        System.out.println("Original user: " + user.getUsername() + ", " + user.getEmail());
        System.out.println("Converted DTO: " + dto.getUsername() + ", " + dto.getEmail());
        System.out.println("Back to user: " + convertedUser.getUsername() + ", " + convertedUser.getEmail());
    }
}