package socialmedia;

public class UserConverter {
    
    public static UserDto toDto(User user) {
        if (user == null) {
            return null;
        }
        return new UserDto(user.getUsername(), user.getEmail());
    }
    
    public static User fromDto(UserDto dto) {
        if (dto == null) {
            return null;
        }
        return new User(dto.getUsername(), dto.getEmail());
    }
}