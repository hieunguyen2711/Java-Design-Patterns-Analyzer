package com.socialmedia;

import com.socialmedia.mapper.UserMapper;
import com.socialmedia.model.User;
import com.socialmedia.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class SocialMediaApplication {
    public static void main(String[] args) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            // Setup database
            setupDatabase(connection);
            
            UserMapper userMapper = new UserMapper();
            
            // Create users
            User user1 = new User(0, "john_doe", "john@example.com");
            User user2 = new User(0, "jane_smith", "jane@example.com");
            
            userMapper.save(user1, connection);
            userMapper.save(user2, connection);
            
            // Find all users
            List<User> users = userMapper.findAll(connection);
            System.out.println("All users:");
            for (User user : users) {
                System.out.println("- " + user.getUsername() + " (" + user.getEmail() + ")");
            }
            
            // Find specific user
            User foundUser = userMapper.findById(1, connection);
            if (foundUser != null) {
                System.out.println("\nFound user: " + foundUser.getUsername());
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private static void setupDatabase(Connection connection) throws SQLException {
        String sql = """
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(255) NOT NULL,
                email VARCHAR(255) NOT NULL
            )
            """;
        
        try (var stmt = connection.createStatement()) {
            stmt.execute(sql);
        }
    }
}