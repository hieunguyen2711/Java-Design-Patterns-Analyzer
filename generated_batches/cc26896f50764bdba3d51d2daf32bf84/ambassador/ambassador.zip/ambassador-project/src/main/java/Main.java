package com.socialmedia;

import com.socialmedia.model.User;
import com.socialmedia.service.UserService;

public class Main {
    public static void main(String[] args) {
        UserService userService = new UserService();
        
        userService.registerUser("john_doe", "john@example.com");
        userService.registerUser("jane_smith", "jane@example.com");
        
        User user1 = userService.findUser("john_doe");
        User user2 = userService.findUser("jane_smith");
        
        System.out.println("User 1: " + user1.getUsername() + " - " + user1.getEmail());
        System.out.println("User 2: " + user2.getUsername() + " - " + user2.getEmail());
    }
}