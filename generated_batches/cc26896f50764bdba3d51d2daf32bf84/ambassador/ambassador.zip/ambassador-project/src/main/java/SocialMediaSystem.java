package com.socialmedia.system;

import com.socialmedia.model.User;
import java.util.HashMap;
import java.util.Map;

public class SocialMediaSystem {
    private static SocialMediaSystem instance;
    private Map<String, User> users;
    
    private SocialMediaSystem() {
        users = new HashMap<>();
    }
    
    public static SocialMediaSystem getInstance() {
        if (instance == null) {
            instance = new SocialMediaSystem();
        }
        return instance;
    }
    
    public void addUser(User user) {
        users.put(user.getUsername(), user);
    }
    
    public User getUser(String username) {
        return users.get(username);
    }
}