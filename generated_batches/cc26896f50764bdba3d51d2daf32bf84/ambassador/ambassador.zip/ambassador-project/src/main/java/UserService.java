package com.socialmedia.service;

import com.socialmedia.model.User;
import com.socialmedia.system.SocialMediaSystem;

public class UserService {
    private SocialMediaSystem socialMediaSystem;
    
    public UserService() {
        this.socialMediaSystem = SocialMediaSystem.getInstance();
    }
    
    public void registerUser(String username, String email) {
        User user = new User(username, email);
        socialMediaSystem.addUser(user);
    }
    
    public User findUser(String username) {
        return socialMediaSystem.getUser(username);
    }
}