public class SocialMediaClient {
    public static void main(String[] args) {
        ActiveObject system = new SocialMediaSystem();
        
        // Asynchronous operations
        system.postMessage("Hello World!");
        system.followUser("john_doe");
        system.postMessage("Java is awesome!");
        system.unfollowUser("john_doe");
        
        // Synchronous operation (will block until processed)
        String feed = system.getUserFeed("alice");
        System.out.println(feed);
    }
}