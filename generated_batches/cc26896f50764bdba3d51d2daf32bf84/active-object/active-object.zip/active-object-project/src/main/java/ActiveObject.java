public interface ActiveObject {
    void postMessage(String message);
    void followUser(String username);
    void unfollowUser(String username);
    String getUserFeed(String username);
}