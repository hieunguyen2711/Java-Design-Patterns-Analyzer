package com.socialmedia;

public class User {
    private String username;
    private SocialMediaSystem socialMediaSystem;
    
    public User(String username, SocialMediaSystem socialMediaSystem) {
        this.username = username;
        this.socialMediaSystem = socialMediaSystem;
    }
    
    public void postUpdate(String content) {
        System.out.println(username + " attempting to post: " + content);
        socialMediaSystem.createPost(content);
    }
}