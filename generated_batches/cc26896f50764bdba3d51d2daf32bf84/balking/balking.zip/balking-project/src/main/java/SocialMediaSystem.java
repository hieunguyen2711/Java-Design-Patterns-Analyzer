package com.socialmedia;

public class SocialMediaSystem {
    private String postContent;
    private boolean isPosting;
    
    public void createPost(String content) {
        if (isPosting) {
            System.out.println("Balking: Already posting...");
            return;
        }
        
        isPosting = true;
        this.postContent = content;
        System.out.println("Posting: " + content);
        
        // Simulate post processing
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        isPosting = false;
        System.out.println("Post completed: " + content);
    }
}