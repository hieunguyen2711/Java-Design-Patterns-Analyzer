package com.socialmedia;

public class Main {
    public static void main(String[] args) {
        SocialMediaSystem system = new SocialMediaSystem();
        User user1 = new User("Alice", system);
        User user2 = new User("Bob", system);
        
        // Simulate concurrent posting attempts
        Thread t1 = new Thread(() -> {
            user1.postUpdate("Hello World!");
        });
        
        Thread t2 = new Thread(() -> {
            user2.postUpdate("Another post");
        });
        
        t1.start();
        t2.start();
    }
}