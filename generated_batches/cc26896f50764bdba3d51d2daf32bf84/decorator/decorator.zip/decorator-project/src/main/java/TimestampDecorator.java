package com.socialmedia.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class TimestampDecorator extends SocialMediaDecorator {
    private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    
    public TimestampDecorator(SocialMediaService service) {
        super(service);
    }
    
    @Override
    public void post(String content) {
        String timestampedContent = "[" + LocalDateTime.now().format(formatter) + "] " + content;
        service.post(timestampedContent);
    }
}