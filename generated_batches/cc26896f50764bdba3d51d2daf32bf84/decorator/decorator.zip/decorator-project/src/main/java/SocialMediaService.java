package com.socialmedia.service;

public interface SocialMediaService {
    void post(String content);
    String getFeed();
}