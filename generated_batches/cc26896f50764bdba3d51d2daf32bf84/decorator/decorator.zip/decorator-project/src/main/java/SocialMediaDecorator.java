package com.socialmedia.service;

public abstract class SocialMediaDecorator implements SocialMediaService {
    protected SocialMediaService service;
    
    public SocialMediaDecorator(SocialMediaService service) {
        this.service = service;
    }
    
    @Override
    public void post(String content) {
        service.post(content);
    }
    
    @Override
    public String getFeed() {
        return service.getFeed();
    }
}