package com.socialmedia.service;

public class BasicSocialMediaService implements SocialMediaService {
    private StringBuilder feed = new StringBuilder();
    
    @Override
    public void post(String content) {
        feed.append("Post: ").append(content).append("\n");
    }
    
    @Override
    public String getFeed() {
        return feed.toString();
    }
}