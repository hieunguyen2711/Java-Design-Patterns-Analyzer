package com.socialmedia.service;

public class HashtagDecorator extends SocialMediaDecorator {
    public HashtagDecorator(SocialMediaService service) {
        super(service);
    }
    
    @Override
    public void post(String content) {
        String taggedContent = "#" + content;
        service.post(taggedContent);
    }
}