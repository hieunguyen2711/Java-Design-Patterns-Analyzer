package com.socialmedia.service;

public class SocialMediaApp {
    public static void main(String[] args) {
        // Basic service
        SocialMediaService basicService = new BasicSocialMediaService();
        basicService.post("Hello World!");
        System.out.println(basicService.getFeed());
        
        // Decorated service with hashtag
        SocialMediaService taggedService = new HashtagDecorator(new BasicSocialMediaService());
        taggedService.post("Java is awesome");
        System.out.println(taggedService.getFeed());
        
        // Decorated service with timestamp
        SocialMediaService timestampedService = new TimestampDecorator(new BasicSocialMediaService());
        timestampedService.post("Learning design patterns");
        System.out.println(timestampedService.getFeed());
        
        // Chain of decorators
        SocialMediaService decoratedService = new HashtagDecorator(
            new TimestampDecorator(new BasicSocialMediaService())
        );
        decoratedService.post("Decorator pattern rocks!");
        System.out.println(decoratedService.getFeed());
    }
}