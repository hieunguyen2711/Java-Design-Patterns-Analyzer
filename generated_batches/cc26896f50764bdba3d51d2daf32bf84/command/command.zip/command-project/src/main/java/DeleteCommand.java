package socialmedia;

public class DeleteCommand implements Command {
    private final SocialMediaSystem system;
    private final String postId;
    
    public DeleteCommand(SocialMediaSystem system, String postId) {
        this.system = system;
        this.postId = postId;
    }
    
    @Override
    public void execute() {
        system.delete(postId);
    }
}