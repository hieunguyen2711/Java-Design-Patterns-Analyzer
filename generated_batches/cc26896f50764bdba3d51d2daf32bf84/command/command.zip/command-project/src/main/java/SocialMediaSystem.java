package socialmedia;

import java.util.ArrayList;
import java.util.List;

public class SocialMediaSystem {
    private final List<String> posts = new ArrayList<>();
    
    public void post(String content) {
        posts.add("Post: " + content);
        System.out.println("Posted: " + content);
    }
    
    public void delete(String postId) {
        posts.removeIf(post -> post.contains(postId));
        System.out.println("Deleted post with ID: " + postId);
    }
    
    public List<String> getPosts() {
        return new ArrayList<>(posts);
    }
}