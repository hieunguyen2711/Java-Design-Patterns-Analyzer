package socialmedia;

public class PostCommand implements Command {
    private final SocialMediaSystem system;
    private final String content;
    
    public PostCommand(SocialMediaSystem system, String content) {
        this.system = system;
        this.content = content;
    }
    
    @Override
    public void execute() {
        system.post(content);
    }
}