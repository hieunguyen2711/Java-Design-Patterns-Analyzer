package socialmedia;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        SocialMediaSystem system = new SocialMediaSystem();
        CommandExecutor executor = new CommandExecutor(system);
        
        // Create and execute commands
        Command postCommand = new PostCommand(system, "Hello World!");
        Command deleteCommand = new DeleteCommand(system, "1");
        
        executor.executeCommand(postCommand);
        executor.executeCommand(deleteCommand);
        
        List<String> posts = system.getPosts();
        System.out.println("Current posts: " + posts);
    }
}