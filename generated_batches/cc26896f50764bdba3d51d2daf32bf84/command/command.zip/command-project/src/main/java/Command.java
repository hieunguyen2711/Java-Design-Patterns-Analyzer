package socialmedia;

public interface Command {
    void execute();
}