package socialmedia;

public class CommandExecutor {
    private final SocialMediaSystem system;
    
    public CommandExecutor(SocialMediaSystem system) {
        this.system = system;
    }
    
    public void executeCommand(Command command) {
        command.execute();
    }
}