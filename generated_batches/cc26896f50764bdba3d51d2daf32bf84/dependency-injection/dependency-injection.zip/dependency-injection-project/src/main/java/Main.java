public class Main {
    public static void main(String[] args) {
        // Dependency injection via constructor
        SocialMediaService twitter = new TwitterService();
        UserService userService1 = new UserService(twitter);
        
        SocialMediaService facebook = new FacebookService();
        UserService userService2 = new UserService(facebook);
        
        userService1.shareUpdate("Hello Twitter!");
        System.out.println(userService1.getSocialFeed());
        
        userService2.shareUpdate("Hello Facebook!");
        System.out.println(userService2.getSocialFeed());
    }
}