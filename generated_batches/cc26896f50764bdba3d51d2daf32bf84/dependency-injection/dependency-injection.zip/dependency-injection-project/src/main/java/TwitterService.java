public class TwitterService implements SocialMediaService {
    @Override
    public void postMessage(String message) {
        System.out.println("Posting to Twitter: " + message);
    }
    
    @Override
    public String getFeed() {
        return "Twitter feed content";
    }
}