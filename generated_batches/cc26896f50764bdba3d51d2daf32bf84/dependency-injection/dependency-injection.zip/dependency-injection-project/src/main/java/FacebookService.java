public class FacebookService implements SocialMediaService {
    @Override
    public void postMessage(String message) {
        System.out.println("Posting to Facebook: " + message);
    }
    
    @Override
    public String getFeed() {
        return "Facebook feed content";
    }
}