public class UserService {
    private final SocialMediaService socialMediaService;
    
    public UserService(SocialMediaService socialMediaService) {
        this.socialMediaService = socialMediaService;
    }
    
    public void shareUpdate(String message) {
        socialMediaService.postMessage(message);
    }
    
    public String getSocialFeed() {
        return socialMediaService.getFeed();
    }
}