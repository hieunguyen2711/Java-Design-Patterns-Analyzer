public interface SocialMediaService {
    void postMessage(String message);
    String getFeed();
}