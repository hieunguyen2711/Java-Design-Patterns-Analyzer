package com.socialmedia.service;

import com.socialmedia.model.User;
import com.socialmedia.dto.UserDTO;

public class UserService {
    
    public UserDTO getUserProfile(String userId) {
        // Simulate fetching user from database
        User user = new User(userId, "john_doe", "john@example.com", "John Doe");
        
        // Transform to DTO for transfer
        return new UserDTO(user.getId(), user.getUsername(), user.getEmail());
    }
    
    public void updateUserProfile(UserDTO userDTO) {
        // Simulate updating user in database
        System.out.println("Updating user profile: " + userDTO.getUsername() + 
                          " with email: " + userDTO.getEmail());
    }
}