package com.socialmedia;

import com.socialmedia.service.UserService;
import com.socialmedia.dto.UserDTO;

public class Main {
    public static void main(String[] args) {
        UserService userService = new UserService();
        
        // Get user profile as DTO (data transfer)
        UserDTO userProfile = userService.getUserProfile("123");
        
        System.out.println("User ID: " + userProfile.getId());
        System.out.println("Username: " + userProfile.getUsername());
        System.out.println("Email: " + userProfile.getEmail());
        
        // Update using DTO
        userService.updateUserProfile(userProfile);
    }
}