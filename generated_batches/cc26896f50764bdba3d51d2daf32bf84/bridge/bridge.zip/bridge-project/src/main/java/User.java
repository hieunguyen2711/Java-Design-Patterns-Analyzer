public class User {
    private String name;
    private SocialMediaPlatform platform;
    private MessagingService messagingService;

    public User(String name, SocialMediaPlatform platform, MessagingService messagingService) {
        this.name = name;
        this.platform = platform;
        this.messagingService = messagingService;
    }

    public void postToSocialMedia(String content) {
        platform.post(content);
    }

    public void sendNotification(String message) {
        messagingService.sendMessage(message);
    }
}