public class Twitter implements SocialMediaPlatform {
    @Override
    public void post(String content) {
        System.out.println("Tweeting on Twitter: " + content);
    }
}