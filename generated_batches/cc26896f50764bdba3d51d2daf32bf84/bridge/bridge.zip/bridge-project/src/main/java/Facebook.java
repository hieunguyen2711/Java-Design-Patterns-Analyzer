public class Facebook implements SocialMediaPlatform {
    @Override
    public void post(String content) {
        System.out.println("Posting on Facebook: " + content);
    }
}