public class EmailMessaging implements MessagingService {
    @Override
    public void sendMessage(String message) {
        System.out.println("Sending email: " + message);
    }
}