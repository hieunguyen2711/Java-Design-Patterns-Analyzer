public interface SocialMediaPlatform {
    void post(String content);
}