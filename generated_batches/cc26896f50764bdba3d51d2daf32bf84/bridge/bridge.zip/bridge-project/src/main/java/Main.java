public class Main {
    public static void main(String[] args) {
        User user1 = new User("Alice", new Facebook(), new EmailMessaging());
        User user2 = new User("Bob", new Twitter(), new SMSMessaging());

        user1.postToSocialMedia("Hello World!");
        user1.sendNotification("You have a new message");

        user2.postToSocialMedia("Java is awesome");
        user2.sendNotification("Your tweet was liked");
    }
}