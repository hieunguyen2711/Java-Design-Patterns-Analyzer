public class AnalyticsVisitor implements SocialMediaVisitor {
    private int totalPosts = 0;
    private int totalComments = 0;

    @Override
    public void visit(Post post) {
        totalPosts++;
    }

    @Override
    public void visit(Comment comment) {
        totalComments++;
    }

    public int getTotalPosts() {
        return totalPosts;
    }

    public int getTotalComments() {
        return totalComments;
    }
}