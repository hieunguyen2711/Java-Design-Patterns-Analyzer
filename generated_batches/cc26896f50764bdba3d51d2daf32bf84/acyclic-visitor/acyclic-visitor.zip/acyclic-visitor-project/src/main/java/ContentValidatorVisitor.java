public class ContentValidatorVisitor implements SocialMediaVisitor {
    private boolean isValid = true;

    @Override
    public void visit(Post post) {
        if (post.getContent() == null || post.getContent().trim().isEmpty()) {
            isValid = false;
        }
    }

    @Override
    public void visit(Comment comment) {
        if (comment.getText() == null || comment.getText().trim().isEmpty()) {
            isValid = false;
        }
    }

    public boolean isValid() {
        return isValid;
    }
}