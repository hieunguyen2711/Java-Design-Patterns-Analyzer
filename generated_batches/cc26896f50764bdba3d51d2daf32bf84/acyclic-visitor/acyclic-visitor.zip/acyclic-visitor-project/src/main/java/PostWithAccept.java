public class PostWithAccept implements SocialMediaElement {
    private String content;
    private User author;

    public PostWithAccept(String content, User author) {
        this.content = content;
        this.author = author;
    }

    @Override
    public void accept(SocialMediaVisitor visitor) {
        visitor.visit(this);
    }

    public String getContent() {
        return content;
    }

    public User getAuthor() {
        return author;
    }
}