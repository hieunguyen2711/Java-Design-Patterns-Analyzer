public interface SocialMediaElement {
    void accept(SocialMediaVisitor visitor);
}