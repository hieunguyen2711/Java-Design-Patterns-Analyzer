public class CommentWithAccept implements SocialMediaElement {
    private String text;
    private User author;
    private Post post;

    public CommentWithAccept(String text, User author, Post post) {
        this.text = text;
        this.author = author;
        this.post = post;
    }

    @Override
    public void accept(SocialMediaVisitor visitor) {
        visitor.visit(this);
    }

    public String getText() {
        return text;
    }

    public User getAuthor() {
        return author;
    }

    public Post getPost() {
        return post;
    }
}