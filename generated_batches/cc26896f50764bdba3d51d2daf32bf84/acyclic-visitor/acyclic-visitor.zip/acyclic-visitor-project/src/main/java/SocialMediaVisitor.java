public interface SocialMediaVisitor {
    void visit(Post post);
    void visit(Comment comment);
}