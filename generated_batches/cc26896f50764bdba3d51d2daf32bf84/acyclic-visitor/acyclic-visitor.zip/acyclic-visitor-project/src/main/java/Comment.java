public class Comment {
    private String text;
    private User author;
    private Post post;

    public Comment(String text, User author, Post post) {
        this.text = text;
        this.author = author;
        this.post = post;
    }

    public String getText() {
        return text;
    }

    public User getAuthor() {
        return author;
    }

    public Post getPost() {
        return post;
    }
}