package com.socialmedia.model;

public class Post {
    private String content;
    private int likes;
    
    public Post(String content) {
        this.content = content;
        this.likes = 0;
    }
    
    public String getContent() {
        return content;
    }
    
    public int getLikes() {
        return likes;
    }
    
    public void incrementLikes() {
        likes++;
    }
}