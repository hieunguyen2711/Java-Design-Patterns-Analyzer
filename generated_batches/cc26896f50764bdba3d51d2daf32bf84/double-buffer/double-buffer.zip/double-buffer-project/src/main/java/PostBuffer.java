package com.socialmedia.buffer;

import com.socialmedia.model.Post;
import java.util.concurrent.atomic.AtomicReference;

public class PostBuffer {
    private final AtomicReference<Post[]> buffer = new AtomicReference<>(new Post[0]);
    
    public void addPost(Post post) {
        Post[] current = buffer.get();
        Post[] updated = new Post[current.length + 1];
        System.arraycopy(current, 0, updated, 0, current.length);
        updated[current.length] = post;
        buffer.set(updated);
    }
    
    public Post[] getPosts() {
        return buffer.get();
    }
}