package com.socialmedia.service;

import com.socialmedia.model.Post;
import com.socialmedia.buffer.PostBuffer;

public class SocialMediaService {
    private final PostBuffer postBuffer = new PostBuffer();
    
    public void createPost(String content) {
        Post post = new Post(content);
        postBuffer.addPost(post);
    }
    
    public Post[] getAllPosts() {
        return postBuffer.getPosts();
    }
}