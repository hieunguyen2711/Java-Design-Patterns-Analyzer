package com.socialmedia;

import com.socialmedia.model.Post;
import com.socialmedia.service.SocialMediaService;

public class Main {
    public static void main(String[] args) {
        SocialMediaService service = new SocialMediaService();
        
        // Add some posts
        service.createPost("Hello World!");
        service.createPost("Java is awesome");
        service.createPost("Design patterns are useful");
        
        // Display all posts
        Post[] posts = service.getAllPosts();
        for (Post post : posts) {
            System.out.println(post.getContent() + " - Likes: " + post.getLikes());
        }
    }
}