package com.socialmedia.model;

public abstract class SocialMediaUser<T extends SocialMediaUser<T>> {
    protected String username;
    protected String email;
    
    public SocialMediaUser(String username, String email) {
        this.username = username;
        this.email = email;
    }
    
    public T withUsername(String username) {
        this.username = username;
        return (T) this;
    }
    
    public T withEmail(String email) {
        this.email = email;
        return (T) this;
    }
    
    public String getUsername() {
        return username;
    }
    
    public String getEmail() {
        return email;
    }
}