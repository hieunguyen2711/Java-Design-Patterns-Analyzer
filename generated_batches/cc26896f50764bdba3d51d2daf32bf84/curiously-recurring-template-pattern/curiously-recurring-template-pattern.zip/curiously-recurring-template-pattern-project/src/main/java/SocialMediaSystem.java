package com.socialmedia.system;

import com.socialmedia.model.RegularUser;
import com.socialmedia.model.PremiumUser;

public class SocialMediaSystem {
    public static void main(String[] args) {
        // Using RegularUser with CRTP
        RegularUser regular = new RegularUser("john_doe", "john@example.com")
            .withUsername("john_updated")
            .verify();
        
        System.out.println("Regular User: " + regular.getUsername() + 
                          ", Verified: " + regular.isVerified());
        
        // Using PremiumUser with CRTP
        PremiumUser premium = new PremiumUser("jane_smith", "jane@example.com")
            .withEmail("jane.smith@premium.com")
            .setSubscriptionLevel(3);
        
        System.out.println("Premium User: " + premium.getUsername() + 
                          ", Level: " + premium.getSubscriptionLevel());
    }
}