package com.socialmedia.model;

public class PremiumUser extends SocialMediaUser<PremiumUser> {
    private int subscriptionLevel;
    
    public PremiumUser(String username, String email) {
        super(username, email);
        this.subscriptionLevel = 1;
    }
    
    public PremiumUser setSubscriptionLevel(int level) {
        this.subscriptionLevel = level;
        return this;
    }
    
    public int getSubscriptionLevel() {
        return subscriptionLevel;
    }
}