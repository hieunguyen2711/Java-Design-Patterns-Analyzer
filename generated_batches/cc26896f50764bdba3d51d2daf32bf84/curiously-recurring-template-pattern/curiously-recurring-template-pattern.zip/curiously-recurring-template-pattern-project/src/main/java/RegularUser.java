package com.socialmedia.model;

public class RegularUser extends SocialMediaUser<RegularUser> {
    private boolean isVerified;
    
    public RegularUser(String username, String email) {
        super(username, email);
        this.isVerified = false;
    }
    
    public RegularUser verify() {
        this.isVerified = true;
        return this;
    }
    
    public boolean isVerified() {
        return isVerified;
    }
}