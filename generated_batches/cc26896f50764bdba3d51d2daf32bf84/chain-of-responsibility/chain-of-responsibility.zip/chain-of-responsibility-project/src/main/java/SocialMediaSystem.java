public class SocialMediaSystem {
    private PostHandler handlerChain;
    
    public SocialMediaSystem() {
        initializeHandlers();
    }
    
    private void initializeHandlers() {
        PostHandler spamFilter = new SpamFilterHandler();
        PostHandler profanityFilter = new ProfanityFilterHandler();
        PostHandler lengthValidator = new LengthValidatorHandler();
        
        spamFilter.setNext(profanityFilter);
        profanityFilter.setNext(lengthValidator);
        
        this.handlerChain = spamFilter;
    }
    
    public void submitPost(Post post) {
        System.out.println("Submitting post by " + post.getAuthor() + ": " + post.getContent());
        handlerChain.handlePost(post);
        System.out.println("Post processed successfully\n");
    }
    
    public static void main(String[] args) {
        SocialMediaSystem system = new SocialMediaSystem();
        
        // Valid post
        system.submitPost(new Post("Hello everyone! This is a great day.", "Alice"));
        
        // Spam post
        system.submitPost(new Post("Buy now! Click here for amazing deals!", "Bob"));
        
        // Profanity post
        system.submitPost(new Post("This badword is inappropriate content", "Charlie"));
        
        // Too long post
        String longContent = "A".repeat(600);
        system.submitPost(new Post(longContent, "David"));
        
        // Empty post
        system.submitPost(new Post("", "Eve"));
    }
}