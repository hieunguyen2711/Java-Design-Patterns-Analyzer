public class ProfanityFilterHandler extends PostHandler {
    private static final String[] PROFANITY_WORDS = {"badword", "offensive", "inappropriate"};
    
    @Override
    protected boolean processPost(Post post) {
        String content = post.getContent().toLowerCase();
        
        for (String profanityWord : PROFANITY_WORDS) {
            if (content.contains(profanityWord)) {
                System.out.println("Profanity filter blocked: " + post.getContent());
                return true;
            }
        }
        
        return false;
    }
}