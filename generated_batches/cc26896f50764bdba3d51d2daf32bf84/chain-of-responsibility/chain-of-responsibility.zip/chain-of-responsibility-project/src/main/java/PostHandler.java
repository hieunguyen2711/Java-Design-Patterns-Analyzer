public abstract class PostHandler {
    protected PostHandler nextHandler;
    
    public void setNext(PostHandler handler) {
        this.nextHandler = handler;
    }
    
    public void handlePost(Post post) {
        if (processPost(post)) {
            return;
        }
        
        if (nextHandler != null) {
            nextHandler.handlePost(post);
        } else {
            System.out.println("Post rejected: " + post.getContent());
        }
    }
    
    protected abstract boolean processPost(Post post);
}