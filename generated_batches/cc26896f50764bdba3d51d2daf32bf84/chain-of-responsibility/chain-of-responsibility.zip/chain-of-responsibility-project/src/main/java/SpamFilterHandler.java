public class SpamFilterHandler extends PostHandler {
    private static final String[] SPAM_WORDS = {"spam", "advertisement", "click here"};
    
    @Override
    protected boolean processPost(Post post) {
        String content = post.getContent().toLowerCase();
        
        for (String spamWord : SPAM_WORDS) {
            if (content.contains(spamWord)) {
                System.out.println("Spam filter blocked: " + post.getContent());
                return true;
            }
        }
        
        return false;
    }
}