public class LengthValidatorHandler extends PostHandler {
    
    @Override
    protected boolean processPost(Post post) {
        String content = post.getContent();
        
        if (content.length() > 500) {
            System.out.println("Length validator blocked: " + post.getContent());
            return true;
        }
        
        if (content.trim().isEmpty()) {
            System.out.println("Empty post blocked: " + post.getContent());
            return true;
        }
        
        return false;
    }
}