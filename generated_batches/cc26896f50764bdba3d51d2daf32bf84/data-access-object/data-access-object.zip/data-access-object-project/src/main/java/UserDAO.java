package com.socialmedia.dao;

import com.socialmedia.model.User;
import java.util.List;

public interface UserDAO {
    User getUserById(int id);
    List<User> getAllUsers();
    void addUser(User user);
    void updateUser(User user);
    void deleteUser(int id);
}