package com.socialmedia;

import com.socialmedia.model.User;
import com.socialmedia.service.UserService;
import java.util.List;

public class SocialMediaApplication {
    public static void main(String[] args) {
        UserService userService = new UserService();
        
        // Add users
        userService.addUser(new User(0, "alice", "alice@example.com"));
        userService.addUser(new User(0, "bob", "bob@example.com"));
        
        // Get all users
        List<User> users = userService.getAllUsers();
        for (User user : users) {
            System.out.println("User: " + user.getUsername() + " - " + user.getEmail());
        }
        
        // Update a user
        User userToUpdate = userService.getUserById(1);
        if (userToUpdate != null) {
            userToUpdate.setEmail("alice.updated@example.com");
            userService.updateUser(userToUpdate);
        }
        
        // Get updated user
        User updatedUser = userService.getUserById(1);
        System.out.println("Updated user: " + updatedUser.getEmail());
    }
}