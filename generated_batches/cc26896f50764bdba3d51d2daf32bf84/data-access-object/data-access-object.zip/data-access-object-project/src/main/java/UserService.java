package com.socialmedia.service;

import com.socialmedia.model.User;
import com.socialmedia.dao.UserDAO;
import com.socialmedia.dao.impl.UserDAOImpl;
import java.util.List;

public class UserService {
    private UserDAO userDAO;
    
    public UserService() {
        this.userDAO = new UserDAOImpl();
    }
    
    public UserService(UserDAO userDAO) {
        this.userDAO = userDAO;
    }
    
    public User getUserById(int id) {
        return userDAO.getUserById(id);
    }
    
    public List<User> getAllUsers() {
        return userDAO.getAllUsers();
    }
    
    public void addUser(User user) {
        userDAO.addUser(user);
    }
    
    public void updateUser(User user) {
        userDAO.updateUser(user);
    }
    
    public void deleteUser(int id) {
        userDAO.deleteUser(id);
    }
}