public class AGradeHandler extends GradeHandler {
    @Override
    public String handleRequest(EnrollmentRequest request) {
        if (request.getCourse().getCredits() >= 3) {
            return "A";
        } else if (nextHandler != null) {
            return nextHandler