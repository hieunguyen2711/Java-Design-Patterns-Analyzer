public abstract class GradeHandler {
    protected GradeHandler nextHandler;
    
    public void setNext(GradeHandler handler) {
        this.nextHandler = handler;
    }
    
    public abstract String handleRequest(EnrollmentRequest request);
}