public class EnrollmentRequest {
    private Student student;
    private Course course;
    private String grade;
    
    public EnrollmentRequest(Student student, Course course) {
        this.student = student;
        this.course = course;
    }
    
    public Student getStudent() {
        return student;
    }
    
    public Course getCourse() {
        return course;
    }
    
    public String getGrade() {
        return grade;
    }
    
    public void setGrade(String grade) {
        this.grade = grade;
    }
}