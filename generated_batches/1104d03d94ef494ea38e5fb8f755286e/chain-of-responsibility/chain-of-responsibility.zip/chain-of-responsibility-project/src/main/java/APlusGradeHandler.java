public class APlusGradeHandler extends GradeHandler {
    @Override
    public String handleRequest(EnrollmentRequest request) {
        if (request.getCourse().getCredits() >= 4) {
            return "A+";
        } else if (nextHandler != null) {
            return nextHandler.handleRequest(request);
        }
        return "B+";
    }
}