package edu.platform.enrollment;

import edu.platform.student.Student;
import edu.platform.course.Course;

public class Enrollment {
    private Student student;
    private Course course;
    private String grade;
    
    public Enrollment(Student student, Course course) {
        this.student = student;
        this.course = course;
    }
    
    public Student getStudent() {
        return student;
    }
    
    public Course getCourse() {
        return course;
    }
    
    public String getGrade() {
        return grade;
    }
    
    public void setGrade(String grade) {
        this.grade = grade;
    }
}