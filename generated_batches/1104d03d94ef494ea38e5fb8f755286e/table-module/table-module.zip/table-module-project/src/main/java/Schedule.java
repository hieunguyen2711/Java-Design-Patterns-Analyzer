package edu.platform.schedule;

import java.util.List;
import java.util.ArrayList;
import edu.platform.course.Course;
import edu.platform.teacher.Teacher;

public class Schedule {
    private List<ScheduleEntry> entries;
    
    public Schedule() {
        this.entries = new ArrayList<>();
    }
    
    public void addEntry(ScheduleEntry entry) {
        entries.add(entry);
    }