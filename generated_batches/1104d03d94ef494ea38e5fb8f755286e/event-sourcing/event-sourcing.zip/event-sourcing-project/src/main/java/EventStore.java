import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class EventStore {
    private final Map<String, List<StudentEnrollmentEvent>> eventsByStudent = new ConcurrentHashMap<>();
    
    public void saveEvent(StudentEnrollmentEvent event) {
        eventsByStudent.computeIfAbsent(event.getEventId(), k -> new ArrayList<>()).add(event