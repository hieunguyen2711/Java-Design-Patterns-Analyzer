public abstract class StudentEnrollmentEvent {
    private final String eventId;
    private final long timestamp;
    
    public StudentEnrollmentEvent(String eventId) {
        this.eventId = eventId;
        this.timestamp = System.currentTimeMillis();
    }
    
    public String getEventId() {
        return eventId;
    }
    
    public long getTimestamp() {
        return timestamp;
    }
    
    public abstract String getEventType();
}