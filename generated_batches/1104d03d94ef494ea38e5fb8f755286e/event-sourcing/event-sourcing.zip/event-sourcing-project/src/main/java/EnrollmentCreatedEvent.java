public class EnrollmentCreatedEvent extends StudentEnrollmentEvent {
    private final String studentId;
    private final String courseId;
    private final String enrollmentDate;
    
    public EnrollmentCreatedEvent(String eventId, String studentId, String courseId, String enrollmentDate) {
        super(eventId);
        this.studentId = studentId;
        this.courseId = courseId;
        this.enrollmentDate = enrollmentDate;
    }
    
    public String getStudentId() {
        return studentId;
    }
    
    public String getCourseId() {
        return courseId;
    }
    
    public String getEnrollmentDate() {
        return enrollmentDate;
    }
    
    @Override
    public String getEventType() {
        return "ENROLLMENT_CREATED";
    }
}