public class EnrollmentCancelledEvent extends StudentEnrollmentEvent {
    private final String studentId;
    private final String courseId;
    private final String cancellationDate;
    
    public EnrollmentCancelledEvent(String eventId, String studentId, String courseId, String cancellationDate) {
        super(eventId);
        this.studentId = studentId;
        this.courseId = courseId;
        this.cancellationDate = cancellationDate;
    }
    
    public String getStudentId() {
        return studentId;
    }
    
    public String getCourseId() {
        return courseId;
    }
    
    public String getCancellationDate() {
        return cancellationDate;
    }
    
    @Override
    public String getEventType() {
        return "ENROLLMENT_CANCELLED";
    }
}