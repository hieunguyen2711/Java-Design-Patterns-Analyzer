package edu.platform.service;

import edu.platform.student.Student;
import edu.platform.course.Course;

public class EnrollmentService {
    private Course course;
    
    public EnrollmentService(Course course) {
        this.course = course;
    }
    
    public void enrollStudent(Student student) {
        course.addStudent(student);
        System.out.println("Enrolled " + student.getName() + " in " + course.getCourseName());
    }
    
    public void unenrollStudent(Student student) {
        course.removeStudent(student);
        System.out.println("Unenrolled " + student.getName() + " from " + course.getCourseName());
    }
}