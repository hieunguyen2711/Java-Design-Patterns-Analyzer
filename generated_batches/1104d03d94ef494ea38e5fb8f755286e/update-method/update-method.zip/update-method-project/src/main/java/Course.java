package edu.platform.course;

import java.util.ArrayList;
import java.util.List;

public class Course {
    private String courseName;
    private int courseId;
    private List<Student> students;
    
    public Course(String courseName, int courseId) {
        this.courseName = courseName;
        this.courseId = courseId;
        this.students = new ArrayList<>();
    }
    
    public void addStudent(Student student) {
        students.add(student);
    }
    
    public void removeStudent(Student student) {
        students.remove(student);
    }
    
    public String getCourseName() {
        return courseName;
    }
    
    public int getCourseId() {
        return courseId;
    }
    
    public List<Student> getStudents() {
        return new ArrayList<>(students);
    }
}