package edu.platform;

import edu.platform.student.Student;
import edu.platform.course.Course;
import edu.platform.service.EnrollmentService;

public class StudentEnrollmentSystem {
    public static void main(String[] args) {
        Course mathCourse = new Course("Calculus", 101);
        EnrollmentService enrollmentService = new EnrollmentService(mathCourse);
        
        Student alice