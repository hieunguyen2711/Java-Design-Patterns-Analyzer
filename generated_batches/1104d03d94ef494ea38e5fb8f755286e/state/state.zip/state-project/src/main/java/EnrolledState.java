package edu.platform.student;

public class EnrolledState implements StudentState {
    
    @Override
    public void enroll(Student student) {
        System.out.println("Student " + student.getName() + " is already enrolled.");
    }
    
    @Override
    public void withdraw(Student student) {
        System.out.println("Student " + student.getName() + " has withdrawn from the course.");
        student.setState(new WithdrawnState());
    }
    
    @Override
    public void completeCourse(Student student) {
        System.out.println("Student " + student.getName() + " has completed the course.");
        student.setState(new CompletedState());
    }
}