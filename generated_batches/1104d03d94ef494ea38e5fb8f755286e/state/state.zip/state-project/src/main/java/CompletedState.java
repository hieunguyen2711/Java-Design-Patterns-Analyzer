package edu.platform.student;

public class CompletedState implements StudentState {
    
    @Override
    public void enroll(Student student) {
        System.out.println("Student " + student.getName() +