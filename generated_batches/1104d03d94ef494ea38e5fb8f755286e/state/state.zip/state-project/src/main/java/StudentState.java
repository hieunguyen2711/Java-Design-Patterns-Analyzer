package edu.platform.student;

public interface StudentState {
    void enroll(Student student);
    void withdraw(Student student);
    void completeCourse(Student student);
}