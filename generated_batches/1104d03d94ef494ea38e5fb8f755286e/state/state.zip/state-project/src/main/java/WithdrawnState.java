package edu.platform.student;

public class WithdrawnState implements StudentState {
    
    @Override
    public void enroll(Student student) {
        System.out.println("Student " + student.getName() + " has re-enrolled.");
        student.setState(new EnrolledState());
    }
    
    @Override
    public void withdraw(Student student) {
        System.out.println("Student " + student.getName() + " is already withdrawn.");
    }
    
    @Override
    public void completeCourse(Student student) {
        System.out.println("Cannot complete course - student has withdrawn.");
    }
}