package edu.platform.student;

public class Student {
    private String name;
    private StudentState state;
    
    public Student(String name) {
        this.name = name;
        this.state = new EnrolledState();
    }
    
    public void enroll() {
        state.enroll(this);
    }
    
    public void withdraw() {
        state.withdraw(this);
    }
    
    public void completeCourse() {
        state.completeCourse(this);
    }
    
    public String getName() {
        return name;
    }
    
    public StudentState getState() {
        return state;
    }
    
    public void setState(StudentState state) {
        this.state = state;
    }
}