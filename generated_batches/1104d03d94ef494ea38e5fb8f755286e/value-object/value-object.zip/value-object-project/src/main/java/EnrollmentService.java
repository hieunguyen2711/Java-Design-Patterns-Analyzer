package edu.platform.student;

import java.util.*;

public class EnrollmentService {
    private final Map<String, Student> students = new HashMap<>();
    
    public void enrollStudent(Student student) {
        students.put(student.getId(), student);
    }
    
    public Optional<Student> findStudentById(String id) {
        return Optional.ofNullable(students.get(id));
    }
    
    public List<Student> getAllStudents() {
        return new ArrayList<>(students.values());
    }
}