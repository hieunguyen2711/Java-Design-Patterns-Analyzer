package edu.platform.student;

public class StudentBuilder {
    private String id;
    private String name;
    private int age;
    
    public StudentBuilder withId(String id) {
        this.id = id;
        return this;
    }
    
    public StudentBuilder withName(String name) {
        this.name = name;
        return this;
    }
    
    public StudentBuilder withAge(int age) {
        this.age = age;
        return this;
    }
    
    public Student build() {
        return new Student(id, name, age);
    }
}