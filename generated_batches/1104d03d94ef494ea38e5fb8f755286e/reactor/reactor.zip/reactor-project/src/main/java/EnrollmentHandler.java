package edu.platform.handler;

import edu.platform.event.EnrollmentEvent;

public interface EnrollmentHandler {
    void handle(EnrollmentEvent event);
}