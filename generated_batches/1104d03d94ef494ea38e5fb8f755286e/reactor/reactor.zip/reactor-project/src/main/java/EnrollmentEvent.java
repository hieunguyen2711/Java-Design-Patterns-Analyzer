package edu.platform.event;

import edu.platform.student.Student;
import edu.platform.course.Course;

public class EnrollmentEvent {
    private Student student;
    private Course course;
    private String eventType;
    
    public EnrollmentEvent(Student student, Course course, String eventType) {
        this.student = student;
        this.course = course;
        this.eventType = eventType;
    }
    
    public Student getStudent() {
        return student;
    }
    
    public Course getCourse() {
        return course;
    }
    
    public String getEventType() {
        return eventType;
    }
}