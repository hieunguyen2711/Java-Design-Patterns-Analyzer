package edu.platform.handler;

import edu.platform.event.EnrollmentEvent;
import java.util.logging.Logger;

public class StudentEnrollmentHandler implements EnrollmentHandler {
    private static final Logger logger = Logger.getLogger(StudentEnrollmentHandler.class.getName());
    
    @Override
    public void handle(EnrollmentEvent event) {
        logger.info("Processing enrollment for student: " + 
                   event.getStudent().getName() + 
                   " in course: " + 
                   event.getCourse().getCourseName());
        
        // Simulate processing logic
        if ("ENROLL".equals(event.getEventType())) {
            logger.info("Student enrolled successfully");