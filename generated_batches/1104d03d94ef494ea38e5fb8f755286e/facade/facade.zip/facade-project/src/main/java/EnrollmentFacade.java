public class EnrollmentFacade {
    private StudentRegistry studentRegistry;
    private CourseScheduler courseScheduler;
    private GradeManager gradeManager;
    private AttendanceTracker attendanceTracker;
    
    public EnrollmentFacade() {
        this.studentRegistry = new StudentRegistry();
        this.courseScheduler = new CourseScheduler();
        this.gradeManager = new GradeManager();
        this.attendanceTracker = new AttendanceTracker();
    }
    
    public void enrollStudent(String studentName, String courseCode) {
        // Complex process hidden behind simple facade interface
        studentRegistry.registerStudent(studentName);
        courseScheduler.assignCourse(courseCode);
        gradeManager.initializeGrades(studentName, courseCode);
        attendanceTracker.startTracking(studentName, courseCode);
        
        System.out.println("Student " + studentName + " enrolled in " + courseCode);
    }
    
    public void checkGrades(String studentName) {
        double average = gradeManager.getAverageGrade(studentName);
        System.out.println("Student " + studentName + " has average grade: " + average);
    }
}