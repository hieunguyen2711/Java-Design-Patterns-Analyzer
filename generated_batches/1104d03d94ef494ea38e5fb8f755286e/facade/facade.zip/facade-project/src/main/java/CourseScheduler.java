public class CourseScheduler {
    public void assignCourse(String courseCode) {
        System.out.println("Assigning course: " + courseCode);
    }
}