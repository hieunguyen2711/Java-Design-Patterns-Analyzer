public class GradeManager {
    public void initializeGrades(String studentName, String courseCode) {
        System.out.println("Initializing grades for " + studentName + " in " + courseCode);
    }
    
    public double getAverageGrade(String studentName) {
        // Simulate grade calculation
        return 85.5;
    }
}