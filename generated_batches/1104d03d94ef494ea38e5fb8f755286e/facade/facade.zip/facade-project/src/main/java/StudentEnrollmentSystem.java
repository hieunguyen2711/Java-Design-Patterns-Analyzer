public class StudentEnrollmentSystem {
    public static void main(String[] args) {
        // Using the Facade to simplify complex operations
        EnrollmentFacade facade = new EnrollmentFacade();
        
        // Enroll student in course with all necessary steps
        facade.enrollStudent("John Doe", "CS101");
        
        // Check grades for a student
        facade.checkGrades("John Doe");
    }
}