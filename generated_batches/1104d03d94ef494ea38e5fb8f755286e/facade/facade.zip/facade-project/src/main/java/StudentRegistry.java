public class StudentRegistry {
    public void registerStudent(String name) {
        System.out.println("Registering student: " + name);
    }
}