package edu.platform.service;

import edu.platform.student.Student;
import edu.platform.dto.StudentDTO;

public class StudentService {
    
    public StudentDTO getStudentDTO(int studentId) {
        // Simulate fetching from database
        Student student = new Student(studentId, "John Doe", "john.doe@university.edu");
        
        // Transform to DTO for transfer
        return new StudentDTO(
            student.getId(),
            student.getName(),
            student.getEmail()
        );
    }
    
    public void updateStudent(StudentDTO studentDTO) {
        // Simulate updating database with DTO data
        System.out.println("Updating student: " + studentDTO.getName() + 
                          " with email: " + studentDTO.getEmail());
    }
}