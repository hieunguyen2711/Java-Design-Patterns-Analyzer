package edu.platform.enrollment;

public class EnrollmentApplication {
    public static void main(String[] args) {
        GradeRepository gradeRepo = new DatabaseGradeRepository();
        AttendanceTracker attendanceTracker = new SqlAttendanceTracker();
        
        StudentEnrollmentService enrollmentService = 
            new StudentEnrollmentService(gradeRepo, attendanceTracker);
            
        enrollmentService.enrollStudent("S001", "CSC101");
    }
}