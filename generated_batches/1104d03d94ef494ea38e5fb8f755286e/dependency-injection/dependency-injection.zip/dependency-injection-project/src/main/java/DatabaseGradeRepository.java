package edu.platform.enrollment;

public class DatabaseGradeRepository implements GradeRepository {
    @Override
    public void saveGrade(String studentId, String courseId, String status) {
        System.out.println("Saving grade for student " + studentId + 
                          " in course " + courseId + " with status: " + status);
    }
}