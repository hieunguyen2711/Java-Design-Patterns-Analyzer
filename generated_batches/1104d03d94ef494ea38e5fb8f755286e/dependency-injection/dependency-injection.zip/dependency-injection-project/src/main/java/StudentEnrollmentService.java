package edu.platform.enrollment;

public class StudentEnrollmentService {
    private final GradeRepository gradeRepository;
    private final AttendanceTracker attendanceTracker;
    
    public StudentEnrollmentService(GradeRepository gradeRepository, 
                                   AttendanceTracker attendanceTracker) {
        this.gradeRepository = gradeRepository;
        this.attendanceTracker = attendanceTracker;
    }
    
    public void enrollStudent(String studentId, String courseId) {
        System.out.println("Enrolling student " + studentId + " in course " + courseId);
        gradeRepository.saveGrade(studentId, courseId, "ENROLLED");
        attendanceTracker.recordAttendance(studentId, courseId, true);
    }
}