package edu.platform.enrollment;

public interface AttendanceTracker {
    void recordAttendance(String studentId, String courseId, boolean present);
}