package edu.platform.enrollment;

public interface GradeRepository {
    void saveGrade(String studentId, String courseId, String status);
}