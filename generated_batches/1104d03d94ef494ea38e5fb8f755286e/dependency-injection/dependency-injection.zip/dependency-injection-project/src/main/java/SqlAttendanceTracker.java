package edu.platform.enrollment;

public class SqlAttendanceTracker implements AttendanceTracker {
    @Override
    public void recordAttendance(String studentId, String courseId, boolean present) {
        System.out.println("Recording attendance for student " + studentId + 
                          " in course " + courseId + " - Present: " + present);
    }
}