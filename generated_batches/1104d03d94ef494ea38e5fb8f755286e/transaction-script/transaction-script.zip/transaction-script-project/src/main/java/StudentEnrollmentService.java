public class StudentEnrollmentService {
    private final CourseRepository courseRepository;
    private final StudentRepository studentRepository;
    
    public StudentEnrollmentService(CourseRepository courseRepository, 
                                   StudentRepository studentRepository) {
        this.courseRepository = courseRepository;
        this.studentRepository = studentRepository;
    }
    
    public void enrollStudentInCourse(int studentId, int courseId) {
        // Transaction script: all logic in single method
        Course course = courseRepository.findCourseById(courseId);
        Student student = studentRepository.findStudentById(studentId);
        
        if (course == null) {
            throw new IllegalArgumentException("Course not found");
        }
        
        if (student == null) {
            throw new IllegalArgumentException("Student not found");
        }
        
        if (course.getEnrolledStudents().size() >= course.getMaxCapacity()) {
            throw new IllegalStateException("Course is full");
        }
        
        student.enrollInCourse(course);
        course.addEnrolledStudent(student);
        
        studentRepository.save(student);
        courseRepository.save(course);
    }
}