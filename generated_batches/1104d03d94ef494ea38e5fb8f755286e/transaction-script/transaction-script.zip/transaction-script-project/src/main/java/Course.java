import java.util.ArrayList;
import java.util.List;

public class Course {
    private int id;
    private String name;
    private int maxCapacity;
    private List<Student> enrolledStudents;
    
    public Course(int id, String name, int maxCapacity) {
        this.id = id;
        this.name = name;
        this.maxCapacity = maxCapacity;
        this.enrolledStudents = new ArrayList<>();
    }
    
    public void addEnrolledStudent(Student student) {
        enrolledStudents.add(student);
    }
    
    public List<Student> getEnrolledStudents() {
        return enrolledStudents;
    }
    
    public int getId() {
        return id;
    }
    
    public String getName() {
        return name;
    }
    
    public int getMaxCapacity() {
        return maxCapacity;
    }
}