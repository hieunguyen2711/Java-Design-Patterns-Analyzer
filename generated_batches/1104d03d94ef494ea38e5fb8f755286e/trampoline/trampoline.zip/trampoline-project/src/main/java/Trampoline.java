package edu.platform.enrollment;

@FunctionalInterface
public interface Trampoline<T> {
    Result<T> apply();
    
    static <T> Trampoline<T> done(T value) {
        return () -> Result.done(value);
    }
    
    static <T> Trampoline<T> suspend(Trampoline<T> trampoline) {
        return () -> Result.suspend(trampoline);
    }
}