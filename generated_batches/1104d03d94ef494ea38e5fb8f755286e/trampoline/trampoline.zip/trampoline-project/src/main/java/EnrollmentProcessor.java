package edu.platform.enrollment;

public class EnrollmentProcessor {
    
    public static <T> T evaluate(Trampoline<T> trampoline) {
        Result<T> result = trampoline.apply();
        
        while (true) {