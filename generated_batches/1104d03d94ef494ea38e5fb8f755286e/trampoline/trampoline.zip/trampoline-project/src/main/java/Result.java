package edu.platform.enrollment;

public sealed interface Result<T> permits Result.Done, Result.Suspend {
    record Done<T>(T value) implements Result<T> {}
    record Suspend<T>(Trampoline<T> trampoline) implements Result<T> {}
    
    static <T> Result<T> done(T value) {
        return new Done<>(value);
    }
    
    static <T> Result<T> suspend(Trampoline<T> trampoline) {
        return new Suspend<>(trampoline);
    }
}