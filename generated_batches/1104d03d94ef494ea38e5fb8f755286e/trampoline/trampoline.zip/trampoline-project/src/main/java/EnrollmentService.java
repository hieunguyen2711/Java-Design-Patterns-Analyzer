package edu.platform.enrollment;

import java.util.List;
import java.util.ArrayList;

public class EnrollmentService {
    private final List<Student> students = new ArrayList<>();
    
    public Trampoline<Boolean> enrollStudent(Student student) {
        return () -> {
            if (student == null) {
                return Result.done(false);
            }
            
            // Simulate some processing that might need to be trampolined
            if (students.size() >= 100) {
                return Result.suspend(enrollStudent(student));
            }
            
            students.add(student);
            return Result.done(true);
        };
    }
    
    public Trampoline<List<Student>> getStudents() {
        return () -> Result.done(students);
    }
}