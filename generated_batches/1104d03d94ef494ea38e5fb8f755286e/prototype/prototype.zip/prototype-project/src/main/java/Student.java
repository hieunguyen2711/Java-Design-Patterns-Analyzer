package edu.platform.student;

import java.util.ArrayList;
import java.util.List;

public class Student implements Cloneable {
    private String name;
    private int id;
    private List<String> courses;
    
    public Student(String name, int id) {
        this.name = name;
        this.id = id;
        this.courses = new ArrayList<>();
    }
    
    public void addCourse(String course) {
        courses.add(course);
    }
    
    public String getName() {
        return name;
    }
    
    public int getId() {
        return id;
    }
    
    public List<String> getCourses() {
        return new ArrayList<>(courses);
    }
    
    @Override
    public Student clone() throws CloneNotSupportedException {
        Student cloned = (Student) super.clone();
        cloned.courses = new ArrayList<>(this.courses);
        return cloned;
    }
    
    @Override
    public String toString() {
        return "Student{name='" + name + "', id=" + id + ", courses=" + courses + "}";
    }
}