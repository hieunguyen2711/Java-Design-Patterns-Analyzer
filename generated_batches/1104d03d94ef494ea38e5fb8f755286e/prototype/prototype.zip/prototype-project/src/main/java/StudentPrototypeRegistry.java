package edu.platform.student;

import java.util.HashMap;
import java.util.Map;

public class StudentPrototypeRegistry {
    private static final Map<String, Student> prototypes = new HashMap<>();
    
    static {
        // Register prototype students
        Student defaultStudent = new Student("Default", 0);
        defaultStudent.addCourse("Math");
        defaultStudent.addCourse("Science");
        prototypes.put("default", defaultStudent);
        
        Student graduateStudent = new Student("Graduate", 100);
        graduateStudent.addCourse("Advanced Math");
        graduateStudent.addCourse("Research Methods");
        prototypes.put("graduate", graduateStudent);
    }
    
    public static Student getPrototype(String key) {
        try {
            return prototypes.get(key).clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        }
    }
    
    public static void registerPrototype(String key, Student prototype) {
        try {
            prototypes.put(key, prototype.clone());
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        }
    }
}