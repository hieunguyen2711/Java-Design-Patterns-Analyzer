package edu.platform.student;

public class EnrollmentSystem {
    public static void main(String[] args) {
        // Create a default student using prototype pattern
        Student defaultStudent = StudentPrototypeRegistry.getPrototype("default");
        System.out.println("Original default