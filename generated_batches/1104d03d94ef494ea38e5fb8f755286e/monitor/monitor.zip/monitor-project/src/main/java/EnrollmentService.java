package edu.platform.service;

import edu.platform.course.Course;
import edu.platform.student.Student;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class EnrollmentService {
    private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
    
    public void enrollStudentInCourse(Student student, Course course) {
        // Write lock for enrollment
        lock.writeLock().lock();
        try {
            course.addStudent(student);
            System.out.println("Enrolled " + student.getName() + 
                             " in " + course.getCourseName());
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    public void printCourseStudents(Course course) {
        // Read lock for reading
        lock.readLock().lock();
        try {
            System.out.println("Students in " + course.getCourseName() + ":");
            course.getStudents().forEach(student -> 
                System.out.println("- " + student.getName()));
        } finally {
            lock.readLock().unlock();
        }
    }
}