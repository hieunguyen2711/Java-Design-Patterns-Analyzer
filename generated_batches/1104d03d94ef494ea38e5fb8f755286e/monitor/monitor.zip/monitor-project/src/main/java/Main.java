package edu.platform;

import edu.platform.course.Course;
import edu.platform.student.Student;
import edu.platform.service.EnrollmentService;

public class Main {
    public static void main(String[] args) {
        Course mathCourse = new Course("MATH101", "