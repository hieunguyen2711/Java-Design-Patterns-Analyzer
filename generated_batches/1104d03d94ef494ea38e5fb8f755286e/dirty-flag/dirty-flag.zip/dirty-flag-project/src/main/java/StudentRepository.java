package edu.university.student;

import java.util.ArrayList;
import java.util.List;

public class StudentRepository {
    private List<Student> students = new ArrayList<>();
    
    public void addStudent(Student student) {
        students.add(student);
    }
    
    public Student getStudent(int id) {
        return students.stream()
                .filter(s -> s.getId() == id)
                .findFirst()
                .orElse(null);
    }
    
    public List<Student> getAllStudents() {
        return new ArrayList<>(students);
    }
    
    public void saveChanges() {
        for (Student student : students) {
            if (student.isDirty()) {
                System.out.println("Saving dirty student: " + student.getName());
                student.clearDirty();
            }
        }
    }
}