package edu.university.student;

public class StudentService {
    private StudentRepository repository;
    
    public StudentService(StudentRepository repository) {
        this.repository = repository;
    }
    
    public void updateStudentName(int id, String newName) {
        Student student = repository.getStudent(id);
        if (student != null) {
            student.setName(newName);
        }
    }
    
    public void saveAllChanges() {
        repository.saveChanges();
    }
}