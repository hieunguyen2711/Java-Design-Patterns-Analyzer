package edu.university.student;

public class Student {
    private String name;
    private int id;
    private boolean dirtyFlag = false;
    
    public Student(String name, int id) {
        this.name = name;
        this.id = id;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
        setDirty(true);
    }
    
    public int getId() {
        return id;
    }
    
    public boolean isDirty() {
        return dirtyFlag;
    }
    
    public void setDirty(boolean dirtyFlag) {
        this.dirtyFlag = dirtyFlag;
    }
    
    public void clearDirty() {
        this.dirtyFlag = false;
    }
}