package edu.university.student;

public class Main {
    public static void main(String[] args) {
        StudentRepository repo = new StudentRepository();
        StudentService service = new StudentService(repo);
        
        // Create students
        Student student1 = new Student("John Doe", 1);
        Student student2 =