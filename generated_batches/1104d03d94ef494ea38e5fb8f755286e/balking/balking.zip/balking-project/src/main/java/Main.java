package edu.platform;

import edu.platform.service.EnrollmentService;
import edu.platform.student.Student;

public class Main {
    public static void main(String[] args) {
        Student student = new Student("S001", "John Doe");
        EnrollmentService service = new EnrollmentService();
        
        // Simulate concurrent enrollment attempts
        Thread t1 = new Thread(() -> {
            boolean result = service.enrollStudent(student);
            System.out.println("Enrollment 1 result: " + result);
        });
        
        Thread t2 = new Thread(() -> {
            boolean result = service.enrollStudent(student);
            System.out.println("Enrollment 2 result: " + result);
        });