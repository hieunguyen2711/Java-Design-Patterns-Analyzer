package edu.platform.student;

public class Student {
    private String id;
    private String name;
    private boolean enrolled;
    
    public Student(String id, String name) {
        this.id = id;
        this.name = name;
        this.enrolled = false;
    }
    
    public String getId() {
        return id;
    }
    
    public String getName() {
        return name;
    }
    
    public boolean isEnrolled() {
        return enrolled;
    }
    
    public void setEnrolled(boolean enrolled) {
        this.enrolled = enrolled;
    }
}