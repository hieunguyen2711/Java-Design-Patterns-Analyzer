package edu.platform.service;

import edu.platform.student.Student;
import java.util.concurrent.atomic.AtomicBoolean;

public class EnrollmentService {
    private final AtomicBoolean isProcessing = new AtomicBoolean(false);
    
    public boolean enrollStudent(Student student) {
        // Balking pattern: if already processing, don't proceed
        if (isProcessing.get()) {
            return false; // Cannot enroll while another enrollment is in progress
        }
        
        // Try to set the processing flag
        if (!isProcessing.compareAndSet(false, true)) {
            return false; // Another thread got there first
        }
        
        try {
            // Simulate enrollment process
            Thread.sleep(100); // Processing time
            
            // Perform actual enrollment
            student.setEnrolled(true);
            System.out.println("Student " + student.getName() + " enrolled successfully");
            
            return true;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        } finally {
            // Always release the processing flag
            isProcessing.set(false);
        }
    }
}