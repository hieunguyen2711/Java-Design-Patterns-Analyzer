public class Enrollment {
    private Student student;
    private Course course;
    private Teacher teacher;
    
    public Enrollment(Student student, Course course, Teacher teacher) {
        this.student = student;
        this.course = course;
        this.teacher = teacher;
    }
    
    public Student getStudent() {
        return student;
    }
    
    public Course getCourse() {
        return course;
    }
    
    public Teacher getTeacher() {
        return teacher;
    }
}