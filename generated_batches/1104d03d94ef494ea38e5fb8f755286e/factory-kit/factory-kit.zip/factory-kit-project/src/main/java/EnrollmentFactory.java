public class EnrollmentFactory {
    
    public static Enrollment createEnrollment(String studentName, int studentId, 
                                            String courseName, String courseId,
                                            String teacherName, String teacherId) {
        Student student = new Student(studentName, studentId);
        Course course = new Course(courseName, courseId);
        Teacher teacher = new Teacher(teacherName, teacherId);
        
        return new Enrollment(student, course, teacher);
    }
    
    public static Enrollment createBasicEnrollment(String studentName, int studentId, 
                                                 String courseName, String courseId) {
        Student student = new Student(studentName, studentId);
        Course course = new Course(courseName, courseId);
        Teacher teacher = null;