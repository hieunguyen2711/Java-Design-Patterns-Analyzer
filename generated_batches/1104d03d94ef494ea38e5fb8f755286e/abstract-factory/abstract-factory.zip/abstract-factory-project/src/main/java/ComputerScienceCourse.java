public class ComputerScienceCourse extends Course {
    @Override
    public String getName() {
        return "Advanced Java Programming";
    }
    
    @Override
    public int getCreditHours() {
        return 3;
    }
}