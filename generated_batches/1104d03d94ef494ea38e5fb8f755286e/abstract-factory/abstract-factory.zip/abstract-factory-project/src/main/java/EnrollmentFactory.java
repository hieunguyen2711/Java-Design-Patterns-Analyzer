public interface EnrollmentFactory {
    Course createCourse();
    Student createStudent();
    Teacher createTeacher();
}