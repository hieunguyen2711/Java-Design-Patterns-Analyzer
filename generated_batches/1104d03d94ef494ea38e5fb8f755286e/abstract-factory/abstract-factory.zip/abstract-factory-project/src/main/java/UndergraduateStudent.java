public class UndergraduateStudent extends Student {
    @Override
    public String getName() {
        return "John Smith";
    }
    
    @Override
    public String getId() {
        return "U123456789";
    }
}