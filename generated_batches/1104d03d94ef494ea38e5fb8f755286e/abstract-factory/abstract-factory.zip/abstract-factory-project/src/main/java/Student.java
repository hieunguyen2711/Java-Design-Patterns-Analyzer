public abstract class Student {
    public abstract String getName();
    public abstract String getId();
}