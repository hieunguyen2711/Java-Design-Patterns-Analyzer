public abstract class Course {
    public abstract String getName();
    public abstract int getCreditHours();
}