public abstract class Teacher {
    public abstract String getName();
    public abstract String getDepartment();
}