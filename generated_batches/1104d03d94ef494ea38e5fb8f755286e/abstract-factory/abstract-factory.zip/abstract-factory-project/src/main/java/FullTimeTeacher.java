public class FullTimeTeacher extends Teacher {
    @Override
    public String getName() {
        return "Dr. Jane Doe";
    }
    
    @Override