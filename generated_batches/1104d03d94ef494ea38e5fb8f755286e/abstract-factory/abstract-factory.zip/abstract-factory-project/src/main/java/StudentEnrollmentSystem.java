public class StudentEnrollmentSystem {
    public static void main(String[] args) {
        // Create concrete factory
        EnrollmentFactory factory = new ConcreteEnrollmentFactory();
        
        // Create components using the factory
        Course course = factory.createCourse();
        Student student = factory.createStudent();
        Teacher teacher = factory.createTeacher();
        
        // Use the created objects
        System.out.println("Course: " + course.getName());
        System.out.println("Student: " + student.getName());
        System.out.println("Teacher: " + teacher.getName());
    }
}