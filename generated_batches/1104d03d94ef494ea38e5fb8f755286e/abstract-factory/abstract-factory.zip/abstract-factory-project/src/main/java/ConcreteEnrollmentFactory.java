public class ConcreteEnrollmentFactory implements EnrollmentFactory {
    @Override
    public Course createCourse() {
        return new ComputerScienceCourse();
    }
    
    @Override
    public Student createStudent() {
        return new UndergraduateStudent();
    }
    
    @Override
    public Teacher createTeacher() {
        return new FullTimeTeacher();
    }
}