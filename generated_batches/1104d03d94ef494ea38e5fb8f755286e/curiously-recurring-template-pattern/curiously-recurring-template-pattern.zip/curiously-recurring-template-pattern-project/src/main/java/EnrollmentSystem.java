package edu.platform.student;

public class EnrollmentSystem {
    public static void main(String[] args) {
        Student student = new Student("John Doe")
            .withName("Jane Smith");
        
        Teacher teacher = new Teacher("Dr. Smith")
            .withName("Prof. Johnson");
        
        student.enrollCourse("Mathematics");
        student.enrollCourse("Physics");
        
        teacher.assignCourse("Mathematics");
        teacher.assignCourse("Calculus");
        
        System.out.println("Student: " + student.getName());
        System.out.println("Enrolled courses: " + student.getEnrolledCourses());
        System.out.println("Teacher: " + teacher.getName());
        System.out.println("Assigned courses: " + teacher.getAssignedCourses());
    }
}