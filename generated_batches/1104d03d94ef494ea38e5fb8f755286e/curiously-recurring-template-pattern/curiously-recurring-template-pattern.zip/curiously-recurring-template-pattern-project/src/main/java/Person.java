package edu.platform.student;

public abstract class Person<T extends Person<T>> {
    private String name;
    
    protected Person(String name) {
        this.name = name;
    }
    
    public String getName() {
        return name;
    }
    
    @SuppressWarnings("unchecked")
    public T withName(String name) {
        this.name = name;
        return (T) this;
    }
}