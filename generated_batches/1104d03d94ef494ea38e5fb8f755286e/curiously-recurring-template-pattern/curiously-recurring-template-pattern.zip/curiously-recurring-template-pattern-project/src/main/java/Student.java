package edu.platform.student;

import java.util.ArrayList;
import java.util.List;

public class Student extends Person<Student> {
    private List<String> enrolledCourses;
    
    public Student(String name) {
        super(name);
        this.enrolledCourses = new ArrayList<>();
    }
    
    public void enrollCourse(String course) {
        enrolledCourses.add(course);
    }
    
    public List<String> getEnrolledCourses() {
        return enrolledCourses;
    }
}