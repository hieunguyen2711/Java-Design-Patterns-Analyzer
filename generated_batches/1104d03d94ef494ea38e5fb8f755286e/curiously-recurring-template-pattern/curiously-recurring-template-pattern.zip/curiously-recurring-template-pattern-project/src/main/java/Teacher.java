package edu.platform.student;

import java.util.ArrayList;
import java.util.List;

public class Teacher extends Person<Teacher> {
    private List<String> assignedCourses;
    
    public Teacher(String name) {
        super(name);
        this.assignedCourses = new ArrayList<>();
    }
    
    public void assignCourse(String course) {
        assignedCourses.add(course);
    }
    
    public List<String> getAssignedCourses() {
        return assignedCourses;
    }
}