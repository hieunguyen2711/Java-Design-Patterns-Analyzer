package edu.platform.student;

public class EnrollmentService {
    
    public void enrollStudent(String studentId) {
        Student student1 = StudentRepository.findStudentById(studentId);
        Student student2 = StudentRepository.findStudentById(studentId);
        
        // Demonstrating identity map - both references point to the same object
        System.out.println("Same instance: " + (student1 == student2));
        System.out.println("Student name: " + student1.getName());
    }
}