package edu.platform.student;

import java.util.HashMap;
import java.util.Map;

public class StudentRepository {
    private static final Map<String, Student> studentCache = new HashMap<>();
    
    public static Student findStudentById(String id) {
        return studentCache.computeIfAbsent(id, StudentRepository::createStudent);
    }
    
    private static Student createStudent(String id) {
        // In a real system, this would query a database
        return new Student(id, "Student-" + id);
    }
    
    public static void clearCache() {
        studentCache.clear();
    }
}