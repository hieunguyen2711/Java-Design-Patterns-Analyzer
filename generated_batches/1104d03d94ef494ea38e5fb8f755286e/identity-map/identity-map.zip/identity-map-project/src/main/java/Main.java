package edu.platform.student;

public class Main {
    public static void main(String[] args) {
        EnrollmentService service = new EnrollmentService();
        
        // First access - creates and caches the student
        service.enrollStudent("S001");
        
        // Second access - retrieves from cache, same instance
        service.enrollStudent("S001");
        
        // Different student ID - creates new instance
        service.enrollStudent("S00