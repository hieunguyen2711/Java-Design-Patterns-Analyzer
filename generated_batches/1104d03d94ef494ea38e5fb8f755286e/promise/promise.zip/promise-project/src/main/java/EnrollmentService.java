package edu.platform.service;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class EnrollmentService {
    private ExecutorService executor = Executors.newFixedThreadPool(2);
    
    public CompletableFuture<Boolean> enrollStudentAsync(Student student, Course course) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                Thread.sleep(1000); // Simulate async operation
                course.enrollStudent(student);
                return true;
            } catch (Exception e) {
                return false;
            }
        }, executor);
    }
    
    public void shutdown() {
        executor.shutdown();
    }
}