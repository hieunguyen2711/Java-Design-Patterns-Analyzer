package edu.platform;

import edu.platform.student.Student;
import edu.platform.course.Course;
import edu.platform.service.EnrollmentService;
import java.util.concurrent.CompletableFuture;

public class StudentEnrollmentSystem {
    
    public static void main(String[] args) {
        Student student1 = new Student("S001", "Alice Johnson");
        Student student2 = new Student("S002", "Bob Smith");
        
        Course mathCourse = new Course("MATH101", "Calculus I");
        Course csCourse = new Course("CS101