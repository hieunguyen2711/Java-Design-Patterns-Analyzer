public class BasicGrade implements Grade {
    private double score;
    
    public BasicGrade(double score) {
        this.score = score;
    }
    
    @Override
    public double getScore() {
        return score;
    }
    
    @Override
    public String getLetterGrade() {
        if (score >= 90) return "A";
        else if (score >= 80) return "B";
        else if (score >= 70) return "C";
        else if (score >= 60) return "D";
        else return "F";
    }
}