public abstract class GradeDecorator implements Grade {
    protected Grade grade;
    
    public GradeDecorator(Grade grade) {
        this.grade = grade;
    }
}