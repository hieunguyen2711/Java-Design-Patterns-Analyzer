public interface Grade {
    double getScore();
    String getLetterGrade();
}