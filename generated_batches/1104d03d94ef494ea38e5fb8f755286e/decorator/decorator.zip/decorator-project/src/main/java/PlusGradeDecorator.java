public class PlusGradeDecorator extends GradeDecorator {
    
    public PlusGradeDecorator(Grade grade) {
        super(grade);
    }
    
    @Override
    public double getScore() {
        return grade.getScore();
    }
    
    @