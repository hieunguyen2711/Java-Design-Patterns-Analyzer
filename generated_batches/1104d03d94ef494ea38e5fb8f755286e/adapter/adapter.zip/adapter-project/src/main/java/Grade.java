package edu.platform.grades;

public class Grade {
    private double score;
    private String letterGrade;
    
    public Grade(double score, String letterGrade) {
        this.score = score;
        this.letterGrade = letterGrade;
    }
    
    public double getScore() {
        return score;
    }
    
    public String getLetterGrade() {
        return letterGrade;
    }
}