package edu.platform.grades;

import java.util.HashMap;
import java.util.Map;

public class StudentGrades {
    private Map<String, Grade> grades;
    
    public StudentGrades() {
        this.grades = new HashMap<>();
    }
    
    public void addGrade(String studentId, Grade grade) {
        grades.put(studentId, grade);
    }
    
    public Grade getGrade(String studentId) {
        return grades.get(studentId);
    }
}