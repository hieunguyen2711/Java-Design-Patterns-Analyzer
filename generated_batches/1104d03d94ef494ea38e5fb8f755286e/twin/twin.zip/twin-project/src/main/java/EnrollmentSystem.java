package edu.platform.system;

import edu.platform.student.Student;
import edu.platform.course.Course;
import edu.platform.teacher.Teacher;

public class EnrollmentSystem {
    private Student student;
    private Course course;
    private Teacher teacher;
    
    public EnrollmentSystem(Student student, Course course, Teacher teacher) {
        this.student = student;
        this.course = course;
        this.teacher = teacher;
    }
    
    public void enrollStudent() {
        course.addStudent(student);
        System.out.println("Student " + student.getName() + 
                          " enrolled in course " + course.getCourseName());
    }