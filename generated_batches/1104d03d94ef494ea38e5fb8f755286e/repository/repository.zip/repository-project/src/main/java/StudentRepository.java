package edu.platform.repository;

import edu.platform.student.Student;
import java.util.List;
import java.util.ArrayList;
import java.util.Optional;

public interface StudentRepository {
    Optional<Student> findById(int id);
    List<Student> findAll();
    Student save(Student student);
    void deleteById(int id);
}