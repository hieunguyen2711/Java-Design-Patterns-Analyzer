package edu.platform.repository.impl;

import edu.platform.student.Student;
import edu.platform.repository.StudentRepository;
import java.util.List;
import java.util.ArrayList;
import java.util.Optional;

public class InMemoryStudentRepository implements StudentRepository {
    private List<Student> students = new ArrayList<>();
    private int nextId = 1;
    
    @Override
    public Optional<Student> findById(int id) {
        return students.stream()
                .filter(student -> student.getId() == id)
                .findFirst();
    }
    
    @Override
    public List<Student> findAll() {
        return new ArrayList<>(students);
    }
    
    @Override
    public Student save(Student student) {
        if (student.getId() == 0) {
            student = new Student(nextId++, student.getName(), student.getEmail());
        } else {
            students.removeIf(s -> s.getId() == student.getId());
        }
        students.add(student);
        return student;
    }
    
    @Override
    public void deleteById(int id) {
        students.removeIf(student -> student.getId() == id);
    }
}