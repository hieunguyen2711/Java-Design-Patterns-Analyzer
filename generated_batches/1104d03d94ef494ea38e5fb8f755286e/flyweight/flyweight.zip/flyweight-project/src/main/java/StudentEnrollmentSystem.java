public class StudentEnrollmentSystem {
    public static void main(String[] args) {
        // Create students
        Student s1 = new Student("Alice Johnson", 1001);
        Student s2 = new Student("Bob Smith", 1002);
        Student s3 = new Student("Charlie Brown", 1003);
        
        // Get courses from factory - same course objects shared
        Course mathCourse = CourseFlyweightFactory.getCourse("MATH101", "Calculus I", 3);
        Course csCourse = CourseFlyweightFactory.getCourse("CS201", "Data Structures", 4