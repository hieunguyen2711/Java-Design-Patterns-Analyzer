import java.util.HashMap;
import java.util.Map;

public class CourseFlyweightFactory {
    private static final Map<String, Course> courses = new HashMap<>();
    
    public static Course getCourse(String courseCode, String courseName, int credits) {
        return courses.computeIfAbsent(courseCode, key -> new Course(courseCode, courseName, credits));
    }
}