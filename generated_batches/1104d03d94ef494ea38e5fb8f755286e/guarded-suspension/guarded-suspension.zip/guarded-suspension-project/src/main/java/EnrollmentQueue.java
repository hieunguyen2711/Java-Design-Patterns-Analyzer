import java.util.LinkedList;
import java.util.Queue;

public class EnrollmentQueue {
    private final Queue<EnrollmentRequest> queue = new LinkedList<>();
    private static final int MAX_QUEUE_SIZE = 100;

    public synchronized void addRequest(EnrollmentRequest request) throws InterruptedException {
        while (queue.size() >= MAX_QUEUE_SIZE) {
            wait(); // Guarded suspension - wait until space available
        }
        queue.offer(request);
        notifyAll(); // Notify waiting threads that new item is added
    }

    public synchronized EnrollmentRequest getRequest() throws InterruptedException {
        while (queue.isEmpty()) {
            wait(); // Guarded suspension - wait until request available
        }
        EnrollmentRequest request = queue.poll();
        notifyAll(); // Notify waiting threads that space is freed
        return request;
    }
}