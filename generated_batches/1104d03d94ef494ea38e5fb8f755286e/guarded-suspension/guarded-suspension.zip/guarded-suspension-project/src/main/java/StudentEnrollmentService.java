public class StudentEnrollmentService {
    private final EnrollmentQueue enrollmentQueue;

    public StudentEnrollmentService(EnrollmentQueue enrollmentQueue) {
        this.enrollmentQueue = enrollmentQueue;
    }

    public void enrollStudent(String studentId, String courseId) throws InterruptedException {
        EnrollmentRequest request = new EnrollmentRequest(studentId, courseId);
        enrollmentQueue.addRequest(request);
        System.out.println("Enrollment request queued for student: " + studentId + 
                          ", course: " + courseId);
    }

    public void processRequests() throws InterruptedException {
        while (true) {
            EnrollmentRequest request = enrollmentQueue.getRequest();
            // Simulate processing
            Thread.sleep(100);
            request.setProcessed(true);
            System.out.println("Enrollment processed for student: " + 
                             request.getStudentId() + ", course: " + 
                             request.getCourseId());
        }
    }
}