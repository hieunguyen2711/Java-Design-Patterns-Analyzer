public class ScienceCourse extends Course {
    private String labRequirement;
    
    public ScienceCourse(String courseName, int credits, String labRequirement) {
        super(courseName, credits);
        this.labRequirement = labRequirement;
    }
    
    @Override
    public void displayCourseInfo() {
        System.out.println("Science Course: " + courseName + ", Lab Required: " + labRequirement + ", Credits: " + credits);
    }
}