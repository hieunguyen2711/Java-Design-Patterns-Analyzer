public class ConcreteCourseFactory extends CourseFactory {
    @Override
    public Course createCourse(String courseName, int credits) {
        if (courseName.toLowerCase().contains("math")) {
            return new MathCourse(courseName, credits, "Intermediate");
        } else if (courseName.toLowerCase().contains("science")) {
            return new ScienceCourse(courseName, credits, "Yes");
        }
        throw new IllegalArgumentException("Unknown course type: " + courseName);
    }
}