public abstract class CourseFactory {
    public abstract Course createCourse(String courseName, int credits);
    
    public Course createMathCourse(String courseName, int credits, String level) {
        return new MathCourse(courseName, credits, level);
    }
    
    public Course createScienceCourse(String courseName, int credits, String labRequirement) {
        return new ScienceCourse(courseName, credits, labRequirement);
    }
}