public abstract class Course {
    protected String courseName;
    protected int credits;
    
    public Course(String courseName, int credits) {
        this.courseName = courseName;
        this.credits = credits;
    }
    
    public abstract void displayCourseInfo();
    
    public String getCourseName() {
        return courseName;
    }
    
    public int getCredits() {
        return credits;
    }
}