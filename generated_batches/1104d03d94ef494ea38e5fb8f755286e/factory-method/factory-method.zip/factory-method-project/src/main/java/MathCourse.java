public class MathCourse extends Course {
    private String level;
    
    public MathCourse(String courseName, int credits, String level) {
        super(courseName, credits);
        this.level = level;
    }
    
    @Override
    public void displayCourseInfo() {
        System.out.println("Math Course: " + courseName + ", Level: " + level + ", Credits: " + credits);
    }
}