package edu.platform.enrollment;

import java.util.ArrayList;
import java.util.List;

public class StudentEnrollmentService {
    private List<Student> students = new ArrayList<>();
    
    public void enrollStudent(Student student) {
        students.add(student);
    }
    
    public List<Student> getStudents() {
        return students;
    }
}