package edu.platform.enrollment;

import java.util.List;

public class EnrollmentProcessor {
    private StudentEnrollmentService enrollmentService;
    
    public EnrollmentProcessor(StudentEnrollmentService enrollmentService) {
        this.enrollmentService = enrollmentService;
    }
    
    public void processEnrollments(EnrollmentAction action) {
        // Execute-around pattern: acquire resources, perform action, release resources
        List<Student> students = enrollmentService.getStudents();
        
        try {
            action.execute(students);
        } finally {
            // Cleanup or finalization logic would go here if needed
        }
    }
}