package edu.platform.enrollment;

import java.util.List;

public class MainApplication {
    public static void main(String[] args) {
        StudentEnrollmentService enrollmentService = new StudentEnrollmentService();
        
        // Add some sample students
        enrollmentService.enrollStudent(new Student("Alice Johnson", 1001));
        enrollmentService.enrollStudent(new Student("Bob Smith", 1002));
        enrollmentService.enrollStudent(new Student("Charlie Brown", 1003));
        
        EnrollmentProcessor processor = new EnrollmentProcessor(enrollmentService);
        
        // Using execute-around pattern to process enrollments
        processor.processEnrollments(students -> {
            System.out.println("Processing " + students.size() + " enrolled students:");
            for (Student student : students) {