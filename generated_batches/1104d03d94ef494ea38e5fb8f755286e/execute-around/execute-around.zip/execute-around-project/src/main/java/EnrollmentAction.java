package edu.platform.enrollment;

import java.util.List;

@FunctionalInterface
public interface EnrollmentAction {
    void execute(List<Student> students);
}