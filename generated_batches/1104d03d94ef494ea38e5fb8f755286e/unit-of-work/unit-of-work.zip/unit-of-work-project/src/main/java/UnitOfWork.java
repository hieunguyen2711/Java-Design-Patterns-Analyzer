package edu.enrollment.persistence;

import edu.enrollment.model.Student;
import edu.enrollment.model.Course;
import edu.enrollment.model.Enrollment;

import java.util.*;

public class UnitOfWork {
    private Map<Class<?>, List<Object>> insertedObjects;
    private Map<Class<?>, List<Object>> updatedObjects;
    private Map<Class<?>, List<Object>> deletedObjects;
    
    public UnitOfWork() {
        this.insertedObjects = new HashMap<>();
        this.updatedObjects = new HashMap<>();
        this.deletedObjects = new HashMap<>();
    }
    
    public void registerInserted(Object entity) {
        getClassList(insertedObjects, entity.getClass()).add(entity);
    }
    
    public void registerUpdated(Object entity) {
        getClassList(updatedObjects, entity.getClass()).add(entity);
    }
    
    public void registerDeleted(Object entity) {
        getClass