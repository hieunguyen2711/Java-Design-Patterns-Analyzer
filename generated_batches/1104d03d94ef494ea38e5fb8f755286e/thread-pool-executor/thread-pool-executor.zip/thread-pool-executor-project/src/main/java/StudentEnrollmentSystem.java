package edu.platform.enrollment;

public class StudentEnrollmentSystem {
    private final EnrollmentService enrollmentService;
    
    public StudentEnrollmentSystem() {
        this.enrollmentService = new EnrollmentService();
    }
    
    public void enrollStudent(String studentId, String courseId) {
        enrollmentService.processEnrollment(studentId, courseId);
    }
    
    public static void main(String[] args) {
        StudentEnrollmentSystem system = new StudentEnrollmentSystem();
        
        // Simulate multiple concurrent enrollments
        for (int i = 1; i <= 5; i++) {
            system.enrollStudent("STU" + i, "CS101");
        }
        
        // Shutdown the service after processing
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("Shutting down enrollment system...");
            system.shutdown();
        }));
    }
    
    private void shutdown() {
        enrollmentService.shutdown();
    }
}