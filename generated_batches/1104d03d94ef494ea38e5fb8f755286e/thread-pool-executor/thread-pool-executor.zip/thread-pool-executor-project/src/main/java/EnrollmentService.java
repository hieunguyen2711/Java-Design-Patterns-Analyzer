package edu.platform.enrollment;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class EnrollmentService {
    private final ExecutorService executorService;
    
    public EnrollmentService() {
        this.executorService = Executors.newFixedThreadPool(3);
    }
    
    public void processEnrollment(String studentId, String courseId) {
        executorService.submit(() -> {
            try {
                // Simulate enrollment processing
                System.out.println("Processing enrollment for student " + studentId + 
                                 " in course " + courseId);
                Thread.sleep(1000); // Simulate work
                System.out.println("Completed enrollment for student " + studentId + 
                                 " in course " + courseId);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
    }
    
    public void shutdown() {
        executorService.shutdown();
        try {
            if (!executorService.awaitTermination(60, TimeUnit.SECONDS)) {
                executorService.shutdownNow();
            }
        } catch (InterruptedException e) {
            executorService.shutdownNow();
        }
    }
}