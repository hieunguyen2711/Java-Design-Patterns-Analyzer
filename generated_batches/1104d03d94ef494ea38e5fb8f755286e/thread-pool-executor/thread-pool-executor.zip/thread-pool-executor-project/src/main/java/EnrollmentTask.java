package edu.platform.enrollment;

public class EnrollmentTask implements Runnable {
    private final String studentId;
    private final String courseId;
    
    public EnrollmentTask(String studentId, String courseId) {
        this.studentId = studentId;
        this.course