public class Course {
    private String courseName;
    private String courseId;
    private Teacher teacher;
    
    public Course(String courseName, String courseId) {
        this.courseName = courseName;
        this.courseId = courseId;
    }
    
    public String getCourseName() {
        return courseName;
    }
    
    public String getCourseId() {
        return courseId;
    }
    
    public Teacher getTeacher() {
        return teacher;
    }
    
    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }
}