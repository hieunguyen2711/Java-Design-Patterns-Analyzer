public class Main {
    public static void main(String[] args) {
        // Create components
        Student student = new Student("John Doe", "S1234