public class EnrollmentSystem {
    private Student student;
    private Course course;
    private Teacher teacher;
    
    public void enrollStudent(Student student, Course course) {
        this.student = student;
        this.course = course;
        System.out.println("Enrolled " + student.getName() + " in " + course.getCourseName());
    }
    
    public void assignTeacher(Course course, Teacher teacher) {
        course.setTeacher(teacher);
        this.teacher = teacher;
        System.out.println("Assigned " + teacher.getName() + " to " + course.getCourseName());
    }
    
    public Student getStudent() {
        return student;
    }
    
    public Course getCourse() {
        return course;
    }
    
    public Teacher getTeacher() {
        return teacher;
    }
}