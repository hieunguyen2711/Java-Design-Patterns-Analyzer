package edu.platform.course;

import java.util.List;
import java.util.ArrayList;

public class Course {
    private String courseName;
    private List<Student> enrolledStudents;
    
    public Course(String courseName) {
        this.courseName = courseName;
        this.enrolledStudents = new ArrayList<>();
    }
    
    public void enrollStudent(Student student) {
        enrolledStudents.add(student);
    }
    
    public List<Student> getEnrolledStudents() {
        return enrolledStudents;
    }
    
    public String getCourseName() {
        return courseName;
    }
}