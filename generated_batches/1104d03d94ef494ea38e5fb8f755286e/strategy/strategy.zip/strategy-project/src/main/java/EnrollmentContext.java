package edu.platform.enrollment;

import edu.platform.student.Student;
import edu.platform.course.Course;

public class EnrollmentContext {
    private EnrollmentStrategy strategy;
    
    public void setEnrollmentStrategy(EnrollmentStrategy strategy) {
        this.strategy = strategy;
    }
    
    public boolean enrollStudent(Student student