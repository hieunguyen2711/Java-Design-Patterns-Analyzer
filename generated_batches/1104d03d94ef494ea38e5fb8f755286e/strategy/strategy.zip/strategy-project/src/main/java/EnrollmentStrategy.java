package edu.platform.enrollment;

import edu.platform.student.Student;
import edu.platform.course.Course;

public interface EnrollmentStrategy {
    boolean enroll(Student student, Course course);
}