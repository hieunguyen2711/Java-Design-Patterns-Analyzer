package edu.platform.enrollment;

import edu.platform.student.Student;
import edu.platform.course.Course;

public class PriorityEnrollmentStrategy implements EnrollmentStrategy {
    @Override
    public boolean enroll(Student student, Course course) {
        if (course.getEnrolledStudents().size() < 10) {
            course.enrollStudent(student);
            return true;
        }
        return false;
    }
}