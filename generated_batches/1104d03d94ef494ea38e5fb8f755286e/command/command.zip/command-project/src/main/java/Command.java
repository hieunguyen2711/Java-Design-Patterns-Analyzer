package edu.platform.command;

public interface Command {
    void execute();
    void undo();
}