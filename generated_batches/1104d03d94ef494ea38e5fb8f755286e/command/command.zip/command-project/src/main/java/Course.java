package edu.platform;

import java.util.ArrayList;
import java.util.List;

public class Course {
    private String courseId;
    private String courseName;
    private List<Student> enrolledStudents;
    
    public Course(String courseId, String courseName) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.enrolledStudents = new ArrayList<>();
    }
    
    public void enrollStudent(Student student) {
        enrolledStudents.add(student);
    }
    
    public void unenrollStudent(Student student) {
        enrolledStudents.remove(student);
    }
    
    // Getters and setters
    public String getCourseId() { return courseId; }
    public String getCourseName() { return courseName; }
}