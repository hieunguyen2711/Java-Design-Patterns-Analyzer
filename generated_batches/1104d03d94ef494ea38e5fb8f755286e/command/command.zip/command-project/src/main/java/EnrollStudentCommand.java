package edu.platform.command;

import edu.platform.Student;
import edu.platform.Course;

public class EnrollStudentCommand implements Command {
    private Student student;
    private Course course;
    
    public EnrollStudentCommand(Student student, Course course) {
        this.student = student;
        this.course = course;
    }
    
    @Override
    public void execute() {
        student.enrollInCourse(course);
    }
    
    @Override
    public void undo() {
        student.unenrollFromCourse(course);
    }
}