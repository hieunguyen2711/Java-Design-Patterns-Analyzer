package edu.platform;

import java.util.ArrayList;
import java.util.List;

public class Student {
    private String studentId;
    private String studentName;
    private List<Course> enrolledCourses;
    
    public Student(String studentId, String studentName) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.enrolledCourses = new ArrayList<>();
    }
    
    public void enrollInCourse(Course course) {
        enrolledCourses.add(course);
        course.enrollStudent(this);
    }
    
    public void unenrollFromCourse(Course course) {
        enrolledCourses.remove(course);
        course.unenrollStudent(this);
    }
    
    // Getters and setters
    public String getStudentId() { return studentId; }
    public String getStudentName() { return studentName; }
}