public class StudentEnrollmentSystem {
    private static StudentEnrollmentSystem instance;
    
    // Private constructor to prevent instantiation
    private StudentEnrollmentSystem() {}
    
    // Static method to get the single instance
    public static synchronized StudentEnrollmentSystem getInstance() {
        if (instance == null) {
            instance = new StudentEnrollmentSystem();
        }
        return instance;
    }
    
    // Monostate pattern - all instances share the same state
    private int totalStudents = 0;
    private int enrolledStudents = 0;
    
    public void registerStudent() {
        totalStudents++;
        enrolledStudents++;
        System.out.println("Student registered. Total: " + totalStudents + ", Enrolled: " + enrolledStudents);
    }
    
    public void unregisterStudent() {
        if (enrolledStudents > 0) {
            enrolledStudents--;
            System.out.println("Student unregistered. Enrolled: " + enrolledStudents);
        }
    }
    
    public int getTotalStudents() {
        return totalStudents;
    }
    
    public int getEnrolledStudents() {
        return enrolledStudents;
    }
}