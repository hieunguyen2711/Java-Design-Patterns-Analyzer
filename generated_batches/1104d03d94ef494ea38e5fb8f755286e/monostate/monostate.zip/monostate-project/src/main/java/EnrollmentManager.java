public class EnrollmentManager {
    private StudentEnrollmentSystem system = StudentEnrollmentSystem.getInstance();
    
    public void enrollStudent() {
        system.registerStudent();
    }
    
    public void dropStudent() {
        system.unregisterStudent();
    }
    
    public void printStatus() {
        System.out.println("Total students: " + system.getTotalStudents());
        System.out.println("Enrolled students: " + system.getEnrolledStudents());
    }
}