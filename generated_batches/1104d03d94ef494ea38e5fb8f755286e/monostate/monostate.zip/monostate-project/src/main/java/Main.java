public class Main {
    public static void main(String[] args) {
        // Using the monostate pattern - multiple instances share same state
        EnrollmentManager manager1 = new EnrollmentManager();
        EnrollmentManager manager2 = new EnrollmentManager();
        
        manager1.enrollStudent();  // Student registered. Total: 1, Enrolled: 1
        manager1.enrollStudent();  // Student registered. Total: 2, Enrolled: 2
        
        manager2.printStatus();    // Total students: 2, Enrolled students: 2
        
        manager1.dropStudent();    // Student unregistered. Enrolled: 1
        
        manager2.printStatus();    // Total students: 2, Enrolled students: