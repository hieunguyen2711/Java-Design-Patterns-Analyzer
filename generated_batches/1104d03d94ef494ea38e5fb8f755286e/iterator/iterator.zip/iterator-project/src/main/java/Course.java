package edu.platform.course;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Course {
    private String courseId;
    private String courseName;
    private List<Student> students;
    
    public Course(String courseId, String courseName) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.students = new ArrayList<>();
    }
    
    public void addStudent(Student student) {
        students.add(student);
    }
    
    public Iterator<Student> getStudentsIterator() {
        return students.iterator();
    }
    
    public String getCourseId() {
        return courseId;
    }
    
    public String getCourseName() {
        return courseName;
    }
}