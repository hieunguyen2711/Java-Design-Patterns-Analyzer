package edu.platform.iterator;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class StudentIterator implements Iterator<Student> {
    private Course course;
    private int currentIndex = 0;
    
    public StudentIterator(Course course) {
        this.course = course;
    }
    
    @Override
    public boolean hasNext() {
        return currentIndex < course.getStudentsIterator().nextIndex();
    }
    
    @Override
    public Student next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        return course.getStudentsIterator().next();
    }
}