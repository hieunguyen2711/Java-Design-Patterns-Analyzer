package edu.platform.iterator;

import java.util.Iterator;
import java.util.List;

public class CourseIterator implements Iterator<Course> {
    private List<Course> courses;
    private int currentIndex = 0;
    
    public CourseIterator(List<Course> courses) {
        this.courses = courses;
    }
    
    @Override
    public boolean hasNext() {
        return currentIndex < courses.size();
    }
    
    @Override
    public Course next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        return courses.get(currentIndex++);
    }
}