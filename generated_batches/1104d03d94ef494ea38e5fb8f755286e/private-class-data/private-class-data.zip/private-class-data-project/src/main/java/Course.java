package edu.platform.course;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

public class Course {
    private final String courseId;
    private final String courseName;
    private final List<Student> students;
    private final Teacher teacher;
    
    public Course(String courseId, String courseName, Teacher teacher) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.teacher = teacher;
        this.students = new ArrayList<>();
    }
    
    public String getCourseId() {
        return courseId;
    }
    
    public String getCourseName() {
        return courseName;
    }
    
    public Teacher getTeacher() {
        return teacher;
    }
    
    public List<Student> getStudents() {
        // Return defensive copy to protect internal state
        return new ArrayList<>(students);
    }
    
    public void addStudent(Student student) {
        students.add(student);
    }
}