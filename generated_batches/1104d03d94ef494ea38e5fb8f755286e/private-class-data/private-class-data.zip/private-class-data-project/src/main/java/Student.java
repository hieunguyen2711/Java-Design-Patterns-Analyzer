package edu.platform.student;

import java.util.List;
import java.util.ArrayList;

public class Student {
    private final String id;
    private final String name;
    private final List<Course> enrolledCourses;
    
    public Student(String id, String name) {
        this.id = id;
        this.name = name;
        this.enrolledCourses = new ArrayList<>();
    }
    
    public String getId() {
        return id;
    }
    
    public String getName() {
        return name;
    }
    
    public List<Course> getEnrolledCourses() {
        // Return defensive copy to protect internal state
        return new ArrayList<>(enrolledCourses);
    }
    
    public void enrollInCourse(Course course) {
        enrolledCourses.add(course);
    }
}