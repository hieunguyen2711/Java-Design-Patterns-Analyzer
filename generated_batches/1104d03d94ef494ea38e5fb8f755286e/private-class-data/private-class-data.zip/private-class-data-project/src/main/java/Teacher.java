package edu.platform.teacher;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

public class Teacher {
    private final String id;
    private final String name;
    private final List<Course> assignedCourses;
    
    public Teacher(String id, String name) {
        this.id = id;
        this.name = name;
        this.assignedCourses = new ArrayList<>();
    }
    
    public String getId() {
        return id;
    }
    
    public String getName() {
        return name;
    }
    
    public List<Course> getAssignedCourses() {
        // Return defensive copy to protect internal state
        return new ArrayList<>(assignedCourses);
    }