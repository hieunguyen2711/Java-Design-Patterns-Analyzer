public interface StudentService {
    void enrollStudent(Student student);
    void dropStudent(Student student);
    void updateStudentInfo(Student student);
}