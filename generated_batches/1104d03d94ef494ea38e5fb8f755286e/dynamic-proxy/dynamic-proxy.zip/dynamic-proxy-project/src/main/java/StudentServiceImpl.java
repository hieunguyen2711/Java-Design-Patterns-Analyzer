import java.util.ArrayList;
import java.util.List;

public class StudentServiceImpl implements StudentService {
    private List<Student> students = new ArrayList<>();
    
    @Override
    public void enrollStudent(Student student) {
        students.add(student);
        System.out.println("Enrolled student: " + student.getName());
    }
    
    @Override
    public void dropStudent(Student student) {
        students.remove(student);
        System.out.println("Dropped student: " + student.getName());
    }
    
    @Override
    public void updateStudentInfo(Student student) {
        System.out.println("Updated info for student: " + student.getName());
    }
}