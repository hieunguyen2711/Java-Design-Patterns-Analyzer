import java.lang.reflect.Proxy;

public class StudentServiceProxy {
    public static StudentService createStudentServiceProxy(StudentService studentService) {
        return (StudentService) Proxy.newProxyInstance(
            StudentService.class.getClassLoader(),
            new Class[]{StudentService.class},
            new LoggingInvocationHandler(studentService)
        );
    }
}