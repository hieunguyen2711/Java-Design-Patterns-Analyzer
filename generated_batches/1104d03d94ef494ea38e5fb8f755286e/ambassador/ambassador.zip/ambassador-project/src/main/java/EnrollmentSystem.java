package edu.platform.system;

import edu.platform.student.Student;
import edu.platform.course.Course;
import edu.platform.teacher.Teacher;

public class EnrollmentSystem {
    private static EnrollmentSystem instance;
    
    private EnrollmentSystem() {}
    
    public static synchronized EnrollmentSystem getInstance() {
        if (instance == null) {
            instance = new EnrollmentSystem();
        }
        return instance;
    }
    
    public void enrollStudentInCourse(Student student, Course course) {
        course.addStudent(student);
    }
    
    public void assignTeacherToCourse(Teacher teacher, Course course) {
        teacher.assignCourse(course);