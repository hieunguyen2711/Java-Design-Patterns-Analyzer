package edu.platform.teacher;

import java.util.List;
import java.util.ArrayList;

public class Teacher {
    private String teacherId;
    private String name;
    private List<Course> courses;
    
    public Teacher(String teacherId, String name) {
        this.teacherId = teacherId;
        this.name = name;
        this.courses = new ArrayList<>();
    }
    
    public void assignCourse(Course course) {
        courses.add(course);
    }
    
    public String getTeacherId() {
        return teacherId;
    }
    
    public String getName() {
        return name;
    }
    
    public List<Course> getCourses() {
        return courses;
    }
}