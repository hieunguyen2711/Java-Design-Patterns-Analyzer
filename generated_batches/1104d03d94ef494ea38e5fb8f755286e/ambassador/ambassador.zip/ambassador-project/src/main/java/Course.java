package edu.platform.course;

import java.util.List;
import java.util.ArrayList;

public class Course {
    private String courseId;
    private String courseName;
    private List<Student> students;
    
    public Course(String courseId, String courseName) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.students = new ArrayList<>();
    }
    
    public void addStudent(Student student) {
        students.add(student);
    }
    
    public String getCourseId() {
        return courseId;
    }
    
    public String getCourseName() {
        return courseName;
    }
    
    public List<Student> getStudents() {
        return students;
    }
}