package edu.platform.course;

public interface CourseComponent {
    void add(CourseComponent component);
    void remove(CourseComponent component);
    String getName();
    double getCreditHours();
    void printCourseInfo();
}