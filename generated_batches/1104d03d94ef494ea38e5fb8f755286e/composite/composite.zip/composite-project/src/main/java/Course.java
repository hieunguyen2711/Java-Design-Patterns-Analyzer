package edu.platform.course;

import java.util.ArrayList;
import java.util.List;

public class Course implements CourseComponent {
    private String name;
    private double creditHours;
    private List<CourseComponent> components;

    public Course(String name, double creditHours) {
        this.name = name;
        this.creditHours = creditHours;
        this.components = new ArrayList<>();
    }

    @Override
    public void add(CourseComponent component) {
        components.add(component);
    }

    @Override
    public void remove(CourseComponent component) {
        components.remove(component);
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public double getCreditHours() {
        return creditHours;
    }

    @Override
    public void printCourseInfo() {
        System.out.println("Course: " + name + " (" + creditHours + " credits)");
        for (CourseComponent component : components) {
            component.printCourseInfo();
        }
    }
}