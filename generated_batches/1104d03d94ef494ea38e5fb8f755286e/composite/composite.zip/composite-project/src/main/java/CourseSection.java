package edu.platform.course;

public class CourseSection implements CourseComponent {
    private String name;
    private double creditHours;
    private String schedule;
    private String instructor;

    public CourseSection(String name, double creditHours, String schedule, String instructor) {
        this.name = name;
        this.creditHours = creditHours;
        this.schedule = schedule;
        this.instructor = instructor;
    }

    @Override
    public void add(CourseComponent component) {
        throw new UnsupportedOperationException("Cannot add components to a section");
    }

    @Override
    public void remove(CourseComponent component) {
        throw new UnsupportedOperationException("Cannot remove components from a section");
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public double getCreditHours() {
        return creditHours;
    }

    @Override
    public void printCourseInfo() {
        System.out.println("  Section: " + name + " (" + creditHours + " credits)");
        System.out.println("    Schedule: " + schedule);
        System.out.println("    Instructor: " + instructor);