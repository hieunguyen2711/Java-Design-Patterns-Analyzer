public interface Visitor {
    void visit(Student student);
    void visit(Course course);
    void visit(Teacher teacher);
}