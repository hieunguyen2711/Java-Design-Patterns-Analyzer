public class ScheduleVisitor implements Visitor {
    @Override
    public void visit(Student student) {
        System.out.println("Scheduling student: " + student.getName());
    }
    
    @Override
    public void visit(Course course) {
        System.out.println("Scheduling course: " + course.getCourseName());
    }
    
    @Override
    public void visit(Teacher teacher) {