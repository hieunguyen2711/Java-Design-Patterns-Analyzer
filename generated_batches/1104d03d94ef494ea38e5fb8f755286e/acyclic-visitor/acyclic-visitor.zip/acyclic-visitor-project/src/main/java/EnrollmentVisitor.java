public class EnrollmentVisitor implements Visitor {
    @Override
    public void visit(Student student) {
        System.out.println("Processing enrollment for student: " + student.getName());
    }
    
    @Override
    public void visit(Course course) {
        System.out.println("Processing enrollment for course: " + course.getCourseName());
    }
    
    @Override
    public void visit(Teacher teacher) {
        System.out.println("Processing enrollment for teacher: " + teacher.getName());
    }
}