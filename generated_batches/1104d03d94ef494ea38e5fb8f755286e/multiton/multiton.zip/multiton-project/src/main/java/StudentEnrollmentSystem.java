public class StudentEnrollmentSystem {
    public static void main(String[] args) {
        // Demonstrating multiton pattern with CourseManager instances
        CourseManager math = CourseManager.getInstance(0);
        CourseManager physics = CourseManager.getInstance(1);
        CourseManager chemistry = CourseManager.getInstance(2);
        
        // Enroll students in different courses
        math.enrollStudent();
        math.enrollStudent();
        physics.enrollStudent();
        chemistry.enrollStudent();
        chemistry.enrollStudent();
        chemistry.enrollStudent();
        
        // Verify that same instances are returned for same IDs
        CourseManager math2 = CourseManager.getInstance(0);
        System.out.println("Same instance for Math: " + (math == math2));
        
        // Show student counts
        System.out.println("Math students: " + math.getStudentCount());
        System.out.println("Physics students: " + physics.getStudentCount());
        System.out.println("Chemistry students: " + chemistry.getStudentCount());
    }
}