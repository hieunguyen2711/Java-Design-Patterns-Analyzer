public class CourseManager {
    private static final String[] COURSE_NAMES = {"Mathematics", "Physics", "Chemistry", "Biology", "Computer Science"};
    private static CourseManager[] instances = new CourseManager[COURSE_NAMES.length];
    
    private final String courseName;
    private int studentCount;
    
    private CourseManager(String courseName) {
        this.courseName = courseName;
        this.studentCount = 0;
    }
    
    public static CourseManager getInstance(int courseId) {
        if (courseId < 0 || courseId >= COURSE_NAMES.length) {
            throw new IllegalArgumentException("Invalid course ID: " + courseId);
        }
        
        if (instances[courseId] == null) {
            instances[courseId] = new CourseManager(COURSE_NAMES[courseId]);
        }
        
        return instances[courseId];
    }
    
    public void enrollStudent() {
        studentCount++;
        System.out.println("Enrolled student in " + courseName + ". Total students: " + studentCount);
    }
    
    public int getStudentCount() {
        return studentCount;
    }
    
    public String getCourseName() {
        return courseName;
    }
}