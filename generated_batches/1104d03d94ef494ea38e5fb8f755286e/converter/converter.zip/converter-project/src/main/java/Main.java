package edu.platform;

import edu.platform.student.Student;
import edu.platform.dto.StudentDTO;
import edu.platform.converter.StudentConverter;

public class Main {
    public static void main(String[] args) {
        // Create a student object
        Student student = new Student("S001", "John Doe", 20);
        
        // Convert to DTO using converter pattern