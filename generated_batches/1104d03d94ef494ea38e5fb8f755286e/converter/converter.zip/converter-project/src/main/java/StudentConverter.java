package edu.platform.converter;

import edu.platform.student.Student;
import edu.platform.dto.StudentDTO;

public class StudentConverter {
    
    public static StudentDTO toDTO(Student student) {
        if (student == null) {
            return null;
        }
        return new StudentDTO(student.getId(), student.getName(), student.getAge());
    }
    
    public static Student fromDTO(StudentDTO dto) {
        if (dto == null) {
            return null;
        }
        return new Student(dto.getId(), dto.getName(), dto.getAge());
    }
}