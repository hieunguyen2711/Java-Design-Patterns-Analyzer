package edu.platform.factory;

import edu.platform.course.Course;
import edu.platform.student.Student;

public class CourseFactory {
    private static CourseFactory instance;
    
    private CourseFactory() {}
    
    public static CourseFactory getInstance() {
        if (instance == null) {
            synchronized (CourseFactory.class) {
                if (instance == null) {
                    instance = new CourseFactory();
                }
            }
        }
        return instance;
    }
    
    public Course createCourse(String courseId, String courseName) {
        return new Course(courseId, courseName);
    }
}