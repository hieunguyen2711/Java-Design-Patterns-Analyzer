package edu.platform.service;

import edu.platform.course.Course;
import edu.platform.student.Student;
import edu.platform.factory.CourseFactory;

public class EnrollmentService {
    private CourseFactory courseFactory;
    
    public EnrollmentService() {
        this.courseFactory = CourseFactory.getInstance();
    }
    
    public void enrollStudentInCourse(Student student, String courseId, String courseName) {
        Course course = courseFactory.createCourse(courseId, courseName);
        course.addStudent(student);
        System.out.println("Enrolled " + student.getName() + " in " + course.getCourseName());
    }
}