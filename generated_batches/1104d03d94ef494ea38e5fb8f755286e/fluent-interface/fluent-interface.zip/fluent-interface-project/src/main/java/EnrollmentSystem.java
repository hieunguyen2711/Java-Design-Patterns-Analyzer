package edu.enrollment;

public class EnrollmentSystem {
    public static void main(String[] args) {
        // Fluent interface usage example
        Student student = new StudentBuilder()
            .withName("John Doe")
            .withId(12345)
            .withEmail("john.doe@university.edu")
            .withMajor("Computer Science")
            .build();
        
        System.out.println("Student created: " + student.getName() + 
                          " with ID: " + student.getId());
    }
}