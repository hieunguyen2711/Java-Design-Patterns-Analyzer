package edu.enrollment;

public class Student {
    private String name;
    private int id;
    private String email;
    private String major;
    
    public Student(String name, int id) {
        this.name = name;
        this.id = id;
    }
    
    public Student setName(String name) {
        this.name = name;
        return this;
    }
    
    public Student setId(int id) {
        this.id = id;
        return this;
    }
    
    public Student setEmail(String email) {
        this.email = email;
        return this;
    }
    
    public Student setMajor(String major) {
        this.major = major;
        return this;
    }
    
    public String getName() {
        return name;
    }
    
    public int getId() {
        return id;
    }
    
    public String getEmail() {
        return email;
    }
    
    public String getMajor() {
        return major;
    }
}