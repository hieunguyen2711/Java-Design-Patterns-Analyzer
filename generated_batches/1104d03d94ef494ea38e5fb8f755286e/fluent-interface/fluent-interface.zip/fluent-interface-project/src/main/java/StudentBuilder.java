package edu.enrollment;

public class StudentBuilder {
    private Student student;
    
    public StudentBuilder() {
        this.student = new Student("", 0);
    }
    
    public StudentBuilder withName(String name) {
        student.setName(name);
        return this;
    }
    
    public StudentBuilder withId(int id) {
        student.setId(id);
        return this;
    }
    
    public StudentBuilder withEmail(String email) {
        student.setEmail(email);
        return this;
    }
    
    public StudentBuilder withMajor(String major) {
        student.setMajor(major);
        return this;
    }
    
    public Student build() {
        return student;
    }
}