package edu.platform.student;

public class EnrollmentSystem implements Observer {
    private String systemName;
    
    public EnrollmentSystem(String systemName) {
        this.systemName = systemName;
    }
    
    @Override
    public void update(String message) {
        System.out.println("Enrollment System [" + systemName + "] received notification: " + message);
    }
}