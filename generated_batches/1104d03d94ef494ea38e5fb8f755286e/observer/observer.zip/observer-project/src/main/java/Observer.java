package edu.platform.student;

public interface Observer {
    void update(String message);
}