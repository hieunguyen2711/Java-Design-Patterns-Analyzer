package edu.platform.student;

public class GradeTracker implements Observer {
    private String trackerName;
    
    public GradeTracker(String trackerName) {
        this.trackerName = trackerName;
    }
    
    @Override
    public void update(String message) {
        System.out.println("Grade Tracker [" + trackerName + "] received notification: " + message);
    }
}