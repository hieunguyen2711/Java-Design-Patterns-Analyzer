package edu.platform.student;

public class StudentEnrollmentService {
    private Student student;
    
    public StudentEnrollmentService(Student student) {
        this.student = student;
    }
    
    public void enrollStudent() {
        // Simulate enrollment process
        System.out.println("Enrolling student: " + student.getName());
        
        // Notify observers about enrollment
        student.notifyObservers("Student " + student.getName() + " has been enrolled");
    }
    
    public void updateGrade(String grade) {
        // Simulate grade update
        System.out.println("Updating grade for student: "