package edu.university.enrollment;

import edu.university.student.Student;
import edu.university.course.Course;

public class Enrollment {
    private Student student;
    private Course course;
    
    public Enrollment(Student student, Course course) {
        this.student = student;
        this.course = course;
    }
    
    public Student getStudent() {
        return student;
    }
    
    public Course getCourse() {
        return course;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Enrollment that = (Enrollment) obj;
        return student.equals(that.student) && course.equals(that.course);
    }
    
    @Override
    public int hashCode() {
        int result = student.hashCode();
        result = 31 * result + course.hashCode();
        return result;