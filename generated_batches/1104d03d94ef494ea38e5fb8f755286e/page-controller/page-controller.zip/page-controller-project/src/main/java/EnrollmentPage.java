public class EnrollmentPage extends Page {
    public EnrollmentPage() {
        super("Student Enrollment");
    }
    
    @Override
    public void display() {
        System.out.println("=== " + pageTitle + " ===");
        System.out.println("Select course to enroll:");
        System.out.println("1. Mathematics");
        System.out.println("2. Physics");
        System.out.println("3. Chemistry");
        System.out.println("4. Biology");
    }
}