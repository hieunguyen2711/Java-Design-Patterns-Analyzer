public abstract class Page {
    protected String pageTitle;
    
    public Page(String pageTitle) {
        this.pageTitle = pageTitle;
    }
    
    public abstract void display();
    
    public String getPageTitle() {
        return pageTitle;
    }
}