import java.util.HashMap;
import java.util.Map;

public class StudentEnrollmentController {
    private static StudentEnrollmentController instance;
    private Map<String, String> pageMappings;
    
    private StudentEnrollmentController() {
        pageMappings = new HashMap<>();
        pageMappings.put("enroll", "EnrollmentPage");
        pageMappings.put("schedule", "SchedulePage");
        pageMappings.put("grades", "GradesPage");
        pageMappings.put("attendance", "AttendancePage");
        pageMappings.put("assignments", "AssignmentsPage");
    }
    
    public static StudentEnrollmentController getInstance() {
        if (instance == null) {
            instance = new StudentEnrollmentController();
        }
        return instance;
    }
    
    public String getPage(String action) {
        return pageMappings.getOrDefault(action, "HomePage");
    }
}