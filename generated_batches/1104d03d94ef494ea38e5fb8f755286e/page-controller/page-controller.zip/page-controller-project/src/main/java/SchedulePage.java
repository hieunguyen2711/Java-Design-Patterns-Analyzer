public class SchedulePage extends Page {
    public SchedulePage() {
        super("Class Schedule");
    }
    
    @Override
    public void display() {
        System.out.println("=== " + pageTitle + " ===");
        System.out.println("Current semester schedule:");
        System.out.println("Monday: Mathematics 9:00-10:30");
        System.out.println("Tuesday: Physics 14:00-15:30");
        System.out.println("Wednesday: Chemistry 10:00-11:30");
        System.out.println("Thursday: Biology 13:00-14:30");
    }
}