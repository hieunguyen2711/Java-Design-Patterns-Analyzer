package edu.enrollment;

public class StudentEnrollmentService {
    
    public EnrollmentResult<Student> findStudent(String studentId) {
        if (studentId == null || studentId.isEmpty()) {
            return EnrollmentResult.failure("Invalid student ID");
        }
        
        // Simulate database lookup
        if ("S001".equals(studentId)) {
            return EnrollmentResult.success(new Student("S001", "John Doe"));
        }
        
        return EnrollmentResult.failure("Student not found: " + studentId);
    }
    
    public EnrollmentResult<Course> findCourse(String courseId) {