package edu.enrollment;

import java.util.Optional;

public class EnrollmentResult<T> {
    private final Optional<T> value;
    private final String errorMessage;
    
    private EnrollmentResult(Optional<T> value, String errorMessage) {
        this.value = value;
        this.errorMessage = errorMessage;
    }
    
    public static <T> EnrollmentResult<T> success(T value) {
        return new EnrollmentResult<>(Optional.of(value), null);
    }
    
    public static <T> EnrollmentResult<T> failure(String error) {
        return new EnrollmentResult<>(Optional.empty(), error);
    }
    
    public Optional<T> getValue() {
        return value;
    }
    
    public boolean isSuccess() {
        return value.isPresent();
    }
    
    public String getErrorMessage() {
        return errorMessage;
    }
}