package edu.platform.enrollment;

public interface Enrollable {
    String getEnrollmentId();
    String getStudentName();
}