package edu.platform.course;

public interface CourseAssignee {
    String getCourseAssignmentId();
    String getTeacherId();
}