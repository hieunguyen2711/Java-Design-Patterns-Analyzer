package edu.platform.teacher;

import edu.platform.enrollment.Enrollable;
import edu.platform.course.CourseAssignee;

public class Teacher implements Enrollable, CourseAssignee {
    private String teacherId;
    private String name;
    
    public Teacher(String teacherId, String name) {
        this.teacherId = teacherId;
        this.name = name;
    }
    
    // Implementation of Enrollable interface methods
    @Override
    public String getEnrollmentId() {
        return teacherId;
    }
    
    @Override
    public String getStudentName() {
        return name;
    }
    
    // Implementation of CourseAssignee interface methods
    @Override
    public String getCourseAssignmentId() {
        return teacherId + "-courses";
    }
    
    @Override
    public String getTeacherId() {
        return teacherId;
    }
}