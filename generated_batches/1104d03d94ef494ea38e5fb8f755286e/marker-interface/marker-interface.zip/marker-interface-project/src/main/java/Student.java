package edu.platform.student;

import edu.platform.enrollment.Enrollable;
import edu.platform.grades.GradeReportable;

public class Student implements Enrollable, GradeReportable {
    private String studentId;
    private String name;
    
    public Student(String studentId, String name) {
        this.studentId = studentId;
        this.name = name;
    }
    
    // Implementation of Enrollable interface methods
    @Override
    public String getEnrollmentId() {
        return studentId;
    }
    
    @Override
    public String getStudentName() {
        return name;
    }
    
    // Implementation of GradeReportable interface methods
    @Override
    public String getGradeReportId() {
        return studentId + "-grades";
    }
    
    @Override
    public String getStudentId() {
        return studentId;
    }
}