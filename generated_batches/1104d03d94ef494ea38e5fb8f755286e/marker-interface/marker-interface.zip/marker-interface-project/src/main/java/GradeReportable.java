package edu.platform.grades;

public interface GradeReportable {
    String getGradeReportId();
    String getStudentId();
}