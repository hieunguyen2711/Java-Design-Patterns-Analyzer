public class EnrollmentSystemClient {
    public static void main(String[] args) {
        BusinessDelegate businessDelegate = new BusinessDelegate();
        Client client = new Client(businessDelegate);

        businessDelegate.setServiceType("STUDENT");
        client.doTask();

        businessDelegate.setServiceType("COURSE");
        client.doTask();
    }
}