public class BusinessDelegate {
    private BusinessService businessService;
    private String serviceType;

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public void doTask() {
        if (serviceType.equalsIgnoreCase("STUDENT")) {
            businessService = new StudentBusinessService();
        } else if (serviceType.equalsIgnoreCase("COURSE")) {
            businessService = new CourseBusinessService();
        }
        businessService.doProcessing();
    }
}