public class CourseBusinessService implements BusinessService {
    @Override
    public void doProcessing() {
        System.out.println("Processing task by invoking Course Service");
    }
}