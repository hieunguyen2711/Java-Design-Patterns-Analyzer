public class StudentBusinessService implements BusinessService {
    @Override
    public void doProcessing() {
        System.out.println("Processing task by invoking Student Service");
    }
}