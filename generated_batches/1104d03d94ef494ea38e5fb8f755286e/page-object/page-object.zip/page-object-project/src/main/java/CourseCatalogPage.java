package edu.university.enrollment.page;

import java.util.List;
import java.util.ArrayList;

public class CourseCatalogPage {
    private List<Course> availableCourses;
    
    public CourseCatalogPage() {
        this.availableCourses = new ArrayList<>();
    }
    
    public void addCourse(Course course) {
        availableCourses.add(course);
    }
    
    public List<Course> getAvailableCourses() {
        return new ArrayList<>(availableCourses);
    }
}