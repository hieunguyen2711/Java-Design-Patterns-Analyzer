package edu.university.enrollment.page;

import java.util.List;
import java.util.ArrayList;

public class StudentEnrollmentPage {
    private List<String> enrolledCourses;
    
    public StudentEnrollmentPage() {
        this.enrolledCourses = new ArrayList<>();
    }
    
    public void enrollStudent(String courseName) {
        enrolledCourses.add(courseName);
    }
    
    public List<String> getEnrolledCourses() {
        return new ArrayList<>(enrolledCourses);
    }
}