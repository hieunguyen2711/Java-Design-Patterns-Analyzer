package edu.university.enrollment.page;

public class EnrollmentSystem {
    private StudentEnrollmentPage studentPage;
    private CourseCatalogPage catalogPage;
    
    public EnrollmentSystem() {
        this.studentPage = new StudentEnrollmentPage();
        this.catalogPage = new CourseCatalogPage();
    }
    
    public void addCourseToCatalog(Course course) {
        catalogPage.addCourse(course);
    }
    
    public void enrollStudentInCourse(String courseName) {
        studentPage.enrollStudent(courseName);
    }
    
    public StudentEnrollmentPage getStudentPage() {
        return studentPage;
    }
    
    public CourseCatalogPage getCatalogPage() {
        return catalogPage;
    }
}