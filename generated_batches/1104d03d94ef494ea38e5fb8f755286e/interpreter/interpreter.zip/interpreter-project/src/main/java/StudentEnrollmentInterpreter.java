public class StudentEnrollmentInterpreter {
    public static void main(String[] args) {
        // Create rules for enrollment eligibility
        Expression isFullTime = new TerminalExpression("full-time");
        Expression hasPassedPrerequisites = new TerminalExpression("prerequisites-passed");
        Expression isJuniorOrSenior = new TerminalExpression("junior");
        Expression isSenior = new TerminalExpression("senior");
        
        // Combine expressions: (full-time AND prerequisites-passed) OR (junior OR senior)
        Expression enrollmentRule = new OrExpression(
            new AndExpression(isFullTime, hasPassedPrerequisites),
            new OrExpression(isJuniorOrSenior, isSenior)
        );
        
        // Test cases
        String student1 = "full-time student with prerequisites-passed";
        String student2 = "part-time student with prerequisites-passed";
        String student3 = "junior student";
        String student4 = "freshman student";
        
        System.out.println("Student 1 eligible: " + enrollmentRule.interpret(student1));
        System.out.println("Student 2 eligible: " + enrollmentRule.inter