package edu.platform.student;

public class Student extends Person {
    private String studentId;
    private double gpa;
    
    public Student(String name, int id, String studentId) {
        super(name, id);
        this.studentId = studentId;
        this.gpa = 0.0;
    }
    
    public String getStudentId() {
        return studentId;
    }
    
    public double getGpa() {
        return gpa;
    }
    
    public void setGpa(double gpa) {
        this.gpa = gpa;
    }
    
    @Override
    public String getRole() {
        return "Student";
    }
}