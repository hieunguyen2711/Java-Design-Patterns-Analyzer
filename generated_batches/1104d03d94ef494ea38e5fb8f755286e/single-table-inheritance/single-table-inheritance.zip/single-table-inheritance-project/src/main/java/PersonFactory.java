package edu.platform.student;

public class PersonFactory {
    public static Person createPerson(String type, String name, int id, String details) {
        switch (type.toLowerCase()) {
            case "student":
                return new Student(name, id, details);
            case "teacher":
                return new Teacher(name, id, details);
            default:
                throw new IllegalArgumentException("Unknown person type: " + type);
        }
    }
}