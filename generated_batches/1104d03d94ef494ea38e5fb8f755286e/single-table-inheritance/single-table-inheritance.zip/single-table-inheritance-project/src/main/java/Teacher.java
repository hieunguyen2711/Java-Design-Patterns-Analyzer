package edu.platform.student;

public class Teacher extends Person {
    private String department;
    private int yearsOfExperience;
    
    public Teacher(String name, int id, String department) {
        super(name, id);
        this.department = department;
        this.yearsOfExperience = 0;
    }
    
    public String getDepartment() {
        return department;
    }
    
    public int getYearsOfExperience() {
        return yearsOfExperience;
    }
    
    public void setYearsOfExperience(int yearsOfExperience) {
        this.yearsOfExperience = yearsOfExperience;
    }
    
    @Override
    public String getRole() {
        return "Teacher";
    }
}