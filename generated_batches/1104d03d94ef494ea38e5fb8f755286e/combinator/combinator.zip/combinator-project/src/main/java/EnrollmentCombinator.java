package edu.platform.combinator;

import java.util.List;
import java.util.ArrayList;
import java.util.function.Function;
import java.util.stream.Collectors;

import edu.platform.student.Student;
import edu.platform.course.Course;
import edu.platform.enrollment.Enrollment;

public class EnrollmentCombinator {
    
    public static List<Enrollment> combineStudentsWithCourses(List<Student> students, List<Course> courses) {
        List<Enrollment> enrollments = new ArrayList<>();
        
        for (Student student : students) {
            for (Course course : courses) {
                enrollments.add(new Enrollment(student, course));
            }
        }
        
        return enrollments;
    }
    
    public static <T, U, R> Function<T, R> combine(Function<T, U> first, Function<U, R> second) {
        return t -> second.apply(first.apply(t));
    }
}