package edu.platform.service;

import java.util.List;
import java.util.stream.Collectors;

import edu.platform.student.Student;
import edu.platform.course.Course;
import edu.platform.enrollment.Enrollment;
import edu.platform.combinator.EnrollmentCombinator;