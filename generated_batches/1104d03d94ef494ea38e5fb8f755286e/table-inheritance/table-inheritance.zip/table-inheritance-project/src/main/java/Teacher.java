package edu.platform.student;

public class Teacher extends Person {
    private String department;
    
    public Teacher(String name, int id, String department) {
        super(name, id);
        this.department = department;
    }
    
    public String getDepartment() {
        return department;
    }
}