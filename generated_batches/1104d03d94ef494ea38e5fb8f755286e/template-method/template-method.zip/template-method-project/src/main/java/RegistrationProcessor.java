public class RegistrationProcessor {
    public static void main(String[] args) {
        CourseRegistrationSystem undergraduate = new UndergraduateRegistration();
        CourseRegistrationSystem graduate = new GraduateRegistration();
        
        System.out.println("=== Undergraduate Registration ===");
        undergraduate.registerStudent();
        
        System.out.println("\n=== Graduate Registration ===");
        graduate.registerStudent();
    }
}