public abstract class CourseRegistrationSystem {
    // Template method
    public final void registerStudent() {
        validateStudent();
        checkCourseAvailability();
        processPayment();
        updateEnrollmentRecords();
        sendConfirmation();
    }
    
    protected abstract void validateStudent();
    protected abstract void checkCourseAvailability();
    protected abstract void processPayment();
    protected abstract void updateEnrollmentRecords();
    
    private void sendConfirmation() {
        System.out.println("Sending enrollment confirmation to student");
    }
}