package edu.platform.course;

import java.util.List;
import java.util.ArrayList;

public class Course {
    private String courseName;
    private String courseId;
    private List<Student> students;
    
    public Course(String courseName, String courseId) {
        this.courseName = courseName;
        this.courseId = courseId;
        this.students = new ArrayList<>();
    }
    
    public void addStudent(Student student) {
        students.add(student);
    }
    
    public String getCourseName() {
        return courseName;
    }
    
    public String getCourseId() {
        return courseId;
    }
    
    public List<Student> getStudents() {
        return students;
    }
}