package edu.platform.teacher;

import java.util.List;
import java.util.ArrayList;

public class Teacher {
    private String name;
    private String teacherId;
    private List<Course> courses;
    
    public Teacher(String name, String teacherId) {
        this.name = name;
        this.teacherId = teacherId;
        this.courses = new ArrayList<>();
    }
    
    public void assignCourse(Course course) {
        courses.add(course);
    }
    
    public String getName() {
        return name;
    }
    
    public String getTeacherId() {
        return teacherId;
    }
    
    public List<Course> getCourses() {
        return courses;
    }
}