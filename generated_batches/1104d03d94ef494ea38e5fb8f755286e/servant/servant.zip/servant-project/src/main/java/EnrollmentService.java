package edu.platform.service;

import edu.platform.student.Student;
import edu.platform.course.Course;
import edu.platform.teacher.Teacher;

public class EnrollmentService {
    private static EnrollmentService instance;
    
    private EnrollmentService() {}
    
    public static synchronized EnrollmentService getInstance() {
        if (instance == null) {
            instance = new EnrollmentService();
        }
        return instance;
    }
    
    public void enrollStudentInCourse(Student student, Course course) {
        course.addStudent(student);
    }
    
    public void assignTeacherToCourse(Teacher teacher, Course course) {
        teacher.assignCourse(course);