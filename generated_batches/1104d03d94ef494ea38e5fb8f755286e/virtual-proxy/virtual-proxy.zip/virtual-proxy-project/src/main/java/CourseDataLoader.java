package edu.platform.loader;

import java.util.List;
import java.util.ArrayList;
import edu.platform.student.Student;
import edu.platform.course.Course;

public class CourseDataLoader {
    public static List<Course> loadCourses() {
        // Simulate expensive database operation
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        List<Course> courses = new ArrayList<>();
        courses.add(new Course(1, "Mathematics"));
        courses.add(new Course(2, "Physics"));
        courses.add(new Course(3, "Chemistry"));
        return courses;
    }
    
    public static List<Student> loadStudents() {
        // Simulate expensive database operation
        try {
            Thread.sleep(1500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        List<Student> students = new ArrayList<>();