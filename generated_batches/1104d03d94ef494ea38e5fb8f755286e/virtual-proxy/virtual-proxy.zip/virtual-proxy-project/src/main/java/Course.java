package edu.platform.course;

import java.util.List;
import java.util.ArrayList;

public class Course {
    private int id;
    private String name;
    private List<Student> students;
    
    public Course(int id, String name) {
        this.id = id;
        this.name = name;
        this.students = new ArrayList<>();
    }
    
    public void addStudent(Student student) {
        students.add(student);
    }
    
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public List<Student> getStudents() { return students; }
}