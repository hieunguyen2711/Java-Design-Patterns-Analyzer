package edu.university.enrollment;

public class EnrollmentSystem {
    private final StudentRegistry registry;
    
    public EnrollmentSystem() {
        this.registry = new StudentRegistry();
    }
    
    public void enrollStudent(Student student) {
        registry.addStudent(student);
    }
    
    public void dropStudent(Student student) {
        registry.removeStudent(student);
    }
    
    public void printEnrollmentReport() {
        registry.printReport();
    }
}