package edu.university.enrollment;

public class EnrollmentSystemClient {
    public static void main(String[] args) {
        EnrollmentSystem system = new EnrollmentSystem();
        
        Student s1 = new Student("S001", "Alice Johnson");
        Student s2 = new Student("S002", "Bob Smith");
        Student s3 = new Student("S003", "Carol Davis");
        
        system.enrollStudent(s1);
        system.enrollStudent(s2);
        system.enrollStudent(s3);
        
        system.printEnrollmentReport();
    }
}