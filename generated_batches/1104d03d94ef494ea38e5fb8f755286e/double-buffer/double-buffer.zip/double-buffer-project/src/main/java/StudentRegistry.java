package edu.university.enrollment;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class StudentRegistry {
    private final List<Student> students = new CopyOnWriteArrayList<>();
    
    public void addStudent(Student student) {
        students.add(student);
    }
    
    public void removeStudent(Student student) {
        students.remove(student);
    }
    
    public void printReport() {
        System.out.println("Enrollment Report:");
        for (Student student : students) {
            System.out.println("- " + student.getName() + " (" + student.getId() + ")");
        }
    }
}