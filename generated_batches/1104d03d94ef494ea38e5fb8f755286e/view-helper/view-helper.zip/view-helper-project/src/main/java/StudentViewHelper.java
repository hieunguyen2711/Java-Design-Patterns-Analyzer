package edu.platform.view;

import edu.platform.student.Student;
import edu.platform.course.Course;

public class StudentViewHelper {
    
    public static String generateStudentInfo(Student student, Course course) {
        StringBuilder sb = new StringBuilder();
        sb.append("Student ID: ").append(student.getId())
          .append("\n")
          .append("Name: ").append(student.getName())
          .append("\n")
          .append("Age: ").append(student.getAge())
          .append("\n")
          .append("Course: ").append(course.getCourseName())
          .append("\n");
        return sb.toString();
    }
    
    public static String generateStudentListInfo(Course course) {
        StringBuilder sb = new StringBuilder();
        sb.append("Course: ").append(course.getCourseName()).append("\n");
        sb.append("Enrolled Students:\n");
        
        for (int i = 0; i < course.getStudents().size(); i++) {
            Student student = course.getStudents().get(i);