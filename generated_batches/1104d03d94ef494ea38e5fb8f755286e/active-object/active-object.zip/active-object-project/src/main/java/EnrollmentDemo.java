package edu.platform.activeobject;

public class EnrollmentDemo {
    public static void main(String[] args) {
        StudentEnrollmentService service = new StudentEnrollmentService();
        
        // Schedule multiple enrollment