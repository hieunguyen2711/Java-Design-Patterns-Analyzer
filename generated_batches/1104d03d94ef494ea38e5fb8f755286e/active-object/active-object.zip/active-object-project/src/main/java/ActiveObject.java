package edu.platform.activeobject;

public interface ActiveObject {
    void scheduleTask(Runnable task);
}