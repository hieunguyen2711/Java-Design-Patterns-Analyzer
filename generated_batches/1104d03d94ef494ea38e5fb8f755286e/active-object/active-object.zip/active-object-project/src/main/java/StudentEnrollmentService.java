package edu.platform.activeobject;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class StudentEnrollmentService implements ActiveObject {
    private final BlockingQueue<Runnable> taskQueue = new LinkedBlockingQueue<>();
    
    public StudentEnrollmentService() {
        startProcessingThread();
    }
    
    @Override
    public void scheduleTask(Runnable task) {
        try {
            taskQueue.put(task);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Task scheduling interrupted", e);
        }
    }
    
    private void startProcessingThread() {
        Thread processingThread = new Thread(() -> {
            while (!Thread.currentThread().isInterrupted()) {
                try {
                    Runnable task = taskQueue.take();
                    task.run();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        });
        processingThread.setDaemon(false);
        processingThread.start();
    }
    
    public void enrollStudent(String studentId, String courseId) {
        scheduleTask(() -> {
            // Simulate enrollment process
            System.out.println("Enrolling student " + studentId + " in course " + courseId);
            try {
                Thread.sleep(100); // Simulate processing time
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            System.out.println("Student " + studentId + " enrolled successfully in course " + courseId);
        });
    }
    
    public void updateGrade(String studentId, String courseId, double grade) {
        scheduleTask(() -> {
            // Simulate grade update process
            System.out.println("Updating grade for student " + studentId + " in course " + courseId);
            try {
                Thread.sleep(150); // Simulate processing time
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            System.out.println("Grade updated successfully for student " + studentId + " in course " + courseId);
        });
    }
}