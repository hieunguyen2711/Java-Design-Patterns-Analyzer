package edu.platform.student;

public class Student {
    private final String firstName;
    private final String lastName;
    private final int studentId;
    private final String email;
    private final String phoneNumber;
    
    private Student(Builder builder) {
        this.firstName = builder.firstName;
        this.lastName = builder.lastName;
        this.studentId = builder.studentId;
        this.email = builder.email;
        this.phoneNumber = builder.phoneNumber;
    }
    
    public String getFirstName() {
        return firstName;
    }
    
    public String getLastName() {
        return lastName;
    }
    
    public int getStudentId() {
        return studentId;
    }
    
    public String getEmail() {
        return email;
    }
    
    public String getPhoneNumber() {
        return phoneNumber;
    }
    
    @Override
    public String toString() {
        return "Student{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", studentId=" + studentId +
                ", email='" + email + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                '}';
    }
    
    public static class Builder {
        private String firstName;
        private String lastName;
        private int studentId;
        private String email;
        private String phoneNumber;
        
        public Builder setFirstName(String firstName) {
            this.firstName = firstName;
            return this;
        }
        
        public Builder setLastName(String lastName) {
            this.lastName = lastName;
            return this;
        }
        
        public Builder setStudentId(int studentId) {
            this.studentId = studentId;
            return this;
        }
        
        public Builder setEmail(String email) {
            this.email = email;
            return this;
        }
        
        public Builder setPhoneNumber(String phoneNumber) {
            this.phoneNumber = phoneNumber;
            return this;
        }
        
        public Student build() {
            return new Student(this);
        }
    }
}