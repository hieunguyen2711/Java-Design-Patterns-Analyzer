package edu.platform.student;

public class StudentBuilderDemo {
    public static void main(String[] args) {
        // Using the builder pattern to create student objects
        Student student1 = new Student.Builder()
                .setFirstName("John")
                .setLastName("Doe")
                .setStudentId(12345)
                .setEmail("john.doe@university.edu")
                .build();
        
        Student student2 = new Student.Builder()
                .setFirstName("