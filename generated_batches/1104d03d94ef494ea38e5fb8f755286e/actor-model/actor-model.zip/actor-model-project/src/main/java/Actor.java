package edu.university.enrollment.actor;

public interface Actor {
    void receive(Object message);
}