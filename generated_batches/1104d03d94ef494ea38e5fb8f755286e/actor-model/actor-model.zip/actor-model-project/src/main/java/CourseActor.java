package edu.university.enrollment.actor;

import java.util.HashMap;
import java.util.Map;

public class CourseActor implements Actor {
    private final Map<String, String> courseTeachers = new HashMap<>();
    
    @Override
    public void receive(Object message) {
        if (message instanceof AssignTeacher) {
            AssignTeacher assignMsg = (AssignTeacher) message;
            courseTeachers.put(assignMsg.courseId, assignMsg.teacherId);
        } else if (message instanceof GetTeacher) {
            GetTeacher getMsg = (GetTeacher) message;
            String teacherId = courseTeachers.get(getMsg.courseId);
            System.out.println("Course " + getMsg.courseId + " taught by: " + teacherId);
        }
    }
    
    public static class AssignTeacher {
        private final String courseId;
        private final String teacherId;
        
        public AssignTeacher(String courseId, String teacherId) {
            this.courseId = courseId;
            this.teacherId = teacherId;
        }
    }