package edu.university.enrollment.actor;

import java.util.HashMap;
import java.util.Map;

public class EnrollmentActor implements Actor {
    private final Map<String, String> studentEnrollments = new HashMap<>();
    
    @Override
    public void receive(Object message) {
        if (message instanceof EnrollStudent) {
            EnrollStudent enrollMsg = (EnrollStudent) message;
            studentEnrollments.put(enrollMsg.studentId, enrollMsg.courseId);
        } else if (message instanceof GetEnrollment) {
            GetEnrollment getMsg = (GetEnrollment) message;
            String courseId = studentEnrollments.get(getMsg.studentId);
            System.out.println("Student " + getMsg.studentId + " enrolled in course: " + courseId);
        }
    }
    
    public static class EnrollStudent {
        private final String studentId;
        private final String courseId;
        
        public EnrollStudent(String studentId, String courseId) {
            this.studentId = studentId;
            this.courseId = courseId;
        }
    }
    
    public static class GetEnrollment {
        private final String studentId;
        
        public GetEnrollment(String studentId) {
            this.studentId = studentId;
        }
    }
}