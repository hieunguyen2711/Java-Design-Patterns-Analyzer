package edu.platform.service;

import edu.platform.student.Student;
import edu.platform.course.Course;
import java.util.HashMap;
import java.util.Map;

public class EnrollmentService {
    private Map<String, Course> courses;
    
    public EnrollmentService() {
        this.courses = new HashMap<>();
    }
    
    public void addCourse(Course course) {
        courses.put(course.getCourseId(), course);
    }
    
    public Student enrollStudentInCourse(String studentId, String courseId) {
        Course course = courses.get(courseId);
        if (course == null) {
            return StudentSpecialCase.getInstance();
        }
        
        // In a real implementation, this would actually enroll the student
        return new Student(studentId, "Enrolled Student");
    }
}