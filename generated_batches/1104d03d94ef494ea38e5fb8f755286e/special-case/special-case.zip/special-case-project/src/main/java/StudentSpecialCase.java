package edu.platform.student;

public class StudentSpecialCase extends Student {
    private static final StudentSpecialCase INSTANCE = new StudentSpecialCase();
    
    private StudentSpecialCase() {
        super("SPECIAL_CASE", "Special Case Student");
    }
    
    public static Student getInstance() {
        return INSTANCE;
    }
}