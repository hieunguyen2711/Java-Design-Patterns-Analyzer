public class UniversityEnrollmentSystem implements EnrollmentSystem {
    private EnrollmentSystem implementation;
    
    public UniversityEnrollmentSystem(EnrollmentSystem implementation) {
        this.implementation = implementation;
    }
    
    @Override
    public void enrollStudent(Student student, Course course) {
        implementation.enrollStudent(student, course);
    }
    
    @Override
    public void dropStudent(Student student, Course course) {
        implementation.dropStudent(student, course);
    }
    
    @Override
    public void displayEnrollmentStatus() {
        implementation.displayEnrollmentStatus();
    }
}