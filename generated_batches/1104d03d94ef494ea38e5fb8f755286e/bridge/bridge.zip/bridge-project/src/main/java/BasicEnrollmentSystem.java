import java.util.*;

public class BasicEnrollmentSystem implements EnrollmentSystem {
    private Map<Student, List<Course>> enrollments;
    
    public BasicEnrollmentSystem() {
        this.enrollments = new HashMap<>();
    }
    
    @Override
    public void enrollStudent(Student student, Course course) {
        enrollments.computeIfAbsent(student, k -> new ArrayList<>()).add(course);
    }
    
    @Override
    public void dropStudent(Student student, Course course) {
        if (enrollments.containsKey(student)) {
            enrollments.get(student).remove(course);
        }
    }
    
    @Override
    public void displayEnrollmentStatus() {
        for (Map.Entry<Student, List<Course>> entry : enrollments.entrySet()) {
            System.out.println("Student