package edu.platform.student;

public class NullStudent extends Student {
    
    public NullStudent() {
        super("Unknown", -1);
    }
    
    @Override
    public String getName() {
        return "Unknown";
    }
    
    @Override
    public int getId() {
        return -1;
    }
}