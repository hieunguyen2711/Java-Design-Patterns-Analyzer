package edu.platform.student;

public class StudentRepository {
    private static final Student[] students = {
        new Student("Alice Johnson", 1001),
        new Student("Bob Smith", 1002),
        new Student("Charlie Brown", 1003)
    };
    
    public static Student findStudentById(int id) {
        for (Student student : students) {
            if (student.getId() == id) {
                return student;
            }
        }
        return new NullStudent();
    }
}