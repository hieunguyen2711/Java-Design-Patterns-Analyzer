package edu.platform.student;

public class EnrollmentService {
    
    public void enrollStudent(int studentId) {
        Student student = StudentRepository.findStudentById(studentId);
        
        if (student instanceof NullStudent) {
            System.out.println("Cannot enroll invalid student");
        } else {
            System.out.println("Enrolling student: " + student.getName());
        }
    }
}