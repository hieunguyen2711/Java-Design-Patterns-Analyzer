package edu.platform.student;

public class Main {
    public static void main(String[] args) {
        EnrollmentService service = new EnrollmentService();
        
        service.enrollStudent(1001); // Valid student
        service.enrollStudent(9999); // Invalid student - returns null object
    }
}