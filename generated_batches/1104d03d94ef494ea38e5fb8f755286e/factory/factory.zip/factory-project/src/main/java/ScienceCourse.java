public class ScienceCourse extends Course {
    public ScienceCourse(String courseName, int credits) {
        super(courseName, credits);
    }
    
    @Override
    public void displayCourseInfo() {
        System.out.println("Science Course: " + courseName + " (" + credits + " credits)");
    }
}