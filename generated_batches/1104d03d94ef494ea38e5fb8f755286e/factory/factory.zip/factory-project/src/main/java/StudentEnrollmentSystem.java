public class StudentEnrollmentSystem {
    public static void main(String[] args) {
        Course mathCourse = CourseFactory.createCourse("math", "Calculus I", 4);
        Course scienceCourse = CourseFactory.createCourse("science", "Biology", 3);
        Course history