public class MathCourse extends Course {
    public MathCourse(String courseName, int credits) {
        super(courseName, credits);
    }
    
    @Override
    public void displayCourseInfo() {
        System.out.println("Math Course: " + courseName + " (" + credits + " credits)");
    }
}