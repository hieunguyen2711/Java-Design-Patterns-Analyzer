public class HistoryCourse extends Course {
    public HistoryCourse(String courseName, int credits) {
        super(courseName, credits);
    }
    
    @Override
    public void displayCourseInfo() {
        System.out.println("History Course: " + courseName + " (" + credits + " credits)");
    }
}