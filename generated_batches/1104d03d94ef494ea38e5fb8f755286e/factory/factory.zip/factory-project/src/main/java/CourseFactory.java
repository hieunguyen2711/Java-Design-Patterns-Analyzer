public class CourseFactory {
    public static Course createCourse(String type, String courseName, int credits) {
        if (type == null) {
            return null;
        }
        
        switch (type.toLowerCase()) {
            case "math":
                return new MathCourse(courseName, credits);
            case "science":
                return new ScienceCourse(courseName, credits);
            case "history":
                return new HistoryCourse(courseName, credits);
            default:
                return null;
        }
    }
}