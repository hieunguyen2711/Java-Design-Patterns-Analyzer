package edu.platform.service.factory;

import edu.platform.service.StudentEnrollmentService;
import edu.platform.service.impl.EnrollmentServiceImpl;
import edu.platform.service.stub.StudentEnrollmentServiceStub;

public class EnrollmentServiceFactory {
    public static StudentEnrollmentService createRealService() {
        return new EnrollmentServiceImpl();
    }
    
    public static StudentEnrollmentService createStubService()