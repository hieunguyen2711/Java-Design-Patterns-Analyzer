package edu.platform.service.impl;

import edu.platform.service.StudentEnrollmentService;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;

public class EnrollmentServiceImpl implements StudentEnrollmentService {
    private final Map<String, Set<String>> enrollmentMap = new HashMap<>();
    
    @Override
    public boolean enrollStudent(String studentId, String courseId) {
        return enrollmentMap.computeIfAbsent(studentId, k -> new HashSet<>()).add(courseId);
    }
    
    @Override
    public boolean dropStudent(String studentId, String courseId) {
        Set<String> courses = enrollmentMap.get(studentId);
        if (courses != null) {
            return courses.remove(courseId);
        }
        return false;
    }
    
    @Override
    public boolean isEnrolled(String studentId, String courseId) {
        Set<String> courses = enrollmentMap.get(studentId);
        return courses != null && courses.contains(courseId);
    }
}