package edu.platform.service;

public interface StudentEnrollmentService {
    boolean enrollStudent(String studentId, String courseId);
    boolean dropStudent(String studentId, String courseId);
    boolean isEnrolled(String studentId, String courseId);
}