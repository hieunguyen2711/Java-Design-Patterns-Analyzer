package edu.platform.service.stub;

import edu.platform.service.StudentEnrollmentService;
import java.util.Collections;
import java.util.Set;
import java.util.HashSet;

public class StudentEnrollmentServiceStub implements StudentEnrollmentService {
    private final Set<String> enrolledStudents = new HashSet<>();
    
    @Override
    public boolean enrollStudent(String studentId, String courseId) {
        return enrolledStudents.add(studentId);
    }
    
    @Override
    public boolean dropStudent(String studentId, String courseId) {
        return enrolledStudents.remove(studentId);
    }
    
    @Override
    public boolean isEnrolled(String studentId, String courseId) {
        return enrolledStudents.contains(studentId);
    }
}