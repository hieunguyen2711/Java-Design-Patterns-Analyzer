package edu.platform.course;

import java.util.List;
import java.util.ArrayList;
import edu.platform.student.Student;

public class Course {
    private String courseId;
    private String courseName;
    private List<Student> students;
    private Teacher teacher;
    
    public Course(String courseId, String courseName) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.students = new ArrayList<>();
    }
    
    public void addStudent(Student student) {
        students.add(student);
    }
    
    public void assignTeacher(Teacher teacher) {
        this.teacher = teacher;
        teacher.assignCourse(this);
    }
    
    public List<Student> getStudents() {
        return students;
    }
    
    public Teacher getTeacher() {
        return teacher;
    }
    
    public String getCourseId() {
        return courseId;
    }
    
    public String getCourseName() {
        return courseName;
    }
}