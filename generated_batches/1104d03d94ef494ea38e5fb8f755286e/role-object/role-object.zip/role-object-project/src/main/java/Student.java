package edu.platform.student;

import java.util.List;
import java.util.ArrayList;

public class Student {
    private String id;
    private String name;
    private List<Course> enrolledCourses;
    
    public Student(String id, String name) {
        this.id = id;
        this.name = name;
        this.enrolledCourses = new ArrayList<>();
    }
    
    public void enrollInCourse(Course course) {
        enrolledCourses.add(course);
        course.addStudent(this);
    }
    
    public List<Course> getEnrolledCourses() {
        return enrolledCourses;
    }
    
    public String getId() {
        return id;
    }
    
    public String getName() {
        return name;
    }
}