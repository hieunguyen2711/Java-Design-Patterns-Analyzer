package edu.platform.teacher;

import java.util.List;
import java.util.ArrayList;
import edu.platform.course.Course;

public class Teacher {
    private String id;
    private String name;
    private List<Course> assignedCourses;
    
    public Teacher(String id, String name) {
        this.id = id;
        this.name = name;
        this.assignedCourses = new ArrayList<>();
    }
    
    public void assignCourse(Course course) {
        assignedCourses.add(course);
    }
    
    public List<Course> getAssignedCourses() {
        return assignedCourses;
    }
    
    public String getId() {
        return id;
    }
    
    public String getName() {
        return name;
    }
}