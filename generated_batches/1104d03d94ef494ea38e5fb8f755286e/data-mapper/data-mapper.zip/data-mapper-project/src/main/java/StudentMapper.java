package edu.platform.mapper;

import edu.platform.student.Student;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentMapper {
    
    public List<Student> findAll(Connection connection) throws SQLException {
        List<Student> students = new ArrayList<>();
        String sql = "SELECT id, name, email FROM students";
        
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                Student student = new Student(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("email")
                );
                students.add(student);
            }
        }
        return students;
    }
    
    public Student findById(Connection connection, int id) throws SQLException {
        String sql = "SELECT id, name, email FROM students WHERE id = ?";
        
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Student(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("email")
                    );
                }
            }
        }
        return null;
    }
    
    public void save(Connection connection, Student student) throws SQLException {
        String sql = "INSERT INTO students (name, email) VALUES (?, ?)";
        
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, student.getName());
            stmt.setString(2, student.getEmail());
            stmt.executeUpdate();
        }
    }
    
    public void update(Connection connection, Student student) throws SQLException {
        String sql = "UPDATE students SET name = ?, email = ? WHERE id = ?";
        
        try (PreparedStatement stmt =