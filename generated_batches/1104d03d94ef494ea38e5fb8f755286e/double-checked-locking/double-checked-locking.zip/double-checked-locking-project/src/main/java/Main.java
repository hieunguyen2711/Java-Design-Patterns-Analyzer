public class Main {
    public static void main(String[] args) {
        EnrollmentService service1 = new EnrollmentService();
        EnrollmentService service2 = new EnrollmentService();
        
        service1.registerStudent("S001", "CSC101");
        service2.registerStudent("S002", "MATH201");
        
        System.out.println("Both services reference the same instance: " + 
                          (service1 == service2));
    }
}