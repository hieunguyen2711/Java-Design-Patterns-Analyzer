public class EnrollmentService {
    private StudentEnrollmentSystem enrollmentSystem;
    
    public EnrollmentService() {
        this.enrollmentSystem = StudentEnrollmentSystem.getInstance();
    }
    
    public void registerStudent(String studentId, String courseId) {
        enrollmentSystem.enrollStudent(studentId, courseId);
    }
}