public class StudentEnrollmentSystem {
    private static volatile StudentEnrollmentSystem instance;
    
    private StudentEnrollmentSystem() {
        // Private constructor to prevent instantiation
    }
    
    public static StudentEnrollmentSystem getInstance() {
        if (instance == null) {
            synchronized (StudentEnrollmentSystem.class) {
                if (instance == null) {
                    instance = new StudentEnrollmentSystem();
                }
            }
        }
        return instance;
    }
    
    public void enrollStudent(String studentId, String courseId) {
        System.out.println("Enrolling student " + studentId + " in course " + courseId);
    }
}