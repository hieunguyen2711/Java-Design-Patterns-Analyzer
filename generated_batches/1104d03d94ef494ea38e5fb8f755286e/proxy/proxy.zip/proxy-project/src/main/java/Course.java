public class Course {
    private String courseName;
    private String courseId;
    private int credits;
    
    public Course(String courseName, String courseId, int credits) {
        this.courseName = courseName;
        this.courseId = courseId;
        this.credits = credits;
    }
    
    public String getCourseName() {
        return courseName;
    }
    
    public String getCourseId() {
        return courseId;
    }
    
    public int getCredits() {
        return credits;
    }
}