public interface EnrollmentService {
    void enrollStudent(Student student, Course course);
    boolean isEnrolled(Student student, Course course);
}