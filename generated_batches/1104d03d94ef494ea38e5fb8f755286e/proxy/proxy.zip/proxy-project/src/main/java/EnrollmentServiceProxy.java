public class EnrollmentServiceProxy implements EnrollmentService {
    private RealEnrollmentService realService;
    private Student currentStudent;
    
    public EnrollmentServiceProxy(Student student) {
        this.currentStudent = student;
        this.realService = new RealEnrollmentService();
    }
    
    @Override
    public void enrollStudent(Student student, Course