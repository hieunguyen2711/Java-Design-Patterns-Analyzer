import java.util.*;

public class RealEnrollmentService implements EnrollmentService {
    private Map<Student, List<Course>> enrollmentRecords;
    
    public RealEnrollmentService() {
        this.enrollmentRecords = new HashMap<>();
    }
    
    @Override
    public void enrollStudent(Student student, Course course) {
        System.out.println("Performing actual enrollment for " + student.getName() + 
                          " in " + course.getCourseName());
        
        enrollmentRecords.putIfAbsent(student, new ArrayList<>());
        enrollmentRecords.get(student).add(course);
    }
    
    @Override
    public boolean isEnrolled(Student student, Course course) {
        System.out.println("Checking actual enrollment status for " + student.getName() + 
                          " in " + course.getCourseName());
        
        List<Course> enrolledCourses = enrollmentRecords.get(student);
        return enrolledCourses != null && enrolledCourses.contains(course);
    }
}