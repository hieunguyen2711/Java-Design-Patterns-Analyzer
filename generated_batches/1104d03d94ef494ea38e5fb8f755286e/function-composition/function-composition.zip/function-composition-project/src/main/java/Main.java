package edu.platform;

import edu.platform.student.Student;
import edu.platform.course.Course;
import edu.platform.service.EnrollmentService;

public class Main {
    public static void main(String[] args) {
        Student student = new Student("John Doe", 12345);
        Course course = new Course("Advanced Mathematics", "MATH-404");
        
        EnrollmentService.enrollStudent(student, course);
    }
}