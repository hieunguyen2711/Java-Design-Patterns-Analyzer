package edu.platform.service;

import edu.platform.student.Student;
import edu.platform.course.Course;
import java.util.function.Function;

public class EnrollmentService {
    
    public static Function<Student, String> studentNameExtractor = 
        student -> student.getName();
        
    public static Function<Course, String> courseNameExtractor = 
        course -> course.getCourseName();
        
    public static Function<String, String> upperCaseTransformer = 
        name -> name.toUpperCase();
        
    public static Function<String, String> prefixFormatter = 
        name -> "ENROLLED: " + name;
    
    public static void enrollStudent(Student student, Course course) {
        // Compose functions to create enrollment message
        Function<Student, String> fullNameExtractor = studentNameExtractor;
        Function<String, String> upperCaseName = fullNameExtractor.andThen(upperCaseTransformer);
        Function<String, String> finalMessage = upperCaseName.andThen(prefixFormatter);
        
        String result = finalMessage.apply(student);
        System.out.println(result + " IN " + course.getCourseId());
    }
}