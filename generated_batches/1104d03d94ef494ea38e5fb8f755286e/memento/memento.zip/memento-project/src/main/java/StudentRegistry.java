package edu.platform.student;

import java.util.ArrayList;
import java.util.List;

public class StudentRegistry {
    private final List<Student> students;
    private final List<Student.Memento> mementos;
    
    public StudentRegistry() {
        this.students = new ArrayList<>();
        this.mementos = new ArrayList<>();
    }
    
    public void addStudent(Student student) {
        students.add(student);
    }
    
    public void saveState() {
        for (Student student : students) {
            mementos.add(student.saveState());
        }
    }
    
    public void restoreState() {
        if (mementos.isEmpty()) return;
        
        int index = 0;
        for (Student student : students) {
            if (index < mementos.size()) {
                student.restoreState(mementos.get(index));
                index++;
            }
        }
    }
    
    public List<Student> getStudents() {
        return new ArrayList<>(students);
    }
}