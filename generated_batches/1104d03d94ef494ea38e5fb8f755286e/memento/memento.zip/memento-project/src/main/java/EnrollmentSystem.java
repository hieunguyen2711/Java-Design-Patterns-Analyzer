package edu.platform.student;

public class EnrollmentSystem {
    public static void main(String[] args) {
        StudentRegistry registry = new StudentRegistry();
        
        Student alice = new Student("Alice");