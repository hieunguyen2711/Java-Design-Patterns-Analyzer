package edu.platform.student;

import java.util.ArrayList;
import java.util.List;

public class Student {
    private String name;
    private List<String> enrolledCourses;
    
    public Student(String name) {
        this.name = name;
        this.enrolledCourses = new ArrayList<>();
    }
    
    public void enrollCourse(String course) {
        enrolledCourses.add(course);
    }
    
    public void dropCourse(String course) {
        enrolledCourses.remove(course);
    }
    
    public String getName() {
        return name;
    }
    
    public List<String> getEnrolledCourses() {
        return new ArrayList<>(enrolledCourses);
    }
    
    public Memento saveState() {
        return new Memento(new ArrayList<>(enrolledCourses));
    }
    
    public void restoreState(Memento memento) {
        this.enrolledCourses = new ArrayList<>(memento.getCourses());
    }
    
    public static class Memento {
        private final List<String> courses;
        
        public Memento(List<String> courses) {
            this.courses = new ArrayList<>(courses);
        }
        
        public List<String> getCourses() {
            return new ArrayList<>(courses);
        }
    }
}