package com.school.service;

public interface StudentEnrollmentService {
    void enrollStudent(String studentId, String courseId);
    void dropCourse(String studentId, String courseId);
    boolean isEnrolled(String studentId, String courseId);
}