package com.school.service.impl;

import com.school.service.StudentEnrollmentService;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class EnrollmentServiceImpl implements StudentEnrollmentService {
    private final Map<String, Set<String>> studentCourses = new HashMap<>();
    
    @Override
    public void enrollStudent(String studentId, String courseId) {
        studentCourses.computeIfAbsent(studentId, k -> new HashSet<>()).add(courseId);
    }
    
    @Override
    public void dropCourse(String studentId, String courseId) {
        Set<String> courses = studentCourses.get(studentId);
        if (courses != null) {
            courses.remove(courseId);
        }
    }
    
    @Override