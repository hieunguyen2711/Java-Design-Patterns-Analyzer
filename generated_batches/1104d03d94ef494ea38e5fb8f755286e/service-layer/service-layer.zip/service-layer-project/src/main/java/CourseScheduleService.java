package com.school.service;

import java.util.List;
import java.util.Map;

public interface CourseScheduleService {
    Map<String, List<String>> getCourseSchedule(String courseId);
    void updateSchedule(String courseId, Map<String, List<String>> schedule);
    List<String> getAvailableSlots(String courseId);
}