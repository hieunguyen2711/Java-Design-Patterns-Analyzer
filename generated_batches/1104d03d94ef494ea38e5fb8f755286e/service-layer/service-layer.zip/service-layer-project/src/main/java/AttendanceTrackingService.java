package com.school.service;

import java.util.Map;
import java.util.Set;

public interface AttendanceTrackingService {
    void markAttendance(String studentId, String courseId, boolean present);
    boolean isPresent(String studentId, String courseId);
    Map<String, Set<String>> getAttendanceReport(String courseId);
}