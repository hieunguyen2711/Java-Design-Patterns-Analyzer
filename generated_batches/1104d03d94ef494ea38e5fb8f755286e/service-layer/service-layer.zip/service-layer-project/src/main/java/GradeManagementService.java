package com.school.service;

import java.util.Map;

public interface GradeManagementService {
    void submitGrade(String studentId, String courseId, double grade);
    double getGrade(String studentId, String courseId);
    Map<String, Double> getAllGradesForStudent(String studentId);
}