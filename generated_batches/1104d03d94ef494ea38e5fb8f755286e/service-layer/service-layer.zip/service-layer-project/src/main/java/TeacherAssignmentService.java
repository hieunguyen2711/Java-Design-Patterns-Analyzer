package com.school.service;

import java.util.List;
import java.util.Map;

public interface TeacherAssignmentService {
    void assignTeacherToCourse(String teacherId, String courseId);
    List<String> getCoursesForTeacher(String teacherId);
    Map<String, String> getTeacherAssignments();
}