package edu.enrollment.controller;

import edu.enrollment.model.Student;
import edu.enrollment.view.StudentView;
import java.util.ArrayList;
import java.util.List;

public class StudentController {
    private List<Student> students;
    private StudentView view;
    
    public StudentController() {
        this.students = new ArrayList<>();
        this.view = new StudentView();
    }
    
    public void addStudent(String id, String name, String email) {
        Student student = new Student(id, name, email);
        students.add(student);
    }
    
    public void updateStudent(String id, String name, String email) {
        for (Student student : students) {
            if (student.getId().equals(id)) {
                student.setName(name);
                student.setEmail(email);
                break;
            }
        }
    }
    
    public Student getStudentById(String id) {
        for (Student student : students) {
            if