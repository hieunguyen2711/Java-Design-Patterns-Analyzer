package edu.enrollment.view;

import edu.enrollment.model.Student;
import java.util.List;

public class StudentView {
    public void displayStudentList(List<Student> students) {
        System.out.println("=== Student List ===");
        for (Student student : students) {
            System.out.println("ID: " + student.getId() + 
                             ", Name: " + student.getName() + 
                             ", Email: " + student.getEmail());
        }
    }
    
    public void displayStudentDetails(Student student) {
        System.out.println("=== Student Details ===");
        System.out.println("ID: " + student.getId());
        System.out.println("Name: " + student.getName());
        System.out.println("Email: " + student.getEmail());
    }
}