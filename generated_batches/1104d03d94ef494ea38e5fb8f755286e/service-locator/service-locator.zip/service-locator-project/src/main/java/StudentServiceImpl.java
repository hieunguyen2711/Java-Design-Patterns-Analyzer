public class StudentServiceImpl implements StudentService {
    @Override
    public void enrollStudent(String studentId, String courseId) {
        System.out.println("Enrolling student " + studentId + " in course " + courseId);
    }

    @Override
    public void dropStudent(String studentId, String courseId) {
        System.out.println("Dropping student " + studentId + " from course " + courseId);
    }

    @Override
    public String getName() {
        return "StudentService";
    }
}