public interface CourseService extends Service {
    void assignTeacher(String courseId, String teacherId);
    void scheduleClass(String courseId, String timeSlot);
}