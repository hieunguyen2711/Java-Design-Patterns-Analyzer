public interface GradeService extends Service {
    void recordGrade(String studentId, String courseId, double grade);
    double getAverageGrade(String studentId);
}