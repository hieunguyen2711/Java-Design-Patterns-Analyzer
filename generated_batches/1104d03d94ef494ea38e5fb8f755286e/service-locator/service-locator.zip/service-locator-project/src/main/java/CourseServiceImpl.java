public class CourseServiceImpl implements CourseService {
    @Override
    public void assignTeacher(String courseId, String teacherId) {
        System.out.println