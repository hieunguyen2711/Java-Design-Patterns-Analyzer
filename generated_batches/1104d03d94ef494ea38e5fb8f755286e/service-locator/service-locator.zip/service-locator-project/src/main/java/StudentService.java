public interface StudentService extends Service {
    void enrollStudent(String studentId, String courseId);
    void dropStudent(String studentId, String courseId);
}