import java.util.HashMap;
import java.util.Map;

public class ServiceRegistry {
    private Map<String, Object> services;

    public ServiceRegistry() {
        services = new HashMap<>();
        initializeServices();
    }

    private void initializeServices() {
        services.put("StudentService", new StudentServiceImpl());
        services.put("CourseService", new CourseServiceImpl());
        services.put("GradeService", new GradeServiceImpl());
    }

    public Object getService(String serviceName) {
        return services.get(serviceName);
    }
}