package edu.platform.student;

public class Student {
    private String id;
    private String name;
    private int gradeLevel;
    
    public Student(String id, String name, int gradeLevel) {
        this.id = id;
        this.name = name;
        this.gradeLevel = gradeLevel;
    }
    
    public String getId() {
        return id;
    }
    
    public String getName() {
        return name;
    }
    
    public int getGradeLevel() {
        return gradeLevel;
    }
}