package edu.platform.service;

import java.util.List;
import java.util.stream.Collectors;
import edu.platform.student.Student;
import edu.platform.course.Course;

public class EnrollmentService {
    
    public List<Student> findStudentsInGrade(List<Course> courses, int gradeLevel) {
        return courses.stream()
                .flatMap(course -> course.getEnrolledStudents().stream())
                .filter(student -> student.getGradeLevel() == gradeLevel)
                .distinct()
                .collect(Collectors.toList());
    }
    
    public List<String> getCourseNamesForStudent(List<Course> courses, String studentId) {
        return courses.stream()
                .filter(course -> course.getEnrolledStudents().stream()
                        .anyMatch(student -> student.getId().equals(studentId)))
                .map(Course::getCourseName)
                .collect(Collectors.toList());
    }
    
    public List<Student> findHighPerformingStudents(List<Course> courses, int minGrade) {
        return courses.stream()
                .flatMap(course -> course.getEnrolledStudents().stream())
                .filter(student -> student.getGradeLevel() >= minGrade)
                .distinct()
                .sorted((s