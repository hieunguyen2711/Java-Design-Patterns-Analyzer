package edu.platform.course;

import java.util.List;
import java.util.ArrayList;

public class Course {
    private String courseId;
    private String courseName;
    private List<Student> enrolledStudents;
    
    public Course(String courseId, String courseName) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.enrolledStudents = new ArrayList<>();
    }
    
    public void enrollStudent(Student student) {
        enrolledStudents.add(student);
    }
    
    public List<Student> getEnrolledStudents() {
        return enrolledStudents;
    }
    
    public String getCourseId() {
        return courseId;
    }
    
    public String getCourseName() {
        return courseName;
    }
}