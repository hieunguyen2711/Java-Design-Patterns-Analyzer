package edu.university.studentenrollment.view;

import java.util.List;

import edu.university.studentenrollment.model.Course;
import edu.university.studentenrollment.model.Student;

public interface StudentEnrollmentView {
    void displayStudents(List<Student> students);
    void displayCourses(List<Course> courses);
    void showErrorMessage(String message);
    String getStudentName();
    String getCourseCode();
}