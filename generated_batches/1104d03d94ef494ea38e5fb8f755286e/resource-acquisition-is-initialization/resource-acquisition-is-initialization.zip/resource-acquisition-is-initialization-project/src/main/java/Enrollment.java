package edu.platform.enrollment;

import edu.platform.student.Student;
import edu.platform.course.Course;

public class Enrollment implements AutoCloseable {
    private Student student;
    private Course course;
    private boolean enrolled;
    
    public Enrollment(Student student, Course course) {
        this.student = student;
        this.course = course;
        this.enrolled = true;
        System.out.println("Enrollment created for " + student.getName() + 
                          " in " + course.getCourseName());
    }
    
    public Student getStudent() {
        return student;
    }
    
    public Course getCourse() {
        return course;
    }
    
    @Override
    public void close() {
        if (enrolled) {
            enrolled = false;
            System.out.println("Enrollment closed for " + student.getName() + 
                              " in " + course.getCourseName());
        }
    }
}