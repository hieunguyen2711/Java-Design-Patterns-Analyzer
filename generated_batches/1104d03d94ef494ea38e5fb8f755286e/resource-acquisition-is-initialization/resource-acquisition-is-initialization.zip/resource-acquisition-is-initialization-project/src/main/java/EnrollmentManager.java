package edu.platform.enrollment;

import edu.platform.student.Student;
import edu.platform.course.Course;

public class EnrollmentManager {
    
    public void enrollStudentInCourse(Student student, Course course) {
        try (Enrollment enrollment = new Enrollment(student, course)) {
            // Simulate some processing with the enrollment
            System.out.println("Processing enrollment...");
            // The enrollment will be automatically closed when exiting the try block
        }
    }
}