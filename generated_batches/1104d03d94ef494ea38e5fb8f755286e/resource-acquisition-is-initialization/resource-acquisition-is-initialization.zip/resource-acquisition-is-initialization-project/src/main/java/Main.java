package edu.platform;

import edu.platform.student.Student;
import edu.platform.course.Course;
import edu.platform.enrollment.EnrollmentManager;

public class Main {
    public static void main(String