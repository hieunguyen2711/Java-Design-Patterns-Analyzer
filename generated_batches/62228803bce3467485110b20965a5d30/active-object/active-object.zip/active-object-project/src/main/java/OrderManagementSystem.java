public class OrderManagementSystem {
    private final ActiveObjectEngine activeObject;
    
    public OrderManagementSystem() {
        this.activeObject = new ActiveObjectEngine();
    }
    
    public void submitOrder(String orderId, double amount) {
        Order order = new Order(orderId, amount);
        activeObject.processOrder(order);
    }
    
    public void cancelOrder(String orderId) {
        activeObject.cancelOrder(orderId);
    }
    
    public static void main(String[] args) {
        OrderManagementSystem system = new OrderManagementSystem();
        
        system.submitOrder("ORD-001", 299.99);
        system.submitOrder("ORD-002", 149.50);
        system.cancelOrder("ORD-001");
        
        try {
            Thread.sleep(3000); // Wait for processing to complete
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        system.shutdown();
    }
    
    public void shutdown() {
        activeObject.shutdown();
    }
}