import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class ActiveObjectEngine implements OrderProcessor {
    private final BlockingQueue<Runnable> queue = new LinkedBlockingQueue<>();
    private final Thread workerThread;
    
    public ActiveObjectEngine() {
        this.workerThread = new Thread(this::processTasks);
        this.workerThread.start();
    }
    
    @Override
    public void processOrder(Order order) {
        queue.add(() -> {
            System.out.println("Processing order: " + order.getOrderId() + 
                             " for amount: $" + order.getAmount());
            try {
                Thread.sleep(1000); // Simulate processing time
                System.out.println("Completed processing order: " + order.getOrderId());
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
    }
    
    @Override
    public void cancelOrder(String orderId) {
        queue.add(() -> {
            System.out.println("Cancelling order: " + orderId);
            try {
                Thread.sleep(500); // Simulate cancellation time
                System.out.println("Cancelled order: " + orderId);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
    }
    
    private void processTasks() {
        while (!Thread.currentThread().isInterrupted()) {
            try {
                Runnable task = queue.take();
                task.run();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }
    
    public void shutdown() {
        workerThread.interrupt();
    }
}