public interface OrderProcessor {
    void processOrder(Order order);
    void cancelOrder(String orderId);
}