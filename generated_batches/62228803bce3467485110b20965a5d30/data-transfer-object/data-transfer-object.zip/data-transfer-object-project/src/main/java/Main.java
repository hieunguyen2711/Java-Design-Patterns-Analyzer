package com.example.ordermanagement;

public class Main {
    public static void main(String[] args) {
        OrderService orderService = new OrderService();
        OrderController controller = new OrderController(orderService);
        
        // Simulate handling an order request
        controller.handleOrderRequest("ORD-456");
    }
}