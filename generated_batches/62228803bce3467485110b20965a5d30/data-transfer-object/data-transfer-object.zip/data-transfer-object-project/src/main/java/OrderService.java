package com.example.ordermanagement;

public class OrderService {
    
    public OrderDTO getOrderDetails(String orderId) {
        // Simulate fetching order from database
        Order order = new Order(orderId, "CUST-123", 299.99);
        
        // Transform Order to OrderDTO for transfer
        return new OrderDTO(
            order.getOrderId(),
            order.getCustomerId(), 
            order.getTotalAmount()
        );
    }
    
    public void processOrder(OrderDTO orderDTO) {
        // Process the order using DTO data
        System.out.println("Processing order: " + orderDTO.getOrderId() + 
                          " for customer: " + orderDTO.getCustomerId());
    }
}