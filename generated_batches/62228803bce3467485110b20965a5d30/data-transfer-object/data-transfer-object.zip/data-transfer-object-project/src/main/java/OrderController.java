package com.example.ordermanagement;

public class OrderController {
    
    private OrderService orderService;
    
    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }
    
    public void handleOrderRequest(String orderId) {
        // Get order data as DTO for transfer
        OrderDTO orderDTO = orderService.getOrderDetails(orderId);
        
        // Use the DTO to process the order
        orderService.processOrder(orderDTO);
        
        // Display transferred data
        System.out.println("Transferred Order Details:");
        System.out.println("Order ID: " + orderDTO.getOrderId());
        System.out.println("Customer ID: " + orderDTO.getCustomerId());
        System.out.println("Total Amount: $" + orderDTO.getTotalAmount());
    }
}