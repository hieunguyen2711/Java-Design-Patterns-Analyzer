public class OrderProcessor {
    private OrderPool orderPool;
    
    public OrderProcessor(OrderPool orderPool) {
        this.orderPool = orderPool;
    }
    
    public void processOrder(String orderId, double amount) {
        Order order = orderPool.acquireOrder(orderId, amount);
        
        System.out.println("Processing: " + order);
        
        // Simulate some processing
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        orderPool.releaseOrder(order);
    }
}