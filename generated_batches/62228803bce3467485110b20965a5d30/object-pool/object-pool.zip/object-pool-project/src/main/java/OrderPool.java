import java.util.ArrayDeque;
import java.util.Deque;

public class OrderPool {
    private static final int POOL_SIZE = 10;
    private static OrderPool instance;
    private Deque<Order> pool;
    
    private OrderPool() {
        pool = new ArrayDeque<>(POOL_SIZE);
        initializePool();
    }
    
    public static synchronized OrderPool getInstance() {
        if (instance == null) {
            instance = new OrderPool();
        }
        return instance;
    }
    
    private void initializePool() {
        for (int i = 0; i < POOL_SIZE; i++) {
            pool.push(new Order("ORDER-" + i, 0.0));
        }
    }
    
    public synchronized Order acquireOrder(String orderId, double amount) {
        Order order = pool.pollLast();
        if (order == null) {
            order = new Order(orderId, amount);
        } else {
            order = new Order(orderId, amount);
        }
        return order;
    }
    
    public synchronized void releaseOrder(Order order) {
        if (pool.size() < POOL_SIZE) {
            pool.push(order);
        }
    }
}