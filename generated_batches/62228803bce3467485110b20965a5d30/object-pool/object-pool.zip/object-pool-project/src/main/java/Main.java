public class Main {
    public static void main(String[] args) {
        OrderPool pool = OrderPool.getInstance();
        OrderProcessor processor = new OrderProcessor(pool);
        
        // Process multiple orders to demonstrate object pooling
        for (int i = 0; i < 15; i++) {
            final int orderId = i;
            new Thread(() -> processor.processOrder("ORDER-" + orderId, 100.0 + orderId)).start();
        }
    }
}