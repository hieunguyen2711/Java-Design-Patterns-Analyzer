public class OrderServiceProxy implements OrderService {
    private RealOrderService realOrderService;
    private String currentUser;

    public OrderServiceProxy(String currentUser) {
        this.currentUser = currentUser;
    }

    @Override
    public void processOrder(String orderId) {
        if (currentUser == null || currentUser.isEmpty()) {
            throw new SecurityException("User not authenticated");
        }
        
        System.out.println("Validating user permissions for: " + currentUser);
        
        if (realOrderService == null) {
            realOrderService = new RealOrderService();
        }
        
        realOrderService.processOrder(orderId);
    }
}