public class OrderManagementSystem {
    public static void main(String[] args) {
        OrderService orderService = new OrderServiceProxy("admin");
        orderService.processOrder("ORD-12345");
        
        // This would throw an exception
        // OrderService invalidService = new OrderServiceProxy("");
        // invalidService.processOrder("ORD-67890");
    }
}