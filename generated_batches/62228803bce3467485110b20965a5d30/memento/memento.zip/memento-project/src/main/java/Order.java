package ecommerce.order;

import java.util.ArrayList;
import java.util.List;

public class Order {
    private String orderId;
    private List<String> items;
    private double totalAmount;
    private OrderStatus status;
    
    public Order(String orderId) {
        this.orderId = orderId;
        this.items = new ArrayList<>();
        this.totalAmount = 0.0;
        this.status = OrderStatus.PENDING;
    }
    
    public void addItem(String item) {
        items.add(item);
        totalAmount += calculateItemPrice(item);
    }
    
    private double calculateItemPrice(String item) {
        // Simplified pricing logic
        return switch (item.toLowerCase()) {
            case "laptop" -> 999.99;
            case "mouse" -> 29.99;
            case "keyboard" -> 79.99;
            default -> 0.0;
        };
    }
    
    public Memento saveToMemento() {
        return new Memento(orderId, new ArrayList<>(items), totalAmount, status);
    }
    
    public void restoreFromMemento(Memento memento) {
        this.orderId = memento.getOrderId();
        this.items = new ArrayList<>(memento.getItems());
        this.totalAmount = memento.getTotalAmount();
        this.status = memento.getStatus();
    }
    
    public String getOrderId() {
        return orderId;
    }
    
    public List<String> getItems() {
        return new ArrayList<>(items);
    }
    
    public double getTotalAmount() {
        return totalAmount;
    }
    
    public OrderStatus getStatus() {
        return status;
    }
    
    public void setStatus(OrderStatus status) {
        this.status = status;
    }
}