package ecommerce.order;

public class OrderManager {
    private Order order;
    private OrderCaretaker caretaker;
    
    public OrderManager(Order order) {
        this.order = order;
        this.caretaker = new OrderCaretaker();
    }
    
    public void processOrder() {
        System.out.println("Processing order: " + order.getOrderId());
        order.setStatus(OrderStatus.CONFIRMED);
        saveState();
        
        order.addItem("mouse");
        order.setStatus(OrderStatus.SHIPPED);
        saveState();
        
        order.addItem("keyboard");
        order.setStatus(OrderStatus.DELIVERED);
        saveState();
    }
    
    private void saveState() {
        caretaker.addMemento(order.saveToMemento());
    }
    
    public void undoLastAction() {
        if (caretaker.getSize() > 1) {
            int lastIndex = caretaker.getSize() - 2;
            order.restoreFromMemento(caretaker.getMemento(lastIndex));
            System.out.println("Undid last action. Current status: " + order.getStatus());
        } else {
            System.out.println("No actions to undo");
        }
    }
    
    public void printCurrentState() {
        System.out.println("Order ID: " + order.getOrderId());
        System.out.println("Items: " + order.getItems());
        System.out.println("Total Amount: $" + order.getTotalAmount());
        System.out.println("Status: " + order.getStatus());
        System.out.println();
    }
}