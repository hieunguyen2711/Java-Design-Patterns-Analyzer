package ecommerce.order;

public class Main {
    public static void main(String[] args) {
        Order order = new Order("ORD-001");
        OrderManager manager = new OrderManager(order);
        
        System.out.println("=== Initial State ===");
        manager.printCurrentState();
        
        System.out.println("=== Processing Order ===");
        manager.processOrder();
        
        System.out.println("=== Final State ===");
        manager.printCurrentState();
        
        System.out.println("=== Undo Last Action ===");
        manager.undoLastAction();
        manager.printCurrentState();
    }
}