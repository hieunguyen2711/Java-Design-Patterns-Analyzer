package ecommerce.order;

import java.util.List;

public class Memento {
    private String orderId;
    private List<String> items;
    private double totalAmount;
    private OrderStatus status;
    
    public Memento(String orderId, List<String> items, double totalAmount, OrderStatus status) {
        this.orderId = orderId;
        this.items = new ArrayList<>(items);
        this.totalAmount = totalAmount;
        this.status = status;
    }
    
    public String getOrderId() {
        return orderId;
    }
    
    public List<String> getItems() {
        return new ArrayList<>(items);
    }
    
    public double getTotalAmount() {
        return totalAmount;
    }
    
    public OrderStatus getStatus() {
        return status;
    }
}