package ecommerce.order;

import java.util.ArrayList;
import java.util.List;

public class OrderCaretaker {
    private List<Memento> mementos;
    
    public OrderCaretaker() {
        this.mementos = new ArrayList<>();
    }
    
    public void addMemento(Memento memento) {
        mementos.add(memento);
    }
    
    public Memento getMemento(int index) {
        return mementos.get(index);
    }
    
    public int getSize() {
        return mementos.size();
    }
}