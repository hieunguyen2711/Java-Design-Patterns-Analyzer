public class OrderManagementSystem {
    public static void main(String[] args) {
        // Register services with the locator
        ServiceLocator.registerService("OrderService", new OrderServiceImpl());
        ServiceLocator.registerService("PaymentService", new PaymentServiceImpl());
        ServiceLocator.registerService("InventoryService", new InventoryServiceImpl());
        
        // Use services through the service locator
        OrderService orderService = ServiceLocator.getService(OrderService.class);
        PaymentService paymentService = ServiceLocator.getService(PaymentService.class);
        InventoryService inventoryService = ServiceLocator.getService(InventoryService.class);
        
        orderService.processOrder("ORD-123");
        paymentService.processPayment("PAY-456");
        inventoryService.checkInventory("PROD-789");
    }
}