import java.util.HashMap;
import java.util.Map;

public class ServiceLocator {
    private static Map<String, Object> services = new HashMap<>();
    
    public static void registerService(String serviceName, Object service) {
        services.put(serviceName, service);
    }
    
    @SuppressWarnings("unchecked")
    public static <T> T getService(Class<T> serviceClass) {
        for (Object service : services.values()) {
            if (serviceClass.isInstance(service)) {
                return (T) service;
            }
        }
        return null;
    }
}