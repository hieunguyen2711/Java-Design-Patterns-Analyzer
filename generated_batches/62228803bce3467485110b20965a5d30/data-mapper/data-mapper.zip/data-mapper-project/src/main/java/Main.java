package com.example.order;

import java.sql.SQLException;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        try {
            OrderService service = new OrderService();
            
            // Create a new order
            Order newOrder = new Order(1, "John Doe", 299.99);
            service.createOrder(newOrder);
            
            // Retrieve all orders
            List<Order> orders = service.getAllOrders();
            for (Order order : orders) {
                System.out.println("Order ID: " + order.getOrderId() + 
                                 ", Customer: " + order.getCustomerName() +
                                 ", Amount: $" + order.getTotalAmount());
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}