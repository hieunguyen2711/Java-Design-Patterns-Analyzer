package com.example.order;

import java.sql.SQLException;
import java.util.List;

public class OrderService {
    private final OrderMapper orderMapper;
    
    public OrderService() {
        this.orderMapper = new OrderMapper();
    }
    
    public List<Order> getAllOrders() throws SQLException {
        return orderMapper.findAll();
    }
    
    public Order getOrderById(int orderId) throws SQLException {
        return orderMapper.findById(orderId);
    }
    
    public void createOrder(Order order) throws SQLException {
        orderMapper.save(order);
    }
    
    public void updateOrder(Order order) throws SQLException {
        orderMapper.update(order);
    }
    
    public void deleteOrder(int orderId) throws SQLException {
        orderMapper.delete(orderId);
    }
}