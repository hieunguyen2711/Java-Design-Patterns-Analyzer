package com.example.order;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OrderMapper {
    
    public List<Order> findAll() throws SQLException {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT order_id, customer_name, total_amount FROM orders";
        
        try (Connection conn = DriverManager.getConnection(
                "jdbc:sqlite:orders.db");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Order order = new Order(
                    rs.getInt("order_id"),
                    rs.getString("customer_name"),
                    rs.getDouble("total_amount")
                );
                orders.add(order);
            }
        }
        return orders;
    }
    
    public Order findById(int orderId) throws SQLException {
        String sql = "SELECT order_id, customer_name, total_amount FROM orders WHERE order_id = ?";
        
        try (Connection conn = DriverManager.getConnection(
                "jdbc:sqlite:orders.db");
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, orderId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return new Order(
                    rs.getInt("order_id"),
                    rs.getString("customer_name"),
                    rs.getDouble("total_amount")
                );
            }
        }
        return null;
    }
    
    public void save(Order order) throws SQLException {
        String sql = "INSERT INTO orders (order_id, customer_name, total_amount) VALUES (?, ?, ?)";
        
        try (Connection conn = DriverManager.getConnection(
                "jdbc:sqlite:orders.db");
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, order.getOrderId());
            pstmt.setString(2, order.getCustomerName());
            pstmt.setDouble(3, order.getTotalAmount());
            pstmt.executeUpdate();
        }
    }
    
    public void update(Order order) throws SQLException {
        String sql = "UPDATE orders SET customer_name = ?, total_amount = ? WHERE order_id = ?";
        
        try (Connection conn = DriverManager.getConnection(
                "jdbc:sqlite:orders.db");
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, order.getCustomerName());
            pstmt.setDouble(2, order.getTotalAmount());
            pstmt.setInt(3, order.getOrderId());
            pstmt.executeUpdate();
        }
    }
    
    public void delete(int orderId) throws SQLException {
        String sql = "DELETE FROM orders WHERE order_id = ?";
        
        try (Connection conn = DriverManager.getConnection(
                "jdbc:sqlite:orders.db");
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, orderId);
            pstmt.executeUpdate();
        }
    }
}