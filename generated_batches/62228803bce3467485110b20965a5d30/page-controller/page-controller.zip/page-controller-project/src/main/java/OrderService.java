package ecommerce.service;

import ecommerce.model.Order;
import java.util.HashMap;
import java.util.Map;

public class OrderService {
    private final Map<String, Order> orders = new HashMap<>();
    
    public Order createOrder(String orderId, String customerId) {
        return new Order(orderId, customerId);
    }
    
    public void saveOrder(Order order) {
        orders.put(order.getId(), order);
        System.out.println("Order saved: " + order.getId());
    }
}