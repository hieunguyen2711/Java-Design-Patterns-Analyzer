package ecommerce.model;

public class Order {
    private final String id;
    private final String customerId;
    
    public Order(String id, String customerId) {
        this.id = id;
        this.customerId = customerId;
    }
    
    public String getId() {
        return id;
    }
    
    public String getCustomerId() {
        return customerId;
    }
}