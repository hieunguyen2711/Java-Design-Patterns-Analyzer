package ecommerce.controller;

import ecommerce.model.Order;
import ecommerce.service.OrderService;

public class OrderController {
    private final OrderService orderService;
    
    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }
    
    public void processOrder(String orderId, String customerId) {
        System.out.println("Processing order: " + orderId);
        Order order = orderService.createOrder(orderId, customerId);
        orderService.saveOrder(order);
        System.out.println("Order processed successfully");
    }
}