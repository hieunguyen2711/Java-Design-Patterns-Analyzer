package ecommerce;

import ecommerce.controller.OrderController;
import ecommerce.service.OrderService;

public class Main {
    public static void main(String[] args) {
        OrderService orderService = new OrderService();
        OrderController controller = new OrderController(orderService);
        
        controller.processOrder("ORD001", "CUST123");
    }
}