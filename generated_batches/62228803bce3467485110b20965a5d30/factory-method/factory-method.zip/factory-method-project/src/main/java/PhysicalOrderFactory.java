public class PhysicalOrderFactory extends OrderFactory {
    @Override
    public Order createOrder(String orderId, double amount) {
        return new PhysicalOrder(orderId, amount, "Default Address");
    }
}