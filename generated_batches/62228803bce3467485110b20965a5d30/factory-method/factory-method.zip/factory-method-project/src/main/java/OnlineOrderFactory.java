public class OnlineOrderFactory extends OrderFactory {
    @Override
    public Order createOrder(String orderId, double amount) {
        return new OnlineOrder(orderId, amount, "default@example.com");
    }
}