public abstract class OrderFactory {
    public abstract Order createOrder(String orderId, double amount);
    
    public Order createOnlineOrder(String orderId, double amount, String customerEmail) {
        Order order = createOrder(orderId, amount);
        // Additional online-specific processing could go here
        return order;
    }
}