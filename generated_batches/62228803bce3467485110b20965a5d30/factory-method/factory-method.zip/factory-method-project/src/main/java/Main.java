public class Main {
    public static void main(String[] args) {
        // Using Online Order Factory
        OrderProcessor onlineProcessor = new OrderProcessor(new OnlineOrderFactory());
        onlineProcessor.processOrder("ON123", 99.99);
        
        // Using Physical Order Factory
        OrderProcessor physicalProcessor = new OrderProcessor(new PhysicalOrderFactory());
        physicalProcessor.processOrder("PH456", 149.50);
    }
}