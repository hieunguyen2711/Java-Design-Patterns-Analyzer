public class OrderProcessor {
    private OrderFactory factory;
    
    public OrderProcessor(OrderFactory factory) {
        this.factory = factory;
    }
    
    public void processOrder(String orderId, double amount) {
        Order order = factory.createOrder(orderId, amount);
        order.processOrder();
    }
}