package com.ecommerce.order;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PaymentProcessor {
    private ExecutorService executor = Executors.newFixedThreadPool(2);
    
    public CompletableFuture<Boolean> processPayment(Order order) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                // Simulate payment processing delay
                Thread.sleep(1000);
                System.out.println("Processing payment for order: " + order.getOrderId());
                return true;
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return false;
            }
        }, executor);
    }
    
    public void shutdown() {
        executor.shutdown();
    }
}