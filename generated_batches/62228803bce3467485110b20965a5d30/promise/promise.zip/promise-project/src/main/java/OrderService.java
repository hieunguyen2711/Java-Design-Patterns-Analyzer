package com.ecommerce.order;

import java.util.concurrent.CompletableFuture;

public class OrderService {
    private PaymentProcessor paymentProcessor;
    
    public OrderService(PaymentProcessor paymentProcessor) {
        this.paymentProcessor = paymentProcessor;
    }
    
    public CompletableFuture<Order> createOrder(String orderId, double amount) {
        Order order = new Order(orderId, amount);
        
        return paymentProcessor.processPayment(order)
                .thenApply(success -> {
                    if (success) {
                        order.setStatus(OrderStatus.PROCESSING);
                        System.out.println("Order " + orderId + " is now processing");
                    } else {
                        order.setStatus(OrderStatus.CANCELLED);
                        System.out.println("Order " + orderId + " was cancelled due to payment failure");
                    }
                    return order;
                })
                .exceptionally(throwable -> {
                    order.setStatus(OrderStatus.CANCELLED);
                    System.err.println("Error processing order: " + throwable.getMessage());
                    return order;
                });
    }
}