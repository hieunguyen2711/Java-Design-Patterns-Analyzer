package com.ecommerce.order;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class OrderManagementSystem {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        PaymentProcessor paymentProcessor = new PaymentProcessor();
        OrderService orderService = new OrderService(paymentProcessor);
        
        // Create multiple orders asynchronously
        CompletableFuture<Order> order1Future = orderService.createOrder("ORD-001", 299.99);
        CompletableFuture<Order> order2Future = orderService.createOrder("ORD-002", 149.50);
        
        // Wait for all orders to complete
        Order order1 = order1Future.get();
        Order order2 = order2Future.get();
        
        System.out.println("Final status of order " + order1.getOrderId() + ": " + order1.getStatus());
        System.out.println("Final status of order " + order2.getOrderId() + ": " + order2.getStatus());
        
        paymentProcessor.shutdown();
    }
}