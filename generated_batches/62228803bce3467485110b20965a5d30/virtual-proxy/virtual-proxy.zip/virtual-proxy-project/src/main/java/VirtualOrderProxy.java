public class VirtualOrderProxy implements Order {
    private String orderId;
    private double totalAmount;
    private RealOrder realOrder;
    
    public VirtualOrderProxy(String orderId, double totalAmount) {
        this.orderId = orderId;
        this.totalAmount = totalAmount;
    }
    
    @Override
    public void processOrder() {
        if (realOrder == null) {
            System.out.println("Creating virtual proxy for order: " + orderId);
            realOrder = new RealOrder(orderId, totalAmount);
        }
        realOrder.processOrder();
    }
    
    @Override
    public double getTotalAmount() {
        if (realOrder == null) {
            return totalAmount;
        }
        return realOrder.getTotalAmount();
    }
}