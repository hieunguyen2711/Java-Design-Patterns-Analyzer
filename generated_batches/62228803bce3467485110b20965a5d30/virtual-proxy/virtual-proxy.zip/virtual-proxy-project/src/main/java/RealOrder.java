public class RealOrder implements Order {
    private String orderId;
    private double totalAmount;
    
    public RealOrder(String orderId, double totalAmount) {
        this.orderId = orderId;
        this.totalAmount = totalAmount;
        System.out.println("Real order created for ID: " + orderId);
    }
    
    @Override
    public void processOrder() {
        System.out.println("Processing real order: " + orderId);
        // Simulate some heavy processing
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        System.out.println("Real order processed successfully");
    }
    
    @Override
    public double getTotalAmount() {
        return totalAmount;
    }
}