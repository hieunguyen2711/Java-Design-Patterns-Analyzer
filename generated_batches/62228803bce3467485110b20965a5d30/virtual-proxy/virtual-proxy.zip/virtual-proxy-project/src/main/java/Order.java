public interface Order {
    void processOrder();
    double getTotalAmount();
}