public class OrderService {
    public static void main(String[] args) {
        // Create proxy instead of real order object
        Order order = new VirtualOrderProxy("ORD-123", 99.99);
        
        System.out.println("Order total amount: " + order.getTotalAmount());
        
        System.out.println("Processing order...");
        order.processOrder();
        
        System.out.println("Processing same order again...");
        order.processOrder(); // This will use the already created real object
    }
}