package ecommerce.order;

import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonOrderConverter implements OrderConverter {
    private ObjectMapper objectMapper;
    
    public JsonOrderConverter() {
        this.objectMapper = new ObjectMapper();
    }
    
    @Override
    public Order convert(String orderData) {
        try {
            return objectMapper.readValue(orderData, Order.class);
        } catch (Exception e) {
            throw new RuntimeException("Failed to convert JSON to Order", e);
        }
    }
}