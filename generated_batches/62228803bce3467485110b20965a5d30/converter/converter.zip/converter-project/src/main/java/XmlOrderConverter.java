package ecommerce.order;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import java.io.StringReader;

public class XmlOrderConverter implements OrderConverter {
    private JAXBContext jaxbContext;
    
    public XmlOrderConverter() throws Exception {
        this.jaxbContext = JAXBContext.newInstance(Order.class);
    }
    
    @Override
    public Order convert(String orderData) {
        try {
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            return (Order) unmarshaller.unmarshal(new StringReader(orderData));
        } catch (Exception e) {
            throw new RuntimeException("Failed to convert XML to Order", e);
        }
    }
}