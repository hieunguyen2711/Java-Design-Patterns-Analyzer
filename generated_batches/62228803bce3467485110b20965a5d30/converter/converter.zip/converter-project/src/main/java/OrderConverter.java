package ecommerce.order;

public interface OrderConverter {
    Order convert(String orderData);
}