package ecommerce.order;

public class OrderService {
    private OrderConverter converter;
    
    public OrderService(OrderConverter converter) {
        this.converter = converter;
    }
    
    public Order processOrder(String orderData, String format) {
        return converter.convert(orderData);
    }
}