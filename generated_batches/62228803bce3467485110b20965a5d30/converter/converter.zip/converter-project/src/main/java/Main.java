package ecommerce.order;

public class Main {
    public static void main(String[] args) {
        try {
            // Simulate JSON order processing
            String jsonOrder = "{\"orderId\":\"ORD-001\",\"amount\":299.99}";
            OrderService service = new OrderService(new JsonOrderConverter());
            Order order = service.processOrder(jsonOrder, "json");
            
            System.out.println("Processed Order ID: " + order.getOrderId() + 
                             ", Amount: $" + order.getAmount());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}