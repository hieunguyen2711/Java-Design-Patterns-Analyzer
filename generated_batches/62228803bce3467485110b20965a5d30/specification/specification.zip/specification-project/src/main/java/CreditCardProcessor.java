package ecommerce.order;

public class CreditCardProcessor implements PaymentProcessor {
    @Override
    public void processPayment(Order order) {
        System.out.println("Processing credit card payment for order " + 
                          order.getOrderId() + " amount: $" + order.getAmount());
    }
}