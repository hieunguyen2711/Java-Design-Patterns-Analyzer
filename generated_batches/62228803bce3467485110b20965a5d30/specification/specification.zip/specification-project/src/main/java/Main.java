package ecommerce.order;

public class Main {
    public static void main(String[] args) {
        Order order1 = new Order("ORD001", 299.99);
        Order order2 = new Order("ORD002", 149.50);
        
        OrderService creditCardService = new OrderService(new CreditCardProcessor());
        OrderService paypalService = new OrderService(new PayPalProcessor());
        
        creditCardService.executeOrder(order1);
        paypalService.executeOrder(order2);
    }
}