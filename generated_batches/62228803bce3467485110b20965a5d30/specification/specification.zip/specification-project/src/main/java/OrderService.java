package ecommerce.order;

public class OrderService {
    private PaymentProcessor paymentProcessor;
    
    public OrderService(PaymentProcessor paymentProcessor) {
        this.paymentProcessor = paymentProcessor;
    }
    
    public void executeOrder(Order order) {
        System.out.println("Executing order: " + order.getOrderId());
        paymentProcessor.processPayment(order);
    }
}