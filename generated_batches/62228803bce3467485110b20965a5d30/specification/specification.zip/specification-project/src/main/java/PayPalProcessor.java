package ecommerce.order;

public class PayPalProcessor implements PaymentProcessor {
    @Override
    public void processPayment(Order order) {
        System.out.println("Processing PayPal payment for order " + 
                          order.getOrderId() + " amount: $" + order.getAmount());
    }
}