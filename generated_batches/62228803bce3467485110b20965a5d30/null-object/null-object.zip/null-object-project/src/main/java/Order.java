package ecommerce.order;

public class Order {
    private String orderId;
    private Customer customer;
    private double totalAmount;
    
    public Order(String orderId, Customer customer, double totalAmount) {
        this.orderId = orderId;
        this.customer = customer;
        this.totalAmount = totalAmount;
    }
    
    public String getOrderId() {
        return orderId;
    }
    
    public Customer getCustomer() {
        return customer;
    }
    
    public double getTotalAmount() {
        return totalAmount;
    }
}