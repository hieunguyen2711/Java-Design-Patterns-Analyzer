package ecommerce.order;

public class NullCustomer extends Customer {
    private static final NullCustomer INSTANCE = new NullCustomer();
    
    private NullCustomer() {
        super("NULL", "Unknown Customer", "unknown@ecommerce.com");
    }
    
    public static NullCustomer getInstance() {
        return INSTANCE;
    }
    
    @Override
    public String getName() {
        return "Unknown Customer";
    }
    
    @Override
    public String getEmail() {
        return "unknown@ecommerce.com";
    }
}