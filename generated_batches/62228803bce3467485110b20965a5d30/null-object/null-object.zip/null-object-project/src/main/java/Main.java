package ecommerce.order;

public class Main {
    public static void main(String[] args) {
        OrderService orderService = new OrderService();
        
        // Create order with valid customer
        Order order1 = orderService.createOrder("ORD001", "CUST001", 299.99);
        System.out.println("Order for: " + order1.getCustomer().getName());
        
        // Create order with invalid customer (will use null object)
        Order order2 = orderService.createOrder("ORD002", "INVALID", 149.99);
        System.out.println("Order for: " + order2.getCustomer().getName());
    }
}