package ecommerce.order;

public class OrderService {
    
    public Order createOrder(String orderId, String customerId, double amount) {
        Customer customer = findCustomer(customerId);
        
        // Null object pattern - if customer is not found, return null customer instead of null
        if (customer == null) {
            customer = NullCustomer.getInstance();
        }
        
        return new Order(orderId, customer, amount);
    }
    
    private Customer findCustomer(String customerId) {
        // Simulate database lookup
        if ("CUST001".equals(customerId)) {
            return new Customer("CUST001", "John Doe", "john@example.com");
        }
        // Return null to demonstrate null object pattern
        return null;
    }
}