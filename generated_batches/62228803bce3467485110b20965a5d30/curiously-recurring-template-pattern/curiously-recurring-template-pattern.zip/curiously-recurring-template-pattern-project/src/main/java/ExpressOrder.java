package com.ecommerce.order;

public class ExpressOrder extends Order<ExpressOrder> {
    private double tax;
    private double discount;
    private double expressFee;
    
    public ExpressOrder(String orderId, double totalAmount) {
        super(orderId, totalAmount);
    }
    
    @Override
    public ExpressOrder withTax(double tax) {
        this.tax = tax;
        return this;
    }
    
    @Override
    public ExpressOrder withDiscount(double discount) {
        this.discount = discount;
        return this;
    }
    
    public ExpressOrder withExpressFee(double expressFee) {
        this.expressFee = expressFee;
        return this;
    }
    
    public double calculateFinalAmount() {
        return totalAmount + (totalAmount * tax / 100) - discount + expressFee;
    }
}