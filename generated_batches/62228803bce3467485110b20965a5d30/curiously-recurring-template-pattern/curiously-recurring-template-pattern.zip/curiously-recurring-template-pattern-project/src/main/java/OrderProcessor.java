package com.ecommerce.order;

public class OrderProcessor {
    public static void main(String[] args) {
        StandardOrder standardOrder = new StandardOrder("STD-001", 100.0)
                .withTax(8.5)
                .withDiscount(10.0);
        
        ExpressOrder expressOrder = new ExpressOrder("EXP-001", 150.0)
                .withTax(8.5)
                .withDiscount(15.0)
                .withExpressFee(25.0);
        
        System.out.println("Standard Order Final Amount: " + standardOrder.calculateFinalAmount());
        System.out.println("Express Order Final Amount: " + expressOrder.calculateFinalAmount());
    }
}