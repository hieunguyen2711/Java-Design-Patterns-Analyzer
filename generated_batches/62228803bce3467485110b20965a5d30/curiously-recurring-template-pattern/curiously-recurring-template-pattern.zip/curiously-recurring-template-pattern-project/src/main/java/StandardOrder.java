package com.ecommerce.order;

public class StandardOrder extends Order<StandardOrder> {
    private double tax;
    private double discount;
    
    public StandardOrder(String orderId, double totalAmount) {
        super(orderId, totalAmount);
    }
    
    @Override
    public StandardOrder withTax(double tax) {
        this.tax = tax;
        return this;
    }
    
    @Override
    public StandardOrder withDiscount(double discount) {
        this.discount = discount;
        return this;
    }
    
    public double calculateFinalAmount() {
        return totalAmount + (totalAmount * tax / 100) - discount;
    }
}