package com.ecommerce.order;

public abstract class Order<T extends Order<T>> {
    protected String orderId;
    protected double totalAmount;
    
    public Order(String orderId, double totalAmount) {
        this.orderId = orderId;
        this.totalAmount = totalAmount;
    }
    
    public abstract T withTax(double tax);
    public abstract T withDiscount(double discount);
    
    public String getOrderId() {
        return orderId;
    }
    
    public double getTotalAmount() {
        return totalAmount;
    }
}