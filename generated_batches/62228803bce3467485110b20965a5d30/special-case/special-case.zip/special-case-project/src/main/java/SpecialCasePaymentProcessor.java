package ecommerce.order;

public class SpecialCasePaymentProcessor implements PaymentProcessor {
    
    @Override
    public boolean processPayment(Order order) {
        if (order.getAmount() > 10000) {
            System.out.println("Special case processing for large order " + order.getOrderId());
            return true;
        }
        return false;
    }
}