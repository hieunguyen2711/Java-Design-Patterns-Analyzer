package ecommerce.order;

public class OrderService {
    
    public void processOrder(Order order) {
        PaymentProcessor processor = PaymentProcessorFactory.createPaymentProcessor(order);
        if (processor.processPayment(order)) {
            order.setStatus(OrderStatus.PROCESSING);
            System.out.println("Order " + order.getOrderId() + " processed successfully");
        } else {
            order.setStatus(OrderStatus.CANCELLED);
            System.out.println("Order " + order.getOrderId() + " cancelled due to payment failure");
        }
    }
}