package ecommerce.order;

public class Main {
    public static void main(String[] args) {
        OrderService service = new OrderService();
        
        // Regular order
        Order regularOrder = new Order("ORD001", 250.0);
        service.processOrder(regularOrder);
        
        // Large order - special case
        Order largeOrder = new Order("ORD002", 15000.0);
        service.processOrder(largeOrder);
        
        // Medium order
        Order mediumOrder = new Order("ORD003", 7500.0);
        service.processOrder(mediumOrder);
    }
}