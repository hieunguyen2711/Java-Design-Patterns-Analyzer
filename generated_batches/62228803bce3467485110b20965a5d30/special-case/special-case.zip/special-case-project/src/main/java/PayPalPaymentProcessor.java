package ecommerce.order;

public class PayPalPaymentProcessor implements PaymentProcessor {
    @Override
    public boolean processPayment(Order order) {
        System.out.println("Processing PayPal payment for order " + order.getOrderId());
        return true;
    }
}