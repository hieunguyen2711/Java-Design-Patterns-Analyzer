package ecommerce.order;

public interface PaymentProcessor {
    boolean processPayment(Order order);
}