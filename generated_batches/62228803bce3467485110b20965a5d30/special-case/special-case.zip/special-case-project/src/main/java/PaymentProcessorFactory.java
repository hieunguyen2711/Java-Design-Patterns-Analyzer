package ecommerce.order;

public class PaymentProcessorFactory {
    
    public static PaymentProcessor createPaymentProcessor(Order order) {
        if (order.getAmount() > 10000) {
            return new SpecialCasePaymentProcessor();
        } else if (order.getAmount() > 5000) {
            return new PayPalPaymentProcessor();
        } else {
            return new CreditCardPaymentProcessor();
        }
    }
}