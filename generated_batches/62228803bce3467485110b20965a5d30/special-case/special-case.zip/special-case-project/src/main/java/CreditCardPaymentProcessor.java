package ecommerce.order;

public class CreditCardPaymentProcessor implements PaymentProcessor {
    @Override
    public boolean processPayment(Order order) {
        System.out.println("Processing credit card payment for order " + order.getOrderId());
        return true;
    }
}