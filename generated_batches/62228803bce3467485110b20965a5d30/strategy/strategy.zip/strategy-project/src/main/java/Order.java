public class Order {
    private double totalAmount;
    private PaymentStrategy paymentStrategy;
    
    public Order(double totalAmount) {
        this.totalAmount = totalAmount;
    }
    
    public void setPaymentStrategy(PaymentStrategy paymentStrategy) {
        this.paymentStrategy = paymentStrategy;
    }
    
    public void processOrder() {
        if (paymentStrategy != null) {
            paymentStrategy.pay(totalAmount);
        } else {
            System.out.println("No payment method selected");
        }
    }
}