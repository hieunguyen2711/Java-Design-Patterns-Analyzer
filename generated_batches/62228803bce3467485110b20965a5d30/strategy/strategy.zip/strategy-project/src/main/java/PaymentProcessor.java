public class PaymentProcessor {
    public static void main(String[] args) {
        Order order1 = new Order(100.0);
        Order order2 = new Order(250.0);
        
        // Using Credit Card payment
        order1.setPaymentStrategy(new CreditCardPayment("1234-5678-9012-3456", "John Doe"));
        order1.processOrder();
        
        // Using PayPal payment
        order2.setPaymentStrategy(new PayPalPayment("john.doe@example.com"));
        order2.processOrder();
    }
}