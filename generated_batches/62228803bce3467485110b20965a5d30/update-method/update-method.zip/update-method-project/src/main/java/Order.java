package ecommerce.order;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Order {
    private String orderId;
    private List<OrderItem> items;
    private BigDecimal totalAmount;
    private OrderStatus status;
    
    public Order(String orderId) {
        this.orderId = orderId;
        this.items = new ArrayList<>();
        this.totalAmount = BigDecimal.ZERO;
        this.status = OrderStatus.PENDING;
    }
    
    public void addItem(OrderItem item) {
        items.add(item);
        updateTotal();
    }
    
    public void removeItem(OrderItem item) {
        items.remove(item);
        updateTotal();
    }
    
    private void updateTotal() {
        totalAmount = items.stream()
                .map(item -> item.getPrice().multiply(BigDecimal.valueOf(item.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    
    public void updateStatus(OrderStatus newStatus) {
        this.status = newStatus;
    }
    
    // Getters and setters
    public String getOrderId() { return orderId; }
    public List<OrderItem> getItems() { return items; }
    public BigDecimal getTotalAmount() { return totalAmount; }
    public OrderStatus getStatus() { return status; }
}