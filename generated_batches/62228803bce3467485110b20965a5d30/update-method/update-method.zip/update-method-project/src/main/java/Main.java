package ecommerce.order;

import java.math.BigDecimal;

public class Main {
    public static void main(String[] args) {
        OrderService service = new OrderService();
        
        // Create an order
        service.createOrder("ORD-001");
        
        // Add items to the order
        service.addItemToOrder("ORD-001", "PROD-001", "Laptop", BigDecimal.valueOf(999.99), 1);
        service.addItemToOrder("ORD-001", "PROD-002", "Mouse", BigDecimal.valueOf(29.99), 2);
        
        // Update order status
        service.updateOrderStatus("ORD-001", OrderStatus.CONFIRMED);
        
        // Remove an item and update total automatically
        service.removeItemFromOrder("ORD-001", "PROD-002");
        
        System.out.println("Order processed successfully!");
    }
}