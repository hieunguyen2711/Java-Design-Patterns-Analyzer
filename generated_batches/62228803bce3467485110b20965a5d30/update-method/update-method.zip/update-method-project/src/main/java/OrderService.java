package ecommerce.order;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public class OrderService {
    private Map<String, Order> orders;
    
    public OrderService() {
        this.orders = new HashMap<>();
    }
    
    public void createOrder(String orderId) {
        Order order = new Order(orderId);
        orders.put(orderId, order);
    }
    
    public void addItemToOrder(String orderId, String productId, String productName, 
                              BigDecimal price, int quantity) {
        Order order = orders.get(orderId);
        if (order != null) {
            OrderItem item = new OrderItem(productId, productName, price, quantity);
            order.addItem(item);
        }
    }
    
    public void updateOrderStatus(String orderId, OrderStatus status) {
        Order order = orders.get(orderId);
        if (order != null) {
            order.updateStatus(status);
        }
    }
    
    public void removeItemFromOrder(String orderId, String productId) {
        Order order = orders.get(orderId);
        if (order != null) {
            order.getItems().removeIf(item -> item.getProductId().equals(productId));
            order.updateTotal(); // Update total after removal
        }
    }
}