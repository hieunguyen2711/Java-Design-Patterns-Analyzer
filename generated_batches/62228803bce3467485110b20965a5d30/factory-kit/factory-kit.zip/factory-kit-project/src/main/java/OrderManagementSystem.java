public class OrderManagementSystem {
    
    public static void main(String[] args) {
        // Using the factory to create different types of orders
        Order standardOrder = OrderFactory.createOrder("standard", "STD001", 299.99);
        Order expressOrder = OrderFactory.createOrder("express", "EXP001", 499.99);
        
        // Processing orders
        standardOrder.processOrder();
        expressOrder.processOrder();
    }
}