public class ExpressOrder extends Order {
    
    public ExpressOrder(String orderId, double amount) {
        super(orderId, amount);
    }
    
    @Override
    public void processOrder() {
        System.out.println("Processing express order " + orderId + " for $" + amount);
    }
}