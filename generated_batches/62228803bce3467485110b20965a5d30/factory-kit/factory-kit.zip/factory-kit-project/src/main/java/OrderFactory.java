public class OrderFactory {
    
    public static Order createOrder(String type, String orderId, double amount) {
        switch (type.toLowerCase()) {
            case "standard":
                return new StandardOrder(orderId, amount);
            case "express":
                return new ExpressOrder(orderId, amount);
            default:
                throw new IllegalArgumentException("Unknown order type: " + type);
        }
    }
}