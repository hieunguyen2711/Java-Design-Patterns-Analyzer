public class StandardOrder extends Order {
    
    public StandardOrder(String orderId, double amount) {
        super(orderId, amount);
    }
    
    @Override
    public void processOrder() {
        System.out.println("Processing standard order " + orderId + " for $" + amount);
    }
}