package ecommerce.order;

public class OrderBuilder {
    private String customerId;
    private String productId;
    private int quantity = 1;
    private double price = 0.0;
    private boolean shipped = false;
    
    public static OrderBuilder createOrder(String customerId, String productId) {
        return new OrderBuilder(customerId, productId);
    }
    
    private OrderBuilder(String customerId, String productId) {
        this.customerId = customerId;
        this.productId = productId;
    }
    
    public OrderBuilder withQuantity(int quantity) {
        this.quantity = quantity;
        return this;
    }
    
    public OrderBuilder withPrice(double price) {
        this.price = price;
        return this;
    }
    
    public OrderBuilder shipped() {
        this.shipped = true;
        return this;
    }
    
    public Order build() {
        Order order = new Order(customerId, productId);
        order.setQuantity(quantity);
        order.setPrice(price);
        if (shipped) {
            order.ship();
        }
        return order;
    }
}