package ecommerce.order;

public class OrderService {
    
    public void processOrder(Order order) {
        System.out.println("Processing order for customer " + 
                          order.getCustomerId() + " with product " + 
                          order.getProductId());
        
        if (order.isShipped()) {
            System.out.println("Order has been shipped");
        }
    }
}