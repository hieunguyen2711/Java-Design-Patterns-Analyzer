package ecommerce.order;

public class OrderManagementSystem {
    
    public static void main(String[] args) {
        // Using fluent interface to build an order
        Order order1 = new OrderBuilder()
            .createOrder("CUST001", "PROD123")
            .withQuantity(2)
            .withPrice(29.99)
            .shipped()
            .build();
        
        // Another example with different configuration
        Order order2 = new OrderBuilder()
            .createOrder("CUST002", "PROD456")
            .withQuantity(1)
            .withPrice(19.99)
            .build();
        
        OrderService service = new OrderService();
        service.processOrder(order1);
        service.processOrder(order2);
    }
}