package ecommerce.order;

public class Order {
    private String customerId;
    private String productId;
    private int quantity;
    private double price;
    private boolean shipped;
    
    public Order(String customerId, String productId) {
        this.customerId = customerId;
        this.productId = productId;
    }
    
    public Order setQuantity(int quantity) {
        this.quantity = quantity;
        return this;
    }
    
    public Order setPrice(double price) {
        this.price = price;
        return this;
    }
    
    public Order ship() {
        this.shipped = true;
        return this;
    }
    
    // Getters for testing
    public String getCustomerId() { return customerId; }
    public String getProductId() { return productId; }
    public int getQuantity() { return quantity; }
    public double getPrice() { return price; }
    public boolean isShipped() { return shipped; }
}