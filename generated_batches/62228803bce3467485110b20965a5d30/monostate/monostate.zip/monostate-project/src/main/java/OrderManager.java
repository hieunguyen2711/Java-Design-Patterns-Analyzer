package ecommerce.order;

public class OrderManager {
    private static OrderManager instance;
    
    // Private constructor to prevent instantiation
    private OrderManager() {}
    
    // Static method to get the single instance
    public static synchronized OrderManager getInstance() {
        if (instance == null) {
            instance = new OrderManager();
        }
        return instance;
    }
    
    // Monostate pattern: all instances share the same state
    private int totalOrdersProcessed = 0;
    private double totalRevenue = 0.0;
    
    public void processOrder(double amount) {
        totalOrdersProcessed++;
        totalRevenue += amount;
        System.out.println("Order processed. Total orders: " + totalOrdersProcessed + 
                          ", Total revenue: $" + totalRevenue);
    }
    
    // Getters for shared state
    public int getTotalOrdersProcessed() {
        return totalOrdersProcessed;
    }
    
    public double getTotalRevenue() {
        return totalRevenue;
    }
}