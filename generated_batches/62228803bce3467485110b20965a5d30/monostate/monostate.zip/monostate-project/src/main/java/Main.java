package ecommerce.order;

public class Main {
    public static void main(String[] args) {
        // Create multiple services that share the same state
        OrderService service1 = new OrderService();
        OrderService service2 = new OrderService();
        
        // Process orders through different services
        service1.createOrder(100.0);
        service1.createOrder(250.0);
        service2.createOrder(75.50);
        
        // Display statistics from both services (they share the same state)
        System.out.println("\n--- Service 1 Statistics ---");
        service1.displayStatistics();
        
        System.out.println("\n--- Service 2 Statistics ---");
        service2.displayStatistics();
    }
}