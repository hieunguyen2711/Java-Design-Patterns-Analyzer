package ecommerce.order;

public class OrderService {
    private OrderManager orderManager = OrderManager.getInstance();
    
    public void createOrder(double amount) {
        System.out.println("Creating order for $" + amount);
        orderManager.processOrder(amount);
    }
    
    public void displayStatistics() {
        System.out.println("Total orders processed: " + orderManager.getTotalOrdersProcessed());
        System.out.println("Total revenue: $" + orderManager.getTotalRevenue());
    }
}