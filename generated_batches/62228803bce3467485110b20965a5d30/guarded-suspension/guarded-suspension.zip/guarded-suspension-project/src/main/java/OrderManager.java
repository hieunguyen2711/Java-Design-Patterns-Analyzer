package com.ecommerce.order;

public class OrderManager {
    private final OrderProcessor processor = new OrderProcessor();
    
    public void handleOrder(String orderId, double amount) throws InterruptedException {
        Order order = new Order(orderId, amount);
        processor.submitOrder(order);
        
        // Process the order immediately if available
        Order processedOrder = processor.processNextOrder();
        System.out.println("Processed order: " + processedOrder.getOrderId() 
                          + " for $" + processedOrder.getAmount());
    }
}