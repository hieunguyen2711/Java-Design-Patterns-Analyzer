package com.ecommerce.order;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        OrderManager manager = new OrderManager();
        
        // Submit orders
        manager.handleOrder("ORD-001", 29.99);
        manager.handleOrder("ORD-002", 45.50);
        manager.handleOrder("ORD-003", 12.75);
    }
}