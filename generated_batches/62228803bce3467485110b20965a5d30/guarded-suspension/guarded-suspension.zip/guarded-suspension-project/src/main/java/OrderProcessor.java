package com.ecommerce.order;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class OrderProcessor {
    private final BlockingQueue<Order> orderQueue = new LinkedBlockingQueue<>();
    
    public void submitOrder(Order order) throws InterruptedException {
        orderQueue.put(order);
    }
    
    public Order processNextOrder() throws InterruptedException {
        // Guarded suspension - wait until there's an order to process
        while (orderQueue.isEmpty()) {
            Thread.sleep(100); // Brief pause to avoid busy waiting
        }
        return orderQueue.take();
    }
}