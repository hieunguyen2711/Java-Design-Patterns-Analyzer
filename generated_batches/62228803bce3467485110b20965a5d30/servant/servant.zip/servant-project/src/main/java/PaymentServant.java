package com.ecommerce.order;

public class PaymentServant {
    public void processPayment(Order order) {
        System.out.println("Processing payment for order " + order.getId());
        // Simulate payment processing logic
        order.setPaymentStatus("PAID");
    }
}