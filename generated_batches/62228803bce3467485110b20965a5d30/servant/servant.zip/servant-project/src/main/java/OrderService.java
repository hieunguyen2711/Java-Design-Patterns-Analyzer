package com.ecommerce.order;

public class OrderService {
    private final PaymentServant paymentServant;
    private final InventoryServant inventoryServant;
    private final ShippingServant shippingServant;

    public OrderService() {
        this.paymentServant = new PaymentServant();
        this.inventoryServant = new InventoryServant();
        this.shippingServant = new ShippingServant();
    }

    public void processOrder(Order order) {
        System.out.println("Processing order: " + order.getId());
        
        // Servant pattern in action - each servant handles specific aspects
        paymentServant.processPayment(order);
        inventoryServant.reserveInventory(order);
        shippingServant.prepareShipment(order);
        
        System.out.println("Order processed successfully!");
    }
}