package com.ecommerce.order;

public class OrderManagementSystem {
    public static void main(String[] args) {
        // Create order service with servants
        OrderService orderService = new OrderService();
        
        // Create an order and process it
        Order order = new Order("ORD-001");
        orderService.processOrder(order);
        
        System.out.println("\nFinal order status:");
        System.out.println("Payment: " + order.getPaymentStatus());
        System.out.println("Inventory: " + order.getInventoryStatus());
        System.out.println("Shipping: " + order.getShippingStatus());
    }
}