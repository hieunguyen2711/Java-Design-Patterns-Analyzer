package com.ecommerce.order;

public class InventoryServant {
    public void reserveInventory(Order order) {
        System.out.println("Reserving inventory for order " + order.getId());
        // Simulate inventory reservation logic
        order.setInventoryStatus("RESERVED");
    }
}