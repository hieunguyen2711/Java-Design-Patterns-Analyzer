package com.ecommerce.order;

public class ShippingServant {
    public void prepareShipment(Order order) {
        System.out.println("Preparing shipment for order " + order.getId());
        // Simulate shipping preparation logic
        order.setShippingStatus("PREPARED");
    }
}