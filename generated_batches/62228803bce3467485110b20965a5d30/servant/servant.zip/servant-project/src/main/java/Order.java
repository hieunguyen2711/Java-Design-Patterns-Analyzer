package com.ecommerce.order;

public class Order {
    private String id;
    private String paymentStatus;
    private String inventoryStatus;
    private String shippingStatus;

    public Order(String id) {
        this.id = id;
        this.paymentStatus = "PENDING";
        this.inventoryStatus = "PENDING";
        this.shippingStatus = "PENDING";
    }

    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getPaymentStatus() { return paymentStatus; }
    public void setPaymentStatus(String paymentStatus) { this.paymentStatus = paymentStatus; }
    
    public String getInventoryStatus() { return inventoryStatus; }
    public void setInventoryStatus(String inventoryStatus) { this.inventoryStatus = inventoryStatus; }
    
    public String getShippingStatus() { return shippingStatus; }
    public void setShippingStatus(String shippingStatus) { this.shippingStatus = shippingStatus; }
}