import java.util.ArrayList;
import java.util.List;

public class OrderDAOImpl implements OrderDAO {
    private List<Order> orders;
    
    public OrderDAOImpl() {
        this.orders = new ArrayList<>();
    }
    
    @Override
    public void save(Order order) {
        orders.add(order);
    }
    
    @Override
    public Order findById(int id) {
        for (Order order : orders) {
            if (order.getId() == id) {
                return order;
            }
        }
        return null;
    }
    
    @Override
    public List<Order> findAll() {
        return new ArrayList<>(orders);
    }
    
    @Override
    public void update(Order order) {
        for (int i = 0; i < orders.size(); i++) {
            if (orders.get(i).getId() == order.getId()) {
                orders.set(i, order);
                break;
            }
        }
    }
    
    @Override
    public void delete(int id) {
        orders.removeIf(order -> order.getId() == id);
    }
}