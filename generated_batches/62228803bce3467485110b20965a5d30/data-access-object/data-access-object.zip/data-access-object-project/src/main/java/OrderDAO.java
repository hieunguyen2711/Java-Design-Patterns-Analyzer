import java.util.List;

public interface OrderDAO {
    void save(Order order);
    Order findById(int id);
    List<Order> findAll();
    void update(Order order);
    void delete(int id);
}