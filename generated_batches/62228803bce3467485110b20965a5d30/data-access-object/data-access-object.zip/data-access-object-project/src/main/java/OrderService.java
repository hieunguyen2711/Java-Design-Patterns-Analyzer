import java.util.List;

public class OrderService {
    private OrderDAO orderDAO;
    
    public OrderService(OrderDAO orderDAO) {
        this.orderDAO = orderDAO;
    }
    
    public void createOrder(int id, String customerName, double totalAmount) {
        Order order = new Order(id, customerName, totalAmount);
        orderDAO.save(order);
    }
    
    public Order getOrderById(int id) {
        return orderDAO.findById(id);
    }
    
    public List<Order> getAllOrders() {
        return orderDAO.findAll();
    }
    
    public void updateOrder(int id, String customerName, double totalAmount) {
        Order order = new Order(id, customerName, totalAmount);
        orderDAO.update(order);
    }
    
    public void deleteOrder(int id) {
        orderDAO.delete(id);
    }
}