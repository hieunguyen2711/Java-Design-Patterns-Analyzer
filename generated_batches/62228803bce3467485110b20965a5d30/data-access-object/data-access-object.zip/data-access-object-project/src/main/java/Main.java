import java.util.List;

public class Main {
    public static void main(String[] args) {
        OrderDAO orderDAO = new OrderDAOImpl();
        OrderService orderService = new OrderService(orderDAO);
        
        // Create orders
        orderService.createOrder(1, "John Doe", 250.00);
        orderService.createOrder(2, "Jane Smith", 175.50);
        
        // Retrieve all orders
        List<Order> orders = orderService.getAllOrders();
        for (Order order : orders) {
            System.out.println("Order ID: " + order.getId() + 
                             ", Customer: " + order.getCustomerName() + 
                             ", Amount: $" + order.getTotalAmount());
        }
        
        // Update an order
        orderService.updateOrder(1, "John Doe Updated", 300.00);
        
        // Retrieve specific order
        Order foundOrder = orderService.getOrderById(1);
        if (foundOrder != null) {
            System.out.println("Found order: " + foundOrder.getCustomerName() + 
                             " - $" + foundOrder.getTotalAmount());
        }
    }
}