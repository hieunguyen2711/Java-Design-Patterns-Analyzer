public class OrderProcessor {
    public void process(Order order) {
        System.out.println("Processing order " + order.getOrderId() + 
                          " for amount $" + order.getAmount());
    }
    
    public void cancel(Order order) {
        System.out.println("Canceling order " + order.getOrderId() + 
                          " for amount $" + order.getAmount());
    }
}