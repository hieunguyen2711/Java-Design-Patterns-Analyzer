public class Main {
    public static void main(String[] args) {
        Order order1 = new Order("ORD001", 299.99);
        Order order2 = new Order("ORD002", 149.50);
        
        OrderProcessor processor = new OrderProcessor();
        OrderCommandInvoker invoker = new OrderCommandInvoker();
        
        Command processOrder1 = new ProcessOrderCommand(order1, processor);
        Command cancelOrder2 = new CancelOrderCommand(order2, processor);
        
        // Execute commands
        invoker.executeCommand(processOrder1);
        invoker.executeCommand(cancelOrder2);
        
        // Undo last command
        invoker.undoLastCommand();
    }
}