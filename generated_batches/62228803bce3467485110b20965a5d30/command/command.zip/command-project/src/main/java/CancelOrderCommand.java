public class CancelOrderCommand implements Command {
    private Order order;
    private OrderProcessor processor;
    
    public CancelOrderCommand(Order order, OrderProcessor processor) {
        this.order = order;
        this.processor = processor;
    }
    
    @Override
    public void execute() {
        processor.cancel(order);
    }
    
    @Override
    public void undo() {
        processor.process(order);
    }
}