import java.util.ArrayList;
import java.util.List;

public class OrderCommandInvoker {
    private List<Command> commandHistory;
    
    public OrderCommandInvoker() {
        this.commandHistory = new ArrayList<>();
    }
    
    public void executeCommand(Command command) {
        command.execute();
        commandHistory.add(command);
    }
    
    public void undoLastCommand() {
        if (!commandHistory.isEmpty()) {
            Command lastCommand = commandHistory.remove(commandHistory.size() - 1);
            lastCommand.undo();
        }
    }
}