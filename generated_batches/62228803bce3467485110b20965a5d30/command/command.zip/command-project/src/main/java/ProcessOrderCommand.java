public class ProcessOrderCommand implements Command {
    private Order order;
    private OrderProcessor processor;
    
    public ProcessOrderCommand(Order order, OrderProcessor processor) {
        this.order = order;
        this.processor = processor;
    }
    
    @Override
    public void execute() {
        processor.process(order);
    }
    
    @Override
    public void undo() {
        processor.cancel(order);
    }
}