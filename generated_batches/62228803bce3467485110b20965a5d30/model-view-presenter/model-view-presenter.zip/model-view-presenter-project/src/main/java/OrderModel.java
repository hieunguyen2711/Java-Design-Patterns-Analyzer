package ecommerce.order;

import java.util.HashMap;
import java.util.Map;

public class OrderModel {
    private Map<String, Order> orders;

    public OrderModel() {
        this.orders = new HashMap<>();
    }

    public void saveOrder(Order order) {
        orders.put(order.getOrderId(), order);
    }

    public Order getOrderById(String orderId) {
        return orders.get(orderId);
    }

    public void updateOrderStatus(String orderId, String status) {
        Order order = orders.get(orderId);
        if (order != null) {
            order.setStatus(status);
        }
    }
}