package ecommerce.order;

public class OrderPresenter {
    private OrderModel model;
    private OrderView view;

    public OrderPresenter(OrderModel model, OrderView view) {
        this.model = model;
        this.view = view;
    }

    public void createOrder() {
        try {
            String orderId = view.getOrderIdInput();
            double totalAmount = view.getTotalAmountInput();
            
            Order order = new Order(orderId, totalAmount);
            model.saveOrder(order);
            
            view.showSuccessMessage("Order created successfully!");
            view.displayOrderDetails(order);
        } catch (Exception e) {
            view.showErrorMessage("Error creating order: " + e.getMessage());
        }
    }

    public void loadOrder(String orderId) {
        try {
            Order order = model.getOrderById(orderId);
            if (order != null) {
                view.displayOrderDetails(order);
            } else {
                view.showErrorMessage("Order not found");
            }
        } catch (Exception e) {
            view.showErrorMessage("Error loading order: " + e.getMessage());
        }
    }

    public void updateOrderStatus(String orderId, String status) {
        try {
            model.updateOrderStatus(orderId, status);
            view.showSuccessMessage("Order status updated successfully!");
        } catch (Exception e) {
            view.showErrorMessage("Error updating order status: " + e.getMessage());
        }
    }
}