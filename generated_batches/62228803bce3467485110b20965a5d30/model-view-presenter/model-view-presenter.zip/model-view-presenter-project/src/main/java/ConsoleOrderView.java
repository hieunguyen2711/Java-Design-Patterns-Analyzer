package ecommerce.order;

import java.util.Scanner;

public class ConsoleOrderView implements OrderView {
    private Scanner scanner;

    public ConsoleOrderView() {
        this.scanner = new Scanner(System.in);
    }

    @Override
    public void displayOrderDetails(Order order) {
        System.out.println("=== ORDER DETAILS ===");
        System.out.println("Order ID: " + order.getOrderId());
        System.out.println("Total Amount: $" + order.getTotalAmount());
        System.out.println("Status: " + order.getStatus());
        System.out.println("=====================");
    }

    @Override
    public void showSuccessMessage(String message) {
        System.out.println("[SUCCESS] " + message);
    }

    @Override
    public void showErrorMessage(String message) {
        System.err.println("[ERROR] " + message);
    }

    @Override
    public String getOrderIdInput() {
        System.out.print("Enter Order ID: ");
        return scanner.nextLine();
    }

    @Override
    public double getTotalAmountInput() {
        System.out.print("Enter Total Amount: $");
        return Double.parseDouble(scanner.nextLine());
    }
}