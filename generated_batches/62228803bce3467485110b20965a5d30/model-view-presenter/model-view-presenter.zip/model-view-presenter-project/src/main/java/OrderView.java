package ecommerce.order;

public interface OrderView {
    void displayOrderDetails(Order order);
    void showSuccessMessage(String message);
    void showErrorMessage(String message);
    String getOrderIdInput();
    double getTotalAmountInput();
}