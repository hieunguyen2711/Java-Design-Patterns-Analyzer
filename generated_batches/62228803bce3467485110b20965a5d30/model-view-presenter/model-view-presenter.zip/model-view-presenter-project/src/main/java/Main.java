package ecommerce.order;

public class Main {
    public static void main(String[] args) {
        // Create components following MVP pattern
        OrderModel model = new OrderModel();
        ConsoleOrderView view = new ConsoleOrderView();
        OrderPresenter presenter = new OrderPresenter(model, view);

        // Simulate user interaction
        System.out.println("E-Commerce Order Management System");
        System.out.println("==================================");

        // Create an order
        presenter.createOrder();

        // Load and update an order
        String orderId = view.getOrderIdInput();
        presenter.loadOrder(orderId);
        presenter.updateOrderStatus(orderId, "SHIPPED");
    }
}