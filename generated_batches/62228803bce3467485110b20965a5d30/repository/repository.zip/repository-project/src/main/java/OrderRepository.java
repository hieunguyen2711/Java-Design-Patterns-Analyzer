package com.example.ordermanagement;

import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;

public interface OrderRepository {
    void save(Order order);
    Order findById(String id);
    List<Order> findByCustomerId(String customerId);
    List<Order> findAll();
    void delete(String id);
}