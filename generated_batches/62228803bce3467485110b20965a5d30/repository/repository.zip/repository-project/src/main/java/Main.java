package com.example.ordermanagement;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Create repository and service
        OrderRepository repository = new InMemoryOrderRepository();
        OrderService orderService = new OrderService(repository);
        
        // Create some orders
        orderService.createOrder("1", "customer123", 99.99);
        orderService.createOrder("2", "customer123", 149.50);
        orderService.createOrder("3", "customer456", 75.25);
        
        // Retrieve orders by customer
        List<Order> customerOrders = orderService.getOrdersByCustomer("customer123");
        System.out.println("Orders for customer123:");
        for (Order order : customerOrders) {
            System.out.println("- Order " + order.getId() + ": $" + order.getTotalAmount());
        }
        
        // Update an order status
        orderService.updateOrderStatus("1", OrderStatus.PROCESSING);
        Order retrievedOrder = orderService.getOrderById("1");
        System.out.println("Updated order 1 status: " + retrievedOrder.getStatus());
    }
}