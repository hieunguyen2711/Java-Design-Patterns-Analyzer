package com.example.ordermanagement;

import java.util.List;

public class OrderService {
    private OrderRepository orderRepository;
    
    public OrderService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }
    
    public void createOrder(String id, String customerId, double amount) {
        Order order = new Order(id, customerId, amount);
        orderRepository.save(order);
    }
    
    public Order getOrderById(String id) {
        return orderRepository.findById(id);
    }
    
    public List<Order> getOrdersByCustomer(String customerId) {
        return orderRepository.findByCustomerId(customerId);
    }
    
    public void updateOrderStatus(String orderId, OrderStatus status) {
        Order order = orderRepository.findById(orderId);
        if (order != null) {
            order.setStatus(status);
        }
    }
}