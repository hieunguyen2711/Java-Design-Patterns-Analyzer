package com.ecommerce.order;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

public class ProductAdded implements OrderEvent {
    private final UUID orderId;
    private final String productId;
    private final BigDecimal price;
    private final LocalDateTime timestamp;

    public ProductAdded(UUID orderId, String productId, BigDecimal price, LocalDateTime timestamp) {
        this.orderId = orderId;
        this.productId = productId;
        this.price = price;
        this.timestamp = timestamp;
    }

    @Override
    public UUID getOrderId() {
        return orderId;
    }

    @Override
    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public String getProductId() {
        return productId;
    }

    public BigDecimal getPrice() {
        return price;
    }
}