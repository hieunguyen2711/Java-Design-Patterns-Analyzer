package com.ecommerce.order;

import java.time.LocalDateTime;
import java.util.UUID;

public class OrderStatusUpdated implements OrderEvent {
    private final UUID orderId;
    private final OrderStatus status;
    private final LocalDateTime timestamp;

    public OrderStatusUpdated(UUID orderId, OrderStatus status, LocalDateTime timestamp) {
        this.orderId = orderId;
        this.status = status;
        this.timestamp = timestamp;
    }

    @Override
    public UUID getOrderId() {
        return orderId;
    }

    @Override
    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public OrderStatus getStatus() {
        return status;
    }
}