package com.ecommerce.order;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Order {
    private final UUID id;
    private final LocalDateTime createdAt;
    private BigDecimal totalAmount;
    private OrderStatus status;
    private List<OrderEvent> events;

    public Order(UUID id, BigDecimal totalAmount) {
        this.id = id;
        this.totalAmount = totalAmount;
        this.createdAt = LocalDateTime.now();
        this.status = OrderStatus.CREATED;
        this.events = new ArrayList<>();
        this.events.add(new OrderCreated(id, totalAmount, createdAt));
    }

    public void updateStatus(OrderStatus status) {
        this.status = status;
        events.add(new OrderStatusUpdated(id, status, LocalDateTime.now()));
    }

    public void addProduct(String productId, BigDecimal price) {
        totalAmount = totalAmount.add(price);
        events.add(new ProductAdded(id, productId, price, LocalDateTime.now()));
    }

    public UUID getId() {
        return id;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public List<OrderEvent> getEvents() {
        return new ArrayList<>(events);
    }
}