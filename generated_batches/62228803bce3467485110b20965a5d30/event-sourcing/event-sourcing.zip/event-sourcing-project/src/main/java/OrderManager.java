package com.ecommerce.order;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class OrderManager {
    private final List<Order> orders = new ArrayList<>();

    public Order createOrder(BigDecimal totalAmount) {
        UUID orderId = UUID.randomUUID();
        Order order = new Order(orderId, totalAmount);
        orders.add(order);
        return order;
    }

    public void processOrder(Order order) {
        order.updateStatus(OrderStatus.PROCESSING);
        order.addProduct("P001", new BigDecimal("29.99"));
        order.updateStatus(OrderStatus.SHIPPED);
    }

    public List<Order> getAllOrders() {
        return new ArrayList<>(orders);
    }
}