package com.ecommerce.order;

import java.time.LocalDateTime;
import java.util.UUID;

public interface OrderEvent {
    UUID getOrderId();
    LocalDateTime getTimestamp();
}