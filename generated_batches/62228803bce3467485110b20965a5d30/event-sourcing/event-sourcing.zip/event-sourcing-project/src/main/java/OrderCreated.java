package com.ecommerce.order;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

public class OrderCreated implements OrderEvent {
    private final UUID orderId;
    private final BigDecimal totalAmount;
    private final LocalDateTime timestamp;

    public OrderCreated(UUID orderId, BigDecimal totalAmount, LocalDateTime timestamp) {
        this.orderId = orderId;
        this.totalAmount = totalAmount;
        this.timestamp = timestamp;
    }

    @Override
    public UUID getOrderId() {
        return orderId;
    }

    @Override
    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }
}