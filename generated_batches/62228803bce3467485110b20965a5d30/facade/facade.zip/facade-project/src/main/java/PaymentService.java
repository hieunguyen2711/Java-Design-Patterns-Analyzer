public class PaymentService {
    public String processPayment(String customerInfo, int amount) {
        // Simulate payment processing
        System.out.println("Processing payment of $" + amount + " for " + customerInfo);
        return "txn_" + System.currentTimeMillis();
    }
}