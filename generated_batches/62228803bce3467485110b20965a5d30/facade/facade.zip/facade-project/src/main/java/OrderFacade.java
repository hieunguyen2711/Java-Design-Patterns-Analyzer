public class OrderFacade {
    private InventoryService inventoryService;
    private PaymentService paymentService;
    private ShippingService shippingService;
    
    public OrderFacade() {
        this.inventoryService = new InventoryService();
        this.paymentService = new PaymentService();
        this.shippingService = new ShippingService();
    }
    
    public void processOrder(String productId, int quantity, String customerInfo) {
        if (inventoryService.isAvailable(productId, quantity)) {
            String transactionId = paymentService.processPayment(customerInfo, quantity * 100);
            if (transactionId != null) {
                shippingService.shipProduct(productId, quantity, customerInfo);
                System.out.println("Order processed successfully!");
            } else {
                System.out.println("Payment failed. Order cancelled.");
            }
        } else {
            System.out.println("Insufficient inventory. Order cancelled.");
        }
    }
}