public class OrderManagementSystem {
    public static void main(String[] args) {
        OrderFacade orderFacade = new OrderFacade();
        
        // Process an order using the facade
        orderFacade.processOrder("P123", 2, "John Doe");
    }
}