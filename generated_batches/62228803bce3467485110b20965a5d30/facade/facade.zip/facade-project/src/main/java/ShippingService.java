public class ShippingService {
    public void shipProduct(String productId, int quantity, String customerInfo) {
        // Simulate shipping
        System.out.println("Shipping " + quantity + " of product " + productId + " to " + customerInfo);
    }
}