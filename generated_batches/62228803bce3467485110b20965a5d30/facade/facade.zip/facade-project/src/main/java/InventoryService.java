public class InventoryService {
    public boolean isAvailable(String productId, int quantity) {
        // Simulate inventory check
        System.out.println("Checking inventory for product " + productId);
        return true;
    }
}