public class Main {
    public static void main(String[] args) {
        System.out.println("Processing online order:");
        OrderService onlineService = new OrderService(new OnlineOrderFactory());
        onlineService.processOrder("ON12345", 99.99);
        
        System.out.println("\nProcessing mobile order:");
        OrderService mobileService = new OrderService(new MobileOrderFactory());
        mobileService.processOrder("MO67890", 149.50);
    }
}