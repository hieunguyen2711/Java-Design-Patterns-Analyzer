public interface ShippingService {
    void shipOrder(String orderId);
}