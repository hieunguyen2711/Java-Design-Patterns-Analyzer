public class ExpressShipping implements ShippingService {
    @Override
    public void shipOrder(String orderId) {
        System.out.println("Shipping order " + orderId + " via express shipping");
    }
}