public interface OrderFactory {
    PaymentProcessor createPaymentProcessor();
    ShippingService createShippingService();
}