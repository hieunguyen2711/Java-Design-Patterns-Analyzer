public class MobileOrderFactory implements OrderFactory {
    @Override
    public PaymentProcessor createPaymentProcessor() {
        return new PayPalProcessor();
    }
    
    @Override
    public ShippingService createShippingService() {
        return new ExpressShipping();
    }
}