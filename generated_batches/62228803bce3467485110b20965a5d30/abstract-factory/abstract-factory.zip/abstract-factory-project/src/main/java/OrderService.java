public class OrderService {
    private final OrderFactory factory;
    
    public OrderService(OrderFactory factory) {
        this.factory = factory;
    }
    
    public void processOrder(String orderId, double amount) {
        PaymentProcessor processor = factory.createPaymentProcessor();
        ShippingService shipping = factory.createShippingService();
        
        processor.processPayment(amount);
        shipping.shipOrder(orderId);
    }
}