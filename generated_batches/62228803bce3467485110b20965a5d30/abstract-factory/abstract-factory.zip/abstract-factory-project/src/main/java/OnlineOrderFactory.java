public class OnlineOrderFactory implements OrderFactory {
    @Override
    public PaymentProcessor createPaymentProcessor() {
        return new CreditCardProcessor();
    }
    
    @Override
    public ShippingService createShippingService() {
        return new StandardShipping();
    }
}