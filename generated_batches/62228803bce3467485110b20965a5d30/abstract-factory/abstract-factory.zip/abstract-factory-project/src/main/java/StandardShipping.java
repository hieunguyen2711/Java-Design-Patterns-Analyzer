public class StandardShipping implements ShippingService {
    @Override
    public void shipOrder(String orderId) {
        System.out.println("Shipping order " + orderId + " via standard shipping");
    }
}