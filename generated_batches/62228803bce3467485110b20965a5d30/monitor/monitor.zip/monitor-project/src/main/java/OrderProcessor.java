package ecommerce.order;

import java.util.concurrent.locks.ReentrantLock;

public class OrderProcessor {
    private final ReentrantLock lock = new ReentrantLock();
    
    public void processOrder(Order order) {
        try {
            lock.lock();
            
            if (order.getStatus() == OrderStatus.PENDING) {
                System.out.println("Processing order: " + order.getOrderId());
                order.setStatus(OrderStatus.PROCESSING);
                
                // Simulate processing time
                Thread.sleep(1000);
                
                order.setStatus(OrderStatus.SHIPPED);
                System.out.println("Order shipped: " + order.getOrderId());
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            lock.unlock();
        }
    }
}