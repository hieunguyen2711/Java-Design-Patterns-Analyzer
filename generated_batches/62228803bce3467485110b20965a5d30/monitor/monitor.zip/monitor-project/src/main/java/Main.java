package ecommerce.order;

public class Main {
    public static void main(String[] args) {
        OrderService service = new OrderService();
        OrderProcessor processor = new OrderProcessor();
        
        // Create orders
        Order order1 = new Order("ORD001", 299.99);
        Order order2 = new Order("ORD002", 149.50);
        
        // Submit orders using monitor pattern
        service.submitOrder(order1);
        service.submitOrder(order2);
        
        // Process orders using monitor pattern
        processor.processOrder(order1);
        processor.processOrder(order2);
        
        System.out.println("Final order count: " + service.getTotalOrders());
    }
}