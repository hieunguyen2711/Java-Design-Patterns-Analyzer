package ecommerce.order;

import java.util.concurrent.locks.ReentrantLock;

public class OrderService {
    private final ReentrantLock monitor = new ReentrantLock();
    private int totalOrders = 0;
    
    public void submitOrder(Order order) {
        try {
            monitor.lock();
            
            System.out.println("Submitting order: " + order.getOrderId());
            totalOrders++;
            System.out.println("Total orders processed: " + totalOrders);
            
        } finally {
            monitor.unlock();
        }
    }
    
    public int getTotalOrders() {
        try {
            monitor.lock();
            return totalOrders;
        } finally {
            monitor.unlock();
        }
    }
}