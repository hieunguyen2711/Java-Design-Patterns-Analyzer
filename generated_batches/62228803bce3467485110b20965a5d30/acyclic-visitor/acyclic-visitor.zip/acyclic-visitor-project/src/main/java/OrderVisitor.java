public interface OrderVisitor {
    void visit(ProductItem productItem);
    void visit(ServiceItem serviceItem);
}