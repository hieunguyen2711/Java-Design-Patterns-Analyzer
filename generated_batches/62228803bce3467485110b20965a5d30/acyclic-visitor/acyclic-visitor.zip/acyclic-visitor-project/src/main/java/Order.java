import java.util.ArrayList;
import java.util.List;

public class Order {
    private List<OrderItem> items = new ArrayList<>();
    
    public void addItem(OrderItem item) {
        items.add(item);
    }
    
    public double calculateTotal() {
        OrderTotalVisitor visitor = new OrderTotalVisitor();
        for (OrderItem item : items) {
            item.accept(visitor);
        }
        return visitor.getTotal();
    }
}