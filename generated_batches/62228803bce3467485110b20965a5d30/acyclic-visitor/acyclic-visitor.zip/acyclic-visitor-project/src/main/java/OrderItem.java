public abstract class OrderItem {
    public abstract void accept(OrderVisitor visitor);
}