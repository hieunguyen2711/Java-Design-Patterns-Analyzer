public class ServiceItem extends OrderItem {
    private String serviceName;
    private double cost;
    
    public ServiceItem(String serviceName, double cost) {
        this.serviceName = serviceName;
        this.cost = cost;
    }
    
    @Override
    public void accept(OrderVisitor visitor) {
        visitor.visit(this);
    }
    
    public String getServiceName() {
        return serviceName;
    }
    
    public double getCost() {
        return cost;
    }
}