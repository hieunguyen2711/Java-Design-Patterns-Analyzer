public class OrderTotalVisitor implements OrderVisitor {
    private double total = 0.0;
    
    @Override
    public void visit(ProductItem productItem) {
        total += productItem.getPrice();
    }
    
    @Override
    public void visit(ServiceItem serviceItem) {
        total += serviceItem.getCost();
    }
    
    public double getTotal() {
        return total;
    }
}