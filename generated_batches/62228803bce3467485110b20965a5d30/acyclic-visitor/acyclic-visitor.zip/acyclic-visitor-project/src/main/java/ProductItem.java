public class ProductItem extends OrderItem {
    private String name;
    private double price;
    
    public ProductItem(String name, double price) {
        this.name = name;
        this.price = price;
    }
    
    @Override
    public void accept(OrderVisitor visitor) {
        visitor.visit(this);
    }
    
    public String getName() {
        return name;
    }
    
    public double getPrice() {
        return price;
    }
}