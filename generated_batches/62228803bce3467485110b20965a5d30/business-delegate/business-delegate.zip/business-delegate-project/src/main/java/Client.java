public class Client {
    public static void main(String[] args) {
        BusinessDelegate businessDelegate = new BusinessDelegate();
        
        businessDelegate.setOrderService(new OrderServiceImpl());
        businessDelegate.setPaymentService(new PaymentServiceImpl());
        businessDelegate.setInventoryService(new InventoryServiceImpl());
        
        businessDelegate.processOrder("ORD-123", "PAY-456", "PROD-789");
    }
}