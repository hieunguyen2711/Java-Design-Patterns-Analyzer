public class BusinessDelegate {
    private OrderService orderService;
    private PaymentService paymentService;
    private InventoryService inventoryService;

    public void setOrderService(OrderService orderService) {
        this.orderService = orderService;
    }

    public void setPaymentService(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    public void setInventoryService(InventoryService inventoryService) {
        this.inventoryService = inventoryService;
    }

    public void processOrder(String orderId, String paymentId, String productId) {
        orderService.processOrder(orderId);
        inventoryService.checkInventory(productId);
        paymentService.processPayment(paymentId);
    }
}