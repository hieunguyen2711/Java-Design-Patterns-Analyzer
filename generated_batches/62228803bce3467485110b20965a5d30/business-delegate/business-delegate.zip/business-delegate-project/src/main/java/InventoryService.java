public interface InventoryService {
    boolean checkInventory(String productId);
}