public interface PaymentService {
    void processPayment(String paymentId);
}