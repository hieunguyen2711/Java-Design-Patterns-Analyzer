public class PaymentServiceImpl implements PaymentService {
    @Override
    public void processPayment(String paymentId) {
        System.out.println("Processing payment: " + paymentId);
    }
}