public class InventoryServiceImpl implements InventoryService {
    @Override
    public boolean checkInventory(String productId) {
        System.out.println("Checking inventory for product: " + productId);
        return true;
    }
}