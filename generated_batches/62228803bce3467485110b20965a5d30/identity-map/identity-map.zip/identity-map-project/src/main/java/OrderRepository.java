package com.ecommerce.order;

import java.util.HashMap;
import java.util.Map;
import java.math.BigDecimal;

public class OrderRepository {
    private final Map<String, Order> orderCache = new HashMap<>();
    
    public Order findById(String orderId) {
        return orderCache.computeIfAbsent(orderId, id -> 
            new Order(id, BigDecimal.valueOf(100.00)));
    }
    
    public void save(Order order) {
        orderCache.put(order.getOrderId(), order);
    }
    
    public void clearCache() {
        orderCache.clear();
    }
}