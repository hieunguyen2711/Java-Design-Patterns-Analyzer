package com.ecommerce.order;

import java.math.BigDecimal;

public class OrderService {
    private final OrderRepository repository;
    
    public OrderService(OrderRepository repository) {
        this.repository = repository;
    }
    
    public Order createOrder(String orderId, BigDecimal amount) {
        Order order = new Order(orderId, amount);
        repository.save(order);
        return order;
    }
    
    public Order getOrder(String orderId) {
        return repository.findById(orderId);
    }
}