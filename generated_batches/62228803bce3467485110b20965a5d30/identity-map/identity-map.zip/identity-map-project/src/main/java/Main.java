package com.ecommerce.order;

import java.math.BigDecimal;

public class Main {
    public static void main(String[] args) {
        OrderRepository repository = new OrderRepository();
        OrderService service = new OrderService(repository);
        
        // First retrieval - creates and caches the order
        Order order1 = service.getOrder("ORD-001");
        System.out.println("First fetch: " + order1.getOrderId());
        
        // Second retrieval - returns cached instance
        Order order2 = service.getOrder("ORD-001");
        System.out.println("Second fetch: " + order2.getOrderId());
        
        // Verify identity map behavior
        System.out.println("Same object? " + (order1 == order2));
        
        // Create new order
        Order order3 = service.createOrder("ORD-002", BigDecimal.valueOf(250.00));
        System.out.println("New order: " + order3.getOrderId());
    }
}