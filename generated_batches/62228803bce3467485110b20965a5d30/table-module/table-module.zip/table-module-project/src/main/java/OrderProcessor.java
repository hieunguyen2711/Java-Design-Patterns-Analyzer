package com.ecommerce.order;

public interface OrderProcessor {
    void processOrder(Order order);
}