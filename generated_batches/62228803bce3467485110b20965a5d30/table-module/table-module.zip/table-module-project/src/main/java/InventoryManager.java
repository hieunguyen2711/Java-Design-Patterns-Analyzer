package com.ecommerce.order;

public class InventoryManager implements OrderProcessor {
    @Override
    public void processOrder(Order order) {
        System.out.println("Checking inventory for order " + order.getOrderId());
        order.setStatus("CONFIRMED");
    }
}