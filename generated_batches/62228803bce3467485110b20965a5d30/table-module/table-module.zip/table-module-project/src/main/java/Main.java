package com.ecommerce.order;

public class Main {
    public static void main(String[] args) {
        OrderProcessingTable table = new OrderProcessingTable();
        Order order = new Order("ORD-001", 299.99);
        
        table.processOrder(order);
    }
}