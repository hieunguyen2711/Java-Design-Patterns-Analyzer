package com.ecommerce.order;

public class PaymentProcessor implements OrderProcessor {
    @Override
    public void processOrder(Order order) {
        System.out.println("Processing payment for order " + order.getOrderId());
        order.setStatus("PAID");
    }
}