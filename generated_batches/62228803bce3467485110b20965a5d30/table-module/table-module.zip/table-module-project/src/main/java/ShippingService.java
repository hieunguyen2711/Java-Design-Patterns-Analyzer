package com.ecommerce.order;

public class ShippingService implements OrderProcessor {
    @Override
    public void processOrder(Order order) {
        System.out.println("Preparing shipping for order " + order.getOrderId());
        order.setStatus("SHIPPED");
    }
}