package com.ecommerce.order;

import java.util.ArrayList;
import java.util.List;

public class OrderProcessingTable {
    private List<OrderProcessor> processors;
    
    public OrderProcessingTable() {
        this.processors = new ArrayList<>();
        initializeProcessors();
    }
    
    private void initializeProcessors() {
        processors.add(new PaymentProcessor());
        processors.add(new InventoryManager());
        processors.add(new ShippingService());
    }
    
    public void processOrder(Order order) {
        System.out.println("Starting order processing for: " + order.getOrderId());
        for (OrderProcessor processor : processors) {
            processor.processOrder(order);
        }
        System.out.println("Final status: " + order.getStatus());
    }
}