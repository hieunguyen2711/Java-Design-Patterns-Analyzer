public class PaymentValidationHandler extends OrderHandler {
    @Override
    public boolean handleOrder(Order order) {
        if (order.getAmount() <= 0) {
            System.out.println("Payment validation failed: Invalid amount");
            return false;
        }
        
        System.out.println("Payment validation passed");
        
        if (nextHandler != null) {
            return nextHandler.handleOrder(order);
        }
        
        return true;
    }
}