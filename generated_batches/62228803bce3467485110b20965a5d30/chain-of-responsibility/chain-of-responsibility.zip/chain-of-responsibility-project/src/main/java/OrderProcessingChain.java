public class OrderProcessingChain {
    private OrderHandler firstHandler;
    
    public void setFirstHandler(OrderHandler handler) {
        this.firstHandler = handler;
    }
    
    public boolean processOrder(Order order) {
        if (firstHandler != null) {
            return firstHandler.handleOrder(order);
        }
        return false;
    }
}