public abstract class OrderHandler {
    protected OrderHandler nextHandler;
    
    public void setNext(OrderHandler handler) {
        this.nextHandler = handler;
    }
    
    public abstract boolean handleOrder(Order order);
}