public class CustomerValidationHandler extends OrderHandler {
    @Override
    public boolean handleOrder(Order order) {
        if (order.getCustomerEmail() == null || !order.getCustomerEmail().contains("@")) {
            System.out.println("Customer validation failed: Invalid email");
            return false;
        }
        
        System.out.println("Customer validation passed");
        
        if (nextHandler != null) {
            return nextHandler.handleOrder(order);
        }
        
        return true;
    }
}