public class Main {
    public static void main(String[] args) {
        // Create handlers
        PaymentValidationHandler paymentValidator = new PaymentValidationHandler();
        CustomerValidationHandler customerValidator = new CustomerValidationHandler();
        DiscountValidationHandler discountValidator = new DiscountValidationHandler();
        
        // Build the chain
        paymentValidator.setNext(customerValidator);
        customerValidator.setNext(discountValidator);
        
        // Create processing chain
        OrderProcessingChain chain = new OrderProcessingChain();
        chain.setFirstHandler(paymentValidator);
        
        // Test with valid order
        System.out.println("Processing valid order:");
        Order validOrder = new Order("123", 500.0, "customer@example.com");
        boolean result = chain.processOrder(validOrder);
        System.out.println("Order processed: " + result);
        
        System.out.println("\n---\n");
        
        // Test with invalid order
        System.out.println("Processing invalid order:");
        Order invalidOrder = new Order("456", -100.0, "invalid-email");
        boolean result2 = chain.processOrder(invalidOrder);
        System.out.println("Order processed: " + result2);
    }
}