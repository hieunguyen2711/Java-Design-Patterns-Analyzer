public class DiscountValidationHandler extends OrderHandler {
    @Override
    public boolean handleOrder(Order order) {
        if (order.getAmount() > 1000 && order.getCustomerEmail().contains("premium")) {
            System.out.println("Discount validation passed: Premium customer discount applied");
        } else {
            System.out.println("Discount validation: No discount applied");
        }
        
        if (nextHandler != null) {
            return nextHandler.handleOrder(order);
        }
        
        return true;
    }
}