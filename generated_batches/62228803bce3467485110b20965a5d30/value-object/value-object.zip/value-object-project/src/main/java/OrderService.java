package com.ecommerce.order;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class OrderService {
    
    public Order createOrder(String customerId, String customerName, String customerEmail,
                           List<OrderItem> items) {
        Customer customer = new Customer(customerId, customerName, customerEmail);
        return new Order(generateOrderId(), customer, items, LocalDateTime.now());
    }
    
    private String generateOrderId() {
        return "ORD-" + System.currentTimeMillis();
    }
}