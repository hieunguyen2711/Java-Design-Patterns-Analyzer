package com.ecommerce.order;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        OrderService orderService = new OrderService();
        
        List<OrderItem> items = Arrays.asList(
            new OrderItem("PROD-001", "Laptop", 1, new BigDecimal("999.99")),
            new OrderItem("PROD-002", "Mouse", 2, new BigDecimal("25.50"))
        );
        
        Order order = orderService.createOrder(
            "CUST-001",
            "John Doe",
            "john.doe@example.com",
            items
        );
        
        System.out.println(order);
    }
}