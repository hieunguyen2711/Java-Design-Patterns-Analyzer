package ecommerce.order;

import java.util.function.Function;

public class OrderProcessor {
    private Function<Order, Double> discountCalculator;
    private Function<Double, Double> taxCalculator;
    private Function<Double, Double> shippingCalculator;
    
    public OrderProcessor(Function<Order, Double> discountCalculator,
                         Function<Double, Double> taxCalculator,
                         Function<Double, Double> shippingCalculator) {
        this.discountCalculator = discountCalculator;
        this.taxCalculator = taxCalculator;
        this.shippingCalculator = shippingCalculator;
    }
    
    public double processOrder(Order order) {
        return shippingCalculator.apply(
            taxCalculator.apply(
                discountCalculator.apply(order)
            )
        );
    }
}