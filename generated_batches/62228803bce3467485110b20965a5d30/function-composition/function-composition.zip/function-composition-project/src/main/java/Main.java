package ecommerce.order;

public class Main {
    public static void main(String[] args) {
        Order order = new Order("ORD001", 100.0);
        OrderProcessingService service = new OrderProcessingService();
        
        double finalAmount = service.calculateFinalAmount(order);
        System.out.println("Final amount: $" + finalAmount);
    }
}