package ecommerce.order;

import java.util.function.Function;

public class OrderProcessingService {
    private static final Function<Order, Double> DISCOUNT_CALCULATOR = 
        order -> order.getAmount() * 0.9;
    
    private static final Function<Double, Double> TAX_CALCULATOR = 
        amount -> amount * 1.08;
    
    private static final Function<Double, Double> SHIPPING_CALCULATOR = 
        amount -> amount + 5.0;
    
    public double calculateFinalAmount(Order order) {
        OrderProcessor processor = new OrderProcessor(
            DISCOUNT_CALCULATOR,
            TAX_CALCULATOR,
            SHIPPING_CALCULATOR
        );
        
        return processor.processOrder(order);
    }
}