package com.ecommerce.order;

public class Order {
    private final String orderId;
    private final String customerName;
    private final String shippingAddress;
    private final double totalAmount;
    private final boolean isGiftWrapped;
    
    private Order(Builder builder) {
        this.orderId = builder.orderId;
        this.customerName = builder.customerName;
        this.shippingAddress = builder.shippingAddress;
        this.totalAmount = builder.totalAmount;
        this.isGiftWrapped = builder.isGiftWrapped;
    }
    
    public String getOrderId() {
        return orderId;
    }
    
    public String getCustomerName() {
        return customerName;
    }
    
    public String getShippingAddress() {
        return shippingAddress;
    }
    
    public double getTotalAmount() {
        return totalAmount;
    }
    
    public boolean isGiftWrapped() {
        return isGiftWrapped;
    }
    
    @Override
    public String toString() {
        return "Order{" +
                "orderId='" + orderId + '\'' +
                ", customerName='" + customerName + '\'' +
                ", shippingAddress='" + shippingAddress + '\'' +
                ", totalAmount=" + totalAmount +
                ", isGiftWrapped=" + isGiftWrapped +
                '}';
    }
    
    public static class Builder {
        private String orderId;
        private String customerName;
        private String shippingAddress;
        private double totalAmount;
        private boolean isGiftWrapped = false;
        
        public Builder setOrderId(String orderId) {
            this.orderId = orderId;
            return this;
        }
        
        public Builder setCustomerName(String customerName) {
            this.customerName = customerName;
            return this;
        }
        
        public Builder setShippingAddress(String shippingAddress) {
            this.shippingAddress = shippingAddress;
            return this;
        }
        
        public Builder setTotalAmount(double totalAmount) {
            this.totalAmount = totalAmount;
            return this;
        }
        
        public Builder setGiftWrapped(boolean giftWrapped) {
            isGiftWrapped = giftWrapped;
            return this;
        }
        
        public Order build() {
            return new Order(this);
        }
    }
}