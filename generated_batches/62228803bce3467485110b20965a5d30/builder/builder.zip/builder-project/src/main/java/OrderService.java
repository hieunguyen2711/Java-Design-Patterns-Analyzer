package com.ecommerce.order;

public class OrderService {
    
    public static void main(String[] args) {
        // Using the builder pattern to create orders
        Order order1 = new Order.Builder()
                .setOrderId("ORD-001")
                .setCustomerName("John Doe")
                .setShippingAddress("123 Main St, Anytown, USA")
                .setTotalAmount(299.99)
                .setGiftWrapped(true)
                .build();
        
        Order order2 = new Order.Builder()
                .setOrderId("ORD-002")
                .setCustomerName("Jane Smith")
                .setShippingAddress("456 Oak Ave, Somewhere, USA")
                .setTotalAmount(149.50)
                .build();
        
        System.out.println(order1);
        System.out.println(order2);
    }
}