public class Main {
    public static void main(String[] args) {
        OrderRepository orderRepository = new OrderRepository();
        UnitOfWork unitOfWork = new UnitOfWork(orderRepository);
        OrderService orderService = new OrderService(unitOfWork);
        
        // Create some orders
        orderService.createOrder("ORD001", "CUST001", 250.00);
        orderService.createOrder("ORD002", "CUST002", 175.50);
        
        // Update an order
        orderService.updateOrder("ORD001", "CUST001", 300.00);
        
        // Delete an order
        orderService.deleteOrder("ORD002");
        
        // Commit all changes
        orderService.processOrders();
    }
}