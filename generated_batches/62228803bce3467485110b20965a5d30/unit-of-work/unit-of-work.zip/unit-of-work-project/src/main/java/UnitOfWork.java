import java.util.ArrayList;
import java.util.List;

public class UnitOfWork {
    private List<Order> addedOrders;
    private List<Order> updatedOrders;
    private List<String> deletedOrderIds;
    private OrderRepository orderRepository;
    
    public UnitOfWork(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
        this.addedOrders = new ArrayList<>();
        this.updatedOrders = new ArrayList<>();
        this.deletedOrderIds = new ArrayList<>();
    }
    
    public void registerAdded(Order order) {
        addedOrders.add(order);
    }
    
    public void registerUpdated(Order order) {
        updatedOrders.add(order);
    }
    
    public void registerDeleted(String orderId) {
        deletedOrderIds.add(orderId);
    }
    
    public void commit() {
        for (Order order : addedOrders) {
            orderRepository.save(order);
        }
        
        for (Order order : updatedOrders) {
            orderRepository.save(order);
        }
        
        for (String orderId : deletedOrderIds) {
            orderRepository.delete(orderId);
        }
        
        // Clear the unit of work after commit
        addedOrders.clear();
        updatedOrders.clear();
        deletedOrderIds.clear();
    }
    
    public void rollback() {
        // In a real implementation, this would undo changes
        // For simplicity, we just clear the tracking lists
        addedOrders.clear();
        updatedOrders.clear();
        deletedOrderIds.clear();
    }
}