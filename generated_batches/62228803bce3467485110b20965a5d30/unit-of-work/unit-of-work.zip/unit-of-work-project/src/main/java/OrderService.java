public class OrderService {
    private UnitOfWork unitOfWork;
    
    public OrderService(UnitOfWork unitOfWork) {
        this.unitOfWork = unitOfWork;
    }
    
    public void createOrder(String orderId, String customerId, double amount) {
        Order order = new Order(orderId, customerId, amount);
        unitOfWork.registerAdded(order);
    }
    
    public void updateOrder(String orderId, String customerId, double amount) {
        // In a real system, we would fetch the existing order first
        Order order = new Order(orderId, customerId, amount);
        unitOfWork.registerUpdated(order);
    }
    
    public void deleteOrder(String orderId) {
        unitOfWork.registerDeleted(orderId);
    }
    
    public void processOrders() {
        unitOfWork.commit();
    }
}