import java.util.HashMap;
import java.util.Map;

public class OrderRepository {
    private Map<String, Order> orders;
    
    public OrderRepository() {
        this.orders = new HashMap<>();
    }
    
    public void save(Order order) {
        orders.put(order.getOrderId(), order);
    }
    
    public Order findById(String orderId) {
        return orders.get(orderId);
    }
    
    public void delete(String orderId) {
        orders.remove(orderId);
    }
}