public class Order {
    private OrderState state;
    
    public Order() {
        this.state = new PendingState();
    }
    
    public void setState(OrderState state) {
        this.state = state;
    }
    
    public void processOrder() {
        state.processOrder(this);
    }
    
    public void shipOrder() {
        state.shipOrder(this);
    }
    
    public void deliverOrder() {
        state.deliverOrder(this);
    }
}