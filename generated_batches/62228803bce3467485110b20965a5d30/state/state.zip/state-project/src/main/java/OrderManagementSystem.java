public class OrderManagementSystem {
    public static void main(String[] args) {
        Order order = new Order();
        
        order.processOrder();  // Pending -> Processing
        order.shipOrder();     // Processing -> Shipped
        order.deliverOrder();  // Shipped -> Delivered
        
        order.deliverOrder();  // Delivered state
    }
}