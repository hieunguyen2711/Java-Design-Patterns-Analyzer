public class ShippedState implements OrderState {
    @Override
    public void processOrder(Order order) {
        System.out.println("Order is already processed");
    }
    
    @Override
    public void shipOrder(Order order) {
        System.out.println("Order is already shipped");
    }
    
    @Override
    public void deliverOrder(Order order) {
        System.out.println("Order is being delivered...");
        order.setState(new DeliveredState());
    }
}