public class DeliveredState implements OrderState {
    @Override
    public void processOrder(Order order) {
        System.out.println("Order is already delivered");
    }
    
    @Override
    public void shipOrder(Order order) {
        System.out.println("Order is already delivered");
    }
    
    @Override
    public void deliverOrder(Order order) {
        System.out.println("Order has already been delivered");
    }
}