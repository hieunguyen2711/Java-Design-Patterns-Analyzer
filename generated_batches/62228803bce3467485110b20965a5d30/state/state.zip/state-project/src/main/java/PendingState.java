public class PendingState implements OrderState {
    @Override
    public void processOrder(Order order) {
        System.out.println("Order is being processed...");
        order.setState(new ProcessingState());
    }
    
    @Override
    public void shipOrder(Order order) {
        System.out.println("Cannot ship order - it's not processed yet");
    }
    
    @Override
    public void deliverOrder(Order order) {
        System.out.println("Cannot deliver order - it's not shipped yet");
    }
}