public class ProcessingState implements OrderState {
    @Override
    public void processOrder(Order order) {
        System.out.println("Order is already being processed");
    }
    
    @Override
    public void shipOrder(Order order) {
        System.out.println("Order is being shipped...");
        order.setState(new ShippedState());
    }
    
    @Override
    public void deliverOrder(Order order) {
        System.out.println("Cannot deliver order - it's not shipped yet");
    }
}