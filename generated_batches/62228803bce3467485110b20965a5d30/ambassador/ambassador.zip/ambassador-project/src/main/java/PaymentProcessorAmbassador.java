package com.example.order;

public class PaymentProcessorAmbassador {
    private static volatile PaymentProcessor instance;
    
    public static PaymentProcessor getInstance() {
        if (instance == null) {
            synchronized (PaymentProcessorAmbassador.class) {
                if (instance == null) {
                    // This is the ambassador pattern - providing a single point of access
                    // to create and manage the actual payment processor implementation
                    instance = new CreditCardProcessor();
                }
            }
        }
        return instance;
    }
    
    public static void setInstance(PaymentProcessor processor) {
        instance = processor;
    }
}