package com.example.order;

public interface PaymentProcessor {
    boolean processPayment(Order order);
}