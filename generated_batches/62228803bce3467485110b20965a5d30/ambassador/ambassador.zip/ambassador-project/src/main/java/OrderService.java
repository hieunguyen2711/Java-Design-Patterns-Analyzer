package com.example.order;

public class OrderService {
    private PaymentProcessor processor;
    
    public OrderService(PaymentProcessor processor) {
        this.processor = processor;
    }
    
    public boolean processOrder(Order order) {
        System.out.println("Processing order " + order.getOrderId() + " with amount $" + order.getAmount());
        return processor.processPayment(order);
    }
}