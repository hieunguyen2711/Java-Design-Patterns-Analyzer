package com.example.order;

public class Main {
    public static void main(String[] args) {
        // Using the ambassador to get the payment processor
        PaymentProcessor processor = PaymentProcessorAmbassador.getInstance();
        
        OrderService orderService = new OrderService(processor);
        
        Order order1 = new Order("ORD001", 150.00);
        Order order2 = new Order("ORD002", 275.50);
        
        orderService.processOrder(order1);
        orderService.processOrder(order2);
        
        // Demonstrating the ambassador can switch implementations
        PaymentProcessorAmbassador.setInstance(new PayPalProcessor());
        processor = PaymentProcessorAmbassador.getInstance();
        
        OrderService paypalOrderService = new OrderService(processor);
        Order order3 = new Order("ORD003", 99.99);
        paypalOrderService.processOrder(order3);
    }
}