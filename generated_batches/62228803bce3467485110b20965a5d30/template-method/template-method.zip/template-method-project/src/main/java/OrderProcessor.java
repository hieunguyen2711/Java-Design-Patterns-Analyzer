package ecommerce.order;

public abstract class OrderProcessor {
    // Template method
    public final void processOrder(Order order) {
        validateOrder(order);
        calculateTotal(order);
        applyDiscounts(order);
        updateInventory(order);
        notifyCustomer(order);
    }
    
    protected abstract void validateOrder(Order order);
    protected abstract void calculateTotal(Order order);
    protected abstract void applyDiscounts(Order order);
    protected abstract void updateInventory(Order order);
    protected abstract void notifyCustomer(Order order);
}