package ecommerce.order;

public class StandardOrderProcessor extends OrderProcessor {
    
    @Override
    protected void validateOrder(Order order) {
        System.out.println("Validating standard order: " + order.getId());
        // Validation logic for standard orders
    }
    
    @Override
    protected void calculateTotal(Order order) {
        System.out.println("Calculating total for standard order: " + order.getId());
        // Calculation logic for standard orders
    }
    
    @Override
    protected void applyDiscounts(Order order) {
        System.out.println("Applying discounts to standard order: " + order.getId());
        // Discount logic for standard orders
    }
    
    @Override
    protected void updateInventory(Order order) {
        System.out.println("Updating inventory for standard order: " + order.getId());
        // Inventory update logic for standard orders
    }
    
    @Override
    protected void notifyCustomer(Order order) {
        System.out.println("Notifying customer about standard order: " + order.getId());
        // Notification logic for standard orders
    }
}