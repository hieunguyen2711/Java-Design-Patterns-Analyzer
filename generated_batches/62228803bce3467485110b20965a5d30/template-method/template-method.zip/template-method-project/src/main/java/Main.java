package ecommerce.order;

public class Main {
    public static void main(String[] args) {
        Order standardOrder = new Order("STD001", 100.0);
        Order premiumOrder = new Order("PRM001", 250.0);
        
        System.out.println("Processing Standard Order:");
        OrderProcessor standardProcessor = new StandardOrderProcessor();
        standardProcessor.processOrder(standardOrder);
        
        System.out.println("\nProcessing Premium Order:");
        OrderProcessor premiumProcessor = new PremiumOrderProcessor();
        premiumProcessor.processOrder(premiumOrder);
    }
}