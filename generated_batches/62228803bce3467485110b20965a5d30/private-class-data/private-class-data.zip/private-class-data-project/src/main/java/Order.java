package com.ecommerce.order;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Order {
    private final String orderId;
    private final List<OrderItem> items;
    private final BigDecimal totalAmount;
    
    public Order(String orderId, List<OrderItem> items) {
        this.orderId = orderId;
        this.items = new ArrayList<>(items);
        this.totalAmount = calculateTotal();
    }
    
    private BigDecimal calculateTotal() {
        return items.stream()
                   .map(OrderItem::getTotalPrice)
                   .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    
    public String getOrderId() {
        return orderId;
    }
    
    public List<OrderItem> getItems() {
        // Return unmodifiable view to prevent external modification
        return new ArrayList<>(items);
    }
    
    public BigDecimal getTotalAmount() {
        return totalAmount;
    }
}