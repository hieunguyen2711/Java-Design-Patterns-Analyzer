package com.ecommerce.order;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class OrderService {
    private final List<Order> orders = new ArrayList<>();
    
    public void addOrder(Order order) {
        orders.add(order);
    }
    
    public List<Order> getAllOrders() {
        return new ArrayList<>(orders); // Return copy to maintain encapsulation
    }
    
    public Order getOrder(String orderId) {
        return orders.stream()
                    .filter(o -> o.getOrderId().equals(orderId))
                    .findFirst()
                    .orElse(null);
    }
}