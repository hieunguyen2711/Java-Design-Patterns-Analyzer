package com.ecommerce.order;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

public class PrivateClassDataDemo {
    public static void main(String[] args) {
        // Create order items using private-class-data pattern
        OrderItem item1 = new OrderItem("P001", "Laptop", 1, new BigDecimal("999.99"));
        OrderItem item2 = new OrderItem("P002", "Mouse", 2, new BigDecimal("25.50"));
        
        List<OrderItem> items = Arrays.asList(item1, item2);
        
        // Create order
        Order order = new Order("ORD-001", items);
        
        System.out.println("Order ID: " + order.getOrderId());
        System.out.println("Total Amount: " + order.getTotalAmount());
        
        // Demonstrate encapsulation - cannot modify internal data directly
        List<OrderItem> retrievedItems = order.getItems();
        // retrievedItems.add(new OrderItem("P003", "Keyboard", 1, new BigDecimal("75.00"))); // Would cause compilation error if uncommented
        
        System.out.println("Number of items: " + retrievedItems.size());
    }
}