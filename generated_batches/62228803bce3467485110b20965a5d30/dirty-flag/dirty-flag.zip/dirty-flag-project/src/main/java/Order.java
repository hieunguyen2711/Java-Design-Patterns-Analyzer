package com.ecommerce.order;

public class Order {
    private String orderId;
    private double totalAmount;
    private boolean isDirty = false;
    
    public Order(String orderId, double totalAmount) {
        this.orderId = orderId;
        this.totalAmount = totalAmount;
    }
    
    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
        markAsDirty();
    }
    
    public double getTotalAmount() {
        return totalAmount;
    }
    
    public String getOrderId() {
        return orderId;
    }
    
    private void markAsDirty() {
        isDirty = true;
    }
    
    public boolean isDirty() {
        return isDirty;
    }
    
    public void clearDirtyFlag() {
        isDirty = false;
    }
}