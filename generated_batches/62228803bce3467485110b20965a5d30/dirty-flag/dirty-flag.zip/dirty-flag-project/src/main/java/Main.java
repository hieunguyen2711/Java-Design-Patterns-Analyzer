package com.ecommerce.order;

public class Main {
    public static void main(String[] args) {
        Order order = new Order("ORD-001", 100.0);
        OrderService service = new OrderService(order);
        
        System.out.println("Initial state - Dirty flag: " + order.isDirty());
        
        // Modify the order
        service.updateOrderTotal(150.0);
        System.out.println("After modification - Dirty flag: " + order.isDirty());
        
        // Process the order (will save if dirty)
        service.processOrder();
        System.out.println("After processing - Dirty flag: " + order.isDirty());
    }
}