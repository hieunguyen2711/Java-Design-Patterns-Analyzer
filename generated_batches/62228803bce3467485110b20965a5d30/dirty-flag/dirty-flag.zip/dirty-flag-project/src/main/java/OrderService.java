package com.ecommerce.order;

public class OrderService {
    private Order order;
    
    public OrderService(Order order) {
        this.order = order;
    }
    
    public void updateOrderTotal(double newAmount) {
        if (order.isDirty()) {
            System.out.println("Order has been modified, saving changes...");
        }
        order.setTotalAmount(newAmount);
    }
    
    public void processOrder() {
        if (order.isDirty()) {
            saveOrder();
            order.clearDirtyFlag();
        }
    }
    
    private void saveOrder() {
        System.out.println("Saving order " + order.getOrderId() + 
                          " with amount: " + order.getTotalAmount());
    }
}