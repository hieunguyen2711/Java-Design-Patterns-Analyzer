package ecommerce.order;

public class OrderService {
    private OrderManager orderManager;
    
    public OrderService() {
        this.orderManager = OrderManager.getInstance();
    }
    
    public void handleOrder(String orderId, double amount) {
        orderManager.processOrder(orderId, amount);
    }
}