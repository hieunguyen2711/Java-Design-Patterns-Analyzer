package ecommerce.order;

public class OrderManager {
    private static volatile OrderManager instance;
    
    private OrderManager() {
        // Private constructor to prevent instantiation
    }
    
    public static OrderManager getInstance() {
        if (instance == null) {
            synchronized (OrderManager.class) {
                if (instance == null) {
                    instance = new OrderManager();
                }
            }
        }
        return instance;
    }
    
    public void processOrder(String orderId, double amount) {
        System.out.println("Processing order " + orderId + " for $" + amount);
    }
}