package ecommerce.order;

public class Main {
    public static void main(String[] args) {
        OrderService service1 = new OrderService();
        OrderService service2 = new OrderService();
        
        service1.handleOrder("ORD-001", 99.99);
        service2.handleOrder("ORD-002", 149.50);
        
        System.out.println("Both services reference same instance: " + 
                          (service1.getClass().getDeclaredFields()[0].getType() == OrderManager.class));
    }
}