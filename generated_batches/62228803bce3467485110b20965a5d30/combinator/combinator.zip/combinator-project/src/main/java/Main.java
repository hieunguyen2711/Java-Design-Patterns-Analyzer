package com.ecommerce.order;

import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Order> orders = Arrays.asList(
            new Order("ORD001", 150.0),
            new Order("ORD002", 200.0),
            new Order("ORD003", 75.0)
        );
        
        OrderProcessor processor = new OrderProcessor(orders);
        
        // Using combinators to process orders
        Double totalAmount = processor.processOrders(OrderCombinator.totalAmount());
        List<String> orderIds = processor.processOrders(OrderCombinator.orderIds());
        Double averageAmount = processor.processOrders(OrderCombinator.averageAmount());
        
        System.out.println("Total Amount: " + totalAmount);
        System.out.println("Order IDs: " + orderIds);
        System.out.println("Average Amount: " + averageAmount);
        
        // Combining operations
        Function<List<Order>, String> combined = OrderCombinator.combine(
            OrderCombinator.totalAmount(),
            amount -> "Total: $" + amount + ", Average: $" + 
                     OrderCombinator.averageAmount().apply(orders)
        );
        
        System.out.println(combined.apply(orders));
    }
}