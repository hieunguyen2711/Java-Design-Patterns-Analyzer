package com.ecommerce.order;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class OrderCombinator {
    
    public static Function<List<Order>, Double> totalAmount() {
        return orders -> orders.stream()
                .mapToDouble(Order::getAmount)
                .sum();
    }
    
    public static Function<List<Order>, List<String>> orderIds() {
        return orders -> orders.stream()
                .map(Order::getOrderId)
                .collect(Collectors.toList());
    }
    
    public static Function<List<Order>, Double> averageAmount() {
        return orders -> orders.stream()
                .mapToDouble(Order::getAmount)
                .average()
                .orElse(0.0);
    }
    
    public static <T, U> Function<List<Order>, U> combine(Function<List<Order>, T> first,
                                                         Function<T, U> second) {
        return orders -> second.apply(first.apply(orders));
    }
}