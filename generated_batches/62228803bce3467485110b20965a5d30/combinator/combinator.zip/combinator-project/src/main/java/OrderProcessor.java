package com.ecommerce.order;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class OrderProcessor {
    private List<Order> orders;
    
    public OrderProcessor(List<Order> orders) {
        this.orders = orders;
    }
    
    public double calculateTotalAmount() {
        return orders.stream()
                .mapToDouble(Order::getAmount)
                .sum();
    }
    
    public <T> T processOrders(Function<List<Order>, T> processor) {
        return processor.apply(orders);
    }
}