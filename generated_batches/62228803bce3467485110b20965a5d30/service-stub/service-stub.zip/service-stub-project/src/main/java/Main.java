package com.ecommerce.order.service;

public class Main {
    public static void main(String[] args) {
        // Using real service
        OrderService realService = new OrderServiceImpl();
        OrderProcessor processor1 = new OrderProcessor(realService);
        
        System.out.println("=== Real Service ===");
        processor1.handleOrder("ORD-001");
        
        // Using stub service for testing
        OrderService stubService = new OrderServiceStub(realService);
        OrderProcessor processor2 = new OrderProcessor(stubService);
        
        System.out.println("\n=== Stub Service ===");
        processor2.handleOrder("ORD-002");
    }
}