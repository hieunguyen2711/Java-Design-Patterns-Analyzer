package com.ecommerce.order.service;

public class OrderServiceStub implements OrderService {
    
    private final OrderService realService;
    
    public OrderServiceStub(OrderService realService) {
        this.realService = realService;
    }
    
    @Override
    public void processOrder(String orderId) {
        // Stub behavior - no actual processing
        System.out.println("Stub: Processing order (no real action)");
    }
    
    @Override
    public boolean validateOrder(String orderId) {
        // Stub behavior - always return true for testing
        System.out.println("Stub: Validating order " + orderId);
        return true;
    }
}