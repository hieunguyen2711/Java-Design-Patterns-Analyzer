package com.ecommerce.order.service;

public class OrderServiceImpl implements OrderService {
    
    @Override
    public void processOrder(String orderId) {
        System.out.println("Processing order: " + orderId);
    }
    
    @Override
    public boolean validateOrder(String orderId) {
        return orderId != null && !orderId.isEmpty();
    }
}