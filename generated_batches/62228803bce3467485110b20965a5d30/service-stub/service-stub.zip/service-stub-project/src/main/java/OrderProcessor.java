package com.ecommerce.order.service;

public class OrderProcessor {
    
    private final OrderService orderService;
    
    public OrderProcessor(OrderService orderService) {
        this.orderService = orderService;
    }
    
    public void handleOrder(String orderId) {
        if (orderService.validateOrder(orderId)) {
            orderService.processOrder(orderId);
        } else {
            System.out.println("Invalid order: " + orderId);
        }
    }
}