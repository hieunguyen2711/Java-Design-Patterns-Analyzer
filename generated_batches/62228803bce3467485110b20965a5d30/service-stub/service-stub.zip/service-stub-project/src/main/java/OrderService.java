package com.ecommerce.order.service;

public interface OrderService {
    void processOrder(String orderId);
    boolean validateOrder(String orderId);
}