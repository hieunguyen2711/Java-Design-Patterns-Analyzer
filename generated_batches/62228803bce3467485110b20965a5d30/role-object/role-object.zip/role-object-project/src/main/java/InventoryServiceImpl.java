package ecommerce.order;

import java.util.HashMap;
import java.util.Map;

public class InventoryServiceImpl implements InventoryService {
    private Map<String, Integer> inventory = new HashMap<>();
    
    public InventoryServiceImpl() {
        // Initialize with some sample data
        inventory.put("P001", 10);
        inventory.put("P002", 5);
        inventory.put("P003", 8);
    }
    
    @Override
    public boolean checkInventory(Order order) {
        for (OrderItem item : order.getItems()) {
            Integer available = inventory.get(item.getProductId());
            if (available == null || available < item.getQuantity()) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public void updateInventory(Order order) {
        for (OrderItem item : order.getItems()) {
            Integer available = inventory.get(item.getProductId());
            if (available != null) {
                inventory.put(item.getProductId(), available - item.getQuantity());
            }
        }
    }
}