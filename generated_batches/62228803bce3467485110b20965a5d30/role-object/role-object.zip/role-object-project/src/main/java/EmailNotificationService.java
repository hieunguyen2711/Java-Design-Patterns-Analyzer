package ecommerce.order;

public class EmailNotificationService implements NotificationService {
    
    @Override
    public void sendOrderConfirmation(Order order) {
        System.out.println("Sending email confirmation for order " + order.getOrderId());
    }
}