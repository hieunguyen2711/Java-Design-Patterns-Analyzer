package ecommerce.order;

public class OrderManagementSystem {
    public static void main(String[] args) {
        // Create services (role objects)
        PaymentService paymentService = new CreditCardPaymentService();
        InventoryService inventoryService = new InventoryServiceImpl();
        NotificationService notificationService = new EmailNotificationService();
        
        // Create order processor with role objects
        OrderProcessor processor = new OrderProcessor(paymentService, inventoryService, notificationService);
        
        // Create an order
        Order order = new Order("ORD-001");
        order.addItem(new OrderItem("P001", "Laptop", new BigDecimal("999.99"), 1));
        order.addItem(new OrderItem("P002", "Mouse", new BigDecimal("29.99"), 2));
        
        // Process the order
        boolean success = processor.processOrder(order);
        
        if (success) {
            System.out.println("Order processed successfully!");
        } else {
            System.out.println("Order processing failed!");
        }
    }
}