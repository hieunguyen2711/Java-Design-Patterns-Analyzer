package ecommerce.order;

import java.math.BigDecimal;

public class OrderProcessor {
    private PaymentService paymentService;
    private InventoryService inventoryService;
    private NotificationService notificationService;
    
    public OrderProcessor(PaymentService paymentService, 
                         InventoryService inventoryService,
                         NotificationService notificationService) {
        this.paymentService = paymentService;
        this.inventoryService = inventoryService;
        this.notificationService = notificationService;
    }
    
    public boolean processOrder(Order order) {
        // Check inventory
        if (!inventoryService.checkInventory(order)) {
            return false;
        }
        
        // Process payment
        if (!paymentService.processPayment(order.getTotalAmount())) {
            return false;
        }
        
        // Update inventory
        inventoryService.updateInventory(order);
        
        // Send notification
        notificationService.sendOrderConfirmation(order);
        
        return true;
    }
}