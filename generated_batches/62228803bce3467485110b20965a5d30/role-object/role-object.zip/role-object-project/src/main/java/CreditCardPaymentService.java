package ecommerce.order;

import java.math.BigDecimal;
import java.util.Random;

public class CreditCardPaymentService implements PaymentService {
    private Random random = new Random();
    
    @Override
    public boolean processPayment(BigDecimal amount) {
        // Simulate payment processing
        return random.nextBoolean();
    }
}