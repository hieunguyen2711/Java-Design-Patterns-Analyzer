package ecommerce.order;

public interface InventoryService {
    boolean checkInventory(Order order);
    void updateInventory(Order order);
}