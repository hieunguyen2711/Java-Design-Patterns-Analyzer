package ecommerce.order;

import java.math.BigDecimal;

public interface PaymentService {
    boolean processPayment(BigDecimal amount);
}