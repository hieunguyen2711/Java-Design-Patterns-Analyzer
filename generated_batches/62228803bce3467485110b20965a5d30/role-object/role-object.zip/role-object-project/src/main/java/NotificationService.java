package ecommerce.order;

public interface NotificationService {
    void sendOrderConfirmation(Order order);
}