public class OrderProcessor {
    public static void main(String[] args) {
        // Create different types of orders using the factory
        Order onlineOrder = OrderFactory.createOrder(
            OrderFactory.OrderType.ONLINE, 
            "ON123", 
            99.99, 
            "customer@example.com"
        );
        
        Order physicalOrder = OrderFactory.createOrder(
            OrderFactory.OrderType.PHYSICAL, 
            "PH456", 
            149.50, 
            "123 Main St, City, State"
        );
        
        // Process orders
        onlineOrder.processOrder();
        physicalOrder.processOrder();
    }
}