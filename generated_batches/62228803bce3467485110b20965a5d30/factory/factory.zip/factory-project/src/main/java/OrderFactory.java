public class OrderFactory {
    public enum OrderType {
        ONLINE, PHYSICAL
    }
    
    public static Order createOrder(OrderType type, String orderId, double amount, String details) {
        switch (type) {
            case ONLINE:
                return new OnlineOrder(orderId, amount, details);
            case PHYSICAL:
                return new PhysicalOrder(orderId, amount, details);
            default:
                throw new IllegalArgumentException("Unknown order type: " + type);
        }
    }
}