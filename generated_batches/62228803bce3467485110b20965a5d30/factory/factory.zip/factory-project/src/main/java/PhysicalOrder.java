public class PhysicalOrder extends Order {
    private String shippingAddress;
    
    public PhysicalOrder(String orderId, double amount, String shippingAddress) {
        super(orderId, amount);
        this.shippingAddress = shippingAddress;
    }
    
    @Override
    public void processOrder() {
        System.out.println("Processing physical order " + orderId + 
                          " for $" + amount + " to address: " + shippingAddress);
    }
}