public class OnlineOrder extends Order {
    private String customerEmail;
    
    public OnlineOrder(String orderId, double amount, String customerEmail) {
        super(orderId, amount);
        this.customerEmail = customerEmail;
    }
    
    @Override
    public void processOrder() {
        System.out.println("Processing online order " + orderId + 
                          " for $" + amount + " to email: " + customerEmail);
    }
}