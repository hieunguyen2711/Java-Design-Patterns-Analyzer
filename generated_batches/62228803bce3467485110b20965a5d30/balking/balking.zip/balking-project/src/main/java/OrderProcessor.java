package ecommerce.order;

import java.util.concurrent.locks.ReentrantLock;

public class OrderProcessor {
    private final ReentrantLock lock = new ReentrantLock();
    
    public void processOrder(Order order) {
        // Balking pattern - only process if order is in PENDING state
        if (!lock.tryLock()) {
            // Another thread is already processing this order
            return;
        }
        
        try {
            if (order.getStatus() != OrderStatus.PENDING) {
                // Balking: don't process orders that are not pending
                return;
            }
            
            // Simulate order processing
            System.out.println("Processing order " + order.getOrderId());
            Thread.sleep(1000); // Simulate work
            
            order.setStatus(OrderStatus.PROCESSING);
            System.out.println("Order " + order.getOrderId() + " is now PROCESSING");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            lock.unlock();
        }
    }
}