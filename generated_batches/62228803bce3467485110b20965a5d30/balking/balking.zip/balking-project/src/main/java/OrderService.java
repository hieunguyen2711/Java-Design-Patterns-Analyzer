package ecommerce.order;

public class OrderService {
    private final OrderProcessor processor;
    
    public OrderService() {
        this.processor = new OrderProcessor();
    }
    
    public void submitOrder(Order order) {
        // This method might be called multiple times for the same order
        // Balking pattern prevents duplicate processing
        processor.processOrder(order);
        
        // Simulate another attempt to process (this will be balked)
        processor.processOrder(order);
    }
}