package ecommerce.order;

public class Main {
    public static void main(String[] args) {
        OrderService service = new OrderService();
        Order order = new Order("ORD-001");
        
        System.out.println("Initial status: " + order.getStatus());
        
        // Submit the same order multiple times to demonstrate balking
        service.submitOrder(order);
        service.submitOrder(order);
        service.submitOrder(order);
        
        System.out.println("Final status: " + order.getStatus());
    }
}