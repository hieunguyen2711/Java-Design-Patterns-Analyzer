public class OrderProcessor {
    private final ThreadPoolExecutor executor;
    
    public OrderProcessor() {
        this.executor = new ThreadPoolExecutor(
            2, 
            4,
            60L,
            TimeUnit.SECONDS,
            new LinkedBlockingQueue<>(10)
        );
    }
    
    public void processOrder(Order order) {
        executor.submit(() -> {
            System.out.println("Processing order: " + order.getId() + 
                             " on thread: " + Thread.currentThread().getName());
            // Simulate order processing
            try {
                Thread.sleep(1000);
                order.setStatus("PROCESSED");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
    }
    
    public void shutdown() {
        executor.shutdown();
    }
}