import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.LinkedBlockingQueue;

public class OrderManagementSystem {
    private final OrderProcessor orderProcessor;
    
    public OrderManagementSystem() {
        this.orderProcessor = new OrderProcessor();
    }
    
    public void submitOrder(String orderId) {
        Order order = new Order(orderId);
        orderProcessor.processOrder(order);
    }
    
    public static void main(String[] args) {
        OrderManagementSystem system = new OrderManagementSystem();
        
        // Submit multiple orders
        for (int i = 1; i <= 6; i++) {
            system.submitOrder("ORDER-" + i);
        }
        
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        system.shutdown();
    }
    
    public void shutdown() {
        orderProcessor.shutdown();
    }
}