package com.ecommerce.order;

public class OrderService {
    private OrderProcessor processor;
    
    public OrderService(OrderProcessor processor) {
        this.processor = processor;
    }
    
    public void processPayment(Order order) {
        processor.processOrder(order, o -> {
            System.out.println("Processing payment for order " + o.getId());
            // Simulate payment processing
            double total = o.getItems().stream()
                .mapToDouble(item -> item.getPrice() * item.getQuantity())
                .sum();
            System.out.println("Payment amount: $" + total);
        });
    }
    
    public void processInventory(Order order) {
        processor.processOrder(order, o -> {
            System.out.println("Checking inventory for order " + o.getId());
            // Simulate inventory check
            o.getItems().forEach(item -> 
                System.out.println("Checking stock for product: " + item.getProductId())
            );
        });
    }
}