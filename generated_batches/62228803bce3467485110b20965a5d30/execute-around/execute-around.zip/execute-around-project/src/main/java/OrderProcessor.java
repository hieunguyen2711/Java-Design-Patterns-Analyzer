package com.ecommerce.order;

import java.util.function.Consumer;

public class OrderProcessor {
    
    public void processOrder(Order order, Consumer<Order> operation) {
        // Pre-processing steps
        System.out.println("Validating order " + order.getId());
        if (order.getItems().isEmpty()) {
            throw new IllegalArgumentException("Order must contain items");
        }
        
        try {
            // Execute the provided operation with the order
            operation.accept(order);
            
            // Post-processing steps
            System.out.println("Order " + order.getId() + " processed successfully");
        } catch (Exception e) {
            System.out.println("Error processing order " + order.getId() + ": " + e.getMessage());
            throw e;
        }
    }
}