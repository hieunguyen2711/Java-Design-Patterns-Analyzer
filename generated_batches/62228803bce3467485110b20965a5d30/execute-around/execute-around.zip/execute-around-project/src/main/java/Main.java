package com.ecommerce.order;

public class Main {
    public static void main(String[] args) {
        OrderProcessor processor = new OrderProcessor();
        OrderService service = new OrderService(processor);
        
        // Create an order
        Order order = new Order("ORD-001");
        order.addItem(new OrderItem("PROD-001", 2, 29.99));
        order.addItem(new OrderItem("PROD-002", 1, 19.99));
        
        // Process payment using execute-around pattern
        service.processPayment(order);
        
        System.out.println("---");
        
        // Process inventory using execute-around pattern
        service.processInventory(order);
    }
}