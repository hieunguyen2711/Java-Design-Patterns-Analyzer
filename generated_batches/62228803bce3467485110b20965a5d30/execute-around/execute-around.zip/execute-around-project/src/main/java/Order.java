package com.ecommerce.order;

import java.util.ArrayList;
import java.util.List;

public class Order {
    private String id;
    private List<OrderItem> items;
    
    public Order(String id) {
        this.id = id;
        this.items = new ArrayList<>();
    }
    
    public void addItem(OrderItem item) {
        items.add(item);
    }
    
    public String getId() {
        return id;
    }
    
    public List<OrderItem> getItems() {
        return items;
    }
}