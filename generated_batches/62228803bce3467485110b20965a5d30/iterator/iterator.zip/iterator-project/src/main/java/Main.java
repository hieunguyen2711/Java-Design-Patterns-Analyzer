package ecommerce.order;

public class Main {
    public static void main(String[] args) {
        OrderManager manager = new OrderManager();
        
        manager.addOrder("ORD001", 299.99);
        manager.addOrder("ORD002", 149.50);
        manager.addOrder("ORD003", 89.99);
        
        manager.processOrders();
    }
}