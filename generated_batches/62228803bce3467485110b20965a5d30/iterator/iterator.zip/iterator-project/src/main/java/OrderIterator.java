package ecommerce.order;

import java.util.Iterator;

public class OrderIterator implements Iterator<Order> {
    private Order[] orders;
    private int currentIndex = 0;
    
    public OrderIterator(Order[] orders) {
        this.orders = orders;
    }
    
    @Override
    public boolean hasNext() {
        return currentIndex < orders.length && orders[currentIndex] != null;
    }
    
    @Override
    public Order next() {
        Order order = orders[currentIndex];
        currentIndex++;
        return order;
    }
}