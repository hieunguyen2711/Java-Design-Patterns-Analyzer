package ecommerce.order;

import java.util.Iterator;

public class OrderCollection implements Iterable<Order> {
    private Order[] orders;
    private int size;
    
    public OrderCollection(int capacity) {
        this.orders = new Order[capacity];
        this.size = 0;
    }
    
    public void addOrder(Order order) {
        if (size < orders.length) {
            orders[size++] = order;
        }
    }
    
    @Override
    public Iterator<Order> iterator() {
        return new OrderIterator(orders);
    }
}