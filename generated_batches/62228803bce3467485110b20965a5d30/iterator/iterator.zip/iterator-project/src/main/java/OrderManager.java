package ecommerce.order;

public class OrderManager {
    private OrderCollection orders;
    
    public OrderManager() {
        this.orders = new OrderCollection(10);
    }
    
    public void addOrder(String orderId, double amount) {
        orders.addOrder(new Order(orderId, amount));
    }
    
    public void processOrders() {
        System.out.println("Processing all orders:");
        for (Order order : orders) {
            System.out.println("Order ID: " + order.getOrderId() + 
                             ", Amount: $" + order.getTotalAmount());
        }
    }
}