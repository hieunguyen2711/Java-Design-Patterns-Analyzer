package com.ecommerce.order.validator;

import com.ecommerce.order.model.Order;
import java.math.BigDecimal;
import java.util.List;

public class OrderValidator {
    
    public boolean validate(Order order) {
        if (order == null) return false;
        if (order.getItems() == null || order.getItems().isEmpty()) return false;
        if (order.getTotalAmount() == null || order.getTotalAmount().compareTo(BigDecimal.ZERO) <= 0) return false;
        if (order.getStatus() == null || order.getStatus().trim().isEmpty()) return false;
        
        // Validate each item
        for (OrderItem item : order.getItems()) {
            if (item.getProductId() == null || item.getQuantity() == null || 
                item.getPrice() == null || item.getPrice().compareTo(BigDecimal.ZERO) <= 0) {
                return false;
            }
        }
        
        return true;
    }
}