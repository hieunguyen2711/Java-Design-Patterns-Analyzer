package com.ecommerce.order;

import com.ecommerce.order.model.Order;
import com.ecommerce.order.model.OrderItem;
import com.ecommerce.order.repository.OrderRepository;
import com.ecommerce.order.service.OrderService;
import com.ecommerce.order.validator.OrderValidator;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;

public class OrderServiceApplication {
    public static void main(String[] args) {
        // Setup dependencies
        OrderRepository orderRepository = new OrderRepository();
        OrderValidator orderValidator = new OrderValidator();
        OrderService orderService = new OrderService(orderRepository, orderValidator);

        // Create test order
        OrderItem item1 = new OrderItem(1L, 2, new BigDecimal("29.99"));
        OrderItem item2 = new OrderItem(2L, 1, new BigDecimal("19.99"));
        
        Order order = new Order();
        order.setItems(Arrays.asList(item1, item2));
        order.setTotalAmount(new BigDecimal("79.97"));
        order.setStatus("PENDING");
        order.setCreatedAt(LocalDateTime.now());

        // Process order through service layer
        Order createdOrder = orderService.createOrder(order);
        System.out.println("Created order with ID: " + createdOrder.getId());
        
        // Retrieve order
        Order retrievedOrder = orderService.getOrderById(createdOrder.getId());
        System.out.println("Retrieved order status: " + retrievedOrder.getStatus());
    }
}