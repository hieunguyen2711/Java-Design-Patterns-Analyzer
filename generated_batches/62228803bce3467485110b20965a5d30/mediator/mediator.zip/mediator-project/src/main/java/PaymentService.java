public class PaymentService {
    private Mediator mediator;
    
    public PaymentService(Mediator mediator) {
        this.mediator = mediator;
    }
    
    public void processPayment(Order order) {
        System.out.println("Processing payment for order: " + order.getOrderId());
        // Simulate payment processing
        mediator.notify(this, "paymentProcessed", order);
    }
}