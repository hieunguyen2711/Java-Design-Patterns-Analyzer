public class NotificationService {
    private Mediator mediator;
    
    public NotificationService(Mediator mediator) {
        this.mediator = mediator;
    }
    
    public void sendNotification(Order order) {
        System.out.println("Sending notification for order: " + order.getOrderId());
        // Simulate sending notification
        mediator.notify(this, "notificationSent", order);
    }
}