public class ShippingService {
    private Mediator mediator;
    
    public ShippingService(Mediator mediator) {
        this.mediator = mediator;
    }
    
    public void shipOrder(Order order) {
        System.out.println("Shipping order: " + order.getOrderId());
        // Simulate shipping
        mediator.notify(this, "orderShipped", order);
    }
}