public class OrderManagementSystem implements Mediator {
    private PaymentService paymentService;
    private ShippingService shippingService;
    private NotificationService notificationService;
    
    public OrderManagementSystem() {
        this.paymentService = new PaymentService(this);
        this.shippingService = new ShippingService(this);
        this.notificationService = new NotificationService(this);
    }
    
    public void processOrder(Order order) {
        System.out.println("Starting order processing for: " + order.getOrderId());
        paymentService.processPayment(order);
    }
    
    @Override
    public void notify(Object sender, String event, Order order) {
        System.out.println(sender.getClass().getSimpleName() + " triggered " + event);
        
        if ("paymentProcessed".equals(event)) {
            shippingService.shipOrder(order);
        } else if ("orderShipped".equals(event)) {
            notificationService.sendNotification(order);
        } else if ("notificationSent".equals(event)) {
            System.out.println("Order processing completed for: " + order.getOrderId());
        }
    }
}