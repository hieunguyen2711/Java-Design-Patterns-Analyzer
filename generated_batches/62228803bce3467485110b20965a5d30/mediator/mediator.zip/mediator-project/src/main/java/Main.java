public class Main {
    public static void main(String[] args) {
        OrderManagementSystem system = new OrderManagementSystem();
        Order order = new Order("ORD-12345", 99.99);
        system.processOrder(order);
    }
}