package ecommerce.order;

import java.util.function.Function;
import java.util.function.Supplier;

public class ProcessResult {
    private final String message;
    private final boolean shouldContinue;
    private final Order order;
    
    public ProcessResult(String message, boolean shouldContinue, Order order) {
        this.message = message;
        this.shouldContinue = shouldContinue;
        this.order = order;
    }
    
    public ProcessResult next(Supplier<ProcessResult> nextStep) {
        if (shouldContinue) {
            return nextStep.get();
        }
        return this;
    }
    
    // Getters for testing
    public String getMessage() { return message; }
    public boolean shouldContinue() { return shouldContinue; }
    public Order getOrder() { return order; }
}