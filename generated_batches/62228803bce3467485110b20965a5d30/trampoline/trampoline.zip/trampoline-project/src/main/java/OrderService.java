package ecommerce.order;

import java.util.function.Function;

public class OrderService {
    private final PaymentProcessor paymentProcessor;
    private final InventoryProcessor inventoryProcessor;
    
    public OrderService(PaymentProcessor paymentProcessor, 
                       InventoryProcessor inventoryProcessor) {
        this.paymentProcessor = paymentProcessor;
        this.inventoryProcessor = inventoryProcessor;
    }
    
    public ProcessResult processOrder(Order order) {
        // Trampoline pattern: return continuation functions instead of direct results
        Function<Order, ProcessResult> trampoline = (o) -> 
            new ProcessResult("Checking inventory", true, o);
        
        return trampoline.apply(order).next(
            () -> inventoryProcessor.checkInventory(order)
        ).next(
            () -> paymentProcessor.processPayment(order)
        );
    }
}