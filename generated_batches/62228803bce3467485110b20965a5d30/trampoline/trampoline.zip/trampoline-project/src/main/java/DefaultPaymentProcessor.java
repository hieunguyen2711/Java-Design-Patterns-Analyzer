package ecommerce.order;

public class DefaultPaymentProcessor implements PaymentProcessor {
    @Override
    public ProcessResult processPayment(Order order) {
        // Simulate payment processing
        return new ProcessResult("Payment processed successfully", false, order);
    }
}