package ecommerce.order;

public class DefaultInventoryProcessor implements InventoryProcessor {
    @Override
    public ProcessResult checkInventory(Order order) {
        // Simulate inventory check
        return new ProcessResult("Inventory checked successfully", true, order);
    }
}