package ecommerce.order;

public interface PaymentProcessor {
    ProcessResult processPayment(Order order);
}