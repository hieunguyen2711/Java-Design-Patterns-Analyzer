package ecommerce.order;

public class Order {
    private final String orderId;
    private final double amount;
    
    public Order(String orderId, double amount) {
        this.orderId = orderId;
        this.amount = amount;
    }
    
    // Getters for testing
    public String getOrderId() { return orderId; }
    public double getAmount() { return amount; }
}