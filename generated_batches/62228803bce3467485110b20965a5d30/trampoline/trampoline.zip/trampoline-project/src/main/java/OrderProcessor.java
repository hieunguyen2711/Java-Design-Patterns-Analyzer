package ecommerce.order;

public interface OrderProcessor {
    ProcessResult process(Order order);
}