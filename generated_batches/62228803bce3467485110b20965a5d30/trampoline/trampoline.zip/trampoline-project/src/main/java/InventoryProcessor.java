package ecommerce.order;

public interface InventoryProcessor {
    ProcessResult checkInventory(Order order);
}