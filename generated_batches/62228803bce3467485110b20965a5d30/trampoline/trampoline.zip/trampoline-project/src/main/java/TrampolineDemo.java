package ecommerce.order;

public class TrampolineDemo {
    public static void main(String[] args) {
        Order order = new Order("ORD-123", 99.99);
        
        PaymentProcessor paymentProcessor = new DefaultPaymentProcessor();
        InventoryProcessor inventoryProcessor = new DefaultInventoryProcessor();
        
        OrderService service = new OrderService(paymentProcessor, inventoryProcessor);
        ProcessResult result = service.processOrder(order);
        
        System.out.println("Final result: " + result.getMessage());
    }
}