package com.example.order;

import java.util.Optional;
import java.util.function.Function;

public class OrderMonad {
    
    public static void main(String[] args) {
        OrderProcessor processor = new OrderProcessor();
        
        // Using Optional as a monad to chain operations safely
        String orderId = "ORD-123";
        
        Optional<Order> result = Optional.of(orderId)
            .flatMap(processor::processOrder)
            .flatMap(processor::calculateDiscount)
            .flatMap(discount -> processor.applyDiscount(
                processor.processOrder(orderId).orElse(null), discount));
        
        result.ifPresent(order -> 
            System.out.println("Final order amount: " + order.getAmount()));
    }
}