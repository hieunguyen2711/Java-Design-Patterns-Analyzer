package com.example.order;

import java.util.Optional;
import java.util.function.Function;

public class OrderProcessor {
    
    public Optional<Order> processOrder(String orderId) {
        // Simulate order processing that might fail
        if (orderId == null || orderId.isEmpty()) {
            return Optional.empty();
        }
        
        return Optional.of(new Order(orderId, 100.0));
    }
    
    public Optional<Double> calculateDiscount(Order order) {
        if (order == null) {
            return Optional.empty();
        }
        
        double discount = order.getAmount() * 0.1;
        return Optional.of(discount);
    }
    
    public Optional<Order> applyDiscount(Order order, Double discount) {
        if (order == null || discount == null) {
            return Optional.empty();
        }
        
        double finalAmount = order.getAmount() - discount;
        return Optional.of(new Order(order.getOrderId(), finalAmount));
    }
}