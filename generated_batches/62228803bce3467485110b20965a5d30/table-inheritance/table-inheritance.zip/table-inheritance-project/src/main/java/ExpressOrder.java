package ecommerce.order;

public class ExpressOrder extends Order {
    
    private boolean rushDelivery;
    
    public ExpressOrder(String orderId, double totalAmount) {
        super(orderId, totalAmount);
        this.rushDelivery = true;
    }
    
    @Override
    public void processOrder() {
        System.out.println("Processing express order: " + orderId + 
                          " with amount: $" + totalAmount + 
                          " (rush delivery: " + rushDelivery + ")");
    }
}