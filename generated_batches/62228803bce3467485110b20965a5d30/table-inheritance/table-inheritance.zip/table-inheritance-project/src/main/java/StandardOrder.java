package ecommerce.order;

public class StandardOrder extends Order {
    
    public StandardOrder(String orderId, double totalAmount) {
        super(orderId, totalAmount);
    }
    
    @Override
    public void processOrder() {
        System.out.println("Processing standard order: " + orderId + 
                          " with amount: $" + totalAmount);
    }
}