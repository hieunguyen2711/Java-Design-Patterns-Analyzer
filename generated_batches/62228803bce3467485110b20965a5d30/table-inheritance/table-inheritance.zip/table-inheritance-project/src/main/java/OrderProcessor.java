package ecommerce.order;

public class OrderProcessor {
    
    public static void main(String[] args) {
        Order standardOrder = OrderFactory.createOrder("standard", "ORD001", 299.99);
        Order expressOrder = OrderFactory.createOrder("express", "EXP001", 499.99);
        
        standardOrder.processOrder();
        expressOrder.processOrder();
    }
}