public class OrderMessage {
    private final MessageType type;
    private final Order order;
    private final String status;
    
    public OrderMessage(MessageType type, Order order) {
        this.type = type;
        this.order = order;
        this.status = null;
    }
    
    public OrderMessage(MessageType type, Order order, String status) {
        this.type = type;
        this.order = order;
        this.status = status;
    }
    
    public MessageType getType() {
        return type;
    }
    
    public Order getOrder() {
        return order;
    }
    
    public String getStatus() {
        return status;
    }
}