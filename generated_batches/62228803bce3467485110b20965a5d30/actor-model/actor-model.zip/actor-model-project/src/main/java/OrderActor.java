import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class OrderActor {
    private final BlockingQueue<OrderMessage> messageQueue = new LinkedBlockingQueue<>();
    private volatile boolean running = true;
    
    public void send(OrderMessage message) {
        try {
            messageQueue.put(message);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
    
    public void start() {
        new Thread(() -> {
            while (running) {
                try {
                    OrderMessage message = messageQueue.take();
                    processMessage(message);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }).start();
    }
    
    private void processMessage(OrderMessage message) {
        switch (message.getType()) {
            case CREATE:
                System.out.println("Creating order: " + message.getOrder().getId());
                break;
            case UPDATE_STATUS:
                System.out.println("Updating status for order: " + message.getOrder().getId() + 
                                 " to " + message.getStatus());
                break;
            case CANCEL:
                System.out.println("Canceling order: " + message.getOrder().getId());
                break;
        }
    }
    
    public void stop() {
        running = false;
    }
}