public class OrderManagementSystem {
    private final OrderActor orderActor = new OrderActor();
    
    public static void main(String[] args) {
        OrderManagementSystem system = new OrderManagementSystem();
        system.start();
        
        // Simulate sending messages to the actor
        Order order1 = new Order("ORD-001", 299.99);
        Order order2 = new Order("ORD-002", 149.50);
        
        system.orderActor.send(new OrderMessage(MessageType.CREATE, order1));
        system.orderActor.send(new OrderMessage(MessageType.UPDATE_STATUS, order1, "SHIPPED"));
        system.orderActor.send(new OrderMessage(MessageType.CREATE, order2));
        system.orderActor.send(new OrderMessage(MessageType.CANCEL, order2));
        
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        system.stop();
    }
    
    public void start() {
        orderActor.start();
    }
    
    public void stop() {
        orderActor.stop();
    }
}