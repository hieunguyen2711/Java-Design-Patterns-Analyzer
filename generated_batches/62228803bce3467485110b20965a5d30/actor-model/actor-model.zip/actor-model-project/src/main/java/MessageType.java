public enum MessageType {
    CREATE,
    UPDATE_STATUS,
    CANCEL
}