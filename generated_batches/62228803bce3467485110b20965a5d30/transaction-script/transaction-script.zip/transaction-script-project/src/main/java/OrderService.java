public class OrderService {
    private OrderRepository orderRepository;
    private PaymentProcessor paymentProcessor;
    private InventoryManager inventoryManager;
    
    public OrderService() {
        this.orderRepository = new OrderRepository();
        this.paymentProcessor = new PaymentProcessor();
        this.inventoryManager = new InventoryManager();
    }
    
    // Transaction script method - all steps in one method
    public boolean processOrder(int orderId, String customerName, double amount, String paymentMethod) {
        try {
            // Step 1: Validate order
            if (orderId <= 0 || amount <= 0) {
                System.out.println("Invalid order data");
                return false;
            }
            
            // Step 2: Check inventory availability
            if (!inventoryManager.checkInventory(amount)) {
                System.out.println("Insufficient inventory");
                return false;
            }
            
            // Step 3: Process payment
            if (!paymentProcessor.processPayment(amount, paymentMethod)) {
                System.out.println("Payment processing failed");
                return false;
            }
            
            // Step 4: Create order record
            Order newOrder = new Order(orderId, customerName, amount);
            orderRepository.save(newOrder);
            
            // Step 5: Update inventory
            inventoryManager.updateInventory(amount);
            
            System.out.println("Order processed successfully");
            return true;
        } catch (Exception e) {
            System.out.println("Error processing order: " + e.getMessage());
            return false;
        }
    }
}