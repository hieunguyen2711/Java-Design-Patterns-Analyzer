public class PaymentProcessor {
    public boolean processPayment(double amount, String paymentMethod) {
        // Simulate payment processing
        System.out.println("Processing payment of $" + amount + " via " + paymentMethod);
        return true; // Assume all payments succeed for this example
    }
}