public class OrderRepository {
    public void save(Order order) {
        // Simulate saving to database
        System.out.println("Saving order " + order.getOrderId() + " for customer " + 
                          order.getCustomerName() + " with amount $" + order.getTotalAmount());
    }
}