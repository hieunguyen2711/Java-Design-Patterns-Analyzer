public class Main {
    public static void main(String[] args) {
        OrderService orderService = new OrderService();
        
        // Process a sample order using transaction script pattern
        boolean success = orderService.processOrder(101, "John Doe", 250.0, "credit_card");
        
        if (success) {
            System.out.println("Order successfully processed!");
        } else {
            System.out.println("Order processing failed!");
        }
    }
}