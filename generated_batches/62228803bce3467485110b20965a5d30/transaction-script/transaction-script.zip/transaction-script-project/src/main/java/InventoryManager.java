public class InventoryManager {
    private double currentInventory = 1000.0;
    
    public boolean checkInventory(double requiredAmount) {
        System.out.println("Checking inventory for " + requiredAmount);
        return currentInventory >= requiredAmount;
    }
    
    public void updateInventory(double amount) {
        currentInventory -= amount;
        System.out.println("Updated inventory to " + currentInventory);
    }
}