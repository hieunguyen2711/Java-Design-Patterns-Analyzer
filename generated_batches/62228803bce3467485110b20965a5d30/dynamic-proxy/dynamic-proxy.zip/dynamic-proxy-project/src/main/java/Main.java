public class Main {
    public static void main(String[] args) {
        OrderService orderService = OrderServiceProxy.createOrderService();
        orderService.processOrder("ORD-123");
    }
}