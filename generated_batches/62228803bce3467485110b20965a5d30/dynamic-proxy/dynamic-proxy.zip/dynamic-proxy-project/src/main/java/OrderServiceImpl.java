public class OrderServiceImpl implements OrderService {
    @Override
    public void processOrder(String orderId) {
        System.out.println("Processing order: " + orderId);
    }
}