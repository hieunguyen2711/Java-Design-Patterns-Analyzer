import java.lang.reflect.Proxy;

public class OrderServiceProxy {
    public static OrderService createOrderService() {
        OrderService target = new OrderServiceImpl();
        return (OrderService) Proxy.newProxyInstance(
            OrderService.class.getClassLoader(),
            new Class[]{OrderService.class},
            new LoggingHandler(target)
        );
    }
}