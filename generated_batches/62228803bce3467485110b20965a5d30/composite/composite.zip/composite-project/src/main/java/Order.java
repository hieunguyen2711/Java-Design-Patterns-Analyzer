package ecommerce.order;

import java.util.ArrayList;
import java.util.List;

public class Order implements OrderComponent {
    private String orderId;
    private List<OrderComponent> items;
    
    public Order(String orderId) {
        this.orderId = orderId;
        this.items = new ArrayList<>();
    }
    
    @Override
    public double getPrice() {
        double total = 0.0;
        for (OrderComponent item : items) {
            total += item.getPrice();
        }
        return total;
    }
    
    @Override
    public void add(OrderComponent component) {
        items.add(component);
    }
    
    @Override
    public void remove(OrderComponent component) {
        items.remove(component);
    }
    
    @Override
    public void display(int depth) {
        StringBuilder indent = new StringBuilder();
        for (int i = 0; i < depth; i++) {
            indent.append("  ");
        }
        System.out.println(indent + "Order: " + orderId + " - Total: $" + getPrice());
        for (OrderComponent item : items) {
            item.display(depth + 1);
        }
    }
}