package ecommerce.order;

public interface OrderComponent {
    double getPrice();
    void add(OrderComponent component);
    void remove(OrderComponent component);
    void display(int depth);
}