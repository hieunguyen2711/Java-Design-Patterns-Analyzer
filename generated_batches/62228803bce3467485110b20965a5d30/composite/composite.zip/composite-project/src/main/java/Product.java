package ecommerce.order;

public class Product implements OrderComponent {
    private String name;
    private double price;
    
    public Product(String name, double price) {
        this.name = name;
        this.price = price;
    }
    
    @Override
    public double getPrice() {
        return price;
    }
    
    @Override
    public void add(OrderComponent component) {
        // Products cannot have children
    }
    
    @Override
    public void remove(OrderComponent component) {
        // Products cannot have children
    }
    
    @Override
    public void display(int depth) {
        StringBuilder indent = new StringBuilder();
        for (int i = 0; i < depth; i++) {
            indent.append("  ");
        }
        System.out.println(indent + name + " - $" + price);
    }
}