package ecommerce.order;

public class OrderManager {
    public static void main(String[] args) {
        // Create order
        Order order = new Order("ORD-001");
        
        // Add individual products
        Product laptop = new Product("Laptop", 999.99);
        Product mouse = new Product("Wireless Mouse", 29.99);
        
        // Create an order item for accessories
        OrderItem accessories = new OrderItem("Accessories");
        accessories.add(mouse);
        
        // Add components to main order
        order.add(laptop);
        order.add(accessories);
        
        // Display the complete order structure
        System.out.println("Order Structure:");
        order.display(0);
    }
}