package ecommerce.order;

import java.util.ArrayList;
import java.util.List;

public class OrderItem implements OrderComponent {
    private String name;
    private List<OrderComponent> components;
    
    public OrderItem(String name) {
        this.name = name;
        this.components = new ArrayList<>();
    }
    
    @Override
    public double getPrice() {
        double total = 0.0;
        for (OrderComponent component : components) {
            total += component.getPrice();
        }
        return total;
    }
    
    @Override
    public void add(OrderComponent component) {
        components.add(component);
    }
    
    @Override
    public void remove(OrderComponent component) {
        components.remove(component);
    }
    
    @Override
    public void display(int depth) {
        StringBuilder indent = new StringBuilder();
        for (int i = 0; i < depth; i++) {
            indent.append("  ");
        }
        System.out.println(indent + name + " - $" + getPrice());
        for (OrderComponent component : components) {
            component.display(depth + 1);
        }
    }
}