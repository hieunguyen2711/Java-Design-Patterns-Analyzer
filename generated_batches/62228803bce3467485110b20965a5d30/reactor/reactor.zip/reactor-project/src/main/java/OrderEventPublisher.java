import java.util.ArrayList;
import java.util.List;

public class OrderEventPublisher {
    private List<OrderEventHandler> handlers = new ArrayList<>();

    public void subscribe(OrderEventHandler handler) {
        handlers.add(handler);
    }

    public void publish(Order order) {
        for (OrderEventHandler handler : handlers) {
            handler.handle(order);
        }
    }
}