public class OrderService {
    private OrderEventPublisher publisher;

    public OrderService() {
        this.publisher = new OrderEventPublisher();
    }

    public void processOrder(Order order) {
        System.out.println("Processing order: " + order.getOrderId());
        publisher.publish(order);
    }

    public void subscribeToEvents(OrderEventHandler handler) {
        publisher.subscribe(handler);
    }
}