@FunctionalInterface
public interface OrderEventHandler {
    void handle(Order order);
}