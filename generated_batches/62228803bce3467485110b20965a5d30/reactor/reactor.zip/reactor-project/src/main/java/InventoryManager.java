public class InventoryManager {
    private OrderEventPublisher publisher;

    public InventoryManager(OrderEventPublisher publisher) {
        this.publisher = publisher;
        this.publisher.subscribe(this::updateInventory);
    }

    private void updateInventory(Order order) {
        System.out.println("Updating inventory for order: " + order.getOrderId());
        try {
            Thread.sleep(500); // Simulate processing time
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        order.setStatus("INVENTORY_UPDATED");
        System.out.println("Inventory updated for order: " + order.getOrderId());
    }
}