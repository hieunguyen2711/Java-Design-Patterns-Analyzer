public class Main {
    public static void main(String[] args) {
        OrderService orderService = new OrderService();
        
        // Subscribe handlers to the event system
        PaymentProcessor paymentProcessor = new PaymentProcessor(orderService);
        InventoryManager inventoryManager = new InventoryManager(orderService);
        
        // Create and process an order
        Order order = new Order("ORD-001", 299.99);
        orderService.processOrder(order);
        
        System.out.println("Final order status: " + order.getStatus());
    }
}