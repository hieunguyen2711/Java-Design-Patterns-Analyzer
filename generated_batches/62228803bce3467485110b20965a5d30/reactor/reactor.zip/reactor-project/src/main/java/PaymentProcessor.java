public class PaymentProcessor {
    private OrderEventPublisher publisher;

    public PaymentProcessor(OrderEventPublisher publisher) {
        this.publisher = publisher;
        this.publisher.subscribe(this::processPayment);
    }

    private void processPayment(Order order) {
        System.out.println("Processing payment for order: " + order.getOrderId());
        try {
            Thread.sleep(1000); // Simulate processing time
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        order.setStatus("PAID");
        System.out.println("Payment processed for order: " + order.getOrderId());
    }
}