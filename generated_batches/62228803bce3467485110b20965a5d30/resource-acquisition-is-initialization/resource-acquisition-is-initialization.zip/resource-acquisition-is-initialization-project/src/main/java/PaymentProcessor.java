package com.ecommerce.order;

public class PaymentProcessor {
    private final Order order;
    
    public PaymentProcessor(Order order) {
        this.order = order;
    }
    
    public void processPayment() {
        System.out.println("Processing payment for order: " + order.getOrderId());
        // Simulate payment processing
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        System.out.println("Payment completed for order: " + order.getOrderId());
    }
}