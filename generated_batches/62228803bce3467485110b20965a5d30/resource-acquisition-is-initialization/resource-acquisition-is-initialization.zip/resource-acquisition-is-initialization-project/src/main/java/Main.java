package com.ecommerce.order;

public class Main {
    public static void main(String[] args) {
        OrderService service = new OrderService();
        
        // Process multiple orders demonstrating RAII pattern
        service.processOrder("ORD-001", 299.99);
        service.processOrder("ORD-002", 149.50);
    }
}