package com.ecommerce.order;

public class OrderService {
    
    public void processOrder(String orderId, double amount) {
        Order order = new Order(orderId, amount);
        
        // RAII pattern in action - resource (PaymentProcessor) acquired and released automatically
        try (PaymentProcessor processor = new PaymentProcessor(order)) {
            processor.processPayment();
        }
    }
}