package ecommerce.order;

import java.math.BigDecimal;
import java.util.List;

public class Order {
    private String orderId;
    private List<OrderItem> items;
    private BigDecimal totalAmount;
    
    public Order(String orderId, List<OrderItem> items) {
        this.orderId = orderId;
        this.items = items;
        this.totalAmount = items.stream()
                .map(item -> item.getPrice().multiply(BigDecimal.valueOf(item.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    
    public String getOrderId() {
        return orderId;
    }
    
    public List<OrderItem> getItems() {
        return items;
    }
    
    public BigDecimal getTotalAmount() {
        return totalAmount;
    }
}