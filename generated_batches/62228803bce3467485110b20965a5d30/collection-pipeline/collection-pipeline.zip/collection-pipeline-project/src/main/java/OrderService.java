package ecommerce.order;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

public class OrderService {
    
    public static void main(String[] args) {
        // Create sample orders
        List<OrderItem> items1 = Arrays.asList(
            new OrderItem("P001", "Laptop", BigDecimal.valueOf(800), 1),
            new OrderItem("P002", "Mouse", BigDecimal.valueOf(25), 2)
        );
        
        List<OrderItem> items2 = Arrays.asList(
            new OrderItem("P003", "Keyboard", BigDecimal.valueOf(75), 1),
            new OrderItem("P004", "Monitor", BigDecimal.valueOf(300), 1)
        );
        
        List<Order> orders = Arrays.asList(
            new Order("O001", items1),
            new Order("O002", items2)
        );
        
        // Process orders using collection-pipeline pattern
        OrderProcessor processor = new OrderProcessor();
        List<Order> processedOrders = processor.processOrders(orders);
        
        processedOrders.forEach(order -> 
            System.out.println("Order: " + order.getOrderId() + 
                             ", Total: $" + order.getTotalAmount()));
    }
}