package ecommerce.order;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

public class OrderProcessor {
    
    public List<Order> processOrders(List<Order> orders) {
        return orders.stream()
                .filter(order -> order.getTotalAmount().compareTo(BigDecimal.valueOf(100)) > 0)
                .map(this::applyDiscount)
                .sorted((o1, o2) -> o2.getTotalAmount().compareTo(o1.getTotalAmount()))
                .collect(Collectors.toList());
    }
    
    private Order applyDiscount(Order order) {
        BigDecimal discountedAmount = order.getTotalAmount()
                .multiply(BigDecimal.valueOf(0.9));
        
        return new Order(order.getOrderId(), order.getItems()) {
            @Override
            public BigDecimal getTotalAmount() {
                return discountedAmount;
            }
        };
    }
}