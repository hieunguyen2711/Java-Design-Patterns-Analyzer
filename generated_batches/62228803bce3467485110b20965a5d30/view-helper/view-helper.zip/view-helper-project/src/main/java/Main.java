package com.ecommerce.order;

public class Main {
    public static void main(String[] args) {
        // Create an order
        Order order = new Order("ORD-001", 299.99, "pending");
        
        // Process the order
        OrderService service = new OrderService(order);
        service.processOrder();
        
        // Use view helper to format display data
        OrderViewHelper viewHelper = service.getViewHelper();
        
        System.out.println("Order ID: " + order.getOrderId());
        System.out.println("Total Amount: " + viewHelper.getFormattedTotal());
        System.out.println("Status: <span class=\"" + viewHelper.getStatusBadgeClass() + "\">" 
                          + viewHelper.getStatusText() + "</span>");
    }
}