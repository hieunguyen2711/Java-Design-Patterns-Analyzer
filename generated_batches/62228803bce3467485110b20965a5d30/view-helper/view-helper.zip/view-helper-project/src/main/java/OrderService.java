package com.ecommerce.order;

public class OrderService {
    private Order order;
    
    public OrderService(Order order) {
        this.order = order;
    }
    
    public void processOrder() {
        // Simulate order processing logic
        System.out.println("Processing order: " + order.getOrderId());
        order.setStatus("shipped");
    }
    
    public OrderViewHelper getViewHelper() {
        return new OrderViewHelper(order);
    }
}