package com.ecommerce.order;

public class OrderViewHelper {
    private Order order;
    
    public OrderViewHelper(Order order) {
        this.order = order;
    }
    
    public String getFormattedTotal() {
        return "$" + String.format("%.2f", order.getTotalAmount());
    }
    
    public String getStatusBadgeClass() {
        switch (order.getStatus().toLowerCase()) {
            case "pending":
                return "badge-warning";
            case "shipped":
                return "badge-info";
            case "delivered":
                return "badge-success";
            default:
                return "badge-secondary";
        }
    }
    
    public String getStatusText() {
        return order.getStatus().substring(0, 1).toUpperCase() + 
               order.getStatus().substring(1).toLowerCase();
    }
}