import java.util.HashMap;
import java.util.Map;

public class ProductFactory {
    private static final Map<String, Product> productCache = new HashMap<>();
    
    public static Product getProduct(String productId, String name, double price) {
        if (productCache.containsKey(productId)) {
            return productCache.get(productId);
        }
        
        Product product = new Product(productId, name, price);
        productCache.put(productId, product);
        return product;
    }
    
    public static int getCacheSize() {
        return productCache.size();
    }
}