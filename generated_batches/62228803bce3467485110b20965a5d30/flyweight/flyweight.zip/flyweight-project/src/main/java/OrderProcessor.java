public class OrderProcessor {
    public static void main(String[] args) {
        // Creating orders with shared products using flyweight pattern
        Order order1 = new Order("O001", ProductFactory.getProduct("P001", "Laptop", 999.99), 1);
        Order order2 = new Order("O002", ProductFactory.getProduct("P001", "Laptop", 999.99), 2);
        Order order3 = new Order("O003", ProductFactory.getProduct("P002", "Mouse", 29.99), 3);
        Order order4 = new Order("O004", ProductFactory.getProduct("P001", "Laptop", 999.99), 1);
        
        System.out.println("Order 1 Total: $" + order1.getTotalPrice());
        System.out.println("Order 2 Total: $" + order2.getTotalPrice());
        System.out.println("Order 3 Total: $" + order3.getTotalPrice());
        System.out.println("Order 4 Total: $" + order4.getTotalPrice());
        
        System.out.println("Number of unique products in cache: " + ProductFactory.getCacheSize());
    }
}