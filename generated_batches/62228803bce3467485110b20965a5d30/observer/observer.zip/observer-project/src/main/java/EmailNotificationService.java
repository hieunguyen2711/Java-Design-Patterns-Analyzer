package ecommerce.order;

public class EmailNotificationService implements OrderObserver {
    
    @Override
    public void update(Order order) {
        System.out.println("Email sent: Order " + order.getOrderId() + " status updated");
    }
}