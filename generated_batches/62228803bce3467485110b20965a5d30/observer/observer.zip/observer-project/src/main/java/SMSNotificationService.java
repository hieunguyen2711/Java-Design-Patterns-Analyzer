package ecommerce.order;

public class SMSNotificationService implements OrderObserver {
    
    @Override
    public void update(Order order) {
        System.out.println("SMS sent: Order " + order.getOrderId() + " status updated");
    }
}