package ecommerce.order;

import java.util.ArrayList;
import java.util.List;

public class Order {
    private String orderId;
    private List<OrderObserver> observers;
    
    public Order(String orderId) {
        this.orderId = orderId;
        this.observers = new ArrayList<>();
    }
    
    public void attach(OrderObserver observer) {
        observers.add(observer);
    }
    
    public void detach(OrderObserver observer) {
        observers.remove(observer);
    }
    
    public void notifyObservers() {
        for (OrderObserver observer : observers) {
            observer.update(this);
        }
    }
    
    public String getOrderId() {
        return orderId;
    }
}