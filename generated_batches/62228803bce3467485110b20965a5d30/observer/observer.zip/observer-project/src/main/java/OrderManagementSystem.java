package ecommerce.order;

public class OrderManagementSystem {
    public static void main(String[] args) {
        // Create an order
        Order order = new Order("ORD-12345");
        
        // Attach observers
        EmailNotificationService emailService = new EmailNotificationService();
        SMSNotificationService smsService = new SMSNotificationService();
        InventoryService inventoryService = new InventoryService();
        
        order.attach(emailService);
        order.attach(smsService);
        order.attach(inventoryService);
        
        // Notify all observers about the order
        order.notifyObservers();
    }
}