package com.ecommerce.order;

import java.math.BigDecimal;

public class ExpressOrder extends Order {
    private String deliveryAddress;
    private boolean rushDelivery;
    
    public ExpressOrder(String orderId, BigDecimal totalAmount, String deliveryAddress, boolean rushDelivery) {
        super(orderId, totalAmount);
        this.deliveryAddress = deliveryAddress;
        this.rushDelivery = rushDelivery;
    }
    
    @Override
    public void processOrder() {
        System.out.println("Processing express order: " + orderId);
        setStatus(OrderStatus.PROCESSING);
        // Business logic for express orders
    }
    
    public String getDeliveryAddress() {
        return deliveryAddress;
    }
    
    public boolean isRushDelivery() {
        return rushDelivery;
    }
}