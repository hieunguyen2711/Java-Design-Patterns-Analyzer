package com.ecommerce.order;

import java.math.BigDecimal;

public class StandardOrder extends Order {
    private String shippingAddress;
    
    public StandardOrder(String orderId, BigDecimal totalAmount, String shippingAddress) {
        super(orderId, totalAmount);
        this.shippingAddress = shippingAddress;
    }
    
    @Override
    public void processOrder() {
        System.out.println("Processing standard order: " + orderId);
        setStatus(OrderStatus.PROCESSING);
        // Business logic for standard orders
    }
    
    public String getShippingAddress() {
        return shippingAddress;
    }
}