package com.ecommerce.order;

import java.math.BigDecimal;

public class OrderFactory {
    public static Order createOrder(String orderType, String orderId, BigDecimal totalAmount, 
                                  Object... additionalParams) {
        switch (orderType.toLowerCase()) {
            case "standard":
                return new StandardOrder(orderId, totalAmount, (String) additionalParams[0]);
            case "express":
                return new ExpressOrder(orderId, totalAmount, (String) additionalParams[0], 
                                      (Boolean) additionalParams[1]);
            default:
                throw new IllegalArgumentException("Unknown order type: " + orderType);
        }
    }
}