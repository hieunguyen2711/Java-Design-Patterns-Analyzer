package com.ecommerce.order;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class OrderProcessor {
    private List<Order> orders;
    
    public OrderProcessor() {
        this.orders = new ArrayList<>();
    }
    
    public void addOrder(Order order) {
        orders.add(order);
    }
    
    public void processAllOrders() {
        for (Order order : orders) {
            order.processOrder();
        }
    }
    
    public static void main(String[] args) {
        OrderProcessor processor = new OrderProcessor();
        
        // Creating different types of orders using single-table inheritance
        Order standardOrder = OrderFactory.createOrder("standard", "STD001", 
                                                     new BigDecimal("99.99"), 
                                                     "123 Main St");
        Order expressOrder = OrderFactory.createOrder("express", "EXP001", 
                                                    new BigDecimal("149.99"),
                                                    "456 Oak Ave", true);
        
        processor.addOrder(standardOrder);
        processor.addOrder(expressOrder);
        
        processor.processAllOrders();
    }
}