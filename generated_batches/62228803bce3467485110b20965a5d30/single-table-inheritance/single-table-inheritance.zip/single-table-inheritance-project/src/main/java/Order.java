package com.ecommerce.order;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public abstract class Order {
    protected String orderId;
    protected BigDecimal totalAmount;
    protected LocalDateTime orderDate;
    protected OrderStatus status;
    
    public Order(String orderId, BigDecimal totalAmount) {
        this.orderId = orderId;
        this.totalAmount = totalAmount;
        this.orderDate = LocalDateTime.now();
        this.status = OrderStatus.PENDING;
    }
    
    public abstract void processOrder();
    
    public String getOrderId() {
        return orderId;
    }
    
    public BigDecimal getTotalAmount() {
        return totalAmount;
    }
    
    public LocalDateTime getOrderDate() {
        return orderDate;
    }
    
    public OrderStatus getStatus() {
        return status;
    }
    
    public void setStatus(OrderStatus status) {
        this.status = status;
    }
}