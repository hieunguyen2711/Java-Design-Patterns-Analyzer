import java.util.HashMap;
import java.util.Map;

public class OrderService {
    private static final Map<String, OrderService> instances = new HashMap<>();
    private final String region;
    
    private OrderService(String region) {
        this.region = region;
    }
    
    public static OrderService getInstance(String region) {
        return instances.computeIfAbsent(region, OrderService::new);
    }
    
    public void process(String orderId) {
        System.out.println("Processing order " + orderId + " in region: " + region);
    }
}