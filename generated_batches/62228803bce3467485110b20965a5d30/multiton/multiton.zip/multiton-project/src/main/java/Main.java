public class Main {
    public static void main(String[] args) {
        OrderProcessor processor = new OrderProcessor();
        
        // Process orders in different regions
        processor.processOrder("ORD-001", "US");
        processor.processOrder("ORD-002", "EU");
        processor.processOrder("ORD-003", "US");  // Should reuse existing instance
        
        // Process default order
        processor.processDefaultOrder("ORD-004");
    }
}