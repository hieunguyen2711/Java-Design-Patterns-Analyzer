public class OrderProcessor {
    private static final String DEFAULT_REGION = "DEFAULT";
    
    public void processOrder(String orderId, String region) {
        OrderService service = OrderService.getInstance(region);
        service.process(orderId);
    }
    
    public void processDefaultOrder(String orderId) {
        OrderService service = OrderService.getInstance(DEFAULT_REGION);
        service.process(orderId);
    }
}