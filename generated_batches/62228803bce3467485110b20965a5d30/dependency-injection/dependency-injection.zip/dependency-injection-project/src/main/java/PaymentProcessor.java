package com.ecommerce.order;

public interface PaymentProcessor {
    boolean processPayment(double amount);
}