package com.ecommerce.order;

public class OrderService {
    private final PaymentProcessor paymentProcessor;
    
    public OrderService(PaymentProcessor paymentProcessor) {
        this.paymentProcessor = paymentProcessor;
    }
    
    public boolean processOrder(Order order) {
        return paymentProcessor.processPayment(order.getAmount());
    }
}