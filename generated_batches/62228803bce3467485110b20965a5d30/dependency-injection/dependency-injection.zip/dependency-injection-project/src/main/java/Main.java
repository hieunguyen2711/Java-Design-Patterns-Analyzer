package com.ecommerce.order;

public class Main {
    public static void main(String[] args) {
        // Dependency injection in action - injecting different payment processors
        PaymentProcessor creditCardProcessor = new CreditCardProcessor();
        OrderService orderService1 = new OrderService(creditCardProcessor);
        
        PaymentProcessor payPalProcessor = new PayPalProcessor();
        OrderService orderService2 = new OrderService(payPalProcessor);
        
        Order order1 = new Order(100.0);
        Order order2 = new Order(250.0);
        
        orderService1.processOrder(order1);
        orderService2.processOrder(order2);
    }
}