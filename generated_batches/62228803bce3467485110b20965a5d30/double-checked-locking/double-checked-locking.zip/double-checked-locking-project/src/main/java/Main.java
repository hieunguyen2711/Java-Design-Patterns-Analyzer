package com.ecommerce.order;

public class Main {
    public static void main(String[] args) {
        OrderProcessor processor1 = new OrderProcessor();
        OrderProcessor processor2 = new OrderProcessor();
        
        processor1.handleOrder("ORD-001");
        processor2.handleOrder("ORD-002");
        
        System.out.println("Singleton instance check: " + 
            (processor1.getOrderService() == processor2.getOrderService()));
    }
    
    private static class OrderProcessor {
        private final OrderService orderService;
        
        public OrderProcessor() {
            this.orderService = OrderService.getInstance();
        }
        
        public OrderService getOrderService() {
            return orderService;
        }
        
        public void handleOrder(String orderId) {
            orderService.processOrder(orderId);
        }
    }
}