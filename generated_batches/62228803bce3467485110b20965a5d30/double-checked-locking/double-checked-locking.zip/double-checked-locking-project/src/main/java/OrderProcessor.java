package com.ecommerce.order;

public class OrderProcessor {
    private final OrderService orderService;
    
    public OrderProcessor() {
        this.orderService = OrderService.getInstance();
    }
    
    public void handleOrder(String orderId) {
        orderService.processOrder(orderId);
    }
}