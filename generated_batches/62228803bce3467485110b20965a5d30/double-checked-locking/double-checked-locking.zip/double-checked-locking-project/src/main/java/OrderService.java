package com.ecommerce.order;

public class OrderService {
    private static volatile OrderService instance;
    
    private OrderService() {
        // Private constructor to prevent instantiation
    }
    
    public static OrderService getInstance() {
        if (instance == null) {
            synchronized (OrderService.class) {
                if (instance == null) {
                    instance = new OrderService();
                }
            }
        }
        return instance;
    }
    
    public void processOrder(String orderId) {
        System.out.println("Processing order: " + orderId);
    }
}