public class ExpressOrder extends Order {
    public ExpressOrder(PaymentProcessor paymentProcessor) {
        super(paymentProcessor);
    }
    
    @Override
    public void processOrder() {
        System.out.println("Processing express order");
        paymentProcessor.processPayment(150.0);
    }
}