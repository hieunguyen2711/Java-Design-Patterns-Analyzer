public class StandardOrder extends Order {
    public StandardOrder(PaymentProcessor paymentProcessor) {
        super(paymentProcessor);
    }
    
    @Override
    public void processOrder() {
        System.out.println("Processing standard order");
        paymentProcessor.processPayment(100.0);
    }
}