public class OrderManager {
    public static void main(String[] args) {
        // Using bridge pattern to separate order processing from payment methods
        Order standardOrder = new StandardOrder(new CreditCardPaymentProcessor());
        Order expressOrder = new ExpressOrder(new DigitalWalletPaymentProcessor());
        
        standardOrder.processOrder();
        expressOrder.processOrder();
    }
}