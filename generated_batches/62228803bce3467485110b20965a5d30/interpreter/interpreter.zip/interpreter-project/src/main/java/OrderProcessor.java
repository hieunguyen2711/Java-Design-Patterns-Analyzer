public class OrderProcessor {
    public static void main(String[] args) {
        // Create expressions for order validation
        Expression orderNumber = new NumberExpression(12345);
        Expression customerName = new NumberExpression(67890);
        Expression hasItems = new NumberExpression(500);
        
        // Combine expressions with logical operators
        Expression complexExpression = new AndExpression(
            new OrExpression(orderNumber, customerName),
            hasItems
        );
        
        // Test the interpreter pattern
        String orderContext = "Order 12345 for customer 67890 contains 500 items";
        System.out.println("Order valid: " + complexExpression.interpret(orderContext));
    }
}