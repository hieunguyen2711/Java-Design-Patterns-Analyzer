public class NumberExpression implements Expression {
    private int number;
    
    public NumberExpression(int number) {
        this.number = number;
    }
    
    @Override
    public boolean interpret(String context) {
        return context.contains(String.valueOf(number));
    }
}