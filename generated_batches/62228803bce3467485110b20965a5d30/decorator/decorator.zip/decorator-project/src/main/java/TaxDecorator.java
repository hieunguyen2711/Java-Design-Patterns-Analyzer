public class TaxDecorator extends OrderDecorator {
    private double taxRate;
    
    public TaxDecorator(Order order, double taxRate) {
        super(order);
        this.taxRate = taxRate;
    }
    
    @Override
    public double getTotalPrice() {
        return order.getTotalPrice() * (1 + taxRate);
    }
    
    @Override
    public String getDescription() {
        return order.getDescription() + " + Tax";
    }
}