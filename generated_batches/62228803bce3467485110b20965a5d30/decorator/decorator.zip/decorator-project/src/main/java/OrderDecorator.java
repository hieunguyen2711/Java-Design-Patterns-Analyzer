public abstract class OrderDecorator implements Order {
    protected Order order;
    
    public OrderDecorator(Order order) {
        this.order = order;
    }
    
    @Override
    public double getTotalPrice() {
        return order.getTotalPrice();
    }
    
    @Override
    public String getDescription() {
        return order.getDescription();
    }
}