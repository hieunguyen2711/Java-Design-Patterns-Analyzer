public class ShippingDecorator extends OrderDecorator {
    private double shippingCost;
    
    public ShippingDecorator(Order order, double shippingCost) {
        super(order);
        this.shippingCost = shippingCost;
    }
    
    @Override
    public double getTotalPrice() {
        return order.getTotalPrice() + shippingCost;
    }
    
    @Override
    public String getDescription() {
        return order.getDescription() + " + Shipping";
    }
}