public class OrderProcessor {
    public static void main(String[] args) {
        Order basicOrder = new BasicOrder(100.0, "Basic Order");
        
        Order decoratedOrder = new TaxDecorator(
            new ShippingDecorator(basicOrder, 10.0), 
            0.08
        );
        
        System.out.println("Description: " + decoratedOrder.getDescription());
        System.out.println("Total Price: $" + decoratedOrder.getTotalPrice());
    }
}