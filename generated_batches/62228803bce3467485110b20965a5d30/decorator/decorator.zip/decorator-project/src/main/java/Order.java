public interface Order {
    double getTotalPrice();
    String getDescription();
}