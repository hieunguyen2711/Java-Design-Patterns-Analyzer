package com.ecommerce.order;

public class OrderService {
    
    public Order createOrderFromTemplate(String templateType, String customerId, double amount) {
        // Get a prototype order and customize it
        Order order = OrderPrototypeRegistry.getPrototype(templateType);
        
        // Customize the cloned order
        order.setOrderId(templateType + "-" + customerId);
        order.setCustomerName("Customer " + customerId);
        order.setTotalAmount(amount);
        
        return order;
    }
    
    public static void main(String[] args) {
        OrderService service = new OrderService();
        
        // Create orders using prototypes
        Order standardOrder = service.createOrderFromTemplate("standard", "C001", 125.50);
        Order premiumOrder = service.createOrderFromTemplate("premium", "C002", 300.75);
        Order vipOrder = service.createOrderFromTemplate("vip", "C003", 600.00);
        
        System.out.println("Created Orders:");
        System.out.println(standardOrder);
        System.out.println(premiumOrder);
        System.out.println(vipOrder);
    }
}