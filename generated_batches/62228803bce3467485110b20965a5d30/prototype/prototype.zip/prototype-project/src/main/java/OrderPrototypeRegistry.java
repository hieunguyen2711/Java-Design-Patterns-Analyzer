package com.ecommerce.order;

import java.util.HashMap;
import java.util.Map;

public class OrderPrototypeRegistry {
    private static final Map<String, Order> prototypes = new HashMap<>();
    
    static {
        // Register prototype orders
        prototypes.put("standard", new Order("STD-001", "John Doe", 100.0));
        prototypes.put("premium", new Order("PREM-001", "Jane Smith", 250.0));
        prototypes.put("vip", new Order("VIP-001", "Bob Johnson", 500.0));
    }
    
    public static Order getPrototype(String type) {
        try {
            return prototypes.get(type).clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException("Failed to clone prototype order", e);
        }
    }
    
    public static void registerPrototype(String key, Order prototype) {
        prototypes.put(key, prototype);
    }
}