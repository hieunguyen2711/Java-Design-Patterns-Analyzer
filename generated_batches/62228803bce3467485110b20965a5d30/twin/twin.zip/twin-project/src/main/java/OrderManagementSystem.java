package com.ecommerce.order;

public class OrderManagementSystem {
    private final OrderProcessor orderProcessor;
    private final PaymentService paymentService;
    
    public OrderManagementSystem() {
        this.orderProcessor = OrderProcessor.getInstance();
        this.paymentService = PaymentService.getInstance();
    }
    
    public void handleOrder(String orderId, double amount) {
        Order order = new Order(orderId, amount);
        orderProcessor.processOrder(order);
        paymentService.processPayment(order);
    }
}