package com.ecommerce.order;

public class Order {
    private String orderId;
    private double amount;
    
    public Order(String orderId, double amount) {
        this.orderId = orderId;
        this.amount = amount;
    }
    
    public String getOrderId() {
        return orderId;
    }
    
    public double getAmount() {
        return amount;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        
        Order order = (Order) obj;
        return Double.compare(order.amount, amount) == 0 &&
               orderId.equals(order.orderId);
    }
    
    @Override
    public int hashCode() {
        int result = orderId.hashCode();
        result = 31 * result + (int) amount;
        return result;
    }
}