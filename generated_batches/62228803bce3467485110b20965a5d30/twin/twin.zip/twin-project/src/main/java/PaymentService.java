package com.ecommerce.order;

public class PaymentService {
    private static volatile PaymentService instance;
    
    private PaymentService() {}
    
    public static PaymentService getInstance() {
        if (instance == null) {
            synchronized (PaymentService.class) {
                if (instance == null) {
                    instance = new PaymentService();
                }
            }
        }
        return instance;
    }
    
    public void processPayment(Order order) {
        System.out.println("Processing payment for order: " + order.getOrderId());
    }
}