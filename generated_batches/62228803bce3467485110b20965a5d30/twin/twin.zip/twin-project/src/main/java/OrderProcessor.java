package com.ecommerce.order;

public class OrderProcessor {
    private static volatile OrderProcessor instance;
    
    private OrderProcessor() {}
    
    public static OrderProcessor getInstance() {
        if (instance == null) {
            synchronized (OrderProcessor.class) {
                if (instance == null) {
                    instance = new OrderProcessor();
                }
            }
        }
        return instance;
    }
    
    public void processOrder(Order order) {
        System.out.println("Processing order: " + order.getOrderId() + 
                          " for amount: $" + order.getAmount());
    }
}