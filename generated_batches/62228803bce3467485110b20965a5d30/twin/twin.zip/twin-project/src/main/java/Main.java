package com.ecommerce.order;

public class Main {
    public static void main(String[] args) {
        OrderManagementSystem system = new OrderManagementSystem();
        
        system.handleOrder("ORD001", 299.99);
        system.handleOrder("ORD002", 149.50);
    }
}