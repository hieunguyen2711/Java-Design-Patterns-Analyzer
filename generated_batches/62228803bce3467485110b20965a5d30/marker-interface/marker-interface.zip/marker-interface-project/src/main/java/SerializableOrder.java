package com.ecommerce.order;

public interface SerializableOrder {
    // Marker interface - no methods required
}