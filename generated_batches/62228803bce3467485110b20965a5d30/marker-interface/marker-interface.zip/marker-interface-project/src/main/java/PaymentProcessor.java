package com.ecommerce.order;

public interface PaymentProcessor {
    void processPayment(Order order);
}