package com.ecommerce.order;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        OrderService orderService = new OrderService();
        
        orderService.addOrder(new Order("ORD001", 150.00));
        orderService.addOrder(new Order("ORD002", 275.50));
        
        PaymentProcessor creditCardProcessor = new CreditCardPaymentProcessor();
        PaymentProcessor payPalProcessor = new PayPalPaymentProcessor();
        
        orderService.processPayments(Arrays.asList(creditCardProcessor, payPalProcessor));
    }
}