package com.ecommerce.order;

public class CreditCardPaymentProcessor implements PaymentProcessor, SerializableOrder {
    @Override
    public void processPayment(Order order) {
        System.out.println("Processing credit card payment for order: " + order.getOrderId());
    }
}