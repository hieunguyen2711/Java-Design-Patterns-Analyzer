package com.ecommerce.order;

public class PayPalPaymentProcessor implements PaymentProcessor, SerializableOrder {
    @Override
    public void processPayment(Order order) {
        System.out.println("Processing PayPal payment for order: " + order.getOrderId());
    }
}