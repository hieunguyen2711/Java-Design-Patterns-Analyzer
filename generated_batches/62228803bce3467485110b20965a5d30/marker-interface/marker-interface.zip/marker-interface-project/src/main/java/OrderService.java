package com.ecommerce.order;

import java.util.ArrayList;
import java.util.List;

public class OrderService {
    private List<Order> orders;
    
    public OrderService() {
        this.orders = new ArrayList<>();
    }
    
    public void addOrder(Order order) {
        orders.add(order);
    }
    
    public void processPayments(List<PaymentProcessor> processors) {
        for (Order order : orders) {
            for (PaymentProcessor processor : processors) {
                if (processor instanceof SerializableOrder) {
                    processor.processPayment(order);
                }
            }
        }
    }
}