package com.ecommerce.order.pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class OrderManagementSystem {
    private WebDriver driver;
    private OrderPage orderPage;
    
    public OrderManagementSystem() {
        this.driver = new ChromeDriver();
        this.orderPage = new OrderPage(driver);
    }
    
    public void createNewOrder(String orderId, String customerName, String... products) {
        driver.get("https://ecommerce.example.com/order/new");
        
        orderPage.enterOrderId(orderId);
        orderPage.enterCustomerName(customerName);
        orderPage.selectProducts(products);
        
        System.out.println("Total amount: " + orderPage.getTotalAmount());
        orderPage.submitOrder();
    }
    
    public void close() {
        driver.quit();
    }
}