package com.ecommerce.order.pageobject;

public class OrderService {
    private OrderManagementSystem orderSystem;
    
    public OrderService() {
        this.orderSystem = new OrderManagementSystem();
    }
    
    public void processOrder(String orderId, String customerName, String... products) {
        orderSystem.createNewOrder(orderId, customerName, products);
    }
    
    public void cleanup() {
        orderSystem.close();
    }
}