package ecommerce.order;

public class Main {
    public static void main(String[] args) {
        OrderService service = new OrderService();
        
        // Submit orders to demonstrate double buffering
        service.submitOrder("ORD-001", 150.0);
        System.out.println("Current order: " + service.getCurrentOrder().getOrderId() 
                          + ", Amount: $" + service.getCurrentOrder().getAmount());
        
        service.submitOrder("ORD-002", 200.0);
        System.out.println("Current order: " + service.getCurrentOrder().getOrderId() 
                          + ", Amount: $" + service.getCurrentOrder().getAmount());
    }
}