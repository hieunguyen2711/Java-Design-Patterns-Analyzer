package ecommerce.order;

public class OrderService {
    private OrderProcessor orderProcessor;
    
    public OrderService() {
        this.orderProcessor = new OrderProcessor();
    }
    
    public void submitOrder(String orderId, double amount) {
        Order newOrder = new Order(orderId, amount);
        orderProcessor.processOrder(newOrder);
        
        // Simulate processing
        orderProcessor.swapBuffers();
    }
    
    public Order getCurrentOrder() {
        return orderProcessor.getCurrentOrder();
    }
}