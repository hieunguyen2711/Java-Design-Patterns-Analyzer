package ecommerce.order;

public class OrderProcessor {
    private volatile Order currentOrder;
    private Order pendingOrder;
    
    public OrderProcessor() {
        this.currentOrder = null;
        this.pendingOrder = null;
    }
    
    public void processOrder(Order order) {
        // Double buffering: switch between current and pending buffers
        if (currentOrder == null) {
            currentOrder = order;
        } else {
            pendingOrder = order;
        }
    }
    
    public Order getCurrentOrder() {
        return currentOrder;
    }
    
    public void swapBuffers() {
        if (pendingOrder != null) {
            currentOrder = pendingOrder;
            pendingOrder = null;
        }
    }
}