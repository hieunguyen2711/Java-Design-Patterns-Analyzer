package ecommerce.controller;

import ecommerce.model.Order;
import ecommerce.model.OrderModel;
import ecommerce.view.OrderView;

public class OrderController {
    private OrderModel model;
    private OrderView view;
    
    public OrderController(OrderModel model, OrderView view) {
        this.model = model;
        this.view = view;
    }
    
    public void createOrder(String orderId, double amount) {
        Order order = new Order(orderId, amount);
        model.addOrder(order);
        System.out.println("Order created successfully!");
    }
    
    public void updateOrderStatus(String orderId, String status) {
        model.updateOrderStatus(orderId, status);
        System.out.println("Order status updated successfully!");
    }
    
    public void displayAllOrders() {
        view.displayOrders(model.getAllOrders());
    }
    
    public void displayOrder(String orderId) {
        Order order = model.getOrderById(orderId);
        if (order != null) {
            view.displayOrder(order);
        } else {
            System.out.println("Order not found!");
        }
    }
}