package ecommerce.view;

import ecommerce.model.Order;
import java.util.List;

public class OrderView {
    
    public void displayOrder(Order order) {
        System.out.println("Order ID: " + order.getOrderId());
        System.out.println("Total Amount: $" + order.getTotalAmount());
        System.out.println("Status: " + order.getStatus());
        System.out.println("------------------------");
    }
    
    public void displayOrders(List<Order> orders) {
        System.out.println("=== All Orders ===");
        for (Order order : orders) {
            displayOrder(order);
        }
    }
}