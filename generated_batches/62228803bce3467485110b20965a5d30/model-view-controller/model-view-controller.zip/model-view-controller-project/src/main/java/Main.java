package ecommerce;

import ecommerce.controller.OrderController;
import ecommerce.model.OrderModel;
import ecommerce.view.OrderView;

public class Main {
    public static void main(String[] args) {
        // Create model, view and controller
        OrderModel model = new OrderModel();
        OrderView view = new OrderView();
        OrderController controller = new OrderController(model, view);
        
        // Use the MVC pattern to manage orders
        controller.createOrder("ORD001", 299.99);
        controller.createOrder("ORD002", 149.50);
        
        controller.displayAllOrders();
        
        controller.updateOrderStatus("ORD001", "SHIPPED");
        controller.displayOrder("ORD001");
    }
}