package ecommerce.model;

import java.util.ArrayList;
import java.util.List;

public class OrderModel {
    private List<Order> orders;
    
    public OrderModel() {
        this.orders = new ArrayList<>();
    }
    
    public void addOrder(Order order) {
        orders.add(order);
    }
    
    public List<Order> getAllOrders() {
        return orders;
    }
    
    public Order getOrderById(String orderId) {
        for (Order order : orders) {
            if (order.getOrderId().equals(orderId)) {
                return order;
            }
        }
        return null;
    }
    
    public void updateOrderStatus(String orderId, String status) {
        Order order = getOrderById(orderId);
        if (order != null) {
            order.setStatus(status);
        }
    }
}