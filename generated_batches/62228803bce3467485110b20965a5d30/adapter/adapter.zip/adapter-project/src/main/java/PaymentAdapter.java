public class PaymentAdapter implements PaymentProcessor {
    private CreditCardProcessor creditCardProcessor;
    
    public PaymentAdapter(CreditCardProcessor creditCardProcessor) {
        this.creditCardProcessor = creditCardProcessor;
    }
    
    @Override
    public void processPayment(double amount) {
        creditCardProcessor.authorize(amount);
        creditCardProcessor.charge(amount);
    }
}