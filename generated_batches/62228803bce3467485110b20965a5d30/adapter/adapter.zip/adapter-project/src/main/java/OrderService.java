public class OrderService {
    private PaymentProcessor paymentProcessor;
    
    public OrderService(PaymentProcessor paymentProcessor) {
        this.paymentProcessor = paymentProcessor;
    }
    
    public void processOrder(Order order) {
        System.out.println("Processing order " + order.getOrderId());
        paymentProcessor.processPayment(order.getAmount());
        System.out.println("Order " + order.getOrderId() + " completed");
    }
}