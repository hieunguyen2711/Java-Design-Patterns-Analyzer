public class Main {
    public static void main(String[] args) {
        Order order = new Order("ORD001", 299.99);
        
        CreditCardProcessor creditCardProcessor = new CreditCardProcessor();
        PaymentProcessor paymentAdapter = new PaymentAdapter(creditCardProcessor);
        
        OrderService orderService = new OrderService(paymentAdapter);
        orderService.processOrder(order);
    }
}