public class CreditCardProcessor {
    public void charge(double amount) {
        System.out.println("Charging $" + amount + " to credit card");
    }
    
    public void authorize(double amount) {
        System.out.println("Authorizing $" + amount + " on credit card");
    }
}