import java.util.ArrayList;
import java.util.List;

public class TicketDAOImpl implements TicketDAO {
    private List<Ticket> tickets;
    
    public TicketDAOImpl() {
        this.tickets = new ArrayList<>();
    }
    
    @Override
    public void createTicket(Ticket ticket) {
        tickets.add(ticket);
    }
    
    @Override
    public Ticket getTicketById(int id) {
        for (Ticket ticket : tickets) {
            if (ticket.getId() == id) {
                return ticket;
            }
        }
        return null;
    }
    
    @Override
    public List<Ticket> getAllTickets() {
        return new ArrayList<>(tickets);
    }
    
    @Override
    public void updateTicket(Ticket ticketToUpdate) {
        for (int i =