import java.util.List;

public interface TicketDAO {
    void createTicket(Ticket ticket);
    Ticket getTicketById(int id);
    List<Ticket> getAllTickets();
    void updateTicket(Ticket ticket);
    void deleteTicket(int id);
}