package com.projecttracker.ticket;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TicketMapper {
    
    private Connection connection;
    
    public TicketMapper(Connection connection) {
        this.connection = connection;
    }
    
    public Ticket findById(int id) throws SQLException {
        String sql = "SELECT * FROM tickets WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapRowToTicket(rs);
            }
        }
        return null;
    }
    
    public List<Ticket> findAll() throws SQLException {
        List<Ticket> tickets = new ArrayList<>();
        String sql = "SELECT * FROM tickets";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                tickets.add(mapRowToTicket(rs));
            }
        }
        return tickets;
    }
    
    public void save(Ticket ticket) throws SQLException