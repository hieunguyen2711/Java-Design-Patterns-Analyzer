package com.example.projecttracker;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class TicketCollectionPipeline {
    private List<Ticket> tickets;
    
    public TicketCollectionPipeline(List<Ticket> tickets) {
        this.tickets = new ArrayList<>(tickets);
    }
    
    public List<Ticket> filterByPriority(Priority priority) {
        return tickets.stream()
                .filter(ticket -> ticket.getPriority() == priority)
                .collect(Collectors.toList());
    }
    
    public List<Ticket> filterByStatus(Status status) {
        return tickets.stream()
                .filter(ticket -> ticket.getStatus() == status)
                .collect(Collectors.toList());
    }
    
    public Map<Priority, Long> countTicketsByPriority() {
        return tickets.stream()
                .