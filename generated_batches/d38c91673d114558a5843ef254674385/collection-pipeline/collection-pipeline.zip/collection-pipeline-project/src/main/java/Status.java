package com.example.projecttracker;

public enum Status {
    OPEN, IN_PROGRESS, RESOLVED, CLOSED
}