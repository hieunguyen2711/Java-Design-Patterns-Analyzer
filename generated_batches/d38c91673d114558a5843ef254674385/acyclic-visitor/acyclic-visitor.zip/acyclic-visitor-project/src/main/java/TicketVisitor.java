public interface TicketVisitor {
    void visit(Ticket ticket);
    void visit(Comment comment);
}