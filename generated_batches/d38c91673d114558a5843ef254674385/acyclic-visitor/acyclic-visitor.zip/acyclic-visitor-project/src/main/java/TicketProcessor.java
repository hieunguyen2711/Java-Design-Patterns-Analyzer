public class TicketProcessor implements TicketVisitor {
    @Override
    public void visit(Ticket ticket) {
        System.out.println("Processing ticket: " + ticket.getTitle());
        if (ticket.getPriority() == Priority.HIGH) {
            ticket.setStatus(Status.IN_PROGRESS);
            System.out.println("High priority ticket set to IN_PROGRESS");
        }
    }
    
    @Override
    public void visit(Comment comment) {
        System.out.println("Processing comment from: " + comment.getAuthor());
        if (comment.getText().contains("@admin")) {
            System.out.println("Admin mention detected in comment");
        }
    }
}