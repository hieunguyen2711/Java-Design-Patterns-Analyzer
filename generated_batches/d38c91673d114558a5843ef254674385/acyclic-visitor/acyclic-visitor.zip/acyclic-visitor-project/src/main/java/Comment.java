public class Comment {
    private String text;
    private String author;
    
    public Comment(String text, String author) {
        this.text = text;
        this.author = author;
    }
    
    public void accept(TicketVisitor visitor) {
        visitor.visit(this);
    }
    
    // Getters and setters
    public String getText() { return text; }
    public void setText(String text) { this.text = text; }
    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }
}