public class TicketService {
    private TicketRepository ticketRepository;
    
    public TicketService(TicketRepository ticketRepository) {
        this.ticketRepository = ticketRepository;
    }
    
    // Transaction script for creating a new ticket
    public void createTicket(int id, String title, String description) {
        Ticket ticket = new Ticket(id, title, description);
        ticketRepository.save(ticket);
    }
    
    // Transaction script for assigning a ticket
    public void assignTicket(int ticketId, String assignee) {
        Ticket ticket = ticketRepository.findById(ticketId);
        if (ticket != null) {
            ticket.setAssignee(assignee);
            ticketRepository.update(ticket);
        }
    }
    
    // Transaction script for updating ticket status
    public void updateTicketStatus(int ticketId, String newStatus) {
        Ticket ticket = ticketRepository.findById(ticketId);
        if (ticket != null) {
            ticket.setStatus(newStatus);
            ticketRepository.update(ticket);
        }
    }
    
    // Transaction script for adding comment to a ticket
    public void addComment(int ticketId, String comment) {
        Ticket ticket = ticketRepository.findById(ticketId);
        if (ticket != null