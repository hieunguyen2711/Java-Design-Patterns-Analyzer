public class FeatureTicketFactory implements TicketFactory {
    @Override
    public Ticket createTicket() {
        return new FeatureTicket();
    }
}