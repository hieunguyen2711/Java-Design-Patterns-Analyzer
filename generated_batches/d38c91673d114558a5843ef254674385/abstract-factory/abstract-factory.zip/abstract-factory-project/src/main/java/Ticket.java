public interface Ticket {
    void assign();
    void updateStatus(String status);
    String getStatus();
}