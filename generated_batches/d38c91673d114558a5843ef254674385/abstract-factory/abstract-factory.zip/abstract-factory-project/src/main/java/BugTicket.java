public class BugTicket implements Ticket {
    private String status = "Open";
    
    @Override
    public void assign() {
        System.out.println("Bug ticket assigned to developer");
    }
    
    @Override
    public void updateStatus(String status) {
        this.status = status;
    }
    
    @Override
    public String getStatus() {
        return status;
    }
}