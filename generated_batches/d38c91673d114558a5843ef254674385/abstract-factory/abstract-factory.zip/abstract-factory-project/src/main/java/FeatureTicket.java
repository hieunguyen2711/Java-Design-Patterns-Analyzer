public class FeatureTicket implements Ticket {
    private String status = "Open";
    
    @Override
    public void assign() {
        System.out.println("Feature ticket assigned to product owner");
    }
    
    @Override
    public void updateStatus(String status) {
        this.status = status;
    }
    
    @Override
    public String getStatus() {
        return status;
    }
}