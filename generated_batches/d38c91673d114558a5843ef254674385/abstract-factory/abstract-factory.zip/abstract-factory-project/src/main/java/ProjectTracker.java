public class ProjectTracker {
    public static void main(String[] args) {
        TicketFactory bugFactory = new BugTicketFactory();
        TicketFactory featureFactory = new FeatureTicketFactory();
        
        Ticket bug = bugFactory.createTicket();
        Ticket feature = featureFactory.createTicket();
        
        bug.assign();
        feature.assign();
        
        bug.updateStatus("In Progress");
        feature.updateStatus("Resolved");
        
        System.out.println("Bug status: " + bug.getStatus());
        System.out.println("Feature status: " + feature.getStatus());
    }
}