public class BugTicketFactory implements TicketFactory {
    @Override
    public Ticket createTicket() {
        return new BugTicket();
    }
}