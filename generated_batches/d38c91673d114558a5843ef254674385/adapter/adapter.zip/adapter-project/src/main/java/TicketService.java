import java.util.*;

public class TicketService {
    private Map<String, Ticket> tickets;
    
    public TicketService() {
        this.tickets = new HashMap<>();
    }
    
    public void createTicket(String id, String title, String description, Priority priority) {
        Ticket ticket = new Ticket(id, title, description, priority);
        tickets.put(id, ticket);
    }
    
    public void assignTicket(String ticketId, String assignee) {
        Ticket ticket = tickets.get(ticketId);
        if (ticket != null) {
            ticket.setAssignee(assignee);
            ticket.setStatus(Status.IN_PROGRESS);
        }
    }
    
    public void updateStatus(String ticketId, Status status) {
        Ticket ticket = tickets.get(ticketId);
        if (ticket != null) {
            ticket.setStatus(status);
        }
    }
    
    public List<Ticket> getTicketsByPriority(Priority priority