public class Ticket {
    private String id;
    private String title;
    private String description;
    private String status;
    private String assignee;
    private int priority;

    public Ticket(String id, String title, String description) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.status = "Open";
        this.priority = 1;
    }

    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public String getAssignee() { return assignee; }
    public void setAssignee(String assignee) { this.assignee = assignee; }
    
    public int getPriority() { return priority; }
    public void setPriority(int priority) { this.priority = priority; }
}