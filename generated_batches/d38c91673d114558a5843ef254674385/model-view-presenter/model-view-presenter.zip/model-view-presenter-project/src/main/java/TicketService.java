import java.util.*;

public class TicketService {
    private List<Ticket> tickets;
    private Map<String, String> comments;

    public TicketService() {
        this.tickets = new ArrayList<>();
        this.comments = new HashMap<>();
    }

    public void createTicket(String id, String title, String description) {
        tickets.add(new Ticket(id, title, description));
    }

    public List<Ticket> getAllTickets() {
        return new ArrayList<>(tickets);
    }

    public Ticket getTicketById(String id) {
        return tickets.stream()
                .filter(ticket -> ticket.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public void updateTicketStatus(String id, String status) {
        Ticket ticket = getTicketById(id);
        if (ticket != null) {
            ticket.setStatus(status);
        }
    }

    public void assignTicket(String id, String assignee) {
        Ticket ticket = getTicketById(id);
        if (ticket != null) {
            ticket.setAssignee(assignee);
        }
    }

    public void addComment(String ticketId, String comment) {
        comments.put(ticketId, comment);
    }

    public String get