package com.projecttracker.dto;

public class TicketDTO {
    private int id;
    private String title;
    private String status;
    private String assignee;
    
    public TicketDTO() {}
    
    public TicketDTO(int id, String title, String status, String assignee) {
        this.id = id;
        this.title = title;
        this.status = status;
        this.assignee = assignee;
    }
    
    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public String getAssignee() { return assignee; }
    public void setAssignee(String assignee) { this.assignee = assignee; }
}