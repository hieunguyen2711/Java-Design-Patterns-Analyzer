package com.projecttracker.ticket;

import java.util.*;

public class TicketManager {
    private final List<Ticket> activeTickets;
    private final List<Ticket> pendingTickets;
    
    public TicketManager() {
        this.activeTickets = new ArrayList<>();
        this.pendingTickets = new ArrayList<>();
    }
    
    // Double buffering pattern: operations are performed on pending list
    // and then swapped to active list at defined intervals
    
    public void addTicket(Ticket ticket) {
        pendingTickets.add(ticket);
    }
    
    public List<Ticket> getActiveTickets() {
        return new ArrayList<>(activeTickets);  // Return copy for safety
    }
    
    public void updateBuffer() {
        synchronized (this) {
            activeTickets.clear();
            activeTickets.addAll(pendingTickets);
            pendingTickets.clear();
        }
    }
    
    public List<Ticket> getTicketsByStatus(Status status) {
        return activeTickets.stream()
                .filter(ticket -> ticket.getStatus() == status)
                .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
    }
}