package com.project.tracker;

import java.util.function.Function;

public class TicketWorkflow {
    
    public static Function<Ticket, Ticket> assignTicket(String assignee) {
        return ticket -> {
            ticket.setAssignee(assignee);
            ticket.setStatus(Status.IN_PROGRESS);
            return ticket;
        };
    }
    
    public static Function<Ticket, Ticket> resolveTicket() {
        return ticket -> {
            ticket.setStatus(Status.RESOLVED);
            return ticket;
        };
    }
    
    public static Function<Ticket, Ticket> closeTicket() {
        return ticket -> {
            ticket.setStatus(Status.CLOSED);
            return ticket;
        };
    }
    
    public static Function<Ticket, Ticket> processTicket(Function<Ticket, Ticket>... steps) {
        return