package com.project.tracker;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH,
    URGENT
}