package com.projecttracker.ticket;

public class FeatureTicket extends Ticket {
    
    private String implementationDetails;
    private