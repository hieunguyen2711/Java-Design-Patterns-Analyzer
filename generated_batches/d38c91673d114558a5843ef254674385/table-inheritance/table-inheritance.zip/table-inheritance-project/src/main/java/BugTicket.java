package com.projecttracker.ticket;

public class BugTicket extends Ticket {
    
    private String bugSeverity;
    private String reproductionSteps;
    
    public BugTicket(String title, String description, Priority priority, 
                     String bugSeverity, String reproductionSteps) {
        super(title, description, priority);
        this.bugSeverity = bugSeverity;
        this.reproductionSteps = reproductionSteps;
    }
    
    @Override
    public void processTicket() {
        System.out.println("Processing Bug Ticket: " + title);
        System.out.println("Severity: " + bugSeverity);
        System.out.println("Reproduction Steps: " + reproductionSteps);
        updateStatus(Status.IN_PROGRESS);
    }
    
    // Getters and setters for bug-specific fields
    public String getBugSeverity() { return bugSeverity; }
    public void setBugSeverity(String bugSeverity) { this.bugSeverity = bugSeverity; }
    public String getReproductionSteps() { return reproductionSteps; }
    public void setReproductionSteps(String reproductionSteps) { this.reproductionSteps = reproductionSteps; }
}