package com.projecttracker.ticket;

public abstract class Ticket {
    protected String title;
    protected String description;
    protected Priority priority;
    protected Status status;
    
    public Ticket(String title, String description, Priority priority) {
        this.title = title;
        this.description = description;
        this.priority = priority;
        this.status = Status.OPEN;
    }
    
    public abstract void processTicket();
    
    public void assignTo(String assignee) {
        System.out.println("Ticket assigned to: " + assignee);
    }
    
    public void updateStatus(Status newStatus) {
        this.status = newStatus;
        System.out.println("Ticket status updated to: " + newStatus);
    }
    
    // Getters and setters
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public Priority getPriority() { return priority; }
    public void setPriority(Priority priority) { this.priority = priority; }
    public Status getStatus() { return status; }
}