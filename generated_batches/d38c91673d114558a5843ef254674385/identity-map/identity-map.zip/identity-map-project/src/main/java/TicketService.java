package com.projecttracker.ticket;

public class TicketService {
    
    public Ticket createTicket(String id, String title, String description) {
        // Identity map ensures we don't create duplicate tickets with same ID
        Ticket existing