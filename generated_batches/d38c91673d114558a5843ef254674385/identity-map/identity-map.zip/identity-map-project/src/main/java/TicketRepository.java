package com.projecttracker.ticket;

import java.util.HashMap;
import java.util.Map;

public class TicketRepository {
    private static final Map<String, Ticket> ticketMap = new HashMap<>();
    
    public static Ticket findById(String id) {
        return ticketMap.get(id);
    }
    
    public static void save(Ticket ticket) {
        ticketMap.put(ticket.getId(), ticket);
    }
    
    public static void delete(String id) {
        ticketMap.remove(id);
    }
    
    public static boolean exists(String id) {
        return ticketMap.containsKey(id);
    }
}