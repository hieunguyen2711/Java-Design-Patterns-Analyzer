import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class TicketService {
    private final BlockingQueue<Runnable> queue = new LinkedBlockingQueue<>();
    private final ActiveObject activeObject;

    public TicketService() {
        this.activeObject = new ActiveObject(queue);
        Thread workerThread = new Thread(activeObject);
        workerThread.start();
    }

    public void createTicket(int id, String title, String description, Priority priority) {
        queue.add(() -> {
            System.out.println("Creating ticket: " + title);
            // Simulate ticket creation logic
            Ticket ticket = new Ticket(id, title, description, priority);
            System.out.println("Ticket created with ID: " + ticket.getId());
        });
    }

    public void assignTicket(int ticketId, String assignee) {
        queue.add(() -> {
            System.out.println("Assigning ticket " + ticketId + " to " + assignee);
            // Simulate assignment logic