package com.projecttracker.service;

import com.projecttracker.ticket.Ticket;
import com.projecttracker.ticket.Priority;
import java.util.*;

public class TicketService {
    private final Map<String, Ticket> tickets = new HashMap<>();
    
    public void createTicket(String id, String title, String description, Priority priority) {
        Ticket ticket = new Ticket(id, title, description, priority);
        tickets.put(id, ticket);
    }
    
    public Ticket getTicket(String id) {
        return tickets.get(id);
    }
    
    public List<Ticket> getAllTickets() {
        return new ArrayList<>(tickets.values());
    }
    
    public void assignTicket(String ticketId, String assignee) {
        Ticket ticket = tickets.get(ticketId);
        if (ticket != null) {