import java.util.*;

public class TicketInterpreter {
    private Map<String, Expression> expressions;
    
    public TicketInterpreter() {
        expressions = new HashMap<>();
        initializeExpressions();
    }
    
    private void initializeExpressions() {
        expressions.put("priority", new PriorityExpression());
        expressions.put("status", new StatusExpression());
        expressions.put("assignee", new AssigneeExpression());
    }
    
    public boolean interpret(String context, Ticket ticket) {
        String[] parts = context.split("\\s+");
        if (parts.length < 2) return false;
        
        String key = parts[0].toLowerCase();
        String value = parts[1];
        
        Expression expression = expressions.get(key);
        if (expression != null) {
            return expression.interpret(value, ticket);
        }
        return false;
    }
}