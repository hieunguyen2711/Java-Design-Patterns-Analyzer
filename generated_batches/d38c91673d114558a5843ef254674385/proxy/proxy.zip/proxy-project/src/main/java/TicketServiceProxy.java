public class TicketServiceProxy implements TicketService {
    private RealTicketService realService;
    private String currentUser;
    
    public Ticket