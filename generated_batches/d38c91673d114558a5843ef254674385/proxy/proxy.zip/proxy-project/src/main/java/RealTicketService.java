import java.util.HashMap;
import java.util.Map;

public class RealTicketService implements TicketService {
    private Map<Integer, Ticket> tickets = new HashMap<>();
    
    @Override
    public void createTicket(Ticket ticket) {
        System.out.println("Creating ticket in database: " + ticket.getTitle());
        tickets.put(ticket.getId(), ticket);
    }
    
    @Override
    public void updateTicket(Ticket ticket) {
        System.out.println("Updating ticket in database: " + ticket.getTitle());
        tickets.put(ticket.getId(), ticket);
    }
    
    @Override
    public void deleteTicket(int id) {
        System.out.println("Deleting ticket from database with ID: " + id);
        tickets.remove(id);
    }
    
    @Override
    public Ticket getTicket(int id) {
        System.out.println("Retrieving ticket from database with ID: " + id);
        return tickets.get(id);
    }
}