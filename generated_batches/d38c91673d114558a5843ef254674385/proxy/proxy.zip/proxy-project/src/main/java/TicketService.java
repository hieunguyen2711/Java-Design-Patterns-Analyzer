public interface TicketService {
    void createTicket(Ticket ticket);
    void updateTicket(Ticket ticket);
    void deleteTicket(int id);
    Ticket getTicket(int id);
}