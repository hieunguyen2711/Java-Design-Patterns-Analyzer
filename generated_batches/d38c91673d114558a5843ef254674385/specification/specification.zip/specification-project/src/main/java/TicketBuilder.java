package com.projecttracker.ticket;

public class TicketBuilder {
    private String id;
    private String title;
    private String description;
    private Priority priority = Priority.MEDIUM;
    private Status status = Status.OPEN;
    private String assignee;
    
    public static TicketBuilder create() {
        return new TicketBuilder();
    }
    
    public TicketBuilder withId(String id) {
        this.id = id;
        return this;
    }
    
    public TicketBuilder withTitle(String title) {
        this.title = title;
        return this;
    }
    
    public TicketBuilder withDescription(String description) {
        this.description = description;
        return this;
    }
    
    public TicketBuilder withPriority(Priority priority) {
        this.priority = priority;
        return this