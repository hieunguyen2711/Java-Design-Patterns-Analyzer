public class HighPriorityTicket extends TicketDecorator {
    
    public HighPriorityTicket(Ticket ticket) {
        super(ticket);
    }

    @Override
    public int getPriority() {
        return ticket.getPriority() + 20;
    }
}