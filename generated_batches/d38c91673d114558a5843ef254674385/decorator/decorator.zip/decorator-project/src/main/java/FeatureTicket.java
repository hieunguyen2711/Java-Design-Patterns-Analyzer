public class FeatureTicket extends Ticket {
    private boolean isComplex;

    public FeatureTicket(String title, String description, boolean isComplex) {
        super(title, description);
        this.isComplex = isComplex;
    }

    @Override
    public int getPriority() {
        return isComplex ? 50 : 30;
    }
}