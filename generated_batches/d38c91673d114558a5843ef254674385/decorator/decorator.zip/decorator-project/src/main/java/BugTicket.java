public class BugTicket extends Ticket {
    private int severity;

    public BugTicket(String title, String description, int severity) {
        super(title, description);
        this.severity = severity;
    }

    @Override
    public int getPriority() {
        return severity * 10;
    }
}