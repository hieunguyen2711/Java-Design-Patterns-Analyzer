public abstract class Ticket {
    protected String title;
    protected String description;
    protected String assignee;
    protected TicketStatus status;

    public Ticket(String title, String description) {
        this.title = title;
        this.description = description;
        this.status = TicketStatus.NEW;
    }

    public abstract int getPriority();

    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public String getAssignee() { return assignee; }
    public void setAssignee(String assignee) { this.assignee = assignee; }
    public TicketStatus getStatus() { return status; }
    public void setStatus(TicketStatus status) { this.status = status; }
}