public abstract class TicketDecorator extends Ticket {
    protected Ticket ticket;

    public TicketDecorator(Ticket ticket) {
        super(ticket.getTitle(), ticket.getDescription());
        this.ticket = ticket;
    }

    @Override
    public int getPriority() {
        return ticket.getPriority();
    }
}