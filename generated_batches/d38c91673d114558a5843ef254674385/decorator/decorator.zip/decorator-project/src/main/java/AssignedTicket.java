public class AssignedTicket extends TicketDecorator {
    
    public AssignedTicket(Ticket ticket) {
        super(ticket);
    }

    @Override
    public int getPriority() {
        return ticket.getPriority() + 5;
    }
}