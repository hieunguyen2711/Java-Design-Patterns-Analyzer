import java.util.*;

public class ProjectTracker {
    private List<Ticket> tickets;
    
    public ProjectTracker() {
        this.tickets = new ArrayList<>();
    }
    
    public void addTicket(Ticket ticket) {
        tickets.add(ticket);
    }
    
    public TicketIterator getTicketsIterator() {
        return new TicketIterator(tickets);
    }
    
    public Iterator<Ticket> getAllTickets() {
        return tickets.iterator();
    }
}