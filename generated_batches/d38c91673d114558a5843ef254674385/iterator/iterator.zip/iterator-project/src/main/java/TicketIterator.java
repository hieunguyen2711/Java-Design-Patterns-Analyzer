import java.util.Iterator;
import java.util.List;

public class TicketIterator implements Iterator<Ticket> {
    private List<Ticket> tickets;
    private int currentIndex = 0;
    
    public TicketIterator(List<Ticket> tickets) {
        this.tickets = tickets;
    }
    
    @Override
    public boolean hasNext() {
        return currentIndex < tickets.size();
    }
    
    @Override
    public Ticket next() {
        if (!hasNext()) {
            throw new RuntimeException("No more tickets");
        }
        return tickets.get(currentIndex++);
    }
}