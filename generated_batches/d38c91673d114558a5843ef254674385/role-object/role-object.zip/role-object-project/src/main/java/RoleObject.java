package com.projecttracker.ticket;

import java.util.List;

public abstract class RoleObject {
    protected String name;
    
    public RoleObject(String name) {
        this.name = name;
    }
    
    public abstract List<String> getPermissions();
    
    // Getters
    public String getName() { return name; }
}