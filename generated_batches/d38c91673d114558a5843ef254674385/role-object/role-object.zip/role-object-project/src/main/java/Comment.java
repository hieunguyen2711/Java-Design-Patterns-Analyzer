package com.projecttracker.ticket;

public class Comment {
    private String text;
    private String author;
    
    public Comment(String text, String author) {
        this.text = text;
        this.author = author;
    }
    
    // Getters
    public String getText() { return text; }
    public String getAuthor() { return author; }
}