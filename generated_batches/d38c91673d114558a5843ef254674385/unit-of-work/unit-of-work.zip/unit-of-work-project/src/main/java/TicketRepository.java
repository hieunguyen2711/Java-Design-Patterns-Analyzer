import java.util.*;

public class TicketRepository {
    private Map<Integer, Ticket> tickets = new HashMap<>();
    
    public void save(Ticket ticket) {
        tickets.put(ticket.getId(), ticket);
    }
    
    public Ticket findById(int id) {
        return tickets.get(id);
    }
    
    public List<Ticket> findAll() {
        return new ArrayList<>(tickets.values());
    }
}