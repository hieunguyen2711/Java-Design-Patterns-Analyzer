import java.util.*;

public class UnitOfWork {
    private Map<Integer, Ticket> addedTickets = new HashMap<>();
    private Map<Integer, Ticket> updatedTickets = new HashMap<>();
    private Set<Integer> deletedTicketIds = new HashSet<>();
    private TicketRepository repository;
    
    public UnitOfWork(TicketRepository repository) {
        this.repository = repository;
    }
    
    public void registerNew(Ticket ticket) {
        addedTickets.put(ticket.getId(), ticket