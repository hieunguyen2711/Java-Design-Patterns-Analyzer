package com.projecttracker.command;

import com.projecttracker.manager.TicketManager;
import com.projecttracker.model.Ticket;

public class UpdateStatusCommand implements Command {
    private TicketManager ticket