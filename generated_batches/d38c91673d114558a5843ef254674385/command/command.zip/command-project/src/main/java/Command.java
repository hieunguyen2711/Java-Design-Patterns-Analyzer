package com.projecttracker.command;

public interface Command {
    void execute();
}