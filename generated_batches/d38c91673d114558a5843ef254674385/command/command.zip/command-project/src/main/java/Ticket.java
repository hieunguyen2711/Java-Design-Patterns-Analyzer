package com.projecttracker.model;

public class Ticket {
    private int id;
    private String title;
    private String status;
    
    public Ticket(int id, String title) {
        this.id = id;
        this.title = title;
        this.status = "OPEN";
    }
    
    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}