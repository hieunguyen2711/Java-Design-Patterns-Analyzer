package com.projecttracker.command;

import com.projecttracker.manager.TicketManager;
import com.projecttracker.model.Ticket;

public class CreateTicketCommand implements Command {
    private TicketManager ticketManager;
    private String title;
    
    public CreateTicketCommand(TicketManager ticketManager, String title) {
        this.ticketManager = ticketManager;
        this.title = title;
    }
    
    @Override
    public void execute() {
        Ticket newTicket = new Ticket(
            ticketManager.getAllTickets().size() + 1,
            title
        );
        ticketManager.addTicket(newTicket);
        System.out.println("Created ticket: " + title);
    }
}