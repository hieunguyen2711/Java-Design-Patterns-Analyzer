package com.projecttracker.manager;

import com.projecttracker.model.Ticket;
import java.util.ArrayList;
import java.util.List;

public class TicketManager {
    private List<Ticket> tickets;
    
    public TicketManager() {
        this.tickets = new ArrayList<>();
    }
    
    public void addTicket(Ticket ticket) {
        tickets.add(ticket);
    }
    
    public Ticket getTicket(int id) {
        return tickets.stream()
                .filter(t -> t.getId() == id)
                .findFirst()
                .orElse(null);
    }
    
    public List<Ticket> getAllTickets() {
        return new ArrayList<>(tickets);
    }
}