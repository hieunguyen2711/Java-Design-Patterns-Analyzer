package com.projecttracker.ticket;

public class Task implements TicketComponent {
    private String name;
    private String status;
    private int priority;
    
    public Task(String name, String status, int priority) {
        this.name = name;
        this.status = status;
        this.priority = priority;
    }
    
    @Override
    public void add(TicketComponent component) {
        throw new UnsupportedOperationException("Cannot add components to a task");
    }
    
    @Override
    public void remove(TicketComponent component) {
        throw new UnsupportedOperationException("Cannot remove components from a task");
    }
    
    @Override
    public String getName() {
        return name;
    }
    
    @Override
    public String getStatus() {
        return status;
    }
    
    @Override
    public int getPriority() {
        return priority;
    }
    
    @Override
    public void display() {
        System.out.println("Task: " + name + ", Status: " + status + ", Priority: " + priority);
    }
}