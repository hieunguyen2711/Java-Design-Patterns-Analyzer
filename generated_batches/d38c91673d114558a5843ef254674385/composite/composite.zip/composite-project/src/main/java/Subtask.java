package com.projecttracker.ticket;

public class Subtask implements TicketComponent {
    private String name;
    private String status;
    private int priority;
    
    public Subtask(String name, String status, int priority) {
        this.name = name;
        this.status = status;
        this.priority = priority;
    }
    
    @Override
    public void add(TicketComponent component) {
        throw new UnsupportedOperationException("Cannot add components to a subtask");
    }
    
    @Override
    public void remove(TicketComponent component) {
        throw new UnsupportedOperationException("Cannot remove components from a subtask");
    }
    
    @Override
    public String getName() {
        return name;
    }
    
    @Override
    public String getStatus() {
        return status;
    }
    
    @Override
    public int getPriority() {
        return priority;
    }
    
    @Override
    public void display() {
        System.out.println("  Subtask: " + name + ", Status: " + status + ", Priority: " + priority);
    }
}