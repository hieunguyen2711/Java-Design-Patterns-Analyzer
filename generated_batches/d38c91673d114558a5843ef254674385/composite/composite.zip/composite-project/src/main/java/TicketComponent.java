package com.projecttracker.ticket;

public interface TicketComponent {
    void add(TicketComponent component);
    void remove(TicketComponent component);
    String getName();
    String getStatus();
    int getPriority();
    void display();
}