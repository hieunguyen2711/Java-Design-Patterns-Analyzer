public class NotificationService {
    public void sendEmail(String recipient, String subject, String message) {
        System.out.println("Sending email to " + recipient + ": " + subject + " - " + message);
    }
    
    public void sendSlackNotification(String channel, String message) {
        System.out.println("Sending Slack notification to " + channel + ": " + message);