import java.util.HashMap;
import java.util.Map;

public class TicketRepository {
    private Map<String, Ticket> tickets = new HashMap<>();
    
    public void save(Ticket ticket) {
        tickets.put(ticket.getId(), ticket);
    }
    
    public Ticket findById(String id) {
        return tickets.get(id);
    }
    
    public void update(Ticket ticket) {
        tickets.put(ticket.getId(), ticket);
    }
}