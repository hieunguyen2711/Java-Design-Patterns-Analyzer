public class FeatureTicket extends Ticket {
    private String storyPoints;

    public FeatureTicket(String title, String description, int priority, String storyPoints) {
        super(title, description, priority);
        this.storyPoints = storyPoints;
    }

    @Override
    public void assignTo(String assignee) {
        System.out.println("Feature ticket '" + title + "' assigned to " + assignee);
        status = "Assigned";
    }
    
    public String getStoryPoints() {
        return storyPoints;
    }
}