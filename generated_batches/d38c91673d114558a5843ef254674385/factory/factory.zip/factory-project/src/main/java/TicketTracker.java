public class TicketTracker {
    public static void main(String[] args) {
        // Using the factory to create different types of tickets