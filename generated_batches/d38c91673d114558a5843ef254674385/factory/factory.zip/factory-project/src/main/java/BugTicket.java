public class BugTicket extends Ticket {
    private String severity;

    public BugTicket(String title, String description, int priority, String severity) {
        super(title, description, priority);
        this.severity = severity;
    }

    @Override
    public void assignTo(String assignee) {
        System.out.println("Bug ticket '" + title + "' assigned to " + assignee);
        status = "Assigned";
    }
    
    public String getSeverity() {
        return severity;
    }
}