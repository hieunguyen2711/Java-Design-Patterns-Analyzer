public class TicketFactory {
    public static Ticket createTicket(String type, String title, String description, int priority) {
        switch (type.toLowerCase()) {
            case "bug":
                return new BugTicket(title, description, priority, "Medium");
            case "feature":
                return new FeatureTicket(title, description, priority, "5");
            default:
                throw new IllegalArgumentException("Unknown ticket type: " + type);
        }
    }
}