public abstract class Ticket {
    protected String title;
    protected String description;
    protected String status;
    protected int priority;

    public Ticket(String title, String description, int priority) {
        this.title = title;
        this.description = description;
        this.priority = priority;
        this.status = "Open";
    }

    public abstract void assignTo(String assignee);
    
    public String getTitle() {
        return title;
    }
    
    public String getDescription() {
        return description;
    }
    
    public String getStatus() {
        return status;
    }
    
    public int getPriority() {
        return priority;
    }
}