public class TicketService {
    private TicketTracker tracker;
    
    public TicketService() {
        this.tracker = TicketTracker.getInstance();
    }
    
    public void handleNewTicket(String description) {
        tracker.createTicket(description);
    }
    
    public void assignTicket(String ticketId, String assignee) {
        tracker.assignTicket(ticketId, assignee);
    }
    
    public void updateTicketStatus(String ticketId, String status) {
        tracker.updateStatus(ticketId, status);
    }
}