public class Main {
    public static void main(String[] args) {
        TicketService service1 = new TicketService();
        TicketService service2 = new TicketService();
        
        // Both services reference the same singleton instance
        System.out.println("Service 1 and Service 2 use same tracker: " 
            + (service1.getClass().getName() == service2.getClass().getName()));
        
        service1.handleNewTicket("Bug in login page");
        service2.assignTicket("TICKET-001", "John Doe");
        service1.updateTicketStatus("TICKET-001", "In Progress");
    }
}