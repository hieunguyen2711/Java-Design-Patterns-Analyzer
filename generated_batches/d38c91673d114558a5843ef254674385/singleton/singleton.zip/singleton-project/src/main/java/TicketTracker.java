public class TicketTracker {
    private static volatile TicketTracker instance;
    
    private TicketTracker() {
        // Private constructor to prevent instantiation
    }
    
    public static TicketTracker getInstance() {
        if (instance == null) {
            synchronized (TicketTracker.class) {
                if (instance == null) {
                    instance = new TicketTracker();
                }
            }
        }
        return instance;
    }
    
    public void createTicket(String description) {
        System.out.println("Creating ticket: " + description);
    }
    
    public void assignTicket(String ticketId, String assignee) {
        System.out.println("Assigning ticket " + ticketId + " to " + assignee);
    }
    
    public void updateStatus(String ticketId, String status) {
        System.out.println("Updating ticket " + ticketId + " status to " + status);
    }
}