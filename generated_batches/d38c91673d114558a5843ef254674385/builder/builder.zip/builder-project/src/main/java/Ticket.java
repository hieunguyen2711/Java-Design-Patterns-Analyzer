package com.project.tracker;

public class Ticket {
    private final String id;
    private final String title;
    private final String description;
    private final Priority priority;
    private final Status status;
    private final String assignee;
    private final String reporter;
    
    private Ticket(Builder builder) {
        this.id = builder.id;
        this.title = builder.title;
        this.description = builder.description;
        this.priority = builder.priority;
        this.status = builder.status;
        this.assignee = builder.assignee;
        this.reporter = builder.reporter;
    }
    
    public String getId() {
        return id;
    }
    
    public String getTitle() {
        return title;
    }
    
    public String getDescription() {
        return description;
    }
    
    public Priority getPriority() {
        return priority;
    }
    
    public Status getStatus() {
        return status;
    }
    
    public String getAssignee() {
        return assignee;
    }
    
    public String getReporter() {
        return reporter;
    }
    
    @Override
    public String toString() {
        return "Ticket{" +
                "id='" + id + '\'' +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", priority=" + priority +
                ", status=" + status +
                ", assignee='" + assignee + '\'' +
                ", reporter='" + reporter + '\'' +
                '}';
    }
    
    public static class Builder {
        private String id;
        private String title;
        private String description;
        private Priority priority = Priority.MEDIUM;
        private Status status = Status.OPEN;
        private String assignee;
        private String reporter;
        
        public Builder id(String id) {
            this.id = id;
            return this;
        }
        
        public Builder title(String title) {
            this.title = title;
            return this;
        }
        
        public Builder description(String description) {
            this.description = description;
            return this;
        }
        
        public Builder priority(Priority priority) {
            this.priority = priority;
            return this;
        }
        
        public Builder status(Status status) {
            this.status = status;
            return this;
        }
        
        public Builder assignee(String assignee) {
            this.assignee = assignee;
            return this;
        }
        
        public Builder reporter(String reporter) {
            this.reporter = reporter;
            return this;
        }
        
        public Ticket