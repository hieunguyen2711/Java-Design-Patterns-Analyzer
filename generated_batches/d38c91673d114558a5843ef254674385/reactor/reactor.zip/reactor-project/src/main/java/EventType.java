package com.example.projecttracker;

public enum EventType {
    CREATED,