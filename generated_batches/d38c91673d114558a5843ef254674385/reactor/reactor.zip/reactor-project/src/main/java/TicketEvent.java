package com.example.projecttracker;

import java.time.LocalDateTime;

public class TicketEvent {
    private String ticketId;
    private EventType type;
    private String description;
    private LocalDateTime timestamp;
    
    public TicketEvent(String ticketId, EventType type, String description) {
        this.ticketId = ticketId;
        this.type = type;
        this.description = description;
        this.timestamp = LocalDateTime.now();
    }
    
    // Getters
    public String getTicketId() { return ticketId; }
    public EventType getType() { return type; }
    public String getDescription() { return description; }
    public LocalDateTime getTimestamp() { return timestamp; }
}