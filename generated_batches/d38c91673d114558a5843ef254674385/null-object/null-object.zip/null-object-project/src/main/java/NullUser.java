public class NullUser extends User {
    
    public NullUser() {
        super("null", "Unassigned", "