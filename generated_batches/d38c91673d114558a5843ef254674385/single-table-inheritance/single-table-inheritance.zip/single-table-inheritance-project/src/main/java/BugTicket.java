package com.projecttracker.ticket;

public class BugTicket extends Ticket {
    private String bugType;
    private String reproSteps;
    
    public BugTicket(String id, String title, String description, Priority priority, 
                     String bugType, String reproSteps) {
        super(id, title, description, priority);
        this.bugType = bugType;
        this.reproSteps = reproSteps;
    }
    
    @Override
    public void assignTo(String assignee) {
        System.out.println("Bug ticket " + id + " assigned to: " + assignee);
    }
    
    @Override
    public void updateStatus(Status status) {
        this.status = status;
        System.out.println("Bug ticket " + id + " status updated to: " + status);
    }
    
    // Getters and setters
    public String getBugType() { return bugType; }
    public String getReproSteps() { return reproSteps; }
}