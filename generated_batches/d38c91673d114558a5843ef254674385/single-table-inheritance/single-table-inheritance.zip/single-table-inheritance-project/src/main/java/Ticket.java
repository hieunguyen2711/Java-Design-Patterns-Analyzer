package com.projecttracker.ticket;

public abstract class Ticket {
    protected String id;
    protected String title;
    protected String description;
    protected Priority priority;
    protected Status status;
    
    public Ticket(String id, String title, String description, Priority priority) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.priority = priority;
        this.status = Status.OPEN;
    }
    
    public abstract void assignTo(String assignee);
    
    public abstract void updateStatus(Status status);
    
    // Getters and setters
    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public Priority getPriority() { return priority; }
    public Status getStatus() { return status; }
    
    public void setPriority(Priority priority) { this.priority = priority; }
}