package com.projecttracker.ticket;

public class FeatureTicket extends Ticket {
    private String userStory;
    private int storyPoints;
    
    public FeatureTicket(String id, String title, String description, Priority priority,
                         String userStory, int storyPoints) {
        super(id, title, description, priority);
        this.userStory = userStory;
        this.storyPoints = storyPoints;
    }
    
    @Override
    public void assignTo(String assignee) {