public class StatusHandler extends Handler {
    @Override
    public void handleRequest(Ticket ticket) {
        if (ticket.getStatus() == Status.NEW) {
            System.out.println("New ticket handled by StatusHandler");
            ticket.setStatus(Status