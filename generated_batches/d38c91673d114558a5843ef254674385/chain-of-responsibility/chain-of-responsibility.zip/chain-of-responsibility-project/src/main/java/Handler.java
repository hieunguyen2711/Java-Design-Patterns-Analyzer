public abstract class Handler {
    protected Handler nextHandler;

    public void setNext(Handler handler) {
        this.nextHandler = handler;
    }

    public abstract void handleRequest(Ticket ticket);

    protected void processTicket(Ticket ticket) {
        if (nextHandler != null) {
            nextHandler.handleRequest(ticket);
        }
    }
}