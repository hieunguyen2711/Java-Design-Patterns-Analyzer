public class PriorityHandler extends Handler {
    @Override
    public void handleRequest(Ticket ticket) {
        if (ticket.getPriority() == Priority.URGENT) {
            System.out.println("URGENT ticket handled by PriorityHandler");
            ticket.setStatus(Status.ASSIGNED);
            processTicket(ticket);
        } else {
            processTicket(ticket);
        }
    }
}