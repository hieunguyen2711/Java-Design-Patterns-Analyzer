public class Ticket {
    private final String id;
    private final String description;
    private TicketPriority priority;
    private TicketStatus status;
    private final String projectName;
    
    public Ticket(String id, String description, TicketPriority priority, String projectName) {
        this.id = id;
        this.description = description;
        this.priority = priority;
        this.status = TicketStatus.OPEN;
        this.projectName = projectName;
    }
    
    public String getId() {
        return id;
    }
    
    public String getDescription() {
        return description;
    }
    
    public TicketPriority getPriority() {
        return priority;
    }
    
    public void setPriority(TicketPriority priority) {
        this.priority = priority;
    }
    
    public TicketStatus getStatus() {
        return status;
    }
    
    public void setStatus(TicketStatus status) {
        this.status = status;
    }
    
    public String getProjectName() {
        return projectName;
    }
}