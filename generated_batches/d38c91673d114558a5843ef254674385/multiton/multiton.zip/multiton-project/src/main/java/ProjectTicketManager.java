public class ProjectTicketManager {
    private final String projectName;
    
    public ProjectTicketManager(String projectName) {
        this.projectName = projectName;
    }
    
    public Ticket createTicket(String id, String description, TicketPriority priority) {
        // Increment ticket count in multiton for this project