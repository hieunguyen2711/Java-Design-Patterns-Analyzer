import java.util.HashMap;
import java.util.Map;

public class ProjectTrackerMultiton {
    private static final Map<String, ProjectTrackerMultiton> instances = new HashMap<>();
    
    private final String projectName;
    private int ticketCount;
    
    private ProjectTrackerMultiton(String projectName) {
        this.projectName = projectName;
        this.ticketCount = 0;
    }
    
    public static synchronized ProjectTrackerMultiton getInstance(String projectName) {
        return instances.computeIfAbsent(projectName, ProjectTrackerMultiton::new);
    }
    
    public String getProjectName() {
        return projectName;
    }
    
    public int getTicketCount() {
        return ticketCount;
    }
    
    public void incrementTicketCount() {
        ticketCount++;
    }
}