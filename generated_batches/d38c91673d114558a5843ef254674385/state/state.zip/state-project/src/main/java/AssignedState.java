public class AssignedState implements TicketState {
    @Override
    public void assign(Ticket ticket) {
        System.out.println("Ticket " + ticket.getId() + " already assigned");
    }
    
    @Override
    public void resolve(Ticket ticket) {
        System.out.println("Ticket " + ticket.getId() + " resolved");
        ticket.setState(new ResolvedState());
    }
    
    @Override
    public void close(Ticket ticket) {
        System.out.println("Cannot close unresolved ticket " + ticket.getId());
    }
    
    @Override
    public void reopen(Ticket ticket) {