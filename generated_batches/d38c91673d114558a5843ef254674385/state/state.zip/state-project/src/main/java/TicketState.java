public interface TicketState {
    void assign(Ticket ticket);
    void resolve(Ticket ticket);
    void close(Ticket ticket);
    void reopen(Ticket ticket);
}