public class Ticket {
    private String id;
    private String title;
    private TicketState state;
    
    public Ticket(String id, String title) {
        this.id = id;
        this.title = title;
        this.state = new OpenState();
    }
    
    public void assign() {
        state.assign(this);
    }
    
    public void resolve() {
        state.resolve(this);
    }
    
    public void close() {
        state.close(this);
    }
    
    public void reopen() {
        state.reopen(this);
    }
    
    public String getId() {
        return id;
    }
    
    public String getTitle() {
        return title;
    }
    
    public TicketState getState() {
        return state;
    }
    
    public void setState(TicketState state) {
        this.state = state;
    }
}