public class OpenState implements TicketState {
    @Override
    public void assign(Ticket ticket) {
        System.out.println("Ticket " + ticket.getId() + " assigned");
        ticket.setState(new AssignedState());
    }
    
    @Override
    public void resolve(Ticket ticket) {
        System.out.println("Cannot resolve unassigned ticket " + ticket.getId());
    }
    
    @Override
    public void close(Ticket ticket) {
        System.out.println("Cannot close unassigned ticket " + ticket.getId());
    }
    
    @Override
    public void reopen(Ticket ticket) {
        System.out.println("Cannot reopen open ticket " + ticket.getId());
    }
}