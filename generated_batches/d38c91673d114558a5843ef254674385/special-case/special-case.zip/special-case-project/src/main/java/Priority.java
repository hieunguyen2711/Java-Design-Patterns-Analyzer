package com.projecttracker.ticket;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH,
    URGENT;
    
    public static final Priority DEFAULT_PRIORITY = LOW;
}