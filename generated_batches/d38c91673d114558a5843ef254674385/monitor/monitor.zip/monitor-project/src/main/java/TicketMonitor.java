package com.projecttracker.monitor;

import com.projecttracker.ticket.Ticket;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class TicketMonitor {
    private final Map<String, Ticket> tickets = new ConcurrentHashMap<>();
    private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
    
    public void addTicket(Ticket ticket) {
        lock.writeLock().lock();
        try {
            tickets.put(ticket.getId(), ticket);
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    public Ticket getTicket(String id) {
        lock.readLock().lock();
        try {
            return tickets.get(id);
        } finally {
            lock.read