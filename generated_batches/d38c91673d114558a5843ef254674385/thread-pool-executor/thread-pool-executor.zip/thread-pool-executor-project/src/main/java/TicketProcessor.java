import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class TicketProcessor {
    private final ExecutorService executorService;
    
    public TicketProcessor(int threadPoolSize) {
        this.executorService = Executors.newFixedThreadPool(threadPoolSize);
    }
    
    public Future<String> processTicketAsync(Ticket ticket) {
        return executorService.submit(() -> {
            // Simulate processing time
            Thread.sleep(1000);
            
            // Process the ticket based on priority
            String result;
            switch (ticket.getPriority()) {
                case URGENT:
                    result = "URGENT: Ticket " + ticket.getId() + " processed immediately";
                    break;
                case HIGH:
                    result = "HIGH: Ticket " + ticket.getId() + " processed within 2 hours";
                    break;
                case