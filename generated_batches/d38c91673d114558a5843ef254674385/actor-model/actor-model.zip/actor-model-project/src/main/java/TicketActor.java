import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class TicketActor {
    private final BlockingQueue<TicketMessage> messageQueue = new LinkedBlockingQueue<>();
    private final String actorId;
    
    public TicketActor(String actorId) {
        this.actorId = actorId;
        start();
    }
    
    public void send(TicketMessage message) {
        try {
            messageQueue.put(message);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
    
    private void start() {
        new