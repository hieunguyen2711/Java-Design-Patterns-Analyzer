public class FeatureTicket extends Ticket {
    private int storyPoints;
    
    public FeatureTicket(String title, String description, int storyPoints) {
        super(title, description);
        this.storyPoints = storyPoints;
    }
    
    @Override
    public void assignTo(String assignee) {
        System.out.println("Feature ticket '" + title + "' assigned to " + assignee);
    }
    
    public int getStoryPoints() {
        return storyPoints;
    }
}