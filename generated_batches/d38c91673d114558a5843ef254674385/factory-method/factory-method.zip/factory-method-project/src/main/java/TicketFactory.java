public abstract class TicketFactory {
    public enum TicketType {
        BUG, FEATURE
    }
    
    public abstract Ticket createTicket(String title, String description);
    
    public static TicketFactory getFactory(TicketType type) {
        switch (type) {
            case BUG:
                return new BugTicketFactory();
            case FEATURE:
                return new FeatureTicketFactory();
            default:
                throw new IllegalArgumentException("Unknown ticket type");
        }
    }
}

class BugTicketFactory extends TicketFactory {
    @Override
    public Ticket createTicket(String title, String description) {
        return new BugTicket(title, description, "Medium");
    }
}

class FeatureTicketFactory extends TicketFactory {
    @Override
    public Ticket createTicket(String title, String description