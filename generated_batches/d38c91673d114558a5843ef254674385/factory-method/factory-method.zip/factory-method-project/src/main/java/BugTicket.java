public class BugTicket extends Ticket {
    private String severity;
    
    public BugTicket(String title, String description, String severity) {
        super(title, description);
        this.severity = severity;
    }
    
    @Override
    public void assignTo(String assignee) {
        System.out.println("Bug ticket '" + title + "' assigned to " + assignee);
    }
    
    public String getSeverity() {
        return severity;
    }
}