public abstract class Ticket {
    protected String title;
    protected String description;
    protected String status;
    
    public Ticket(String title, String description) {
        this.title = title;
        this.description = description;
        this.status = "Open";
    }
    
    public abstract void assignTo(String assignee);
    
    public void updateStatus(String newStatus) {
        this.status = newStatus;
    }
    
    public String getTitle() {
        return title;
    }
    
    public String getDescription() {
        return description;
    }
    
    public String getStatus() {
        return status;
    }
}