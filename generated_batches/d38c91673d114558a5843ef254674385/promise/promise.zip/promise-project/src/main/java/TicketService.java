package com.projecttracker.ticket;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TicketService {
    private final Map<String, Ticket> tickets = new HashMap<>();
    private final ExecutorService executor = Executors.newFixedThreadPool(4);
    
    public CompletableFuture<Ticket> createTicketAsync(String id, String title, 
                                                     String description, Priority priority) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                Thread.sleep(100); // Simulate async work
                Ticket ticket = new Ticket(id, title, description, priority);
                tickets.put(id, ticket);
                return ticket;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }