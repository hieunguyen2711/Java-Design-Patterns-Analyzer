import java.util.ArrayList;
import java.util.List;

public class TicketTrackerMonostate {
    private static List<Ticket> tickets = new ArrayList<>();
    private static int nextId = 1;
    
    // Private constructor to prevent instantiation
    private TicketTrackerMonostate() {}
    
    public static void createTicket(String title, String description) {
        Ticket ticket = new Ticket(nextId++, title, description);
        tickets.add(ticket);
    }
    
    public static