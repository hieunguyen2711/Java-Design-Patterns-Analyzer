package com.projecttracker.ticket;

public class Ticket implements Cloneable {
    private String id;
    private String title;
    private String description;
    private String assignee;
    private Priority priority;
    private Status status;
    
    public Ticket(String id, String title, String description, String assignee, Priority priority, Status status) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.assignee = assignee;
        this.priority = priority;
        this.status = status;
    }
    
    @Override
    public Ticket clone() throws CloneNotSupportedException {
        return (Ticket) super.clone();
    }
    
    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public String getAssignee() { return assignee; }
    public void setAssignee(String assignee) { this.assignee = assignee; }
    
    public Priority getPriority() { return priority; }
    public void setPriority(Priority priority) { this.priority = priority; }
    
    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }
}