package com.projecttracker.ticket;

import java.util.HashMap;
import java.util.Map;

public class TicketPrototypeRegistry {
    private static final Map<String, Ticket> prototypes = new HashMap<>();
    
    static {
        // Register prototype tickets
        prototypes.put("bug", new Ticket("BUG-001", "Bug Report Template", 
            "Template for bug reports", "Unassigned", Priority.HIGH, Status.OPEN));
        
        prototypes.put("feature", new Ticket("FEAT-001", "Feature Request Template", 
            "Template for feature requests", "Unassigned", Priority.MEDIUM, Status.OPEN));
    }
    
    public static Ticket getPrototype(String type) {
        try {
            return prototypes.get(type).clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException("Failed to clone prototype ticket", e);
        }
    }
    
    public static void registerPrototype(String type, Ticket prototype