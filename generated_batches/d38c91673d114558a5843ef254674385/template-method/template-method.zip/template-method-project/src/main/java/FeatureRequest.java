public class FeatureRequest extends Ticket {
    private String priority;
    
    public FeatureRequest(String title, String description, String priority) {
        super(title, description);
        this.priority = priority;
    }
    
    @Override
    protected void performWork() {
        System.out.println("Implementing feature with priority: " + priority);
        System.out.println("Creating user documentation");
        System.out.println("Conducting code review");
    }
}