public abstract class Ticket {
    protected String title;
    protected String description;
    protected String status;
    
    public Ticket(String title, String description) {
        this.title = title;
        this.description = description;
        this.status = "CREATED";
    }
    
    // Template method
    public final void processTicket() {
        assignTicket();
        updateStatus("IN_PROGRESS");
        performWork();
        updateStatus("RESOLVED");
        notifyCompletion();
    }
    
    protected abstract void performWork();
    
    protected void assignTicket() {
        System.out.println("Assigning ticket: " + title);
    }
    
    protected void updateStatus(String newStatus) {
        this.status = newStatus;
        System.out.println("Ticket status updated to: " + newStatus);
    }
    
    protected void notifyCompletion() {
        System.out.println("Notifying completion of ticket: " + title);
    }
}