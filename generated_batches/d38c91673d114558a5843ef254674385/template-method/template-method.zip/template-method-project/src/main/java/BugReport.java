public class BugReport extends Ticket {
    private String severity;
    
    public BugReport(String title, String description, String severity) {
        super(title, description);
        this.severity = severity;
    }
    
    @Override
    protected void performWork() {
        System.out.println("Fixing bug with severity: " + severity);
        System.out.println("Running tests for bug fix");
        System.out.println("Documenting the bug fix");
    }
}