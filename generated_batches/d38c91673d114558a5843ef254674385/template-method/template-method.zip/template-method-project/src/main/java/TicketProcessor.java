public class TicketProcessor {
    public static void main(String[] args) {
        Ticket bug = new BugReport("Login page crash", "Users cannot login after password reset", "HIGH");
        Ticket feature = new FeatureRequest("Dark mode support", "Add dark theme option to application", "MEDIUM");
        
        System.out.println("Processing Bug Report:");
        bug.processTicket();
        
        System.out.println("\nProcessing Feature Request:");
        feature.processTicket();