package com.projecttracker.ticket;

public class Ticket {
    private String id;
    private String title;
    private String description;
    private Status status;
    private Priority priority;
    
    public Ticket(String id, String title, String description) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.status = Status.OPEN;
        this.priority = Priority.MEDIUM;
    }
    
    public void updateStatus(Status newStatus) {
        this.status = newStatus;
    }
    
    public void updatePriority(Priority newPriority) {
        this.priority = newPriority;
    }
    
    public void updateTitle(String newTitle) {
        this.title = newTitle;
    }
    
    public void updateDescription(String newDescription) {
        this.description = newDescription;
    }
    
    // Getters
    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public Status getStatus() { return status; }
    public Priority getPriority() { return priority; }
}