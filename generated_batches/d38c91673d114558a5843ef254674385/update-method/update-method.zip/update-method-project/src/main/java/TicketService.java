package com.projecttracker.ticket;

import java.util.ArrayList;
import java.util.List;

public class TicketService {
    private List<Ticket> tickets;
    
    public TicketService() {
        this.tickets = new ArrayList<>();
    }
    
    public void createTicket(String id, String title, String description) {
        tickets.add(new Ticket(id, title, description));
    }
    
    public Ticket getTicket(String id) {
        return tickets.stream()
                .filter(ticket -> ticket.getId().equals(id))
                .findFirst()
                .orElse(null);
    }
    
    public void updateTicketStatus(String ticketId, Status newStatus) {
        Ticket ticket = getTicket(ticketId);
        if (ticket != null) {
            ticket.updateStatus(newStatus);
        }
    }
    
    public void updateTicketPriority(String ticketId, Priority newPriority) {
        Ticket ticket = getTicket(ticketId);
        if (ticket != null) {
            ticket.updatePriority