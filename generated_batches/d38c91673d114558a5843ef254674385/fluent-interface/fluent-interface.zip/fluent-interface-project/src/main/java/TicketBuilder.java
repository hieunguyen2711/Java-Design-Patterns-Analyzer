package com.project.tracker;

public class TicketBuilder {
    
    public static Ticket createTicket(String title) {
        return new Ticket(title);
    }
    
    public static void main(String[] args) {
        // Fluent interface usage example
        Ticket ticket = TicketBuilder.createTicket("Bug Fix")
                .setDescription("Fix login page redirect issue")
                .setAssignee("John Doe")
                .setStatus("Open")
                .setPriority(2)
                .addComment("Initial report from QA team");
        
        System.out.println(ticket);
    }
}