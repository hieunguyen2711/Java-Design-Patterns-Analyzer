package com.projecttracker.service;

import com.projecttracker.model.Ticket;
import java.util.ArrayList;
import java.util.List;

public class TicketService {
    private List<Ticket> tickets;
    
    public TicketService() {
        this.tickets = new ArrayList<>();
    }
    
    public void createTicket(Ticket ticket) {
        tickets.add(ticket);
    }
    
    public List<Ticket> getAllTickets() {
        return new ArrayList<>(tickets);
    }
    
    public Ticket getTicketById(int id) {
        for (Ticket ticket : tickets) {
            if (ticket.getId() == id) {
                return ticket;
            }
        }
        return null;
    }
    
    public void updateTicket(Ticket updatedTicket) {
        for (int i = 0; i < tickets.size(); i++) {
            if (tickets.get(i).getId() == updatedTicket.getId()) {
                tickets.set(i, updatedTicket);
                break;
            }
        }
    }
    
    public void deleteTicket(int id) {
        tickets.removeIf(ticket -> ticket.getId() == id);
    }
}