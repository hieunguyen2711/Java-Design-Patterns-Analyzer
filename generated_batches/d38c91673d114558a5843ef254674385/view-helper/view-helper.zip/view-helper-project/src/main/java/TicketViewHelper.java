package com.projecttracker.view;

import com.projecttracker.ticket.Ticket;
import com.projecttracker.ticket.Priority;
import com.projecttracker.ticket.Status;

public class TicketViewHelper {
    
    public String getPriorityBadge(Priority priority) {
        switch (priority) {
            case LOW:
                return "<span class='badge badge-secondary'>LOW</span>";
            case MEDIUM:
                return "<span class='badge badge-warning'>MEDIUM</span>";
            case HIGH:
                return "<span class='badge badge-danger'>HIGH</span>";
            case URGENT:
                return "<span class='badge badge-dark'>URGENT</span>";
            default:
                return "<span class='badge badge-default'>UNKNOWN</span>";
        }
    }
    
    public String