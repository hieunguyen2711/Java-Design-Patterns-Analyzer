package com.projecttracker.ticket;

public class Ticket {
    private String id;
    private String title;
    private String description;
    private Priority priority;
    private Status status;
    private String assignee;
    
    public Ticket(String id, String title, String description) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.priority = Priority.MEDIUM;
        this.status = Status.OPEN;
    }
    
    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public Priority getPriority() { return priority; }
    public void setPriority(Priority priority) { this.priority = priority; }
    
    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }
    
    public String getAssignee() { return assignee; }
    public void setAssignee(String assignee) { this.assignee = assignee; }
}