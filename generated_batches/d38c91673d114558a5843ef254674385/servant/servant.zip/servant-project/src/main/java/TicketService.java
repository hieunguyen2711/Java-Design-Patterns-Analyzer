package com.projecttracker.service;

import com.projecttracker.ticket.Ticket;
import java.util.ArrayList;
import java.util.List;

public class TicketService {
    private List<Ticket> tickets;
    
    public TicketService() {
        this.tickets = new ArrayList<>();
    }
    
    public void createTicket(Ticket ticket) {
        tickets.add(ticket);
    }
    
    public void assignTicket(String ticketId, String assignee) {
        Ticket ticket = findTicketById(ticketId);
        if (ticket != null) {
            ticket.setAssignee(assignee);
        }
    }
    
    public void updateStatus(String ticketId, Status status) {
        Ticket ticket = findTicketById(ticketId);
        if (ticket != null) {
            ticket.setStatus(status);
        }
    }
    
    public List<T