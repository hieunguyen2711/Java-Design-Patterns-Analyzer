package com.example.tickettracker;

public enum Status {
    OPEN, IN_PROGRESS, RESOLVED, CLOSED
}