package com.example.tickettracker;

public enum Priority {
    LOW, MEDIUM, HIGH, URGENT
}