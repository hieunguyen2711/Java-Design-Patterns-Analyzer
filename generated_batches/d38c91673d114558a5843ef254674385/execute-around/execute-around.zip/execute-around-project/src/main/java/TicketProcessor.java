package com.example.tickettracker;

import java.util.List;
import java.util.function.Consumer;

public class TicketProcessor {
    
    public static void processTickets(TicketManager manager, Consumer<Ticket> processor) {
        // Execute-around pattern: setup and cleanup around processing
        System.out.println("Starting ticket processing...");
        
        List<Ticket> tickets = manager.getTickets();
        for (Ticket ticket : tickets) {
            processor.accept(ticket);
        }
        
        System.out.println("Finished ticket processing.");
    }
}