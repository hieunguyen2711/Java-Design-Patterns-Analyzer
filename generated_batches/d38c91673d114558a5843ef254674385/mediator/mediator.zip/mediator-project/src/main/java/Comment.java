public class Comment {
    private String id;
    private String content;
    private User author;
    private String timestamp;
    
    public Comment(String id, String content, User