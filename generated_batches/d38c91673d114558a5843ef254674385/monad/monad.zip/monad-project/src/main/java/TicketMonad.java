package com.project.tracker;

import java.util.Optional;
import java.util.function.Function;

public class TicketMonad {
    private final Optional<Ticket