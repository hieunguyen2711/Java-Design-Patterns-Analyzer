package com.project.tracker;

public class Ticket {
    private final String id;
    private final String title;
    private final String description;
    private final Priority priority;
    private final Status status;
    private final String assignee;

    public Ticket(String id, String title, String description, Priority priority, Status status, String assignee) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.priority = priority;
        this.status = status;
        this.assignee = assignee;
    }

    // Getters
    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public Priority getPriority() { return priority; }
    public Status getStatus() { return status; }
    public String getAssignee() { return assignee; }

    // Builder pattern for creating tickets
    public static class Builder {
        private String id;
        private String title;
        private String description;
        private Priority priority = Priority.MEDIUM;
        private Status status = Status.OPEN;
        private String assignee;

        public Builder withId(String id) {
            this.id = id;
            return this;
        }

        public Builder withTitle(String title) {
            this.title = title;
            return this;
        }

        public Builder withDescription(String description) {
            this.description = description;
            return this;
        }

        public Builder withPriority(Priority priority) {
            this.priority = priority;
            return this;
        }

        public Builder withStatus(Status status) {
            this.status = status;
            return this;
        }

        public Builder withAssignee(String assignee) {
            this.assignee = assignee;
            return this;
        }

        public Ticket build() {
            return new Ticket(id, title, description, priority, status, assignee);
        }
    }

    @Override
    public String toString() {
        return "Ticket{" +
                "id='" + id + '\'' +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", priority=" + priority +
                ", status=" + status +
                ", assignee='" + assignee + '\'' +
                '}';
    }
}