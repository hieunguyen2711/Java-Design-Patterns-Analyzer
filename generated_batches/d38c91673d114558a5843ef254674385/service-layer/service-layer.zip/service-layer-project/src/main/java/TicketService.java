import java.util.*;

public interface TicketService {
    Ticket createTicket(String title, String description, Priority priority);
    void assignTicket(int ticketId, String assignee);
    void updateTicketStatus(int ticketId, Status status);
    List<Ticket> getTicketsByPriority(Priority priority);
    List<Ticket> getAllTickets();
}