import java.util.*;

public class TicketServiceImpl implements TicketService {
    private Map<Integer, Ticket> tickets = new HashMap<>();
    private int nextId = 1;

    @Override
    public Ticket createTicket(String title, String description, Priority priority) {
        Ticket ticket = new Ticket(nextId++, title, description, priority);
        tickets.put(ticket.getId(), ticket);
        return ticket;
    }

    @Override
    public void assignTicket(int ticketId, String assign