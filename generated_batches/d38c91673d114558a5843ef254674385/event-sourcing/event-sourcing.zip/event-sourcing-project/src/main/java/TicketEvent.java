package com.example.projecttracker;

import java.time.LocalDateTime;
import java.util.UUID;

public abstract class TicketEvent {
    private final String eventId;
    private final LocalDateTime timestamp;
    private final String ticketId;
    
    public TicketEvent(String ticketId) {
        this.eventId = UUID.randomUUID().toString();
        this.timestamp = LocalDateTime.now();
        this.ticketId = ticketId;
    }
    
    public String getEventId() {
        return eventId;
    }
    
    public LocalDateTime getTimestamp() {
        return timestamp;
    }
    
    public String getTicketId() {
        return