package com.example.projecttracker;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Ticket {
    private final String id;
    private String title;
    private String description;
    private Priority priority;
    private Status status;
    private String assignee;
    private final List<TicketEvent> events;
    
    public Ticket(String title, String description, Priority priority) {
        this.id = UUID.randomUUID().toString();
        this.title = title;
        this.description = description;
        this.priority = priority;
        this.status = Status.OPEN;
        this.events = new ArrayList<>();
        this.events.add(new TicketCreatedEvent(this.id, title, description, priority));
    }
    
    public void assignTo(String assignee) {
        this.assignee = assignee;
        events.add(new TicketAssignedEvent(this.id, assignee));
    }
    
    public void updateStatus(Status status) {
        this.status = status;
        events.add(new TicketStatusUpdatedEvent(this.id, status));
    }
    
    public void addComment(String comment) {
        events.add(new TicketCommentAddedEvent(this.id, comment));
    }
    
    public void updatePriority(Priority priority) {
        this.priority = priority;
        events.add(new TicketPriorityUpdatedEvent(this.id, priority));
    }
    
    public String getId() {
        return id;
    }
    
    public String getTitle() {
        return title;
    }
    
    public String getDescription() {
        return description;
    }
    
    public Priority getPriority() {
        return priority;
    }
    
    public Status getStatus() {
        return status;
    }
    
    public String getAssignee() {
        return assignee;
    }
    
    public List<TicketEvent> getEvents() {
        return new ArrayList<>(events);
    }
}