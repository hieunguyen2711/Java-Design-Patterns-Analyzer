package com.example.projecttracker;

public class TicketBuilder {
    private Ticket ticket;
    
    public TicketBuilder(String id, String title) {
        this.ticket = new Ticket(id, title);
    }
    
    public TicketBuilder withDescription(String description) {
        ticket.setDescription(description);
        return this;
    }
    
    public TicketBuilder withPriority(Priority priority) {
        ticket.setPriority(priority);
        return this;
    }
    
    public TicketBuilder withStatus(Status status) {
        ticket.setStatus(status);
        return this;
    }
    
    public TicketBuilder assignedTo(String assignee) {
        ticket.setAssignee(assignee);
        return this;
    }