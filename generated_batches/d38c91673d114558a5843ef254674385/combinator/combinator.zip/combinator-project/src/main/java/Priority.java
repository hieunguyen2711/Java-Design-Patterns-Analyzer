package com.example.projecttracker;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH,
    URGENT
}