package com.projecttracker.ticket;

import java.util.*;

public class TicketManager {
    private final Map<String, Ticket> tickets;
    
    public TicketManager() {
        this.tickets = new HashMap<>();
    }

    public Ticket createTicket(String title, String description, Priority priority) {
        Ticket ticket = new Ticket(title, description, priority);