package com.projecttracker.ticket;

import java.util.Date;
import java.util.UUID;

public class Ticket {
    private final String id;
    private String title;
    private String description;
    private Priority priority;
    private Status status;
    private String assignee;
    private Date createdAt;
    private Date updatedAt;

    public Ticket(String title, String description, Priority priority) {
        this.id = UUID.randomUUID().toString();
        this.title = title;
        this.description = description;
        this.priority = priority;
        this.status = Status.OPEN;
        this.createdAt = new Date();
        this.updatedAt = new Date();
    }

    // Getters and setters
    public String getId() { return id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { 
        this.title = title; 
        this.updatedAt = new Date();
    }
    public String getDescription() { return description; }
    public void setDescription(String description) { 
        this.description = description; 
        this.updatedAt = new Date();
    }
    public Priority getPriority() { return priority; }
    public void setPriority(Priority priority) { 
        this.priority = priority; 
        this.updatedAt = new Date();
    }
    public Status getStatus() { return status; }
    public void setStatus(Status status) { 
        this.status = status; 
        this.updatedAt = new Date();
    }
    public String getAssignee() { return assignee; }
    public void setAssignee(String assignee) { 
        this.assignee = assignee; 
        this.updatedAt = new Date();
    }
    public Date getCreatedAt() { return createdAt; }
    public Date getUpdatedAt() { return updatedAt; }

    @Override
    public String toString() {
        return "Ticket{" +
                "id='" + id + '\'' +
                ", title='" + title + '\'' +
                ", priority=" + priority +
                ", status=" + status +
                ", assignee='" + assignee + '\'' +
                '}';
    }
}