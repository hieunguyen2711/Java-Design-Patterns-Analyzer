package com.projecttracker.ticket;

public class Ticket {
    private String id;
    private String title;
    private String description;
    private Priority priority;
    private Status status;
    private String assignee;
    
    public Ticket(String id, String title, String description, Priority priority) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.priority = priority;
        this.status = Status.OPEN;
    }
    
    // Twin pattern - create a copy with different ID
    public Ticket twin() {
        return new Ticket("TWIN-" + this.id, this.title, this.description, this.priority);
    }
    
    // Twin pattern - create a copy with same ID but different status
    public Ticket twin(Status newStatus) {
        Ticket ticket = new Ticket(this.id, this.title, this.description, this.priority);
        ticket.status = newStatus;
        return ticket;
    }
    
    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public Priority getPriority() { return priority; }
    public void setPriority(Priority priority) { this.priority = priority; }
    
    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }
    
    public String getAssignee() { return assignee; }
    public void setAssignee(String assignee) { this.assignee = assignee; }
}