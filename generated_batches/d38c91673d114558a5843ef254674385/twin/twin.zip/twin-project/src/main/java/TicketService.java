package com.projecttracker.ticket;

import java.util.ArrayList;
import java.util.List;

public class TicketService {
    private List<Ticket> tickets;
    
    public TicketService() {
        this.tickets = new ArrayList<>();
    }
    
    public void createTicket(String id, String title, String