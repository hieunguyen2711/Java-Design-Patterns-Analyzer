import java.util.*;

public class TicketService {
    private Map<Integer, Ticket> tickets;
    private Map<Integer, CommentProxy> commentProxies;

    public TicketService() {
        this.tickets = new HashMap<>();
        this.commentProxies = new HashMap<>();
    }

    public void createTicket(int id, String title, String description) {
        tickets.put(id, new Ticket(id, title, description));
    }

    public Ticket getTicket(int id) {
        return tickets.get(id);
    }

    public CommentProxy getComments(int ticketId) {
        if (!commentProxies.containsKey(ticketId)) {
            commentProxies.put(ticketId, new CommentProxy(ticketId));
        }
        return commentProxies.get(ticketId);
    }

    public void assignTicket(int id, String assignee) {
        Ticket ticket = tickets.get(id);
        if (ticket != null) {
            ticket.setAssignee(assignee);
        }
    }

    public void updateStatus(int id, Status status) {
        Ticket ticket = tickets.get(id);
        if (ticket != null) {
            ticket.setStatus(status);
        }
    }
}