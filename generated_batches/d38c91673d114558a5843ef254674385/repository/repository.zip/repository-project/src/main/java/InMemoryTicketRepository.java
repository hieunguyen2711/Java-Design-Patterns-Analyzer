import java.util.*;
import java.util.stream.Collectors;

public class InMemoryTicketRepository implements TicketRepository {
    private final Map<Integer, Ticket> tickets = new HashMap<>();
    private int nextId = 1;

    @Override
    public Ticket save(Ticket ticket) {
        if (ticket.getId() == 0) {
            ticket.setId(nextId++);
        }
        tickets.put(ticket.getId(), ticket);
        return ticket;
    }

    @Override
    public Optional<Ticket> findById(int id) {
        return Optional.ofNullable(tickets.get(id));
    }

    @Override
    public List<Ticket> findAll() {
        return new ArrayList<>(tickets.values());
    }

    @Override
    public void deleteById(int id