import java.util.*;

public interface TicketRepository {
    Ticket save(Ticket ticket);
    Optional<Ticket> findById(int id);
    List<Ticket> findAll();
    void deleteById(int id);
    List<Ticket> findByStatus(String status);
    List<Ticket> findByAssignee(String assignee);
}