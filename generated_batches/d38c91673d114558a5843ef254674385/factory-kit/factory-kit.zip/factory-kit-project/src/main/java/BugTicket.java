public class BugTicket extends Ticket {
    
    private String severity;
    private String reproducibility;

    public BugTicket(String id, String title, String description, Priority priority) {
        super(id, title, description, priority);
        this.severity =