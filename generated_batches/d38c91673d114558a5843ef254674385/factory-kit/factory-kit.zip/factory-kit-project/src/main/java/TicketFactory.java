public class TicketFactory {
    
    public static Ticket createTicket(String type, String id, String title, 
                                    String description, Priority priority) {
        switch (type.toLowerCase()) {
            case "bug":
                return new BugTicket(id, title, description, priority);
            case "feature":
                return new FeatureTicket(id, title, description, priority);
            case "task":
                return new TaskTicket(id, title, description, priority);
            default:
                throw new IllegalArgumentException("Unknown ticket type: " + type);
        }
    }
}