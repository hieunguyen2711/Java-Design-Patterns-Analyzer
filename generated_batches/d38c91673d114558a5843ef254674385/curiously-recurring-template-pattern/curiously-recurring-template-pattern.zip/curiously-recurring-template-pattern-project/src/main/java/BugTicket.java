package com.project.tracker.ticket;

public class BugTicket extends Ticket<BugTicket> {
    private String severity;
    
    public BugTicket(String id, String title, String description, Priority priority, String severity) {
        super(id, title, description, priority);
        this.severity = severity;
    }
    
    @Override
    public BugTicket withTitle(String title) {
        return new BugTicket(this.id, title, this.description, this.priority, this.severity);
    }
    
    @Override
    public BugTicket withDescription(String description) {
        return new BugTicket(this.id, this.title, description, this.priority, this.severity);
    }
    
    @Override
    public BugTicket withPriority(Priority priority) {
        return new BugTicket(this.id, this.title, this.description, priority, this.severity);
    }
    
    public String getSeverity() {
        return severity;
    }
    
    public BugTicket withSeverity(String severity) {
        return new BugTicket(this.id, this.title, this.description, this.priority, severity);
    }
}