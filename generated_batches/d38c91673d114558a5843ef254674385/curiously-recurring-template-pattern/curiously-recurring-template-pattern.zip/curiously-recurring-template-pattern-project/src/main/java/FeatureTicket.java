package com.project.tracker.ticket;

public class FeatureTicket extends Ticket<FeatureTicket> {
    private String estimatedHours;
    
    public FeatureTicket(String id, String title, String description, Priority priority, String estimatedHours) {
        super(id, title, description, priority);
        this