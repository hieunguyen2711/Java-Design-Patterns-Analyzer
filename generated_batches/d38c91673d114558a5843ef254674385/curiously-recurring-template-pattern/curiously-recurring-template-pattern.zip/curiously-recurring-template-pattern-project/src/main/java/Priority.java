package com.project.tracker.ticket;

public enum Priority {
    LOW, MEDIUM, HIGH, URGENT
}