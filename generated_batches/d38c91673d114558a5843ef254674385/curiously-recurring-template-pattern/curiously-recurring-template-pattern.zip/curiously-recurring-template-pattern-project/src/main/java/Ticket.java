package com.project.tracker.ticket;

public abstract class Ticket<T extends Ticket<T>> {
    protected String id;
    protected String title;
    protected String description;
    protected Priority priority;
    
    public Ticket(String id, String title, String description, Priority priority) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.priority = priority;
    }
    
    public abstract T withTitle(String title);
    public abstract T withDescription(String description);
    public abstract T withPriority(Priority priority);
    
    public String getId() {
        return id;
    }
    
    public String getTitle() {
        return title;
    }
    
    public String getDescription() {
        return description;
    }
    
    public Priority getPriority() {
        return priority;
    }
}