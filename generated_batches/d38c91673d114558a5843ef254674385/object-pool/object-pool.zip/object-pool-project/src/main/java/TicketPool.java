import java.util.ArrayDeque;
import java.util.Deque;

public class TicketPool {
    private static final int POOL_SIZE = 10;
    private static volatile TicketPool instance;
    private final Deque<Ticket> pool;
    
    private TicketPool() {
        pool = new ArrayDeque<>(POOL_SIZE);
        initializePool();
    }
    
    public static TicketPool getInstance() {
        if (instance == null) {
            synchronized (TicketPool.class) {
                if (instance == null) {
                    instance = new TicketPool();
                }
            }
        }
        return instance;
    }
    
    private void initializePool() {
        for (int i = 0; i < POOL_SIZE; i++) {
            pool.push(new Ticket("T" + i, "Default Title", "Default Description", "OPEN", 1));
        }
    }
    
    public Ticket acquireTicket(String id, String title, String description, String status, int priority) {
        Ticket ticket = pool.pollLast();
        if (ticket ==