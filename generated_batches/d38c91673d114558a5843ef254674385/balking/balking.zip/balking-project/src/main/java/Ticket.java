package com.projecttracker.ticket;

public class Ticket {
    private String id;
    private String title;
    private Status status;
    
    public Ticket(String id, String title) {
        this.id = id;
        this.title = title;
        this.status = Status.OPEN;
    }
    
    public String getId() {
        return id;
    }
    
    public String getTitle() {
        return title;
    }
    
    public Status getStatus() {
        return status;
    }
    
    public void setStatus(Status status) {
        this.status = status;
    }
}