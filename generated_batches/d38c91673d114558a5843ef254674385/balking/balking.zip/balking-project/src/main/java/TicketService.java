package com.projecttracker.ticket;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

public class TicketService {
    private final ConcurrentHashMap<String, Ticket> tickets = new ConcurrentHashMap<>();
    private final AtomicBoolean isProcessing = new AtomicBoolean(false);
    
    public void createTicket(String id, String title) {
        if (tickets.putIfAbsent(id, new Ticket(id, title)) == null) {
            System.out.println("Ticket " + id + " created");
        }
    }
    
    public boolean assignTicket(String ticketId, String assignee) {
        // Balking pattern: only proceed if not already processing
        if (!isProcessing.compareAndSet(false, true)) {
            System.out.println("Balking: Ticket assignment already in progress for " + ticketId);
            return false;
        }
        
        try {
            Ticket ticket = tickets.get(ticketId);
            if (ticket != null) {
                // Simulate processing delay
                Thread.sleep(100);
                ticket.setStatus(Status.IN_PROGRESS);
                System.out.println("Ticket " + ticketId + " assigned to " + assignee);
                return true;
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            isProcessing.set(false); // Always reset the flag
        }
        
        return false;
    }
    
    public boolean resolveTicket(String ticketId) {
        if (!isProcessing.compareAndSet(false, true)) {
            System.out.println("Balking: Ticket resolution already in progress for " + ticketId);
            return false;
        }
        
        try {
            Ticket ticket = tickets.get(ticketId);
            if (