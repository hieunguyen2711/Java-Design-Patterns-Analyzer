public class ProjectServiceImpl implements ProjectService {
    @Override
    public void createProject(String name) {
        System.out.println("Creating project: " + name);
    }
}