public interface ProjectService {
    void createProject(String name);
}