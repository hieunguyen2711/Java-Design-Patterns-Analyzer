public interface TicketService {
    void createTicket(String title, String description);
}