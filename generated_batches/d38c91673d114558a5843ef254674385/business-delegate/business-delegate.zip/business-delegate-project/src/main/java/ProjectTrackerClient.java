public class ProjectTrackerClient {
    public static void main(String[] args) {
        BusinessDelegate delegate = new BusinessDelegate();
        delegate.createProject("Website Redesign");
        delegate.createTicket("Fix login bug", "User cannot log in after password reset");
    }
}