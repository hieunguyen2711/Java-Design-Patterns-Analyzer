public class BusinessDelegate {
    private ProjectService projectService;
    private TicketService ticketService;
    
    public void createProject(String name) {
        if (projectService == null) {
            projectService = new ProjectServiceImpl();
        }
        projectService.createProject(name);
    }
    
    public void createTicket(String title, String description) {
        if (ticketService == null) {
            ticketService = new TicketServiceImpl();
        }
        ticketService.createTicket(title, description);
    }
}