public class TicketServiceImpl implements TicketService {
    @Override
    public void createTicket(String title, String description) {
        System.out.println("Creating ticket: " + title);
    }
}