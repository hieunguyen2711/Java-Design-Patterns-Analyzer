package com.projecttracker.ticket;

import java.time.LocalDateTime;
import java.util.Objects;

public class TicketBuilder {
    private int id;
    private String title;
    private String description;
    private Priority priority;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    
    public TicketBuilder setId(int id) {
        this.id = id;
        return this;
    }
    
    public TicketBuilder setTitle(String title) {
        this.title = title;
        return this;
    }
    
    public TicketBuilder setDescription(String description) {
        this.description = description;
        return this;
    }
    
    public TicketBuilder setPriority(Priority priority) {