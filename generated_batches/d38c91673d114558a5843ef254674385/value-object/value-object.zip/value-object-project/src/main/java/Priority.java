package com.projecttracker.ticket;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH,
    URGENT
}