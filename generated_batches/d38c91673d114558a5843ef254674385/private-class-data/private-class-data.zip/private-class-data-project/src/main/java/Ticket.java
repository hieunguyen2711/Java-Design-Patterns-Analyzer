package com.projecttracker.ticket;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Ticket {
    private final UUID id;
    private final String title;
    private final String description;
    private final Priority priority;
    private final Status status;
    private final List<Comment> comments;
    private final String assignee;
    
    public Ticket(String title, String description, Priority priority, String assignee) {
        this.id = UUID.randomUUID();
        this.title = title;
        this.description = description;
        this.priority = priority;
        this.status = Status.OPEN;
        this.comments = new ArrayList<>();
        this.assignee = assignee;
    }
    
    public TicketId getId() {
        return new TicketId(id);
    }
    
    public String getTitle() {
        return title;
    }
    
    public String getDescription() {
        return description;
    }
    
    public Priority getPriority() {
        return priority;
    }
    
    public Status getStatus() {
        return status;
    }
    
    public List<Comment> getComments() {
        return new ArrayList<>(comments);
    }
    
    public String getAssignee() {
        return assignee;
    }
    
    public void addComment(Comment comment) {
        comments.add(comment);
    }
    
    public void updateStatus(Status newStatus) {
        this.status = newStatus;
    }
    
    public static class TicketId {
        private final UUID id;
        
        private TicketId(UUID id) {
            this.id = id;
        }
        
        public UUID getId() {
            return id;
        }
        
        @Override
        public boolean equals(Object obj) {
            if (this == obj) return true;
            if (obj == null || getClass() != obj.getClass()) return false;
            TicketId ticketId = (TicketId) obj;
            return id.equals(ticketId.id);
        }
        
        @Override
        public int hashCode() {
            return id.hashCode();
        }
    }
}