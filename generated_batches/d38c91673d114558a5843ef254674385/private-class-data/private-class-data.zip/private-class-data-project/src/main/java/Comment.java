package com.projecttracker.ticket;

import java.time.LocalDateTime;
import java.util.UUID;

public class Comment {
    private final UUID id;
    private final String content;
    private final LocalDateTime timestamp;
    private final String author;
    
    public Comment(String content, String author) {
        this.id = UUID.randomUUID();
        this.content = content;
        this.timestamp = LocalDateTime.now();
        this.author = author;
    }