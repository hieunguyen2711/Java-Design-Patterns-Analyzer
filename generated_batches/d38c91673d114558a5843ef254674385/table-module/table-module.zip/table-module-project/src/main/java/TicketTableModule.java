package com.projecttracker.ticket;

import java.util.*;

public class TicketTableModule {
    private List<Ticket> tickets;
    
    public TicketTableModule() {
        this.tickets = new ArrayList<>();
    }
    
    public void addTicket(Ticket ticket) {
        tickets.add(ticket);
    }
    
    public void removeTicket(String id) {
        tickets.removeIf(ticket -> ticket.getId().equals(id));
    }
    
    public List<Ticket> getAllTickets() {
        return new ArrayList<>(tickets);
    }
    
    public Ticket getTicketById(String id) {
        return tickets.stream()
                .filter(ticket -> ticket.getId().equals(id))
                .findFirst()
                .orElse(null);
    }
    
    public List<Ticket> getTicketsByStatus(Status status