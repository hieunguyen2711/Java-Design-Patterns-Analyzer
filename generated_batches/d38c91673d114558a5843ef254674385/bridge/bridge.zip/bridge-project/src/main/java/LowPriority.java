public class LowPriority implements Priority {
    @Override
    public String getPriorityLevel() {
        return "LOW";
    }

    @Override
    public int getPriorityValue() {
        return 1;
    }
}