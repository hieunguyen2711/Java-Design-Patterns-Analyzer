public class HighPriority implements Priority {
    @Override
    public String getPriorityLevel() {
        return "HIGH";
    }

    @Override
    public int getPriorityValue() {
        return 3;
    }
}