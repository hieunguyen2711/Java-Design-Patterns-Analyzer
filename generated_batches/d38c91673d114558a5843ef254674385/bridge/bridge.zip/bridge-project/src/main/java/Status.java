public interface Status {
    String getStatusName();
    void updateStatus(Ticket ticket);
}