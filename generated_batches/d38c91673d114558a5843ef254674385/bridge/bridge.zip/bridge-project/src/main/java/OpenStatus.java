public class OpenStatus implements Status {
    @Override
    public String getStatusName() {
        return "OPEN";
    }

    @Override
    public void updateStatus(Ticket ticket) {
        ticket.setStatus(this);