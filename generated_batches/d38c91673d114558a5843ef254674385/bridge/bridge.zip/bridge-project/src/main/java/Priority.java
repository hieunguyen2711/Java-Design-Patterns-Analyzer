public interface Priority {
    String getPriorityLevel();
    int getPriorityValue();
}