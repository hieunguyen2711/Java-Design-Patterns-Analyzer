public class MediumPriority implements Priority {
    @Override
    public String getPriorityLevel() {
        return "MEDIUM";
    }

    @Override
    public int getPriorityValue() {
        return 2;
    }
}