package com.projecttracker.ticket;

import java.util.ArrayList;
import java.util.List;

public class TicketService {
    private List<Ticket> tickets = new ArrayList<>();
    
    public void createTicket(String title, String description, Priority priority) {
        tickets.add(new Ticket(title, description, priority));
    }
    
    public void updateTicket(int index, String title, String description, Priority priority) {
        if (index >= 0 && index < tickets.size()) {
            Ticket ticket = tickets.get(index);
            ticket.setTitle(title);
            ticket.setDescription(description);
            ticket.setPriority(priority);
            
            // Check dirty flag before saving
            if (ticket.isDirty()) {
                saveTicket(ticket);
                ticket.clearDirtyFlag();
            }
        }
    }
    
    private void saveTicket(Ticket ticket) {
        System.out.println("Saving ticket: " + ticket.getTitle() + 
                          " with priority: " + ticket.getPriority());
    }
}