package com.projecttracker.ticket;

public class Main {
    public static void main(String[] args) {
        TicketService service = new TicketService();
        
        //