package com.projecttracker.ticket;

public class Ticket {
    private String title;
    private String description;
    private Priority priority;
    private boolean isDirty = false;
    
    public Ticket(String title, String description, Priority priority) {
        this.title = title;
        this.description = description;
        this.priority = priority;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
        markDirty();
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
        markDirty();
    }
    
    public Priority getPriority() {
        return priority;
    }
    
    public void setPriority(Priority priority) {
        this.priority = priority;
        markDirty();
    }
    
    private void markDirty() {
        isDirty = true;
    }
    
    public boolean isDirty() {
        return isDirty;
    }
    
    public void clearDirtyFlag() {
        isDirty = false;
    }
}