import java.util.function.Function;

public class TicketProcessor {
    private Function<Ticket, Ticket> processorChain;
    
    public TicketProcessor() {
        this.processorChain = ticket -> ticket; // Identity function as base
    }
    
    public void addProcessor(Function<Ticket, Ticket> processor) {
        this.processorChain = this.processorChain.andThen(processor);
    }
    
    public Ticket process(Ticket ticket) {
        return processorChain.apply(ticket);
    }
}