public class TicketService {
    private TicketProcessor processor;
    
    public TicketService() {
        this.processor = new TicketProcessor();
        setupDefaultProcessors();
    }
    
    private void setupDefaultProcessors() {
        // Function composition - each processor modifies the ticket in sequence
        processor.addProcessor(this::assignPriority);
        processor.addProcessor(this::setInitialStatus