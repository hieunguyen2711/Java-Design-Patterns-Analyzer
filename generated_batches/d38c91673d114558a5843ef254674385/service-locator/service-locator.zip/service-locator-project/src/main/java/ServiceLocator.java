import java.util.HashMap;
import java.util.Map;

public class ServiceLocator {
    private static final Map<Class<?>, Object> services = new HashMap<>();
    
    static {
        services.put(TicketService.class, new TicketServiceImpl());
        services.put(NotificationService.class, new EmailNotificationService());
    }
    
    public static <T> T getService(Class<T> serviceClass) {
        return serviceClass.cast(services.get(serviceClass));
    }
}