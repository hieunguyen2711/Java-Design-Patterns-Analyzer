public class TicketServiceImpl implements TicketService {
    private NotificationService notificationService;
    
    public TicketServiceImpl() {
        this.notificationService = ServiceLocator.getService(NotificationService.class);
    }
    
    @Override
    public void createTicket(String description) {
        System.out.println("Creating ticket: " + description);
        notificationService.sendNotification("New ticket created: " + description);
    }
    
    @Override
    public void assignTicket(int ticketId, String assignee) {
        System.out.println("Assigning ticket " + ticketId + " to " + assignee);
        notificationService.sendNotification("Ticket " + ticketId + " assigned to " + assignee);
    }
    
    @Override
    public void updateStatus(int ticketId, String status) {
        System.out.println("Updating ticket " + ticketId + " status to: " + status);
        notificationService.sendNotification("Ticket " + ticketId + " status updated to: " + status);
    }
}