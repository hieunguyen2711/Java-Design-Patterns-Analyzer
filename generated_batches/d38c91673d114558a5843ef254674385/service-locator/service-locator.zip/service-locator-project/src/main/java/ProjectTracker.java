public class ProjectTracker {
    public static void main(String[] args) {
        TicketService ticketService = ServiceLocator.getService(TicketService.class);
        
        ticketService.createTicket("Bug in login page");
        ticketService.assignTicket(1, "John Doe");
        ticketService.updateStatus(1, "In