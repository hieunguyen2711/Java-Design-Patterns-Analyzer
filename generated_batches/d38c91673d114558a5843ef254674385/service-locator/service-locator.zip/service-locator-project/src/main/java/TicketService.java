public interface TicketService {
    void createTicket(String description);
    void assignTicket(int ticketId, String assignee);
    void updateStatus(int ticketId, String status);
}