import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

public class TicketManager {
    private static volatile TicketManager instance;
    private final Map<Integer, Ticket> tickets;
    
    private TicketManager() {
        this.tickets = new ConcurrentHashMap<>();
    }
    
    public static TicketManager getInstance() {
        if (instance == null) {
            synchronized (TicketManager.class) {
                if (instance == null) {
                    instance = new TicketManager();
                }
            }
        }
        return instance;
    }
    
    public void createTicket(int id, String title, String description) {
        tickets.put(id, new Ticket(id, title, description));
    }
    
    public Ticket getTicket(int id) {
        return tickets.get(id);
    }
    
    public void updateTicketStatus(int id, Status status) {
        Ticket ticket = tickets.get(id);
        if (ticket != null) {
            ticket.setStatus(status);
        }
    }
}