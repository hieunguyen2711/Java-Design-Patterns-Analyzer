public class Comment {
    private int id;
    private String text;
    private