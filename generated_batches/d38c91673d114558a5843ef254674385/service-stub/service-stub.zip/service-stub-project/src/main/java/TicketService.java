package com.projecttracker.service;

public interface TicketService {
    void createTicket(String description);
    void assignTicket(int ticketId, String assignee);
    void updateStatus(int ticketId, String status);
    void addComment(int ticketId, String comment);
    void setPriority(int ticketId, int priority);
}