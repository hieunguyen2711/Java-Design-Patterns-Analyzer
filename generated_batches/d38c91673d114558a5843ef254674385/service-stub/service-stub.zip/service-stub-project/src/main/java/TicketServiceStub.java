package com.projecttracker.service;

public class TicketServiceStub implements TicketService {
    
    @Override
    public void createTicket(String description) {
        System.out.println("STUB: Creating ticket with description: " + description);
    }
    
    @Override
    public void assignTicket(int ticketId