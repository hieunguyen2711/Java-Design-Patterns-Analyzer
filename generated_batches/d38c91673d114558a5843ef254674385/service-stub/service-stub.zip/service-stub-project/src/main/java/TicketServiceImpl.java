package com.projecttracker.service;

import java.util.HashMap;
import java.util.Map;

public class TicketServiceImpl implements TicketService {
    private Map<Integer, Ticket> tickets = new HashMap<>();
    private int nextTicketId = 1;
    
    @Override
    public void createTicket(String description) {
        Ticket ticket = new Ticket(nextTicketId++, description);
        tickets.put(ticket.getId(), ticket);
        System.out.println("Created ticket: " + ticket);
    }
    
    @Override
    public void assignTicket(int ticketId, String assignee) {
        Ticket ticket = tickets.get(ticketId);
        if (ticket != null) {
            ticket.setAssignee(assignee);
            System.out.println("Assigned ticket " + ticketId + " to " + assignee);
        }
    }
    
    @Override
    public void updateStatus(int ticketId, String status) {
        Ticket ticket = tickets.get(ticketId);
        if (ticket != null) {
            ticket.setStatus(status);
            System.out.println("Updated ticket " + ticketId + " status to: " + status);
        }
    }
    
    @Override
    public void addComment(int ticketId, String comment) {
        Ticket ticket = tickets.get(ticketId);
        if (ticket != null) {
            ticket.addComment(comment);
            System.out.println("Added comment to ticket " + ticketId);
        }
    }
    
    @Override
    public void setPriority(int ticketId, int priority) {
        Ticket ticket = tickets.get(ticketId);
        if (ticket != null) {
            ticket.setPriority(priority);
            System.out.println("Set priority for ticket " + ticketId + " to: " + priority);
        }
    }
}