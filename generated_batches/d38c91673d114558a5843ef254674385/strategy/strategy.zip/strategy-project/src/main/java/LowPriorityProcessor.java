package com.projecttracker.ticket;

public class LowPriorityProcessor implements TicketProcessor {
    @Override
    public void process(Ticket ticket) {
        System.out.println("Processing low priority ticket: " + ticket.getTitle());
        ticket.setStatus(Status.IN_PROGRESS);
    }
}