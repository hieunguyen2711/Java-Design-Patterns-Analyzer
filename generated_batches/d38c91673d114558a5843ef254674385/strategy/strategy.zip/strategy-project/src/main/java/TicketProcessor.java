package com.projecttracker.ticket;

public interface TicketProcessor {
    void process(Ticket ticket);
}