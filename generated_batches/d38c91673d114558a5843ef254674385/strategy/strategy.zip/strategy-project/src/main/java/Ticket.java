package com.projecttracker.ticket;

import java.util.ArrayList;
import java.util.List;

public class Ticket {
    private String id;
    private String title;
    private String description;
    private Priority priority;
    private Status status;
    private List<Comment> comments;
    
    public Ticket(String id, String title, String description, Priority priority) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.priority = priority;
        this.status = Status.OPEN;
        this.comments = new ArrayList<>();
    }
    
    public void addComment(Comment comment) {
        comments.add(comment);
    }
    
    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public Priority getPriority() { return priority; }
    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }
    public List<Comment> getComments() { return comments; }
}