package com.projecttracker.ticket;

public class HighPriorityProcessor implements TicketProcessor {
    @Override
    public void process(Ticket ticket) {
        System.out.println("