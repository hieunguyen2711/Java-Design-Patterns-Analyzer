import java.util.ArrayList;
import java.util.List;

public class TicketTracker {
    private final List<Ticket> tickets = new ArrayList<>();
    
    public Ticket createTicket(String ticketId, String type, Priority