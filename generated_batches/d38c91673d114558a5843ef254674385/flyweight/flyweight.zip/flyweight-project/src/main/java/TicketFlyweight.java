public class TicketFlyweight {
    private final String type;
    private final Priority priority;
    
    public TicketFlyweight(String type, Priority priority) {
        this.type = type;
        this.priority = priority;
    }
    
    public void displayTicketDetails(String ticketId, String assignee, String status) {
        System.out.println("Ticket ID: " + ticketId);
        System.out.println("Type: " + type);
        System.out.println("Priority: " + priority);
        System.out.println("Assignee: " + assignee);
        System.out.println("Status: " + status);
        System.out.println("------------------------");
    }
}