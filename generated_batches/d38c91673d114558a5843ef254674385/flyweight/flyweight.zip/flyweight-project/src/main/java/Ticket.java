public class Ticket {
    private final String ticketId;
    private final TicketFlyweight flyweight;
    private String assignee;
    private String status;
    
    public Ticket(String ticketId, TicketFlyweight flyweight) {
        this.ticketId = ticketId;
        this.flyweight = flyweight;
    }
    
    public void setAssignee(String assignee) {
        this.assignee = assignee;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public void displayTicket() {
        flyweight.displayTicketDetails(ticketId, assignee, status);
    }
}