import java.util.HashMap;
import java.util.Map;

public class FlyweightFactory {
    private static final Map<String, TicketFlyweight> flyweights = new HashMap<>();
    
    public static TicketFlyweight getTicketFlyweight(String type, Priority priority) {
        String key = type + "_" + priority;
        
        if (!flyweights.containsKey(key)) {
            flyweights.put(key, new TicketFlyweight(type, priority));
        }
        
        return flyweights.get(key);
    }
}