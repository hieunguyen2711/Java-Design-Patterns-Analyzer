public enum TicketType {
    BUG,
    FEATURE,
    TASK,
    IMPROVEMENT
}