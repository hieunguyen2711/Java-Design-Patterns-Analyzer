import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class TicketProcessor {
    private final BlockingQueue<Ticket> ticketQueue;
    
    public TicketProcessor() {
        this.ticketQueue = new LinkedBlockingQueue<>();
    }
    
    public void submitTicket(Ticket ticket) {
        try {
            // Guarded suspension - only add if queue is not full
            ticketQueue.put(ticket);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Interrupted while submitting ticket", e);
        }
    }
    
    public Ticket getNextTicket() {
        try {
            // Guarded suspension - wait until a ticket is available
            return ticketQueue.take();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return null;
        }
    }
}