public class TicketService {
    private final TicketProcessor processor;
    
    public TicketService(TicketProcessor processor) {
        this.processor = processor;
    }
    
    public void createTicket(int id, String title, String description) {
        Ticket ticket = new Ticket(id, title, description);
        processor.submitTicket(ticket);
    }
    
    public Ticket