public class TicketServiceImpl implements TicketService {
    private final java.util.Map<Integer, Ticket> tickets = new java.util.HashMap<>();

    @Override
    public void createTicket(Ticket ticket) {
        tickets.put(ticket.getId(), ticket);
        System.out.println("Created ticket: " + ticket.getTitle());
    }

    @Override
    public void updateTicket(Ticket ticket) {
        if (tickets.containsKey(ticket.getId())) {
            tickets.put(ticket.getId(), ticket);
            System.out