public interface TicketService {
    void createTicket(Ticket ticket);
    void updateTicket(Ticket ticket);
    void deleteTicket(int id);
    Ticket getTicket(int id);
    void assignTicket(int id, String assignee);
    void changeStatus(int id, String status);
}