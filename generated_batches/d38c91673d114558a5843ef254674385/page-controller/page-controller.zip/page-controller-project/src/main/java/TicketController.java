package com.projecttracker.controller;

import com.projecttracker.ticket.Ticket;
import com.projecttracker.service.TicketService;
import java.util.List;

public class TicketController {
    private TicketService ticketService;
    
    public TicketController() {
        this.ticketService = new TicketService();
    }
    
    public void createTicket(String title, String description) {
        Ticket ticket = new Ticket(0, title, description);
        ticketService.saveTicket(ticket);
    }
    
    public List<Ticket> getAllTickets() {
        return ticketService.getAllTickets();
    }
    
    public Ticket getTicketById(int id) {
        return ticketService.getTicketById(id);
    }
    
    public void updateTicketStatus(int id, String status) {
        Ticket ticket = ticketService.getTicketById(id);
        if (ticket != null) {
            ticket.setStatus(status);
            ticketService.saveTicket(ticket);
        }
    }
    
    public void assignTicket(int id, String assignee) {
        Ticket ticket = ticketService.getTicketById(id);
        if (ticket != null) {
            ticket.setAssignee(assignee);
            ticketService.saveTicket(ticket);