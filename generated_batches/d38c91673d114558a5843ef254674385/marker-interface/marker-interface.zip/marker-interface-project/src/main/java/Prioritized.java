package com.example.projecttracker;

public interface Prioritized {
    // Marker interface for tickets that have priority levels
}