package com.example.projecttracker;

public class Ticket implements Assignable, Prioritized {
    private String id;
    private String description;
    private Status status;
    private String assignee;
    private Priority priority;

    public Ticket(String id, String description, Priority priority) {
        this.id = id;
        this.description = description;
        this.priority = priority;
        this.status = Status.OPEN;
    }

    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }
    
    public String getAssignee() { return assignee; }
    public void setAssignee(String assignee) { this.assignee = assignee; }
    
    public Priority getPriority() { return priority; }
    public void setPriority(Priority priority) { this.priority = priority; }
}