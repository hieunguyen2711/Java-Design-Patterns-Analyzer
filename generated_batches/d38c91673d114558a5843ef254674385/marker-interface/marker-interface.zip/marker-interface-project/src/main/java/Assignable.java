package com.example.projecttracker;

public interface Assignable {
    // Marker interface for tickets that can be assigned to users
}