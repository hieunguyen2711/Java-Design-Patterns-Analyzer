package com.example.projecttracker;

import java.util.ArrayList;
import java.util.List;

public class TicketManager {
    private List<Ticket> tickets;

    public TicketManager() {
        this.tickets = new ArrayList<>();
    }

    public void addTicket(Ticket ticket) {
        tickets.add(ticket);
    }

    public List<Ticket> getAssignableTickets() {
        List<Ticket> assignableTickets = new ArrayList<>();
        for (Ticket ticket : tickets) {
            if (ticket instanceof Assignable) {
                assignableTickets.add(ticket);
            }
        }
        return assignableTickets;
    }

    public List<Ticket>