package com.projecttracker.ticket;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL;
    
    public static Priority fromString(String priorityStr) {
        switch (priorityStr.toLowerCase()) {
            case "low": return LOW;
            case "medium": return MEDIUM;
            case "high": return HIGH;
            case "critical": return CRITICAL;
            default: throw new IllegalArgumentException("Unknown priority: " + priorityStr);
        }
    }
}