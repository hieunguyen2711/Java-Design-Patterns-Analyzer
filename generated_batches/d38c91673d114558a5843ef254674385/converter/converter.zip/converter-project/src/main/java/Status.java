package com.projecttracker.ticket;

public enum Status {
    OPEN,
    IN_PROGRESS,
    RESOLVED,
    CLOSED;
    
    public static Status fromString(String statusStr) {
        switch (statusStr.toLowerCase()) {
            case "open": return OPEN;
            case "in_progress": return IN_PROGRESS;
            case "resolved": return RESOLVED;
            case "closed": return CLOSED;
            default: throw new IllegalArgumentException("Unknown status: " + statusStr);
        }
    }
}