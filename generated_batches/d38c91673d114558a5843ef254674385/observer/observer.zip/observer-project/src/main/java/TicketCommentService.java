public class TicketCommentService implements Observer {
    @Override
    public void update(Ticket ticket) {
        System.out.println("COMMENT SERVICE: Status updated for ticket " + ticket.getId() + 
                          ". New status: " + ticket.getStatus());
    }
}