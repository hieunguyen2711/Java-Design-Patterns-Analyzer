public class TicketNotificationService implements Observer {
    @Override
    public void update(Ticket ticket) {
        System.out.println("NOTIFICATION: Ticket " + ticket.getId() + 
                          " status changed to " + ticket.getStatus());
    }
}