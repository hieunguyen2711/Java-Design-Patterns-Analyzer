public interface Observer {
    void update(Ticket ticket);
}