package com.example.tracker.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TicketCreatedPage {
    private WebDriver driver;

    @FindBy(className = "ticket-id")
    private WebElement ticketIdDisplay;

    @FindBy(className = "status-assigned")
    private WebElement statusDisplay;

    public TicketCreatedPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public String getTicketId() {
        return ticketIdDisplay.getText();
    }

    public String getStatus() {
        return statusDisplay.getText();
    }
}