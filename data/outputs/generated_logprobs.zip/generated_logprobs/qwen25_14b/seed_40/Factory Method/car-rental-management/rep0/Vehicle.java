public abstract class Vehicle {
    private String id;
    private boolean isReserved;

    public Vehicle(String id) {
        this.id = id;
        this.isReserved = false;
    }

    public void reserve() {
        this.isReserved = true;
        System.out.println("Vehicle " + id + " has been reserved.");
    }

    public void returnVehicle() {
        this.isReserved = false;
        System.out.println("Vehicle " + id + " has been returned.");
    }

    public boolean isReserved() {
        return isReserved;
    }
}