public class Main {
    public static void main(String[] args) {
        FleetFactory factory = FleetFactory.getInstance();

        Vehicle car = factory.createVehicle("car", "C123");
        Vehicle truck = factory.createVehicle("truck", "T456");

        car.reserve();
        truck.reserve();

        car.returnVehicle();
        truck.returnVehicle();
    }
}