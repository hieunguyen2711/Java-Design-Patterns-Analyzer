import java.util.HashMap;
import java.util.Map;

public class FleetFactory extends VehicleFactory {

    private static FleetFactory instance;

    private Map<String, Class<? extends Vehicle>> vehicleTypes;

    private FleetFactory() {
        vehicleTypes = new HashMap<>();
        vehicleTypes.put("car", Car.class);
        vehicleTypes.put("truck", Truck.class);
    }

    public static synchronized FleetFactory getInstance() {
        if (instance == null) {
            instance = new FleetFactory();
        }
        return instance;
    }

    @Override
    public Vehicle createVehicle(String type, String id) {
        try {
            return vehicleTypes.get(type).getConstructor(String.class).newInstance(id);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}