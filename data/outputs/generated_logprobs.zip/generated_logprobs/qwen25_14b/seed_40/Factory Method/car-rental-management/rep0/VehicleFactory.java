public abstract class VehicleFactory {
    public abstract Vehicle createVehicle(String type, String id);
}