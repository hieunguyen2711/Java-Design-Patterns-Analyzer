public class FullTimeEmployee extends Employee {
    public FullTimeEmployee(String name) {
        super(name);
    }
    
    @Override
    public void calculateSalary() {
        System.out.println("Calculating salary for full-time employee " + getName());
    }
}