public class Main {
    public static void main(String[] args) {
        EmployeeService serviceFullTime = new EmployeeService(new FullTimeEmployeeFactory());
        EmployeeService servicePartTime = new EmployeeService(new PartTimeEmployeeFactory());

        serviceFullTime.processEmployee("fulltime", "John Doe");
        servicePartTime.processEmployee("parttime", "Jane Smith");
    }
}