public class PartTimeEmployeeFactory implements EmployeeFactory {
    @Override
    public Employee createEmployee(String type, String name) {
        if ("parttime".equalsIgnoreCase(type)) {
            return new PartTimeEmployee(name);
        } else {
            throw new IllegalArgumentException("Unknown employee type: " + type);
        }
    }
}