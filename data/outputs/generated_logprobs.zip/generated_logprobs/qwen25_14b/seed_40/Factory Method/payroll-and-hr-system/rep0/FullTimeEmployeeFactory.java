public class FullTimeEmployeeFactory implements EmployeeFactory {
    @Override
    public Employee createEmployee(String type, String name) {
        if ("fulltime".equalsIgnoreCase(type)) {
            return new FullTimeEmployee(name);
        } else {
            throw new IllegalArgumentException("Unknown employee type: " + type);
        }
    }
}