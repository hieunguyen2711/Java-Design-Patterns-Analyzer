public class EmployeeService {
    private EmployeeFactory factory;

    public EmployeeService(EmployeeFactory factory) {
        this.factory = factory;
    }

    public void processEmployee(String type, String name) {
        Employee employee = factory.createEmployee(type, name);
        employee.calculateSalary();
    }
}