public interface EmployeeFactory {
    Employee createEmployee(String type, String name);
}