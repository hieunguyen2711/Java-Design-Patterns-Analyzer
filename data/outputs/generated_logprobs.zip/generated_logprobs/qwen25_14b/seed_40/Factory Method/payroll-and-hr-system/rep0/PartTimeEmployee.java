public class PartTimeEmployee extends Employee {
    public PartTimeEmployee(String name) {
        super(name);
    }
    
    @Override
    public void calculateSalary() {
        System.out.println("Calculating salary for part-time employee " + getName());
    }
}