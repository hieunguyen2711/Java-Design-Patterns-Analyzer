package lms.lessonmodules;

public class ProgrammingLessonModule implements LessonModule {

    @Override
    public void study() {
        System.out.println("Studying programming concepts.");
    }
}