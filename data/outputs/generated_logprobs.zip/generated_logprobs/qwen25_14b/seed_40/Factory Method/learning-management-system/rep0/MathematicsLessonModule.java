package lms.lessonmodules;

public class MathematicsLessonModule implements LessonModule {

    @Override
    public void study() {
        System.out.println("Studying mathematics problems.");
    }
}