package lms;

public abstract class Course {
    private String courseName;
    
    public Course(String courseName) {
        this.courseName = courseName;
    }
    
    public void enroll() {
        System.out.println("Enrolled in " + courseName);
    }
    
    // Abstract method to create a new LessonModule instance
    public abstract LessonModule createLessonModule();
}