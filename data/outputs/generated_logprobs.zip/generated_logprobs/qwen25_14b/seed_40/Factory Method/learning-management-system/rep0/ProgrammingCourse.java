package lms;

import lms.lessonmodules.ProgrammingLessonModule;

public class ProgrammingCourse extends Course {

    public ProgrammingCourse(String courseName) {
        super(courseName);
    }

    @Override
    public LessonModule createLessonModule() {
        return new ProgrammingLessonModule();
    }
}