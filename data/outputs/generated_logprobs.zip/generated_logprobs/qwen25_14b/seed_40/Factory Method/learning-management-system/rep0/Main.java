package lms;

public class Main {
    public static void main(String[] args) {
        Course programmingCourse = new ProgrammingCourse("Java Programming");
        Course mathematicsCourse = new MathematicsCourse("Advanced Mathematics");

        programmingCourse.enroll();
        LessonModule programmingLesson = programmingCourse.createLessonModule();
        programmingLesson.study();

        mathematicsCourse.enroll();
        LessonModule mathematicsLesson = mathematicsCourse.createLessonModule();
        mathematicsLesson.study();
    }
}