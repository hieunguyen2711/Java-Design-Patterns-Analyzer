package lms.lessonmodules;

public interface LessonModule {
    void study();
}