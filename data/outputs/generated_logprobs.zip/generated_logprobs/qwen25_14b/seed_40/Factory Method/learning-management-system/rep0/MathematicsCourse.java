package lms;

import lms.lessonmodules.MathematicsLessonModule;

public class MathematicsCourse extends Course {

    public MathematicsCourse(String courseName) {
        super(courseName);
    }

    @Override
    public LessonModule createLessonModule() {
        return new MathematicsLessonModule();
    }
}