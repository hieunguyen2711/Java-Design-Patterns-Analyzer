public interface TicketFactory {
    Ticket createTicket(String id, String title);
}