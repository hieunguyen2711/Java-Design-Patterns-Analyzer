public class Main {
    public static void main(String[] args) {
        TicketTracker tracker = new TicketTracker(new BugTicketFactory());
        tracker.processTicket("001", "Database Connection Issue");

        tracker = new TicketTracker(new FeatureRequestTicketFactory());
        tracker.processTicket("002", "Add User Management Module");
    }
}