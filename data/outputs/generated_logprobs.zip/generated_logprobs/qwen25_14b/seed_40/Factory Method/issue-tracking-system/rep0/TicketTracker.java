public class TicketTracker {
    private TicketFactory factory;

    public TicketTracker(TicketFactory factory) {
        this.factory = factory;
    }

    public void processTicket(String id, String title) {
        Ticket ticket = factory.createTicket(id, title);
        ticket.handle();
    }
}