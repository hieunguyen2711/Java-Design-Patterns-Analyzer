public class FeatureRequestTicket extends Ticket {
    public FeatureRequestTicket(String id, String title) {
        super(id, title);
    }

    @Override
    public void handle() {
        System.out.println("Handling feature request ticket: " + getId());
        setStatus("Pending Approval");
    }
}