public class FeatureRequestTicketFactory implements TicketFactory {
    @Override
    public Ticket createTicket(String id, String title) {
        return new FeatureRequestTicket(id, title);
    }
}