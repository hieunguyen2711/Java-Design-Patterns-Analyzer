public abstract class Ticket {
    private String id;
    private String title;
    private String status;

    public Ticket(String id, String title) {
        this.id = id;
        this.title = title;
        this.status = "Open";
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getStatus() {
        return status;
    }

    public abstract void handle();
}