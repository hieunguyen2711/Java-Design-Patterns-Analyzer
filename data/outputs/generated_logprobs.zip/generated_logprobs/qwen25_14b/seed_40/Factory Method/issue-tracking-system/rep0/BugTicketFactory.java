public class BugTicketFactory implements TicketFactory {
    @Override
    public Ticket createTicket(String id, String title) {
        return new BugTicket(id, title);
    }
}