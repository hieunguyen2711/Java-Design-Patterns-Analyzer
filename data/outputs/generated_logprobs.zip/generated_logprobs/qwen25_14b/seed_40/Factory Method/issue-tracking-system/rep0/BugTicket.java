public class BugTicket extends Ticket {
    public BugTicket(String id, String title) {
        super(id, title);
    }

    @Override
    public void handle() {
        System.out.println("Handling bug ticket: " + getId());
        setStatus("In Progress");
    }
}