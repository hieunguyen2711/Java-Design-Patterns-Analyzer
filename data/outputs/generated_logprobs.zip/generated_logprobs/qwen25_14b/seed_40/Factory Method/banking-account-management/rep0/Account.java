package com.example.account;

public interface Account {
    void deposit(double amount);
    void withdraw(double amount);
}