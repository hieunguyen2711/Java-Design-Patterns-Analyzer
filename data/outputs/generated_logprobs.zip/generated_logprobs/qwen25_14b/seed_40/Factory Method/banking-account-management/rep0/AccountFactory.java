package com.example.account;

public abstract class AccountFactory {
    public abstract Account createAccount();
}