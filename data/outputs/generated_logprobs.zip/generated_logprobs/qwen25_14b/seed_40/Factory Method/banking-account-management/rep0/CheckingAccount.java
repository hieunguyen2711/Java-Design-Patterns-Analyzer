package com.example.account;

public class CheckingAccount implements Account {
    @Override
    public void deposit(double amount) {
        System.out.println("Deposited " + amount + " into Checking Account.");
    }

    @Override
    public void withdraw(double amount) {
        System.out.println("Withdrew " + amount + " from Checking Account.");
    }
}