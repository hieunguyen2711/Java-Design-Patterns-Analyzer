package com.example.account;

public class SavingsAccount implements Account {
    @Override
    public void deposit(double amount) {
        System.out.println("Deposited " + amount + " into Savings Account.");
    }

    @Override
    public void withdraw(double amount) {
        System.out.println("Withdrew " + amount + " from Savings Account.");
    }
}