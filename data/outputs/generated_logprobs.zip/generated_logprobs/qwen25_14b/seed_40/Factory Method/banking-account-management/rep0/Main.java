package com.example.account;

public class Main {
    public static void main(String[] args) {
        AccountFactory savingsFactory = new SavingsAccountFactory();
        Account savingsAccount = savingsFactory.createAccount();
        savingsAccount.deposit(100);
        savingsAccount.withdraw(50);

        AccountFactory checkingFactory = new CheckingAccountFactory();
        Account checkingAccount = checkingFactory.createAccount();
        checkingAccount.deposit(200);
        checkingAccount.withdraw(75);
    }
}