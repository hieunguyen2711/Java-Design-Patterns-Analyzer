package com.example.account;

public class CheckingAccountFactory extends AccountFactory {
    @Override
    public Account createAccount() {
        return new CheckingAccount();
    }
}