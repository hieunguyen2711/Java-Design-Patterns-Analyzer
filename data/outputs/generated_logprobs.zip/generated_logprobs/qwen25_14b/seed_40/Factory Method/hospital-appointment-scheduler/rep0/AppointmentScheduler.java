package clinic.appointment;

import clinic.doctor.Doctor;
import clinic.patient.Patient;

public class AppointmentScheduler {
    private final AppointmentFactory appointmentFactory;

    public AppointmentScheduler(AppointmentFactory appointmentFactory) {
        this.appointmentFactory = appointmentFactory;
    }

    public void scheduleAppointment(Doctor doctor, Patient patient) {
        // Assuming the factory method creates an appropriate appointment type
        Appointment appointment = appointmentFactory.createAppointment();
        appointment.setDoctor(doctor);
        appointment.setPatient(patient);
        System.out.println("Appointment scheduled for " + patient.getName() + " with " + doctor.getName());
    }
}