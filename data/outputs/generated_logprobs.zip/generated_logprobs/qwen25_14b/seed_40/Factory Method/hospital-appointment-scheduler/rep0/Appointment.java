package clinic.appointment;

public abstract class Appointment {
    protected Doctor doctor;
    protected Patient patient;

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }
}