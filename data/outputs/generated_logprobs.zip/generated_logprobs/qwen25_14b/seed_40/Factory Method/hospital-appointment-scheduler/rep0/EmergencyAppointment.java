package clinic.appointment;

public class EmergencyAppointment extends Appointment {
    @Override
    public String toString() {
        return "Emergency Appointment";
    }
}