package clinic.appointment;

public class RegularAppointmentFactory implements AppointmentFactory {
    @Override
    public Appointment createAppointment() {
        return new RegularAppointment();
    }
}