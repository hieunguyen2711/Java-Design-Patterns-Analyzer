package clinic.appointment;

import clinic.doctor.Doctor;
import clinic.patient.Patient;

public class Main {
    public static void main(String[] args) {
        Doctor doctor = new Doctor("Dr. Smith");
        Patient regularPatient = new Patient("John Doe");
        Patient emergencyPatient = new Patient("Jane Doe");

        AppointmentScheduler scheduler = new AppointmentScheduler(new RegularAppointmentFactory());
        scheduler.scheduleAppointment(doctor, regularPatient);

        scheduler = new AppointmentScheduler(new EmergencyAppointmentFactory());
        scheduler.scheduleAppointment(doctor, emergencyPatient);
    }
}