package clinic.appointment;

public class RegularAppointment extends Appointment {
    @Override
    public String toString() {
        return "Regular Appointment";
    }
}