package clinic.appointment;

public class EmergencyAppointmentFactory implements AppointmentFactory {
    @Override
    public Appointment createAppointment() {
        return new EmergencyAppointment();
    }
}