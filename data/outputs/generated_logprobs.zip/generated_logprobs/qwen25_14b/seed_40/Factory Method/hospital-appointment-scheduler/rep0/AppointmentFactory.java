package clinic.appointment;

public interface AppointmentFactory {
    Appointment createAppointment();
}