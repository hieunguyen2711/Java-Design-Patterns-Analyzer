public class VeggiePizza extends Pizza {
    public VeggiePizza() {
        setName("Veggie Pizza");
    }

    @Override
    public void prepare() {
        System.out.println("Preparing " + name);
    }
}