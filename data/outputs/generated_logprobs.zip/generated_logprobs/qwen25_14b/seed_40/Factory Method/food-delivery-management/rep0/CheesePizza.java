public class CheesePizza extends Pizza {
    public CheesePizza() {
        setName("Cheese Pizza");
    }

    @Override
    public void prepare() {
        System.out.println("Preparing " + name);
    }
}