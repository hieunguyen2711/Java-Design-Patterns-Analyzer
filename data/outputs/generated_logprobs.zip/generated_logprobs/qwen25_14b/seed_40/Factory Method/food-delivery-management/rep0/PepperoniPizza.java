public class PepperoniPizza extends Pizza {
    public PepperoniPizza() {
        setName("Pepperoni Pizza");
    }

    @Override
    public void prepare() {
        System.out.println("Preparing " + name);
    }
}