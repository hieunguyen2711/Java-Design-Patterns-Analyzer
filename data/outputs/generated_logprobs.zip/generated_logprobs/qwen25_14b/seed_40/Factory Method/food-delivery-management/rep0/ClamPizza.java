public class ClamPizza extends Pizza {
    public ClamPizza() {
        setName("Clam Pizza");
    }

    @Override
    public void prepare() {
        System.out.println("Preparing " + name);
    }
}