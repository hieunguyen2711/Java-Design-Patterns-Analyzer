public class NYPizzaStore extends PizzaStore {
    @Override
    public Pizza createPizza(String item) {
        if (item.equals("cheese")) {
            return new CheesePizza();
        } else if (item.equals("pepperoni")) {
            return new PepperoniPizza();
        } else if (item.equals("clam")) {
            return new ClamPizza();
        } else if (item.equals("veggie")) {
            return new VeggiePizza();
        } else {
            return null;
        }
    }
}