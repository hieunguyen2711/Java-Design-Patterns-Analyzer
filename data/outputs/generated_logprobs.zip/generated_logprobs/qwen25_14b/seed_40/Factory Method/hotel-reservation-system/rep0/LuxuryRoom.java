public class LuxuryRoom extends Room {

    public LuxuryRoom(String roomNumber) {
        super(roomNumber, 2);
    }

    @Override
    public void book() {
        System.out.println("Luxury room " + getRoomNumber() + " is booked.");
    }
}