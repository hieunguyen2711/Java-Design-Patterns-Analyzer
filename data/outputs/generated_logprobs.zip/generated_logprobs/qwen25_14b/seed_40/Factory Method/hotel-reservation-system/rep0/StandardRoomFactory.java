public class StandardRoomFactory implements RoomFactory {

    @Override
    public Room createRoom(String type, String roomNumber) {
        if ("STANDARD".equalsIgnoreCase(type)) {
            return new StandardRoom(roomNumber);
        } else {
            throw new IllegalArgumentException("Invalid room type");
        }
    }
}