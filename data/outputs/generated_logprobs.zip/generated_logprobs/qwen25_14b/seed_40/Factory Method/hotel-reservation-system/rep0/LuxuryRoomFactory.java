public class LuxuryRoomFactory implements RoomFactory {

    @Override
    public Room createRoom(String type, String roomNumber) {
        if ("LUXURY".equalsIgnoreCase(type)) {
            return new LuxuryRoom(roomNumber);
        } else {
            throw new IllegalArgumentException("Invalid room type");
        }
    }
}