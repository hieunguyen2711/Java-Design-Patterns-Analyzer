public class StandardRoom extends Room {

    public StandardRoom(String roomNumber) {
        super(roomNumber, 1);
    }

    @Override
    public void book() {
        System.out.println("Standard room " + getRoomNumber() + " is booked.");
    }
}