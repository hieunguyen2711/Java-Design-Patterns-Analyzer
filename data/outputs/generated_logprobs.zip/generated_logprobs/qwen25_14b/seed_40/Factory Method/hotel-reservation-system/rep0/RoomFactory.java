public interface RoomFactory {
    Room createRoom(String type, String roomNumber);
}