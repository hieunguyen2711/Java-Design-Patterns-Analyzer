public class HotelReservationSystem {

    public static void main(String[] args) {
        RoomFactory factory = null;

        if (args.length > 0) {
            switch (args[0].toUpperCase()) {
                case "LUXURY":
                    factory = new LuxuryRoomFactory();
                    break;
                case "STANDARD":
                    factory = new StandardRoomFactory();
                    break;
                default:
                    throw new IllegalArgumentException("Unknown room type");
            }
        } else {
            throw new IllegalArgumentException("Room type argument is required");
        }

        Room room = factory.createRoom(args[0], "101");
        room.book();
    }
}