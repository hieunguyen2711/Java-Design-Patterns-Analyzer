package com.example.enrollment;

public interface Course {
    void enrollStudent(Student student);
    void scheduleClass();
}