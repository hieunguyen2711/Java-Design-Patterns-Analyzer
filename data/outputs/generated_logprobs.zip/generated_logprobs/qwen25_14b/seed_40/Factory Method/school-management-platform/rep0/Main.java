package com.example.enrollment;

public class Main {
    public static void main(String[] args) {
        CourseFactory mathFactory = new MathCourseFactory();
        Course algebraCourse = mathFactory.createCourse("Algebra");
        algebraCourse.enrollStudent(new Student("Alice"));
        algebraCourse.scheduleClass();

        CourseFactory englishFactory = new EnglishCourseFactory();
        Course literatureCourse = englishFactory.createCourse("Literature");
        literatureCourse.enrollStudent(new Student("Bob"));
        literatureCourse.scheduleClass();
    }
}