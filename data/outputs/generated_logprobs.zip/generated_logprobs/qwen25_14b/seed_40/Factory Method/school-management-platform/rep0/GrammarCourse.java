package com.example.enrollment;

public class GrammarCourse implements Course {
    @Override
    public void enrollStudent(Student student) {
        System.out.println(student.getName() + " enrolled in Grammar.");
    }

    @Override
    public void scheduleClass() {
        System.out.println("Grammar class scheduled.");
    }
}