package com.example.enrollment;

public abstract class CourseFactory {
    public abstract Course createCourse(String courseType);
}