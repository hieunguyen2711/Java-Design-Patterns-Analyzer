package com.example.enrollment;

public class CalculusCourse implements Course {
    @Override
    public void enrollStudent(Student student) {
        System.out.println(student.getName() + " enrolled in Calculus.");
    }

    @Override
    public void scheduleClass() {
        System.out.println("Calculus class scheduled.");
    }
}