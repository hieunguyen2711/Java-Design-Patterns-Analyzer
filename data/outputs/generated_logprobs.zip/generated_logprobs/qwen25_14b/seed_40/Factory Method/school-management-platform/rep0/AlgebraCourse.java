package com.example.enrollment;

public class AlgebraCourse implements Course {
    @Override
    public void enrollStudent(Student student) {
        System.out.println(student.getName() + " enrolled in Algebra.");
    }

    @Override
    public void scheduleClass() {
        System.out.println("Algebra class scheduled.");
    }
}