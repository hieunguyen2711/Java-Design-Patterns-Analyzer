package com.example.enrollment;

public class EnglishCourseFactory extends CourseFactory {
    @Override
    public Course createCourse(String courseType) {
        if ("Literature".equals(courseType)) {
            return new LiteratureCourse();
        } else if ("Grammar".equals(courseType)) {
            return new GrammarCourse();
        }
        throw new IllegalArgumentException("Unknown course type");
    }
}