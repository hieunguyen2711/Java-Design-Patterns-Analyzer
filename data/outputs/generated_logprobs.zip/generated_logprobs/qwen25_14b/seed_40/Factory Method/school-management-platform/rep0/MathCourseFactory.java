package com.example.enrollment;

public class MathCourseFactory extends CourseFactory {
    @Override
    public Course createCourse(String courseType) {
        if ("Algebra".equals(courseType)) {
            return new AlgebraCourse();
        } else if ("Calculus".equals(courseType)) {
            return new CalculusCourse();
        }
        throw new IllegalArgumentException("Unknown course type");
    }
}