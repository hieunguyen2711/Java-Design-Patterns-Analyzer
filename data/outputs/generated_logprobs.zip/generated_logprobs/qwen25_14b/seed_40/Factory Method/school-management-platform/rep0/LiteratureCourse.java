package com.example.enrollment;

public class LiteratureCourse implements Course {
    @Override
    public void enrollStudent(Student student) {
        System.out.println(student.getName() + " enrolled in Literature.");
    }

    @Override
    public void scheduleClass() {
        System.out.println("Literature class scheduled.");
    }
}