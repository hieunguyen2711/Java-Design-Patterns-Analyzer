public abstract class Library {
    public abstract Book createBook(String type, String title, String author);

    public void addBook(String type, String title, String author) {
        Book book = createBook(type, title, author);
        // Add book to collection (pseudo-code)
        System.out.println("Added " + book.getTitle() + " to the library.");
    }
}