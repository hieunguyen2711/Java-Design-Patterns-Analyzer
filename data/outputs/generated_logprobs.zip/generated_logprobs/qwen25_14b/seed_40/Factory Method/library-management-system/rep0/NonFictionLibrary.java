public class NonFictionLibrary extends Library {
    @Override
    public Book createBook(String type, String title, String author) {
        if ("non-fiction".equalsIgnoreCase(type)) {
            return new NonFictionBook(title, author);
        } else {
            throw new IllegalArgumentException("Invalid book type");
        }
    }
}