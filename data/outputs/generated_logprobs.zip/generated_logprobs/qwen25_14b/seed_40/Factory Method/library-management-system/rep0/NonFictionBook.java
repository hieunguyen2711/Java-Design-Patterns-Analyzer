public class NonFictionBook extends Book {
    public NonFictionBook(String title, String author) {
        super(title, author);
    }
}