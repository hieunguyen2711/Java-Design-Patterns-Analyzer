public class FictionLibrary extends Library {
    @Override
    public Book createBook(String type, String title, String author) {
        if ("fiction".equalsIgnoreCase(type)) {
            return new FictionBook(title, author);
        } else {
            throw new IllegalArgumentException("Invalid book type");
        }
    }
}