public class Main {
    public static void main(String[] args) {
        Library fictionLibrary = new FictionLibrary();
        fictionLibrary.addBook("fiction", "The Great Gatsby", "F. Scott Fitzgerald");

        Library nonFictionLibrary = new NonFictionLibrary();
        nonFictionLibrary.addBook("non-fiction", "A Brief History of Time", "Stephen Hawking");
    }
}