public class BasicMembership extends Membership {

    public BasicMembership(String memberID) {
        super(memberID, "Basic");
    }

    @Override
    public void enrollInClass() {
        System.out.println("Enrolled in basic class.");
    }
}