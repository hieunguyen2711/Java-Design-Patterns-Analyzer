public abstract class Membership {
    protected String memberID;
    protected String membershipType;

    public Membership(String memberID, String membershipType) {
        this.memberID = memberID;
        this.membershipType = membershipType;
    }

    public abstract void enrollInClass();
}