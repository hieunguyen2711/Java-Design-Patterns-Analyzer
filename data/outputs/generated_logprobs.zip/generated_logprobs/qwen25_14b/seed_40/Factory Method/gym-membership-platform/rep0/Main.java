public class Main {
    public static void main(String[] args) {
        Membership basicMember = MembershipFactory.getMembership("basic", "M123");
        Membership premiumMember = MembershipFactory.getMembership("premium", "P456");

        basicMember.enrollInClass();
        premiumMember.enrollInClass();
    }
}