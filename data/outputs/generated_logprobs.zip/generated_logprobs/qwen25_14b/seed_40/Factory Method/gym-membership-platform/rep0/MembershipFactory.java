public class MembershipFactory {

    public static Membership getMembership(String type, String memberID) {
        if (type == null) {
            return null;
        } else if (type.equalsIgnoreCase("basic")) {
            return new BasicMembership(memberID);
        } else if (type.equalsIgnoreCase("premium")) {
            return new PremiumMembership(memberID);
        }
        return null;
    }
}