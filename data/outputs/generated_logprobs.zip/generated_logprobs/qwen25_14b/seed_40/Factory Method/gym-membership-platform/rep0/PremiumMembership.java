public class PremiumMembership extends Membership {

    public PremiumMembership(String memberID) {
        super(memberID, "Premium");
    }

    @Override
    public void enrollInClass() {
        System.out.println("Enrolled in premium class.");
    }
}