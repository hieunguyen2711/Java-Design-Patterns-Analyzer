public class SupplierItem extends Item {
    public SupplierItem(String name, int location, int reorderThreshold) {
        super(name, location, reorderThreshold);
    }

    // Additional methods specific to SupplierItem can be added here
}