import Item;

public class MovementLogStockIntake implements StockIntake {
    @Override
    public Item createItem(String name, int location, int reorderThreshold) {
        return new MovementLogItem(name, location, reorderThreshold);
    }
}