public class Main {
    public static void main(String[] args) {
        StockIntake supplierIntake = new SupplierStockIntake();
        Item supplierItem = supplierIntake.createItem("Laptop", 102, 5);

        StockIntake logIntake = new MovementLogStockIntake();
        Item logItem = logIntake.createItem("Mouse", 103, 10);

        System.out.println(supplierItem.getName() + " is located at " + supplierItem.getLocation());
        System.out.println(logItem.getName() + " is located at " + logItem.getLocation());
    }
}