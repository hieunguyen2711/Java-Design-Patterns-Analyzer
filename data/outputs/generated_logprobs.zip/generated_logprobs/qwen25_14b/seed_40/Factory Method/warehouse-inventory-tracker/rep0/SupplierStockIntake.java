import Item;

public class SupplierStockIntake implements StockIntake {
    @Override
    public Item createItem(String name, int location, int reorderThreshold) {
        return new SupplierItem(name, location, reorderThreshold);
    }
}