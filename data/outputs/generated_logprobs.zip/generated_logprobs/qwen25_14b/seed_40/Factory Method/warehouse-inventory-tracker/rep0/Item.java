public abstract class Item {
    private String name;
    private int location;
    private int reorderThreshold;

    public Item(String name, int location, int reorderThreshold) {
        this.name = name;
        this.location = location;
        this.reorderThreshold = reorderThreshold;
    }

    public String getName() {
        return name;
    }

    public int getLocation() {
        return location;
    }

    public int getReorderThreshold() {
        return reorderThreshold;
    }

    public void setLocation(int location) {
        this.location = location;
    }
}