public class MovementLogItem extends Item {
    public MovementLogItem(String name, int location, int reorderThreshold) {
        super(name, location, reorderThreshold);
    }

    // Additional methods specific to MovementLogItem can be added here
}