public interface StockIntake {
    Item createItem(String name, int location, int reorderThreshold);
}