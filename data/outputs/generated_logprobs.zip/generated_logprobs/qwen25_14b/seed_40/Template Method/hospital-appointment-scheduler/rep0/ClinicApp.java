package clinic.appointment;

public class ClinicApp {
    public static void main(String[] args) {
        System.out.println("Scheduling a doctor appointment:");
        new DoctorScheduler().scheduleAppointment();

        System.out.println("\nScheduling a patient check-in:");
        new PatientCheckInScheduler().scheduleAppointment();
    }
}