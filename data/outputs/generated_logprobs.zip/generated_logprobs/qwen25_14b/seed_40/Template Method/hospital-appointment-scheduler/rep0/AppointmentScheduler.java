package clinic.appointment;

public abstract class AppointmentScheduler {
    // Template method that defines the overall structure of scheduling an appointment
    public final void scheduleAppointment() {
        findAvailableSlot();
        confirmAppointment();
        sendConfirmationEmail();
    }

    // Abstract methods that subclasses must implement
    protected abstract void findAvailableSlot();

    protected abstract void confirmAppointment();

    protected abstract void sendConfirmationEmail();
}