package clinic.appointment;

public class DoctorScheduler extends AppointmentScheduler {

    @Override
    protected void findAvailableSlot() {
        System.out.println("Finding available slot for doctor...");
        // Logic to find an available slot for the doctor
    }

    @Override
    protected void confirmAppointment() {
        System.out.println("Confirming appointment with doctor...");
        // Logic to confirm the appointment with the doctor
    }

    @Override
    protected void sendConfirmationEmail() {
        System.out.println("Sending confirmation email to patient...");
        // Logic to send a confirmation email to the patient
    }
}