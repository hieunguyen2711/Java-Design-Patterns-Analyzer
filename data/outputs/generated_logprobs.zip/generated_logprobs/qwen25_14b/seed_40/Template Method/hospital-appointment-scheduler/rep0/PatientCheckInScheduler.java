package clinic.appointment;

public class PatientCheckInScheduler extends AppointmentScheduler {

    @Override
    protected void findAvailableSlot() {
        System.out.println("Finding available check-in slot for patient...");
        // Logic to find an available check-in slot for the patient
    }

    @Override
    protected void confirmAppointment() {
        System.out.println("Confirming patient's check-in...");
        // Logic to confirm the patient's check-in
    }

    @Override
    protected void sendConfirmationEmail() {
        System.out.println("Sending check-in confirmation to patient...");
        // Logic to send a check-in confirmation email to the patient
    }
}