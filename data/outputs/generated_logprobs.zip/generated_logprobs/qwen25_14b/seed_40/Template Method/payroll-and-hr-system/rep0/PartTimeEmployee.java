import Employee;

public class PartTimeEmployee extends Employee {

    public PartTimeEmployee(String name, double salary) {
        super(name, salary);
    }

    @Override
    public void requestLeave() {
        System.out.println(getName() + " has requested 1 week of leave.");
    }

    @Override
    public void calculateTax() {
        double tax = getSalary() * 0.15; // Example tax rate
        System.out.println(getName() + "'s tax is: $" + tax);
    }
}