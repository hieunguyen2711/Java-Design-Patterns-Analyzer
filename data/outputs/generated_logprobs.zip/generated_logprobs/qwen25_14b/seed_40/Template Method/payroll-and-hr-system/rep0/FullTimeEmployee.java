import Employee;

public class FullTimeEmployee extends Employee {

    public FullTimeEmployee(String name, double salary) {
        super(name, salary);
    }

    @Override
    public void requestLeave() {
        System.out.println(getName() + " has requested 2 weeks of leave.");
    }

    @Override
    public void calculateTax() {
        double tax = getSalary() * 0.2; // Example tax rate
        System.out.println(getName() + "'s tax is: $" + tax);
    }
}