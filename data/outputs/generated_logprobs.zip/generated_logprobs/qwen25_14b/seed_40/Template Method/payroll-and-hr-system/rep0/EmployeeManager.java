import Employee;

public class EmployeeManager {

    private Employee employee;

    public EmployeeManager(Employee employee) {
        this.employee = employee;
    }

    public void manageEmployee() {
        employee.requestLeave();
        employee.calculateTax();
    }
}