import Employee;
import FullTimeEmployee;
import PartTimeEmployee;
import EmployeeManager;

public class Main {
    public static void main(String[] args) {
        Employee fullTimeEmployee = new FullTimeEmployee("John Doe", 50000);
        Employee partTimeEmployee = new PartTimeEmployee("Jane Smith", 30000);

        EmployeeManager managerForFullTime = new EmployeeManager(fullTimeEmployee);
        managerForFullTime.manageEmployee();

        EmployeeManager managerForPartTime = new EmployeeManager(partTimeEmployee);
        managerForPartTime.manageEmployee();
    }
}