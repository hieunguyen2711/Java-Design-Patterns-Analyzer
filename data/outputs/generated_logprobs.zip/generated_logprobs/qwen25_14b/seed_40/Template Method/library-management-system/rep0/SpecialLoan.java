public class SpecialLoan extends LoanProcess {

    @Override
    protected void borrowBook() {
        System.out.println("Borrowing book with special privileges...");
    }

    @Override
    protected void setDueDate() {
        System.out.println("Setting due date for special loan (extended period)...");
    }

    @Override
    protected void calculateLateFee() {
        System.out.println("Special loans do not incur late fees.");
    }
}