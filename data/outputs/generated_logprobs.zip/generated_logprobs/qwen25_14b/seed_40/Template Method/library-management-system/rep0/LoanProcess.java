public abstract class LoanProcess {

    final void processLoan() {
        checkoutBook();
        borrowBook();
        setDueDate();
        calculateLateFee();
    }

    // Hook method
    void checkoutBook() {
        System.out.println("Checking out book...");
    }

    // Hook method
    void returnBook() {
        System.out.println("Returning book...");
    }

    protected abstract void borrowBook();

    protected abstract void setDueDate();

    protected abstract void calculateLateFee();

}