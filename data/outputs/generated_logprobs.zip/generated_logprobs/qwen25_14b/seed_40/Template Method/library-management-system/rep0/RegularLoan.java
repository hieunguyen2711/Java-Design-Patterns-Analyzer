public class RegularLoan extends LoanProcess {

    @Override
    protected void borrowBook() {
        System.out.println("Borrowing book normally...");
    }

    @Override
    protected void setDueDate() {
        System.out.println("Setting due date for regular loan...");
    }

    @Override
    protected void calculateLateFee() {
        System.out.println("Calculating late fee for regular loan...");
    }
}