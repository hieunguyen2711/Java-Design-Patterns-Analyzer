public class WithdrawOperation extends AccountOperation {

    private final double amount;

    public WithdrawOperation(String accountNumber, double initialBalance, double amount) {
        super(accountNumber, initialBalance);
        this.amount = amount;
    }

    @Override
    protected void performTransaction() {
        if (balance >= amount) {
            System.out.println("Withdrawing $" + amount + " from account " + accountNumber);
            balance -= amount;
            printStatement();
        } else {
            System.out.println("Insufficient funds in account " + accountNumber);
        }
    }

    private void printStatement() {
        System.out.println("Current balance: $" + balance);
    }
}