public class TransferOperation extends AccountOperation {

    private final String toAccountNumber;
    private final double amount;

    public TransferOperation(String accountNumber, double initialBalance, String toAccountNumber, double amount) {
        super(accountNumber, initialBalance);
        this.toAccountNumber = toAccountNumber;
        this.amount = amount;
    }

    @Override
    protected void performTransaction() {
        if (balance >= amount) {
            System.out.println("Transferring $" + amount + " from account " + accountNumber + " to " + toAccountNumber);
            balance -= amount;
            printStatement();
        } else {
            System.out.println("Insufficient funds in account " + accountNumber);
        }
    }

    private void printStatement() {
        System.out.println("Current balance: $" + balance);
    }
}