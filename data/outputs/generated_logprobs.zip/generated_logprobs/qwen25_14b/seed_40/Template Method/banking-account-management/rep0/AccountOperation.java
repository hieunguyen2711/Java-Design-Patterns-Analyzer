public abstract class AccountOperation {

    protected final String accountNumber;
    protected double balance;

    public AccountOperation(String accountNumber, double initialBalance) {
        this.accountNumber = accountNumber;
        this.balance = initialBalance;
    }

    // Template method
    public void executeTransaction() {
        checkAccountStatus();
        performTransaction();
        recordAuditHistory();
    }

    protected abstract void performTransaction();

    private void checkAccountStatus() {
        System.out.println("Checking account status for " + accountNumber);
    }

    private void recordAuditHistory() {
        System.out.println("Recording transaction for " + accountNumber);
    }
}