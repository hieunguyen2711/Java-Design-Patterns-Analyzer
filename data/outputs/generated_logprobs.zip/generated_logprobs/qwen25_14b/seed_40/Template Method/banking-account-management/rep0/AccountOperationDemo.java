public class AccountOperationDemo {

    public static void main(String[] args) {
        AccountOperation depositOp = new DepositOperation("123456", 1000, 500);
        depositOp.executeTransaction();

        AccountOperation withdrawOp = new WithdrawOperation("123456", 1500, 200);
        withdrawOp.executeTransaction();

        AccountOperation transferOp = new TransferOperation("123456", 1300, "789012", 100);
        transferOp.executeTransaction();
    }
}