public class DepositOperation extends AccountOperation {

    private final double amount;

    public DepositOperation(String accountNumber, double initialBalance, double amount) {
        super(accountNumber, initialBalance);
        this.amount = amount;
    }

    @Override
    protected void performTransaction() {
        System.out.println("Depositing $" + amount + " into account " + accountNumber);
        balance += amount;
        printStatement();
    }

    private void printStatement() {
        System.out.println("Current balance: $" + balance);
    }
}