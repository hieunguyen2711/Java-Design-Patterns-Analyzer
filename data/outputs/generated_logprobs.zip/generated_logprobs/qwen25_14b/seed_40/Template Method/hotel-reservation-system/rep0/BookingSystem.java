package com.example.booking;

public abstract class BookingSystem {

    // Template method
    public final void processBooking() {
        prepareRoom();
        checkInGuest();
        stayDuration();
        checkOutGuest();
        finalizeBilling();
    }

    // Hook methods
    protected void prepareRoom() {
        System.out.println("Preparing room for booking...");
    }

    protected void checkInGuest() {
        System.out.println("Checking in guest...");
    }

    protected void stayDuration() {
        System.out.println("Guest is staying for the duration of the booking...");
    }

    protected void checkOutGuest() {
        System.out.println("Checking out guest...");
    }

    protected void finalizeBilling() {
        System.out.println("Finalizing billing for guest...");
    }
}