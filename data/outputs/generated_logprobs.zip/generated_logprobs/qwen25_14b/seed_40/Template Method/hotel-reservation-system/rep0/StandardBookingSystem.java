package com.example.booking;

public class StandardBookingSystem extends BookingSystem {

    @Override
    protected void prepareRoom() {
        System.out.println("Standard room preparation...");
    }

    @Override
    protected void checkInGuest() {
        System.out.println("Standard check-in procedure...");
    }

    @Override
    protected void stayDuration() {
        System.out.println("Standard stay duration...");
    }

    @Override
    protected void checkOutGuest() {
        System.out.println("Standard check-out procedure...");
    }

    @Override
    protected void finalizeBilling() {
        System.out.println("Standard billing process...");
    }
}