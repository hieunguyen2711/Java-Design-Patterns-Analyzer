package com.example.booking;

public class DeluxeBookingSystem extends BookingSystem {

    @Override
    protected void prepareRoom() {
        System.out.println("Deluxe room preparation...");
    }

    @Override
    protected void checkInGuest() {
        System.out.println("Deluxe check-in procedure...");
    }

    @Override
    protected void stayDuration() {
        System.out.println("Deluxe stay duration...");
    }

    @Override
    protected void checkOutGuest() {
        System.out.println("Deluxe check-out procedure...");
    }

    @Override
    protected void finalizeBilling() {
        System.out.println("Deluxe billing process...");
    }
}