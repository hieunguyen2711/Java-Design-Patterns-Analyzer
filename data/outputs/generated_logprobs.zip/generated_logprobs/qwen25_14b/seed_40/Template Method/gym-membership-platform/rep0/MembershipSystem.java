package com.membership.system;

public abstract class MembershipSystem {

    // Template method
    public final void processMembership() {
        scheduleClass();
        bookTrainer();
        checkAttendance();
        trackPayment();
    }

    // Primitive operations
    protected abstract void scheduleClass();

    protected abstract void bookTrainer();

    protected abstract void checkAttendance();

    protected abstract void trackPayment();
}