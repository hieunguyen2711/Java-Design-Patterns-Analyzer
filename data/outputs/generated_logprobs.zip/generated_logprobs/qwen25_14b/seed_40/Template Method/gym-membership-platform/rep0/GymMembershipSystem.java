package com.membership.system;

public class GymMembershipSystem extends MembershipSystem {

    @Override
    protected void scheduleClass() {
        System.out.println("Scheduling classes for gym members...");
    }

    @Override
    protected void bookTrainer() {
        System.out.println("Booking trainers for gym members...");
    }

    @Override
    protected void checkAttendance() {
        System.out.println("Checking attendance of gym members...");
    }

    @Override
    protected void trackPayment() {
        System.out.println("Tracking payments for gym members...");
    }
}