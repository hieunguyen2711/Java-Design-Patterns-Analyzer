package com.membership.system;

public class SwimClubMembershipSystem extends MembershipSystem {

    @Override
    protected void scheduleClass() {
        System.out.println("Scheduling swim classes...");
    }

    @Override
    protected void bookTrainer() {
        System.out.println("Booking swim instructors...");
    }

    @Override
    protected void checkAttendance() {
        System.out.println("Checking attendance of swimmers...");
    }

    @Override
    protected void trackPayment() {
        System.out.println("Tracking payments for swim club members...");
    }
}