package lms;

public class ProgrammingCourse extends Course {
    
    public ProgrammingCourse(String courseName) {
        super(courseName);
    }
    
    @Override
    protected void performLessonModules() {
        System.out.println("Programming lessons: Code syntax, algorithms, debugging.");
    }

    @Override
    protected void performAssignments() {
        System.out.println("Programming assignments: Implement a linked list, write a sorting algorithm.");
    }

    @Override
    protected void gradeSubmissions() {
        System.out.println("Grading programming assignments.");
    }

    @Override
    protected void trackProgress() {
        System.out.println("Tracking student progress on coding exercises.");
    }
}