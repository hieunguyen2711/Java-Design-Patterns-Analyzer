package lms;

public abstract class Course {
    private String courseName;
    
    public Course(String courseName) {
        this.courseName = courseName;
    }
    
    public void startCourse() {
        System.out.println("Starting " + courseName);
        performLessonModules();
        performAssignments();
        gradeSubmissions();
        trackProgress();
        System.out.println(courseName + " completed.");
    }
    
    protected abstract void performLessonModules();
    protected abstract void performAssignments();
    protected abstract void gradeSubmissions();
    protected abstract void trackProgress();
}