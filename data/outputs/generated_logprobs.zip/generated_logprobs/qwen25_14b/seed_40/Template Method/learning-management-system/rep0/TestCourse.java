package lms;

public class TestCourse {
    public static void main(String[] args) {
        Course programmingCourse = new ProgrammingCourse("Advanced Java Programming");
        programmingCourse.startCourse();
    }
}