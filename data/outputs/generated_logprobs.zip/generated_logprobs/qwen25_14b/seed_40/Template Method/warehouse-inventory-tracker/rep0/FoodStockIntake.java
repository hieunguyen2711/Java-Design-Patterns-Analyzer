package com.stockmanagement;

public class FoodStockIntake extends StockIntakeTemplate {

    @Override
    protected void checkItemLocation() {
        System.out.println("Checking location of food items.");
    }

    @Override
    protected boolean isRestockNeeded() {
        return false; // Assume no restock needed for simplicity
    }

    @Override
    protected void restock() {
        System.out.println("Restocking food items.");
    }

    @Override
    protected void logMovement() {
        System.out.println("Logging movement of food items.");
    }

    public static void main(String[] args) {
        new FoodStockIntake().processStock();
    }
}