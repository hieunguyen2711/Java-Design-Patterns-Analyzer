package com.stockmanagement;

public class ElectronicsStockIntake extends StockIntakeTemplate {

    @Override
    protected void checkItemLocation() {
        System.out.println("Checking location of electronics items.");
    }

    @Override
    protected boolean isRestockNeeded() {
        return true; // Assume restock needed for simplicity
    }

    @Override
    protected void restock() {
        System.out.println("Restocking electronics items.");
    }

    @Override
    protected void logMovement() {
        System.out.println("Logging movement of electronics items.");
    }

    public static void main(String[] args) {
        new ElectronicsStockIntake().processStock();
    }
}