package com.stockmanagement;

public abstract class StockIntakeTemplate {

    protected final void processStock() {
        checkItemLocation();
        checkReorderThreshold();
        if (isRestockNeeded()) {
            restock();
        }
        logMovement();
    }

    protected abstract void checkItemLocation();

    protected abstract boolean isRestockNeeded();

    protected abstract void restock();

    protected abstract void logMovement();
}