package com.fleetmanagement;

public abstract class VehicleReservationSystem {
    protected String vehicleId;
    protected String reservationId;

    public VehicleReservationSystem(String vehicleId, String reservationId) {
        this.vehicleId = vehicleId;
        this.reservationId = reservationId;
    }

    // Template method
    public final void processReservation() {
        checkVehicleAvailability();
        reserveVehicle();
        confirmReservation();
        sendConfirmationEmail();
    }

    // Hook methods
    protected void checkVehicleAvailability() {
        System.out.println("Checking availability for vehicle " + vehicleId);
    }

    protected void reserveVehicle() {
        System.out.println("Reserving vehicle " + vehicleId + " for reservation " + reservationId);
    }

    protected void confirmReservation() {
        System.out.println("Confirming reservation " + reservationId);
    }

    protected void sendConfirmationEmail() {
        System.out.println("Sending confirmation email for reservation " + reservationId);
    }
}