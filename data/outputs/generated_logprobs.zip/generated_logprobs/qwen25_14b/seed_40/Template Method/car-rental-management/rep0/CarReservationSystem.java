package com.fleetmanagement;

public class CarReservationSystem extends VehicleReservationSystem {

    public CarReservationSystem(String vehicleId, String reservationId) {
        super(vehicleId, reservationId);
    }

    @Override
    protected void checkVehicleAvailability() {
        System.out.println("Checking if car " + vehicleId + " is available.");
    }

    @Override
    protected void reserveVehicle() {
        System.out.println("Reserving car " + vehicleId + " for reservation " + reservationId);
    }

    @Override
    protected void confirmReservation() {
        System.out.println("Confirming car reservation " + reservationId);
    }

    @Override
    protected void sendConfirmationEmail() {
        System.out.println("Sending confirmation email for car reservation " + reservationId);
    }
}