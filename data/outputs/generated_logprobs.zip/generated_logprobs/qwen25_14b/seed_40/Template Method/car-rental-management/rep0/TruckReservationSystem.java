package com.fleetmanagement;

public class TruckReservationSystem extends VehicleReservationSystem {

    public TruckReservationSystem(String vehicleId, String reservationId) {
        super(vehicleId, reservationId);
    }

    @Override
    protected void checkVehicleAvailability() {
        System.out.println("Checking if truck " + vehicleId + " is available.");
    }

    @Override
    protected void reserveVehicle() {
        System.out.println("Reserving truck " + vehicleId + " for reservation " + reservationId);
    }

    @Override
    protected void confirmReservation() {
        System.out.println("Confirming truck reservation " + reservationId);
    }

    @Override
    protected void sendConfirmationEmail() {
        System.out.println("Sending confirmation email for truck reservation " + reservationId);
    }
}