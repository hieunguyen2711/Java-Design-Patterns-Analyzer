package com.projecttracker.workflow;

public class BugTicketWorkflow extends TicketWorkflow {

    @Override
    public void createTicket() {
        System.out.println("Creating a new bug ticket...");
    }

    @Override
    public void assignTicket() {
        System.out.println("Assigning the bug ticket to a developer...");
    }

    @Override
    public void updateStatus() {
        System.out.println("Updating the status of the bug ticket...");
    }
}