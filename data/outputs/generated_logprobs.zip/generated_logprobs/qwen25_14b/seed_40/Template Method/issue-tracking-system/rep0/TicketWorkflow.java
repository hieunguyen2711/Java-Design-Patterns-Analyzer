package com.projecttracker.workflow;

public abstract class TicketWorkflow {

    // Abstract method to create a new ticket
    public abstract void createTicket();

    // Abstract method to assign a ticket to a developer
    public abstract void assignTicket();

    // Abstract method to update the ticket status
    public abstract void updateStatus();

    // Concrete method implementing the template method pattern
    public final void processTicket() {
        createTicket();
        assignTicket();
        updateStatus();
    }
}