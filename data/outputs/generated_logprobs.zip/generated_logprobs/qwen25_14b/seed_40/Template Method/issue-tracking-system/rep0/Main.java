package com.projecttracker;

import com.projecttracker.workflow.BugTicketWorkflow;
import com.projecttracker.workflow.FeatureTicketWorkflow;

public class Main {
    public static void main(String[] args) {
        TicketWorkflow bugWorkflow = new BugTicketWorkflow();
        bugWorkflow.processTicket();

        System.out.println();

        TicketWorkflow featureWorkflow = new FeatureTicketWorkflow();
        featureWorkflow.processTicket();
    }
}