package com.projecttracker.workflow;

public class FeatureTicketWorkflow extends TicketWorkflow {

    @Override
    public void createTicket() {
        System.out.println("Creating a new feature ticket...");
    }

    @Override
    public void assignTicket() {
        System.out.println("Assigning the feature ticket to a developer...");
    }

    @Override
    public void updateStatus() {
        System.out.println("Updating the status of the feature ticket...");
    }
}