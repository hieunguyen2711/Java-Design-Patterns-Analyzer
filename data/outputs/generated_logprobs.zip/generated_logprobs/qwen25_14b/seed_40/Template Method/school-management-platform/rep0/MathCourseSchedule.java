package com.example.enrollment;

public class MathCourseSchedule extends CourseSchedule {

    @Override
    protected void selectClasses() {
        System.out.println("Selecting math classes for the semester.");
    }

    @Override
    protected void assignTeachers() {
        System.out.println("Assigning teachers for math classes.");
    }

    @Override
    protected void setGradingCriteria() {
        System.out.println("Setting grading criteria for math classes.");
    }

    @Override
    protected void markAttendance() {
        System.out.println("Marking attendance for math classes.");
    }
}