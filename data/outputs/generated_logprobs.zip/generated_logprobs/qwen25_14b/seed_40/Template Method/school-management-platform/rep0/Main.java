package com.example.enrollment;

public class Main {
    public static void main(String[] args) {
        CourseSchedule mathSchedule = new MathCourseSchedule();
        mathSchedule.processSchedule();

        System.out.println("\n");

        CourseSchedule englishSchedule = new EnglishCourseSchedule();
        englishSchedule.processSchedule();
    }
}