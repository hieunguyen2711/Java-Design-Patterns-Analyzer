package com.example.enrollment;

public class EnglishCourseSchedule extends CourseSchedule {

    @Override
    protected void selectClasses() {
        System.out.println("Selecting English classes for the semester.");
    }

    @Override
    protected void assignTeachers() {
        System.out.println("Assigning teachers for English classes.");
    }

    @Override
    protected void setGradingCriteria() {
        System.out.println("Setting grading criteria for English classes.");
    }

    @Override
    protected void markAttendance() {
        System.out.println("Marking attendance for English classes.");
    }
}