package com.example.enrollment;

public abstract class CourseSchedule {
    // Template method
    public final void processSchedule() {
        selectClasses();
        assignTeachers();
        setGradingCriteria();
        markAttendance();
    }

    // Primitive operations
    protected abstract void selectClasses();
    protected abstract void assignTeachers();
    protected abstract void setGradingCriteria();
    protected abstract void markAttendance();
}