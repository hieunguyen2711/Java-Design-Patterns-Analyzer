public class SpecialMenuOrderProcessing extends AbstractOrderProcessing {

    @Override
    protected void prepareOrder() {
        System.out.println("Special preparation for the order...");
    }
}