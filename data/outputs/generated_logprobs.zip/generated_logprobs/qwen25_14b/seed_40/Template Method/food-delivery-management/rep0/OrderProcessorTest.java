public class OrderProcessorTest {

    public static void main(String[] args) {
        AbstractOrderProcessing standard = new StandardOrderProcessing();
        standard.processOrder();

        AbstractOrderProcessing special = new SpecialMenuOrderProcessing();
        special.processOrder();
    }
}