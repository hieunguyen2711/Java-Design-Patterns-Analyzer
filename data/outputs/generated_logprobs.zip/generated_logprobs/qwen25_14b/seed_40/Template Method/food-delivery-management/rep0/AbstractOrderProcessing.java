public abstract class AbstractOrderProcessing {

    // Template method
    public final void processOrder() {
        prepareOrder();
        cookFood();
        assignDelivery();
        trackOrderStatus();
    }

    // Hook method - can be overridden by subclasses
    protected void prepareOrder() {
        System.out.println("Preparing the order...");
    }

    // Concrete steps that cannot be changed
    protected void cookFood() {
        System.out.println("Cooking the food...");
    }

    // Concrete steps that cannot be changed
    protected void assignDelivery() {
        System.out.println("Assigning delivery person...");
    }

    // Concrete steps that cannot be changed
    protected void trackOrderStatus() {
        System.out.println("Tracking order status...");
    }
}