public class StandardOrderProcessing extends AbstractOrderProcessing {

    @Override
    protected void prepareOrder() {
        System.out.println("Standard preparation for the order...");
    }
}