package com.library.manager;

public class BookManager {
    private static BookManager instance;
    private String bookTitle;
    private int copiesAvailable;

    private BookManager(String bookTitle, int copiesAvailable) {
        this.bookTitle = bookTitle;
        this.copiesAvailable = copiesAvailable;
    }

    public static BookManager getInstance(String bookTitle, int copiesAvailable) {
        if (instance == null) {
            synchronized (BookManager.class) {
                if (instance == null) {
                    instance = new BookManager(bookTitle, copiesAvailable);
                }
            }
        }
        return instance;
    }

    public void borrowBook() {
        if (copiesAvailable > 0) {
            System.out.println("Borrowed " + bookTitle + ". Copies left: " + (--copiesAvailable));
        } else {
            System.out.println("No copies of " + bookTitle + " available.");
        }
    }

    public void returnBook() {
        System.out.println("Returned " + bookTitle + ". Copies now: " + (++copiesAvailable));
    }
}