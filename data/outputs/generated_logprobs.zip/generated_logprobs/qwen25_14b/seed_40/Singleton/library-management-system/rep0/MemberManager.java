package com.library.manager;

public class MemberManager {
    private static MemberManager instance;
    private int memberCount;

    private MemberManager() {
        this.memberCount = 0;
    }

    public static MemberManager getInstance() {
        if (instance == null) {
            synchronized (MemberManager.class) {
                if (instance == null) {
                    instance = new MemberManager();
                }
            }
        }
        return instance;
    }

    public void addMember() {
        System.out.println("Added a new member. Total members: " + (++memberCount));
    }

    public void removeMember() {
        if (memberCount > 0) {
            System.out.println("Removed a member. Total members: " + (--memberCount));
        } else {
            System.out.println("No members to remove.");
        }
    }
}