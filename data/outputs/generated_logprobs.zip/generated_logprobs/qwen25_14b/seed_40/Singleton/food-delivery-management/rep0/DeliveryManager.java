package com.restaurant.backend;

public class DeliveryManager {
    private static DeliveryManager instance;

    private DeliveryManager() {}

    public static synchronized DeliveryManager getInstance() {
        if (instance == null) {
            instance = new DeliveryManager();
        }
        return instance;
    }

    // Add methods to manage deliveries
}