package com.restaurant.backend;

public class MenuManager {
    private static MenuManager instance;

    private MenuManager() {}

    public static synchronized MenuManager getInstance() {
        if (instance == null) {
            instance = new MenuManager();
        }
        return instance;
    }

    // Add methods to manage menu items
}