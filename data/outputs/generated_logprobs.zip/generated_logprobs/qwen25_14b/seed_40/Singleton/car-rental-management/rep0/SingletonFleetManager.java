public class SingletonFleetManager {
    private static volatile SingletonFleetManager instance;
    private FleetInventory fleetInventory;

    private SingletonFleetManager() {
        // Initialize fleet inventory and other components here
        fleetInventory = new FleetInventory();
    }

    public static SingletonFleetManager getInstance() {
        if (instance == null) {
            synchronized (SingletonFleetManager.class) {
                if (instance == null) {
                    instance = new SingletonFleetManager();
                }
            }
        }
        return instance;
    }

    // Add methods for managing reservations, vehicle pickup/return, pricing, and maintenance status
}