package com.example.bank;

public class Main {
    public static void main(String[] args) {
        BankAccount account1 = new BankAccount("123456789", 1000);
        BankAccount account2 = new BankAccount("987654321", 500);

        account1.deposit(200);
        account1.transfer(account2, 300);

        AuditLogManager logger = AuditLogManager.getInstance("audit_log.txt");
        for (AccountAudit entry : account1.getAuditHistory()) {
            logger.log(entry);
        }
    }
}