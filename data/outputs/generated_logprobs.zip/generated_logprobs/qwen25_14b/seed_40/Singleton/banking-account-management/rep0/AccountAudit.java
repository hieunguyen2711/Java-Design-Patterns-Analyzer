package com.example.bank;

public class AccountAudit {
    private String action;
    private double amount;
    private String timestamp;

    public AccountAudit(String action, double amount, String timestamp) {
        this.action = action;
        this.amount = amount;
        this.timestamp = timestamp;
    }

    // Getters and setters can be added here

    @Override
    public String toString() {
        return "Action: " + action + ", Amount: " + amount + ", Timestamp: " + timestamp;
    }
}