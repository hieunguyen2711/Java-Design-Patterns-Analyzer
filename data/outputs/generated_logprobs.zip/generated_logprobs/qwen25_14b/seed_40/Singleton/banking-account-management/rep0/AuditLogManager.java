package com.example.bank;

public class AuditLogManager {
    private static AuditLogManager instance;
    private final String logFilePath;

    private AuditLogManager(String logFilePath) {
        this.logFilePath = logFilePath;
        // Simulate writing audit logs to a file
    }

    public static synchronized AuditLogManager getInstance(String logFilePath) {
        if (instance == null) {
            instance = new AuditLogManager(logFilePath);
        }
        return instance;
    }

    public void log(AccountAudit auditEntry) {
        // Code to write audit entry to log file at logFilePath
        System.out.println("Logging: " + auditEntry.toString());
    }
}