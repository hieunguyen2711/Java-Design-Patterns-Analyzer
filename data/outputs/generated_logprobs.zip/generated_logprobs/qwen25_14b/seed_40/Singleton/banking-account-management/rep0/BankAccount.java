package com.example.bank;

public class BankAccount {
    private String accountNumber;
    private double balance;
    private AccountAudit[] auditHistory;

    public BankAccount(String accountNumber, double initialDeposit) {
        this.accountNumber = accountNumber;
        this.balance = initialDeposit;
        this.auditHistory = new AccountAudit[0];
    }

    public void deposit(double amount) {
        this.balance += amount;
        addAuditEntry("DEPOSIT", amount);
    }

    public boolean withdraw(double amount) {
        if (this.balance >= amount) {
            this.balance -= amount;
            addAuditEntry("WITHDRAWAL", amount);
            return true;
        } else {
            return false;
        }
    }

    public void transfer(BankAccount recipient, double amount) {
        if (withdraw(amount)) {
            recipient.deposit(amount);
            addAuditEntry("TRANSFER TO " + recipient.getAccountNumber(), amount);
        }
    }

    private void addAuditEntry(String action, double amount) {
        AccountAudit[] newHistory = Arrays.copyOf(auditHistory, auditHistory.length + 1);
        newHistory[newHistory.length - 1] = new AccountAudit(action, amount, getCurrentTimestamp());
        auditHistory = newHistory;
    }

    private String getCurrentTimestamp() {
        return String.valueOf(System.currentTimeMillis());
    }

    // Getters and setters can be added here

    public String getAccountNumber() {
        return accountNumber;
    }

    public double getBalance() {
        return balance;
    }

    public AccountAudit[] getAuditHistory() {
        return auditHistory;
    }
}