package com.example.inventory;

public interface BillingService {
    void billGuest(String guestName, double amount);
}