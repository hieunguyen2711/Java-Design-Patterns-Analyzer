package com.example.inventory;

public class RoomInventoryManager {
    private static RoomInventoryManager instance;
    private final PricingPlan pricingPlan;
    private final BillingService billingService;

    private RoomInventoryManager(PricingPlan pricingPlan, BillingService billingService) {
        this.pricingPlan = pricingPlan;
        this.billingService = billingService;
    }

    public static RoomInventoryManager getInstance(PricingPlan pricingPlan, BillingService billingService) {
        if (instance == null) {
            synchronized (RoomInventoryManager.class) {
                if (instance == null) {
                    instance = new RoomInventoryManager(pricingPlan, billingService);
                }
            }
        }
        return instance;
    }

    // Methods related to managing room inventory, bookings, etc.
}