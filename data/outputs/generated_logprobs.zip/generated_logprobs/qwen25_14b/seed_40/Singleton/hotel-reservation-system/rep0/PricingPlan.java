package com.example.inventory;

public interface PricingPlan {
    double getPriceForStay(int numberOfNights);
}