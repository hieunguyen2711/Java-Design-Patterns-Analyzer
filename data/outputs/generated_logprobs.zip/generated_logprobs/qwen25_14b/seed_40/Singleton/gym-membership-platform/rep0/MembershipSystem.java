package com.membership.system;

public class MembershipSystem {
    private static MembershipSystem instance;
    private final Schedule schedule;
    private final TrainerBooking trainerBooking;
    private final AttendanceCheckIn attendanceCheckIn;
    private final PaymentTracking paymentTracking;

    private MembershipSystem() {
        schedule = new Schedule();
        trainerBooking = new TrainerBooking();
        attendanceCheckIn = new AttendanceCheckIn();
        paymentTracking = new PaymentTracking();
    }

    public static MembershipSystem getInstance() {
        if (instance == null) {
            synchronized (MembershipSystem.class) {
                if (instance == null) {
                    instance = new MembershipSystem();
                }
            }
        }
        return instance;
    }

    // Methods related to membership system functionalities can be added here
}