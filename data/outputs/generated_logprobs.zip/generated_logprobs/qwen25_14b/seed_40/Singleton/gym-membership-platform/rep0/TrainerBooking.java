package com.membership.system;

public class TrainerBooking {
    // Class implementation related to trainer booking goes here
}