package com.example.enrollment;

public class Main {
    public static void main(String[] args) {
        // Accessing the Singleton instance
        SingletonPatternExample system = SingletonPatternExample.getInstance();
        system.enrollStudent("123456");

        // Attempting to create another instance should result in the same object
        SingletonPatternExample anotherSystem = SingletonPatternExample.getInstance();
        if (system == anotherSystem) {
            System.out.println("Singleton works, both variables contain the same instance.");
        }
    }
}