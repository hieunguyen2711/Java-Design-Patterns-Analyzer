package com.example.enrollment;

/**
 * This class demonstrates the Singleton Design Pattern.
 * It ensures that only one instance of the StudentEnrollmentSystem exists.
 */
public class SingletonPatternExample {
    private static final SingletonPatternExample INSTANCE = new SingletonPatternExample();

    private SingletonPatternExample() {}

    public static SingletonPatternExample getInstance() {
        return INSTANCE;
    }

    // Example method to simulate functionality
    public void enrollStudent(String studentId) {
        System.out.println("Enrolling student with ID: " + studentId);
    }
}