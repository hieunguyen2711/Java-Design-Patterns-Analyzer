package com.example.tickettracker;

public class SingletonTicketTrackerFactory {
    private static final SingletonTicketTrackerFactory INSTANCE = new SingletonTicketTrackerFactory();

    private SingletonTicketTrackerFactory() {}

    public static SingletonTicketTrackerFactory getInstance() {
        return INSTANCE;
    }

    public TicketTracker createTicketTracker(String ticketId) {
        return new TicketTracker(ticketId);
    }
}