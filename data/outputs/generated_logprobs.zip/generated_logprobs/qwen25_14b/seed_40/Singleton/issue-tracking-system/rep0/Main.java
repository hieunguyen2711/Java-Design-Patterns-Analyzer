package com.example.tickettracker;

public class Main {
    public static void main(String[] args) {
        SingletonTicketTrackerFactory factory = SingletonTicketTrackerFactory.getInstance();
        TicketTracker ticket1 = factory.createTicketTracker("TICKET001");
        TicketTracker ticket2 = factory.createTicketTracker("TICKET002");

        System.out.println(ticket1.getTicketId());
        System.out.println(ticket2.getTicketId());
    }
}