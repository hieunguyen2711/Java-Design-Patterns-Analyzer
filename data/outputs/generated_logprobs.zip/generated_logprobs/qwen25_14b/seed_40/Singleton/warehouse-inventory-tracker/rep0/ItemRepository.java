package com.stockmanagement;

public class ItemRepository {
    private static ItemRepository instance;
    private final java.util.List<Item> items = new java.util.ArrayList<>();

    private ItemRepository() {
        // Initialize items or load from database
        items.add(new Item("Item1", 10, "LocationA"));
        items.add(new Item("Item2", 5, "LocationB"));
    }

    public static ItemRepository getInstance() {
        if (instance == null) {
            instance = new ItemRepository();
        }
        return instance;
    }

    public java.util.List<Item> getItems() {
        return items;
    }
}