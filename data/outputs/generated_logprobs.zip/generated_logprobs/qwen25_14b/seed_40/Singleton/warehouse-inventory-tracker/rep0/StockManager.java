package com.stockmanagement;

public class StockManager {
    private static StockManager instance;
    private final ItemRepository itemRepository;

    private StockManager() {
        itemRepository = ItemRepository.getInstance();
    }

    public static synchronized StockManager getInstance() {
        if (instance == null) {
            instance = new StockManager();
        }
        return instance;
    }

    public void manageStock() {
        // Logic to manage stock based on item locations, reorder thresholds, etc.
        System.out.println("Managing stock with items from " + itemRepository.getItems().size() + " different locations.");
    }
}