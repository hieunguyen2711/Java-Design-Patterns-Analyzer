package clinic.manager;

import clinic.model.Doctor;
import clinic.model.Patient;
import clinic.model.VisitHistory;

public class ClinicManager {
    private Doctor doctor;
    private Patient patient;
    private VisitHistory visitHistory;

    public ClinicManager(Doctor doctor, Patient patient) {
        this.doctor = doctor;
        this.patient = patient;
        this.visitHistory = new VisitHistory();
    }

    public void scheduleAppointment(AppointmentSlot slot) {
        // Logic to schedule an appointment
        visitHistory.addVisit(slot);
    }

    public VisitHistory getVisitHistory() {
        return visitHistory;
    }
}