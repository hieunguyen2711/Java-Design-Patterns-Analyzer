package clinic;

import clinic.database.SingletonClinicDatabase;
import clinic.manager.ClinicManager;
import clinic.model.AppointmentSlot;
import clinic.model.Doctor;
import clinic.model.Patient;

public class Main {
    public static void main(String[] args) {
        Doctor doctor = new Doctor("D001", "Dr. Smith");
        Patient patient = new Patient("P001", "John Doe");

        ClinicManager manager = new ClinicManager(doctor, patient);

        AppointmentSlot slot = new AppointmentSlot(
                java.time.LocalDateTime.of(2023, 10, 1, 9, 0),
                java.time.LocalDateTime.of(2023, 10, 1, 10, 0)
        );

        manager.scheduleAppointment(slot);

        SingletonClinicDatabase db = SingletonClinicDatabase.getInstance();
        // Interact with the database

        System.out.println("Visit History: " + manager.getVisitHistory().getVisitList());
    }
}