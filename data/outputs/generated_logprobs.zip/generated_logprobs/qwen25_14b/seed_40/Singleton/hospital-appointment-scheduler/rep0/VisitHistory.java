package clinic.model;

import java.util.ArrayList;
import java.util.List;

public class VisitHistory {
    private List<AppointmentSlot> visitList;

    public VisitHistory() {
        this.visitList = new ArrayList<>();
    }

    public void addVisit(AppointmentSlot slot) {
        visitList.add(slot);
    }

    public List<AppointmentSlot> getVisitList() {
        return visitList;
    }
}