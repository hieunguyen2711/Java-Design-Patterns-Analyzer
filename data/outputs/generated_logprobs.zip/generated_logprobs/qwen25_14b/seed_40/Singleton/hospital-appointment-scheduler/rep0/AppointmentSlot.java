package clinic.model;

import java.time.LocalDateTime;

public class AppointmentSlot {
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private boolean isBooked;

    public AppointmentSlot(LocalDateTime startTime, LocalDateTime endTime) {
        this.startTime = startTime;
        this.endTime = endTime;
        this.isBooked = false;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public boolean isBooked() {
        return isBooked;
    }

    public void setBooked(boolean booked) {
        isBooked = booked;
    }
}