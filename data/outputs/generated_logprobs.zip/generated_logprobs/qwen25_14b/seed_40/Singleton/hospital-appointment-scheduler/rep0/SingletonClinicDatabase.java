package clinic.database;

public class SingletonClinicDatabase {
    private static SingletonClinicDatabase instance;

    private SingletonClinicDatabase() {}

    public static synchronized SingletonClinicDatabase getInstance() {
        if (instance == null) {
            instance = new SingletonClinicDatabase();
        }
        return instance;
    }

    // Methods to interact with the database can be added here
}