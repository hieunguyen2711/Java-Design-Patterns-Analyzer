package hr.system;

import java.util.ArrayList;
import java.util.List;

public class PayrollSystem {
    private List<Employee> employees = new ArrayList<>();

    public void addEmployee(Employee employee) {
        employees.add(employee);
    }

    public void removeEmployee(Employee employee) {
        employees.remove(employee);
    }

    public void notifyTaxDeduction(double deductionPercentage) {
        for (Employee employee : employees) {
            System.out.println("Notifying " + employee.getName() + " about " + deductionPercentage + "% tax deduction.");
        }
    }
}