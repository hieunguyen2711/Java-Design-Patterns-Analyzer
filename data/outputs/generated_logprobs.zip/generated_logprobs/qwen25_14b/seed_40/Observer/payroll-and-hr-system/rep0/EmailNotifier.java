package hr.system;

public class EmailNotifier implements Observer {
    private String email;

    public EmailNotifier(String email) {
        this.email = email;
    }

    @Override
    public void update(double deductionPercentage) {
        System.out.println("Sending email to " + email + " regarding " + deductionPercentage + "% tax deduction.");
    }
}