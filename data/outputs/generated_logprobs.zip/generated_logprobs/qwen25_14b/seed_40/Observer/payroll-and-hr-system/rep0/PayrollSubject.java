package hr.system;

import java.util.ArrayList;
import java.util.List;

public class PayrollSubject implements Subject {
    private List<Observer> observers = new ArrayList<>();
    private PayrollSystem payrollSystem;

    public PayrollSubject(PayrollSystem payrollSystem) {
        this.payrollSystem = payrollSystem;
    }

    @Override
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers(double deductionPercentage) {
        for (Observer observer : observers) {
            observer.update(deductionPercentage);
        }
    }

    public void notifyTaxDeduction(double deductionPercentage) {
        notifyObservers(deductionPercentage);
    }
}