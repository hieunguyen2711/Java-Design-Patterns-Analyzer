package hr.system;

public interface Observer {
    void update(double deductionPercentage);
}