package hr.system;

public class Main {
    public static void main(String[] args) {
        PayrollSystem payrollSystem = new PayrollSystem();
        PayrollSubject payrollSubject = new PayrollSubject(payrollSystem);

        Employee employee1 = new Employee("E001", "John Doe", 50000);
        Employee employee2 = new Employee("E002", "Jane Smith", 60000);

        payrollSystem.addEmployee(employee1);
        payrollSystem.addEmployee(employee2);

        payrollSubject.registerObserver(new EmailNotifier("john.doe@example.com"));
        payrollSubject.registerObserver(new EmailNotifier("jane.smith@example.com"));

        payrollSystem.notifyTaxDeduction(15); // This will trigger notifications via the registered observers
    }
}