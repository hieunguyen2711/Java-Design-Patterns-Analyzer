package patterns.observer;

public class Nurse implements Observer {
    @Override
    public void update(String message) {
        if ("Patient Checked In".equals(message)) {
            System.out.println("Nurse: Preparing examination room for " + ((DoctorAppointmentSubject) this).getPatientName());
        } else if ("Patient Name Changed".equals(message)) {
            System.out.println("Nurse: Updating patient information");
        }
    }

    private String getPatientName() {
        return ((DoctorAppointmentSubject) this).patientName;
    }
}