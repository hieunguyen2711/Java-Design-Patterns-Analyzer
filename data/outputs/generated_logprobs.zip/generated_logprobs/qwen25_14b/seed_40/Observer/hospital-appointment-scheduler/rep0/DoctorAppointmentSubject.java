package patterns.observer;

import java.util.ArrayList;
import java.util.List;

public class DoctorAppointmentSubject implements Subject {
    private List<Observer> observers = new ArrayList<>();
    private String patientName;
    private boolean isPatientCheckedIn;

    public DoctorAppointmentSubject() {
        this.patientName = "";
        this.isPatientCheckedIn = false;
    }

    @Override
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers(String message) {
        for (Observer observer : observers) {
            observer.update(message);
        }
    }

    public void setPatientName(String name) {
        this.patientName = name;
        System.out.println("Doctor: Setting Patient Name to " + name);
        notifyObservers("Patient Name Changed");
    }

    public void checkInPatient() {
        this.isPatientCheckedIn = true;
        System.out.println("Doctor: Patient Checked In");
        notifyObservers("Patient Checked In");
    }
}