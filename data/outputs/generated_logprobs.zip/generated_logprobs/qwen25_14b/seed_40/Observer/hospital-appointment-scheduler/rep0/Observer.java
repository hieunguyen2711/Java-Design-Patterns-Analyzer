package patterns.observer;

import java.util.ArrayList;
import java.util.List;

public interface Observer {
    void update(String message);
}