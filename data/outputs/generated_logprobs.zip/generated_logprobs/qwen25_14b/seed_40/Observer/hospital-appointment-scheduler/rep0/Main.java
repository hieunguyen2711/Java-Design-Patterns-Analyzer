package patterns.observer;

public class Main {
    public static void main(String[] args) {
        DoctorAppointmentSubject doctor = new DoctorAppointmentSubject();
        Receptionist receptionist = new Receptionist();
        Nurse nurse = new Nurse();

        doctor.registerObserver(receptionist);
        doctor.registerObserver(nurse);

        doctor.setPatientName("John Doe");
        doctor.checkInPatient();
    }
}