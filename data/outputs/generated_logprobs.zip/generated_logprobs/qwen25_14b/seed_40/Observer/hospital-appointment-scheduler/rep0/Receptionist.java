package patterns.observer;

public class Receptionist implements Observer {
    @Override
    public void update(String message) {
        if ("Patient Checked In".equals(message)) {
            System.out.println("Receptionist: Confirming appointment with " + ((DoctorAppointmentSubject) this).getPatientName());
        } else if ("Patient Name Changed".equals(message)) {
            System.out.println("Receptionist: Notifying doctor of name change");
        }
    }

    private String getPatientName() {
        return ((DoctorAppointmentSubject) this).patientName;
    }
}