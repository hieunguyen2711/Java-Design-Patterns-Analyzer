package com.fleetmanagement;

public class Bike implements Vehicle {
    private String id;
    private String model;
    private String reservationStatus;

    public Bike(String id, String model) {
        this.id = id;
        this.model = model;
        this.reservationStatus = "Available";
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public String getModel() {
        return model;
    }

    @Override
    public String getReservationStatus() {
        return reservationStatus;
    }

    @Override
    public void setReservationStatus(String status) {
        this.reservationStatus = status;
        notifyObservers(status);
    }

    @Override
    public String toString() {
        return "Bike{" +
                "id='" + id + '\'' +
                ", model='" + model + '\'' +
                ", reservationStatus='" + reservationStatus + '\'' +
                '}';
    }
}