package com.fleetmanagement;

public class VehicleReservationSystem {
    public static void main(String[] args) {
        FleetManager manager = new FleetManager();

        Vehicle vehicle1 = new Car("V1", "Toyota Camry");
        Vehicle vehicle2 = new Bike("B1", "Honda CB1000R");

        manager.addVehicle(vehicle1);
        manager.addVehicle(vehicle2);

        vehicle1.setReservationStatus("Reserved");
        vehicle2.setReservationStatus("Available");
    }
}