package com.fleetmanagement;

import java.util.ArrayList;
import java.util.List;

public class FleetManager implements VehicleObserver {
    private List<Vehicle> vehicles = new ArrayList<>();

    public void addVehicle(Vehicle vehicle) {
        vehicles.add(vehicle);
    }

    public void removeVehicle(Vehicle vehicle) {
        vehicles.remove(vehicle);
    }

    @Override
    public void update(Vehicle vehicle) {
        System.out.println("Vehicle " + vehicle.getId() + " has changed its reservation status to " + vehicle.getReservationStatus());
    }
}