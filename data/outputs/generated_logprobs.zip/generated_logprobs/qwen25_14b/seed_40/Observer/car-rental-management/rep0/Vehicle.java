package com.fleetmanagement;

public interface Vehicle {
    String getId();
    String getModel();
    String getReservationStatus();
    void setReservationStatus(String status);
}