package com.fleetmanagement;

public interface VehicleObserver {
    void update(Vehicle vehicle);
}