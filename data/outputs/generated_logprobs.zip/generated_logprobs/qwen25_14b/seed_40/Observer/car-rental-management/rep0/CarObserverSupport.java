package com.fleetmanagement;

import java.util.ArrayList;
import java.util.List;

public abstract class CarObserverSupport implements VehicleObserver {
    protected List<VehicleObserver> observers = new ArrayList<>();

    public void addObserver(VehicleObserver observer) {
        observers.add(observer);
    }

    public void removeObserver(VehicleObserver observer) {
        observers.remove(observer);
    }

    protected void notifyObservers(String status) {
        for (VehicleObserver observer : observers) {
            observer.update(this);
        }
    }
}