package com.example.designpatterns;

import java.util.List;
import java.util.LinkedList;

public class StatementGenerator implements Observer {
    private List<Double> transactions = new LinkedList<>();

    @Override
    public void update(Account account) {
        transactions.add(account.getBalance());
    }

    public List<Double> getTransactions() {
        return transactions;
    }
}