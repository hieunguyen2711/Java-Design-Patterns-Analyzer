package com.example.designpatterns;

import java.util.LinkedList;
import java.util.Queue;

public class AuditHistory implements Observer {
    private Queue<Double> history = new LinkedList<>();

    @Override
    public void update(Account account) {
        history.offer(account.getBalance());
    }

    public Queue<Double> getHistory() {
        return history;
    }
}