package com.example.designpatterns;

public interface Observer {
    void update(Account account);
}