package com.example.designpatterns;

import java.util.ArrayList;
import java.util.List;

public class Account {
    private double balance;
    private List<Observer> observers = new ArrayList<>();

    public Account(double initialBalance) {
        this.balance = initialBalance;
    }

    public void deposit(double amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Deposit amount must be positive");
        }
        balance += amount;
        notifyObservers();
    }

    public void withdraw(double amount) {
        if (amount <= 0 || amount > balance) {
            throw new IllegalArgumentException("Withdrawal amount must be positive and less than or equal to the balance");
        }
        balance -= amount;
        notifyObservers();
    }

    public double getBalance() {
        return balance;
    }

    public void attach(Observer observer) {
        observers.add(observer);
    }

    public void detach(Observer observer) {
        observers.remove(observer);
    }

    private void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(this);
        }
    }
}