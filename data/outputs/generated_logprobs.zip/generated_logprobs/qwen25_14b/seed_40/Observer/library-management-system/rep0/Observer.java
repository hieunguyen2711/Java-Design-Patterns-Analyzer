import java.util.Observable;
import java.util.Observer;

public interface Observer extends java.util.Observer {
    @Override
    void update(Observable o, Object arg);
}