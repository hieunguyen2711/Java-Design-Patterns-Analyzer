public class EmailNotificationService implements Observer {
    private String email;

    public EmailNotificationService(String email) {
        this.email = email;
    }

    @Override
    public void update(Observable o, Object arg) {
        String message = (String)arg;
        sendEmail(message);
    }

    private void sendEmail(String message) {
        System.out.println("Sending email: " + message + " to " + email);
    }
}