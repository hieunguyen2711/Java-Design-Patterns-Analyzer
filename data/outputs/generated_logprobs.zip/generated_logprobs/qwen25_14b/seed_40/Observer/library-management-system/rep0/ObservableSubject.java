import java.util.Observable;

public abstract class ObservableSubject extends Observable {
    protected void notifyObservers(Object data) {
        setChanged();
        notifyObservers(data);
    }
}