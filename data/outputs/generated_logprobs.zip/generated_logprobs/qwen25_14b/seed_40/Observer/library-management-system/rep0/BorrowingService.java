import java.util.ArrayList;
import java.util.List;

public class BorrowingService extends ObservableSubject {
    private List<Book> books;
    private List<LibraryMember> members;

    public BorrowingService() {
        books = new ArrayList<>();
        members = new ArrayList<>();
    }

    public void registerObserver(Observer observer) {
        addObserver(observer);
    }

    public void unregisterObserver(Observer observer) {
        deleteObserver(observer);
    }

    public void borrowBook(LibraryMember member, Book book) {
        if (book.isAvailable()) {
            book.setAvailable(false);
            members.add(member);
            notifyObservers("Borrowed " + book.getTitle() + " by " + member.getName());
        } else {
            System.out.println(book.getTitle() + " is not available.");
        }
    }

    public void returnBook(Book book) {
        book.setAvailable(true);
        notifyObservers("Returned " + book.getTitle());
    }
}