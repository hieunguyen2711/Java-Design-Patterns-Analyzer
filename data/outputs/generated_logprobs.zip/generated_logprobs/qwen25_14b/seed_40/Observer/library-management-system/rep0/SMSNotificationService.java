public class SMSNotificationService implements Observer {
    private String phoneNumber;

    public SMSNotificationService(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @Override
    public void update(Observable o, Object arg) {
        String message = (String)arg;
        sendSMS(message);
    }

    private void sendSMS(String message) {
        System.out.println("Sending SMS: " + message + " to " + phoneNumber);
    }
}