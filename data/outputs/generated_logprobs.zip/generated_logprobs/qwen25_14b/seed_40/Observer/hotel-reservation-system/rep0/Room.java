package com.example.inventory;

public class Room {
    private int id;
    private boolean isBooked;

    public Room(int id) {
        this.id = id;
        this.isBooked = false;
    }

    public int getId() {
        return id;
    }

    public boolean isBooked() {
        return isBooked;
    }

    public void book() {
        this.isBooked = true;
    }
}