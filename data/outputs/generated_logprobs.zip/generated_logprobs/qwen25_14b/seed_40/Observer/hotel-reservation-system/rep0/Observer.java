package com.example.inventory;

public interface Observer {
    void update(RoomInventory roomInventory);
}