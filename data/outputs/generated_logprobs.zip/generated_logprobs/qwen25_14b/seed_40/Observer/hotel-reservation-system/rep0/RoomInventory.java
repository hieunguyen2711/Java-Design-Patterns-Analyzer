package com.example.inventory;

import java.util.ArrayList;
import java.util.List;

public class RoomInventory {
    private List<Room> rooms = new ArrayList<>();
    private List<Observer> observers = new ArrayList<>();

    public void addRoom(Room room) {
        rooms.add(room);
        notifyObservers();
    }

    public void removeRoom(Room room) {
        rooms.remove(room);
        notifyObservers();
    }

    public void bookRoom(int roomId) {
        for (Room room : rooms) {
            if (room.getId() == roomId) {
                room.book();
                break;
            }
        }
        notifyObservers();
    }

    public void addObserver(Observer observer) {
        observers.add(observer);
    }

    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    private void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(this);
        }
    }
}