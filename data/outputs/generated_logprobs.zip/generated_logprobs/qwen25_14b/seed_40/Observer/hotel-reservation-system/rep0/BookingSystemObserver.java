package com.example.inventory;

public class BookingSystemObserver implements Observer {
    @Override
    public void update(RoomInventory roomInventory) {
        System.out.println("Booking system notified of changes in room inventory.");
        // Here you could implement logic to synchronize with a booking system
    }
}