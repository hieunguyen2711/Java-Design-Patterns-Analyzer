package com.example.inventory;

public class BillingSystemObserver implements Observer {
    @Override
    public void update(RoomInventory roomInventory) {
        System.out.println("Billing system notified of changes in room inventory.");
        // Here you could implement logic to adjust billing based on room status
    }
}