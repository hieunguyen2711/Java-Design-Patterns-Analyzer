public class PaymentTrackingObserver implements Observer {
    @Override
    public void update(String message) {
        System.out.println("Payment Tracking Observer: " + message);
    }
}