public class TrainerBookingObserver implements Observer {
    @Override
    public void update(String message) {
        System.out.println("Trainer Booking Observer: " + message);
    }
}