public class AttendanceCheckInObserver implements Observer {
    @Override
    public void update(String message) {
        System.out.println("Attendance Check-In Observer: " + message);
    }
}