public class Main {
    public static void main(String[] args) {
        MembershipSubject membershipSubject = new MembershipSubject();

        TrainerBookingObserver trainerBookingObserver = new TrainerBookingObserver();
        AttendanceCheckInObserver attendanceCheckInObserver = new AttendanceCheckInObserver();
        PaymentTrackingObserver paymentTrackingObserver = new PaymentTrackingObserver();

        membershipSubject.registerObserver(trainerBookingObserver);
        membershipSubject.registerObserver(attendanceCheckInObserver);
        membershipSubject.registerObserver(paymentTrackingObserver);

        membershipSubject.setMessageAndNotify("New member joined!");
    }
}