import java.util.ArrayList;
import java.util.List;

/**
 * Interface for Observers in the Observer Design Pattern.
 */
public interface Observer {
    void update(String message);
}