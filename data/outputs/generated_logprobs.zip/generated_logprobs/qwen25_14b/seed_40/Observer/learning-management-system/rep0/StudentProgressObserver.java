/**
 * Concrete Observer implementing the Observer interface.
 * This represents a student who is interested in knowing about their course progress.
 */
public class StudentProgressObserver implements Observer {

    private String name;

    public StudentProgressObserver(String name) {
        this.name = name;
    }

    @Override
    public void update(String message) {
        System.out.println(name + " received an update: " + message);
    }
}