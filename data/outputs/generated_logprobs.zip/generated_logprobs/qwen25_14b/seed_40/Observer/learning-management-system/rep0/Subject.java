import java.util.ArrayList;
import java.util.List;

/**
 * Interface for Subjects in the Observer Design Pattern.
 */
public interface Subject {
    void registerObserver(Observer observer);
    void removeObserver(Observer observer);
    void notifyObservers(String message);
}