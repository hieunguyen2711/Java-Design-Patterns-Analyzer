/**
 * Main class to demonstrate the Observer Design Pattern in action.
 */
public class Main {
    public static void main(String[] args) {
        CourseProgressSubject courseProgress = new CourseProgressSubject();

        Observer alice = new StudentProgressObserver("Alice");
        Observer bob = new StudentProgressObserver("Bob");

        courseProgress.registerObserver(alice);
        courseProgress.registerObserver(bob);

        // Simulate progress updates
        courseProgress.setProgress("New assignment added.");
        courseProgress.setProgress("Assignment due date extended.");

        courseProgress.removeObserver(alice);

        // Alice should no longer receive updates
        courseProgress.setProgress("Final grades released.");
    }
}