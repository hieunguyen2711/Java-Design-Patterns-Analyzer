import java.util.ArrayList;
import java.util.List;

/**
 * Concrete Subject implementing the Subject interface.
 * This represents a course's progress which can notify observers about updates.
 */
public class CourseProgressSubject implements Subject {

    private List<Observer> observers = new ArrayList<>();
    private String progressMessage;

    @Override
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers(String message) {
        this.progressMessage = message;
        for (Observer observer : observers) {
            observer.update(message);
        }
    }

    /**
     * Method to simulate course progress updates.
     */
    public void setProgress(String message) {
        notifyObservers(message);
    }
}