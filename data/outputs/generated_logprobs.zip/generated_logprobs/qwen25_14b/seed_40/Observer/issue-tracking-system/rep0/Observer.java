package com.example.tickettracker;

public interface Observer {
    void update(String message);
}