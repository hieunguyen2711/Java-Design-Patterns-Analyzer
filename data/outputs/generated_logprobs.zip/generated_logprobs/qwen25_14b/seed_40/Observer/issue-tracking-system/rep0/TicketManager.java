package com.example.tickettracker;

public class TicketManager implements Ticket {
    private java.util.List<Observer> observers = new java.util.ArrayList<>();

    @Override
    public void addObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers(String update) {
        for (Observer observer : observers) {
            observer.update(update);
        }
    }

    public void createTicket() {
        System.out.println("A new ticket has been created.");
        notifyObservers("A new ticket has been created.");
    }
}