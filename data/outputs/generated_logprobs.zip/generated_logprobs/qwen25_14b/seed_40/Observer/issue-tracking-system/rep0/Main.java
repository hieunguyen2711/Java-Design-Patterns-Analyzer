package com.example.tickettracker;

public class Main {
    public static void main(String[] args) {
        TicketManager ticketManager = new TicketManager();
        
        Observer developer1 = new Developer("Alice");
        Observer developer2 = new Developer("Bob");

        ticketManager.addObserver(developer1);
        ticketManager.addObserver(developer2);

        ticketManager.createTicket();

        ticketManager.removeObserver(developer1);
        ticketManager.createTicket();
    }
}