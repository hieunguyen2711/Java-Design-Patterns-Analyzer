package com.example.tickettracker;

public interface Ticket {
    void addObserver(Observer observer);
    void removeObserver(Observer observer);
    void notifyObservers(String update);
}