import java.util.Observable;

public interface Subject extends Observable {
    void registerObserver(Observer o);
    void removeObserver(Observer o);
    void notifyObservers();
}