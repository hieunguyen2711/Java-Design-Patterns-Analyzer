import java.util.Observable;

public class RestaurantOrder extends Observable implements Subject {
    private OrderStatus status = OrderStatus.PENDING;

    public void setStatus(OrderStatus status) {
        this.status = status;
        setChanged();
        notifyObservers(status);
    }

    @Override
    public void registerObserver(Observer o) {
        addObserver(o);
    }

    @Override
    public void removeObserver(Observer o) {
        deleteObserver(o);
    }

    @Override
    public void notifyObservers() {
        setChanged();
        notifyObservers();
    }
}