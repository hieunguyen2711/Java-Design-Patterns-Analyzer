public class DeliveryService implements Observer {
    @Override
    public void update(Observable o, Object arg) {
        if (arg instanceof OrderStatus && ((OrderStatus)arg).equals(OrderStatus.READY_FOR_PICKUP)) {
            System.out.println("Delivery service received an update. Order is ready for pickup.");
        }
    }
}