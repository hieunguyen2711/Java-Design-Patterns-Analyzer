public class CustomerNotificationService implements Observer {
    @Override
    public void update(Observable o, Object arg) {
        if (arg instanceof OrderStatus && ((OrderStatus)arg).equals(OrderStatus.DELIVERED)) {
            System.out.println("Customer notification service received an update. Your order has been delivered.");
        }
    }
}