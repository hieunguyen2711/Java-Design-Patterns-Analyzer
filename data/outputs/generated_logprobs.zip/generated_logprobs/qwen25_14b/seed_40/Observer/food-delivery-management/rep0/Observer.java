import java.util.Observable;
import java.util.Observer;

public interface Observer {
    void update(Observable o, Object arg);
}