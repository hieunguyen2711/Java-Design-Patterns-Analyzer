public class Main {
    public static void main(String[] args) {
        RestaurantOrder order = new RestaurantOrder();

        DeliveryService deliveryService = new DeliveryService();
        CustomerNotificationService customerNotificationService = new CustomerNotificationService();

        order.registerObserver(deliveryService);
        order.registerObserver(customerNotificationService);

        // Simulate order status changes
        order.setStatus(OrderStatus.PREPARING);
        order.setStatus(OrderStatus.READY_FOR_PICKUP);
        order.setStatus(OrderStatus.DELIVERED);
    }
}