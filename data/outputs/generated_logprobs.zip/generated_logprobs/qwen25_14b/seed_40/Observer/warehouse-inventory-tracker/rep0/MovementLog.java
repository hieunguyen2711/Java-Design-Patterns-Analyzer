package com.stockmanagement;

import java.util.logging.Logger;

public class MovementLog implements Observer {
    private static final Logger LOGGER = Logger.getLogger(MovementLog.class.getName());

    @Override
    public void update(StockItem item, int quantity) {
        LOGGER.info(item.getItemName() + " quantity updated to " + quantity);
        // Logic to log the movement of the item
    }
}