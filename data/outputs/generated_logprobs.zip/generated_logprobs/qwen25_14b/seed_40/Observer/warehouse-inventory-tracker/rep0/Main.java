package com.stockmanagement;

public class Main {
    public static void main(String[] args) {
        StockItem item = new StockItem("Laptop", 50, 10);

        MovementLog log = new MovementLog();
        SupplierRestocker restocker = new SupplierRestocker();

        item.addObserver(log);
        item.addObserver(restocker);

        item.setQuantity(8); // Below reorder threshold, should trigger supplier restock
        item.setQuantity(20); // Above reorder threshold, no action expected
    }
}