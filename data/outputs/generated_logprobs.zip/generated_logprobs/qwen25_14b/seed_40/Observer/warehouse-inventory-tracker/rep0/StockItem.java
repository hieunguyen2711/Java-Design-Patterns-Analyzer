package com.stockmanagement;

public class StockItem {
    private String itemName;
    private int quantity;
    private int reorderThreshold;

    public StockItem(String itemName, int initialQuantity, int reorderThreshold) {
        this.itemName = itemName;
        this.quantity = initialQuantity;
        this.reorderThreshold = reorderThreshold;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
        notifyObservers();
    }

    public int getQuantity() {
        return quantity;
    }

    public int getReorderThreshold() {
        return reorderThreshold;
    }

    // Observer methods
    private java.util.List<Observer> observers = new java.util.ArrayList<>();

    public void addObserver(Observer observer) {
        observers.add(observer);
    }

    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    protected void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(this, quantity);
        }
    }
}