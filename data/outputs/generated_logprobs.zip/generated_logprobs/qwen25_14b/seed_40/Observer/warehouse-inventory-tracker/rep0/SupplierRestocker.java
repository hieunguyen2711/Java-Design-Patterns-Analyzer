package com.stockmanagement;

import java.util.logging.Logger;

public class SupplierRestocker implements Observer {
    private static final Logger LOGGER = Logger.getLogger(SupplierRestocker.class.getName());

    @Override
    public void update(StockItem item, int quantity) {
        if (quantity <= item.getReorderThreshold()) {
            LOGGER.info("Reordering " + item.getItemName() + " from supplier.");
            // Logic to contact supplier and order more items
        }
    }
}