package com.stockmanagement;

public interface Observer {
    void update(StockItem item, int quantity);
}