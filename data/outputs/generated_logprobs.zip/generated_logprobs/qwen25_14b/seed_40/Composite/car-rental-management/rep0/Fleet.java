import java.util.ArrayList;
import java.util.List;

public class Fleet implements Vehicle {
    private List<Vehicle> vehicles;

    public Fleet() {
        this.vehicles = new ArrayList<>();
    }

    public void addVehicle(Vehicle vehicle) {
        vehicles.add(vehicle);
    }

    public void removeVehicle(Vehicle vehicle) {
        vehicles.remove(vehicle);
    }

    @Override
    public void displayDetails() {
        for (Vehicle vehicle : vehicles) {
            vehicle.displayDetails();
        }
    }
}