public interface Vehicle {
    void displayDetails();
}