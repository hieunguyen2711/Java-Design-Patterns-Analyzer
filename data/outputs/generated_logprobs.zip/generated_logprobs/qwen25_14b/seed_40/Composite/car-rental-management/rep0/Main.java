public class Main {
    public static void main(String[] args) {
        Fleet fleet = new Fleet();
        
        // Adding individual cars to the fleet
        fleet.addVehicle(new Car("ABC123"));
        fleet.addVehicle(new Car("DEF456"));
        
        // Adding a composite fleet (sub-fleet)
        Fleet subFleet = new Fleet();
        subFleet.addVehicle(new Car("GHI789"));
        fleet.addVehicle(subFleet);
        
        // Display details of all vehicles in the fleet
        fleet.displayDetails();
    }
}