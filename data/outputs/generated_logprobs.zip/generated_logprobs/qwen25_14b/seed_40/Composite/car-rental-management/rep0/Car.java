import java.util.Arrays;

public class Car implements Vehicle {
    private String licensePlate;
    private boolean reserved;

    public Car(String licensePlate) {
        this.licensePlate = licensePlate;
        this.reserved = false;
    }

    @Override
    public void displayDetails() {
        System.out.println("Car with license plate " + licensePlate + " is " + (reserved ? "reserved" : "available"));
    }
}