package clinic;

public class Patient {
    private String name;

    public Patient(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void visit(AppointmentSlot slot) {
        slot.checkIn(this);
    }
}