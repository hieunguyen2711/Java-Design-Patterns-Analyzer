package clinic;

public class AppointmentSlot {
    private String slotTime;

    public AppointmentSlot(String slotTime) {
        this.slotTime = slotTime;
    }

    public void checkIn(Patient patient) {
        System.out.println(patient.getName() + " checked into " + slotTime);
    }
}