package clinic;

public class Clinic {
    public static void main(String[] args) {
        Component doctor1 = new Leaf("Dr. John Doe");
        Component doctor2 = new Leaf("Dr. Jane Smith");

        Composite morningSlots = new Composite("Morning Slots");
        morningSlots.add(new AppointmentSlot("9:00 AM"));
        morningSlots.add(new AppointmentSlot("10:00 AM"));

        Composite afternoonSlots = new Composite("Afternoon Slots");
        afternoonSlots.add(new AppointmentSlot("2:00 PM"));
        afternoonSlots.add(new AppointmentSlot("3:00 PM"));

        Composite allSlots = new Composite("All Slots");
        allSlots.add(morningSlots);
        allSlots.add(afternoonSlots);

        Patient patient1 = new Patient("Alice");
        Patient patient2 = new Patient("Bob");

        ((AppointmentSlot) morningSlots.children.get(0)).checkIn(patient1);
        ((AppointmentSlot) afternoonSlots.children.get(1)).checkIn(patient2);

        allSlots.display();
    }
}