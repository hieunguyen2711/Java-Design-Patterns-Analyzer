package com.example.membership;

public class IndividualMembership implements MembershipComponent {

    private String memberName;
    private String membershipType;

    public IndividualMembership(String memberName, String membershipType) {
        this.memberName = memberName;
        this.membershipType = membershipType;
    }

    @Override
    public void printDetails() {
        System.out.println("Member Name: " + memberName + ", Membership Type: " + membershipType);
    }
}