package com.example.membership;

import java.util.ArrayList;
import java.util.List;

public class FamilyMembership implements MembershipComponent {

    private List<MembershipComponent> members = new ArrayList<>();
    private String familyHeadName;

    public FamilyMembership(String familyHeadName) {
        this.familyHeadName = familyHeadName;
    }

    public void addMember(MembershipComponent member) {
        members.add(member);
    }

    public void removeMember(MembershipComponent member) {
        members.remove(member);
    }

    @Override
    public void printDetails() {
        System.out.println("Family Head: " + familyHeadName);
        for (MembershipComponent member : members) {
            member.printDetails();
        }
    }
}