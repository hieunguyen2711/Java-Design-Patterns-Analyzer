package com.example.membership;

public interface MembershipComponent {
    void printDetails();
}