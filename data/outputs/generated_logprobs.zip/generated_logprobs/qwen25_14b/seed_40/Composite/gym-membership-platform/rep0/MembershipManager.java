package com.example.membership;

public class MembershipManager {
    public static void main(String[] args) {
        MembershipComponent individual1 = new IndividualMembership("Alice", "Basic");
        MembershipComponent individual2 = new IndividualMembership("Bob", "Premium");

        FamilyMembership family = new FamilyMembership("Charlie");
        family.addMember(individual1);
        family.addMember(individual2);

        System.out.println("Printing Family Membership Details:");
        family.printDetails();
    }
}