package com.library.system;

import com.library.components.Book;
import com.library.components.LibraryComposite;
import com.library.components.Member;

public class LibrarySystem {
    public static void main(String[] args) {
        LibraryComposite root = new LibraryComposite();

        LibraryComposite books = new LibraryComposite();
        books.add(new Book("Java Concurrency in Practice", "Brian Goetz"));
        books.add(new Book("Effective Java", "Joshua Bloch"));

        LibraryComposite members = new LibraryComposite();
        members.add(new Member("001", "Alice"));
        members.add(new Member("002", "Bob"));

        root.add(books);
        root.add(members);

        root.displayDetails();
    }
}