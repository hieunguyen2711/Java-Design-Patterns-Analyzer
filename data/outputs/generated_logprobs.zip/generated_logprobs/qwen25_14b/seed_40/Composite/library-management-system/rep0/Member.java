package com.library.components;

public class Member implements LibraryComponent {
    private String memberId;
    private String name;

    public Member(String memberId, String name) {
        this.memberId = memberId;
        this.name = name;
    }

    @Override
    public void displayDetails() {
        System.out.println("Member ID: " + memberId + ", Name: " + name);
    }
}