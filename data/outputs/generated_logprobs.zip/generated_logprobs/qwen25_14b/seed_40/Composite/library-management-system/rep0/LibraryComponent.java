package com.library.components;

public interface LibraryComponent {
    void displayDetails();
}