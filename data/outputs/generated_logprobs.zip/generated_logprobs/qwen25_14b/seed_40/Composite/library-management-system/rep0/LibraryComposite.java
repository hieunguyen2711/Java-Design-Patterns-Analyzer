package com.library.components;

import java.util.ArrayList;
import java.util.List;

public class LibraryComposite implements LibraryComponent {
    private List<LibraryComponent> components = new ArrayList<>();

    public void add(LibraryComponent component) {
        components.add(component);
    }

    public void remove(LibraryComponent component) {
        components.remove(component);
    }

    @Override
    public void displayDetails() {
        for (LibraryComponent component : components) {
            component.displayDetails();
        }
    }
}