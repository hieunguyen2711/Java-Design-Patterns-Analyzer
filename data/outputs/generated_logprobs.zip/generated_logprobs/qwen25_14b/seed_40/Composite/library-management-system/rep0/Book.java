package com.library.components;

public class Book implements LibraryComponent {
    private String title;
    private String author;

    public Book(String title, String author) {
        this.title = title;
        this.author = author;
    }

    @Override
    public void displayDetails() {
        System.out.println("Book Title: " + title + ", Author: " + author);
    }
}