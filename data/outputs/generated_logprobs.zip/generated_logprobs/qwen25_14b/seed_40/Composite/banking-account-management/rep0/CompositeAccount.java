import java.util.ArrayList;
import java.util.List;

public class CompositeAccount extends Account {
    private List<Account> accounts;

    public CompositeAccount(String id) {
        super(id);
        this.accounts = new ArrayList<>();
    }

    public void add(Account account) {
        accounts.add(account);
    }

    public void remove(Account account) {
        accounts.remove(account);
    }

    @Override
    public void deposit(double amount) {
        distributeAmount(amount, true);
    }

    @Override
    public void withdraw(double amount) {
        distributeAmount(amount, false);
    }

    private void distributeAmount(double amount, boolean isDeposit) {
        double totalBalance = 0;
        for (Account account : accounts) {
            totalBalance += account.getBalance();
        }

        double share = amount / accounts.size();

        for (Account account : accounts) {
            if (isDeposit) {
                account.deposit(share);
            } else {
                account.withdraw(share);
            }
        }
    }
}