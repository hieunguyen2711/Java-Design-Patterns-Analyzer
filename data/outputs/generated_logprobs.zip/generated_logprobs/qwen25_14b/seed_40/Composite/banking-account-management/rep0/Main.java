public class Main {
    public static void main(String[] args) {
        // Create individual accounts
        Account savingsAccount1 = new SavingsAccount("SAV1");
        Account savingsAccount2 = new SavingsAccount("SAV2");

        // Deposit and withdraw operations on individual accounts
        savingsAccount1.deposit(1000);
        savingsAccount2.deposit(2000);

        savingsAccount1.withdraw(500);
        savingsAccount2.withdraw(700);

        // Create a composite account and add individual accounts to it
        Account compositeAccount = new CompositeAccount("COMPOSITE1");
        compositeAccount.add(savingsAccount1);
        compositeAccount.add(savingsAccount2);

        // Deposit and withdraw operations on the composite account
        compositeAccount.deposit(3000);
        compositeAccount.withdraw(1000);

        // Generate statements
        AccountStatementGenerator.generateStatement(compositeAccount);
        AccountStatementGenerator.generateStatement(savingsAccount1);
        AccountStatementGenerator.generateStatement(savingsAccount2);
    }
}