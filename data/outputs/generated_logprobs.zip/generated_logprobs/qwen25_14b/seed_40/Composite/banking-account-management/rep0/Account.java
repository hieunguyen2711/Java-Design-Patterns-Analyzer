public abstract class Account {
    private String id;

    public Account(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public abstract void deposit(double amount);
    public abstract void withdraw(double amount);
}