import java.util.ArrayList;
import java.util.List;

public class SavingsAccount extends Account {
    private double balance;
    private List<String> transactionHistory;

    public SavingsAccount(String id) {
        super(id);
        this.balance = 0;
        this.transactionHistory = new ArrayList<>();
    }

    @Override
    public void deposit(double amount) {
        balance += amount;
        transactionHistory.add("Deposited " + amount);
    }

    @Override
    public void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
            transactionHistory.add("Withdrawn " + amount);
        } else {
            System.out.println("Insufficient funds");
        }
    }

    public double getBalance() {
        return balance;
    }

    public List<String> getTransactionHistory() {
        return transactionHistory;
    }
}