public class AccountStatementGenerator {
    public static void generateStatement(Account account) {
        if (account instanceof CompositeAccount) {
            System.out.println("Composite Account Statement:");
            for (Account subAccount : ((CompositeAccount) account).accounts) {
                System.out.println("Sub-account ID: " + subAccount.getId());
                System.out.println("Balance: $" + subAccount.getBalance());
                System.out.println("Transactions: ");
                for (String transaction : ((SavingsAccount) subAccount).getTransactionHistory()) {
                    System.out.println("- " + transaction);
                }
                System.out.println("-----------------------------");
            }
        } else {
            System.out.println("Account ID: " + account.getId());
            System.out.println("Balance: $" + ((SavingsAccount) account).getBalance());
            System.out.println("Transactions: ");
            for (String transaction : ((SavingsAccount) account).getTransactionHistory()) {
                System.out.println("- " + transaction);
            }
        }
    }
}