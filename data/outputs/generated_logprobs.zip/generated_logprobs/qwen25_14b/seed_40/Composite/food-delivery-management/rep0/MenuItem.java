import java.util.*;

public class MenuItem implements MenuComponent {
    private String name;
    private String description;
    private double price;
    private boolean vegetarian;

    public MenuItem(String name, String description, double price, boolean vegetarian) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.vegetarian = vegetarian;
    }

    @Override
    public void add(MenuComponent menuComponent) {
        throw new UnsupportedOperationException("MenuItem cannot have children");
    }

    @Override
    public void remove(MenuComponent menuComponent) {
        throw new UnsupportedOperationException("MenuItem cannot have children");
    }

    @Override
    public MenuComponent getChild(int i) {
        throw new UnsupportedOperationException("MenuItem cannot have children");
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getPrice() {
        return Double.toString(price);
    }

    @Override
    public void print() {
        System.out.print(" " + (vegetarian ? "(v)" : "") + " " + getName() + ", ");
        System.out.println(getPrice() + " -- " + getDescription());
    }

    public String getDescription() {
        return description;
    }
}