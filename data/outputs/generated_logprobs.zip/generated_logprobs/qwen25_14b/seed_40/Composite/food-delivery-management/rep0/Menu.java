import java.util.*;

public class Menu implements MenuComponent {
    private String name;
    private String description;
    private List<MenuComponent> menuComponents = new ArrayList<>();

    public Menu(String name, String description) {
        this.name = name;
        this.description = description;
    }

    @Override
    public void add(MenuComponent menuComponent) {
        menuComponents.add(menuComponent);
    }

    @Override
    public void remove(MenuComponent menuComponent) {
        menuComponents.remove(menuComponent);
    }

    @Override
    public MenuComponent getChild(int i) {
        return menuComponents.get(i);
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getPrice() {
        return null; // Not applicable for a menu
    }

    @Override
    public void print() {
        System.out.print("\n" + getName() + "\n");
        System.out.print(description + "\n--------------------------------\n");

        for (MenuComponent menuComponent : menuComponents) {
            menuComponent.print();
        }
    }
}