package com.example.lms;

public class Main {
    public static void main(String[] args) {
        Component course = new Composite("Java Programming");
        Component module1 = new Composite("Module 1 - Basics");
        Component module2 = new Composite("Module 2 - Advanced Topics");

        Component assignment1 = new Leaf("Assignment 1");
        Component assignment2 = new Leaf("Assignment 2");

        module1.add(assignment1);
        module2.add(assignment2);

        course.add(module1);
        course.add(module2);

        course.printStructure(0);
    }
}