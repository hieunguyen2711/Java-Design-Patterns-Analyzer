package com.example.lms;

import java.util.ArrayList;
import java.util.List;

public class Composite implements Component {

    private final String name;
    private final List<Component> children = new ArrayList<>();

    public Composite(String name) {
        this.name = name;
    }

    @Override
    public void add(Component component) {
        children.add(component);
    }

    @Override
    public void remove(Component component) {
        children.remove(component);
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void printStructure(int depth) {
        System.out.println("-".repeat(depth * 2) + getName());
        for (Component child : children) {
            child.printStructure(depth + 1);
        }
    }
}