package com.example.lms;

public class Leaf implements Component {

    private final String name;

    public Leaf(String name) {
        this.name = name;
    }

    @Override
    public void add(Component component) {
        // Leafs cannot have children
    }

    @Override
    public void remove(Component component) {
        // Leafs cannot have children
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void printStructure(int depth) {
        System.out.println("-".repeat(depth * 2) + getName());
    }
}