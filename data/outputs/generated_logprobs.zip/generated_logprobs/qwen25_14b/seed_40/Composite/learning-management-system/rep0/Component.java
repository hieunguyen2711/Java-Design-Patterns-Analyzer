package com.example.lms;

public interface Component {
    void add(Component component);
    void remove(Component component);
    String getName();
    void printStructure(int depth);
}