package com.example.inventory;

public class BookingManager {
    public static void main(String[] args) {
        // Example of booking a simple room
        Room simpleRoom = new SimpleRoom("A1", 150.0);
        System.out.println("Simple Room Total Price: " + simpleRoom.calculateTotalPrice(2));

        // Example of booking a suite with two rooms
        Room simpleRoom2 = new SimpleRoom("B2", 180.0);
        Suite suite = new Suite("SUITE1", 300.0);
        suite.addRoom(simpleRoom);
        suite.addRoom(simpleRoom2);
        System.out.println("Suite Total Price: " + suite.calculateTotalPrice(2));
    }
}