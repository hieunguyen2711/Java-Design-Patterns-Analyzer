package com.example.inventory;

public abstract class Room {
    private String roomId;
    private double pricePerNight;

    public Room(String roomId, double pricePerNight) {
        this.roomId = roomId;
        this.pricePerNight = pricePerNight;
    }

    public String getRoomId() {
        return roomId;
    }

    public double getPricePerNight() {
        return pricePerNight;
    }

    public abstract double calculateTotalPrice(int nights);
}