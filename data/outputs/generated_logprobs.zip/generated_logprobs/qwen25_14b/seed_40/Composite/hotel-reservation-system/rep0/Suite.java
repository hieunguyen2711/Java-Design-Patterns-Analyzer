package com.example.inventory;

import java.util.ArrayList;
import java.util.List;

public class Suite extends Room {
    private List<Room> rooms;

    public Suite(String roomId, double basePrice) {
        super(roomId, basePrice);
        this.rooms = new ArrayList<>();
    }

    public void addRoom(Room room) {
        rooms.add(room);
    }

    public void removeRoom(Room room) {
        rooms.remove(room);
    }

    @Override
    public double calculateTotalPrice(int nights) {
        double totalPrice = 0;
        for (Room room : rooms) {
            totalPrice += room.calculateTotalPrice(nights);
        }
        return totalPrice;
    }
}