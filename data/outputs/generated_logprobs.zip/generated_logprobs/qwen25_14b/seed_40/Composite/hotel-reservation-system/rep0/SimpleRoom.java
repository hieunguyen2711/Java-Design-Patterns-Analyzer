package com.example.inventory;

public class SimpleRoom extends Room {
    public SimpleRoom(String roomId, double pricePerNight) {
        super(roomId, pricePerNight);
    }

    @Override
    public double calculateTotalPrice(int nights) {
        return getPricePerNight() * nights;
    }
}