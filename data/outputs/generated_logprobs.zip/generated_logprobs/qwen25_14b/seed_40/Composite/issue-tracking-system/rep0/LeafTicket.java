public class LeafTicket extends Ticket {
    public LeafTicket(String id, String title, String description) {
        super(id, title, description);
    }

    @Override
    public void add(Ticket component) {
        throw new UnsupportedOperationException("Leaf tickets cannot have components.");
    }

    @Override
    public void remove(Ticket component) {
        throw new UnsupportedOperationException("Leaf tickets cannot have components.");
    }

    @Override
    public void display() {
        System.out.println("Ticket ID: " + id + ", Title: " + title + ", Description: " + description);
    }
}