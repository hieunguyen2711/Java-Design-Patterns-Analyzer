public class TicketTracker {
    public static void main(String[] args) {
        CompositeTicket parentTicket = new CompositeTicket("T1", "Parent Ticket", "This is a parent ticket.");
        
        LeafTicket childTicket1 = new LeafTicket("T2", "Child Ticket 1", "This is a child ticket under parent.");
        LeafTicket childTicket2 = new LeafTicket("T3", "Child Ticket 2", "Another child ticket under parent.");
        
        parentTicket.add(childTicket1);
        parentTicket.add(childTicket2);
        
        parentTicket.display();
    }
}