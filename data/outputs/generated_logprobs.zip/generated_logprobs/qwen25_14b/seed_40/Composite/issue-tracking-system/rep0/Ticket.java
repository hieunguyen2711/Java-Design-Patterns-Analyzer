public abstract class Ticket {
    protected String id;
    protected String title;
    protected String description;

    public Ticket(String id, String title, String description) {
        this.id = id;
        this.title = title;
        this.description = description;
    }

    public abstract void add(Ticket component);
    public abstract void remove(Ticket component);
    public abstract void display();
}