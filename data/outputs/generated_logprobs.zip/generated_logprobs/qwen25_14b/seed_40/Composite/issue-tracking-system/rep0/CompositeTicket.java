import java.util.ArrayList;
import java.util.List;

public class CompositeTicket extends Ticket {
    private List<Ticket> children = new ArrayList<>();

    public CompositeTicket(String id, String title, String description) {
        super(id, title, description);
    }

    @Override
    public void add(Ticket component) {
        children.add(component);
    }

    @Override
    public void remove(Ticket component) {
        children.remove(component);
    }

    @Override
    public void display() {
        System.out.println("Composite Ticket ID: " + id + ", Title: " + title + ", Description: " + description);
        for (Ticket child : children) {
            child.display();
        }
    }
}