import java.util.ArrayList;
import java.util.List;

public class Composite implements Component {
    private String name;
    private List<Component> children = new ArrayList<>();

    public Composite(String name) {
        this.name = name;
    }

    @Override
    public void add(Component component) {
        children.add(component);
    }

    @Override
    public void remove(Component component) {
        children.remove(component);
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void display(int depth) {
        // Print spaces to indicate depth
        for (int i = 0; i < depth; i++) {
            System.out.print(" ");
        }
        System.out.println(name);

        // Recursively display child components
        for (Component component : children) {
            component.display(depth + 4);
        }
    }
}