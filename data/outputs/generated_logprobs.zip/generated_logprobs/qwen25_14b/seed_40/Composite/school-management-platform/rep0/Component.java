public interface Component {
    void add(Component component);
    void remove(Component component);
    String getName();
    void display(int depth);
}