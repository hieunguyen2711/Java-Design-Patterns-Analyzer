public class Client {
    public static void main(String[] args) {
        Component root = new Composite("School");

        Component departmentOfMathematics = new Composite("Department of Mathematics");
        Component departmentOfPhysics = new Composite("Department of Physics");

        Component professorSmith = new Leaf("Professor Smith");
        Component professorJones = new Leaf("Professor Jones");

        departmentOfMathematics.add(professorSmith);
        departmentOfPhysics.add(professorJones);

        root.add(departmentOfMathematics);
        root.add(departmentOfPhysics);

        root.display(0);
    }
}