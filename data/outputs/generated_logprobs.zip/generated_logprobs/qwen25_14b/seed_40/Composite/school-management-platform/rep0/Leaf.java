import java.util.Arrays;

public class Leaf implements Component {
    private String name;

    public Leaf(String name) {
        this.name = name;
    }

    @Override
    public void add(Component component) {
        // Leaf nodes cannot have children
        throw new UnsupportedOperationException("Leaf nodes cannot have children");
    }

    @Override
    public void remove(Component component) {
        // Leaf nodes cannot have children
        throw new UnsupportedOperationException("Leaf nodes cannot have children");
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void display(int depth) {
        // Print spaces to indicate depth
        for (int i = 0; i < depth; i++) {
            System.out.print(" ");
        }
        System.out.println(name);
    }
}