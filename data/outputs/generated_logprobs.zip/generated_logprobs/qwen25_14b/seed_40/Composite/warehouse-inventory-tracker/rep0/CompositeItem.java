import java.util.ArrayList;
import java.util.List;

public class CompositeItem implements Item {
    private String name;
    private List<Item> children;
    private Map<String, Integer> quantitiesByLocation;

    public CompositeItem(String name) {
        this.name = name;
        this.children = new ArrayList<>();
        this.quantitiesByLocation = new HashMap<>();
    }

    @Override
    public void add(Item item) {
        children.add(item);
    }

    @Override
    public void remove(Item item) {
        children.remove(item);
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getQuantity() {
        int totalQuantity = 0;
        for (Item child : children) {
            if (child instanceof LeafItem) {
                totalQuantity += ((LeafItem) child).getQuantity();
            } else {
                totalQuantity += ((CompositeItem) child).getQuantity();
            }
        }
        return totalQuantity;
    }

    @Override
    public void setQuantity(int quantity) {
        // Composite items don't directly set quantity, they aggregate it.
    }

    @Override
    public void setLocation(String location) {
        // Composite items don't have a location, they manage their children's locations.
    }

    @Override
    public String getLocation() {
        // Composite items don't have a location, they manage their children's locations.
        return null;
    }

    public void updateQuantitiesByLocation() {
        quantitiesByLocation.clear();
        for (Item child : children) {
            String childLocation = child.getLocation();
            int childQuantity = child.getQuantity();
            quantitiesByLocation.put(childLocation, quantitiesByLocation.getOrDefault(childLocation, 0) + childQuantity);
        }
    }

    public Map<String, Integer> getQuantitiesByLocation() {
        return quantitiesByLocation;
    }
}