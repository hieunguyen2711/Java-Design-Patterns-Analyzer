public interface Item {
    void add(Item item);
    void remove(Item item);
    String getName();
    int getQuantity();
    void setQuantity(int quantity);
    void setLocation(String location);
    String getLocation();
}