import java.util.HashMap;
import java.util.Map;

public class LeafItem implements Item {
    private String name;
    private int quantity;
    private String location;

    public LeafItem(String name) {
        this.name = name;
        this.quantity = 0;
        this.location = "Unknown";
    }

    @Override
    public void add(Item item) {
        throw new UnsupportedOperationException("Leaf items cannot have children.");
    }

    @Override
    public void remove(Item item) {
        throw new UnsupportedOperationException("Leaf items cannot have children.");
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getQuantity() {
        return quantity;
    }

    @Override
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Override
    public void setLocation(String location) {
        this.location = location;
    }

    @Override
    public String getLocation() {
        return location;
    }
}