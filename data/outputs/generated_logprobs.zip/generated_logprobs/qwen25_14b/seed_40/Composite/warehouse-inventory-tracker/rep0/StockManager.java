public class StockManager {
    public static void main(String[] args) {
        CompositeItem electronics = new CompositeItem("Electronics");
        CompositeItem computers = new CompositeItem("Computers");
        CompositeItem phones = new CompositeItem("Phones");

        LeafItem laptop = new LeafItem("Laptop");
        LeafItem desktop = new LeafItem("Desktop");
        LeafItem smartphone = new LeafItem("Smartphone");

        laptop.setQuantity(10);
        laptop.setLocation("Warehouse A");
        desktop.setQuantity(5);
        desktop.setLocation("Warehouse B");
        smartphone.setQuantity(20);
        smartphone.setLocation("Warehouse C");

        computers.add(laptop);
        computers.add(desktop);
        phones.add(smartphone);

        electronics.add(computers);
        electronics.add(phones);

        System.out.println("Total Quantity of Electronics: " + electronics.getQuantity());
        electronics.updateQuantitiesByLocation();
        System.out.println("Quantity by Location: " + electronics.getQuantitiesByLocation());
    }
}