public class PayrollSystem {
    public static void main(String[] args) {
        Manager manager = new Manager("John Doe", 1001);
        RegularEmployee emp1 = new RegularEmployee("Jane Smith", 1002);
        RegularEmployee emp2 = new RegularEmployee("Sam Johnson", 1003);

        manager.add(emp1);
        manager.add(emp2);

        System.out.println("Manager's Salary: " + manager.calculateSalary());
    }
}