public class RegularEmployee extends Employee {
    public RegularEmployee(String name, int id) {
        super(name, id);
    }

    @Override
    public double calculateSalary() {
        return 2000; // Fixed salary for regular employees
    }
}