import java.util.ArrayList;
import java.util.List;

public class Manager extends Employee {
    private List<Employee> subordinates;

    public Manager(String name, int id) {
        super(name, id);
        this.subordinates = new ArrayList<>();
    }

    @Override
    public double calculateSalary() {
        double totalSalary = 0;
        for (Employee subordinate : subordinates) {
            totalSalary += subordinate.calculateSalary();
        }
        return totalSalary + 5000; // Base salary of manager plus subordinates' salaries
    }

    public void add(Employee employee) {
        subordinates.add(employee);
    }

    public void remove(Employee employee) {
        subordinates.remove(employee);
    }
}