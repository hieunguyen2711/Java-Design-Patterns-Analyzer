public class BasicRoom implements Room {
    @Override
    public String getDescription() {
        return "Basic Room";
    }

    @Override
    public double cost() {
        return 100.0;
    }
}