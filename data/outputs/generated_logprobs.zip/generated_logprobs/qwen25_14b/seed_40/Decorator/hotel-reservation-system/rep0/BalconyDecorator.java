public class BalconyDecorator extends RoomDecorator {
    public BalconyDecorator(Room room) {
        super(room);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + ", with a balcony";
    }

    @Override
    public double cost() {
        return super.cost() + 30.0;
    }
}