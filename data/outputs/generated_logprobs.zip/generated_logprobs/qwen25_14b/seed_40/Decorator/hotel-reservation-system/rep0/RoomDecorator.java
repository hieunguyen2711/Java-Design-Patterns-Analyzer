public abstract class RoomDecorator implements Room {
    protected final Room room;

    public RoomDecorator(Room room) {
        this.room = room;
    }

    @Override
    public String getDescription() {
        return room.getDescription();
    }

    @Override
    public double cost() {
        return room.cost();
    }
}