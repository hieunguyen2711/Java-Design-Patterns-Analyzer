public class LuxuryBathroomDecorator extends RoomDecorator {
    public LuxuryBathroomDecorator(Room room) {
        super(room);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + ", with a luxury bathroom";
    }

    @Override
    public double cost() {
        return super.cost() + 50.0;
    }
}