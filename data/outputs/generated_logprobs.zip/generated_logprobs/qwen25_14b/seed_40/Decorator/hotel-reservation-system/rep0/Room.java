public interface Room {
    String getDescription();
    double cost();
}