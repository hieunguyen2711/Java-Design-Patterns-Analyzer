public class StockItem implements Item {
    private String name;
    private int quantity;

    public StockItem(String name) {
        this.name = name;
        this.quantity = 0;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getQuantity() {
        return quantity;
    }

    @Override
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}