public abstract class ItemDecorator implements Item {
    protected final Item item;

    public ItemDecorator(Item item) {
        this.item = item;
    }

    @Override
    public String getName() {
        return item.getName();
    }

    @Override
    public int getQuantity() {
        return item.getQuantity();
    }

    @Override
    public void setQuantity(int quantity) {
        item.setQuantity(quantity);
    }
}