public class ReorderThresholdDecorator extends ItemDecorator {
    private int threshold;

    public ReorderThresholdDecorator(Item item, int threshold) {
        super(item);
        this.threshold = threshold;
    }

    public boolean needsReordering() {
        return getQuantity() <= threshold;
    }
}