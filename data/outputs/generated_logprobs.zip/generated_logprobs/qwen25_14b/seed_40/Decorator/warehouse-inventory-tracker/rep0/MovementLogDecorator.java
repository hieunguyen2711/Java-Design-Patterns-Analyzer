import java.util.ArrayList;
import java.util.List;

public class MovementLogDecorator extends ItemDecorator {
    private List<String> logs = new ArrayList<>();

    public MovementLogDecorator(Item item) {
        super(item);
    }

    public void logMovement(String movement) {
        logs.add(movement);
    }

    public List<String> getLogs() {
        return logs;
    }
}