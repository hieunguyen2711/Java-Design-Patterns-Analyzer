public interface Item {
    String getName();
    int getQuantity();
    void setQuantity(int quantity);
}