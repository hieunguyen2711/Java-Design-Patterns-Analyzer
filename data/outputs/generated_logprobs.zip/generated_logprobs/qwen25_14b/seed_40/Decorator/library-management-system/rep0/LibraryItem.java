package library;

import java.time.LocalDate;

public abstract class LibraryItem {
    private LocalDate dueDate;
    
    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }
    
    public abstract void borrow(Member member);
    public abstract void returnItem();
}