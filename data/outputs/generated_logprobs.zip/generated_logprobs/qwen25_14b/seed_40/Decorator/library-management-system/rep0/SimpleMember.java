package library;

public class SimpleMember implements Member {
    private int memberId;
    private String name;

    public SimpleMember(int memberId, String name) {
        this.memberId = memberId;
        this.name = name;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public int getMemberId() {
        return memberId;
    }

    @Override
    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }
}