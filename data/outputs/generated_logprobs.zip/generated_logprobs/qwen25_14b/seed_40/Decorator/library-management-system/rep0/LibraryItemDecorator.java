package library;

import java.time.LocalDate;

public class LibraryItemDecorator extends BookDecorator implements LibraryItem {
    public LibraryItemDecorator(Book book) {
        super(book);
    }

    @Override
    public void borrow(Member member) {
        System.out.println(member.getName() + " has borrowed " + getTitle());
    }

    @Override
    public void returnItem() {
        System.out.println(getTitle() + " has been returned.");
    }

    @Override
    public LocalDate getDueDate() {
        // Implement as needed based on specific requirements
        return null;
    }

    @Override
    public void setDueDate(LocalDate dueDate) {
        // Implement as needed based on specific requirements
    }
}