package library;

import java.time.LocalDate;

public class BorrowingSystem {
    public static void main(String[] args) {
        // Create a simple book
        Book book = new SimpleBook("Java Design Patterns", "A guide to common design patterns in Java");
        
        // Decorate the book with late fee calculation
        Book decoratedBook = new LateFeeDecorator((Book) new LibraryItemDecorator(book));
        
        // Simulate borrowing the book
        Member member = new SimpleMember(12345, "John Doe");
        ((LibraryItem)decoratedBook).borrow(member);
        ((LibraryItem)decoratedBook).setDueDate(LocalDate.now().plusDays(7));
        
        // Simulate returning the book after the due date
        double lateFee = ((LateFeeDecorator) decoratedBook).calculateLateFee(LocalDate.now().plusDays(10));
        System.out.println("Late Fee: $" + lateFee);
    }
}