package library;

public abstract class BookDecorator implements Book {
    protected final Book book;

    public BookDecorator(Book book) {
        this.book = book;
    }

    @Override
    public String getTitle() {
        return book.getTitle();
    }

    @Override
    public void setTitle(String title) {
        book.setTitle(title);
    }

    @Override
    public String getDescription() {
        return book.getDescription();
    }

    @Override
    public void setDescription(String description) {
        book.setDescription(description);
    }
}