package library;

public interface Member {
    String getName();
    void setName(String name);
    int getMemberId();
    void setMemberId(int memberId);
}