package library;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class LateFeeDecorator extends BookDecorator {
    private double dailyLateFee = 0.5; // Example fee

    public LateFeeDecorator(Book book) {
        super(book);
    }

    public double calculateLateFee(LocalDate returnDate) {
        LocalDate dueDate = ((LibraryItem)super).getDueDate();
        long daysLate = ChronoUnit.DAYS.between(dueDate, returnDate);
        return daysLate * dailyLateFee;
    }
}