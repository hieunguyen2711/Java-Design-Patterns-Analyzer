package library;

public interface Book {
    String getTitle();
    void setTitle(String title);
    String getDescription();
    void setDescription(String description);
}