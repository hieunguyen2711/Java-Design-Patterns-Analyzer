public class WithCertificateCourse extends CourseDecorator {
    public WithCertificateCourse(Course course) {
        super(course);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + " with certificate";
    }

    @Override
    public double getPrice() {
        return super.getPrice() + 50.0;
    }
}