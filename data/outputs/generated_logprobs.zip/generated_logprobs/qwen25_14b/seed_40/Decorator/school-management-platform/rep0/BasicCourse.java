public class BasicCourse implements Course {
    private String description;
    private double price;

    public BasicCourse(String description, double price) {
        this.description = description;
        this.price = price;
    }

    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public double getPrice() {
        return price;
    }
}