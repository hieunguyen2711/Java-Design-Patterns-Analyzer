public class WithOnlineAccessCourse extends CourseDecorator {
    public WithOnlineAccessCourse(Course course) {
        super(course);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + " with online access";
    }

    @Override
    public double getPrice() {
        return super.getPrice() + 25.0;
    }
}