public interface Course {
    String getDescription();
    double getPrice();
}