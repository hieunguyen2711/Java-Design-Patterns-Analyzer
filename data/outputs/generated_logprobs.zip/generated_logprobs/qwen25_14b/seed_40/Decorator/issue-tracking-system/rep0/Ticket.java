public interface Ticket {
    String getDescription();
    void addComment(String comment);
    String getStatus();
    void setStatus(String status);
    int getPriority();
}