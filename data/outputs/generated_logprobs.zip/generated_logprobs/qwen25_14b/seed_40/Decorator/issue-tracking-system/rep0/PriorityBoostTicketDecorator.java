public class PriorityBoostTicketDecorator extends TicketDecorator {
    public PriorityBoostTicketDecorator(Ticket ticket) {
        super(ticket);
    }

    @Override
    public int getPriority() {
        return Math.min(super.getPriority() - 1, 1); // Cannot go below priority level 1
    }
}