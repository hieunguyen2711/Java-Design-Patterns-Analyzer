public class StatusUpdateTicketDecorator extends TicketDecorator {
    private final String status;

    public StatusUpdateTicketDecorator(Ticket ticket, String status) {
        super(ticket);
        this.status = status;
    }

    @Override
    public String getStatus() {
        return status;
    }
}