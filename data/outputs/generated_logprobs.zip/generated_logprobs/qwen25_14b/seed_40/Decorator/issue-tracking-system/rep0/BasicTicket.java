import java.util.ArrayList;
import java.util.List;

public class BasicTicket implements Ticket {
    private String description;
    private List<String> comments = new ArrayList<>();
    private String status;
    private int priority;

    public BasicTicket(String description, int priority) {
        this.description = description;
        this.status = "New";
        this.priority = priority;
    }

    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public void addComment(String comment) {
        comments.add(comment);
    }

    @Override
    public String getStatus() {
        return status;
    }

    @Override
    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public int getPriority() {
        return priority;
    }
}