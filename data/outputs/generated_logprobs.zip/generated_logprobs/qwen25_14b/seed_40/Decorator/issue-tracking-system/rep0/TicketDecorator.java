public abstract class TicketDecorator implements Ticket {
    protected final Ticket ticket;

    public TicketDecorator(Ticket ticket) {
        this.ticket = ticket;
    }

    @Override
    public String getDescription() {
        return ticket.getDescription();
    }

    @Override
    public void addComment(String comment) {
        ticket.addComment(comment);
    }

    @Override
    public String getStatus() {
        return ticket.getStatus();
    }

    @Override
    public void setStatus(String status) {
        ticket.setStatus(status);
    }

    @Override
    public int getPriority() {
        return ticket.getPriority();
    }
}