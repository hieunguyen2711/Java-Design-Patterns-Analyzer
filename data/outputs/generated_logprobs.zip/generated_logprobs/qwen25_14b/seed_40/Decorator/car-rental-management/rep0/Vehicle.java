public interface Vehicle {
    String getDescription();
    double getCostPerDay();
}