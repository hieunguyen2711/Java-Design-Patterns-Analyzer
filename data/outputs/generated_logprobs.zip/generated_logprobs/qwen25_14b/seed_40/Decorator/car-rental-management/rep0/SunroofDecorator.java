package decorators;

import vehicle.Vehicle;

public class SunroofDecorator extends VehicleDecorator {
    public SunroofDecorator(Vehicle vehicle) {
        super(vehicle);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + ", with Sunroof";
    }

    @Override
    public double getCostPerDay() {
        return super.getCostPerDay() + 20.0;
    }
}