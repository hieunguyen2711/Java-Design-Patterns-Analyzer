package vehicles;

import vehicle.Vehicle;

public class BasicCar implements Vehicle {
    @Override
    public String getDescription() {
        return "Basic Car";
    }

    @Override
    public double getCostPerDay() {
        return 50.0;
    }
}