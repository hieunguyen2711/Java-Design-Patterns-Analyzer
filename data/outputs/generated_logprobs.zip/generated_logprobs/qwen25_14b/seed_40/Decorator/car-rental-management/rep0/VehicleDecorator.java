package decorators;

import vehicle.Vehicle;

public abstract class VehicleDecorator implements Vehicle {
    protected final Vehicle vehicle;

    public VehicleDecorator(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    @Override
    public String getDescription() {
        return vehicle.getDescription();
    }

    @Override
    public double getCostPerDay() {
        return vehicle.getCostPerDay();
    }
}