package decorators;

import vehicle.Vehicle;

public class GPSNavigationDecorator extends VehicleDecorator {
    public GPSNavigationDecorator(Vehicle vehicle) {
        super(vehicle);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + ", with GPS Navigation";
    }

    @Override
    public double getCostPerDay() {
        return super.getCostPerDay() + 10.0;
    }
}