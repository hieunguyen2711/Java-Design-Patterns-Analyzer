import java.util.ArrayList;
import java.util.List;

public class BasicAccount implements Account {
    private double balance;
    private List<String> auditHistory = new ArrayList<>();

    @Override
    public void deposit(double amount) {
        balance += amount;
        auditHistory.add("Deposited " + amount);
    }

    @Override
    public void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
            auditHistory.add("Withdrawn " + amount);
        } else {
            auditHistory.add("Failed to withdraw " + amount + ", insufficient funds");
        }
    }

    @Override
    public String generateStatement() {
        StringBuilder statement = new StringBuilder("Balance: $" + balance + "\n");
        for (String entry : auditHistory) {
            statement.append(entry).append("\n");
        }
        return statement.toString();
    }
}