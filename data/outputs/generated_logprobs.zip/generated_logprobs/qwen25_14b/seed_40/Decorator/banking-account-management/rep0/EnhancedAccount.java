public class EnhancedAccount extends BasicAccount {
    // Additional features can be added here
}