public class AuditLogDecorator extends StatementDecorator {
    private final List<String> logEntries = new ArrayList<>();

    public AuditLogDecorator(Account account) {
        super(account);
    }

    @Override
    public void deposit(double amount) {
        super.deposit(amount);
        logEntries.add("Deposited " + amount);
    }

    @Override
    public void withdraw(double amount) {
        super.withdraw(amount);
        logEntries.add("Withdrawn " + amount);
    }

    @Override
    public String generateStatement() {
        return decoratedAccount.generateStatement() + "\nAudit Log:\n" + String.join("\n", logEntries);
    }
}