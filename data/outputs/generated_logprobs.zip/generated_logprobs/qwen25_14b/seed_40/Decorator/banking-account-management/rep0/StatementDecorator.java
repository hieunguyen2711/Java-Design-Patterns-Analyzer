public abstract class StatementDecorator implements Account {
    protected final Account decoratedAccount;

    public StatementDecorator(Account account) {
        this.decoratedAccount = account;
    }

    @Override
    public void deposit(double amount) {
        decoratedAccount.deposit(amount);
    }

    @Override
    public void withdraw(double amount) {
        decoratedAccount.withdraw(amount);
    }
}