package clinic;

public interface AppointmentSlot {
    void setDoctor(String doctor);
    String getDoctor();
    void setPatient(String patient);
    String getPatient();
    void checkIn();
    void visit();
}