package clinic;

public class ClinicApp {
    public static void main(String[] args) {
        AppointmentSlot basicAppointment = new BasicAppointmentSlot();
        basicAppointment.setDoctor("Dr. Smith");
        basicAppointment.setPatient("John Doe");
        basicAppointment.checkIn();
        basicAppointment.visit();

        System.out.println("\nAdding urgent care flag:");
        AppointmentSlot urgentAppointment = new UrgentCareDecorator(basicAppointment);
        urgentAppointment.visit();
    }
}