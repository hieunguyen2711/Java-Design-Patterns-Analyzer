package clinic;

import java.util.Date;

public class BasicAppointmentSlot implements AppointmentSlot {
    private String doctor;
    private String patient;
    private Date checkInTime;
    private boolean visited = false;

    @Override
    public void setDoctor(String doctor) {
        this.doctor = doctor;
    }

    @Override
    public String getDoctor() {
        return doctor;
    }

    @Override
    public void setPatient(String patient) {
        this.patient = patient;
    }

    @Override
    public String getPatient() {
        return patient;
    }

    @Override
    public void checkIn() {
        checkInTime = new Date();
        System.out.println("Patient " + patient + " checked in at " + checkInTime);
    }

    @Override
    public void visit() {
        if (visited) {
            System.out.println("Visit already completed.");
            return;
        }
        visited = true;
        System.out.println("Doctor " + doctor + " is now seeing patient " + patient);
    }
}