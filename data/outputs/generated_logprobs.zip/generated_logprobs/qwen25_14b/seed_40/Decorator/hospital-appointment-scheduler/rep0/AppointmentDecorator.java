package clinic;

public abstract class AppointmentDecorator implements AppointmentSlot {
    protected AppointmentSlot appointmentSlot;

    public AppointmentDecorator(AppointmentSlot appointmentSlot) {
        this.appointmentSlot = appointmentSlot;
    }

    @Override
    public void setDoctor(String doctor) {
        appointmentSlot.setDoctor(doctor);
    }

    @Override
    public String getDoctor() {
        return appointmentSlot.getDoctor();
    }

    @Override
    public void setPatient(String patient) {
        appointmentSlot.setPatient(patient);
    }

    @Override
    public String getPatient() {
        return appointmentSlot.getPatient();
    }

    @Override
    public void checkIn() {
        appointmentSlot.checkIn();
    }

    @Override
    public void visit() {
        appointmentSlot.visit();
    }
}