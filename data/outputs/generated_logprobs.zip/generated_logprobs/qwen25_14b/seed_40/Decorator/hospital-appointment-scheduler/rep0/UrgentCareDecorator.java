package clinic;

public class UrgentCareDecorator extends AppointmentDecorator {
    public UrgentCareDecorator(AppointmentSlot appointmentSlot) {
        super(appointmentSlot);
    }

    @Override
    public void visit() {
        System.out.println("Urgent care flag is set for this appointment.");
        super.visit();
    }
}