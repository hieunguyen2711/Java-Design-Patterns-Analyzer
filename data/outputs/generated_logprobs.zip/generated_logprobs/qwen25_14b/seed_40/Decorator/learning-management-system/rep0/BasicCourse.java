package com.example.lms;

public class BasicCourse extends Course {
    public BasicCourse(String courseName) {
        super(courseName);
    }

    @Override
    public void displayCourseDetails() {
        System.out.println("Basic Course: " + courseName);
    }
}