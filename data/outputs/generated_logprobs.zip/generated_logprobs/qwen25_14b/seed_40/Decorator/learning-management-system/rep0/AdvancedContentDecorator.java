package com.example.lms;

public class AdvancedContentDecorator extends CourseDecorator {
    public AdvancedContentDecorator(Course course) {
        super(course);
    }

    @Override
    public void displayCourseDetails() {
        course.displayCourseDetails();
        System.out.println("  + Advanced Content Added");
    }
}