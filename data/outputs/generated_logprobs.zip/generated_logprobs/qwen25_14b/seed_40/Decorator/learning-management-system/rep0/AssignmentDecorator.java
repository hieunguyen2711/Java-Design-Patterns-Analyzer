package com.example.lms;

public class AssignmentDecorator extends CourseDecorator {
    public AssignmentDecorator(Course course) {
        super(course);
    }

    @Override
    public void displayCourseDetails() {
        course.displayCourseDetails();
        System.out.println("  + Assignments Added");
    }
}