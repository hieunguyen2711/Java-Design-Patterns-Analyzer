package com.example.lms;

public abstract class CourseDecorator implements Course {
    protected final Course course;

    public CourseDecorator(Course course) {
        this.course = course;
    }

    @Override
    public abstract void displayCourseDetails();
}