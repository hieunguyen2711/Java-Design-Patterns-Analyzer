package com.example.lms;

public class Main {
    public static void main(String[] args) {
        // Creating a basic course
        Course javaCourse = new BasicCourse("Java Programming");
        
        // Adding advanced content decorator
        Course javaCourseWithAdvancedContent = new AdvancedContentDecorator(javaCourse);
        
        // Adding assignment decorator
        Course javaCourseWithAssignments = new AssignmentDecorator(javaCourseWithAdvancedContent);
        
        // Displaying the final course details
        javaCourseWithAssignments.displayCourseDetails();
    }
}