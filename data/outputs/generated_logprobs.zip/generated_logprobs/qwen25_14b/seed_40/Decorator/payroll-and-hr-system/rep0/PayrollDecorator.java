public abstract class PayrollDecorator implements Employee {
    protected Employee employee;

    public PayrollDecorator(Employee employee) {
        this.employee = employee;
    }

    @Override
    public String getName() {
        return employee.getName();
    }
}