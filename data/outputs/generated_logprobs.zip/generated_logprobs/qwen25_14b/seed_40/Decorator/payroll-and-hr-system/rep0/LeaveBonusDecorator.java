public class LeaveBonusDecorator extends PayrollDecorator {
    private final double bonusRate;

    public LeaveBonusDecorator(Employee employee, double bonusRate) {
        super(employee);
        this.bonusRate = bonusRate;
    }

    @Override
    public double getSalary() {
        return employee.getSalary() + (employee.getSalary() * bonusRate / 100);
    }
}