public class RegularEmployee implements Employee {
    private final String name;
    private final double salary;

    public RegularEmployee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public double getSalary() {
        return salary;
    }
}