public class TaxDeductionDecorator extends PayrollDecorator {
    private final double taxRate;

    public TaxDeductionDecorator(Employee employee, double taxRate) {
        super(employee);
        this.taxRate = taxRate;
    }

    @Override
    public double getSalary() {
        return employee.getSalary() - (employee.getSalary() * taxRate / 100);
    }
}