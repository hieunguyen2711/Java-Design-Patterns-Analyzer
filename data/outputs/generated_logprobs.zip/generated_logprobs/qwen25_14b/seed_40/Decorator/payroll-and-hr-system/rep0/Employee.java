public interface Employee {
    String getName();
    double getSalary();
}