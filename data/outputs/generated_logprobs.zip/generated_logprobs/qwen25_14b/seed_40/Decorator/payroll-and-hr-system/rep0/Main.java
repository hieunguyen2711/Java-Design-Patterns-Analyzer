public class Main {
    public static void main(String[] args) {
        Employee john = new RegularEmployee("John Doe", 50000);

        // Apply tax deduction
        Employee taxedJohn = new TaxDeductionDecorator(john, 20);

        // Apply leave bonus
        Employee bonusJohn = new LeaveBonusDecorator(taxedJohn, 10);

        System.out.println("Employee Name: " + bonusJohn.getName());
        System.out.println("Employee Salary: $" + bonusJohn.getSalary());
    }
}