public class UnlimitedClassesMembership extends MembershipDecorator {
    public UnlimitedClassesMembership(Membership membership) {
        super(membership);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + ", with unlimited classes";
    }

    @Override
    public double cost() {
        return super.cost() + 30.0;
    }
}