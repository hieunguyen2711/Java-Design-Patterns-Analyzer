public class Main {
    public static void main(String[] args) {
        Membership basicMembership = new BasicMembership();
        System.out.println(basicMembership.getDescription() + ": $" + basicMembership.cost());

        Membership trainerAccessMembership = new TrainerAccessMembership(basicMembership);
        System.out.println(trainerAccessMembership.getDescription() + ": $" + trainerAccessMembership.cost());

        Membership unlimitedClassesMembership = new UnlimitedClassesMembership(trainerAccessMembership);
        System.out.println(unlimitedClassesMembership.getDescription() + ": $" + unlimitedClassesMembership.cost());
    }
}