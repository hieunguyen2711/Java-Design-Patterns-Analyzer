public class BasicMembership implements Membership {
    @Override
    public String getDescription() {
        return "Basic Membership";
    }

    @Override
    public double cost() {
        return 50.0;
    }
}