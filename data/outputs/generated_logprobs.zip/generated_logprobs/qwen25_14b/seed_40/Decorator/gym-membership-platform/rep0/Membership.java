public interface Membership {
    String getDescription();
    double cost();
}