public abstract class MembershipDecorator implements Membership {
    protected final Membership membership;

    public MembershipDecorator(Membership membership) {
        this.membership = membership;
    }

    @Override
    public String getDescription() {
        return membership.getDescription();
    }

    @Override
    public double cost() {
        return membership.cost();
    }
}