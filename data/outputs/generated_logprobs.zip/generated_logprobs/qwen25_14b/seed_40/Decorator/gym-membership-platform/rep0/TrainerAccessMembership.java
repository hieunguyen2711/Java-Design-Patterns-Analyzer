public class TrainerAccessMembership extends MembershipDecorator {
    public TrainerAccessMembership(Membership membership) {
        super(membership);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + ", with access to personal trainers";
    }

    @Override
    public double cost() {
        return super.cost() + 20.0;
    }
}